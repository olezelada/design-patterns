-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle attachment count in the table KYP.FrameworkCount
--				On insert in the table KYP.CommunicationEntity
--				The trigger is written with the assumption that inserts on table KYP.CommunicationEntity
--				occur on a row by row basis and not bulk inserts to the table.
-- =============================================
CREATE TRIGGER [KYP].[trg_OnInsert_CommunicationEntity]
   ON [KYP].[CommunicationEntity]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (
		SELECT 1 
		FROM KYP.FrameworkCount A INNER JOIN INSERTED B 
			ON A.FrameworkEntityType = B.CommEntityType
			AND A.FrameworkEntityTypeID = B.CommEntityTypeID
	)
	UPDATE A 
		SET A.CommunicationCount= A.CommunicationCount + 1,
			A.ModifiedDate = getdate(), 
			A.ModifiedBy = 'Communication Increased'
	FROM KYP.FrameworkCount A INNER JOIN INSERTED B 
			ON A.FrameworkEntityType = B.CommEntityType
			AND A.FrameworkEntityTypeID = B.CommEntityTypeID


	ELSE 
	INSERT INTO [KYP].[FrameworkCount]
			  ([FrameworkEntityType]
			  ,[FrameworkEntityTypeID]
			  ,[NoteCount] 
			  ,[DocumentCount]
			  ,[CommunicationCount]
			  ,[CreatedDate]
			  ,[CreatedBy]
			  ,[ModifiedDate]
			  ,[ModifiedBy]
			  ,[IsDeleted])
     SELECT CommEntityType
           ,CommEntityTypeID
		   ,0 as NoteCount
		   ,0 as DocumentCount
           ,1 as CommunicationCount
           ,getdate() as CreatedDate
           ,'Communication Created' as CreatedBy
           ,NULL
           ,NULL
           ,0
	FROM INSERTED


END


GO

