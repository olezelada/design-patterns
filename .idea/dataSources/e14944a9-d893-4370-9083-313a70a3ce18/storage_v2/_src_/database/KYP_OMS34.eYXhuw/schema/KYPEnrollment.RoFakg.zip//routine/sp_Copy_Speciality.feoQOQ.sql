
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Speciality.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @@app_speciality_id : this is the SpecialityID Application that will be Create in Update Account, it is Null when account is create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Speciality]
	@account_party_id INT,
	@app_party_id INT,
	@last_action_user_id VARCHAR(100),
	@app_speciality_id INT = NULL
AS
BEGIN
	SET NOCOUNT ON 
	DECLARE @date_created DATE, @AccTranID  INT,@appID INT;
	DECLARE @AppNo varchar(15);
	
	SET @date_created =  GETDATE();
	SET @AccTranID= 0;
	
   IF not exists(select StateCode from KYP.OIS_App_Version where StateCode = 'MD') --MD-660 
   BEGIN
			--   AccountTransactionID DBAB-131 MD-660
		  IF @app_speciality_id IS NULL -- from Create
		  BEGIN
			SET @appID=@app_party_id;
		  END
		  
		  IF @app_party_id IS NULL -- From Tracking
		  BEGIN
			 SELECT @appID=partyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Speciality]
			 WHERE specialityID = @app_speciality_id     
		  END
		  
		   SELECT  @AccTranID=AccountTransactionID
		   FROM [KYPEnrollment].[AccountTransactions]
		   where AccountID= (select AccountID from kypenrollment.pAccount_PDM_Party  where partyID =@account_party_id)
			   AND ApplicationID = @appID
		   
		--
			IF @app_party_id IS NULL
			BEGIN
			
				INSERT INTO [KYPEnrollment].[pAccount_PDM_Speciality]
					   ([PartyID]
					   ,[TaxonomyCode]
					   ,[IsPrimary] 
					   ,[Speciality_Code] 
					   ,[Board] 
					   ,[CreatedBy]
					   ,[DateCreated]
					   ,[IsDeleted]
					   ,[LastAction]
					   ,[LastActionDate]
					   ,[LastActorUserID]
					   ,[LastActionApprovedBy]
					   ,[CurrentRecordFlag]
					   ,[Type]
					   ,AccountTransactionID
					   ,IsUpdate)
				SELECT @account_party_id
					   ,Upper([TaxonomyCode])
					   ,[IsPrimary] 
					   ,[Speciality_Code] 
					   ,[Board] 
					   ,[CreatedBy]
					   ,@date_created
					   ,[IsDeleted]
					   ,'C'
					   ,@date_created
					   ,@last_action_user_id
					   ,@last_action_user_id
					   ,1
					   ,[Type]
					   ,@AccTranID --   AccountTransactionID DBAB-131
					   ,0
				FROM [KYPPORTAL].[PortalKYP].[pPDM_Speciality] WHERE SpecialityID=@app_speciality_id 	
			  
			END
			ELSE
			BEGIN
				
					INSERT INTO [KYPEnrollment].[pAccount_PDM_Speciality]
					   ([PartyID]
					   ,[TaxonomyCode]
					   ,[IsPrimary] 
					   ,[Speciality_Code] 
					   ,[Board] 
					   ,[CreatedBy]
					   ,[DateCreated]
					   ,[IsDeleted]
					   ,[LastAction]
					   ,[LastActionDate]
					   ,[LastActorUserID]
					   ,[LastActionApprovedBy]
					   ,[CurrentRecordFlag]
					   ,[Type]
						,AccountTransactionID
					   ,IsUpdate)
				   SELECT @account_party_id
					   ,Upper([TaxonomyCode])
					   ,[IsPrimary] 
					   ,[Speciality_Code] 
					   ,[Board] 
					   ,[CreatedBy]
					   ,@date_created
					   ,[IsDeleted]
					   ,'C'
					   ,@date_created
					   ,@last_action_user_id
					   ,@last_action_user_id
					   ,1
					   ,[Type]
					   ,@AccTranID --   AccountTransactionID DBAB-131
					   ,0
				   FROM [KYPPORTAL].[PortalKYP].[pPDM_Speciality] WHERE PartyID=@app_party_id AND IsDeleted = 0
				
	END	
  END
  ELSE
  BEGIN
  	DECLARE @account_number VARCHAR(12);
  	DECLARE @is_chow VARCHAR(20);
    DECLARE @old_account_party_id INT;
  	
  	SELECT @account_number = AccountNumber FROM KYPEnrollment.pADM_Account WHERE PartyID = @account_party_id
  	SELECT TOP 1 @is_chow = ApplnType FROM KYP.ADM_Case WHERE AccountNo Like @account_number+'%' ORDER BY CaseID DESC
    
  	IF (@is_chow = 'CHOW')
  	BEGIN
  		SELECT @old_account_party_id = PartyID
		  FROM (SELECT ROW_NUMBER () OVER (ORDER BY AccountID DESC) AS RowNum, *
			      FROM KYPEnrollment.pADM_Account
			      WHERE AccountNumber LIKE @account_number+'%'
			      ) OldAccount
		  WHERE RowNum = 2
  	
  		EXEC KYPEnrollment.sp_Clone_Speciality @account_party_id, @old_account_party_id, @last_action_user_id
  	END
	
  END
END


GO

