


CREATE TRIGGER [KYP].[trg_ScreeningJournalEntry] 
   ON  [KYP].[ADM_Case_Screening_History]
   AFTER Insert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Declare 
    /*--------Variable declaration for KYP-1182 and KYP-1184-----------*/
        @MultipleCaseID varchar(500),
       -- @ApplicationID int,
       
        
        
        
     /*--------End of Variable declaration for KYP-1182 and KYP-1184-----------*/
    
    @AlertNo varchar(500),
    @AlertID int,
    @CurrentWFStatus varchar(50),
    @JournalEvent varchar(50),
    @Username varchar(25),
    @Description varchar(100),
    @PersonID int,
    @AssignToUserID int,
    @NotesDescription varchar(MAX),
    @FormattedContent VARCHAR(MAX),	/* KYP 3.4 - SCREEN 16 */
    @NotesTitle varchar(120),
    @Number varchar(20),
    @FirstName varchar(25),
    @LastName varchar(25),
    @Name varchar(100),
    @NoteID int,
    @CurrentDate datetime,
    @Currenttag varchar(5),
    @Notenumber varchar(15),
    @Type varchar(100),
    @SubType varchar(100),
    @RelatedEntityType varchar(50),
    @JournalDescription varchar(250),
    @CaseID int,
    @NoteEntityType varchar(100),
    @NoteEntityTypeID varchar(100),
    @NoteEntityDepID varchar(100),
    @NoteEntityDep varchar(100),
    @Level int,
    @SmartletParameter varchar(500),
    @IsLastLevel bit,
    @RelatedEntityID int,
    @FullName varchar(200),
    @IsExistID int,
    @NoteCount int,
    @IsExistCaseID int,
    @CaseNoteCNT int,
    @InfoID INT,
    @StatusCode int,
    
    
    -- START : Changes for KYP-2880 (NM-Enhancement) - By : Nitish Gondkar - 26-June-2013
    @body NVARCHAR(MAX),
	@EmailAddTo VARCHAR(500),		
	@EmailAddCC VARCHAR(500),
	@Sub VARCHAR(MAX),
	@ALIASNAME VARCHAR(100),
	@MultipleTrackingNo VARCHAR(800)
	
            
    Select @MultipleCaseID= MultipleCaseID from inserted
    select @CurrentDate=getdate()
    Select @AlertNo= AlertNo from inserted
    Select @JournalEvent=JournalEvent from inserted
    Select @NotesDescription=NotesDescription from inserted
    Select @FormattedContent=FormattedContent from inserted	/* KYP 3.4 - SCREEN 16 */
    Select @AlertID=AlertID from KYP.MDM_Alert where AlertNo=@AlertNo
    Select @CurrentWFStatus=CurrentWFStatus from KYP.MDM_Alert where AlertID=@AlertID
    Select @Username=UserName from inserted
    Select @AssignToUserID=AssignToUserID from inserted
    Select @InfoID = InfoID from inserted  
     
    Select @PersonID=PersonID from KYP.OIS_User where UserID=@Username
    Select @FullName=FullName from KYP.OIS_Person where PersonID=@PersonID
    Select @NotesTitle=LTRIM(RTRIM(SUBSTRING(NotesTitle,1,50))) from inserted
  
    Select @Number='NT-<NNNNNN>'
    Select @FirstName=FirstName from KYP.OIS_Person where PersonID=@PersonID
    Select @LastName=LastName from KYP.OIS_Person where PersonID=@PersonID
    Select @Name= @LastName +  COALESCE((', ' + @FirstName), '') 
    Select @Currenttag=Tag from KYP.OIS_Tag where Tag=','
    Select @Type=Type from inserted
    Select @RelatedEntityType=RelatedEntityType from inserted
    Select @CaseID= CaseID from inserted
    Select @SmartletParameter=SmartletParameter from inserted
    Select @SubType=SubType from inserted
    Select @RelatedEntityID=RelatedEntityID from inserted
    Select @CurrentWFStatus=CurrentWFStatus from inserted
    SELECT @MultipleTrackingNo=MultipleTrackingNo from inserted
    SELECT @StatusCode=StatusCodeNumber from inserted
    SELECT TOP 1 @ALIASNAME = KYPALIAS FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
    
    IF(LTRIM(RTRIM(ISNULL(@LastName,''))) != '') 
		BEGIN
			SELECT @Name= @LastName +  COALESCE((', ' + @FirstName), '') 
		END
    ELSE
		BEGIN
			SELECT @Name= @FirstName
		END
    
    
    IF (@ALIASNAME IS NULL OR @ALIASNAME = '')
    BEGIN
		SET @ALIASNAME = 'KYP';
    END 
    
	if  (@RelatedEntityType='SDM_Resolution' or @Type='Reopened')
	begin
		Select @Name=  @FirstName+' '+@LastName
	end
    
    if  (@NotesTitle is null)
    begin
       select @NotesTitle=substring(@NotesDescription,1,50)
    end
    
    /* insert journal entry*/  
    
    If (@JournalEvent='AssignToOther' or @JournalEvent= 'Team-Reassign')
    begin
		if @AlertNo is not null
		begin
            exec dbo.createAssignToOther @AlertNo,@JournalEvent,@Username,@AssignToUserID,@RelatedEntityType,
                                         @NotesDescription,@NotesTitle,@Number,@Currenttag,@Type,@SubType, @SmartletParameter
		end
    end
    /*This changes is for KYP-1182 */  
    /*---Insert jOURNAL ENTRY FOR  Screening Team APPLICATION------*/
	else if (@JournalEvent= 'Scr-Team-Reassign-App')
		begin
			if @MultipleCaseID is not null
				begin                        
					exec dbo.createAssignToOtherForApp @MultipleCaseID,@JournalEvent,@Username,@AssignToUserID,@RelatedEntityType,
                                             @NotesDescription,@NotesTitle,@Currenttag,@Number,@Type,@SubType
                                             /*START - Changes for http://jira/browse/KYP-2988 */
                                             ,@CurrentWFStatus
                                             /*END - Changes for http://jira/browse/KYP-2988 */
                                             
                                             ,@FormattedContent /* KYP 3.4 - SCREEN 16 */               
			end
		end
   
	else if (@JournalEvent= 'Scr-Unassigned-Reassign-App')
		begin
			if @MultipleCaseID is not null
				begin
					exec dbo.createAssignToOtherForApp @MultipleCaseID,@JournalEvent,@Username,@AssignToUserID,@RelatedEntityType,
                                             @NotesDescription,@NotesTitle,@Number,@Currenttag,@Type,@SubType
											
                                             ,@CurrentWFStatus
                                              ,@FormattedContent /* KYP 3.4 - SCREEN 16 */   
                                            
				end
		end
     /*---END OF Insert jOURNAL ENTRY FOR APPLICATION------*/
    else if @JournalEvent='AssignToSelf'
		begin
       --------Create journal entry for Assign to self business event---------
			if @AlertNo is not null
				begin
					exec dbo.createAssignToSelf @AlertNo,@JournalEvent,@Username,@AssignToUserID,@RelatedEntityType,
                                         @NotesDescription,@NotesTitle,@Number,@Currenttag,@Type,@SubType
                                          ,@FormattedContent /* KYP 3.4 - SCREEN 16 */ 
				end
		end
  
	
	/*Screening Workflow history changes */
			
		ELSE IF @JournalEvent = 'WF_InsertScreeningHistory'
		BEGIN
			
			IF @MultipleCaseID IS NOT null
			BEGIN
			
			 -- Declare Cursor
				 DECLARE lookupCur CURSOR FOR SELECT item FROM  fnSplitString(@MultipleCaseID, ',')
				
				 -- Open Cursor
				 OPEN lookupCur
				
				
				 -- Load first row from Cursor
				
				 FETCH NEXT FROM lookupCur INTO @CaseID
				
				 WHILE (@@FETCH_STATUS <> -1 ) -- Check for Final Row
				
				 BEGIN
				
				   IF ( @@FETCH_STATUS <> -2 ) -- Check for Error
				
				   BEGIN
				
				     EXEC [KYP].[sp_PopulateScreeningWorkflowHistory] @CaseID, @RelatedEntityType, @CurrentWFStatus, @Username, @NotesDescription, @MultipleTrackingNo,@StatusCode
				
				   END
				
				 -- Load next row into the Cursor
				
				 FETCH NEXT FROM lookupCur INTO @CaseID
				
				 END
				
				 -- Close and Deallocate
				
				 CLOSE lookupCur
				
				 DEALLOCATE lookupCur
		
				
			END
		ELSE 
			BEGIN
				EXEC [KYP].[sp_PopulateScreeningWorkflowHistory] @CaseID, @RelatedEntityType, @CurrentWFStatus, @Username, @NotesDescription, @MultipleTrackingNo,@StatusCode
			END
			
		END
	/*Screening Workflow history changes */
	
	
 
 IF(@JournalEvent  = 'ScreeningCreateFinding')
       BEGIN		
			exec [KYP].[p_ScreeningCF] @InfoID = @InfoID,@Number = @Number
		END	
		 
 --------------------------------------------------------------------------------------------
 
 IF (@FormattedContent IS NULL) /* KYP 3.4 - SCREEN 16 */
		BEGIN
			SET @FormattedContent = @NotesDescription
 END
 
 
if (@JournalEvent is null) 
 begin
 exec @NoteID = [KYP].[p_InsertOISNote]	
 @UserID=@Username,@Name=@NotesTitle,@Type=@Type,@SubType=@SubType,
 @ParentID=0, @DateCreated = @CurrentDate, @Author=@Name,@RelatedEntityType =@RelatedEntityType,
 @Content= @FormattedContent, @UnformattedContent=@NotesDescription , @Number=@Number , 
 @VersionNo =1, @isWorkpaper=0, @isAcknowledged=0 , @WorkflowName=NULL, @isAdverse=0,
 @Deleted=0, @DeletedOn=NULL, @DeletedBy=NULL , @DeletedByUserID=NULL , @UpdatedOn=NULL,
 @UpdatedBy =NULL, @UpdatedByUserID=NULL , @IsImportant=0 , @IsLastVersion=1 , @IsSticky=0 ,
 @IsReferenced=0 , @HasComments=0 , @HasDocuments=0 , @NumberSchemaInfo=@Number , @LastVersion =1,
 @AllowComments =0, @RestoredBy=NULL , @RestoredByUserID=NULL , @CaseID=@CaseID , @AlertID =@AlertID,
 @IncidentID =NULL, @Tags =NULL, @FullDateCreated=NULL , @RelatedEntityID=@RelatedEntityID , @Importance='Low',
 @Score =0, @DMSID =NULL, @DocumentCount=NULL ,@MultipleCaseID=Null,@MultipleTrackingNo=Null,@PInID=Null 
   
   --Updating the ConfirmationNoteID with NoteID  when a record created in OIS_Note through bulk update. 
              
      if @Currenttag is null
      begin
          INSERT INTO [KYP].[OIS_Tag]
           ([Tag])
          VALUES
           (',')
      end
      
           INSERT INTO [KYP].[OIS_JT_NoteTag]
           ([NoteID]
           ,[Tag])
      VALUES
           (@NoteID
           ,',')
           
           
    --Get the notenumber------
    
    exec [KYP].[p_GenerateNoteNumber] @NoteID,
    @Notenumber=@Notenumber output
    
    /******* Updating note number in OIS_Note***********/ 
    update KYP.OIS_Note set Number= @Notenumber where NoteID= @NoteID
    
    /********Creating Journal entry********************/
    
   Select  @JournalDescription='Notes Added-'+' '+@Type+' '+@Notenumber+' '+'was added to'+' '+@RelatedEntityType
    
    INSERT INTO [KYP].[OIS_Journal]
           ([UserID],[ACTIONID],[Date_x],[DESCRIPTION],[EntityTable],[Entity],[EntityID],[CaseID]
           ,[ShortDescription])
     VALUES
           (@Username,1,@CurrentDate,@JournalDescription,'OIS_Note','Note',@NoteID,@CaseID
           ,@JournalDescription)
           
  /**********Segregate the smartlet parameter for noteentity entry************/  
           
    select 
    @NoteEntityType =NoteEntityType,
    @NoteEntityTypeID =NoteEntityTypeID,
    @NoteEntityDepID =NoteEntityDepID,
    @NoteEntityDep= NoteEntityDep,
    @Level =Level,
    @IsLastLevel=IsLastLevel
    from  simple_intlist_to_tbl(@SmartletParameter)       
     
     
     /********Insert into Noteentity*************/
     INSERT INTO [KYP].[NoteEntity]
           ([NoteNumber]
           ,[NoteEntityType]
           ,[NoteEntityDep]
           ,[NoteEntityTypeID]
           ,[NoteEntityDepID]
           ,[Level]
           ,[IsLastLevel])
    
           select @Notenumber
           ,NoteEntityType
           ,NoteEntityDep
           ,NoteEntityTypeID
           ,NoteEntityDepID
           ,Level
           ,IsLastLevel from  simple_intlist_to_tbl(@SmartletParameter)  
           
           
      select @IsExistID= ParentID from  KYP.NoteCounts where ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
      
      Select @IsExistCaseID=ParentID from  KYP.NoteCounts where ParentID = @CaseID
      and ParentTable='ADM_Case'
      
      
     
      select @NoteCount=0
      
      Select @CaseNoteCNT=0
      
      Select @NoteCount=count(RelatedEntityID) from KYP.OIS_Note where RelatedEntityID=@RelatedEntityID 
      and RelatedEntityType=@RelatedEntityType and (Deleted is null or Deleted=0)
      
      Select @CaseNoteCNT=count(CaseID) from KYP.OIS_Note where CaseID=@CaseID and 
      (Deleted is null or Deleted=0)
      
      if @IsExistID is null
      begin
     
      
       INSERT INTO [KYP].[NoteCounts]
           ([ParentID]
           ,[ParentTable]
           ,[Counts])
        VALUES
           (@RelatedEntityID,
           @RelatedEntityType,
           @NoteCount)
      end
      else
      begin
       UPDATE [KYP].[NoteCounts]
        SET 
      [Counts] = @NoteCount
       WHERE ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
       
      end --if @IsExistID
    
    
    if @IsExistCaseID is null
      begin
     
        INSERT INTO [KYP].[NoteCounts]
           ([ParentID]
           ,[ParentTable]
           ,[Counts])
        VALUES
           (@CaseID,
           'ADM_Case',
           @CaseNoteCNT)
      end
      else
      begin
       UPDATE [KYP].[NoteCounts] set
       [Counts] = @CaseNoteCNT
       WHERE ParentID = @CaseID 
      and ParentTable='ADM_Case'
       
      end --if @IsExistID
    
    
    if  (@RelatedEntityType='SDM_Resolution' and  @Type='Pended')
    begin
    
        update KYP.ADM_Case set DateResolved=null where CaseID=@CaseID
        update KYP.ADM_Case set StatusName='Pended' where CaseID=@CaseID
    end
    
    if  (@RelatedEntityType='SDM_Resolution' and  @Type='Completed')
    begin
    
        update KYP.ADM_Case set DateResolved=null where CaseID=@CaseID
        update KYP.ADM_Case set StatusName='Completed' where CaseID=@CaseID
    end
       
      
    
 end    

	DECLARE @RETVAL INT;

	SELECT @RETVAL = IDENT_CURRENT('kyp.ADM_Case_Screening_History');

	IF OBJECT_ID(N'tempdb..#tmpData') IS NOT NULL
	BEGIN
		DROP TABLE #tmpData
	END

	CREATE TABLE #tmpData (
		TempID INT IDENTITY(1, 1) NOT NULL
		,ValueData VARCHAR(20)
		)

	SET IDENTITY_INSERT #tmpData ON

	INSERT INTO #tmpData (TempID)
	VALUES (@RETVAL);

	UPDATE #tmpData
	SET ValueData = 'Updated'
	WHERE TempID = @RETVAL;

	SET IDENTITY_INSERT #tmpData OFF

	DROP TABLE #tmpData
END


GO

