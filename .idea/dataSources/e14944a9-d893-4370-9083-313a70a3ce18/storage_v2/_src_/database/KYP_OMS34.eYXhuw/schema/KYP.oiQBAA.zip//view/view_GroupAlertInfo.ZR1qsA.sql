
CREATE VIEW [KYP].[view_GroupAlertInfo]
AS
select p.ID as ID,priority as Relavence,p.group_AlertNO as GroupAlertNO ,AlertNO as MemberAlertNO,AlertID
 as MemberAlertID, NPI as ProviderNO ,watchedpartyName as ProviderName,
 WatchlistName as watchlist,matchStatusIndicatordesc as AlertSatus,
  createdDate as Date,NoOfMergedAlerts as NoOfMergedAlerts,
  AssignedToUserID as AssignedToUserID, p.Type as AlertType,
   p.MembersCount as MembersCount,p.MemberwithAltCount as MemberwithAltCount,A.IsMerged as IsMerged, 
  a.ProviderType as ProviderType from kyp.MDM_Alert a inner join KYP.MDM_GroupAlert p on p.member_AlertNo= A.AlertNO


GO

