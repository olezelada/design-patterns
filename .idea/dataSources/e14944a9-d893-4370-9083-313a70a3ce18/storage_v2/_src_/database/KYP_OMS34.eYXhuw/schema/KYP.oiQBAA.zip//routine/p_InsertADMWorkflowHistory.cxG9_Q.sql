


CREATE PROCEDURE [KYP].[p_InsertADMWorkflowHistory] 
	
	@CaseID VARCHAR(50),
	@WorkflowStatus VARCHAR(50) = NULL,
	@DateTime DATETIME,
	@UserID VARCHAR(50),
	@UserFullName VARCHAR(100),
	@Notes VARCHAR(MAX),
	@RoleName VARCHAR(50) = NULL,
	@MajorStatus VARCHAR(50),
	@MinorStatus VARCHAR(50),
	@ActivityStatus VARCHAR(50),
	@Description VARCHAR(100),
	@EndDateTime DATETIME,
	@NoOfDays INT,
	@Type VARCHAR(50) = 'HISTORY',
	@SortDateTime DATETIME,
	@Assignee VARCHAR(100)
AS
BEGIN
  BEGIN  TRY
        --Added for KEN-14861
        -- for returned case taking Assignee value from ADm_case
     if @ActivityStatus='Returned'
 BEGIN
      declare @AssignedFromID int;
      set @AssignedFromID = (select AssignedFromID FROM kyp.ADM_Case WHERE CaseID=@CaseID);
      set @Assignee = (select FullName from kyp.ois_user where personid=@AssignedFromID) ;
 END
	
	INSERT INTO [KYP].[ADM_WorkflowHistory]
           ([CaseID]
           ,[WorkflowStatus]
           ,[DateTime]
           ,[UserID]
           ,[UserFullName]
           ,[Notes]
           ,[RoleName]
           ,[MajorStatus]
           ,[MinorStatus]
           ,[ActivityStatus]
           ,[Description]
           ,[EndDateTime]
           ,[NoOfDays]
           ,[Type]
           ,[SortDateTime]
           ,[Assignee])
     VALUES
           (@CaseID
           ,@WorkflowStatus
           ,@DateTime
           ,@UserID
           ,@UserFullName
           ,@Notes
           ,@RoleName
           ,@MajorStatus
           ,@MinorStatus
           ,@ActivityStatus
           ,@Description
           ,@EndDateTime
           ,@NoOfDays
           ,@Type
           ,@SortDateTime
           ,@Assignee)
           
            return IDENT_CURRENT('[KYP].[ADM_WorkflowHistory]')
   END TRY
	BEGIN CATCH	
	  
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'CaseID',@KeyValue=@CaseID

    END CATCH	
END


GO

