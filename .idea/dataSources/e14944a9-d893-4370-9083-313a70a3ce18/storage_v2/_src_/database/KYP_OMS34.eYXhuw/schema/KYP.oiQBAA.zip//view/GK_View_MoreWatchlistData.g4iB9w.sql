


CREATE VIEW [KYP].[GK_View_MoreWatchlistData] as
SELECT     row_number() OVER (ORDER BY GateKeeperID ASC) AS ID, *
FROM         
(
Select P.GateKeeperID,
CASE isnull(P.Name, '')
	WHEN '' then  
		case P.LastName 
			when null then isnull(P.FirstName, '') + ' ' + isnull(P.MiddleName, '')
		else 
			P.LastName + ', '  +isnull(P.FirstName, '') + ' ' + isnull(P.MiddleName, '')
		end
	ELSE P.Name
END AS Name,
P.AkaName,P.Status,N.ID as NPIID,N.NPI ,PR.ID as ProviderID,PR.ProviderNo,AD.City,AD.State,AD.ZipCode,AD.AddressLine1,L.ID as LicenseID,L.License,AD.ID as AddressID,
  PH.ID as PhoneNoID,PH.PhoneNo from KYP.GK_Watchlist P 
 LEFT join KYP.GK_NPIWatchlist N ON N.GateKeeperID = P.GateKeeperID AND ISNULL(N.NPI,'') != '' AND N.isDeleted = 0
 LEFT join KYP.GK_ProviderNoWatchlist PR ON PR.GateKeeperID = P.GateKeeperID AND ISNULL(PR.ProviderNo,'') != '' AND PR.isDeleted = 0
 LEFT join KYP.GK_AddressWatchlist AD ON AD.GateKeeperID = P.GateKeeperID AND ISNULL(AD.City,'') != '' AND ISNULL(AD.State,'') != '' AND ISNULL(AD.ZipCode,'') != '' AND AD.isDeleted = 0
 LEFT join KYP.GK_LicenseWatchlist L  ON L.GateKeeperID = P.GateKeeperID AND ISNULL(L.License,'') != '' AND L.isDeleted=0
 LEFT join KYP.GK_PhoneNoWatchlist PH  ON PH.GateKeeperID = P.GateKeeperID AND ISNULL(PH.PhoneNo,'') != '' AND PH.isDeleted=0 
WHERE p.isDeleted = 0
)Z


GO

