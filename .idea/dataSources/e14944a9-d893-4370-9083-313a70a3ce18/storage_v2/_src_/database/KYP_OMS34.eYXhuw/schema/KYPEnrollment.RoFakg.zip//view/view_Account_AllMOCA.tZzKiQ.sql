


CREATE view [KYPEnrollment].[view_Account_AllMOCA] (MID
	,FilterBy
	,AccountID
	,PartyID
	,NAME
	,Type
	,TIN
	,MaskedTIN
	,NPI
	,SSN
	,MaskedSSN
	,BusinessType
	,ModifiedBy
	,DateModified
	,AssociationDetails
	,Associations
	,EffectiveDate
	,EffectiveEndDate
	,RelatedAccounts
	,Address
	,AddLine1
	,AddLine2
	,ACity
	,County
	,AState
	,AZip
	,LastName
	,FirstName
	,Relationship
	,AccountNumber
	,ApplicationNumber
	,TaxIDProfileID
	,ScreenedOn
	,CurrentRecordFlag
	) as
select Convert(varchar(15),Pa.PartyID)+Convert(varchar(15),Ads.AddressID) MID
	,'Account'
	,NULL AccountID
	,pa.PartyID
	,isnull(pe.LastName, '') + ', ' + isnull(pe.FirstName, '') + ' ' + isnull(pe.MiddleName, '')
	,'Individual'
	,''
	,''
	,Case when per.NPI = '0' Then NULL Else Convert(varchar(20),per.NPI) End as NPI --Added Case statement for CAPAVE-2540 by Sundar on 6Feb2018
	,pe.SSN
	,replace(pe.SSN, SUBSTRING(pe.SSN, 0, 7), 'XXX-XX') AS MaskedSSN
	,''
	,pa.LastActorUserID AS ModifiedBy
	,pa.LastActionDate AS DateModified
	,(
		CASE owr.PercentCheck
			WHEN 1
				THEN 'Ownership Interest ' + owr.PercentValue + '% effective on ' + left(convert(VARCHAR, owr.PercentDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.[Partner]
			WHEN 1
				THEN 'Partner ' + owr.PartnerValue + '% effective on ' + left(convert(VARCHAR, owr.PartnerDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.Managing
			WHEN 1
				THEN 'Managing Employee effective on ' + left(convert(VARCHAR, owr.ManagingDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.Agent
			WHEN 1
				THEN 'Agent; '
			ELSE ''
			END
		) + (
		CASE owr.Director
			WHEN 1
				THEN 'Director/Officer as: ' + owr.DirectorValue + '; '
			ELSE ''
			END
		) + (
		CASE owr.Other
			WHEN 1
				THEN 'Other: ' + owr.OtherValue + '% effective on ' + left(convert(VARCHAR, owr.OtherDate, 101), 10) + '; '
			ELSE ''
			END
		) AS AssociationDetails
	,(
		CASE owr.PercentCheck
			WHEN 1
				THEN 'Ownership Interest; '
			ELSE ''
			END
		) + (
		CASE owr.[Partner]
			WHEN 1
				THEN 'Partner; '
			ELSE ''
			END
		) + (
		CASE owr.Managing
			WHEN 1
				THEN 'Managing Employee; '
			ELSE ''
			END
		) + (
		CASE owr.Agent
			WHEN 1
				THEN 'Agent; '
			ELSE ''
			END
		) + (
		CASE owr.Director
			WHEN 1
				THEN 'Director/Officer; '
			ELSE ''
			END
		) + (
		CASE owr.Other
			WHEN 1
				THEN 'Other; '
			ELSE ''
			END
		) + (
		CASE owr.ClinicalDirector
			WHEN 1
				THEN 'ClinicalDirector; '
			ELSE ''
			END
		) + (
		CASE owr.ExecutiveDirector
			WHEN 1
				THEN 'ExecutiveDirector; '
			ELSE ''
			END
		) AS Associations
	--,convert(VARCHAR, owr.OtherDate, 101) AS EffectiveDate
	,convert(VARCHAR, pa.MOCARelationshipStartDate, 101) AS EffectiveDate --Changed from Owr.OtherDate to pa.MOCARelationshipStartDate on 13Mar2018 for CAPAVE-2270		
	,convert(VARCHAR, pa.MOCARelationshipEndDate, 101) AS EffectiveEndDate
	,(
		SELECT COUNT(DISTINCT pa2.AccountID)
		FROM KYPEnrollment.pAccount_PDM_Person per2
			,KYPEnrollment.pAccount_PDM_Party pa2
		WHERE pa2.PartyID = per2.PartyID
			AND pa2.[Type] = 'Individual Ownership'
			AND pa2.CurrentRecordFlag <> 0
			AND pa2.CurrentRecordFlag IS NOT NULL
			AND per2.LastName = pe.LastName
			AND per2.FirstName = pe.FirstName
			AND (per2.SSN = pe.SSN)
		)
	,ads.AddressLine1 + ', ' + (
		CASE 
			WHEN ads.AddressLine2 IS NULL
				THEN ''
			ELSE ads.AddressLine2 + ' '
			END
		) + (
		CASE 
			WHEN ads.City IS NULL
				THEN ''
			ELSE ads.City + ', '
			END
		) + ads.[State]
	,ISNULL(ads.AddressLine1, '') AS AddLine1
	,ISNULL(ads.AddressLine2, '') AS AddLine2
	,ISNULL(ads.City, '') AS ACity
	,ISNULL(ads.County, '') AS County
	,ISNULL(ads.STATE, '') AS AState
	,ISNULL(ads.ZipPlus4, '') AS AZip
	,pe.LastName
	,pe.FirstName
	,NULL as 'Relationship'	
	,Pa.ScreenedAccountNo AS AccountNumber
	,Pa.ScreenedAppNo AS ApplicationNumber
	,pa.TaxIDProfileID AS TaxIDProfileID
	,Pa.ScreenedOn	
	,Pa.CurrentRecordFlag
from kypenrollment.paccount_pdm_party Pa
JOIN KYPEnrollment.pAccount_PDM_Person Pe ON Pe.PartyID = pa.PartyID
JOIN KYPEnrollment.pAccount_PDM_Provider Per ON Per.PartyID = pa.PartyID
JOIN KYPEnrollment.pAccount_PDM_Owner_Role owr ON pa.PartyID = owr.PartyID
JOIN KYPEnrollment.pAccount_PDM_Location lo ON lo.PartyID = pa.PartyID
JOIN KYPEnrollment.pAccount_PDM_Address ads ON lo.AddressID = ads.AddressID
Join kypenrollment.taxidprofile TP on Pa.TaxidProfileID=TP.TaxidProfileID 
where pa.Type in ('Individual Ownership')
and pa.IsDeleted = 0
Union 
select Convert(varchar(15),Pa.PartyID)+Convert(varchar(15),Ads.AddressID) MID
	,'Account'
	,NULL AccountID
	,pa.PartyID
	,org.LegalName
	,'Organizational'
	,org.EIN
	,replace(org.EIN, SUBSTRING(org.EIN, 0, 7), 'XXX-XX')
	,org.NPI
	,''
	,''
	,''
	,pa.LastActorUserID AS ModifiedBy
	,pa.LastActionDate AS DateModified
	,(
		CASE owr.PercentCheck
			WHEN 1
				THEN 'Ownership Interest ' + owr.PercentValue + '% effective on ' + left(convert(VARCHAR, owr.PercentDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.[Partner]
			WHEN 1
				THEN 'Partner ' + owr.PartnerValue + '% effective on ' + left(convert(VARCHAR, owr.PartnerDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.Managing
			WHEN 1
				THEN 'Managing Employee effective on ' + left(convert(VARCHAR, owr.ManagingDate, 101), 10) + '; '
			ELSE ''
			END
		) + (
		CASE owr.Agent
			WHEN 1
				THEN 'Agent; '
			ELSE ''
			END
		) + (
		CASE owr.Director
			WHEN 1
				THEN 'Director/Officer as: ' + owr.DirectorValue + '; '
			ELSE ''
			END
		) + (
		CASE owr.Other
			WHEN 1
				THEN 'Other: ' + owr.OtherValue + '% effective on ' + left(convert(VARCHAR, owr.OtherDate, 101), 10) + '; '
			ELSE ''
			END
		) AS AssociationDetails
	,(
		CASE owr.PercentCheck
			WHEN 1
				THEN 'Ownership Interest; '
			ELSE ''
			END
		) + (
		CASE owr.[Partner]
			WHEN 1
				THEN 'Partner; '
			ELSE ''
			END
		) + (
		CASE owr.Managing
			WHEN 1
				THEN 'Managing Employee; '
			ELSE ''
			END
		) + (
		CASE owr.Agent
			WHEN 1
				THEN 'Agent; '
			ELSE ''
			END
		) + (
		CASE owr.Director
			WHEN 1
				THEN 'Director/Officer; '
			ELSE ''
			END
		) + (
		CASE owr.Other
			WHEN 1
				THEN 'Other; '
			ELSE ''
			END
		) + (
		CASE owr.ClinicalDirector
			WHEN 1
				THEN 'ClinicalDirector; '
			ELSE ''
			END
		) + (
		CASE owr.ExecutiveDirector
			WHEN 1
				THEN 'ExecutiveDirector; '
			ELSE ''
			END
		)AS Associations
	--,convert(VARCHAR, owr.OtherDate, 101) AS EffectiveDate
	,convert(VARCHAR, pa.MOCARelationshipStartDate, 101) AS EffectiveDate --Changed from Owr.OtherDate to pa.MOCARelationshipStartDate on 13Mar2018 for CAPAVE-2270		
	,convert(VARCHAR, pa.MOCARelationshipEndDate, 101) AS EffectiveEndDate
	,(
		SELECT COUNT(DISTINCT pa2.AccountID)
		FROM KYPEnrollment.pAccount_PDM_Organization org2
			,KYPEnrollment.pAccount_PDM_Party pa2
		WHERE pa2.PartyID = org2.PartyID
			AND pa2.[Type] = 'Entity Ownership'
			AND pa2.CurrentRecordFlag <> 0
			AND pa2.CurrentRecordFlag IS NOT NULL
			AND org2.LegalName = org.LegalName
			AND (
				org2.EIN = org.EIN
				OR org2.EIN IS NULL
				)
		)
	,ads.AddressLine1 + ', ' + (
		CASE 
			WHEN ads.AddressLine2 IS NULL
				THEN ''
			ELSE ads.AddressLine2 + ' '
			END
		) + (
		CASE 
			WHEN ads.City IS NULL
				THEN ''
			ELSE ads.City + ', '
			END
		) + ads.[State]
	,ISNULL(ads.AddressLine1, '') AS AddLine1
	,ISNULL(ads.AddressLine2, '') AS AddLine2
	,ISNULL(ads.City, '') AS ACity
	,ISNULL(ads.County, '') AS County
	,ISNULL(ads.STATE, '') AS AState
	,ISNULL(ads.ZipPlus4, '') AS AZip
	,'' AS LastName
	,'' AS FirstName
	,NULL as 'Relationship'
	,Pa.ScreenedAccountNo AS AccountNumber
	,Pa.ScreenedAppNo AS ApplicationNumber	
	,pa.TaxIDProfileID AS TaxIDProfileID
	,Pa.ScreenedOn
	,Pa.CurrentRecordFlag
from kypenrollment.paccount_pdm_party Pa
JOIN KYPEnrollment.pAccount_PDM_Organization org ON org.PartyID = pa.PartyID
JOIN KYPEnrollment.pAccount_PDM_Owner_Role owr ON pa.PartyID = owr.PartyID
JOIN KYPEnrollment.pAccount_PDM_Location lo ON lo.PartyID = pa.PartyID
JOIN KYPEnrollment.pAccount_PDM_Address ads ON lo.AddressID = ads.AddressID
Join kypenrollment.taxidprofile TP on Pa.TaxidProfileID=TP.TaxidProfileID
where pa.Type in ('Entity ownership')
and pa.IsDeleted = 0


GO

