

CREATE VIEW [KYP].[view_FindingDates]
AS
select NoteID,caseID,Name,ReasonCode,Tags,[Content],Score,UpdAction,ExternalYesNO,a.Author, 
a.DateCreated,DocumentCount,RelatedEntityType,RelatedEntityID,Deleted,DiffScore,UpdatedBy,AutoFlag,DMSID,RiskScoreColor,PartyRole,p.Findingdates,p.SortFlag
from kyp.OIS_Note a inner join 
KYP.Eventdates p on p.CFId = a.NoteID and isnull(a.Deleted, 0) = 0 
WHERE a.Name NOT IN ('TempNoteForDocFW','TEMP') 
and Tags NOT IN('Field Verification','Document Verification','Others')


GO

