/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMEmployee]
(@PartyID int
 ,@ProviderID int= NULL
 ,@Designation varchar(25) =NULL
 ,@FromDate smalldatetime = NULL
 ,@ThroughDate smalldatetime=NULL
 ,@DateReported datetime=NULL
 ,@InformationSource varchar(50)=NULL
 ,@MedicareIDNo varchar(25)=NULL
 ,@PercentageControl int=NULL
 ,@ProvideContractService varchar(5)=NULL
 ,@TypeOfService varchar(25)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0

)
as begin 

INSERT INTO [KYP].[PDM_Employee]
           ([PartyID]
           ,[ProviderID]
           ,[Designation]
           ,[FromDate]
           ,[ThroughDate]
           ,[DateReported]
           ,[InformationSource]
           ,[Medicare ID No]
           ,[PercentageControl]
           ,[Provide Contract Service]
           ,[Type Of Service]
           ,[Remarks]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@ProviderID
           ,@Designation
           ,@FromDate
           ,@ThroughDate
           ,@DateReported
           ,@InformationSource
           ,@MedicareIDNo
           ,@PercentageControl
           ,@ProvideContractService
           ,@TypeOfService
           ,@Remarks
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[PDM_Employee]')

end


GO

