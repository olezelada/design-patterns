

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create ProfileMaster for new profile and Profile Details for new Account.   
-- PARAMETERS: 
-- @party_app_id : partyID Application that will be Account. 
-- @account_Id : AccountID that will be create. 
-- @account_party_id : partyID to Account that will be create.
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_BizProfile_Details]
@party_app_id INT,
@account_Id INT,
@account_party_id INT,
@last_action_user_id VARCHAR(100),
@row_trigger_source VARCHAR(100) = NULL
AS
BEGIN
SET NOCOUNT ON 
DECLARE @profile_id INT, @enrollment_id VARCHAR(40),@address_line1 VARCHAR(250),@address_line2 VARCHAR(50),
@city VARCHAR(25),@state VARCHAR(40),@zipPlus4 VARCHAR(50),@date_created DATE, @message varchar(100),@PayAddress_line1 varchar(250),
@PayAddress_line2 varchar(50), @payCity Varchar(25), @PayState Varchar(40), @PayZipPlus4 varchar(50);
SET @date_created =  GETDATE();

SELECT @profile_id = [profile_id] 
FROM [KYPPORTAL].[PortalKYP].[pADM_Application] 
WHERE PartyID=@party_app_id;

SELECT @enrollment_id = [EnrollmentProfileId] 
FROM [KYPPORTAL].[PortalKYP].[pProfile] 
WHERE profile_id = @profile_id;

--IF (SELECT COUNT(ID) FROM [KYPEnrollment].[pAccount_BizProfile_Master] WHERE ProfileID=@enrollment_id)=0
IF NOT EXISTS(SELECT ID FROM [KYPEnrollment].[pAccount_BizProfile_Master] WHERE ProfileID=@enrollment_id) 
BEGIN
	 INSERT INTO [KYPEnrollment].[pAccount_BizProfile_Master]
			   ([ProfileID]
			   ,[ProfileName]
			   --,[TypeOfProfile] where
			   --,[SSN] where
			   --,[EIN] where
			   --,[ProfileCreatedDate] where
			   --,[EffectiveBeginDate] where
			   --,[EffectiveEndDate] where
			   ,[LastAction] 
			   ,[LastActionDate]
			   ,[LastActionUserID]
			   ,[CurrentRecordFlag]
			   ,[LastActionApprovedBy]
			   ,[IsTempProfile]
			   ,[Row_Trigger_Source])
	 SELECT [EnrollmentProfileId],
			[profile_name],  
			'C',
			@date_created,
			@last_action_user_id,
			1,
			@last_action_user_id,
			1,
			@row_trigger_source
	 FROM [KYPPORTAL].[PortalKYP].[pProfile] WHERE profile_id= @profile_id          
END

/* replace KEN-15722 performance
SELECT @address_line1 = address.AddressLine1,@address_line2 = address.AddressLine2,
@city = address.City,@state = address.State,@zipPlus4 = address.ZipPlus4
FROM [KYPEnrollment].[pAccount_PDM_Address] address, [KYPEnrollment].[pAccount_PDM_Location] location
WHERE location.AddressID= address.AddressID AND location.PartyID=@account_party_id 
AND location.Type='Servicing'

SELECT @PayAddress_line1 = address.AddressLine1,@PayAddress_line2 = address.AddressLine2,
@PayCity = address.City,@PayState = address.State,@PayZipPlus4 = address.ZipPlus4
FROM [KYPEnrollment].[pAccount_PDM_Address] address, [KYPEnrollment].[pAccount_PDM_Location] location
WHERE location.AddressID= address.AddressID AND location.PartyID=@account_party_id 
AND location.Type='Pay-to'
*/
SELECT 
@address_line1 = max(case when location.type='Servicing' then address.AddressLine1 end),
@address_line2 =max(case when location.Type='Servicing' then  address.AddressLine2 end),
@city = max(case when location.Type='Servicing' then address.City end),
@state = max(case when location.Type='Servicing' then address.State end ),
@zipPlus4 = MAX( case when location.Type='Servicing' then address.ZipPlus4 end),
@PayAddress_line1 = max(case when location.Type='Pay-to' then address.AddressLine1 end),
 @PayAddress_line2 = max(case when location.Type='Pay-to' then address.AddressLine2 end),
@PayCity = max(case when location.Type='Pay-to' then address.City end),
@PayState = max(case when location.Type='Pay-to' then address.State end),
@PayZipPlus4 = max(case when location.Type='Pay-to' then address.ZipPlus4 end)

FROM [KYPEnrollment].[pAccount_PDM_Address] address, [KYPEnrollment].[pAccount_PDM_Location] location
WHERE location.AddressID= address.AddressID AND location.PartyID=@account_party_id
AND (location.Type='Servicing' or location.Type='Pay-to')
group by location.partyid

INSERT INTO [KYPEnrollment].[pAccount_BizProfile_Details]
           ([ProfileID]
           ,[AccountID]
		   ,[AccountNumber]
           ,[AccountEnrollmentStatus]
           ,[AccountProviderType]
           ,[AccountNPI]
           ,[AccountSSN]
           ,[AccountAddressType]
           ,[AccountAddressLine1]
           ,[AccountAddressLine2]
           ,[AccountAdrCity]
           ,[AccountAdrState]
           ,[AccountAdrZip9]
           --,[AccountLicenseType]--where
           --,[AccountLicenseNo]--where
           ,[EffectiveBeginDate] --where
           --,[EffectiveEndDate]--where
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[PayAccountAddressLine1]
           ,[PayAccountAddressLine2]
           ,[PayAccountAdrCity]
           ,[PayAccountAdrState]
           ,[payAccountAdrZip9]
           ,[UserRemark])
SELECT @enrollment_id,
       @account_Id,
	   [AccountNumber],
       [StatusAcc],
       [ProviderTypeCode],
       [NPI],
       [SSN],
       'Service Address',--need change
       @address_line1,
       @address_line2,
       @city,
       @state,
       @zipPlus4,
       @date_created,
       'C',
       @date_created,
       @last_action_user_id,
       @last_action_user_id,
       0,
       @PayAddress_line1,
       @PayAddress_line2,
       @PayCity,
       @PayState,
       @PayZipPlus4,
       0
             
FROM [KYPEnrollment].[pADM_Account] 
WHERE AccountId=@account_Id

SELECT @message = 'New BizProfile Details'
RAISERROR (@message,0,1) WITH NOWAIT;

END


GO

