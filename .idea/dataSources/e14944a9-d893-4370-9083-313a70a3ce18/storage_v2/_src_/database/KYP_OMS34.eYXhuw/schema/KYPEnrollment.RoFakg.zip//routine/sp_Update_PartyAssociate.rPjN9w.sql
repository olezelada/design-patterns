
CREATE PROCEDURE [KYPEnrollment].[sp_Update_PartyAssociate]
@UniqueID int
 
AS

BEGIN
declare
 @profileid  varchar(40),
 @TaxID 		    varchar(10), 
 @MocaType  		varchar(50), 
 @SSN_TIN  			varchar(11),
 @Name  			varchar(100),
 @currentrecordflag bit 	
 
 SELECT @ProfileID = ProfileID,@TaxID = TaxID,@MocaType=MOCAType,@SSN_TIN=SSNorTIN,@Name=case when isnull(legalname,'')<>'' then legalname else isnull(LastName,'')+','+isnull(FirstName,'') end 
 ,@currentrecordflag=CurrentRecordFlag  
  FROM KYPEnrollment.UniqueMOCAsProfileTINwise  WHERE UniqueMOCAsProfileTINwiseID =@uniqueid

--
set @Name=RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(isnull(@name,''),' ',''),'  ',''),',',''),'-',''),'_','')))
set @ProfileId=REPLACE(@ProfileId,'-','')
set @TaxID=REPLACE(@TaxID,'-','')
SET @SSN_TIN =REPLACE(isnull(@SSN_TIN,''),'-','')


--#Partytemp stored all parties that have taxid,profileid,ssn_tin,name
select * 
into #PartyTemp
from
(
select replace(prof.ProfileID,'-','') as profileid, replace(isnull(acc.EIN,''),'-','') as EIN,parti.AccountID,acc.AccountNumber,acc.partyid as partyid_acc,parti.PartyID,ParentPartyID,type,isnull(person.LastName,'')+','+isnull(person.FirstName,'')  as name ,replace(isnull(person.ssn,''),'-','') as SSN_TIN 
from 
kypenrollment.pADM_Account acc inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner join kypenrollment.pAccount_BizProfile_Details prof on acc.AccountID=prof.AccountID 
inner join KYPEnrollment.pAccount_BizProfile_Master BPM  ON prof.ProfileId	= BPM.ProfileId
inner join kypenrollment.pAccount_PDM_Party parti on acc.PartyID=parti.parentpartyid
left join kypenrollment.pAccount_PDM_Person person on parti.partyid=person.partyid

where replace(isnull(acc.EIN,''),'-','')=@taxid and
 replace(prof.ProfileID,'-','')=@ProfileId and 
 (OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
 (
 (@SSN_TIN<>'' AND  replace(isnull(person.ssn,''),'-','')=@SSN_TIN)   OR
 (@SSN_TIN='' AND  RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(isnull(person.LastName,'')+','+isnull(person.FirstName,'') ,' ',''),'  ',''),',',''),'-',''),'_','')))=@Name )
 )
 --and  type in ('Individual Ownership','SubcontractorIndividual','TransactionIndividual')
 and  type =@MocaType
 and acc.PackageName	in ('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP')
 AND ACC.IsDeleted	= 0 AND
 bpm.IsTempProfile	= 0 AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)
and IsPastOwner = 0
and acc.NPI  NOT LIKE '%[a-z]%'
and parti.currentrecordflag=@currentrecordflag
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')


union all
select replace(prof.profileid,'-','') as profileid,replace(acc.EIN,'-','') AS EIN,parti.AccountID,acc.accountnumber,acc.partyid as partyid_acc,parti.PartyID,ParentPartyID,type,isnull(orga.legalname,''),replace(isnull(orga.ein,''),'-','') 
from  
kypenrollment.pADM_Account acc inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner join kypenrollment.pAccount_BizProfile_Details prof on acc.AccountID=prof.AccountID 
inner join KYPEnrollment.pAccount_BizProfile_Master BPM  ON prof.ProfileId	= BPM.ProfileId
inner join kypenrollment.pAccount_PDM_Party parti on acc.PartyID=parti.parentpartyid
left join kypenrollment.pAccount_PDM_Organization orga on parti.PartyID=orga.PartyID 

where replace(isnull(acc.EIN,''),'-','')=@taxid and 
 replace(prof.ProfileID,'-','')=@ProfileId and
 (OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
 (
 (@SSN_TIN<>'' AND replace(isnull(orga.ein,''),'-','')=@SSN_TIN) OR
 (@SSN_TIN='' AND  RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(isnull(orga.legalname,''),' ',''),'  ',''),',',''),'-',''),'_','')))=@name ) 
 )
 --AND  type in ('Entity Ownership','SubcontractorEntity','TransactionEntity')  
 and  type =@MocaType
 and  acc.PackageName	in ('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP')
  AND ACC.IsDeleted	= 0 AND
 BPM.IsTempProfile	= 0 AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)
and IsPastOwner = 0
and acc.NPI  NOT LIKE '%[a-z]%'
and parti.currentrecordflag=@currentrecordflag
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')

 
 ) aux order by accountid

--insert to taxid_associate
insert into kypenrollment.pAccount_TaxID_Associate(AccountID,PartyID,EntityID,TaxID,CurrentRecordFlag ) 
select AccountID,partyid_acc,AccountNumber ,ein,1 from #PartyTemp except
select ass.AccountID,PartyID,EntityID,taxid,1 from kypenrollment.pAccount_TaxID_Associate ass inner join kypenrollment.paccount_bizprofile_details prof 
on ass.AccountID=prof.AccountID 
where TaxID=@taxid and replace(prof.ProfileID,'-','')=@profileid 
declare @mainparty int 
select top 1 @mainparty=MainPartyID from kypenrollment.pAccount_Party_Associate where PartyID in (select PartyID from #partytemp)
if @mainparty is null
 select top 1 @mainparty=partyid from #PartyTemp 
if @mainparty is not null
begin 
--insert to party_associate
insert into kypenrollment.pAccount_Party_Associate (MainPartyID, PartyID,AccountID,Type )
select @mainparty,partyid,accountid,TYPE from #partytemp except
select mainpartyid,partyid, accountid,type from kypenrollment.pAccount_Party_Associate 
--update status of currentrecordflag in party_associate
update asoc set CurrentRecordFlag =@currentrecordflag 
from  kypenrollment.pAccount_Party_Associate asoc inner join #PartyTemp temp on asoc.PartyID=temp.partyid 
end

END

drop table #PartyTemp


GO

