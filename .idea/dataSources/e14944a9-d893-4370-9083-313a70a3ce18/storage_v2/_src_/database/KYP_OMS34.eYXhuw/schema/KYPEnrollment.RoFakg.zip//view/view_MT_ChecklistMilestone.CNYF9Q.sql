




CREATE VIEW [KYPEnrollment].[view_MT_ChecklistMilestone]
AS
SELECT row_number() OVER (ORDER BY ChecklistID ASC) AS ViewID,* 
 

FROM         
(		
		
		Select task.TaskName
			  ,task.SortOrder
			  ,task.AutoCheck
			  ,task.IsDeleted
              ,task.SortOrder2
			  ,t.StateName TaskState
			  ,ch.ChecklistID
			  ,ch.Entity
			  ,ch.EntityID
			  ,CASE 
				WHEN task.TaskName IN ('In Portal','Submitted') 
				THEN 
					NULL 
				ELSE
					ch.DateCompletion 
				END
				
				AS DateCompletion 
			  ,ch.CheckValue
			  ,ch.YesNoNAValue
			  ,ch.AdvancedValue
              ,ch.EnablingDate
  			  ,(case when ch.IsCompleted=1 then 'true' else (case when ch.IsCompleted=0 then 'false' else 'N/A' end) end) as IsCompleted
  			  , CONVERT(VARCHAR,(SELECT COUNT(cc.IsCompleted) from KYPEnrollment.MT_Checklist cc WHERE ch.EntityID=cc.EntityID AND cc.IsCompleted='true' AND cc.IsVisible = 1)) + ' out of ' + CONVERT(VARCHAR,(SELECT COUNT(cc.IsCompleted) from KYPEnrollment.MT_Checklist cc WHERE ch.EntityID=cc.EntityID AND cc.IsVisible = 1)) + ' completed' As CompletedTasks
			  ,ch.UserID
			  ,t.TypeDropdown
			  ,t.TemplateName
		from  KYPEnrollment.MT_Task task,
			  KYPEnrollment.MT_Checklist ch,
			  KYPEnrollment.MT_Template t 	
		where task.TaskID=ch.TaskID
		and  task.TemplateID=t.TemplateID 
		and (task.IsDeleted is null or task.IsDeleted='false')
		and (t.IsDeleted is null or t.IsDeleted='false')
        and (ch.IsVisible = 1) 
		)G


GO

