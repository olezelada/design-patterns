CREATE PROCEDURE [dbo].[DeleteDupProv]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	Declare 
	@ProvNumber varchar(20),
	@PartyID int,
	@MinProvID int
	
	

	DECLARE delcursor CURSOR FOR   
    select  A.ProvNumber ,A.partyID 
         from KYP.PDM_Provider A inner join KYP.PDM_Party B
         on A.PartyID =B.PartyID and B.currentmodule=2 and B.IsDeleted <> 1
          group by A.PartyID,A.ProvNumber  
         having COUNT(A.ProvNumber) > 1 				-- This is done to get Parent Alert first in Cursor loop
	
	OPEN delcursor
	FETCH NEXT FROM delcursor INTO @ProvNumber,@PartyID
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		    SELECT @MinProvID=MIN(ProvID)  FROM KYP.PDM_provider 
		      GROUP BY provnumber, partyid having ProvNumber =@ProvNumber and PartyID =@PartyID 
		      
		 
		    
		 update KYP.PDM_Owner set ProviderID = @MinProvID where 
		 --PartyID =@PartyID 		    and 
		 ProviderID in (select Provid from KYP.PDM_Provider where ProvNumber 
		    = @ProvNumber and PartyID =@PartyID) 
		    --and OwnerID in
		    --(select OwnerID from kyp.PDM_Owner where PartyID <> @PartyID 
		    --and ProviderID <>@MinProvID) 
		    
			DELETE KYP.PDM_Owner
			FROM KYP.PDM_Owner
			LEFT OUTER JOIN (
			   SELECT Min(OwnerID) as RowId, providerID, partyid 
			   FROM KYP.PDM_Owner
			   GROUP BY providerID, partyid
			) as KeepRows ON
			   KYP.PDM_Owner.OwnerID = KeepRows.RowId
			WHERE
			   KeepRows.RowId IS NULL 
		     
		     --print @MinProvID
		    
		    update KYP.PDM_Employee set ProviderID = @MinProvID where 
		    --PartyID =@PartyID 
		   -- and 
		    ProviderID in (select Provid from KYP.PDM_Provider where ProvNumber 
		    = @ProvNumber and PartyID =@PartyID)
		    -- and EmployeeID  in
		    --(select EmployeeID  from kyp.PDM_Employee where PartyID <> @PartyID 
		    --and ProviderID <>@MinProvID) 
		    
		        
			DELETE KYP.PDM_Employee
			FROM KYP.PDM_Employee
			LEFT OUTER JOIN (
			   SELECT Min(EmployeeID) as RowId, providerID, partyid 
			   FROM KYP.PDM_Employee 
			   GROUP BY providerID, partyid
			) as KeepRows ON
			   KYP.PDM_Employee.EmployeeID  = KeepRows.RowId
			WHERE
			   KeepRows.RowId IS NULL 
		    
		    update KYP.MDM_SearchProviders set ProviderID = @MinProvID where ProviderID in
		    (select Provid from KYP.PDM_Provider where ProvNumber 
		    = @ProvNumber and PartyID =@PartyID)
		    
		     update KYP.MDM_ImpProviders  set ProviderID = @MinProvID where ProviderID in
		    (select Provid from KYP.PDM_Provider where ProvNumber 
		    = @ProvNumber and PartyID =@PartyID)
		    
		    update KYP.PDM_Location  set ProviderID = @MinProvID where ProviderID in
		    (select Provid from KYP.PDM_Provider where ProvNumber 
		    = @ProvNumber and PartyID =@PartyID)
		    
		    
			DELETE KYP.PDM_provider 
			FROM KYP.PDM_provider
			LEFT OUTER JOIN (
			   SELECT MIN(ProvID) as RowId, A.ProvNumber , A.PartyID  
			   FROM KYP.PDM_provider A inner join KYP.PDM_Party B
               on A.PartyID =B.PartyID and B.currentmodule=2 and B.IsDeleted <> 1
			   GROUP BY A.provnumber, A.partyid having ProvNumber =@ProvNumber
			) as KeepRows ON
			   KYP.PDM_provider.ProvID = KeepRows.RowId
			WHERE
			   KeepRows.RowId IS NULL and kyp.PDM_Provider.provNumber=@ProvNumber
			   --and ProvID not in
			   --(select providerid from KYP.MDM_SearchProviders where Impacted =1)
		    
		
			
			FETCH NEXT FROM delcursor INTO @ProvNumber, @PartyID	
	END
	CLOSE delcursor 
	DEALLOCATE delcursor

   
END


GO

