















-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_InternalApprovedUseData] 

@LastActionComments varchar(20), @AccountInternalUseID int,@ProviderTypeCode varchar(20)
	
AS
BEGIN

Declare
 @CodeIdentification varchar(10),
 @CodeDescription varchar(250),
 @CodeType varchar(10),
 @CreatedBy varchar(100),
 @CodeDateEffDate smalldatetime,
 @CodeDateExpDate smalldatetime,
 @AppCount int,
 @partyid int,
 @accManyUserID int,
 @Typeinertnal int,
 @ApplnType varchar(100)
 
	
	if(@ProviderTypeCode='002')
	begin
	 set @Typeinertnal=100
	end
	else
	begin
	set @Typeinertnal=24
	end
	select @partyid=PartyID from  
	KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@LastActionComments

	select @ApplnType=ApplnType from
	KYP.ADM_Case where Number=@LastActionComments

	
	select @AppCount=COUNT(ActivityID) from 
	KYPPORTAL.PortalKYP.pPDM_BusinessActivity   where PartyID = @partyid and (Approved=0 or Approved is null)and TargetPath not like 'pAccount_PDM_BusinessActivity|ActivityID|%'


	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.ActivityID FROM(
		SELECT row_number() OVER(order by ActivityID) As RowNumber,ActivityID
		FROM KYPPORTAL.PortalKYP.pPDM_BusinessActivity  WHERE PartyID = @partyid and(Approved=0 or Approved is null)and TargetPath not like 'pAccount_PDM_BusinessActivity|ActivityID|%')X WHERE X.RowNumber = @AppCount
	
		SELECT @CodeIdentification =B.Code,@CodeDescription =B.Descriptor,@CodeType ='Category',
		@CodeDateEffDate =A.EffectiveDate,@CodeDateExpDate =null,@CreatedBy ='System'
		FROM KYPPORTAL.PortalKYP.pPDM_BusinessActivity A
		inner join KYPEnrollment.LK_AccInternalUseDataCode B on A.Activity=B.Descriptor and TYPE=@Typeinertnal
		WHERE A.ActivityID =@accManyUserID 
		Print '@CodeIdentification'+convert(varchar(100),@CodeIdentification)
		Print '@@CodeDescription'+convert(varchar(100),@CodeDescription)		
		Print '@@AccountInternalUseID'+convert(varchar(100),@AccountInternalUseID)		
		if(@ApplnType='New' or @ApplnType='New Group')
		begin

		delete from KYPEnrollment.EDM_ApplicationInternalMany where CodeIdentification=@CodeIdentification and CodeDescription=@CodeDescription and 
		AccountInternalUseID=@AccountInternalUseID
		end
		else
		begin
		
		delete from KYPEnrollment.EDM_SupplementalInteranlMany where CodeIdentification=@CodeIdentification and CodeDescription=@CodeDescription and 
		AccountInternalUseID=@AccountInternalUseID
		end
		
		SET @AppCount = @AppCount - 1
	
	END
END


GO

