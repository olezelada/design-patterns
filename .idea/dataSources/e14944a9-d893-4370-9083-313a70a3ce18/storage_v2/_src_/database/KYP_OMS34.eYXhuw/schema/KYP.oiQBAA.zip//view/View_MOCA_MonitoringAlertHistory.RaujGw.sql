
CREATE VIEW [KYP].[View_MOCA_MonitoringAlertHistory]
AS
  Select T1.AlertId,T3.ResolutionType,T1.WatchedPartyID,T1.WatchlistName,T1.MedicaidID,T1.CreatedDate,T1.SSN,T1.TAXID, T1.WatchedPartyType
From kyp.mdm_alert T1
Left Join (select AlertID,Max(ResolutionID) ResolutionID from KYP.MDM_AlertResolution
  group by alertid) T2 ON T1.AlertID = T2.AlertID
Left Join KYP.MDM_AlertResolution T3 ON T2.ResolutionID = T3.REsolutionID


GO

