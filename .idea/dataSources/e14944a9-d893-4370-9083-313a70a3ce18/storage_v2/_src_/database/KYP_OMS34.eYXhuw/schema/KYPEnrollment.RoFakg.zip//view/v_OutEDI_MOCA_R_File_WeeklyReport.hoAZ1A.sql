
CREATE VIEW [KYPEnrollment].[v_OutEDI_MOCA_R_File_WeeklyReport]
AS
SELECT  row_number() OVER (ORDER BY PartyID ASC) AS ID, *
FROM         
(
Select DISTINCT x.PartyID, x.ProviderNo,x.OwnerNo,x.ServiceLocationNo,x.ProviderTypeCode, x.SSN,x.EIN
,x.MOCARelationshipStartDate,x.MOCARelationshipEndDate
,x.LastActionDate,x.Type

from( 
select PRT.PartyID
,PRT.Type,PRT.LastActionDate,PRT.MOCARelationshipStartDate,PRT.MOCARelationshipEndDate ,PRT.LastMOCARelationshipUpdateBy 
,A.NPI as ProviderNo,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode
,Case when(PRT.Type='Individual Ownership') then (select SSN from KYPEnrollment.pAccount_PDM_Person where PartyID=PRT.PartyID)ELSE NULL END AS SSN
,Case when(PRT.Type='Entity Ownership') then (select TIN from [KYPEnrollment].[pAccount_PDM_Organization] where PartyID=PRT.PartyID)ELSE NULL END AS EIN

from KYPEnrollment.pAccount_PDM_Party PRT
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=PRT.AccountID 
 where prt.IsProvider=0
--PRT.Type in ('Entity Ownership','Individual Ownership') 
--AND PRT.LastMOCARelationshipUpdateBy in('P','E','T' )
--AND CONVERT(VARCHAR, PRT.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-7, 101) and  CONVERT(VARCHAR, PRT.LastActionDate , 101) <=  CONVERT(VARCHAR, GETDATE(), 101)  
--AND 
--AND CONVERT(VARCHAR, PRT.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-1, 101) 
) x 
) z
------------------------------------------- Close of MOCA Reference file ------------------------------------------------------------------------------


GO

