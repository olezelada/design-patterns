/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMAddress]
(@AddressLine1 varchar(250)=NULL
 ,@AddressLine2 varchar(25)= NULL
 ,@County varchar(25) =NULL
 ,@City varchar(25) = NULL
 ,@Zip varchar(5)=NULL
 ,@ZipPlus4 varchar(4)=NULL
 ,@State varchar(25)=NULL
 ,@Country varchar(25)=NULL
 ,@Latitude varchar(8)=NULL
 ,@Longitude varchar(8)=NULL
 ,@USPSFlag bit=0
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int =NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@InActive bit=1
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[PDM_Address]
           ([AddressLine1]
           ,[AddressLine2]
           ,[County]
           ,[City]
           ,[Zip]
           ,[ZipPlus4]
           ,[State]
           ,[Country]
           ,[Latitude]
           ,[Longitude]
           ,[USPSFlag]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[InActive]
           ,[IsDeleted])
     VALUES
           (@AddressLine1
           ,@AddressLine2
           ,@County
           ,@City
           ,@Zip
           ,@ZipPlus4
           ,@State
           ,@Country
           ,@Latitude
           ,@Longitude
           ,@USPSFlag
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@InActive
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[PDM_Address]')

end


GO

