
CREATE VIEW [KYP].[v_PartyTotalRedFlags] AS
SELECT SUM(X.RedFlagCount) As RedFlag,X.ApplicationID,X.PartyID FROM(
SELECT DISTINCT P.ApplicationID,P.PartyID,F.RedFlagCount
 FROM KYP.SDM_RedFlag F INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = F.ScreeningID AND P.IsActive = 1
 )X GROUP BY X.ApplicationID,X.PartyID


GO

