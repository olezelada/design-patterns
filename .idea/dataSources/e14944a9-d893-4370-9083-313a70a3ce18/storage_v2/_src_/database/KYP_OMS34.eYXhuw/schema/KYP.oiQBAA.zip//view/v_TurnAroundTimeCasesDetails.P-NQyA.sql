
CREATE VIEW [KYP].[v_TurnAroundTimeCasesDetails]
AS
SELECT 1 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 6) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 6) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 2 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 1) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 1) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 3 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 8) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 8) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 4 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 15) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 15) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 5 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 22) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 22) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 6 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 29) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 29) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 7 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 36) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 36) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0

UNION ALL

SELECT 8 AS 'Week'
	,CaseID
	,Risk
	,Number
	,PAN
	,ProviderName
	,TypeDescription
	,DateReceived
	,DateResolved
	,FullName
	,DateAssigned
	,WFMinorStep AS StatusName
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49) AS 'WeekStartDate'
	,DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 43) AS 'WeekEndDate'
	,DATEDIFF(DAY, DateReceived, DateResolved) AS [TAT_Days]
FROM KYP.ADM_Case
INNER JOIN KYP.OIS_User ON KYP.ADM_Case.cUrrentlyAssignedToID = KYP.OIS_User.PersonID
WHERE (
		DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49)
			AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 43) + CAST('23:59:59' AS DATETIME)
		AND StatusCodeNumber <> 12
		)
	AND IsPPURequired = 0


GO

