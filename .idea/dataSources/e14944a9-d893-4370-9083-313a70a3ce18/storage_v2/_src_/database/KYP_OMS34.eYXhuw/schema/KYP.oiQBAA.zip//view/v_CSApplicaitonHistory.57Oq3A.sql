


CREATE VIEW [KYP].[v_CSApplicaitonHistory] AS
SELECT	CONVERT(VARCHAR,C.CaseID ) As CaseID,
		CONVERT(VARCHAR,C.AccountID) As AccountID,
		CONVERT(VARCHAR,C.AccountNo) As AccountNo,
		CONVERT(VARCHAR,C.DateReceived ,101) As DateReceived,
	C.ApplnTypeAlias As ApplicationType,
	C.ResolutionStatus As LastResolution,
	CASE WHEN C.ResolutionStatus = 'Referred-Licensing and Certification (L&C)' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Enrolled/Provisional Status Granted' THEN 'rgb(29, 204, 6);'
	 WHEN C.ResolutionStatus = 'NPI Change' THEN 'rgb(29, 204, 6);'
	 WHEN C.ResolutionStatus = 'Denied' THEN 'rgb(255, 0, 0);'
	 WHEN C.ResolutionStatus = 'Referred-Office of Legal Services (OLS)' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Deficiency Notice Sent' THEN 'rgb(255, 174, 0);'
	 WHEN C.ResolutionStatus = 'Referred-Audits and Investigations (A&I)' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Referred-Benefits Division' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Referred-Lab Field Services' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Referred-Other' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Referred-Pharmacy' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Review Cancelled - Close as duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN C.ResolutionStatus = 'Closed as Duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN C.ResolutionStatus = 'Approve' THEN 'rgb(29, 204, 6);'
	 WHEN C.ResolutionStatus = 'Approved' THEN 'rgb(29, 204, 6);'
	 WHEN C.ResolutionStatus = 'Close without account update' THEN 'rgb(255, 174, 0);'
	 WHEN C.ResolutionStatus = 'Dis-Enrolled by Provider' THEN 'rgb(128, 128, 128);'
	 WHEN C.ResolutionStatus = 'Review Cancelled - Application Withdrawn' THEN 'rgb(0, 128, 128);'	 
	 WHEN C.ResolutionStatus = 'Ignored' THEN 'rgb(255, 174, 0);'
	 WHEN C.ResolutionStatus = 'Referred' THEN 'rgb(0, 0, 255);'
	 WHEN C.ResolutionStatus = 'Close with no action' THEN 'rgb(255, 174, 0);'	 
	 ELSE '#FFFFFF;' END As RSBGColor,		
		ISNULL(CONVERT(VARCHAR,C.CompositeRisk),'NA') As RiskScore,
		CASE WHEN C.ActivityStatus = 'Completed' THEN 'C'
		ELSE 'O' END As Status
FROM KYPEnrollment.AccountSearch S 
INNER JOIN KYP.ADM_Case C ON C.AccountNo = S.AccountNumber


GO

