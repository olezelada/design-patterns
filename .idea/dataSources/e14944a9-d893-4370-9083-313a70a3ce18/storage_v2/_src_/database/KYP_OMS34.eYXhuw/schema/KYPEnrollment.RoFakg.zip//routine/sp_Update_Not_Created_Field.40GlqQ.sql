
/* ==========================================================
-- Author:		<D-Harbor>
-- PROCEDURE: Update not created field
-- PARAMETERS:
  @account_id         : AccountID from Account
	@account_party_id   : PartyID from Account
	@app_package_name   : PackagesName from Application
	@app_party_id       : PartyID from Application
  @section_code       : SectionCode from FieldValuesTracking
  @last_action_user_id: this is the user Enrollment

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Not_Created_Field]
	@account_id INT,
	@account_party_id INT,
	@app_package_name VARCHAR(15),
	@app_party_id INT,
  @section_code VARCHAR (30),
  @last_action_user_id VARCHAR(100)
AS
  BEGIN
    IF (@app_package_name IN ('F_PI_OE', 'F_PI_SP'))
      BEGIN
        DECLARE @TypeServiceAddress VARCHAR(20) = 'ServAddrImagingLic'
        IF(@section_code ='2.2.1')
        BEGIN
          IF NOT EXISTS (SELECT NumberID FROM KYPEnrollment.pAccount_PDM_Number WHERE PartyID = @account_party_id AND Type=@TypeServiceAddress AND IsDeleted=0)
          BEGIN
            EXEC [KYPEnrollment].[Copy_Twin_Number] @account_party_id,
                                                    @app_party_id,
                                                    @last_action_user_id,
                                                    @TypeServiceAddress;
          END

          IF NOT EXISTS (SELECT QuestionID FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie WHERE PartyID = @account_party_id AND Name=@TypeServiceAddress AND IsDeleted=0)
          BEGIN
            EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByName] @app_party_id,
                                                                       @account_party_id,
                                                                       @TypeServiceAddress;
          END
        END
      END
  END


GO

