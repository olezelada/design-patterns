CREATE PROCEDURE [KYPEnrollment].[sp_CreateMixedGroupAffiliationMOCATranspositionForMMIS]
(
	@Scenario INT
)
AS 
BEGIN

	DECLARE @loopID					INT,
			@MaxID					INT,
			@MixedGroupClubbingID	VARCHAR(18),
			@MGPartyID				INT,
			@MGAccountID 			INT,
			@MGAccountNumber 		VARCHAR(20),
			@MGStatusAcc 			VARCHAR(50),
			@MGBillingStatus		VARCHAR(50),
			@MGStatusBeginDate 		SMALLDATETIME,
			@MGApplicationDate 		SMALLDATETIME,
			@MGActivationDate 		SMALLDATETIME, 
			@MGDeactivationDate 	SMALLDATETIME,
			@MGCliaNumber 			VARCHAR(30),
			@IsPaveOwnedData		VARCHAR(3),
			@AccountProcessing		VARCHAR(3),
			@lCount					INT,
			@I						INT = 1,
			@MGOutOfStateInd		VARCHAR(1),
			@MGCHDPCode				VARCHAR(150),
			@MGReEnrolInd			VARCHAR(10),
			@MGReEnrolDate			SMALLDATETIME,
			@MGProvisionalCode		VARCHAR(2),
			@MGProvisionalCodeDate	SMALLDATETIME,
			@MGLabStatusCode		VARCHAR(30),
			@MGLabStatusCodeDate	SMALLDATETIME,
			@MGNextReEnrollmentDate	SMALLDATETIME

	DECLARE @SubGroupAccountIDsAndPartyID TABLE
	(
		[SubGroupNPI]					VARCHAR(10) NULL,
		[SubGroupServiceLocationNo]		VARCHAR(3) NULL,
		[SubGroupOwnerNo]				VARCHAR(3) NULL,
		[MixedGroupClubbingID]			VARCHAR(18) NULL,
		[SubGroupAccountID]				INT NOT NULL,
		[SubGroupPartyID]				INT NULL,
		[SubGroupAccountNumber]			VARCHAR(20) NULL,
		[SubGroupLegalName]				VARCHAR(250) NULL,
		[SubGroupProviderTypeCode]		VARCHAR(5) NULL,
		[SubGroupProviderDescription]	VARCHAR(200) NULL,
		[SubGroupAccountType]			VARCHAR(25) NULL,
		[SubGroupPackageName]			VARCHAR(100) NULL,
		[SubGroupPracticeAddress]		VARCHAR(250) NULL
	)

	DECLARE @MGStatusAndDate TABLE
	(
		[NPI]					[VARCHAR](10) NULL,
		[ServiceLocationNo] 	[VARCHAR](3) NULL,
		[OwnerNo] 				[VARCHAR](3) NULL,
		[StatusAcc] 			[VARCHAR](50) NULL,
		[EarliestStartDate]		[SMALLDATETIME] NULL,
		[LatestStartDate] 		[SMALLDATETIME] NULL
	)

	DECLARE @MG_CLIA_AuxTable TABLE  
	(
		[CliaNumber] 	[VARCHAR](30) NULL,
		[MinCliaNumber] [VARCHAR](30) NULL,
		[MaxCliaNumber] [VARCHAR](30) NULL
	)
/*
	DECLARE @personTemp1 TABLE
	(
		DMLAction					VARCHAR(25),
		PartyID 					INT NULL,
		SSN 						VARCHAR(11) NULL, 
		Salutation 					VARCHAR(50) NULL, 
		FirstName 					VARCHAR(25) NULL, 
		LastName 					VARCHAR(25) NULL, 
		MiddleName 					VARCHAR(25) NULL, 
		DoB 						DATETIME NULL, 
		NPI 						VARCHAR(10) NULL,
		MOCARelationshipStartDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag		BIT NULL,
		NewCurrentRecordFlag		BIT NULL,
		OldMOCARelationshipEndDate	SMALLDATETIME NULL,
		NewMOCARelationshipEndDate	SMALLDATETIME NULL,
		NewIsDeleted				BIT NULL
	)

	DECLARE @OrgTemp1 TABLE
	(
		DMLAction					VARCHAR(25),
		PartyID 					INT NULL,
		TIN 						VARCHAR(11) NULL, 
		LegalName 					VARCHAR(100) NULL, 
		EIN 						VARCHAR(30) NULL, 
		NPI 						VARCHAR(10) NULL,
		MOCARelationshipStartDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag		BIT NULL,
		NewCurrentRecordFlag		BIT NULL,
		OldMOCARelationshipEndDate	SMALLDATETIME NULL,
		NewMOCARelationshipEndDate	SMALLDATETIME NULL,
		NewIsDeleted				BIT NULL
	)
*/
	DECLARE @TempRenderingAffiliationInsertSfileLog TABLE  
	(
		AccountID 				INT NOT NULL,
		AffiliatedAccountID 	INT NULL,
		TypeAffiliation			VARCHAR(50) NULL,
		AffiliationStartDate	SMALLDATETIME NULL,
		AffiliationEndDate		SMALLDATETIME NULL
	)

	DECLARE @TempRenderingAffiliationInsertYfileLog TABLE  
	(
		AccountID 				INT NOT NULL,
		AffiliatedAccountID 	INT NULL,
		TypeAffiliation			VARCHAR(50) NULL,
		AffiliationStartDate	SMALLDATETIME NULL,
		AffiliationEndDate		SMALLDATETIME NULL
	)

	DECLARE @TempSpecialityLog TABLE  
	(
		DMLAction				VARCHAR(25),
		SpecialityID			INT,
		PartyID					INT NOT NULL,
		OldSpecialityCode		VARCHAR(50) NULL,
		NewSpecialityCode		VARCHAR(50) NULL,
		OldSpecCertDate			SMALLDATETIME NULL,
		NewSpecCertDate			SMALLDATETIME NULL,
		NewType					VARCHAR(80) NULL,
		OldTaxonomyCode			VARCHAR(200) NULL,
		NewTaxonomyCode			VARCHAR(200) NULL,
		OldIsDeleted			INT NULL,
		NewIsDeleted			INT NULL
	)

	DECLARE @TempAccountLog TABLE  
	(
		AccountID				INT NOT NULL,
		OldLegalName			VARCHAR(250) NULL,
		NewLegalName			VARCHAR(250) NULL,
		OldBusinessName			VARCHAR(250) NULL,
		NewBusinessName			VARCHAR(250) NULL,
		OldEIN					VARCHAR(10) NULL,
		NewEIN					VARCHAR(10) NULL,
		OldSSN					VARCHAR(10) NULL,
		NewSSN					VARCHAR(10) NULL,
		OldPIN					VARCHAR(10) NULL,
		NewPIN					VARCHAR(10) NULL,
		OldProvLocTypeCd		VARCHAR(25) NULL,
		NewProvLocTypeCd		VARCHAR(25) NULL,
		OldPracticeAddress		VARCHAR(250) NULL,
		NewPracticeAddress		VARCHAR(250) NULL,
		OldPhone				VARCHAR(20) NULL,
		NewPhone				VARCHAR(20) NULL,
		OldActivationDate		SMALLDATETIME NULL,
		NewActivationDate		SMALLDATETIME NULL,
		OldDeActivationDate		SMALLDATETIME NULL,
		NewDeActivationDate		SMALLDATETIME NULL,
		OldStatusAcc			VARCHAR(50) NULL,
		NewStatusAcc			VARCHAR(50) NULL,
		OldStatusBeginDate		SMALLDATETIME NULL,
		NewStatusBeginDate		SMALLDATETIME NULL,
		OldNextReEnrollmentDate	SMALLDATETIME NULL,
		NewNextReEnrollmentDate	SMALLDATETIME NULL
	)
							
	DECLARE @TempAddressLog TABLE  
	(
		AddressID				INT NOT NULL,
		AddressType				VARCHAR(30) NULL,
		OldAddressLine1			VARCHAR(250) NULL,
		NewAddressLine1			VARCHAR(250) NULL,
		OldAddressLine2			VARCHAR(250) NULL,
		NewAddressLine2			VARCHAR(250) NULL,
		OldCounty				VARCHAR(25) NULL,
		NewCounty				VARCHAR(25) NULL,
		OldCity					VARCHAR(25) NULL,
		NewCity					VARCHAR(25) NULL,
		OldZip					VARCHAR(25) NULL,
		NewZip					VARCHAR(25) NULL,
		OldState				VARCHAR(40) NULL,
		NewState				VARCHAR(40) NULL
	)
							
	DECLARE @TempLocationLog TABLE  
	(
		LocationID			INT NOT NULL,
		OldPhone1			VARCHAR(25) NULL,
		NewPhone1			VARCHAR(25) NULL
	)
	
	DECLARE @TempOrganizationLog TABLE
	(
		OrgID				INT NOT NULL,
		OldTIN				VARCHAR(16),
		NewTIN				VARCHAR(16),
		OldLegalName		VARCHAR(100),
		NewLegalName		VARCHAR(100),
		OldDBAName1			VARCHAR(100),
		NewDBAName1			VARCHAR(100),
		OldBusinessName		VARCHAR(100),
		NewBusinessName		VARCHAR(100),
		OldPhone1			VARCHAR(20),
		NewPhone1			VARCHAR(20),
		OldEIN				VARCHAR(40),
		NewEIN				VARCHAR(40)
	)
						
	DECLARE @TempCLIALog TABLE  
	(
		CliaID					INT NOT NULL,
		OldCertificateType		VARCHAR(50) NULL,
		NewCertificateType		VARCHAR(50) NULL,
		OldCliaNumber			VARCHAR(30) NULL,
		NewCliaNumber			VARCHAR(30) NULL
	)						

	DECLARE @TempOwnerLog TABLE  
	(
		OwnerID					INT NOT NULL,
		OwnerNo					VARCHAR(3) NULL,
		OldEffectiveBeingDate	SMALLDATETIME NULL,
		NewEffectiveBeingDate	SMALLDATETIME NULL,
		OldEffectiveEndDate		SMALLDATETIME NULL,
		NewEffectiveEndDate		SMALLDATETIME NULL,
		OldLegalName			VARCHAR(150) NULL,
		NewLegalName			VARCHAR(150) NULL,
		OldBusinessName 		VARCHAR(150) NULL,
		NewBusinessName 		VARCHAR(150) NULL,
		OldDBAName 				VARCHAR(150) NULL,
		NewDBAName 				VARCHAR(150) NULL,
		OldTIN 					VARCHAR(15) NULL,
		NewTIN 					VARCHAR(15) NULL,
		OldTINH 				VARCHAR(15) NULL,
		NewTINH 				VARCHAR(15) NULL,
		OldSSN 					VARCHAR(15) NULL,
		NewSSN 					VARCHAR(15) NULL,
		OldSSNH 				VARCHAR(15) NULL,
		NewSSNH  				VARCHAR(15) NULL
	)
	
	DECLARE @TempBizProfileDetailLog TABLE
	(
		BizProfileDetailsID			INT,
		OldAccountEnrollmentStatus	VARCHAR(50) NULL,
		NewAccountEnrollmentStatus	VARCHAR(50) NULL,
		OldAccountBillingStatus 	VARCHAR(30) NULL,
		NewAccountBillingStatus		VARCHAR(30) NULL,
		OldAccountLegalName 		VARCHAR(150) NULL,
		NewAccountLegalName 		VARCHAR(150) NULL,
		OldAccountSSN 				VARCHAR(15) NULL,
		NewAccountSSN 				VARCHAR(15) NULL,
		OldAccountEIN 				VARCHAR(15) NULL,
		NewAccountEIN 				VARCHAR(15) NULL,
		OldAccountAddressLine1 		VARCHAR(255) NULL,
		NewAccountAddressLine1 		VARCHAR(255) NULL,
		OldAccountAddressLine2 		VARCHAR(100) NULL,
		NewAccountAddressLine2 		VARCHAR(100) NULL,
		OldAccountAdrCity 			VARCHAR(40) NULL,
		NewAccountAdrCity 			VARCHAR(40) NULL,
		OldAccountAdrState 			VARCHAR(40) NULL,
		NewAccountAdrState 			VARCHAR(40) NULL,
		OldAccountAdrZip9 			VARCHAR(15) NULL,
		NewAccountAdrZip9 			VARCHAR(15) NULL,
		OldAccountPhone 			VARCHAR(15) NULL,
		NewAccountPhone 			VARCHAR(15) NULL,
		OldAccountPIN 				VARCHAR(15) NULL,
		NewAccountPIN 				VARCHAR(15) NULL,
		OldEffectiveBeginDate 		SMALLDATETIME NULL,
		NewEffectiveBeginDate 		SMALLDATETIME NULL,
		OldEffectiveEndDate 		SMALLDATETIME NULL,
		NewEffectiveEndDate 		SMALLDATETIME NULL,
		OldPayAccountAddressLine1 	VARCHAR(100) NULL,
		NewPayAccountAddressLine1 	VARCHAR(100) NULL,
		OldPayAccountAddressLine2 	VARCHAR(100) NULL,
		NewPayAccountAddressLine2 	VARCHAR(100) NULL,
		OldPayAccountAdrCity		VARCHAR(40) NULL,
		NewPayAccountAdrCity 		VARCHAR(40) NULL,
		OldPayAccountAdrState 		VARCHAR(40) NULL,
		NewPayAccountAdrState 		VARCHAR(40) NULL,
		OldPayAccountAdrZip9 		VARCHAR(20) NULL,
		NewPayAccountAdrZip9 		VARCHAR(20) NULL,
		OldProfileID				VARCHAR(40) NULL,
		NewProfileID				VARCHAR(40) NULL
	)			

	DECLARE @TempAccountInternalUseLog TABLE  
	(
		AccountInternalUseID	INT NOT NULL,
		OldBillingStatus		VARCHAR(30) NULL,
		NewBillingStatus		VARCHAR(30) NULL,
		OldBillingBeginDate		SMALLDATETIME NULL,
		NewBillingBeginDate		SMALLDATETIME NULL,
		OldOutOfStateInd		VARCHAR(1) NULL,
		NewOutOfStateInd		VARCHAR(1) NULL,
		OldCHDPCode				VARCHAR(150) NULL,
		NewCHDPCode				VARCHAR(150) NULL,
		OldReEnrolInd			VARCHAR(10) NULL,
		NewReEnrolInd			VARCHAR(10) NULL,
		OldReEnrolDate			SMALLDATETIME NULL,
		NewReEnrolDate			SMALLDATETIME NULL,
		OldProvisionalCode		VARCHAR(2) NULL,
		NewProvisionalCode		VARCHAR(2) NULL,
		OldProvisionalCodeDate	SMALLDATETIME NULL,
		NewProvisionalCodeDate	SMALLDATETIME NULL,
		OldLabStatusCode		VARCHAR(30) NULL,
		NewLabStatusCode		VARCHAR(30) NULL,
		OldLabStatusCodeDate	SMALLDATETIME NULL,
		NewLabStatusCodeDate	SMALLDATETIME NULL
	)

	DECLARE @TempPaymentDetailLog TABLE  
	(
		PaymentDetailID			INT NOT NULL,
		OldEFTIndicator			VARCHAR(8) NULL,
		NewEFTIndicator			VARCHAR(8) NULL
	)

	DECLARE @TempRenderingAffiliationUpdateSfileLog TABLE  
	(
		RenderingAffiliationID	INT NOT NULL,
		AccountID				INT NULL,
		AffiliatedAccountID		INT NULL,
		NewTypeAffiliation		VARCHAR(50),
		AffiliationStartDate	SMALLDATETIME NULL,
		OldAffiliationEndDate	SMALLDATETIME NULL,
		NewAffiliationEndDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag	INT NULL,
		NewCurrentRecordFlag	INT NULL
	)
	
	DECLARE @TempRenderingAffiliationUpdateYfileLog TABLE  
	(
		RenderingAffiliationID	INT NOT NULL,
		AccountID				INT NULL,
		AffiliatedAccountID		INT NULL,
		NewTypeAffiliation		VARCHAR(50),
		AffiliationStartDate	SMALLDATETIME NULL,
		OldAffiliationEndDate	SMALLDATETIME NULL,
		NewAffiliationEndDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag	INT NULL,
		NewCurrentRecordFlag	INT NULL
	)
	
	DECLARE @TempRenderingAffiliationDELforSfileLog TABLE  
	(
		RenderingAffiliationID	INT NOT NULL,
		AccountID				INT NULL,
		AffiliatedAccountID		INT NULL,
		NewTypeAffiliation		VARCHAR(50),
		AffiliationStartDate	SMALLDATETIME NULL,
		OldAffiliationEndDate	SMALLDATETIME NULL,
		NewAffiliationEndDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag	INT NULL,
		NewCurrentRecordFlag	INT NULL
	)
	
	DECLARE @TempRenderingAffiliationDELforYfileLog TABLE  
	(
		RenderingAffiliationID	INT NOT NULL,
		AccountID				INT NULL,
		AffiliatedAccountID		INT NULL,
		NewTypeAffiliation		VARCHAR(50),
		AffiliationStartDate	SMALLDATETIME NULL,
		OldAffiliationEndDate	SMALLDATETIME NULL,
		NewAffiliationEndDate	SMALLDATETIME NULL,
		OldCurrentRecordFlag	INT NULL,
		NewCurrentRecordFlag	INT NULL
	)
	
	DECLARE @AccountNumberHistory TABLE
	(
		AccountID			INT,
		OldAccountNumber	VARCHAR(24),
		NewAccountNumber	VARCHAR(24)
	)

	DECLARE @TempMessage TABLE  
	(
		MessageID	INT NOT NULL,
		UUID		VARCHAR(200) NULL,
		DateSent	DATETIME NULL
	)

	DECLARE @TempRecipient TABLE
	(
		ID					INT PRIMARY KEY IDENTITY(1,1),
		MessageRecipientID	INT,
		Owner_User_ID		INT,
		Owner_Profile_ID	BIGINT,
		IsRead				BIT,
		IsDeleted			BIT,
		RecipientType		VARCHAR(50)
	)

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountStatusUpdate]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountStatusUpdate

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAddressUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAddressUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempLocationUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempLocationUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempOrganizationUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempOrganizationUpdated	
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountInternalUseUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountInternalUseUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempPaymentDetailUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempPaymentDetailUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationINSforSfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationINSforSfile
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationINSforYfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationINSforYfile
		
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempSpecialityNew]') AND TYPE IN (N'U'))
		DROP TABLE TempSpecialityNew

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempSpecialityDeleted]') AND TYPE IN (N'U'))
		DROP TABLE TempSpecialityDeleted
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempSpecialityUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempSpecialityUpdated
		
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempTaxonomyNew]') AND TYPE IN (N'U'))
		DROP TABLE TempTaxonomyNew
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempTaxonomyDeleted]') AND TYPE IN (N'U'))
		DROP TABLE TempTaxonomyDeleted
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempCLIAUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempCLIAUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempOwnerUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempOwnerUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountOwnerUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountOwnerUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationDELforSfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationDELforSfile
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationDELforYfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationDELforYfile

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationUPDforSfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationUPDforSfile
		
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationReactivateOrInsertforSfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationReactivateOrInsertforSfile
		
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempRenderingAffiliationReactivateOrInsertforYfile]') AND TYPE IN (N'U'))
		DROP TABLE TempRenderingAffiliationReactivateOrInsertforYfile

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountLegalNameUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountLegalNameUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountBusinessNameUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountBusinessNameUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountEINUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountEINUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountSSNUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountSSNUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountPINUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountPINUpdated

	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountProvLocTypCodUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountProvLocTypCodUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountOutOfStateIndicatorUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountOutOfStateIndicatorUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountCHDPCodeUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountCHDPCodeUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountReenrollmentIndicatorDateUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountReenrollmentIndicatorDateUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountProvisionalCodeDateUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountProvisionalCodeDateUpdated
		
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountLabStatusCodeDateUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountLabStatusCodeDateUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempBizProfileDetailUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempBizProfileDetailUpdated
	
	IF EXISTS (SELECT * FROM sys.objects WHERE OBJECT_ID = OBJECT_ID(N'[dbo].[TempAccountNextReEnrollmentDateUpdated]') AND TYPE IN (N'U'))
		DROP TABLE TempAccountNextReEnrollmentDateUpdated

	;
	DISABLE TRIGGER ALL	ON [KYPEnrollment].[pADM_Account];
	DISABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
/*
	DISABLE TRIGGER AccountHistory_MadeChange_Account  	ON [KYPEnrollment].[pADM_Account];
	DISABLE TRIGGER AffectedPortalActive 				ON [KYPEnrollment].[pADM_Account];
	DISABLE TRIGGER pADM_Account_AccStatus_tr 			ON [KYPEnrollment].[pADM_Account];
*/
--	DISABLE TRIGGER AccountsSearch 						ON KYPEnrollment.AccountSearch;

	SELECT @loopID = 1

	SELECT @MaxID = MAX(ID)
		FROM StageTableToLoopThroughMixedGroup

	WHILE @loopID <= @MaxID
	BEGIN

		SELECT @MixedGroupClubbingID = MixedGroupClubbingID
			FROM StageTableToLoopThroughMixedGroup
			WHERE ID = @loopID

		INSERT INTO @SubGroupAccountIDsAndPartyID 
		(
			[SubGroupNPI]
			,[SubGroupServiceLocationNo]
			,[SubGroupOwnerNo]
			,[MixedGroupClubbingID]
			,[SubGroupAccountID]
			,[SubGroupPartyID]
			,[SubGroupAccountNumber]
			,[SubGroupLegalName]
			,[SubGroupProviderTypeCode]
			,[SubGroupProviderDescription]
			,[SubGroupAccountType]
			,[SubGroupPackageName]
			,[SubGroupPracticeAddress])
		SELECT 	[SubGroupNPI]
				,[SubGroupServiceLocationNo]
				,[SubGroupOwnerNo]
				,[MixedGroupClubbingID]
				,[SubGroupAccountID]
				,[SubGroupPartyID]
				,[SubGroupAccountNumber]
				,[SubGroupLegalName]
				,[SubGroupProviderTypeCode]
				,[SubGroupProviderDescription]
				,[SubGroupAccountType]
				,[SubGroupPackageName]
				,[SubGroupPracticeAddress]
			FROM temp_StageSubGroups_ForComp_MGMapping
			WHERE MixedGroupClubbingID= @MixedGroupClubbingID
			ORDER BY SubGroupPartyID
		
		SELECT @IsPaveOwnedData = IsProvOwnedData,@AccountProcessing = AccProcessing
			FROM KYPEnrollment.pADM_Account ACC
			JOIN @SubGroupAccountIDsAndPartyID TV
			ON	NPI 					= SubGroupNPI AND
				ServiceLocationNo 		= SubGroupServiceLocationNo AND
				OwnerNo					= SubGroupOwnerNo
			WHERE ACC.ProviderTypeCode	= '100';
		
		IF @AccountProcessing = 0

		BEGIN
		
--Retrive the Account Number, ID and PartyID to be used  for MG
			SELECT @MGAccountNumber=A.AccountNumber,@MGPartyID = A.PartyID,@MGAccountID = A.AccountID
				FROM KYPEnrollment.pADM_Account A
				JOIN StageTableToLoopThroughMixedGroup B
				ON A.NPI + '_' + A.ServiceLocationNo + '_' + A.OwnerNo = B.MixedGroupClubbingID
				WHERE 	A.IsDeleted=0 
						AND A.ProviderTypeCode = '100'
						AND StatusAcc <>'7 - Active Rendering (indirect)'
						AND B.ID = @loopID

---===========>Transforming affiliations through KYPEnrollment.pAccount_RenderingAffiliation==========================
/*
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET [AffiliationEndDate]	= B.AffiliationEndDate,
						CurrentRecordFlag		= B.CurrentRecordFlag
					OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
							B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
							DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag														
						INTO @TempRenderingAffiliationUPDandDELLog
					FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
					JOIN (SELECT *
							FROM (SELECT AffiliatedAccountID,AffiliationStartDate,AffiliationEndDate,CurrentRecordFlag,
										 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID,AffiliationStartDate ORDER BY CurrentRecordFlag DESC,AffiliationEndDate DESC) RowNumber
									FROM KYPEnrollment.pAccount_RenderingAffiliation RA
									JOIN @SubGroupAccountIDsAndPartyID Temp
									ON RA.AccountID			= Temp.SubGroupAccountID) ILV
							WHERE RowNumber = 1) B
					ON	A.AffiliatedAccountID										= B.AffiliatedAccountID AND
						ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
					WHERE AccountID			= @MGAccountID
*/
/*
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET [AffiliationEndDate]	= B.AffiliationEndDate,
						CurrentRecordFlag		= B.CurrentRecordFlag
					OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
							B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
							DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag														
						INTO @TempRenderingAffiliationUPDandDELLog
					FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
					JOIN (SELECT *
							FROM (SELECT AffiliatedAccountID,AffiliationStartDate,AffiliationEndDate,CurrentRecordFlag,RenderingAffiliationID,
										 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID,AffiliationStartDate ORDER BY CurrentRecordFlag DESC,AffiliationEndDate DESC) RowNumber
									FROM KYPEnrollment.pAccount_RenderingAffiliation RA			
									WHERE AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
														FROM (SELECT AccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
														JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																FROM KYPEnrollment.pADM_Account
																WHERE	IsDeleted			= 0 AND
																		IsPastOwner			= 1 AND
																		(LEN(AccountNumber) = 13 OR LEN(AccountNumber) = 16) AND
																		ProviderTypeCode	!= 100) B -- All the SG of that MG
														ON	A.SubGroupNPI				= B.NPI AND
															A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
															A.SubGroupOwnerNo			= B.OwnerNo)) ILV
								WHERE RowNumber = 1) B
					ON	A.AffiliatedAccountID										= B.AffiliatedAccountID AND
						ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
					WHERE AccountID			= @MGAccountID

			SELECT	T.RenderingAffiliationID,T.AccountID,T.AffiliatedAccountID,T.NewTypeAffiliation,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationUPD
				FROM @TempRenderingAffiliationUPDandDELLog T
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON T.AccountID					= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON T.AffiliatedAccountID		= ACC1.AccountID	
				LEFT JOIN @TempRenderingAffiliationUPDandDELLog T1
				ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
					ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	!= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')
				WHERE T.NewTypeAffiliation		LIKE '%MIDLEVEL%' AND
					  /*T.OldCurrentRecordFlag	= 1 AND
					  T.NewCurrentRecordFlag	= 0 AND*/
					  T.OldCurrentRecordFlag	!= T.NewCurrentRecordFlag AND
					  T1.RenderingAffiliationID IS NOT NULL 

-- System fields update for Rendering Affiliation
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET LastAction			= 'U',
					LastUpdatedBy		= 'M',
					LastActorUserID		= 'system',
					[LastActionDate]	= GETDATE()
				WHERE RenderingAffiliationID IN (SELECT	RenderingAffiliationID
													FROM TempRenderingAffiliationUPD)
			
-- If the Rendering Updated then it's Account information also gets updated
			UPDATE [KYPEnrollment].[pADM_Account]
				SET [LastActorUserID]		= 'system',
					[LastActionApprovedBy]	= 'system',
					[LastAction]			= 'U',
					[LastActionDate]		= GETDATE(),
					[DateModified]			= GETDATE(),
					[AccountUpdateDate]		= GETDATE(),
					[AccountUpdatedBy]		= 'M'
				FROM [KYPEnrollment].[pADM_Account] ACC
				JOIN KYPEnrollment.pAccount_RenderingAffiliation RA
				ON ACC.AccountID				= RA.AccountID
				JOIN TempRenderingAffiliationUPD Temp
				ON RA.RenderingAffiliationID	= Temp.RenderingAffiliationID
			
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'UPD' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationUPD
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'UPD' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationUPD

			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			(
				[AccountID]
				,[AffiliatedAccountID]
				,[TypeAffiliation]
				,[AffiliationStartDate]
				,[AffiliationEndDate]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionComments]
				,[LastActionReason]
				,[LastActionApprovedBy]
				,[CurrentRecordFlag]
				,IsDeleted
				,[TempAffiliation]
				,[LastAction]
				,[LastUpdatedBy]
				,[groupEmail]
				,[rendering_email]
				,[AffiliatedAccountProvTypeCode])
			OUTPUT INSERTED.AccountID,INSERTED.AffiliatedAccountID,INSERTED.TypeAffiliation,INSERTED.AffiliationStartDate,INSERTED.AffiliationEndDate
				INTO @TempRenderingAffiliationINSLog
			SELECT 	@MGAccountID as [AccountID]
					,A.[AffiliatedAccountID]
					,[TypeAffiliation]
					,A.[AffiliationStartDate]
					,[AffiliationEndDate]
					,CONVERT(DATE,GETDATE(),112) 
					,'System'
					,NULL
					,NULL
					,'System'
					,1
					,0
					,[TempAffiliation]
					,'C'
					,'M'
					,NULL
					,NULL
					,[AffiliatedAccountProvTypeCode]
				FROM (SELECT AffiliatedAccountID,AffiliationStartDate,MAX([TypeAffiliation]) AS TypeAffiliation,MAX(AffiliationEndDate) AS AffiliationEndDate,
							 MAX([AffiliatedAccountProvTypeCode]) AS [AffiliatedAccountProvTypeCode],MAX(TempAffiliation) As TempAffiliation
						FROM KYPEnrollment.pAccount_RenderingAffiliation RA
						JOIN @SubGroupAccountIDsAndPartyID Temp
						ON RA.AccountID = Temp.SubGroupAccountID
						WHERE CurrentRecordFlag = 1
						GROUP BY AffiliatedAccountID,AffiliationStartDate) A
				LEFT JOIN (SELECT AffiliatedAccountID,AccountID,AffiliationStartDate
								FROM KYPEnrollment.pAccount_RenderingAffiliation
								WHERE AccountID			= @MGAccountID AND
									  CurrentRecordFlag = 1) B
				ON A.AffiliatedAccountID										= B.AffiliatedAccountID AND
				   ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
				WHERE B.AffiliatedAccountID	IS NULL;

			SELECT	RA.TypeAffiliation,RA.AccountID,RA.AffiliatedAccountID,RA.AffiliationStartDate,RA.AffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationINS
				FROM @TempRenderingAffiliationINSLog RA
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON RA.AccountID				= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON RA.AffiliatedAccountID	= ACC1.AccountID

-- Rendering Affiliation insertion for Account History
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'Y Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINS where TypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINS where TypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINS where TypeAffiliation LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINS where TypeAffiliation LIKE '%MIDLEVEL%'
*/


/*Below UPDATE statment is for S file. Two cases could happen, CurrentRecordFlag can change from 0 to 1 and 1 to 0. If it updates the Rendering 
	affiliation CurrentRecordFlag from 0 to 1 then its a New Case. If it's update the Rendering affiliation CurrentRecordFlag from 1 to 0 and 
	AffiliationEndDate also gets changed then it would be the Update case.*/

			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET [AffiliationEndDate]	= B.AffiliationEndDate,
					CurrentRecordFlag		= B.CurrentRecordFlag
				OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
						B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
						DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag														
					INTO @TempRenderingAffiliationUpdateSfileLog
				FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
				JOIN (SELECT *
						FROM (SELECT AffiliatedAccountID,AffiliationStartDate,AffiliationEndDate,CurrentRecordFlag,RenderingAffiliationID,
									 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID,AffiliationStartDate ORDER BY CurrentRecordFlag DESC,AffiliationEndDate DESC) RowNumber
								FROM KYPEnrollment.pAccount_RenderingAffiliation RA			
								WHERE AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
														FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
														JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																FROM KYPEnrollment.pADM_Account
																WHERE	IsDeleted			= 0 AND
																		IsPastOwner			= 1 AND
																		ProviderTypeCode	!= 100) B -- All the SG of that MG
														ON	A.SubGroupNPI				= B.NPI AND
															A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
															A.SubGroupOwnerNo			= B.OwnerNo AND
															A.SubGroupProviderTypeCode	= B.ProviderTypeCode) AND
									   IsDeleted = 0) ILV
							WHERE RowNumber = 1) B
				ON	A.AffiliatedAccountID										= B.AffiliatedAccountID AND
					ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
				WHERE AccountID			= @MGAccountID		AND
					  TypeAffiliation	LIKE '%MIDLEVEL%'	AND
					  IsDeleted			= 0

-- If it's update the Rendering affiliation CurrentRecordFlag from 1 to 0 and AffiliationEndDate also gets changed then it would be the Update case.
			SELECT	T.RenderingAffiliationID,T.AccountID,T.AffiliatedAccountID,T.NewTypeAffiliation,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationUPDforSfile
				FROM @TempRenderingAffiliationUpdateSfileLog T
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON T.AccountID					= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON T.AffiliatedAccountID		= ACC1.AccountID	
				LEFT JOIN @TempRenderingAffiliationUpdateSfileLog T1
				ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
					ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	!= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')
				WHERE T.NewTypeAffiliation		LIKE '%MIDLEVEL%' AND
					  T.OldCurrentRecordFlag	= 1 AND
					  T.NewCurrentRecordFlag	= 0 AND
					  -- T.OldCurrentRecordFlag	!= T.NewCurrentRecordFlag AND
					  T1.RenderingAffiliationID IS NOT NULL 

-- System fields update for Rendering Affiliation
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET LastAction			= 'U',
					LastUpdatedBy		= 'M',
					LastActorUserID		= 'system',
					[LastActionDate]	= GETDATE()
				WHERE RenderingAffiliationID IN (SELECT	TMP.RenderingAffiliationID
													FROM TempRenderingAffiliationUPDforSfile TMP)
			
-- If the Rendering Updated then it's Account information also gets updated
			UPDATE [KYPEnrollment].[pADM_Account]
				SET [LastActorUserID]		= 'system',
					[LastActionApprovedBy]	= 'system',
					[LastAction]			= 'U',
					[LastActionDate]		= GETDATE(),
					[DateModified]			= GETDATE(),
					[AccountUpdateDate]		= GETDATE(),
					[AccountUpdatedBy]		= 'M'
				FROM [KYPEnrollment].[pADM_Account] ACC
				JOIN KYPEnrollment.pAccount_RenderingAffiliation RA
				ON ACC.AccountID				= RA.AccountID
				JOIN TempRenderingAffiliationUPDforSfile Temp
				ON RA.RenderingAffiliationID	= Temp.RenderingAffiliationID
			
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'UPD' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationUPDforSfile
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'UPD' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationUPDforSfile
				
				
/*				
			SELECT	T.RenderingAffiliationID,T.AccountID,T.AffiliatedAccountID,T.NewTypeAffiliation,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationDELforYfile
				FROM @TempRenderingAffiliationUPDLog T
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON T.AccountID					= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON T.AffiliatedAccountID		= ACC1.AccountID	
				/*LEFT JOIN @TempRenderingAffiliationUPDLog T1
				ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
					ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	!= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')*/
				WHERE T.NewTypeAffiliation		NOT LIKE '%MIDLEVEL%' AND
					  T.OldCurrentRecordFlag	= 1 AND
					  T.NewCurrentRecordFlag	= 0 -- AND
					  -- T.OldCurrentRecordFlag	!= T.NewCurrentRecordFlag AND
					  -- T1.RenderingAffiliationID IS NOT NULL 

-- System fields update for Rendering Affiliation
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET LastAction			= 'U',
					LastUpdatedBy		= 'M',
					LastActorUserID		= 'system',
					[LastActionDate]	= GETDATE()
				WHERE RenderingAffiliationID IN (SELECT	RenderingAffiliationID
													FROM TempRenderingAffiliationDELforYfile)
			
-- If the Rendering Updated then it's Account information also gets updated
			UPDATE [KYPEnrollment].[pADM_Account]
				SET [LastActorUserID]		= 'system',
					[LastActionApprovedBy]	= 'system',
					[LastAction]			= 'U',
					[LastActionDate]		= GETDATE(),
					[DateModified]			= GETDATE(),
					[AccountUpdateDate]		= GETDATE(),
					[AccountUpdatedBy]		= 'M'
				FROM [KYPEnrollment].[pADM_Account] ACC
				JOIN KYPEnrollment.pAccount_RenderingAffiliation RA
				ON ACC.AccountID				= RA.AccountID
				JOIN TempRenderingAffiliationDELforYfile Temp
				ON RA.RenderingAffiliationID	= Temp.RenderingAffiliationID
			
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'Y Billing - Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforYfile where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforYfile where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
*/

-- If it updates the Rendering affiliation CurrentRecordFlag from 0 to 1 then its a New Case.
			SELECT	T.RenderingAffiliationID,T.AccountID,T.AffiliatedAccountID,T.NewTypeAffiliation,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationReactivateOrInsertforSfile
				FROM @TempRenderingAffiliationUpdateSfileLog T
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON T.AccountID					= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON T.AffiliatedAccountID		= ACC1.AccountID
				/*LEFT JOIN @TempRenderingAffiliationUpdateSfileLog T1
				ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
					ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	!= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')*/
				WHERE -- T.NewTypeAffiliation		LIKE '%MIDLEVEL%' AND
					  T.OldCurrentRecordFlag	= 0 AND
					  T.NewCurrentRecordFlag	= 1 --AND
					  -- T.OldCurrentRecordFlag	!= T.NewCurrentRecordFlag AND
					  --T1.RenderingAffiliationID IS NOT NULL 

			-- System fields update for Rendering Affiliation
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET LastAction			= 'U',
					LastUpdatedBy		= 'M',
					LastActorUserID		= 'system',
					[LastActionDate]	= GETDATE()
				WHERE RenderingAffiliationID IN (SELECT	TMP.RenderingAffiliationID
													FROM TempRenderingAffiliationReactivateOrInsertforSfile TMP)

			-- If the Rendering Updated then it's Account information also gets updated
			UPDATE [KYPEnrollment].[pADM_Account]
				SET [LastActorUserID]		= 'system',
					[LastActionApprovedBy]	= 'system',
					[LastAction]			= 'U',
					[LastActionDate]		= GETDATE(),
					[DateModified]			= GETDATE(),
					[AccountUpdateDate]		= GETDATE(),
					[AccountUpdatedBy]		= 'M'
				FROM [KYPEnrollment].[pADM_Account] ACC
				JOIN KYPEnrollment.pAccount_RenderingAffiliation RA
				ON ACC.AccountID				= RA.AccountID
				JOIN TempRenderingAffiliationReactivateOrInsertforSfile Temp
				ON RA.RenderingAffiliationID	= Temp.RenderingAffiliationID

			-- Rendering Affiliation insertion for Account History (Records which got reactivate, Reactivate means it's a new Insertion for Account History)
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationReactivateOrInsertforSfile WHERE NewTypeAffiliation LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationReactivateOrInsertforSfile WHERE NewTypeAffiliation LIKE '%MIDLEVEL%'

/*Below UPDATE statment is for Y file. If it updates the Rendering affiliation CurrentRecordFlag from 0 to 1 then its a New Case(As it is a New case we are reactivating the affiliation, making CurrentRecordFlag as 1 and IsDeleted as 0).
	Here, we are not updating 1 to 0 because As of now CurrentRecordFlag won’t change from 1 to 0 as Y file receives only DEL and NEW.
	When Delta load or Portal would do Delete, both will mark CurrentRecordFlag as 0 and IsDeleted flag as 1. So, in this case we are not
	doing anything for Mixed Group.*/
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET CurrentRecordFlag	= CASE WHEN A.CurrentRecordFlag = 0 THEN
												B.CurrentRecordFlag
											ELSE
												A.CurrentRecordFlag
											END,
					isDeleted			= CASE WHEN A.CurrentRecordFlag = 0 THEN
												B.isDeleted
											ELSE
												A.isDeleted
											END
				OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
						B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
						DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag														
					INTO @TempRenderingAffiliationUpdateYfileLog
				FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
				JOIN (SELECT *
						FROM (SELECT AffiliatedAccountID,AffiliationStartDate,AffiliationEndDate,CurrentRecordFlag,RenderingAffiliationID,isDeleted,
									 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID ORDER BY CurrentRecordFlag DESC) RowNumber
								FROM KYPEnrollment.pAccount_RenderingAffiliation RA			
								WHERE AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
														FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
														JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																FROM KYPEnrollment.pADM_Account
																WHERE	IsDeleted			= 0 AND
																		IsPastOwner			= 1 AND
																		ProviderTypeCode	!= 100) B -- All the SG of that MG
														ON	A.SubGroupNPI				= B.NPI AND
															A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
															A.SubGroupOwnerNo			= B.OwnerNo AND
															A.SubGroupProviderTypeCode	= B.ProviderTypeCode) AND
									   IsDeleted = 0) ILV
							WHERE RowNumber = 1) B
				ON	A.AffiliatedAccountID	= B.AffiliatedAccountID
				WHERE AccountID				= @MGAccountID		AND
					  TypeAffiliation		NOT LIKE '%MIDLEVEL%'	AND
					  A.isDeleted			= 0
						  
			SELECT	T.RenderingAffiliationID,T.AccountID,T.AffiliatedAccountID,T.NewTypeAffiliation,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationReactivateOrInsertforYfile
				FROM @TempRenderingAffiliationUpdateYfileLog T
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON T.AccountID					= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON T.AffiliatedAccountID		= ACC1.AccountID
				/*LEFT JOIN @TempRenderingAffiliationUPDLog T1
				ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
					ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	!= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')*/
				WHERE -- T.NewTypeAffiliation		LIKE '%MIDLEVEL%' AND
					  T.OldCurrentRecordFlag	= 0 AND
					  T.NewCurrentRecordFlag	= 1 --AND
					  -- T.OldCurrentRecordFlag	!= T.NewCurrentRecordFlag AND
					  --T1.RenderingAffiliationID IS NOT NULL 

			-- System fields update for Rendering Affiliation
			UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
				SET LastAction			= 'U',
					LastUpdatedBy		= 'M',
					LastActorUserID		= 'system',
					[LastActionDate]	= GETDATE()
				WHERE RenderingAffiliationID IN (SELECT	TMP.RenderingAffiliationID
													FROM TempRenderingAffiliationReactivateOrInsertforYfile TMP)

			-- If the Rendering Updated then it's Account information also gets updated
			UPDATE [KYPEnrollment].[pADM_Account]
				SET [LastActorUserID]		= 'system',
					[LastActionApprovedBy]	= 'system',
					[LastAction]			= 'U',
					[LastActionDate]		= GETDATE(),
					[DateModified]			= GETDATE(),
					[AccountUpdateDate]		= GETDATE(),
					[AccountUpdatedBy]		= 'M'
				FROM [KYPEnrollment].[pADM_Account] ACC
				JOIN KYPEnrollment.pAccount_RenderingAffiliation RA
				ON ACC.AccountID				= RA.AccountID
				JOIN TempRenderingAffiliationReactivateOrInsertforYfile Temp
				ON RA.RenderingAffiliationID	= Temp.RenderingAffiliationID
			
			-- Rendering Affiliation insertion for Account History (Records which got reactivate, Reactivate means it's a new Insertion for Account History)
			INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT AccountID,'Y Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationReactivateOrInsertforYfile WHERE NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
					UNION ALL
					SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationReactivateOrInsertforYfile WHERE NewTypeAffiliation NOT LIKE '%MIDLEVEL%'

-- Below Insert statment is for S file.
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			(
				[AccountID]
				,[AffiliatedAccountID]
				,[TypeAffiliation]
				,[AffiliationStartDate]
				,[AffiliationEndDate]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionComments]
				,[LastActionReason]
				,[LastActionApprovedBy]
				,[CurrentRecordFlag]
				,IsDeleted
				,[TempAffiliation]
				,[LastAction]
				,[LastUpdatedBy]
				,[groupEmail]
				,[rendering_email]
				,[AffiliatedAccountProvTypeCode])
			OUTPUT INSERTED.AccountID,INSERTED.AffiliatedAccountID,INSERTED.TypeAffiliation,INSERTED.AffiliationStartDate,INSERTED.AffiliationEndDate
				INTO @TempRenderingAffiliationInsertSfileLog
			SELECT 	@MGAccountID as [AccountID]
					,A.[AffiliatedAccountID]
					,[TypeAffiliation]
					,A.[AffiliationStartDate]
					,[AffiliationEndDate]
					,CONVERT(DATE,GETDATE(),112) 
					,'System'
					,NULL
					,NULL
					,'System'
					,1
					,0
					,[TempAffiliation]
					,'C'
					,'M'
					,NULL
					,NULL
					,[AffiliatedAccountProvTypeCode]
				FROM (SELECT AffiliatedAccountID,AffiliationStartDate,MAX([TypeAffiliation]) AS TypeAffiliation,MAX(AffiliationEndDate) AS AffiliationEndDate,
							 MAX([AffiliatedAccountProvTypeCode]) AS [AffiliatedAccountProvTypeCode],MAX(TempAffiliation) As TempAffiliation
						FROM KYPEnrollment.pAccount_RenderingAffiliation RA
						JOIN @SubGroupAccountIDsAndPartyID Temp
						ON RA.AccountID = Temp.SubGroupAccountID
						WHERE TypeAffiliation	LIKE '%MIDLEVEL%' AND
							  CurrentRecordFlag = 1 AND
							  IsDeleted			= 0
						GROUP BY AffiliatedAccountID,AffiliationStartDate) A
				LEFT JOIN (SELECT AffiliatedAccountID,AccountID,AffiliationStartDate
								FROM KYPEnrollment.pAccount_RenderingAffiliation
								WHERE AccountID			= @MGAccountID AND
									  TypeAffiliation	LIKE '%MIDLEVEL%' AND
									  CurrentRecordFlag = 1 AND
									  IsDeleted			= 0) B
				ON A.AffiliatedAccountID										= B.AffiliatedAccountID AND
				   ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
				WHERE TypeAffiliation		LIKE '%MIDLEVEL%' AND
					  B.AffiliatedAccountID	IS NULL;

			SELECT	RA.TypeAffiliation,RA.AccountID,RA.AffiliatedAccountID,RA.AffiliationStartDate,RA.AffiliationEndDate,
					ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
					ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
				INTO TempRenderingAffiliationINSforSfile
				FROM @TempRenderingAffiliationInsertSfileLog RA
				LEFT JOIN KYPEnrollment.pADM_Account ACC
				ON RA.AccountID				= ACC.AccountID
				LEFT JOIN KYPEnrollment.pADM_Account ACC1
				ON RA.AffiliatedAccountID	= ACC1.AccountID
-- Below Insert statment is for Y file.
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			(
				[AccountID]
				,[AffiliatedAccountID]
				,[TypeAffiliation]
				,[AffiliationStartDate]
				,[AffiliationEndDate]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionComments]
				,[LastActionReason]
				,[LastActionApprovedBy]
				,[CurrentRecordFlag]
				,IsDeleted
				,[TempAffiliation]
				,[LastAction]
				,[LastUpdatedBy]
				,[groupEmail]
				,[rendering_email]
				,[AffiliatedAccountProvTypeCode])
			OUTPUT INSERTED.AccountID,INSERTED.AffiliatedAccountID,INSERTED.TypeAffiliation,INSERTED.AffiliationStartDate,INSERTED.AffiliationEndDate
				INTO @TempRenderingAffiliationInsertYfileLog
			SELECT 	@MGAccountID AS [AccountID]
					,A.[AffiliatedAccountID]
					,[TypeAffiliation]
					,A.[AffiliationStartDate]
					,[AffiliationEndDate]
					,CONVERT(DATE,GETDATE(),112) 
					,'System'
					,NULL
					,NULL
					,'System'
					,1
					,0
					,[TempAffiliation]
					,'C'
					,'M'
					,NULL
					,NULL
					,[AffiliatedAccountProvTypeCode]
				FROM (SELECT *
						FROM (SELECT AffiliatedAccountID,AffiliationStartDate,TypeAffiliation,AffiliationEndDate,AffiliatedAccountProvTypeCode,
									 TempAffiliation,ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID ORDER BY AffiliationStartDate DESC) AS RN
									FROM KYPEnrollment.pAccount_RenderingAffiliation RA
									JOIN @SubGroupAccountIDsAndPartyID Temp
									ON RA.AccountID = Temp.SubGroupAccountID
									WHERE TypeAffiliation	NOT LIKE '%MIDLEVEL%' AND
										  CurrentRecordFlag = 1 AND
										  IsDeleted			= 0) ILV
						-- GROUP BY AffiliatedAccountID,AffiliationStartDate
						WHERE ILV.RN = 1) A
				LEFT JOIN (SELECT AffiliatedAccountID,AccountID,AffiliationStartDate
								FROM KYPEnrollment.pAccount_RenderingAffiliation
								WHERE AccountID			= @MGAccountID AND
									  TypeAffiliation	NOT LIKE '%MIDLEVEL%' AND
									  CurrentRecordFlag = 1 AND
									  IsDeleted			= 0) B
				ON A.AffiliatedAccountID										= B.AffiliatedAccountID/* AND
				   ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')*/
				WHERE TypeAffiliation		NOT LIKE '%MIDLEVEL%' AND
					  B.AffiliatedAccountID	IS NULL;

				SELECT	RA.TypeAffiliation,RA.AccountID,RA.AffiliatedAccountID,RA.AffiliationStartDate,RA.AffiliationEndDate,
						ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
						ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
					INTO TempRenderingAffiliationINSforYfile
					FROM @TempRenderingAffiliationInsertYfileLog RA
					LEFT JOIN KYPEnrollment.pADM_Account ACC
					ON RA.AccountID				= ACC.AccountID
					LEFT JOIN KYPEnrollment.pADM_Account ACC1
					ON RA.AffiliatedAccountID	= ACC1.AccountID

-- Rendering Affiliation insertion for Account History
			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'Y Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINSforYfile where TypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINSforYfile where TypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINSforSfile where TypeAffiliation LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'NEW' AS Action,'NPI' AS Attribute,'-' AS OldValue,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS NewValue,1 FROM TempRenderingAffiliationINSforSfile where TypeAffiliation LIKE '%MIDLEVEL%'

---===========>Ensuring that Rendering Supervisor is inserted for the MG Affiliation===========       

			MERGE [KYPEnrollment].[pAccount_RenderingSupervisor] TRGT
			USING 
			(  
				SELECT *
					FROM [KYPEnrollment].[pAccount_RenderingAffiliation] 
					WHERE AccountID = @MGAccountID
			)SRC
			ON (TRGT.RenderingAffiliationId = SRC.RenderingAffiliationID)
			WHEN NOT MATCHED THEN 
			INSERT
			( 
				[RenderingAffiliationId]
				,[InstanceId]
				,[ProviderNumber]
				,[Npi]
				,[Name]
				,[LicenseOrID]
				,[LicenseOrIdNumber]
				,[ProfessionalLicense]
				,[LicenseExpirationDate]
				,[isAccount]
				,[dateCreated]
				,[dateModified]
				,[dateDeleted]
				,[createdBy]
				,[modifiedBy]
				,[deletedBy]
				,[isDeleted]
				,[LastAction]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionReason]
				,[LastActionComments]
				,[LastActionApprovedBy]
				,[CurrentRecordFlag]

			)
			VALUES
			(
				SRC.[RenderingAffiliationId]
				,NULL
				,'No Data'
				,'No Data'
				,'No Data'
				,NULL
				,NULL
				,NULL
				,NULL
				,NULL
				,CONVERT(DATE,GETDATE(),112) 
				,NULL
				,NULL
				,NULL
				,NULL
				,NULL
				,0
				,'C'
				,CONVERT(DATE,GETDATE(),112) 
				,'System'
				,NULL
				,NULL
				,'System'
				,1
			 );

/*
Below code is commented by Anshu on 18th April, 2018. MOCA should not create for Mixed Group Account from Delta as Sub Account will create
MOCAs for MOCA linking. It was needed for MOCA spreading
*/

/*
---===========>Transforming Owners on to Mixed Group==========================       

-- First Transform Individual Owners of Sub Groups

			Print 'Going to start Owner Transposition for Ind Owner==>' +  convert(varchar(10),@loopID )

			MERGE [KYPEnrollment].[pAccount_PDM_Party] TRGT
			USING
			(
				SELECT	CASE MG.SSN WHEN NULL THEN 
							NULL
						ELSE
							MG.PartyID
						END PartyID, SG.Name, SG.MOCARelationshipStartDate AS SGMOCARelationshipStartDate, SG.MOCARelationshipEndDate,
							SG.SSN, SG.Salutation, SG.FirstName, SG.LastName,SG.MiddleName, SG.DOB, SG.NPI, SG.NPI AS ProviderNPI,
							MG.MOCARelationshipStartDate AS MGMOCARelationshipStartDate,SG.CurrentRecordFlag,SG.IsDeleted
					FROM ((SELECT *
								FROM(SELECT PRT.PartyID,PRT.Name, PRT.MOCARelationshipStartDate, PRT.MOCARelationshipEndDate,
											PRSN.SSN,PRSN.Salutation,PRSN.FirstName, PRSN.LastName, PRSN.MiddleName, PRSN.DoB, PRSN.NPI,
											PRT.IsDeleted,PRT.CurrentRecordFlag,
											ROW_NUMBER() OVER (PARTITION BY SSN,MOCARelationshipStartDate ORDER BY PRT.IsDeleted ASC,PRT.CurrentRecordFlag DESC) RowNumber
										FROM @SubGroupAccountIDsAndPartyID TEMP
										JOIN KYPEnrollment.pAccount_PDM_Party PRT
										ON TEMP.SubGroupPartyID = PRT.ParentPartyID  AND
										   PRT.Type = 'Individual Ownership'
										JOIN KYPEnrollment.pAccount_PDM_Person PRSN
										ON PRT.PartyID = PRSN.PartyID) ILV
								 WHERE ILV.RowNumber = 1) SG
								-- WHERE PRT.CurrentRecordFlag = 1
							LEFT JOIN(SELECT DISTINCT PRT.PartyID,PRT.Name, PRT.MOCARelationshipStartDate, PRT.MOCARelationshipEndDate, 
											  PRSN.SSN, PRSN.Salutation, PRSN.FirstName, PRSN.LastName, PRSN.MiddleName, PRSN.DOB, PRSN.NPI,
											  PRT.CurrentRecordFlag
											FROM @SubGroupAccountIDsAndPartyID TEMP
											JOIN KYPEnrollment.pADM_Account ACC
											ON TEMP.SubGroupNPI = ACC.NPI AND
											   TEMP.SubGroupServiceLocationNo = ACC.ServiceLocationNo AND
											   TEMP.SubGroupOwnerNo = ACC.OwnerNo AND
											   ACC.ProviderTypeCode = '100'
											JOIN KYPEnrollment.pAccount_PDM_Party PRT
											ON ACC.AccountID = PRT.AccountID AND
											   PRT.Type = 'Individual Ownership'
											JOIN KYPEnrollment.pAccount_PDM_Person PRSN
											ON PRT.PartyID = PRSN.PartyID) MG
											-- WHERE PRT.CurrentRecordFlag = 1
							ON	SG.SSN	= MG.SSN AND
								ISNULL(CONVERT(VARCHAR(32),SG.MOCARelationshipStartDate,105),'') = ISNULL(CONVERT(VARCHAR(32),MG.MOCARelationshipStartDate,105),''))
			) SRC
			ON TRGT.PartyID = SRC.PartyID
			WHEN NOT MATCHED THEN 
			INSERT
			(
				[AccountID]
				,[Type]
				,[Name]
				,[IsProvider]
				,[IsEnrolled]
				,[IsTemp]
				,[IsActive]
				,[LoadType]
				,[LoadID]
				,[LastLoadDate]
				,[DateModified]
				,[IsDeleted]
				,[Source]
				,[CreatedBy]
				,[DateCreated]
				,[ModifiedBy]
				,[DeletedBy]
				,[DateDeleted]
				,[ParentPartyID]
				,[profile_id]
				,[LastAction]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionReason]
				,[LastActionComments]
				,[LastActionApprovedBy]
				,[LastMOCARelationshipUpdateBy]
				,[LastMOCAUpdateBy]
				,[MOCARelationshipStartDate]
				,[MOCARelationshipEndDate]
				,[CurrentRecordFlag]	
			)
			VALUES
			(
				@MGAccountID
				,'Individual Ownership'
				,SRC.Name
				,0
				,1
				,0
				,1
				,'DeltaAccLoad'
				,CONVERT(VARCHAR(8), GETDATE(), 112)
				,getdate()
				,NULL
				,0
				,NULL
				,NULL
				,getdate()
				,NULL
				,NULL
				,'2069-12-31 00:00:00'
				,@MGPartyID
				,NULL
				,'C'
				,getdate()
				,'System'
				,NULL
				,NULL
				,'System'
				,'M'
				,'M'
				,SRC.SGMOCARelationshipStartDate
				,SRC.MOCARelationshipEndDate
				,1 
			)
			WHEN MATCHED THEN
				UPDATE SET	TRGT.MOCARelationshipEndDate	= SRC.MOCARelationshipEndDate,
							TRGT.CurrentRecordFlag			= SRC.CurrentRecordFlag,
							TRGT.IsDeleted					= SRC.IsDeleted
			OUTPUT	$Action,INSERTED.PartyID,SRC.SSN,SRC.Salutation,SRC.FirstName,SRC.LastName,SRC.MiddleName,SRC.DoB,SRC.NPI,
					SRC.SGMOCARelationshipStartDate,DELETED.CurrentRecordFlag,INSERTED.CurrentRecordFlag,
					DELETED.MOCARelationshipEndDate,INSERTED.MOCARelationshipEndDate,INSERTED.IsDeleted
				INTO @PersonTemp1;

			DELETE FROM @PersonTemp1 WHERE DMLAction IN('UPDATE','DELETE')

			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT @MGAccountID,'MOCA Individual' AS GroupName,'NEW' AS Action,'SSN' AS Attribute,'-' AS OldValue,SSN AS NewValue,1 FROM @PersonTemp1

			PRINT 'Ind Owner Party Done==>' +  CONVERT(VARCHAR(10),@loopID ) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Person](PartyID,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,DateDeleted,
				lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
			SELECT partyid,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,NULL,NULL,'C',GetDate(),'System','System',1  
				FROM @PersonTemp1

			PRINT 'Ind Owner Person Done==>' +  CONVERT(VARCHAR(10),@loopID ) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]([PartyID],[DateCreated],[IsDeleted],[NPI],[LastAction],[LastActionDate],[LastActorUserID],
				[LastActionApprovedBy],[CurrentRecordFlag])
			SELECT [PartyID],CONVERT(DATE,GETDATE(),112),0,[NPI],'C',CONVERT(DATE,GETDATE(),112),'System','System',1
				FROM @PersonTemp1 

			PRINT 'Ind Owner Provider Done==>' + CONVERT(VARCHAR(10),@loopID ) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Address](addressLine1 ,addressLine2,City,State,Zip,ZipPlus4,AddressType,lastAction,LastActionDate,
				LastActionUserId,LastActionApprovedByUsedID,CurrentRecordFlag,ServiceLocationNo)

			SELECT PartyID,NULL,NULL,NULL,NULL,NULL,'Moca','C',GetDate(),'System','System',1,NULL
				FROM @PersonTemp1

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,
				LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
			SELECT NULL,PartyID,NULL,GETDATE(),1,0,'No Data','C',GETDATE(),'System','System',1
				FROM @PersonTemp1

			UPDATE A 
				SET A.AddressID = B.AddressID
				FROM [KYPEnrollment].[pAccount_PDM_Location] A
				INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] B
				ON CAST(A.PartyID AS VARCHAR(10)) = B.AddressLine1 
				WHERE 	A.AddressID IS NULL AND
						B.AddressType = 'Moca' AND
						A.PartyID IN (SELECT PartyID
										FROM @PersonTemp1)
			 
			UPDATE [KYPEnrollment].[pAccount_PDM_Address]
				SET AddressLine1 	= 'No Data',
					AddressType 	= NULL
				WHERE AddressLine1 IN (SELECT CAST(PartyID AS VARCHAR(10))
										FROM @PersonTemp1)

			INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role (TypeForm, IsDeleted, CurrentRecordFlag, Other, OtherValue, OtherDate,PartyID, DateCreated,
				LastAction,LastActionDate,LastActionApprovedBy,LastActorUserID)
			SELECT 'OwnerControlInterestOwnerRole', 0, 1, 1,'No Data',MOCARelationshipStartDate,PartyID,GETDATE(),'C',NULL,'System','System'  
				FROM @PersonTemp1

			-- Below code is written because same MOCA may occurs in multiple Subgroup with the different MOCARelationshipStartDate. In that case, MG level only one MOCA should display with first MOCARelationshipStartDate.
			UPDATE KYPEnrollment.pAccount_PDM_Party
				SET CurrentRecordFlag	= 0,
					IsDeleted			= 1,
					LastActorUserID		= 'System',
					[LastActionDate]	= GETDATE()
				FROM KYPEnrollment.pAccount_PDM_Party P
				JOIN (SELECT *
						FROM (SELECT P.PartyID,ROW_NUMBER() OVER (PARTITION BY SSN ORDER BY P.MOCARelationshipStartDate ASC) AS RN
								FROM KYPEnrollment.pAccount_PDM_Party P
								JOIN KYPEnrollment.pAccount_PDM_Person PRS
								ON P.PartyID = PRS.PartyID
								WHERE AccountID				= @MGAccountID AND
									  P.Type				= 'Individual Ownership' AND
									  P.CurrentRecordFlag	= 1 AND
									  P.IsDeleted			= 0) ILV
						WHERE ILV.RN > 1) ILV1
				ON P.PartyID = ILV1.PartyID
				WHERE AccountID = @MGAccountID

			PRINT 'Completed Owner Transposition for Ind Owner==>' +  convert(varchar(10),@loopID )

--Then Transform Entity Owners of Sub Groups

			PRINT 'Going to start Entity Transposition for Org Owner==>' +  convert(varchar(10),@loopID )

			MERGE [KYPEnrollment].[pAccount_PDM_Party]  TRGT
			USING 
			(
				SELECT	CASE MG.EIN WHEN NULL THEN 
							NULL
						ELSE
							MG.PartyID
						END PartyID, SG.Name, SG.MOCARelationshipStartDate AS SGMOCARelationshipStartDate, SG.MOCARelationshipEndDate,
							SG.TIN, SG.LegalName,SG.EIN, SG.NPI, SG.NPI as ProviderNPI,MG.MOCARelationshipStartDate AS MGMOCARelationshipStartDate,
							SG.CurrentRecordFlag,SG.IsDeleted
					FROM ((SELECT * FROM
								(SELECT	PRT.PartyID,PRT.Name, ORG.TIN, PRT.MOCARelationshipStartDate, PRT.MOCARelationshipEndDate, 
										ORG.LegalName,ORG.EIN,ORG.NPI,ORG.NPI AS ProviderNPI,PRT.IsDeleted,PRT.CurrentRecordFlag,
										ROW_NUMBER() OVER (PARTITION BY EIN,MOCARelationshipStartDate ORDER BY PRT.IsDeleted ASC,PRT.CurrentRecordFlag DESC) RowNumber
									FROM @SubGroupAccountIDsAndPartyID TEMP
									JOIN KYPEnrollment.pAccount_PDM_Party PRT
									ON TEMP.SubGroupPartyID = PRT.ParentPartyID AND
									   PRT.Type = 'Entity Ownership'
									JOIN KYPEnrollment.pAccount_PDM_Organization ORG
									ON PRT.PartyID = ORG.PartyID) ILV
									WHERE ILV.RowNumber = 1) SG
								-- WHERE PRT.CurrentRecordFlag = 1
							LEFT JOIN (SELECT DISTINCT PRT.PartyID,PRT.Name, PRT.MOCARelationshipStartDate, PRT.MOCARelationshipEndDate, 
											  ORG.TIN,ORG.LegalName,ORG.EIN,ORG.NPI,ORG.NPI AS ProviderNPI,PRT.CurrentRecordFlag
										FROM @SubGroupAccountIDsAndPartyID TEMP
										JOIN KYPEnrollment.pADM_Account ACC
										ON TEMP.SubGroupNPI = ACC.NPI AND
										   TEMP.SubGroupServiceLocationNo = ACC.ServiceLocationNo AND
										   TEMP.SubGroupOwnerNo = ACC.OwnerNo AND
										   ACC.ProviderTypeCode = '100'
										JOIN KYPEnrollment.pAccount_PDM_Party PRT
										ON ACC.AccountID = PRT.AccountID AND
										   PRT.Type = 'Entity Ownership'
										JOIN KYPEnrollment.pAccount_PDM_Organization ORG
										ON PRT.PartyID = ORG.PartyID) MG
										-- WHERE PRT.CurrentRecordFlag = 1
							ON	SG.EIN	= MG.EIN AND
								ISNULL(CONVERT(VARCHAR(32),SG.MOCARelationshipStartDate,105),'') = ISNULL(CONVERT(VARCHAR(32),MG.MOCARelationshipStartDate,105),'')
								-- AND SG.CurrentRecordFlag	= MG.CurrentRecordFlag
								)
			) SRC
			ON TRGT.PartyID = SRC.PartyID
			WHEN NOT MATCHED THEN 
			INSERT 
			(
				[AccountID]
				,[Type]
				,[Name]
				,[IsProvider]
				,[IsEnrolled]
				,[IsTemp]
				,[IsActive]
				,[LoadType]
				,[LoadID]
				,[LastLoadDate]
				,[DateModified]
				,[IsDeleted]
				,[Source]
				,[CreatedBy]
				,[DateCreated]
				,[ModifiedBy]
				,[DeletedBy]
				,[DateDeleted]
				,[ParentPartyID]
				,[profile_id]
				,[LastAction]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionReason]
				,[LastActionComments]
				,[LastActionApprovedBy]
				,[LastMOCARelationshipUpdateBy]
				,[LastMOCAUpdateBy]
				,[MOCARelationshipStartDate]
				,[MOCARelationshipEndDate]
				,[CurrentRecordFlag]	
			)
			VALUES
			(
				@MGAccountID
				,'Entity Ownership'
				,SRC.Name
				,0
				,1
				,0
				,1
				,'DeltaAccLoad'
				,CONVERT(VARCHAR(8), GETDATE(), 112)
				,getdate()
				,NULL
				,0
				,NULL
				,NULL
				,getdate()
				,NULL
				,NULL
				,'2069-12-31 00:00:00'
				,@MGPartyID
				,NULL
				,'C'
				,getdate()
				,'System'
				,NULL
				,NULL
				,'System'
				,'M'
				,'M'
				,SRC.SGMOCARelationshipStartDate
				,SRC.MOCARelationshipEndDate
				,1 
			)
			WHEN MATCHED THEN
			UPDATE SET	TRGT.MOCARelationshipEndDate	= SRC.MOCARelationshipEndDate,
						TRGT.CurrentRecordFlag			= SRC.CurrentRecordFlag,
						TRGT.IsDeleted					= SRC.IsDeleted
			OUTPUT	$Action,INSERTED.PartyID,SRC.TIN, SRC.LegalName,SRC.EIN,SRC.NPI,SRC.SGMOCARelationshipStartDate,DELETED.CurrentRecordFlag,
					INSERTED.CurrentRecordFlag,DELETED.MOCARelationshipEndDate,INSERTED.MOCARelationshipEndDate,INSERTED.IsDeleted
				INTO @OrgTemp1;

			DELETE FROM @OrgTemp1 WHERE DMLAction IN('UPDATE','DELETE')

			INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT @MGAccountID,'MOCA Organization' AS GroupName,'NEW' AS Action,'EIN' AS Attribute,'-' AS OldValue,EIN AS NewValue,1 FROM @OrgTemp1

			PRINT 'Org Owner Party Done==>' +  convert(varchar(10),@loopID ) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization](PartyID,LegalName,DBAName1,TIN,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,
				LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,EIN)
			SELECT PartyID,LegalName,NULL,TIN,NPI,NULL,NULL,'C',GetDate(),'System','System',1,EIN
				FROM @OrgTemp1

			PRINT 'Org Owner Organization Done==>' +  convert(varchar(10),@loopID ) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]([PartyID],[DateCreated],[IsDeleted],[NPI],[LastAction],[LastActionDate],[LastActorUserID]
				,[LastActionApprovedBy],[CurrentRecordFlag])
			SELECT [PartyID],CONVERT(DATE,GETDATE(),112),0,[NPI],'C',CONVERT(DATE,GETDATE(),112),'System','System',1
				FROM @OrgTemp1 

			PRINT 'Org Owner Provider Done==>' +  CONVERT(VARCHAR(10),@loopID) 

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Address](addressLine1,addressLine2,City,State ,Zip,ZipPlus4,AddressType,lastAction,LastActionDate,
							LastActionUserId,LastActionApprovedByUsedID,CurrentRecordFlag,ServiceLocationNo)

			SELECT PartyID,NULL,NULL,NULL,NULL,NULL,'Moca','C',GETDATE(),'System','System',1,NULL
				FROM @OrgTemp1

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,
				LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
			SELECT NULL,Partyid,NULL,GETDATE(),1,0,'No Data','C',GETDATE(),'System','System',1
				FROM @OrgTemp1

			UPDATE A
				SET A.AddressID = B.AddressID
				FROM [KYPEnrollment].[pAccount_PDM_Location] A
				INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] B
				ON CAST(A.PartyID AS VARCHAR(10)) = B.AddressLine1 
				WHERE A.AddressID IS NULL AND
					  B.AddressType = 'Moca' AND
					  A.PARTYID IN (SELECT PartyID
										FROM @OrgTemp1)
			 
			UPDATE [KYPEnrollment].[pAccount_PDM_Address]
				SET AddressLine1 = 'No Data',
					AddressType = NULL
				WHERE AddressLine1 IN (SELECT CAST(PartyID AS VARCHAR(10))
											FROM @OrgTemp1)

			INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role(TypeForm,IsDeleted,CurrentRecordFlag,Other,OtherValue,OtherDate,PartyID,DateCreated,LastAction,
				LastActionDate,LastActionApprovedBy,LastActorUserID)
			SELECT 'OwnerControlInterestOwnerRole', 0, 1, 1,'No Data',MOCARelationshipStartDate,PartyID,GETDATE(),'C',NULL,'System','System'  
				FROM @OrgTemp1

			-- Below code is written because same MOCA may occurs in multiple Subgroup with the different MOCARelationshipStartDate. In that case, MG level only one MOCA should display with first MOCARelationshipStartDate.
			UPDATE KYPEnrollment.pAccount_PDM_Party
				SET CurrentRecordFlag	= 0,
					IsDeleted			= 1,
					LastActorUserID		= 'System',
					[LastActionDate]	= GETDATE()
				FROM KYPEnrollment.pAccount_PDM_Party P
				JOIN (SELECT *
						FROM (SELECT P.PartyID,ROW_NUMBER() OVER (PARTITION BY EIN ORDER BY P.MOCARelationshipStartDate ASC) AS RN
								FROM KYPEnrollment.pAccount_PDM_Party P
								JOIN KYPEnrollment.pAccount_PDM_Organization ORG
								ON P.PartyID = ORG.PartyID
								WHERE AccountID				= @MGAccountID AND
									  P.Type				= 'Entity Ownership' AND
									  P.CurrentRecordFlag	= 1 AND
									  P.IsDeleted			= 0) ILV
						WHERE ILV.RN > 1) ILV1
				ON P.PartyID = ILV1.PartyID
				WHERE AccountID = @MGAccountID

			PRINT 'Completed Owner Transposition for Org Owner==>' + CONVERT(VARCHAR(10),@loopID )
*/
---===========>Do Account Numbering Change (Account and Account Search) and Flagging of subgroups==========================      
-- Only for Scenario 3 as 2 is for created, 4 is for updated and 1 we are already updating the Account number in calling procedure
			IF @Scenario = 1 OR @Scenario = 3

			BEGIN
				
				/*Commented by Anshuman on 12th Apr, 2017: From Portal, first Group Account is created and one application created on top of it,
				  later for same key fields Mixed Group also created. Now this Group Account will come through Delta load.
				  Whenever an application raised to any Group Account and that Group Account now changed into
				  the Subgroup then will send a notification to the Provider that "Group Account changed into the Mixed Group Account". For that we need to insert
				  records in three tables KYPPORTAL.PortalKYP.Message, KYPPORTAL.PortalKYP.MessageRecipient and KYPPORTAL.PortalKYP.Recipient*/

				/*SELECT SubGroupAccountID,AccountNumber,CONVERT(DATE,GETDATE(),105) AS DateSent,NEWID() AS UUID
					INTO #TempGroupAccountChangedintoMixedGroupAccount
					FROM @SubGroupAccountIDsAndPartyID Temp
					JOIN KYPEnrollment.pADM_Account ACC
					ON Temp.SubGroupAccountID	= ACC.AccountID
					JOIN KYPPORTAL.PortalKYP.pRenderingAffiliation RA -- Account should be exist in this table then only it will convert into Mixed Group
					ON Temp.SubGroupAccountID	= RA.Group_Instance_ID
					GROUP BY SubGroupAccountID,AccountNumber
				*/
				SELECT SubGroupAccountID,Group_AccountNumber AS AccountNumber,CONVERT(DATE,GETDATE(),105) AS DateSent,NEWID() AS UUID
					INTO #TempGroupAccountChangedintoMixedGroupAccount
					FROM @SubGroupAccountIDsAndPartyID Temp
					--JOIN KYPEnrollment.pADM_Account ACC
					--ON Temp.SubGroupAccountID	= ACC.AccountID
					JOIN KYPPORTAL.PortalKYP.pRenderingAffiliation RA -- Account should be exist in this table then only it will convert into Mixed Group
					ON Temp.SubGroupAccountID		= RA.Group_Instance_ID
					JOIN KYP.ADM_Case C
					ON RA.Rendering_ProviderNumber	= C.Number
					GROUP BY SubGroupAccountID,Group_AccountNumber

				INSERT INTO KYPPORTAL.PortalKYP.Message
				(
					FromGroupName,
					BodyMessage,
					Subject,
					IsDeleted,
					UUID,
					DateSent,
					NotifiedByPublic,
					IsMailSent,
					TotalAttachments
				)
				OUTPUT INSERTED.MessageID,INSERTED.UUID,INSERTED.DateSent
					INTO @TempMessage
				SELECT 'DHCS Provider Enrollment Department','<HTML><BODY>This message is for informational purposes only. DHCS Medi-Cal has approved one or more Rendering Provider type affiliations, which provider type(s) are different from your original group&rsquo;s type. The follow changes were made to your group&rsquo;s account.<br><br>
				Old Account ID: <b>' + AccountNumber + '</b><br><br>
				Group Type: <b>Mixed Group</b><br>
				New Account ID:<b>' + @MGAccountNumber + '</b><br><br>
				If you have any questions or concerns, please send a message to <b><a href="#" onclick="messageCenterWidget.writeNewMessage();inboxDialog.close();">DHCS Provider Enrollment Division</a></b><br><br>
				Sincerely,<br>
				DHCS Medi-Cal<br>
				Provider Enrollment Division<br>
				</BODY></HTML>','Account ID: ' + AccountNumber + ' Changed to Mixed Group',0,UUID,DateSent,1,0,0	--,SubGroupAccountID
					FROM #TempGroupAccountChangedintoMixedGroupAccount	

				INSERT INTO KYPPORTAL.PortalKYP.MessageRecipient(MessageID,Type)
					SELECT MessageID,'new'
						FROM @TempMessage

				INSERT INTO	@TempRecipient		
					SELECT MR.MessageRecipientID,ILV.Owner_User_ID,ILV.Owner_Profile_ID,0,0,'PortalUser'
						FROM @TempMessage Temp
						JOIN KYPPORTAL.PortalKYP.MessageRecipient MR
						ON Temp.MessageID = MR.MessageID
						JOIN (SELECT DISTINCT Owner_User_ID,Owner_Profile_ID,UUID,DateSent
								FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
								JOIN #TempGroupAccountChangedintoMixedGroupAccount Temp
								ON RA.Group_Instance_ID = Temp.SubGroupAccountID) ILV
						ON	Temp.UUID		= ILV.UUID AND
							Temp.DateSent	= ILV.DateSent

					UNION

					SELECT MR.MessageRecipientID,ILV.Associate_User_ID,ILV.Associate_Profile_ID,0,0,'PortalUser'
						FROM @TempMessage Temp
						JOIN KYPPORTAL.PortalKYP.MessageRecipient MR
						ON Temp.MessageID = MR.MessageID
						JOIN (SELECT DISTINCT Associate_User_ID,Associate_Profile_ID,UUID,DateSent
								FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
								JOIN #TempGroupAccountChangedintoMixedGroupAccount Temp
								ON RA.Group_Instance_ID = Temp.SubGroupAccountID
								WHERE Associate_User_ID		IS NOT NULL AND
									  Associate_Profile_ID	IS NOT NULL) ILV
						ON	Temp.UUID		= ILV.UUID AND
							Temp.DateSent	= ILV.DateSent

				WHILE @I <= (SELECT COUNT(1)
								FROM @TempRecipient)
								
				BEGIN

					INSERT INTO KYPPORTAL.PortalKYP.Recipient
					(
						MessageRecipientID,
						PortalUserID,
						ProfileID,
						IsRead,
						IsDeleted,
						RecipientType
					)
					SELECT	MessageRecipientID,
							Owner_User_ID,
							Owner_Profile_ID,
							IsRead,
							IsDeleted,
							RecipientType
						FROM @TempRecipient
						WHERE ID = @I

					SET @I = @I + 1
					
				END

				UPDATE A 
					SET	A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode,
						A.IsPastOwner 	= 1,
						A.LastActionDate = GETDATE()
					OUTPUT INSERTED.AccountID,DELETED.AccountNumber,INSERTED.AccountNumber
					INTO @AccountNumberHistory
					FROM [KYPEnrollment].[pADM_Account] A
					JOIN @SubGroupAccountIDsAndPartyID B
					ON A.AccountID = B.SubGroupAccountID

				INSERT INTO KYPEnrollment.MixedGroupHistory(AccountID,GroupName,[Action],Attribute,OldValue,NewValue,IsFlag)
					SELECT AccountID,'Mixed Group Created','UPD','Account Number',OldAccountNumber,NewAccountNumber,0
						FROM @AccountNumberHistory

				UPDATE A
					SET A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode
					FROM KYPEnrollment.AccountSearch A
					JOIN @SubGroupAccountIDsAndPartyID B
					ON A.AccountID = B.SubGroupAccountID
				
				UPDATE A
					SET A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode
					FROM KYPEnrollment.pAccount_BizProfile_Details A
					JOIN @SubGroupAccountIDsAndPartyID B
					ON A.AccountID = B.SubGroupAccountID
				
				/*Commented by Anshuman on 12th Apr, 2017: Whenever an application raised to any Group Account and that Group Account now changed 
				  into the Subgroup then Group Account ID will changed into Mixed Groyp AccountID in Portal tables and will track the history also*/

				UPDATE KYPPORTAL.PortalKYP.pRenderingAffiliation
					SET Old_Group_Instance_ID	 = Group_Instance_ID,
						Old_Group_ProviderNumber = Group_ProviderNumber,
						Account_Changed_to_SubGroup_Account_Date = GETDATE()
					FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON RA.Group_Instance_ID	= B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.pRenderingAffiliation
					SET Group_Instance_ID	 = @MGAccountID,
						Group_ProviderNumber = @MGAccountNumber
					FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON RA.Group_Instance_ID	= B.SubGroupAccountID	

				UPDATE KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation
					SET Old_GroupAccountID	= GroupAccountID,
						Account_Changed_to_SubGroup_Account_Date = GETDATE()
					FROM KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation RA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON RA.GroupAccountID = B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation
					SET GroupAccountID	 = @MGAccountID
					FROM KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation RA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON RA.GroupAccountID = B.SubGroupAccountID

				/* For Group Service address tab*/
				UPDATE KYPPORTAL.PortalKYP.pServiceAddressRendering
					SET Old_AccountID								= AccountID,
						Old_AccountNumber							= AccountNumber,
						Account_Changed_to_SubGroup_Account_Date	= GETDATE()
					FROM KYPPORTAL.PortalKYP.pServiceAddressRendering SA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON SA.AccountID	= B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.pServiceAddressRendering
					SET AccountID		= @MGAccountID,
						AccountNumber	= @MGAccountNumber
					FROM KYPPORTAL.PortalKYP.pServiceAddressRendering SA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON SA.AccountID	= B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.pAffiliationServiceAddress
					SET Old_AccountID	= AccountID,
						Account_Changed_to_SubGroup_Account_Date = GETDATE()
					FROM KYPPORTAL.PortalKYP.pAffiliationServiceAddress ASA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON ASA.AccountID = B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.pAffiliationServiceAddress
					SET AccountID	= @MGAccountID
					FROM KYPPORTAL.PortalKYP.pAffiliationServiceAddress ASA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON ASA.AccountID = B.SubGroupAccountID

				/*Application*/
				UPDATE KYP.ADM_Case
					SET AccountNumberBeforeConvertingToSubgroup	= Group_AccountNumber,
						AccountChangedToSubgroupDate			= GETDATE()
					FROM KYP.ADM_Case AC
					JOIN @SubGroupAccountIDsAndPartyID B
					ON AC.Group_AccountNumber = B.SubGroupAccountNumber
					WHERE ApplnType IN('Rendering-S','New Rendering')

				UPDATE KYP.ADM_Case
					SET Group_AccountNumber = @MGAccountNumber
					FROM KYP.ADM_Case AC
					JOIN @SubGroupAccountIDsAndPartyID B
					ON AC.Group_AccountNumber = B.SubGroupAccountNumber
					WHERE ApplnType IN('Rendering-S','New Rendering')

				UPDATE KYP.ADM_Case
					SET AccountNumberBeforeConvertingToSubgroup	= Group_DisaffiliateAcNo,
						AccountChangedToSubgroupDate			= GETDATE()
					FROM KYP.ADM_Case AC
					JOIN @SubGroupAccountIDsAndPartyID B
					ON AC.Group_DisaffiliateAcNo = B.SubGroupAccountNumber
					WHERE ApplnType IN('Disaffiliation')
					
				UPDATE KYP.ADM_Case
					SET Group_DisaffiliateAcNo	= @MGAccountNumber,
						AccountNo				= @MGAccountNumber
					FROM KYP.ADM_Case AC
					JOIN @SubGroupAccountIDsAndPartyID B
					ON AC.Group_DisaffiliateAcNo = B.SubGroupAccountNumber
					WHERE ApplnType IN('Disaffiliation')

				/*Linked application*/
				UPDATE KYP.OIS_UserLinkedAppDetail
					SET GroupApplicationNumberBeforeConvertingToSubgroup = GroupApplicationNo,
						AccountChangedToSubgroupDate					 = GETDATE()
					FROM KYP.OIS_UserLinkedAppDetail L
					JOIN @SubGroupAccountIDsAndPartyID B
					ON L.GroupApplicationNo = B.SubGroupAccountNumber

				UPDATE KYP.OIS_UserLinkedAppDetail
					SET GroupApplicationNo = @MGAccountNumber
					FROM KYP.OIS_UserLinkedAppDetail L
					JOIN @SubGroupAccountIDsAndPartyID B
					ON L.GroupApplicationNo = B.SubGroupAccountNumber
				
				/*Account Section in Portal*/
				UPDATE KYPPORTAL.PortalKYP.AccountSectionChange
					SET Old_AccountID								= AccountID,
						Old_AccountNumber							= AccountNumber,
						Account_Changed_to_SubGroup_Account_Date	= GETDATE()
					FROM KYPPORTAL.PortalKYP.AccountSectionChange AC
					JOIN @SubGroupAccountIDsAndPartyID B
					ON AC.AccountID = B.SubGroupAccountID

				UPDATE KYPPORTAL.PortalKYP.AccountSectionChange
					SET AccountID		= @MGAccountID,
						AccountNumber	= @MGAccountNumber
					FROM KYPPORTAL.PortalKYP.AccountSectionChange RA
					JOIN @SubGroupAccountIDsAndPartyID B
					ON RA.AccountID	= B.SubGroupAccountID
				
			DROP TABLE #TempGroupAccountChangedintoMixedGroupAccount

			END

-- Get the MG Status and Dates as below before inserting into pADM_Account
			INSERT INTO @MGStatusAndDate 
			(
				[NPI] ,
				[ServiceLocationNo] ,
				[OwnerNo],
				[StatusAcc] ,
				[EarliestStartDate] ,
				[LatestStartDate]
			)
			SELECT	NPI,
					ServiceLocationNo,
					OwnerNo,
					StatusAcc,
					MIN(StatusBeginDate) AS EarliestDate,
					MAX(StatusBeginDate) AS LatestDate
				FROM KYPEnrollment.pADM_Account
				WHERE AccountID IN (SELECT TMP.SubGroupAccountID
										FROM @SubGroupAccountIDsAndPartyID TMP)
			GROUP BY NPI,ServiceLocationNo,OwnerNo,StatusAcc
			ORDER BY NPI,ServiceLocationNo,OwnerNo,StatusAcc	
					
			IF EXISTS (SELECT 1
							FROM @MGStatusAndDate
							WHERE StatusAcc = '1 - Active')
			BEGIN

				SELECT @MGStatusAcc='1 - Active'
				SELECT @MGBillingStatus = '1 - Billing'
				SELECT @MGStatusBeginDate = EarliestStartDate
					FROM @MGStatusAndDate
					WHERE StatusAcc = '1 - Active' 
				SELECT @MGActivationDate = EarliestStartDate
					FROM @MGStatusAndDate
					WHERE StatusAcc = '1 - Active' 
				SELECT @MGDeactivationDate = NULL

			END

			IF NOT EXISTS (SELECT 1
								FROM @MGStatusAndDate
								WHERE StatusAcc = '1 - Active')
			BEGIN

				SELECT @MGStatusAcc='2 - Inactive'
				SELECT @MGBillingStatus = NULL
				SELECT @MGStatusBeginDate = LatestStartDate
					FROM @MGStatusAndDate
					WHERE StatusAcc <> '1 - Active' 
				SELECT @MGDeactivationDate = LatestStartDate
					FROM @MGStatusAndDate
					WHERE StatusAcc <> '1 - Active' 
				SELECT @MGActivationDate = NULL

			END

			SELECT @MGOutOfStateInd = OutOfStateInd
				FROM (SELECT OutOfStateInd,ROW_NUMBER() OVER (ORDER BY OutOfStateInd) AS RN
						FROM [KYPEnrollment].EDM_AccountInternalUse
						WHERE	AccountID IN (SELECT TMP.SubGroupAccountID
												FROM @SubGroupAccountIDsAndPartyID TMP) AND
								ISNULL(OutOfStateInd,'') != '') ILV
				WHERE ILV.RN = 1

			SELECT @MGCHDPCode = CHDPCode
				FROM (SELECT CHDPCode,ROW_NUMBER() OVER (ORDER BY CHDPCode) AS RN
						FROM [KYPEnrollment].EDM_AccountInternalUse
						WHERE	AccountID IN (SELECT TMP.SubGroupAccountID
												FROM @SubGroupAccountIDsAndPartyID TMP) AND
								ISNULL(CHDPCode,'') != '') ILV
				WHERE ILV.RN = 1

			SELECT @MGReEnrolInd = ReEnrolInd,@MGReEnrolDate = ReEnrolDate,@MGNextReEnrollmentDate = ReEnrollmentDate
				FROM (SELECT ReEnrolInd,ReEnrolDate,ROW_NUMBER() OVER (ORDER BY ReEnrolDate DESC) AS RN,ACC.ReenrollmentDate
						FROM [KYPEnrollment].EDM_AccountInternalUse IUD
						JOIN KYPEnrollment.pADM_Account ACC
						ON IUD.AccountID = ACC.AccountID
						WHERE	IUD.AccountID IN (SELECT TMP.SubGroupAccountID
													FROM @SubGroupAccountIDsAndPartyID TMP)/* AND
								ISNULL(ReEnrolDate,'') != ''*/) ILV
				WHERE ILV.RN = 1

			SELECT @MGProvisionalCode = ProvisionalCode,@MGProvisionalCodeDate = ProvisionalCodeDate
				FROM (SELECT ProvisionalCode,ProvisionalCodeDate,ROW_NUMBER() OVER (ORDER BY ProvisionalCodeDate DESC) AS RN
						FROM [KYPEnrollment].EDM_AccountInternalUse
						WHERE	AccountID IN (SELECT TMP.SubGroupAccountID
												FROM @SubGroupAccountIDsAndPartyID TMP)/* AND
								ISNULL(ProvisionalCodeDate,'') != ''*/) ILV
				WHERE ILV.RN = 1

			SELECT @MGLabStatusCode = LabStatusCode,@MGLabStatusCodeDate = LabStatusCodeDate
				FROM (SELECT LabStatusCode,LabStatusCodeDate,ROW_NUMBER() OVER (ORDER BY LabStatusCodeDate DESC) AS RN
						FROM [KYPEnrollment].EDM_AccountInternalUse
						WHERE	AccountID IN (SELECT TMP.SubGroupAccountID
												FROM @SubGroupAccountIDsAndPartyID TMP) AND
								ISNULL(LabStatusCode,'') != '') ILV
				WHERE ILV.RN = 1
/*
			MERGE [KYPEnrollment].[pAccount_PDM_Speciality]  TRGT
				USING
				(
					--SELECT	@MGPartyID AS [MGPartyID],
					--			Speciality_Code,
					--			TaxonomyCode,
					--			[Type],
					--			MAX([SpecCertDate]) AS SpecCertDate
					--	FROM [KYPEnrollment].[pAccount_PDM_Speciality]  
					--	WHERE PartyID IN (SELECT SubGroupPartyID
					--						FROM @SubGroupAccountIDsAndPartyID) AND
					--		  Speciality_Code NOT IN ('99','00') AND
					--		  IsDeleted = 0
					--	GROUP BY Speciality_Code,[Type],TaxonomyCode
					SELECT *
						FROM (SELECT @MGPartyID AS [MGPartyID],
									 [TaxonomyCode],
									 [Speciality_Code],
									 [DateDeleted],
									 [IsDeleted],
									 [CurrentRecordFlag],
									 [Type],
									 [SpecCertDate],
									 ROW_NUMBER() OVER (PARTITION BY Speciality_Code ORDER BY LastActionDate DESC) AS RowNumber
								FROM [KYPEnrollment].[pAccount_PDM_Speciality]
								WHERE PartyID IN (SELECT SubGroupPartyID
													FROM @SubGroupAccountIDsAndPartyID) AND
									  Speciality_Code NOT IN ('99','00')) ILV
						WHERE ILV.RowNumber = 1
				) SRC
				ON (TRGT.PartyID					= SRC.MGPartyID AND
					ISNULL(TRGT.Speciality_Code,'')	= ISNULL(SRC.Speciality_Code,''))
				WHEN NOT MATCHED THEN 
					INSERT 
					(	
						[PartyID]
						,[TaxonomyCode]
						,[Speciality_Code]
						,[Board]
						,[CreatedBy]
						,[DateCreated]
						,[ModifiedBy]
						,[DeletedBy]
						,[DateDeleted]
						,[IsDeleted]
						,[LastAction]
						,[LastActionDate]
						,[LastActorUserID]
						,[LastActionReason]
						,[LastActionComments]
						,[LastActionApprovedBy]
						,[CurrentRecordFlag]
						,[Type]
						,[SpecCertDate]
					)
					 VALUES
					 (
						@MGPartyID
						,SRC.[TaxonomyCode]
						,SRC.[Speciality_Code]
						,NULL
						,1
						,CONVERT(DATE,GETDATE(),112)
						,NULL
						,NULL
						,SRC.[DateDeleted]
						,SRC.[IsDeleted]
						,'C'
						,CONVERT(DATE,GETDATE(),112)
						,'system'
						,NULL
						,NULL
						,'system'
						,SRC.[CurrentRecordFlag]
						,SRC.[Type]
						,SRC.[SpecCertDate]
					 )
				 WHEN MATCHED THEN
					UPDATE SET	TRGT.IsDeleted			= SRC.IsDeleted,
								TRGT.CurrentRecordFlag	= SRC.CurrentRecordFlag,
								TRGT.DateModified		= CONVERT(DATE,GETDATE(),112)
				OUTPUT	$Action AS DMLAction,INSERTED.SpecialityID,INSERTED.PartyID AS PartyID,
						DELETED.Speciality_Code AS OldSpecialityCode,INSERTED.Speciality_Code AS NewSpecialityCode,
						DELETED.SpecCertDate AS OldSpecCertDate,INSERTED.SpecCertDate AS NewSpecCertDate,INSERTED.[Type] AS NewType,
						DELETED.TaxonomyCode AS OldTaxonomyCode,INSERTED.TaxonomyCode AS NewTaxonomyCode,
						DELETED.IsDeleted AS OldIsDeleted,INSERTED.IsDeleted AS NewIsDeleted
					INTO @TempSpecialityLog;
*/
					
					
					
			
			
			
			
			
			
			
			IF @IsPaveOwnedData = 0

			BEGIN

---===========>Specialty and Taxonomy in the table called PDM_Specialty (send all valid spec & taxonomy)==========================

-- Distinct clause along with exception of 99 and 00 would ensure that repitions are avoided
				MERGE [KYPEnrollment].[pAccount_PDM_Speciality]  TRGT
				USING 
				(
					/*SELECT	@MGPartyID AS [MGPartyID],
								Speciality_Code,
								TaxonomyCode,
								[Type],
								MAX([SpecCertDate]) AS SpecCertDate
						FROM [KYPEnrollment].[pAccount_PDM_Speciality]  
						WHERE PartyID IN (SELECT SubGroupPartyID
											FROM @SubGroupAccountIDsAndPartyID) AND
							  Speciality_Code NOT IN ('99','00') AND
							  IsDeleted = 0
						GROUP BY Speciality_Code,[Type],TaxonomyCode*/
					SELECT *
						FROM (SELECT @MGPartyID AS [MGPartyID],
									 [TaxonomyCode],
									 [Speciality_Code],
									 [DateDeleted],
									 [IsDeleted],
									 [CurrentRecordFlag],
									 [Type],
									 [SpecCertDate],
									 ROW_NUMBER() OVER (PARTITION BY Speciality_Code ORDER BY LastActionDate DESC) AS RowNumber
								FROM [KYPEnrollment].[pAccount_PDM_Speciality]
								WHERE PartyID IN (SELECT TMP.SubGroupPartyID
													FROM @SubGroupAccountIDsAndPartyID TMP) AND
									  Speciality_Code NOT IN ('99','00')) ILV
						WHERE ILV.RowNumber = 1
				) SRC
				ON (TRGT.PartyID					= SRC.MGPartyID AND
					ISNULL(TRGT.Speciality_Code,'')	= ISNULL(SRC.Speciality_Code,''))
				WHEN NOT MATCHED THEN 
					INSERT 
					(	
						[PartyID]
						,[TaxonomyCode]
						,[Speciality_Code]
						,[Board]
						,[CreatedBy]
						,[DateCreated]
						,[ModifiedBy]
						,[DeletedBy]
						,[DateDeleted]
						,[IsDeleted]
						,[LastAction]
						,[LastActionDate]
						,[LastActorUserID]
						,[LastActionReason]
						,[LastActionComments]
						,[LastActionApprovedBy]
						,[CurrentRecordFlag]
						,[Type]
						,[SpecCertDate]
					)
					 VALUES
					 (
						@MGPartyID
						,SRC.[TaxonomyCode]
						,SRC.[Speciality_Code]
						,NULL
						,1
						,CONVERT(DATE,GETDATE(),112)
						,NULL
						,NULL
						,SRC.[DateDeleted]
						,SRC.[IsDeleted]
						,'C'
						,CONVERT(DATE,GETDATE(),112)
						,'system'
						,NULL
						,NULL
						,'system'
						,SRC.[CurrentRecordFlag]
						,SRC.[Type]
						,SRC.[SpecCertDate]
					 )
				 WHEN MATCHED THEN
					UPDATE SET	TRGT.IsDeleted			= SRC.IsDeleted,
								TRGT.CurrentRecordFlag	= SRC.CurrentRecordFlag,
								TRGT.DateModified		= CONVERT(DATE,GETDATE(),112)
				OUTPUT	$Action AS DMLAction,INSERTED.SpecialityID,INSERTED.PartyID AS PartyID,
						DELETED.Speciality_Code AS OldSpecialityCode,INSERTED.Speciality_Code AS NewSpecialityCode,
						DELETED.SpecCertDate AS OldSpecCertDate,INSERTED.SpecCertDate AS NewSpecCertDate,INSERTED.[Type] AS NewType,
						DELETED.TaxonomyCode AS OldTaxonomyCode,INSERTED.TaxonomyCode AS NewTaxonomyCode,
						DELETED.IsDeleted AS OldIsDeleted,INSERTED.IsDeleted AS NewIsDeleted
					INTO @TempSpecialityLog;

-- Speciality Insertion
				SELECT T.PartyID,NewSpecialityCode,NewTaxonomyCode,NewSpecCertDate,NewType
					INTO TempSpecialityNew
					FROM @TempSpecialityLog T
					JOIN KYPEnrollment.pADM_Account ACC
					ON	T.PartyID		= ACC.PartyID AND
						ACC.IsDeleted	= 0
					WHERE DMLAction		= 'INSERT' AND
						  NewType		= 'Specialty Code'

-- Speciality Deletion
				SELECT SpecialityID,OldSpecialityCode,OldTaxonomyCode,OldSpecCertDate,NewType
					INTO TempSpecialityDeleted
					FROM @TempSpecialityLog
					WHERE DMLAction		= 'UPDATE'			AND
						  NewType		= 'Specialty Code'	AND
						  OldIsDeleted	= 0 AND
						  NewIsDeleted	= 1

				UPDATE [KYPEnrollment].[pAccount_PDM_Speciality]
					SET	IsDeleted			= 1,
						CurrentRecordFlag	= 0,
						DateDeleted			= CONVERT(DATE,GETDATE(),112)
					WHERE SpecialityID IN (SELECT TMP.SpecialityID
											FROM TempSpecialityDeleted TMP)

-- Speciality Updation
				SELECT T.SpecialityID,T.OldSpecialityCode,T.NewSpecialityCode,T.OldTaxonomyCode,T.NewTaxonomyCode,T.OldSpecCertDate,T.NewSpecCertDate
					INTO TempSpecialityUpdated
					FROM @TempSpecialityLog T
					LEFT JOIN @TempSpecialityLog T1
					ON	T.SpecialityID											= T1.SpecialityID		AND
						T.OldSpecialityCode										= T1.NewSpecialityCode AND
						ISNULL(CONVERT(VARCHAR(32),T.OldSpecCertDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewSpecCertDate,105),'')
					WHERE T.DMLAction		= 'UPDATE'			AND
						  T.NewType			= 'Specialty Code'	AND
						  T.NewIsDeleted	= 0					AND
						  T1.SpecialityID	IS NULL

-- Speciality System fields update
				UPDATE [KYPEnrollment].[pAccount_PDM_Speciality]
					SET	[ModifiedBy]			= 1,
						[LastAction]			= 'U',
						[LastActionDate]		= CONVERT(DATE,GETDATE(),112),
						[LastActorUserID]		= 'system',
						[LastActionReason]		= NULL,
						[LastActionComments]	= NULL,
						[LastActionApprovedBy]	= 'system'
					WHERE SpecialityID IN (SELECT TMP.SpecialityID
											FROM TempSpecialityUpdated TMP)

-- If the Speciality Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Speciality SPC
					ON ACC.PartyID = SPC.PartyID
					JOIN TempSpecialityUpdated Temp
					ON SPC.SpecialityID	= Temp.SpecialityID

-- Taxonomy Insertion
				SELECT T.PartyID,NewSpecialityCode,NewTaxonomyCode,NewType
					INTO TempTaxonomyNew
					FROM @TempSpecialityLog T
					JOIN KYPEnrollment.pADM_Account ACC
					ON	T.PartyID		= ACC.PartyID AND
						ACC.IsDeleted	= 0
					WHERE DMLAction		= 'INSERT' AND
						  NewType		= 'Taxonomy Code'

-- Taxonomy Deletion
				SELECT PartyID,OldSpecialityCode,OldTaxonomyCode,NewType
					INTO TempTaxonomyDeleted
					FROM @TempSpecialityLog
					WHERE DMLAction		= 'UPDATE'			AND
						  NewType		= 'Taxonomy Code'	AND
						  OldIsDeleted	= 0 AND
						  NewIsDeleted	= 1

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Specialty' AS GroupName,'NEW' AS Action,'Specialty' AS Attribute,'-' AS OldValue,ISNULL(NewTaxonomyCode,'-') + '(' + ISNULL(NewSpecialityCode,'-') + ')~' + ISNULL(CONVERT(VARCHAR(32),NewSpecCertDate,105),'-') AS NewValue,1 FROM TempSpecialityNew
					UNION ALL
					SELECT @MGAccountID,'Specialty' AS GroupName,'DEL' AS Action,'Specialty' AS Attribute,ISNULL(OldTaxonomyCode,'-') + '(' + ISNULL(OldSpecialityCode,'-') + ')~' + ISNULL(CONVERT(VARCHAR(32),OldSpecCertDate,105),'-') AS OldValue,'-' AS NewValue,1 FROM TempSpecialityDeleted
					UNION ALL
					SELECT @MGAccountID,'Specialty' AS GroupName,'UPD' AS Action,'Specialty' AS Attribute,ISNULL(OldTaxonomyCode,'-') + '(' + ISNULL(OldSpecialityCode,'-') + ')~' + ISNULL(CONVERT(VARCHAR(32),OldSpecCertDate,105),'-') AS OldValue,NewTaxonomyCode + '(' + NewSpecialityCode + ')~' + CONVERT(VARCHAR(32),NewSpecCertDate,105) AS NewValue,0 FROM TempSpecialityUpdated
					UNION ALL
					SELECT @MGAccountID,'Taxonomy' AS GroupName,'NEW' AS Action,'Taxonomy Code' AS Attribute,'-' AS OldValue,NewSpecialityCode + ': ' + ISNULL(NewTaxonomyCode,'-') AS NewValue,1 FROM TempTaxonomyNew
					UNION ALL
					SELECT @MGAccountID,'Taxonomy' AS GroupName,'DEL' AS Action,'Taxonomy Code' AS Attribute,OldSpecialityCode + ': ' + ISNULL(OldTaxonomyCode,'-') AS OldValue,'-' AS NewValue,1 FROM TempTaxonomyDeleted
				
-- Set primary Specialty
				UPDATE [KYPEnrollment].[pAccount_PDM_Speciality]
					SET IsPrimary = 1 
					WHERE	PartyID = @MGPartyID AND 
							Speciality_Code = (SELECT TOP 1 TMP.[Speciality_Code]
													FROM [KYPEnrollment].[pAccount_PDM_Speciality] TMP
													WHERE PartyID = (SELECT MAX(TMP1.SubGroupPartyID)
																		FROM @SubGroupAccountIDsAndPartyID TMP1) AND
														  IsPrimary = 1 AND
														  [Type] = 'Specialty Code'
												/*SELECT TOP 1 TMP.[Speciality_Code] 
													FROM [KYPEnrollment].[pAccount_PDM_Speciality] TMP
													WHERE	PartyID = @MGPartyID AND
															[Type] = 'Specialty Code'
															ORDER BY Speciality_Code ASC*/) -- Correction done on 2nd January, 2019

-- Set Primary Taxonomy
				UPDATE [KYPEnrollment].[pAccount_PDM_Speciality]  
					SET IsPrimary = 1 
					WHERE	PartyID = @MGPartyID AND
							[Speciality_Code] = (SELECT TOP 1 TMP.[Speciality_Code]
													FROM [KYPEnrollment].[pAccount_PDM_Speciality] TMP
													WHERE PartyID = (SELECT MAX(TMP1.SubGroupPartyID)
																		FROM @SubGroupAccountIDsAndPartyID TMP1) AND
														  IsPrimary = 1 AND
														  [Type] = 'Taxonomy Code')

				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LegalName]				= ILV.LegalName,														
						[PracticeAddress]		= ILV.PracticeAddress,
						[StatusBeginDate]		= @MGStatusBeginDate,
						[ActivationDate]		= @MGActivationDate,
						[DeActivationDate]		= @MGDeactivationDate,
						[StatusAcc]				= @MGStatusAcc,
						[SSN]					= ILV.SSN,
						[EIN]					= ILV.EIN,
						[PIN]					= ILV.PIN,
						[Phone]					= ILV.Phone,
						[BusinessName]			= ILV.BusinessName,
						ProvLocTypeCd			= ILV.ProvLocTypeCd,
						ReEnrollmentDate		= @MGNextReEnrollmentDate,
						IsCrossover				= CASE WHEN @MGProvisionalCode = 'X' THEN
															1
														ELSE
															0
														END,
						LastActionDate = GETDATE()
					OUTPUT	INSERTED.AccountID,DELETED.LegalName AS OldLegalName,INSERTED.LegalName AS NewLegalName,
							DELETED.BusinessName AS OldBusinessName,INSERTED.BusinessName AS NewBusinessName,
							DELETED.EIN AS OldEIN,INSERTED.EIN AS NewEIN,DELETED.SSN AS OldSSN,INSERTED.SSN AS NewSSN,DELETED.PIN AS OldPIN,
							INSERTED.PIN AS NewPIN,DELETED.ProvLocTypeCd AS OldProvLocTypeCd,INSERTED.ProvLocTypeCd AS NewProvLocTypeCd,
							DELETED.PracticeAddress AS OldPracticeAddress,INSERTED.PracticeAddress AS NewPracticeAddress,
							DELETED.Phone AS OldPhone,INSERTED.Phone AS NewPhone,
							DELETED.ActivationDate AS OldActivationDate,@MGActivationDate AS NewActivationDate,
							DELETED.DeActivationDate AS OldDeActivationDate,@MGDeactivationDate AS NewDeActivationDate,
							-- Below fields are useful for Account Status
							DELETED.StatusAcc AS OldStatusAcc,@MGStatusAcc AS NewStatusAcc,
							DELETED.StatusBeginDate AS OldStatusBeginDate,@MGStatusBeginDate AS NewStatusBeginDate,
							DELETED.ReEnrollmentDate AS OldNextReEnrollmentDate,@MGNextReEnrollmentDate AS NewNextReEnrollmentDate
						INTO @TempAccountLog
					FROM KYPEnrollment.pADM_Account ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,LegalName,PracticeAddress,LastActorUserID,LastActionApprovedBy,AccountUpdateUserID,
								 AccountUpdatedBy,SSN,EIN,PIN,Phone,BusinessName,ProvLocTypeCd,CreatedBy
							FROM KYPEnrollment.pADM_Account
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID
				
				SELECT	T.AccountID,T.OldLegalName,T.NewLegalName,T.OldBusinessName,T.NewBusinessName,T.OldEIN,T.NewEIN,T.OldSSN,T.NewSSN,
						T.OldPIN,T.NewPIN,T.OldProvLocTypeCd,T.NewProvLocTypeCd
					INTO TempAccountUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID													= T1.AccountID							AND
						ISNULL(T.OldPracticeAddress,'')								= ISNULL(T1.NewPracticeAddress,'')		AND
						ISNULL(T.OldPhone,'')										= ISNULL(T1.NewPhone,'')				AND
						ISNULL(CONVERT(VARCHAR(32),T.OldActivationDate,105),'')		= ISNULL(CONVERT(VARCHAR(32),T1.NewActivationDate,105),'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldDeActivationDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewDeActivationDate,105),'')AND
						ISNULL(T.OldStatusAcc,'')									= ISNULL(T1.NewStatusAcc,'')								AND
						ISNULL(CONVERT(VARCHAR(32),T.OldStatusBeginDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewStatusBeginDate,105),'')
					WHERE T1.AccountID IS NULL

				SELECT	T.AccountID,T.OldLegalName,T.NewLegalName
					INTO TempAccountLegalNameUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID					= T1.AccountID		AND
						ISNULL(T.OldLegalName,'')	= ISNULL(T1.NewLegalName,'')
					WHERE T1.AccountID IS NULL

				SELECT	T.AccountID,T.OldBusinessName,T.NewBusinessName
					INTO TempAccountBusinessNameUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID					= T1.AccountID		AND
						ISNULL(T.OldBusinessName,'')= ISNULL(T1.NewBusinessName,'')
					WHERE T1.AccountID IS NULL
					
				SELECT	T.AccountID,T.OldEIN,T.NewEIN
					INTO TempAccountEINUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID			= T1.AccountID	AND
						ISNULL(T.OldEIN,'')	= ISNULL(T1.NewEIN,'')
					WHERE T1.AccountID IS NULL
					
				SELECT	T.AccountID,T.OldSSN,T.NewSSN
					INTO TempAccountSSNUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID			= T1.AccountID	AND
						ISNULL(T.OldSSN,'')	= ISNULL(T1.NewSSN,'')
					WHERE T1.AccountID IS NULL
					
				SELECT	T.AccountID,T.OldPIN,T.NewPIN
					INTO TempAccountPINUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID			= T1.AccountID AND
						ISNULL(T.OldPIN,'')	= ISNULL(T1.NewPIN,'')
					WHERE T1.AccountID IS NULL
					
				SELECT	T.AccountID,T.OldProvLocTypeCd,T.NewProvLocTypeCd
					INTO TempAccountProvLocTypCodUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID						= T1.AccountID		AND
						ISNULL(T.OldProvLocTypeCd,'')	= ISNULL(T1.NewProvLocTypeCd,'')
					WHERE T1.AccountID IS NULL
				
				SELECT	T.AccountID,T.OldNextReEnrollmentDate,T.NewNextReEnrollmentDate
					INTO TempAccountNextReEnrollmentDateUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID								= T1.AccountID		AND
						ISNULL(T.OldNextReEnrollmentDate,'')	= ISNULL(T1.NewNextReEnrollmentDate,'')
					WHERE T1.AccountID IS NULL
				
-- Account system fields update
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					WHERE AccountID IN (SELECT TMP1.AccountID FROM TempAccountLegalNameUpdated TMP1
										UNION
										SELECT TMP2.AccountID FROM TempAccountBusinessNameUpdated TMP2
										UNION	
										SELECT TMP3.AccountID FROM TempAccountEINUpdated TMP3
										UNION
										SELECT TMP4.AccountID FROM TempAccountSSNUpdated TMP4
										UNION
										SELECT TMP5.AccountID FROM TempAccountPINUpdated TMP5
										UNION
										SELECT TMP6.AccountID FROM TempAccountProvLocTypCodUpdated TMP6
										UNION
										SELECT TMP7.AccountID FROM TempAccountUpdated TMP7
										UNION
										SELECT TMP8.AccountID FROM TempAccountNextReEnrollmentDateUpdated TMP8)

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Legal Name' AS GroupName,'UPD' AS Action,'Provider legal name' AS Attribute,OldLegalName AS OldValue,NewLegalName AS NewValue,0 FROM TempAccountLegalNameUpdated
					UNION ALL
					SELECT @MGAccountID,'Business Name' AS GroupName,'UPD' AS Action,'Business Name' AS Attribute,OldBusinessName AS OldValue,NewBusinessName AS NewValue,0 FROM TempAccountBusinessNameUpdated
					UNION ALL
					SELECT @MGAccountID,'EIN' AS GroupName,'UPD' AS Action,'EIN' AS Attribute,OldEIN AS OldValue,NewEIN AS NewValue,0 FROM TempAccountEINUpdated
					UNION ALL
					SELECT @MGAccountID,'SSN' AS GroupName,'UPD' AS Action,'SSN' AS Attribute,OldSSN AS OldValue,NewSSN AS NewValue,0 FROM TempAccountSSNUpdated
					UNION ALL
					SELECT @MGAccountID,'PIN' AS GroupName,'UPD' AS Action,'PIN' AS Attribute,OldPIN AS OldValue,NewPIN AS NewValue,0 FROM TempAccountPINUpdated
					UNION ALL
					SELECT @MGAccountID,'Provider Location Type Code' AS GroupName,'UPD' AS Action,'Provider Location Type Code' AS Attribute,OldProvLocTypeCd AS OldValue,NewProvLocTypeCd AS NewValue,0 FROM TempAccountProvLocTypCodUpdated
					-- UNION ALL
					
				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Next Re-enrollment Date' AS GroupName,'UPD' AS Action,'Next Re-enrollment Date' AS Attribute,OldNextReEnrollmentDate AS OldValue,NewNextReEnrollmentDate AS NewValue,0 FROM TempAccountNextReEnrollmentDateUpdated
				
-- Whenever Account status will change in Account table, Its status will become deactivate in AccountStatus table and new entry will be inserted with the Current Status
				SELECT	T.AccountID,T.OldStatusAcc,T.NewStatusAcc-- ,NewStatusBeginDate -- Don't compare this field as it is written to insert in Account Status table
					INTO TempAccountStatusUpdate
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID		= T1.AccountID		AND
						T.OldStatusAcc	= T1.NewStatusAcc
					WHERE T1.AccountID	IS NULL
				
				SELECT @lCount = COUNT(1)
					FROM TempAccountStatusUpdate
				
				IF @lCount > 1
				
				BEGIN
				
					UPDATE KYPEnrollment.pADM_AccountStatus
						SET EffectiveEndDate	= @MGStatusBeginDate - 1,
							CurrentRecordFlag	= 0
						WHERE AccountStatusID IN (SELECT MAX(TMP.AccountStatusID)
													FROM KYPEnrollment.pADM_AccountStatus TMP
													WHERE AccountID			= @MGAccountID AND -- IN (SELECT AccountID FROM TempAccountStatusUpdate) 
														  CurrentRecordFlag = 1
													GROUP BY AccountID)

					INSERT INTO KYPEnrollment.pADM_AccountStatus
					(
						AccountID,
						StatusType,
						StatusValue,
						EffectiveBeginDate,
						LastAction,
						LastActionDate,
						LastActionApprovedBy,
						CurrentRecordFlag
					)
					SELECT	@MGAccountID,
							'Enrollment',
							@MGStatusAcc,
							@MGStatusBeginDate,
							'C',
							GETDATE(),
							'System',
							1

					INSERT INTO KYPEnrollment.MixedGroupHistory
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'Status Code' AS Attribute,OldStatusAcc AS OldValue,@MGStatusAcc AS NewValue,0 FROM @TempAccountLog
						UNION ALL
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldStatusBeginDate,105) AS OldValue,CONVERT(VARCHAR(32),@MGStatusBeginDate,105) AS NewValue,0 FROM @TempAccountLog
						UNION ALL
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'End Date' AS Attribute,CONVERT(VARCHAR(32),@MGStatusBeginDate-1,105) AS OldValue,'-' AS NewValue,0 FROM @TempAccountLog

				END

				UPDATE [KYPEnrollment].[pAccount_PDM_Address]
					SET AddressLine1					= ILV.AddressLine1,
						AddressLine2					= ILV.AddressLine2,
						County							= ILV.County,
						City							= ILV.City,
						Zip								= ILV.Zip,
						ZipPlus4						= ILV.ZipPlus4,
						[State]							= ILV.[State]						
       				OUTPUT	INSERTED.AddressID,INSERTED.AddressType,DELETED.AddressLine1 AS OldAddressLine1,INSERTED.AddressLine1 AS NewAddressLine1,
       						DELETED.AddressLine2 AS OldAddressLine2,INSERTED.AddressLine2 AS NewAddressLine2,DELETED.County AS OldCounty,
       						INSERTED.County AS NewCounty,DELETED.City AS OldCity,INSERTED.City AS NewCity,
       						DELETED.ZipPlus4 AS OldZip,INSERTED.ZipPlus4 AS NewZip,DELETED.[State] AS OldState,INSERTED.[State] AS NewState
						INTO @TempAddressLog
					FROM KYPEnrollment.pAccount_PDM_Address ADRS
       				JOIN (SELECT AddressID,SG.Phone1,SG.AddressLine1,SG.AddressLine2,SG.County,SG.City,SG.Zip,SG.ZipPlus4,SG.[State]
       						FROM(SELECT  @MGPartyID AS MGPartyID,PartyID AS SGPartyID,Phone1,ADR.AddressLine1,ADR.AddressLine2,ADR.County,ADR.City,ADR.Zip,
       									 ADR.ZipPlus4,ADR.[State],LOC.[Type]
       								FROM KYPEnrollment.pAccount_PDM_Address ADR
									JOIN KYPEnrollment.pAccount_PDM_Location LOC
									ON ADR.AddressID	= LOC.AddressID
									WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
														FROM @SubGroupAccountIDsAndPartyID TMP)) SG
							JOIN KYPEnrollment.pAccount_PDM_Location MG
							ON SG.MGPartyID	= MG.PartyID AND
							   SG.[Type]	= MG.[Type]) ILV
					ON ADRS.AddressID	= ILV.AddressID

				SELECT	T.AddressID,T.AddressType,T.OldAddressLine1,T.NewAddressLine1,T.OldAddressLine2,T.NewAddressLine2,T.OldCounty,
						T.NewCounty,T.OldCity,T.NewCity,T.OldZip,T.NewZip,T.OldState,T.NewState
					INTO TempAddressUpdated
					FROM @TempAddressLog T
					LEFT JOIN @TempAddressLog T1
					ON	T.AddressID						= T1.AddressID					AND
						ISNULL(T.OldAddressLine1,'')	= ISNULL(T1.NewAddressLine1,'')	AND
						ISNULL(T.OldAddressLine2,'')	= ISNULL(T1.NewAddressLine2,'')	AND
						ISNULL(T.OldCounty,'')			= ISNULL(T1.NewCounty,'')		AND
						ISNULL(T.OldCity,'')			= ISNULL(T1.NewCity,'')			AND
						ISNULL(T.OldZip,'')				= ISNULL(T1.NewZip,'')			AND
						ISNULL(T.OldState,'')			= ISNULL(T1.NewState,'')
					WHERE T1.AddressID IS NULL
-- Account system fields update				
				UPDATE [KYPEnrollment].[pAccount_PDM_Address]
					SET [LastAction]					= 'U',
						[LastActionDate]				= GETDATE(),
						[LastActionUserID]				= 'system',
       					[LastActionApprovedByUsedID]	= 'system'
       				WHERE AddressID IN (SELECT TMP.AddressID
       										FROM TempAddressUpdated TMP)
       										
-- If the Address Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON ACC.PartyID		= LOC.PartyID
					JOIN KYPEnrollment.pAccount_PDM_Address ADR
					ON LOC.AddressID	= ADR.AddressID
					JOIN TempAddressUpdated Temp
					ON ADR.AddressID	= Temp.AddressID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'AddressLine1' AS Attribute,OldAddressLine1 AS OldValue,NewAddressLine1 AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'AddressLine2' AS Attribute,OldAddressLine2 AS OldValue,NewAddressLine2 AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'County' AS Attribute,OldCounty AS OldValue,NewCounty AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'City' AS Attribute,OldCity AS OldValue,NewCity AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'State' AS Attribute,OldState AS OldValue,NewState AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'Zip' AS Attribute,OldZip AS OldValue,NewZip AS NewValue,0 FROM TempAddressUpdated					
				
				UPDATE KYPEnrollment.pAccount_PDM_Location
					SET Phone1	= ILV.Phone1						
					OUTPUT INSERTED.LocationID,DELETED.Phone1 AS OldPhone1,INSERTED.Phone1 AS NewPhone1
						INTO @TempLocationLog
					FROM KYPEnrollment.pAccount_PDM_Location LOC					
					JOIN (SELECT @MGPartyID AS MGPartyID,Phone1,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,[Type]
							FROM KYPEnrollment.pAccount_PDM_Location
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON	LOC.PartyID	= ILV.MGPartyID	AND
						LOC.[Type]	= ILV.[Type]				 
				
				SELECT	T.LocationID,T.OldPhone1,T.NewPhone1
					INTO TempLocationUpdated
					FROM @TempLocationLog T
					LEFT JOIN @TempLocationLog T1
					ON	T.LocationID			= T1.LocationID	AND
						ISNULL(T.OldPhone1,'')	= ISNULL(T1.NewPhone1,'')
					WHERE T1.LocationID IS NULL
				
				UPDATE KYPEnrollment.pAccount_PDM_Location
					SET LastAction 				= 'U',
						LastActionDate			= GETDATE(),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE LocationID IN(SELECT TMP.LocationID
											FROM TempLocationUpdated TMP)
				
				-- If the Location Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON ACC.PartyID		= LOC.PartyID
					JOIN TempLocationUpdated Temp
					ON LOC.LocationID	= Temp.LocationID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Telephone number' AS GroupName,'UPD' AS Action,'Telephone number' AS Attribute,OldPhone1 AS OldValue,NewPhone1 AS NewValue,0 FROM TempLocationUpdated
					
				UPDATE [KYPEnrollment].[pAccount_PDM_Organization]
					SET [TIN]					= ILV.TIN,
						[LegalName]				= ILV.LegalName,
						[DBAName1]				= ILV.DBAName1,
						[BusinessName]			= ILV.BusinessName,
						[Phone1]				= ILV.Phone1,
						[EIN]					= ILV.EIN						
					OUTPUT	INSERTED.OrgID,DELETED.TIN AS OldTIN,INSERTED.TIN AS NewTIN,
							DELETED.LegalName AS OldLegalName,INSERTED.LegalName AS NewLegalName,
							DELETED.DBAName1 AS OldDBAName1,INSERTED.DBAName1 AS NewDBAName1,
							DELETED.BusinessName AS OldBusinessName,INSERTED.BusinessName AS NewBusinessName,
							DELETED.Phone1 AS OldPhone1,INSERTED.Phone1 AS NewPhone1,
							DELETED.EIN AS OldEIN,INSERTED.EIN AS NewEIN
						INTO @TempOrganizationLog
					FROM KYPEnrollment.pAccount_PDM_Organization ORG
					JOIN (SELECT @MGPartyID AS MGPartyID,TIN,LegalName,DBAName1,BusinessName,Phone1,ModifiedBy,DateModified,EIN,LastAction,
								 LastActorUserID,LastActionApprovedBy
							FROM KYPEnrollment.pAccount_PDM_Organization
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ORG.PartyID	= ILV.MGPartyID							
				
				SELECT	T.OrgID,T.OldPhone1,T.NewPhone1
					INTO TempOrganizationUpdated
					FROM @TempOrganizationLog T
					LEFT JOIN @TempOrganizationLog T1
					ON	T.OrgID						= T1.OrgID	AND
						ISNULL(T.OldTIN,'')			= ISNULL(T1.NewTIN,'') AND
						ISNULL(T.OldLegalName,'')	= ISNULL(T1.NewLegalName,'') AND
						ISNULL(T.OldBusinessName,'')= ISNULL(T1.NewBusinessName,'') AND
						ISNULL(T.OldPhone1,'')		= ISNULL(T1.NewPhone1,'') AND
						ISNULL(T.OldEIN,'')			= ISNULL(T1.NewEIN,'')			
					WHERE T1.OrgID IS NULL
				
				UPDATE KYPEnrollment.pAccount_PDM_Organization
					SET [LastActionDate]		= CONVERT(DATE,GETDATE(),112),
						[LastAction]			= 'U',
						[DateModified]			= CONVERT(DATE,GETDATE(),112),
						[ModifiedBy]			= 1,
						[LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system'
					WHERE OrgID IN(SELECT TMP.OrgID
									FROM TempOrganizationUpdated TMP)

-- If the Organization Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Organization ORG
					ON ACC.PartyID	= ORG.PartyID
					JOIN TempOrganizationUpdated Temp
					ON ORG.OrgID	= Temp.OrgID

				INSERT INTO @MG_CLIA_AuxTable 
				(
					[CliaNumber] ,
					[MinCliaNumber],
					[MaxCliaNumber]
				)
				SELECT CliaNumber,MIN(CliaNumber) AS MinCliaNumber,MAX(CliaNumber) AS MaxCliaNumber
					FROM  [KYPEnrollment].[pAccount_PDM_Clia]
					WHERE PartyID IN (SELECT TMP.SubGroupPartyID
										FROM @SubGroupAccountIDsAndPartyID TMP)
				GROUP BY CliaNumber
				ORDER BY CliaNumber DESC
		
				IF EXISTS (SELECT 1
								FROM @MG_CLIA_AuxTable
								WHERE CliaNumber IS NOT NULL)
				BEGIN
				
					SELECT @MGCliaNumber = MinCliaNumber
						FROM @MG_CLIA_AuxTable
						WHERE -- CliaNumber IS NOT NULL
						ISNULL(CliaNumber,'') != ''
				
				END

				IF NOT EXISTS (SELECT 1
									FROM @MG_CLIA_AuxTable
									WHERE CliaNumber IS NOT NULL)
				BEGIN
				
					SELECT @MGCliaNumber = NULL
				
				END

				UPDATE [KYPEnrollment].[pAccount_PDM_Clia]
					SET [CertificateType]	= ILV.CertificateType,
						[CliaNumber]		= @MGCliaNumber
					OUTPUT	INSERTED.CliaID,DELETED.CertificateType AS OldCertificateType,INSERTED.CertificateType AS NewCertificateType,
							DELETED.CliaNumber AS OldCliaNumber,INSERTED.CliaNumber AS NewCliaNumber
						INTO @TempCLIALog
					FROM KYPEnrollment.pAccount_PDM_Clia CLIA
					JOIN (SELECT @MGPartyID AS MGPartyID,CertificateType
							FROM KYPEnrollment.pAccount_PDM_Clia
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON CLIA.PartyID	= ILV.MGPartyID
				
				SELECT T.CliaID,T.OldCertificateType,T.NewCertificateType,T.OldCliaNumber,T.NewCliaNumber
					INTO TempCLIAUpdated
					FROM @TempCLIALog T
					LEFT JOIN @TempCLIALog T1
					ON	T.CliaID						= T1.CliaID				AND
						ISNULL(T.OldCertificateType,'')	= ISNULL(T1.NewCertificateType,'') AND
						ISNULL(T.OldCliaNumber,'')		= ISNULL(T1.NewCliaNumber,'')
					WHERE T1.CliaID IS NULL
				
				UPDATE [KYPEnrollment].[pAccount_PDM_Clia]
					SET LastAction 					= 'U',
						LastActionDate 				= CONVERT(DATE,GETDATE(),112),
						LastActorUserID 			= 'system',
						LastActionReason			= NULL,
						LastActionComments			= NULL,
						LastActionApprovedByUsedID	= 'system'
					WHERE CliaID IN (SELECT TMP.CliaID
										FROM TempCLIAUpdated TMP)					

-- If the CLIA Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Clia CLIA
					ON ACC.PartyID	= CLIA.PartyID
					JOIN TempCLIAUpdated Temp
					ON CLIA.CliaID	= Temp.CliaID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'CLIA' AS GroupName,'UPD' AS Action,'CLIA Number' AS Attribute,OldCliaNumber AS OldValue,NewCliaNumber AS NewValue,0 FROM TempCLIAUpdated
					UNION ALL
					SELECT @MGAccountID,'CLIA' AS GroupName,'UPD' AS Action,'Type Cert' AS Attribute,OldCertificateType AS OldValue,NewCertificateType AS NewValue,0 FROM TempCLIAUpdated

				UPDATE [KYPEnrollment].[pAccount_Name]
					SET Name = ILV.Name
					FROM KYPEnrollment.pAccount_Name ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,Name
							FROM KYPEnrollment.pAccount_Name
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID

				UPDATE [KYPEnrollment].[pAccount_Owner]
					SET [LegalName]			= ILV.LegalName,
						[BusinessName]		= ILV.BusinessName,
						[DBAName]			= ILV.DBAName,
						[TIN]				= ILV.TIN,
						[TINH]				= ILV.TINH,
						[SSN]				= ILV.SSN,
						[SSNH]				= ILV.SSNH,
						EffectiveBeingDate	= ILV.EffectiveBeingDate,
						EffectiveEndDate	= ILV.EffectiveEndDate
					OUTPUT	INSERTED.OwnerID,ILV.OwnerNo,DELETED.EffectiveBeingDate AS OldEffectiveBeingDate,INSERTED.EffectiveBeingDate AS NewEffectiveBeingDate,
							DELETED.EffectiveEndDate AS OldEffectiveEndDate,INSERTED.EffectiveEndDate AS NewEffectiveEndDate,
							DELETED.LegalName AS OldLegalName,INSERTED.LegalName AS NewLegalName,
							DELETED.BusinessName AS OldBusinessName,INSERTED.BusinessName AS NewBusinessName,
							DELETED.DBAName AS OldDBAName,INSERTED.DBAName AS NewDBAName,
							DELETED.TIN AS OldTIN,INSERTED.TIN AS NewTIN,DELETED.TINH AS OldTINH,INSERTED.TINH AS NewTINH,
							DELETED.SSN AS OldSSN,INSERTED.SSN AS NewSSN,DELETED.SSNH AS OldSSNH,INSERTED.SSNH AS NewSSNH
						INTO @TempOwnerLog
					FROM KYPEnrollment.pAccount_Owner ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,OwnerNo,LegalName,BusinessName,DBAName,TIN,TINH,LastAction,LastActorUserID,SSN,SSNH,
								 EffectiveBeingDate,EffectiveEndDate
							FROM KYPEnrollment.pAccount_Owner
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID  
				
				SELECT T.OwnerID,T.OwnerNo,T.OldEffectiveBeingDate,T.NewEffectiveBeingDate,T.OldEffectiveEndDate,T.NewEffectiveEndDate
					INTO TempOwnerUpdated
					FROM @TempOwnerLog T
					LEFT JOIN @TempOwnerLog T1
					ON	T.OwnerID = T1.OwnerID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveBeingDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveBeingDate,105),'') AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveEndDate,105),'')
					WHERE T1.OwnerID IS NULL
				
				SELECT T.OwnerID,T.OwnerNo,T.OldEffectiveBeingDate,T.NewEffectiveBeingDate,T.OldEffectiveEndDate,T.NewEffectiveEndDate
					INTO TempAccountOwnerUpdated
					FROM @TempOwnerLog T
					LEFT JOIN @TempOwnerLog T1
					ON	T.OwnerID = T1.OwnerID AND
						ISNULL(T.OldLegalName,'')		= ISNULL(T1.NewLegalName,'')	AND
						ISNULL(T.OldBusinessName,'')	= ISNULL(T1.NewBusinessName,'') AND
						ISNULL(T.OldDBAName,'')			= ISNULL(T1.NewDBAName,'')		AND
						ISNULL(T.OldTIN,'')				= ISNULL(T1.NewTIN,'')			AND
						ISNULL(T.OldTINH,'')			= ISNULL(T1.NewTINH,'')			AND
						ISNULL(T.OldSSN,'')				= ISNULL(T1.NewSSN,'')			AND
						ISNULL(T.OldSSNH,'')			= ISNULL(T1.NewSSNH,'')			AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveBeingDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveBeingDate,105),'') AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveEndDate,105),'')
					WHERE T1.OwnerID IS NULL

				UPDATE [KYPEnrollment].[pAccount_Owner]
					SET [LastAction]		= 'U',
						[LastActionDate]	= CONVERT(DATE,GETDATE(),112),
						[LastActorUserID]	= 'system'
					WHERE OwnerID IN(SELECT TMP.OwnerID
										FROM TempAccountOwnerUpdated TMP)
				
-- If the Owner Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_Owner OWN
					ON ACC.AccountID	= OWN.AccountID
					JOIN TempAccountOwnerUpdated Temp
					ON OWN.OwnerID		= Temp.OwnerID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'Owner No' AS Attribute,OwnerNo AS OldValue,OwnerNo AS NewValue,0 FROM TempOwnerUpdated
					UNION ALL
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldEffectiveBeingDate,105) AS OldValue,CONVERT(VARCHAR(32),NewEffectiveBeingDate,105) AS NewValue,0 FROM TempOwnerUpdated
					UNION ALL
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'End Date' AS Attribute,CONVERT(VARCHAR(32),OldEffectiveEndDate,105) AS OldValue,CONVERT(VARCHAR(32),NewEffectiveEndDate,105) AS NewValue,0 FROM TempOwnerUpdated

				UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
					SET BillingStatus			= @MGBillingStatus,
						BillingBeginDate		= CASE WHEN @MGBillingStatus IS NULL THEN
														NULL
													ELSE
														@MGStatusBeginDate
													END,
						OutOfStateInd			= @MGOutOfStateInd,
						CHDPCode				= @MGCHDPCode,
						ReEnrolInd				= @MGReEnrolInd,
						ReEnrolDate				= @MGReEnrolDate,
						ProvisionalCode			= @MGProvisionalCode,
						ProvisionalCodeDate		= @MGProvisionalCodeDate,
						LabStatusCode			= @MGLabStatusCode,
						LabStatusCodeDate		= @MGLabStatusCodeDate
					OUTPUT	INSERTED.AccountInternalUseID,DELETED.BillingStatus AS OldBillingStatus,INSERTED.BillingStatus AS NewBillingStatus,
							DELETED.BillingBeginDate AS OldBillingBeginDate,INSERTED.BillingBeginDate AS NewBillingBeginDate,
							DELETED.OutOfStateInd AS OldOutOfStateInd,INSERTED.OutOfStateInd AS NewOutOfStateInd,
							DELETED.CHDPCode AS OldCHDPCode,INSERTED.CHDPCode AS NewCHDPCode,
							DELETED.ReEnrolInd AS OldReEnrolInd,INSERTED.ReEnrolInd AS NewReEnrolInd,
							DELETED.ReEnrolDate AS OldReEnrolDate,INSERTED.ReEnrolDate AS NewReEnrolDate,
							DELETED.ProvisionalCode AS OldProvisionalCode,INSERTED.ProvisionalCode AS NewProvisionalCode,
							DELETED.ProvisionalCodeDate AS OldProvisionalCodeDate,INSERTED.ProvisionalCodeDate AS NewProvisionalCodeDate,
							DELETED.LabStatusCode AS OldLabStatusCode,INSERTED.LabStatusCode AS NewLabStatusCode,
							DELETED.LabStatusCodeDate AS OldLabStatusCodeDate,INSERTED.LabStatusCodeDate AS NewLabStatusCodeDate
						INTO @TempAccountInternalUseLog
					WHERE AccountID = @MGAccountID

				SELECT T.AccountInternalUseID,T.OldBillingStatus,T.NewBillingStatus,T.OldBillingBeginDate,T.NewBillingBeginDate
					INTO TempAccountInternalUseUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										= T1.AccountInternalUseID			AND
						ISNULL(T.OldBillingStatus,'')								= ISNULL(T1.NewBillingStatus,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldBillingBeginDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewBillingBeginDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL
				
				SELECT T.AccountInternalUseID,T.OldOutOfStateInd,T.NewOutOfStateInd
					INTO TempAccountOutOfStateIndicatorUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID			= T1.AccountInternalUseID		AND
						ISNULL(T.OldOutOfStateInd,'')	= ISNULL(T1.NewOutOfStateInd,'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldCHDPCode,T.NewCHDPCode
					INTO TempAccountCHDPCodeUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID		= T1.AccountInternalUseID	AND
						ISNULL(T.OldCHDPCode,'')	= ISNULL(T1.NewCHDPCode,'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldReEnrolInd,T.NewReEnrolInd,T.OldReEnrolDate,T.NewReEnrolDate
					INTO TempAccountReenrollmentIndicatorDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID									= T1.AccountInternalUseID		AND
						ISNULL(T.OldReEnrolInd,'')								= ISNULL(T1.NewReEnrolInd,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldReEnrolDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewReEnrolDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldProvisionalCode,T.NewProvisionalCode,T.OldProvisionalCodeDate,T.NewProvisionalCodeDate
					INTO TempAccountProvisionalCodeDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										 = T1.AccountInternalUseID			AND
						ISNULL(T.OldProvisionalCode,'')								 = ISNULL(T1.NewProvisionalCode,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldProvisionalCodeDate,105),'') = ISNULL(CONVERT(VARCHAR(32),T1.NewProvisionalCodeDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldLabStatusCode,T.NewLabStatusCode,T.OldLabStatusCodeDate,T.NewLabStatusCodeDate
					INTO TempAccountLabStatusCodeDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										= T1.AccountInternalUseID			AND
						ISNULL(T.OldLabStatusCode,'')								= ISNULL(T1.NewLabStatusCode,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldLabStatusCodeDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewLabStatusCodeDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
					SET LastAction				= 'U',
						LastActionDate			= CONVERT(DATE,GETDATE(),112),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE AccountInternalUseID	IN (SELECT TMP1.AccountInternalUseID FROM TempAccountInternalUseUpdated TMP1
													UNION
													SELECT TMP2.AccountInternalUseID FROM TempAccountOutOfStateIndicatorUpdated TMP2
													UNION
													SELECT TMP3.AccountInternalUseID FROM TempAccountCHDPCodeUpdated TMP3
													UNION
													SELECT TMP4.AccountInternalUseID FROM TempAccountReenrollmentIndicatorDateUpdated TMP4
													UNION
													SELECT TMP5.AccountInternalUseID FROM TempAccountProvisionalCodeDateUpdated TMP5
													UNION
													SELECT TMP6.AccountInternalUseID FROM TempAccountLabStatusCodeDateUpdated TMP6)

-- If the AccountInternalUse Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.EDM_AccountInternalUse AIU
					ON ACC.AccountID	= AIU.AccountID
					WHERE AIU.AccountInternalUseID IN  (SELECT TMP1.AccountInternalUseID FROM TempAccountInternalUseUpdated TMP1
														UNION
														SELECT TMP2.AccountInternalUseID FROM TempAccountOutOfStateIndicatorUpdated TMP2
														UNION
														SELECT TMP3.AccountInternalUseID FROM TempAccountCHDPCodeUpdated TMP3
														UNION
														SELECT TMP4.AccountInternalUseID FROM TempAccountReenrollmentIndicatorDateUpdated TMP4
														UNION
														SELECT TMP5.AccountInternalUseID FROM TempAccountProvisionalCodeDateUpdated TMP5
														UNION
														SELECT TMP6.AccountInternalUseID FROM TempAccountLabStatusCodeDateUpdated TMP6)
					/*JOIN TempAccountInternalUseUpdated Temp
					ON AIU.AccountInternalUseID	= Temp.AccountInternalUseID*/

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Billing Status' AS GroupName,'UPD' AS Action,'Status Code' AS Attribute,OldBillingStatus AS OldValue,NewBillingStatus AS NewValue,0 FROM TempAccountInternalUseUpdated
					UNION ALL
					SELECT @MGAccountID,'Billing Status' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldBillingBeginDate,105) AS OldValue,CONVERT(VARCHAR(32),NewBillingBeginDate,105) AS NewValue,0 FROM TempAccountInternalUseUpdated
					UNION ALL
					SELECT @MGAccountID,'Out of State Indicator' AS GroupName,'UPD' AS Action,'Out of State Indicator' AS Attribute,OldOutOfStateInd AS OldValue,NewOutOfStateInd AS NewValue,0 FROM TempAccountOutOfStateIndicatorUpdated
					UNION ALL
					SELECT @MGAccountID,'CHDP' AS GroupName,'UPD' AS Action,'CHDP Code' AS Attribute,OldCHDPCode AS OldValue,NewCHDPCode AS NewValue,0 FROM TempAccountCHDPCodeUpdated
					UNION ALL
					SELECT @MGAccountID,'ReEnrollment' AS GroupName,'UPD' AS Action,'Reenrollment Indicator' AS Attribute,OldReEnrolInd AS OldValue,NewReEnrolInd AS NewValue,0 FROM TempAccountReenrollmentIndicatorDateUpdated
					UNION ALL
					SELECT @MGAccountID,'ReEnrollment' AS GroupName,'UPD' AS Action,'Reenrollment Date' AS Attribute,CONVERT(VARCHAR(32),OldReEnrolDate,105) AS OldValue,CONVERT(VARCHAR(32),NewReEnrolDate,105) AS NewValue,0 FROM TempAccountReenrollmentIndicatorDateUpdated
					UNION ALL
					SELECT @MGAccountID,'Provisional' AS GroupName,'UPD' AS Action,'Provisional Code' AS Attribute,OldProvisionalCode AS OldValue,NewProvisionalCode AS NewValue,0 FROM TempAccountProvisionalCodeDateUpdated
					UNION ALL
					SELECT @MGAccountID,'Provisional' AS GroupName,'UPD' AS Action,'Provisional Date' AS Attribute,CONVERT(VARCHAR(32),OldProvisionalCodeDate,105) AS OldValue,CONVERT(VARCHAR(32),NewProvisionalCodeDate,105) AS NewValue,0 FROM TempAccountProvisionalCodeDateUpdated
					UNION
					SELECT @MGAccountID,'Lab Status' AS GroupName,'UPD' AS Action,'Lab Status Code' AS Attribute,OldLabStatusCode AS OldValue,NewLabStatusCode AS NewValue,0 FROM TempAccountLabStatusCodeDateUpdated
					UNION
					SELECT @MGAccountID,'Lab Status' AS GroupName,'UPD' AS Action,'Lab Status Code Date' AS Attribute,CONVERT(VARCHAR(32),OldLabStatusCodeDate,105) AS OldValue,CONVERT(VARCHAR(32),NewLabStatusCodeDate,105) AS NewValue,0 FROM TempAccountLabStatusCodeDateUpdated

				UPDATE [KYPEnrollment].[pAccount_PDM_PaymentDetail]
					SET EFT_Indicator = ILV.EFT_Indicator
					OUTPUT INSERTED.PaymentDetailID,DELETED.EFT_Indicator AS OldEFTIndicator,INSERTED.EFT_Indicator AS NewEFTIndicator
						INTO @TempPaymentDetailLog
					FROM KYPEnrollment.pAccount_PDM_PaymentDetail PD
					JOIN (SELECT @MGPartyID AS MGPartyID,EFT_Indicator
							FROM KYPEnrollment.pAccount_PDM_PaymentDetail
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON PD.PartyID	= ILV.MGPartyID

				SELECT	T.PaymentDetailID,T.OldEFTIndicator,T.NewEFTIndicator
					INTO TempPaymentDetailUpdated
					FROM @TempPaymentDetailLog T
					LEFT JOIN @TempPaymentDetailLog T1
					ON	T.PaymentDetailID				= T1.PaymentDetailID			AND
						ISNULL(T.OldEFTIndicator,'')	= ISNULL(T1.NewEFTIndicator,'')
					WHERE T1.PaymentDetailID IS NULL
				
				UPDATE [KYPEnrollment].[pAccount_PDM_PaymentDetail]
					SET LastAction				= 'U',
						LastActionDate			= CONVERT(DATE,GETDATE(),112),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE PaymentDetailID IN(SELECT TMP.PaymentDetailID
												FROM TempPaymentDetailUpdated TMP)

-- If the Payment Detail Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_PaymentDetail PD
					ON ACC.PartyID			= PD.PartyID
					JOIN TempPaymentDetailUpdated Temp
					ON PD.PaymentDetailID	= Temp.PaymentDetailID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'EFT Indicator' AS GroupName,'UPD' AS Action,'EFT Indicator' AS Attribute,OldEFTIndicator AS OldValue,NewEFTIndicator AS NewValue,0 FROM TempPaymentDetailUpdated

				UPDATE [KYPEnrollment].[AccountSearch]
					SET [EnrollmentStatus]		= @MGStatusAcc,
						[BillingStatus]			= @MGBillingStatus,
						[ServiceCity]			= ILV.ServiceCity,
						[ServiceState]			= ILV.ServiceState,
						[ServiceZip]			= ILV.ServiceZip,
						[PayCity]				= ILV.PayCity,
						[PayState]				= ILV.[PayState],
						[PayZip]				= ILV.[PayZip],
						[AccountName]			= ILV.[AccountName],
						[SSN]					= ILV.[SSN],
						[TAXID]					= ILV.[TAXID],
						[StatusDate]			= @MGStatusBeginDate,
						[ServiceAddressLine1]	= ILV.[ServiceAddressLine1],
						[ServiceAddressLine2]	= ILV.[ServiceAddressLine2],
						[PayAddressLine1]		= ILV.[PayAddressLine1],
						[PayAddressLine2]		= ILV.[PayAddressLine2],
						[StatusBeginDate]		= @MGStatusBeginDate,
						MailCity				= ILV.MailCity,-- KEN-18021
						MailState				= ILV.MailState,
						MailZip					= ILV.MailZip,
						MailAddressLine1		= ILV.MailAddressLine1,
						MailAddressLine2		= ILV.MailAddressLine2,
						EnrolledOn				= @MGStatusBeginDate,
						ReEnrollmentDate		= @MGReEnrolDate
					FROM KYPEnrollment.AccountSearch ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,BillingStatus,ServiceCity,ServiceState,ServiceZip,PayCity,[PayState],[PayZip],
								 [AccountName],[SSN],[TAXID],[ServiceAddressLine1],[ServiceAddressLine2],PayAddressLine1,PayAddressLine2,
								 MailCity,MailState,MailZip,MailAddressLine1,MailAddressLine2
							FROM KYPEnrollment.AccountSearch
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID

/* Below DELETE statement will delete the rendering from S file. Take combination of each AffiliatedAccountID and AffiliationStartDate 
	for all the Rendering affiliations from all the Sub Groups which don’t have even a Single Active records (which means not even a single 
	IsDeleted = 0, All should be IsDeleted = 1). Take top record of rendering affiliation from each combination and update IsDeleted flag as 
	1 in Mixed Group Rendering affiliations(If IsDeleted flag was IsDeleted = 0 earlier)*/
				UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET LastAction			= 'D',
						IsDeleted			= 1,
						CurrentRecordFlag	= B.CurrentRecordFlag,
						LastUpdatedBy		= 'M',
						LastActorUserID		= 'system',
						LastActionDate		= GETDATE()
					OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
							B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
							DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag														
						INTO @TempRenderingAffiliationDELforSfileLog
					FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
					JOIN (SELECT *
							FROM (SELECT RenderingAffiliationID,AffiliatedAccountID,AffiliationStartDate,CurrentRecordFlag,
										 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID,AffiliationStartDate ORDER BY CurrentRecordFlag DESC,AffiliationEndDate DESC) RowNumber
									FROM KYPEnrollment.pAccount_RenderingAffiliation RA			
									WHERE AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
															FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																	FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
															JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																	FROM KYPEnrollment.pADM_Account
																	WHERE	IsDeleted			= 0 AND
																			IsPastOwner			= 1 AND
																			ProviderTypeCode	!= 100) B -- All the SG of that MG
															ON	A.SubGroupNPI				= B.NPI AND
																A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
																A.SubGroupOwnerNo			= B.OwnerNo AND
																A.SubGroupProviderTypeCode	= B.ProviderTypeCode) AND
										   TypeAffiliation LIKE '%MIDLEVEL%') ILV -- AND
							WHERE NOT EXISTS (SELECT 1
												FROM KYPEnrollment.pAccount_RenderingAffiliation RAF
												WHERE ILV.AffiliatedAccountID = RAF.AffiliatedAccountID AND
													  ISNULL(ILV.AffiliationStartDate,'') = ISNULL(RAF.AffiliationStartDate,'') AND
													  AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
																	FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																			FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
																	JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																			FROM KYPEnrollment.pADM_Account
																			WHERE	IsDeleted			= 0 AND
																					IsPastOwner			= 1 AND
																					ProviderTypeCode	!= 100) B -- All the SG of that MG
																	ON	A.SubGroupNPI				= B.NPI AND
																		A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
																		A.SubGroupOwnerNo			= B.OwnerNo AND
																		A.SubGroupProviderTypeCode	= B.ProviderTypeCode)AND
													   TypeAffiliation LIKE '%MIDLEVEL%' AND
													   RAF.IsDeleted   = 0) AND
								  RowNumber = 1) B
					ON	A.AffiliatedAccountID										= B.AffiliatedAccountID AND
						ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')
					WHERE AccountID			= @MGAccountID AND
						  TypeAffiliation	LIKE '%MIDLEVEL%' AND
						  IsDeleted			= 0

				SELECT	T.RenderingAffiliationID,T.NewTypeAffiliation,T.AccountID,T.AffiliatedAccountID,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
						ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
						ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
					INTO TempRenderingAffiliationDELforSfile
					FROM @TempRenderingAffiliationDELforSfileLog T
					LEFT JOIN KYPEnrollment.pADM_Account ACC
					ON T.AccountID				= ACC.AccountID
					LEFT JOIN KYPEnrollment.pADM_Account ACC1
					ON T.AffiliatedAccountID	= ACC1.AccountID
					/*LEFT JOIN @TempRenderingAffiliationUPDandDELLog T1
					ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')
					WHERE T.OldCurrentRecordFlag	= 1 AND
						  T.NewCurrentRecordFlag	= 0 AND
						  (T.NewTypeAffiliation NOT LIKE '%MIDLEVEL%' OR
						  (T.NewTypeAffiliation LIKE '%MIDLEVEL%' AND (ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),''))))*/

/* Below DELETE statement will delete the rendering from Y file. Take combination of each AffiliatedAccountID
	for all the Rendering affiliations from all the Sub Groups which don’t have even a Single Active records (which means not even a single 
	IsDeleted = 0, All should be IsDeleted = 1). Take top record of rendering affiliation from each combination and update IsDeleted flag as 
	1 in Mixed Group Rendering affiliations(If IsDeleted flag was IsDeleted = 0 earlier)*/

				UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET LastAction			= 'D',
						IsDeleted			= 1,
						CurrentRecordFlag	= B.CurrentRecordFlag,
						LastUpdatedBy		= 'M',
						LastActorUserID		= 'system',
						LastActionDate		= GETDATE()
					OUTPUT	INSERTED.RenderingAffiliationID,@MGAccountID AS AccountID,B.AffiliatedAccountID,INSERTED.TypeAffiliation AS NewTypeAffiliation,
							B.AffiliationStartDate,DELETED.AffiliationEndDate AS OldAffiliationEndDate,INSERTED.AffiliationEndDate AS NewAffiliationEndDate,
							DELETED.CurrentRecordFlag AS OldCurrentRecordFlag,INSERTED.CurrentRecordFlag AS NewCurrentRecordFlag
						INTO @TempRenderingAffiliationDELforYfileLog
					FROM [KYPEnrollment].[pAccount_RenderingAffiliation] A
					JOIN (SELECT *
							FROM (SELECT RenderingAffiliationID,AffiliatedAccountID,AffiliationStartDate,CurrentRecordFlag,
										 ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID ORDER BY CurrentRecordFlag DESC,AffiliationEndDate DESC) RowNumber
									FROM KYPEnrollment.pAccount_RenderingAffiliation RA			
									WHERE AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
															FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																	FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
															JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																	FROM KYPEnrollment.pADM_Account
																	WHERE	IsDeleted			= 0 AND
																			IsPastOwner			= 1 AND
																			ProviderTypeCode	!= 100) B -- All the SG of that MG
															ON	A.SubGroupNPI				= B.NPI AND
																A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
																A.SubGroupOwnerNo			= B.OwnerNo AND
																A.SubGroupProviderTypeCode	= B.ProviderTypeCode) AND
										   TypeAffiliation NOT LIKE '%MIDLEVEL%') ILV -- AND
							WHERE NOT EXISTS (SELECT 1
												FROM KYPEnrollment.pAccount_RenderingAffiliation RAF
												WHERE ILV.AffiliatedAccountID = RAF.AffiliatedAccountID AND
													  -- ISNULL(ILV.AffiliationStartDate,'') = ISNULL(RAF.AffiliationStartDate,'') AND
													  AccountID IN(SELECT B.AccountID -- We have written this code because through Delta we will receive only those SG which came from CAMMIS but to impose the affiliation into MG we required all the SG for that MG.
																	FROM (SELECT SubGroupAccountID,SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo,SubGroupProviderTypeCode
																			FROM @SubGroupAccountIDsAndPartyID) A -- Subgroup which are coming through Delta
																	JOIN (SELECT AccountID,NPI,ServiceLocationNo,OwnerNo,ProviderTypeCode
																			FROM KYPEnrollment.pADM_Account
																			WHERE	IsDeleted			= 0 AND
																					IsPastOwner			= 1 AND
																					ProviderTypeCode	!= 100) B -- All the SG of that MG
																	ON	A.SubGroupNPI				= B.NPI AND
																		A.SubGroupServiceLocationNo = B.ServiceLocationNo AND
																		A.SubGroupOwnerNo			= B.OwnerNo AND
																		A.SubGroupProviderTypeCode	= B.ProviderTypeCode)AND
													   TypeAffiliation NOT LIKE '%MIDLEVEL%' AND
													   RAF.IsDeleted   = 0) AND
								  RowNumber = 1) B
					ON	A.AffiliatedAccountID										= B.AffiliatedAccountID/* AND
						ISNULL(CONVERT(VARCHAR(32),A.AffiliationStartDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),B.AffiliationStartDate,105),'')*/
					WHERE AccountID			= @MGAccountID AND
						  TypeAffiliation	NOT LIKE '%MIDLEVEL%' AND
						  IsDeleted			= 0

				SELECT	T.RenderingAffiliationID,T.NewTypeAffiliation,T.AccountID,T.AffiliatedAccountID,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
						ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
						ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
					INTO TempRenderingAffiliationDELforYfile
					FROM @TempRenderingAffiliationDELforYfileLog T
					LEFT JOIN KYPEnrollment.pADM_Account ACC
					ON T.AccountID				= ACC.AccountID
					LEFT JOIN KYPEnrollment.pADM_Account ACC1
					ON T.AffiliatedAccountID	= ACC1.AccountID
					/*LEFT JOIN @TempRenderingAffiliationUPDandDELLog T1
					ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')
					WHERE T.OldCurrentRecordFlag	= 1 AND
						  T.NewCurrentRecordFlag	= 0 AND
						  (T.NewTypeAffiliation NOT LIKE '%MIDLEVEL%' OR
						  (T.NewTypeAffiliation LIKE '%MIDLEVEL%' AND (ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),''))))*/

				INSERT INTO KYPEnrollment.MixedGroupHistory
				SELECT AccountID,'Y Billing - Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforYfile where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforYfile where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AccountID,'SNMP Billing - Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforSfile where NewTypeAffiliation LIKE '%MIDLEVEL%'
				UNION ALL
				SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDELforSfile where NewTypeAffiliation LIKE '%MIDLEVEL%'

/*
				SELECT	T.RenderingAffiliationID,T.NewTypeAffiliation,T.AccountID,T.AffiliatedAccountID,T.AffiliationStartDate,T.OldAffiliationEndDate,T.NewAffiliationEndDate,
						ACC.NPI AS AccountNPI,ACC.LegalName AS AccountLegalName,ACC.AccountNumber,ACC.ProviderTypeCode AS AccountProviderTypeCode,
						ACC1.NPI AS AffiliatedNPI,ACC1.LegalName AS AffiliatedLegalName,ACC1.AccountNumber AS AffiliatedAccountNumber,ACC1.ProviderTypeCode AS AffiliatedProviderTypeCode
					INTO TempRenderingAffiliationDEL
					FROM @TempRenderingAffiliationUPDandDELLog T
					LEFT JOIN KYPEnrollment.pADM_Account ACC
					ON T.AccountID				= ACC.AccountID
					LEFT JOIN KYPEnrollment.pADM_Account ACC1
					ON T.AffiliatedAccountID	= ACC1.AccountID
					LEFT JOIN @TempRenderingAffiliationUPDandDELLog T1
					ON	T.RenderingAffiliationID	= T1.RenderingAffiliationID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),'')
					WHERE T.OldCurrentRecordFlag	= 1 AND
						  T.NewCurrentRecordFlag	= 0 AND
						  (T.NewTypeAffiliation NOT LIKE '%MIDLEVEL%' OR
						  (T.NewTypeAffiliation LIKE '%MIDLEVEL%' AND (ISNULL(CONVERT(VARCHAR(32),T.OldAffiliationEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewAffiliationEndDate,105),''))))
-- Here we are not updating IsDeleted Flag at any point of time only one affiliation will be exist in MG level. Same affiliation we will make it active and later Inactive, same process will continue.
				UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET LastAction		= 'D',
						IsDeleted		= 1,
						LastUpdatedBy	= 'M',
						LastActorUserID	= 'system',
						LastActionDate	= GETDATE()
					WHERE RenderingAffiliationID IN (SELECT	RenderingAffiliationID
														FROM TempRenderingAffiliationDEL)

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT AccountID,'Y Billing - Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDEL where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
					UNION ALL
					SELECT AffiliatedAccountID,'Y Billing - Affiliated Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDEL where NewTypeAffiliation NOT LIKE '%MIDLEVEL%'
					UNION ALL
					SELECT AccountID,'SNMP Billing - Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AffiliatedNPI,'-') + '~' + ISNULL(AffiliatedAccountNumber,'-') + '~' + ISNULL(AffiliatedLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDEL where NewTypeAffiliation LIKE '%MIDLEVEL%'
					UNION ALL
					SELECT AffiliatedAccountID,'SNMP Billing - Affiliated Account' AS GroupName,'DEL' AS Action,'NPI' AS Attribute,ISNULL(AccountNPI,'-') + '~' + ISNULL(AccountNumber,'-') + '~' + ISNULL(AccountLegalName,'-') AS OldValue,'-' AS NewValue,1 FROM TempRenderingAffiliationDEL where NewTypeAffiliation LIKE '%MIDLEVEL%'
*/
				UPDATE [KYPEnrollment].[pAccount_BizProfile_Details]
					SET [AccountEnrollmentStatus] 	= @MGStatusAcc,
						[AccountBillingStatus] 		= @MGBillingStatus,
						[AccountLegalName] 			= ILV.AccountLegalName,
						[AccountSSN] 				= ILV.[AccountSSN],
						[AccountEIN] 				= ILV.[AccountEIN],
						[AccountAddressLine1] 		= ILV.[AccountAddressLine1],
						[AccountAddressLine2] 		= ILV.[AccountAddressLine2],
						[AccountAdrCity] 			= ILV.[AccountAdrCity],
						[AccountAdrState] 			= ILV.[AccountAdrState],
						[AccountAdrZip9] 			= ILV.[AccountAdrZip9],
						[AccountPhone] 				= ILV.[AccountPhone],
						[AccountPIN] 				= ILV.[AccountPIN],
						[EffectiveBeginDate] 		= @MGStatusBeginDate,
						[EffectiveEndDate] 			= @MGDeactivationDate,
						[PayAccountAddressLine1] 	= ILV.[PayAccountAddressLine1],
						[PayAccountAddressLine2] 	= ILV.[PayAccountAddressLine2],
						[PayAccountAdrCity] 		= ILV.[PayAccountAdrCity],
						[PayAccountAdrState] 		= ILV.[PayAccountAdrState],
						[PayAccountAdrZip9]  		= ILV.[PayAccountAdrZip9],
						[ProfileID]					= ILV.[ProfileID] -- Commented by Anshu on 13th April, 2017. When SubGroup Profile would change then its Mixed Group Profile also should get change if the Mixed Group Account is not accessed from Portal.
					OUTPUT	INSERTED.BizProfileDetailsID,
							DELETED.AccountEnrollmentStatus AS OldAccountEnrollmentStatus,INSERTED.AccountEnrollmentStatus AS NewAccountEnrollmentStatus,
							DELETED.AccountBillingStatus AS OldAccountBillingStatus,INSERTED.AccountBillingStatus AS NewAccountBillingStatus,
							DELETED.AccountLegalName AS OldAccountLegalName,INSERTED.AccountLegalName AS NewAccountLegalName,
							DELETED.AccountSSN AS OldAccountSSN,INSERTED.AccountSSN AS NewAccountSSN,
							DELETED.AccountEIN AS OldAccountEIN,INSERTED.AccountEIN AS NewAccountEIN,
							DELETED.AccountAddressLine1 AS OldAccountAddressLine1,INSERTED.AccountAddressLine1 AS NewAccountAddressLine1,
							DELETED.AccountAddressLine2 AS OldAccountAddressLine2,INSERTED.AccountAddressLine2 AS NewAccountAddressLine2,
							DELETED.AccountAdrCity AS OldAccountAdrCity,INSERTED.AccountAdrCity AS NewAccountAdrCity,
							DELETED.AccountAdrState AS OldAccountAdrState,INSERTED.AccountAdrState AS NewAccountAdrState,
							DELETED.AccountAdrZip9 AS OldAccountAdrZip9,INSERTED.AccountAdrZip9 AS NewAccountAdrZip9,
							DELETED.AccountPhone AS OldAccountPhone,INSERTED.AccountPhone AS NewAccountPhone,
							DELETED.AccountPIN AS OldAccountPIN,INSERTED.AccountPIN AS NewAccountPIN,
							DELETED.EffectiveBeginDate AS OldEffectiveBeginDate,@MGStatusBeginDate AS NewEffectiveBeginDate,
							DELETED.EffectiveEndDate AS OldEffectiveEndDate,@MGDeactivationDate AS NewEffectiveEndDate,
							DELETED.PayAccountAddressLine1 AS OldPayAccountAddressLine1,INSERTED.PayAccountAddressLine1 AS NewPayAccountAddressLine1,
							DELETED.PayAccountAddressLine2 AS OldPayAccountAddressLine2,INSERTED.PayAccountAddressLine2 AS NewPayAccountAddressLine2,
							DELETED.PayAccountAdrCity AS OldPayAccountAdrCity,INSERTED.PayAccountAdrCity AS NewPayAccountAdrCity,
							DELETED.PayAccountAdrState AS OldPayAccountAdrState,INSERTED.PayAccountAdrState AS NewPayAccountAdrState,
							DELETED.PayAccountAdrZip9 AS OldPayAccountAdrZip9,INSERTED.PayAccountAdrZip9 AS NewPayAccountAdrZip9,
							DELETED.ProfileID AS OldProfileID,INSERTED.ProfileID AS NewProfileID
						INTO @TempBizProfileDetailLog
					FROM KYPEnrollment.pAccount_BizProfile_Details ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,AccountLegalName,AccountSSN,AccountEIN,AccountAddressLine1,AccountAddressLine2,
								 AccountAdrCity,AccountAdrState,AccountAdrZip9,AccountPhone,AccountPIN,LastAction,LastActorUserID,LastActionApprovedBy,
								 PayAccountAddressLine1,PayAccountAddressLine2,PayAccountAdrCity,PayAccountAdrState,PayAccountAdrZip9,ProfileID
							FROM KYPEnrollment.pAccount_BizProfile_Details
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID  
					
					SELECT	T.BizProfileDetailsID,T.OldAccountBillingStatus,T.NewAccountBillingStatus
						INTO TempBizProfileDetailUpdated
						FROM @TempBizProfileDetailLog T
						LEFT JOIN @TempBizProfileDetailLog T1
						ON	T.BizProfileDetailsID					= T1.BizProfileDetailsID			AND
							ISNULL(T.OldAccountEnrollmentStatus,'')	= ISNULL(T1.NewAccountEnrollmentStatus,'') AND
							ISNULL(T.OldAccountBillingStatus,'')	= ISNULL(T1.NewAccountBillingStatus,'') AND
							ISNULL(T.OldAccountLegalName,'')		= ISNULL(T1.NewAccountLegalName,'') AND
							ISNULL(T.OldAccountSSN,'') 				= ISNULL(T1.NewAccountSSN,'') AND
							ISNULL(T.OldAccountEIN,'')				= ISNULL(T1.NewAccountEIN,'') AND
							ISNULL(T.OldAccountAddressLine1,'')		= ISNULL(T1.NewAccountAddressLine1,'') AND
							ISNULL(T.OldAccountAddressLine2,'')		= ISNULL(T1.NewAccountAddressLine2,'') AND
							ISNULL(T.OldAccountAdrCity,'')			= ISNULL(T1.NewAccountAdrCity,'') AND
							ISNULL(T.OldAccountAdrState,'')			= ISNULL(T1.NewAccountAdrState,'') AND
							ISNULL(T.OldAccountAdrZip9,'')			= ISNULL(T1.NewAccountAdrZip9,'') AND
							ISNULL(T.OldAccountPhone,'')			= ISNULL(T1.NewAccountPhone,'') AND
							ISNULL(T.OldAccountPIN,'')				= ISNULL(T1.NewAccountPIN,'') AND
							ISNULL(T.OldEffectiveBeginDate,'')		= ISNULL(T1.NewEffectiveBeginDate,'') AND
							ISNULL(T.OldEffectiveEndDate,'') 		= ISNULL(T1.NewEffectiveEndDate,'') AND
							ISNULL(T.OldPayAccountAddressLine1,'')	= ISNULL(T1.NewPayAccountAddressLine1,'') AND
							ISNULL(T.OldPayAccountAddressLine2,'') 	= ISNULL(T1.NewPayAccountAddressLine2,'') AND
							ISNULL(T.OldPayAccountAdrCity,'')		= ISNULL(T1.NewPayAccountAdrCity,'') AND
							ISNULL(T.OldPayAccountAdrState,'')		= ISNULL(T1.NewPayAccountAdrState,'') AND
							ISNULL(T.OldPayAccountAdrZip9,'')		= ISNULL(T1.NewPayAccountAdrZip9,'') AND
							ISNULL(T.OldProfileID,'')				= ISNULL(T1.NewProfileID,'')
						WHERE T1.BizProfileDetailsID IS NULL
					
					UPDATE [KYPEnrollment].[pAccount_BizProfile_Details]
						SET [LastAction] 			= 'U',
							[LastActionDate] 		= CONVERT(DATE,GETDATE(),112),
							[LastActorUserID] 		= 'system',
							[LastActionApprovedBy] 	= 'system'
						WHERE BizProfileDetailsID	IN (SELECT TMP.BizProfileDetailsID
															FROM TempBizProfileDetailUpdated TMP)

					DELETE FROM @TempSpecialityLog
					DROP TABLE TempSpecialityNew
					DROP TABLE TempSpecialityDeleted
					DROP TABLE TempSpecialityUpdated
					DROP TABLE TempTaxonomyNew
					DROP TABLE TempTaxonomyDeleted
					DROP TABLE TempAccountUpdated
					DELETE FROM @TempAccountLog
					DROP TABLE TempAccountStatusUpdate
					DELETE FROM @TempAddressLog
					DROP TABLE TempAddressUpdated
					DELETE FROM @TempLocationLog
					DROP TABLE TempLocationUpdated
					DROP TABLE TempOrganizationUpdated
					DELETE FROM @TempOrganizationLog
					DELETE FROM @TempCLIALog
					DROP TABLE TempCLIAUpdated
					DELETE FROM @TempOwnerLog
					DROP TABLE TempOwnerUpdated
					DROP TABLE TempAccountOwnerUpdated
					DELETE FROM @TempAccountInternalUseLog
					DROP TABLE TempAccountInternalUseUpdated
					DELETE FROM @TempPaymentDetailLog
					DROP TABLE TempPaymentDetailUpdated
					DELETE FROM @TempRenderingAffiliationUpdateSfileLog
					DROP TABLE TempRenderingAffiliationDELforSfile
					DROP TABLE TempRenderingAffiliationDELforYfile
					DROP TABLE TempAccountLegalNameUpdated
					DROP TABLE TempAccountBusinessNameUpdated
					DROP TABLE TempAccountEINUpdated
					DROP TABLE TempAccountSSNUpdated
					DROP TABLE TempAccountPINUpdated
					DROP TABLE TempAccountProvLocTypCodUpdated
					DROP TABLE TempAccountNextReEnrollmentDateUpdated
					DROP TABLE TempAccountOutOfStateIndicatorUpdated
					DROP TABLE TempAccountCHDPCodeUpdated
					DROP TABLE TempAccountReenrollmentIndicatorDateUpdated
					DROP TABLE TempAccountProvisionalCodeDateUpdated
					DROP TABLE TempAccountLabStatusCodeDateUpdated
					DELETE FROM @TempBizProfileDetailLog
					DROP TABLE TempBizProfileDetailUpdated

			END

			ELSE IF @IsPaveOwnedData = 1

			BEGIN
		
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [StatusBeginDate]		= @MGStatusBeginDate,
						[ActivationDate]		= @MGActivationDate,
						[DeActivationDate]		= @MGDeactivationDate,
						[PIN]					= ILV.PIN,
						[StatusAcc]				= @MGStatusAcc,
						ProvLocTypeCd			= ILV.ProvLocTypeCd,
						ReEnrollmentDate		= @MGNextReEnrollmentDate,
						LastActionDate			= GETDATE()
					OUTPUT	INSERTED.AccountID,NULL AS OldLegalName,NULL AS NewLegalName,NULL AS OldBusinessName,NULL AS NewBusinessName,
							NULL AS OldEIN,NULL AS NewEIN,NULL AS OldSSN,NULL AS NewSSN,DELETED.PIN AS OldPIN,INSERTED.PIN AS NewPIN,
							DELETED.ProvLocTypeCd AS OldProvLocTypeCd,INSERTED.ProvLocTypeCd AS NewProvLocTypeCd,
							NULL AS OldPracticeAddress,NULL AS NewPracticeAddress,NULL AS OldPhone,NULL AS NewPhone,
							NULL AS OldActivationDate,NULL AS NewActivationDate,NULL AS OldDeActivationDate,NULL AS NewDeActivationDate,
							-- Below fields are useful for Account Status
							DELETED.StatusAcc AS OldStatusAcc,@MGStatusAcc AS NewStatusAcc,NULL AS OldStatusBeginDate,NULL AS NewStatusBeginDate,
							DELETED.ReEnrollmentDate AS OldNextReEnrollmentDate,@MGNextReEnrollmentDate AS NewNextReEnrollmentDate
						INTO @TempAccountLog
					FROM KYPEnrollment.pADM_Account ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,LegalName,PracticeAddress,LastActorUserID,LastActionApprovedBy,AccountUpdateUserID,
								 AccountUpdatedBy,SSN,EIN,PIN,Phone,BusinessName,CreatedBy,ProvLocTypeCd
							FROM KYPEnrollment.pADM_Account
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID
				
				SELECT	T.AccountID,T.OldPIN,T.NewPIN
					INTO TempAccountPINUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID	= T1.AccountID		AND
						T.OldPIN	= T1.NewPIN
					WHERE T1.AccountID IS NULL
				
				SELECT	T.AccountID,T.OldLegalName,T.NewLegalName,T.OldBusinessName,T.NewBusinessName,T.OldEIN,T.NewEIN,T.OldSSN,T.NewSSN,
						T.OldPIN,T.NewPIN,T.OldProvLocTypeCd,T.NewProvLocTypeCd
					INTO TempAccountUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID													= T1.AccountID												AND
						ISNULL(CONVERT(VARCHAR(32),T.OldActivationDate,105),'')		= ISNULL(CONVERT(VARCHAR(32),T1.NewActivationDate,105),'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldDeActivationDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewDeActivationDate,105),'')AND
						ISNULL(T.OldStatusAcc,'')									= ISNULL(T1.NewStatusAcc,'')								AND
						ISNULL(CONVERT(VARCHAR(32),T.OldStatusBeginDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewStatusBeginDate,105),'')
					WHERE T1.AccountID IS NULL
				
				SELECT	T.AccountID,T.OldProvLocTypeCd,T.NewProvLocTypeCd
					INTO TempAccountProvLocTypCodUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID						= T1.AccountID		AND
						ISNULL(T.OldProvLocTypeCd,'')	= ISNULL(T1.NewProvLocTypeCd,'')
					WHERE T1.AccountID IS NULL

				SELECT	T.AccountID,T.OldNextReEnrollmentDate,T.NewNextReEnrollmentDate
					INTO TempAccountNextReEnrollmentDateUpdated
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID								= T1.AccountID		AND
						ISNULL(T.OldNextReEnrollmentDate,'')	= ISNULL(T1.NewNextReEnrollmentDate,'')
					WHERE T1.AccountID IS NULL

				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastAction]			= 'U',
						[LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					WHERE AccountID IN (SELECT TMP1.AccountID FROM TempAccountPINUpdated TMP1
										UNION
										SELECT TMP2.AccountID FROM TempAccountUpdated TMP2
										UNION
										SELECT TMP3.AccountID FROM TempAccountProvLocTypCodUpdated TMP3
										UNION
										SELECT TMP4.AccountID FROM TempAccountNextReEnrollmentDateUpdated TMP4)

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'PIN' AS GroupName,'UPD' AS Action,'PIN' AS Attribute,OldPIN AS OldValue,NewPIN AS NewValue,0 FROM TempAccountPINUpdated
					UNION ALL
					SELECT @MGAccountID,'Provider Location Type Code' AS GroupName,'UPD' AS Action,'Provider Location Type Code' AS Attribute,OldProvLocTypeCd AS OldValue,NewProvLocTypeCd AS NewValue,0 FROM TempAccountProvLocTypCodUpdated
					-- UNION ALL
					
				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Next Re-enrollment Date' AS GroupName,'UPD' AS Action,'Next Re-enrollment Date' AS Attribute,OldNextReEnrollmentDate AS OldValue,NewNextReEnrollmentDate AS NewValue,0 FROM TempAccountNextReEnrollmentDateUpdated

				-- Whenever Account status will change in Account table, Its status will become deactivate in AccountStatus table and new entry will be inserted with the Current Status
				SELECT	T.AccountID,T.OldStatusAcc,T.NewStatusAcc-- ,NewStatusBeginDate -- Don't compare this field as it is written to insert in Account Status table
					INTO TempAccountStatusUpdate
					FROM @TempAccountLog T
					LEFT JOIN @TempAccountLog T1
					ON	T.AccountID		= T1.AccountID		AND
						T.OldStatusAcc	= T1.NewStatusAcc
					WHERE T1.AccountID	IS NULL

				SELECT @lCount = COUNT(1)
					FROM TempAccountStatusUpdate
				
				IF @lCount > 1
				
				BEGIN
				
					UPDATE KYPEnrollment.pADM_AccountStatus
						SET EffectiveEndDate	= @MGStatusBeginDate - 1,
							CurrentRecordFlag	= 0
						WHERE AccountStatusID IN (SELECT MAX(ACS.AccountStatusID)
													FROM KYPEnrollment.pADM_AccountStatus ACS
													WHERE AccountID			= @MGAccountID AND -- IN (SELECT AccountID FROM TempAccountStatusUpdate) 
														  CurrentRecordFlag = 1
													GROUP BY AccountID)

					INSERT INTO KYPEnrollment.pADM_AccountStatus
					(
						AccountID,
						StatusType,
						StatusValue,
						EffectiveBeginDate,
						LastAction,
						LastActionDate,
						LastActionApprovedBy,
						CurrentRecordFlag
					)
					SELECT	@MGAccountID,
							'Enrollment',
							@MGStatusAcc,
							@MGStatusBeginDate,
							'C',
							GETDATE(),
							'System',
							1

					INSERT INTO KYPEnrollment.MixedGroupHistory
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'Status Code' AS Attribute,OldStatusAcc AS OldValue,@MGStatusAcc AS NewValue,0 FROM @TempAccountLog
						UNION ALL
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldStatusBeginDate,105) AS OldValue,CONVERT(VARCHAR(32),@MGStatusBeginDate,105) AS NewValue,0 FROM @TempAccountLog
						UNION ALL
						SELECT @MGAccountID,'Enrollment Status' AS GroupName,'UPD' AS Action,'End Date' AS Attribute,CONVERT(VARCHAR(32),@MGStatusBeginDate-1,105) AS OldValue,'-' AS NewValue,0 FROM @TempAccountLog

				END
				
				UPDATE [KYPEnrollment].[pAccount_PDM_Address]
					SET AddressLine1					= ILV.AddressLine1,
						AddressLine2					= ILV.AddressLine2,
						County							= ILV.County,
						City							= ILV.City,
						Zip								= ILV.Zip,
						ZipPlus4						= ILV.ZipPlus4,
						[State]							= ILV.[State]						
       				OUTPUT	INSERTED.AddressID,INSERTED.AddressType,DELETED.AddressLine1 AS OldAddressLine1,INSERTED.AddressLine1 AS NewAddressLine1,
       						DELETED.AddressLine2 AS OldAddressLine2,INSERTED.AddressLine2 AS NewAddressLine2,DELETED.County AS OldCounty,
       						INSERTED.County AS NewCounty,DELETED.City AS OldCity,INSERTED.City AS NewCity,
       						DELETED.ZipPlus4 AS OldZip,INSERTED.ZipPlus4 AS NewZip,DELETED.[State] AS OldState,INSERTED.[State] AS NewState
						INTO @TempAddressLog
       				FROM KYPEnrollment.pAccount_PDM_Address ADRS
       				JOIN (SELECT AddressID,SG.Phone1,SG.AddressLine1,SG.AddressLine2,SG.County,SG.City,SG.Zip,SG.ZipPlus4,SG.[State]
       						FROM(SELECT  @MGPartyID AS MGPartyID,PartyID AS SGPartyID,Phone1,ADR.AddressLine1,ADR.AddressLine2,ADR.County,ADR.City,ADR.Zip,
       									 ADR.ZipPlus4,ADR.[State],LOC.[Type]
       								FROM KYPEnrollment.pAccount_PDM_Address ADR
									JOIN KYPEnrollment.pAccount_PDM_Location LOC
									ON ADR.AddressID	= LOC.AddressID
									WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
														FROM @SubGroupAccountIDsAndPartyID TMP)) SG
							JOIN KYPEnrollment.pAccount_PDM_Location MG
							ON SG.MGPartyID	= MG.PartyID AND
							   SG.[Type]	= MG.[Type] AND
							   MG.[Type]	= 'Pay-to') ILV
					ON ADRS.AddressID	= ILV.AddressID
				
				SELECT	T.AddressID,T.AddressType,T.OldAddressLine1,T.NewAddressLine1,T.OldAddressLine2,T.NewAddressLine2,T.OldCounty,
						T.NewCounty,T.OldCity,T.NewCity,T.OldZip,T.NewZip,T.OldState,T.NewState
					INTO TempAddressUpdated
					FROM @TempAddressLog T
					LEFT JOIN @TempAddressLog T1
					ON	T.AddressID						= T1.AddressID					AND
						ISNULL(T.OldAddressLine1,'')	= ISNULL(T1.NewAddressLine1,'')	AND
						ISNULL(T.OldAddressLine2,'')	= ISNULL(T1.NewAddressLine2,'')	AND
						ISNULL(T.OldCounty,'')			= ISNULL(T1.NewCounty,'')		AND
						ISNULL(T.OldCity,'')			= ISNULL(T1.NewCity,'')			AND
						ISNULL(T.OldZip,'')				= ISNULL(T1.NewZip,'')			AND
						ISNULL(T.OldState,'')			= ISNULL(T1.NewState,'')
					WHERE T1.AddressID IS NULL
				
				UPDATE [KYPEnrollment].[pAccount_PDM_Address]
					SET [LastAction]					= 'U',
						[LastActionDate]				= GETDATE(),
						[LastActionUserID]				= 'system',
       					[LastActionApprovedByUsedID]	= 'system'
       				WHERE AddressID IN (SELECT TMP.AddressID
       										FROM TempAddressUpdated TMP)

-- If the Address Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON ACC.PartyID		= LOC.PartyID
					JOIN KYPEnrollment.pAccount_PDM_Address ADR
					ON LOC.AddressID	= ADR.AddressID
					JOIN TempAddressUpdated Temp
					ON ADR.AddressID	= Temp.AddressID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'AddressLine1' AS Attribute,OldAddressLine1 AS OldValue,NewAddressLine1 AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'AddressLine2' AS Attribute,OldAddressLine2 AS OldValue,NewAddressLine2 AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'County' AS Attribute,OldCounty AS OldValue,NewCounty AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'City' AS Attribute,OldCity AS OldValue,NewCity AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'State' AS Attribute,OldState AS OldValue,NewState AS NewValue,0 FROM TempAddressUpdated
					UNION ALL
					SELECT @MGAccountID,AddressType + ' Address' AS GroupName,'UPD' AS Action,'Zip' AS Attribute,OldZip AS OldValue,NewZip AS NewValue,0 FROM TempAddressUpdated					

				UPDATE KYPEnrollment.pAccount_PDM_Location
					SET Phone1 					= ILV.Phone1						
					OUTPUT INSERTED.LocationID,DELETED.Phone1 AS OldPhone1,INSERTED.Phone1 AS NewPhone1
						INTO @TempLocationLog
					FROM KYPEnrollment.pAccount_PDM_Location LOC
					JOIN (SELECT @MGPartyID AS MGPartyID,Phone1,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,[Type]
							FROM KYPEnrollment.pAccount_PDM_Location
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON	LOC.PartyID	= ILV.MGPartyID	AND
						LOC.[Type]	= ILV.[Type]	AND
						LOC.[Type]	= 'Pay-to'
				
				SELECT	T.LocationID,T.OldPhone1,T.NewPhone1
					INTO TempLocationUpdated
					FROM @TempLocationLog T
					LEFT JOIN @TempLocationLog T1
					ON	T.LocationID			= T1.LocationID	AND
						ISNULL(T.OldPhone1,'')	= ISNULL(T1.NewPhone1,'')
					WHERE T1.LocationID IS NULL
				
				UPDATE KYPEnrollment.pAccount_PDM_Location
					SET LastAction 				= 'U',
						LastActionDate			= GETDATE(),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE LocationID IN(SELECT TMP.LocationID
											FROM TempLocationUpdated TMP)

-- If the Location Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON ACC.PartyID		= LOC.PartyID
					JOIN TempLocationUpdated Temp
					ON LOC.LocationID	= Temp.LocationID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Telephone Number' AS GroupName,'UPD' AS Action,'Telephone Number' AS Attribute,OldPhone1 AS OldValue,NewPhone1 AS NewValue,0 FROM TempLocationUpdated
-- 3562 clia starts
				INSERT INTO @MG_CLIA_AuxTable 
				(
					[CliaNumber] ,
					[MinCliaNumber],
					[MaxCliaNumber]
				)
				SELECT CliaNumber,MIN(CliaNumber) AS MinCliaNumber,MAX(CliaNumber) AS MaxCliaNumber
					FROM  [KYPEnrollment].[pAccount_PDM_Clia]
					WHERE PartyID IN (SELECT TMP.SubGroupPartyID
										FROM @SubGroupAccountIDsAndPartyID TMP)
				GROUP BY CliaNumber
				ORDER BY CliaNumber DESC

				IF EXISTS (SELECT 1
								FROM @MG_CLIA_AuxTable
								WHERE CliaNumber IS NOT NULL)
				BEGIN

					SELECT @MGCliaNumber = MinCliaNumber
						FROM @MG_CLIA_AuxTable
						WHERE -- CliaNumber IS NOT NULL
						ISNULL(CliaNumber,'') != ''

				END

				IF NOT EXISTS (SELECT 1
									FROM @MG_CLIA_AuxTable
									WHERE CliaNumber IS NOT NULL)
				BEGIN

					SELECT @MGCliaNumber = NULL

				END

				UPDATE [KYPEnrollment].[pAccount_PDM_Clia]
					SET [CertificateType]	= ILV.CertificateType,
						[CliaNumber]		= @MGCliaNumber
					OUTPUT	INSERTED.CliaID,DELETED.CertificateType AS OldCertificateType,INSERTED.CertificateType AS NewCertificateType,
							DELETED.CliaNumber AS OldCliaNumber,INSERTED.CliaNumber AS NewCliaNumber
						INTO @TempCLIALog
					FROM KYPEnrollment.pAccount_PDM_Clia CLIA
					JOIN (SELECT @MGPartyID AS MGPartyID,CertificateType
							FROM KYPEnrollment.pAccount_PDM_Clia
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON CLIA.PartyID	= ILV.MGPartyID

				SELECT T.CliaID,T.OldCertificateType,T.NewCertificateType,T.OldCliaNumber,T.NewCliaNumber
					INTO TempCLIAUpdated
					FROM @TempCLIALog T
					LEFT JOIN @TempCLIALog T1
					ON	T.CliaID						= T1.CliaID				AND
						ISNULL(T.OldCertificateType,'')	= ISNULL(T1.NewCertificateType,'') AND
						ISNULL(T.OldCliaNumber,'')		= ISNULL(T1.NewCliaNumber,'')
					WHERE T1.CliaID IS NULL

				UPDATE [KYPEnrollment].[pAccount_PDM_Clia]
					SET LastAction 					= 'U',
						LastActionDate 				= CONVERT(DATE,GETDATE(),112),
						LastActorUserID 			= 'system',
						LastActionReason			= NULL,
						LastActionComments			= NULL,
						LastActionApprovedByUsedID	= 'system'
					WHERE CliaID IN (SELECT TMP.CliaID
										FROM TempCLIAUpdated TMP)					

				-- If the CLIA Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_Clia CLIA
					ON ACC.PartyID	= CLIA.PartyID
					JOIN TempCLIAUpdated Temp
					ON CLIA.CliaID	= Temp.CliaID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'CLIA' AS GroupName,'UPD' AS Action,'CLIA Number' AS Attribute,OldCliaNumber AS OldValue,NewCliaNumber AS NewValue,0 FROM TempCLIAUpdated
					UNION ALL
					SELECT @MGAccountID,'CLIA' AS GroupName,'UPD' AS Action,'Type Cert' AS Attribute,OldCertificateType AS OldValue,NewCertificateType AS NewValue,0 FROM TempCLIAUpdated
-- 3562 clia ends
--3562 OwnereffectiveBegindate start
				UPDATE [KYPEnrollment].[pAccount_Owner]
					SET EffectiveBeingDate	= ILV.EffectiveBeingDate,
						EffectiveEndDate	= ILV.EffectiveEndDate
					OUTPUT	INSERTED.OwnerID,ILV.OwnerNo,DELETED.EffectiveBeingDate AS OldEffectiveBeingDate,INSERTED.EffectiveBeingDate AS NewEffectiveBeingDate,
							DELETED.EffectiveEndDate AS OldEffectiveEndDate,INSERTED.EffectiveEndDate AS NewEffectiveEndDate,
							NULL AS OldLegalName,NULL AS NewLegalName,NULL AS OldBusinessName,NULL AS NewBusinessName,NULL AS OldDBAName,NULL AS NewDBAName,
							NULL AS OldTIN,NULL AS NewTIN,NULL AS OldTINH,NULL AS NewTINH,NULL AS OldSSN,NULL AS NewSSN,NULL AS OldSSNH,NULL AS NewSSNH
						INTO @TempOwnerLog
					FROM KYPEnrollment.pAccount_Owner ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,OwnerNo,EffectiveBeingDate,EffectiveEndDate
							FROM KYPEnrollment.pAccount_Owner
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID  
				
				SELECT T.OwnerID,T.OwnerNo,T.OldEffectiveBeingDate,T.NewEffectiveBeingDate,T.OldEffectiveEndDate,T.NewEffectiveEndDate
					INTO TempOwnerUpdated
					FROM @TempOwnerLog T
					LEFT JOIN @TempOwnerLog T1
					ON	T.OwnerID = T1.OwnerID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveBeingDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveBeingDate,105),'') AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveEndDate,105),'')
					WHERE T1.OwnerID IS NULL
				
				SELECT T.OwnerID,T.OwnerNo,T.OldEffectiveBeingDate,T.NewEffectiveBeingDate,T.OldEffectiveEndDate,T.NewEffectiveEndDate
					INTO TempAccountOwnerUpdated
					FROM @TempOwnerLog T
					LEFT JOIN @TempOwnerLog T1
					ON	T.OwnerID = T1.OwnerID AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveBeingDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveBeingDate,105),'') AND
						ISNULL(CONVERT(VARCHAR(32),T.OldEffectiveEndDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewEffectiveEndDate,105),'')
					WHERE T1.OwnerID IS NULL

				UPDATE [KYPEnrollment].[pAccount_Owner]
					SET [LastAction]		= 'U',
						[LastActionDate]	= CONVERT(DATE,GETDATE(),112),
						[LastActorUserID]	= 'system'
					WHERE OwnerID IN(SELECT TMP.OwnerID
										FROM TempAccountOwnerUpdated TMP)

-- If the Owner Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_Owner OWN
					ON ACC.AccountID	= OWN.AccountID
					JOIN TempAccountOwnerUpdated Temp
					ON OWN.OwnerID		= Temp.OwnerID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'Owner No' AS Attribute,OwnerNo AS OldValue,OwnerNo AS NewValue,0 FROM TempOwnerUpdated
					UNION ALL
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldEffectiveBeingDate,105) AS OldValue,CONVERT(VARCHAR(32),NewEffectiveBeingDate,105) AS NewValue,0 FROM TempOwnerUpdated
					UNION ALL
					SELECT @MGAccountID,'Ownership' AS GroupName,'UPD' AS Action,'End Date' AS Attribute,CONVERT(VARCHAR(32),OldEffectiveEndDate,105) AS OldValue,CONVERT(VARCHAR(32),NewEffectiveEndDate,105) AS NewValue,0 FROM TempOwnerUpdated
--3562 OwnereffectiveBegindate end
				UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
					SET BillingStatus			= @MGBillingStatus,
						BillingBeginDate		= CASE WHEN @MGBillingStatus IS NULL THEN
														NULL
													ELSE
														@MGStatusBeginDate
													END,
						OutOfStateInd			= @MGOutOfStateInd,
						CHDPCode				= @MGCHDPCode,
						ReEnrolInd				= @MGReEnrolInd,
						ReEnrolDate				= @MGReEnrolDate,
						ProvisionalCode			= @MGProvisionalCode,
						ProvisionalCodeDate		= @MGProvisionalCodeDate,
						LabStatusCode			= @MGLabStatusCode,
						LabStatusCodeDate		= @MGLabStatusCodeDate
					OUTPUT	INSERTED.AccountInternalUseID,DELETED.BillingStatus AS OldBillingStatus,INSERTED.BillingStatus AS NewBillingStatus,
							DELETED.BillingBeginDate AS OldBillingBeginDate,INSERTED.BillingBeginDate AS NewBillingBeginDate,
							DELETED.OutOfStateInd AS OldOutOfStateInd,INSERTED.OutOfStateInd AS NewOutOfStateInd,
							DELETED.CHDPCode AS OldCHDPCode,INSERTED.CHDPCode AS NewCHDPCode,
							DELETED.ReEnrolInd AS OldReEnrolInd,INSERTED.ReEnrolInd AS NewReEnrolInd,
							DELETED.ReEnrolDate AS OldReEnrolDate,INSERTED.ReEnrolDate AS NewReEnrolDate,
							DELETED.ProvisionalCode AS OldProvisionalCode,INSERTED.ProvisionalCode AS NewProvisionalCode,
							DELETED.ProvisionalCodeDate AS OldProvisionalCodeDate,INSERTED.ProvisionalCodeDate AS NewProvisionalCodeDate,
							DELETED.LabStatusCode AS OldLabStatusCode,INSERTED.LabStatusCode AS NewLabStatusCode,
							DELETED.LabStatusCodeDate AS OldLabStatusCodeDate,INSERTED.LabStatusCodeDate AS NewLabStatusCodeDate
						INTO @TempAccountInternalUseLog
					WHERE AccountID = @MGAccountID

				SELECT T.AccountInternalUseID,T.OldBillingStatus,T.NewBillingStatus,T.OldBillingBeginDate,T.NewBillingBeginDate
					INTO TempAccountInternalUseUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										= T1.AccountInternalUseID			AND
						ISNULL(T.OldBillingStatus,'')								= ISNULL(T1.NewBillingStatus,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldBillingBeginDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewBillingBeginDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL
				
				SELECT T.AccountInternalUseID,T.OldOutOfStateInd,T.NewOutOfStateInd
					INTO TempAccountOutOfStateIndicatorUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID			= T1.AccountInternalUseID		AND
						ISNULL(T.OldOutOfStateInd,'')	= ISNULL(T1.NewOutOfStateInd,'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldCHDPCode,T.NewCHDPCode
					INTO TempAccountCHDPCodeUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID		= T1.AccountInternalUseID	AND
						ISNULL(T.OldCHDPCode,'')	= ISNULL(T1.NewCHDPCode,'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldReEnrolInd,T.NewReEnrolInd,T.OldReEnrolDate,T.NewReEnrolDate
					INTO TempAccountReenrollmentIndicatorDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID									= T1.AccountInternalUseID		AND
						ISNULL(T.OldReEnrolInd,'')								= ISNULL(T1.NewReEnrolInd,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldReEnrolDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewReEnrolDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldProvisionalCode,T.NewProvisionalCode,T.OldProvisionalCodeDate,T.NewProvisionalCodeDate
					INTO TempAccountProvisionalCodeDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										 = T1.AccountInternalUseID			AND
						ISNULL(T.OldProvisionalCode,'')								 = ISNULL(T1.NewProvisionalCode,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldProvisionalCodeDate,105),'') = ISNULL(CONVERT(VARCHAR(32),T1.NewProvisionalCodeDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				SELECT T.AccountInternalUseID,T.OldLabStatusCode,T.NewLabStatusCode,T.OldLabStatusCodeDate,T.NewLabStatusCodeDate
					INTO TempAccountLabStatusCodeDateUpdated
					FROM @TempAccountInternalUseLog T
					LEFT JOIN @TempAccountInternalUseLog T1
					ON	T.AccountInternalUseID										= T1.AccountInternalUseID			AND
						ISNULL(T.OldLabStatusCode,'')								= ISNULL(T1.NewLabStatusCode,'')	AND
						ISNULL(CONVERT(VARCHAR(32),T.OldLabStatusCodeDate,105),'')	= ISNULL(CONVERT(VARCHAR(32),T1.NewLabStatusCodeDate,105),'')
					WHERE T1.AccountInternalUseID IS NULL

				UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
					SET LastAction				= 'U',
						LastActionDate			= CONVERT(DATE,GETDATE(),112),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE AccountInternalUseID	IN (SELECT TMP1.AccountInternalUseID FROM TempAccountInternalUseUpdated TMP1
													UNION
													SELECT TMP2.AccountInternalUseID FROM TempAccountOutOfStateIndicatorUpdated TMP2
													UNION
													SELECT TMP3.AccountInternalUseID FROM TempAccountCHDPCodeUpdated TMP3
													UNION
													SELECT TMP4.AccountInternalUseID FROM TempAccountReenrollmentIndicatorDateUpdated TMP4
													UNION
													SELECT TMP5.AccountInternalUseID FROM TempAccountProvisionalCodeDateUpdated TMP5
													UNION
													SELECT TMP6.AccountInternalUseID FROM TempAccountLabStatusCodeDateUpdated TMP6)

-- If the AccountInternalUse Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.EDM_AccountInternalUse AIU
					ON ACC.AccountID	= AIU.AccountID
					WHERE AIU.AccountInternalUseID IN  (SELECT TMP1.AccountInternalUseID FROM TempAccountInternalUseUpdated TMP1
														UNION
														SELECT TMP2.AccountInternalUseID FROM TempAccountOutOfStateIndicatorUpdated TMP2
														UNION
														SELECT TMP3.AccountInternalUseID FROM TempAccountCHDPCodeUpdated TMP3
														UNION
														SELECT TMP4.AccountInternalUseID FROM TempAccountReenrollmentIndicatorDateUpdated TMP4
														UNION
														SELECT TMP5.AccountInternalUseID FROM TempAccountProvisionalCodeDateUpdated TMP5
														UNION
														SELECT TMP6.AccountInternalUseID FROM TempAccountLabStatusCodeDateUpdated TMP6)
					/*JOIN TempAccountInternalUseUpdated Temp
					ON AIU.AccountInternalUseID	= Temp.AccountInternalUseID*/

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'Billing Status' AS GroupName,'UPD' AS Action,'Status Code' AS Attribute,OldBillingStatus AS OldValue,NewBillingStatus AS NewValue,0 FROM TempAccountInternalUseUpdated
					UNION ALL
					SELECT @MGAccountID,'Billing Status' AS GroupName,'UPD' AS Action,'Begin Date' AS Attribute,CONVERT(VARCHAR(32),OldBillingBeginDate,105) AS OldValue,CONVERT(VARCHAR(32),NewBillingBeginDate,105) AS NewValue,0 FROM TempAccountInternalUseUpdated
					UNION ALL
					SELECT @MGAccountID,'Out of State Indicator' AS GroupName,'UPD' AS Action,'Out of State Indicator' AS Attribute,OldOutOfStateInd AS OldValue,NewOutOfStateInd AS NewValue,0 FROM TempAccountOutOfStateIndicatorUpdated
					UNION ALL
					SELECT @MGAccountID,'CHDP' AS GroupName,'UPD' AS Action,'CHDP Code' AS Attribute,OldCHDPCode AS OldValue,NewCHDPCode AS NewValue,0 FROM TempAccountCHDPCodeUpdated
					UNION ALL
					SELECT @MGAccountID,'ReEnrollment' AS GroupName,'UPD' AS Action,'Reenrollment Indicator' AS Attribute,OldReEnrolInd AS OldValue,NewReEnrolInd AS NewValue,0 FROM TempAccountReenrollmentIndicatorDateUpdated
					UNION ALL
					SELECT @MGAccountID,'ReEnrollment' AS GroupName,'UPD' AS Action,'Reenrollment Date' AS Attribute,CONVERT(VARCHAR(32),OldReEnrolDate,105) AS OldValue,CONVERT(VARCHAR(32),NewReEnrolDate,105) AS NewValue,0 FROM TempAccountReenrollmentIndicatorDateUpdated
					UNION ALL
					SELECT @MGAccountID,'Provisional' AS GroupName,'UPD' AS Action,'Provisional Code' AS Attribute,OldProvisionalCode AS OldValue,NewProvisionalCode AS NewValue,0 FROM TempAccountProvisionalCodeDateUpdated
					UNION ALL
					SELECT @MGAccountID,'Provisional' AS GroupName,'UPD' AS Action,'Provisional Date' AS Attribute,CONVERT(VARCHAR(32),OldProvisionalCodeDate,105) AS OldValue,CONVERT(VARCHAR(32),NewProvisionalCodeDate,105) AS NewValue,0 FROM TempAccountProvisionalCodeDateUpdated
					UNION
					SELECT @MGAccountID,'Lab Status' AS GroupName,'UPD' AS Action,'Lab Status Code' AS Attribute,OldLabStatusCode AS OldValue,NewLabStatusCode AS NewValue,0 FROM TempAccountLabStatusCodeDateUpdated
					UNION
					SELECT @MGAccountID,'Lab Status' AS GroupName,'UPD' AS Action,'Lab Status Code Date' AS Attribute,CONVERT(VARCHAR(32),OldLabStatusCodeDate,105) AS OldValue,CONVERT(VARCHAR(32),NewLabStatusCodeDate,105) AS NewValue,0 FROM TempAccountLabStatusCodeDateUpdated
					
				UPDATE [KYPEnrollment].[pAccount_PDM_PaymentDetail]
					SET EFT_Indicator = ILV.EFT_Indicator
					OUTPUT INSERTED.PaymentDetailID,DELETED.EFT_Indicator AS OldEFTIndicator,INSERTED.EFT_Indicator AS NewEFTIndicator
						INTO @TempPaymentDetailLog
					FROM KYPEnrollment.pAccount_PDM_PaymentDetail PD
					JOIN (SELECT @MGPartyID AS MGPartyID,EFT_Indicator
							FROM KYPEnrollment.pAccount_PDM_PaymentDetail
							WHERE PartyID IN(SELECT MAX(TMP.SubGroupPartyID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON PD.PartyID	= ILV.MGPartyID
				
				SELECT T.PaymentDetailID,T.OldEFTIndicator,T.NewEFTIndicator
					INTO TempPaymentDetailUpdated
					FROM @TempPaymentDetailLog T
					LEFT JOIN @TempPaymentDetailLog T1
					ON	T.PaymentDetailID				= T1.PaymentDetailID	AND
						ISNULL(T.OldEFTIndicator,'')	= ISNULL(T1.NewEFTIndicator,'')
					WHERE T1.PaymentDetailID IS NULL
				
				UPDATE [KYPEnrollment].[pAccount_PDM_PaymentDetail]
					SET LastAction				= 'U',
						LastActionDate			= CONVERT(DATE,GETDATE(),112),
						LastActorUserID			= 'system',
						LastActionApprovedBy	= 'system'
					WHERE PaymentDetailID IN(SELECT TMP.PaymentDetailID
												FROM TempPaymentDetailUpdated TMP)

-- If the Payment Detail Updated then it's Account information also gets updated
				UPDATE [KYPEnrollment].[pADM_Account]
					SET [LastActorUserID]		= 'system',
						[LastActionApprovedBy]	= 'system',
						[LastAction]			= 'U',
						[LastActionDate]		= GETDATE(),
						[DateModified]			= GETDATE(),
						[AccountUpdateDate]		= GETDATE(),
						[AccountUpdatedBy]		= 'M'
					FROM [KYPEnrollment].[pADM_Account] ACC
					JOIN KYPEnrollment.pAccount_PDM_PaymentDetail PD
					ON ACC.PartyID			= PD.PartyID
					JOIN TempPaymentDetailUpdated Temp
					ON PD.PaymentDetailID	= Temp.PaymentDetailID

				INSERT INTO KYPEnrollment.MixedGroupHistory
					SELECT @MGAccountID,'EFT Indicator' AS GroupName,'UPD' AS Action,'EFT Indicator' AS Attribute,OldEFTIndicator AS OldValue,NewEFTIndicator AS NewValue,0 FROM TempPaymentDetailUpdated

				UPDATE [KYPEnrollment].[AccountSearch]
					SET [EnrollmentStatus]		= @MGStatusAcc,
						[BillingStatus]			= @MGBillingStatus,
						[PayCity]				= ILV.PayCity,
						[PayState]				= ILV.[PayState],
						[PayZip]				= ILV.[PayZip],
						[StatusDate]			= @MGStatusBeginDate,
						[PayAddressLine1]		= ILV.[PayAddressLine1],
						[PayAddressLine2]		= ILV.[PayAddressLine2],
						[StatusBeginDate]		= @MGStatusBeginDate,
						EnrolledOn				= @MGStatusBeginDate,
						ReEnrollmentDate		= @MGReEnrolDate
					FROM KYPEnrollment.AccountSearch ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,BillingStatus,ServiceCity,ServiceState,ServiceZip,PayCity,[PayState],[PayZip],
								 [AccountName],[SSN],[TAXID],[ServiceAddressLine1],[ServiceAddressLine2],PayAddressLine1,PayAddressLine2
							FROM KYPEnrollment.AccountSearch
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
													FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
					ON ACC.AccountID = ILV.MGAccountID  

				UPDATE [KYPEnrollment].[pAccount_BizProfile_Details]
					SET [AccountEnrollmentStatus] 	= @MGStatusAcc,
						[AccountBillingStatus] 		= @MGBillingStatus,
						[EffectiveBeginDate] 		= @MGStatusBeginDate,
						[EffectiveEndDate] 			= @MGDeactivationDate,
						[PayAccountAddressLine1] 	= ILV.[PayAccountAddressLine1],
						[PayAccountAddressLine2] 	= ILV.[PayAccountAddressLine2],
						[PayAccountAdrCity] 		= ILV.[PayAccountAdrCity],
						[PayAccountAdrState] 		= ILV.[PayAccountAdrState],
						[PayAccountAdrZip9]  		= ILV.[PayAccountAdrZip9]
					OUTPUT	INSERTED.BizProfileDetailsID,
							DELETED.AccountEnrollmentStatus AS OldAccountEnrollmentStatus,INSERTED.AccountEnrollmentStatus AS NewAccountEnrollmentStatus,
							DELETED.AccountBillingStatus AS OldAccountBillingStatus,INSERTED.AccountBillingStatus AS NewAccountBillingStatus,
							NULL AS OldAccountLegalName,NULL AS NewAccountLegalName,NULL AS OldAccountSSN,NULL AS NewAccountSSN,
							NULL AS OldAccountEIN,NULL AS NewAccountEIN,NULL AS OldAccountAddressLine1,NULL AS NewAccountAddressLine1,
							NULL AS OldAccountAddressLine2,NULL AS NewAccountAddressLine2,NULL AS OldAccountAdrCity,NULL AS NewAccountAdrCity,
							NULL AS OldAccountAdrState,NULL AS NewAccountAdrState,NULL AS OldAccountAdrZip9,NULL AS NewAccountAdrZip9,
							NULL AS OldAccountPhone,NULL AS NewAccountPhone,NULL AS OldAccountPIN,NULL AS NewAccountPIN,
							DELETED.EffectiveBeginDate AS OldEffectiveBeginDate,@MGStatusBeginDate AS NewEffectiveBeginDate,
							DELETED.EffectiveEndDate AS OldEffectiveEndDate,@MGDeactivationDate AS NewEffectiveEndDate,
							DELETED.PayAccountAddressLine1 AS OldPayAccountAddressLine1,INSERTED.PayAccountAddressLine1 AS NewPayAccountAddressLine1,
							DELETED.PayAccountAddressLine2 AS OldPayAccountAddressLine2,INSERTED.PayAccountAddressLine2 AS NewPayAccountAddressLine2,
							DELETED.PayAccountAdrCity AS OldPayAccountAdrCity,INSERTED.PayAccountAdrCity AS NewPayAccountAdrCity,
							DELETED.PayAccountAdrState AS OldPayAccountAdrState,INSERTED.PayAccountAdrState AS NewPayAccountAdrState,
							DELETED.PayAccountAdrZip9 AS OldPayAccountAdrZip9,INSERTED.PayAccountAdrZip9 AS NewPayAccountAdrZip9,
							NULL AS OldProfileID,NULL AS NewProfileID
						INTO @TempBizProfileDetailLog
					FROM KYPEnrollment.pAccount_BizProfile_Details ACC
					JOIN (SELECT @MGAccountID AS MGAccountID,AccountLegalName,AccountSSN,AccountEIN,AccountAddressLine1,AccountAddressLine2,
								 AccountAdrCity,AccountAdrState,AccountAdrZip9,AccountPhone,AccountPIN,LastAction,LastActorUserID,LastActionApprovedBy,
								 PayAccountAddressLine1,PayAccountAddressLine2,PayAccountAdrCity,PayAccountAdrState,PayAccountAdrZip9
							FROM KYPEnrollment.pAccount_BizProfile_Details
							WHERE AccountID IN (SELECT MAX(TMP.SubGroupAccountID)
												FROM @SubGroupAccountIDsAndPartyID TMP)) ILV
				ON ACC.AccountID = ILV.MGAccountID
				
				SELECT	T.BizProfileDetailsID,T.OldAccountBillingStatus,T.NewAccountBillingStatus
						INTO TempBizProfileDetailUpdated
						FROM @TempBizProfileDetailLog T
						LEFT JOIN @TempBizProfileDetailLog T1
						ON	T.BizProfileDetailsID					= T1.BizProfileDetailsID					AND
							ISNULL(T.OldAccountEnrollmentStatus,'')	= ISNULL(T1.NewAccountEnrollmentStatus,'')	AND
							ISNULL(T.OldAccountBillingStatus,'')	= ISNULL(T1.NewAccountBillingStatus,'')		AND
							ISNULL(T.OldEffectiveBeginDate,'')		= ISNULL(T1.NewEffectiveBeginDate,'')		AND
							ISNULL(T.OldEffectiveEndDate,'') 		= ISNULL(T1.NewEffectiveEndDate,'')			AND
							ISNULL(T.OldPayAccountAddressLine1,'')	= ISNULL(T1.NewPayAccountAddressLine1,'')	AND
							ISNULL(T.OldPayAccountAddressLine2,'') 	= ISNULL(T1.NewPayAccountAddressLine2,'')	AND
							ISNULL(T.OldPayAccountAdrCity,'')		= ISNULL(T1.NewPayAccountAdrCity,'')		AND
							ISNULL(T.OldPayAccountAdrState,'')		= ISNULL(T1.NewPayAccountAdrState,'')		AND
							ISNULL(T.OldPayAccountAdrZip9,'')		= ISNULL(T1.NewPayAccountAdrZip9,'')
						WHERE T1.BizProfileDetailsID IS NULL
					
				UPDATE [KYPEnrollment].[pAccount_BizProfile_Details]
					SET [LastAction] 			= 'U',
						[LastActionDate] 		= CONVERT(DATE,GETDATE(),112),
						[LastActorUserID] 		= 'system',
						[LastActionApprovedBy] 	= 'system'
					WHERE BizProfileDetailsID	IN (SELECT TMP.BizProfileDetailsID
														FROM TempBizProfileDetailUpdated TMP)
															
				DROP TABLE TempAccountUpdated
				DELETE FROM @TempAccountLog
				DROP TABLE TempAccountPINUpdated
				DROP TABLE TempAccountStatusUpdate
				DELETE FROM @TempAddressLog
				DROP TABLE TempAddressUpdated
				DELETE FROM @TempLocationLog
				DROP TABLE TempLocationUpdated
				DELETE FROM @TempAccountInternalUseLog
				DROP TABLE TempAccountInternalUseUpdated
				DELETE FROM @TempPaymentDetailLog
				DROP TABLE TempPaymentDetailUpdated
				DELETE FROM @TempBizProfileDetailLog
				DROP TABLE TempBizProfileDetailUpdated
				--3562
				DELETE FROM @TempOwnerLog
				DROP TABLE TempOwnerUpdated
				DROP TABLE TempAccountOwnerUpdated
				DROP TABLE TempAccountProvLocTypCodUpdated
				DROP TABLE TempAccountOutOfStateIndicatorUpdated
				DROP TABLE TempAccountCHDPCodeUpdated
				DROP TABLE TempAccountReenrollmentIndicatorDateUpdated
				DROP TABLE TempAccountProvisionalCodeDateUpdated
				DROP TABLE TempAccountLabStatusCodeDateUpdated
				DELETE FROM @TempCLIALog
				DROP TABLE TempCLIAUpdated
				DROP TABLE TempAccountNextReEnrollmentDateUpdated

			END

			DELETE FROM @TempRenderingAffiliationInsertSfileLog
			DROP TABLE TempRenderingAffiliationINSforSfile
			DELETE FROM @TempRenderingAffiliationInsertYfileLog
			DROP TABLE TempRenderingAffiliationINSforYfile
			DELETE FROM @TempRenderingAffiliationUpdateSfileLog
			DROP TABLE TempRenderingAffiliationUPDforSfile
			DROP TABLE TempRenderingAffiliationReactivateOrInsertforSfile
			DROP TABLE TempRenderingAffiliationReactivateOrInsertforYfile
			-- DROP TABLE TempMOCAIndividualLog
			-- DROP TABLE TempMOCAIndividualNew
			-- DROP TABLE TempMOCAIndividualUpdated
			-- DROP TABLE TempMOCAEntityLog
			-- DROP TABLE TempMOCAEntityNew
			-- DROP TABLE TempMOCAEntityUpdated

		END
		-- Anshu, We need to add Error log here which will tell us that this account is not processed because it was in transition phase
		DELETE FROM @SubGroupAccountIDsAndPartyID 
		DELETE FROM @MGStatusAndDate
		DELETE FROM @MG_CLIA_AuxTable
--		DELETE FROM @personTemp1
--		DELETE FROM @OrgTemp1
		
		SELECT @loopID = MIN (ID)
			FROM StageTableToLoopThroughMixedGroup
			WHERE ID > @loopID
		
		SET @MGAccountNumber		= NULL
		SET @MGPartyID				= NULL
		SET @MGAccountID			= NULL
		SET @MGReEnrolInd			= NULL
		SET @MGReEnrolDate			= NULL
		SET @MGOutOfStateInd		= NULL
		SET @MGCHDPCode				= NULL
		SET @MGProvisionalCode		= NULL
		SET @MGProvisionalCodeDate	= NULL
		SET @MGLabStatusCode		= NULL
		SET @MGLabStatusCodeDate	= NULL
		SET @MixedGroupClubbingID	= NULL
		SET @MGStatusAcc 			= NULL
		SET @MGBillingStatus		= NULL
		SET @MGStatusBeginDate 		= NULL
		SET @MGApplicationDate 		= NULL
		SET @MGActivationDate 		= NULL
		SET @MGDeactivationDate 	= NULL
		SET @MGCliaNumber 			= NULL

	END

	--============>>>>>Don't miss to Enable the Triggers Again
	;
	ENABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
	ENABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
/*	
	ENABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
	ENABLE TRIGGER  AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
	ENABLE TRIGGER  pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
*/
--	ENABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;

END
GO

