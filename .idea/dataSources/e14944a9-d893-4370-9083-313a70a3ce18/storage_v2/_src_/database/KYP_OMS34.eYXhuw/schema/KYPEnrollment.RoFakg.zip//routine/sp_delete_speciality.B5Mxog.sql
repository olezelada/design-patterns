
CREATE PROCEDURE [KYPEnrollment].[sp_delete_speciality] 
@new_Account_Id int

AS
BEGIN
SET NOCOUNT ON;

update s set isdeleted=1,currentrecordflag=0 
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Speciality s ON a.PartyID=s.PartyID where a.AccountID=@new_Account_Id and a.IsDeleted=0 and s.IsDeleted=0 and s.CurrentRecordFlag=1



END
GO

