


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@account_id INT,
@is_update BIT = 0,
@table_code VARCHAR(20) = NULL

AS
BEGIN
  IF @is_update = 0
  BEGIN
       DECLARE @type_Radio VARCHAR(50),@type_answer_two VARCHAR(50),@type_answer_Three VARCHAR(100),@date_create DATE
       SET @date_create = GETDATE();

	  SELECT @type_Radio = PrimaryAnswer, @type_answer_two = SecondAnswer, @type_answer_Three = ThirdAnswer
	  FROM  [KYPPORTAL].[PortalKYP].[pPDM_PlaceBusiness] WHERE PartyID =@party_app_id AND  TargetPath NOT LIKE '%|%';

		INSERT INTO [KYPEnrollment].[pAccount_PDM_PlaceBusiness] (
				[PartyId]
			   ,[PrimaryAnswer]
			   ,[SecondAnswer]
			   ,[ThirdAnswer]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag])
		  VALUES(@party_account_id
				,@type_Radio
				,@type_answer_two
				,@type_answer_Three
				,0
				,'C'
				,@date_create
				,@last_action_user_id
				,@last_action_user_id
				,1)
 END

  DECLARE @party_place_r1 INT,@party_place_acc_r1 INT
  SELECT @party_place_r1 = PartyID
  FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
  WHERE Type='Lease Information' AND ParentPartyID= @party_app_id AND IsDeleted=0 AND  TargetPath NOT LIKE '%|%';

  EXEC @party_place_acc_r1 = [KYPEnrollment].[sp_Copy_Party] @party_place_r1,@party_account_id,@account_id,@last_action_user_id;
  EXEC [KYPEnrollment].[sp_Copy_Person]@party_place_acc_r1,@party_place_r1,@last_action_user_id;
  EXEC [KYPEnrollment].[sp_Copy_Address]@party_place_acc_r1,@party_place_r1,NULL,@last_action_user_id;
  PRINT 'CREATE ACCOUNT TWO RADIOS'

END


GO

