-- =============================================
-- Author:		Sheetal
-- Create date: Aug 10 2012
-- Description:	Finds if Application number already exists
-- =============================================
CREATE PROCEDURE [KYP].[p_FindADMCaseRecord]
	-- Add the parameters for the stored procedure here
	 @Number varchar(35) 
	
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @CaseID int
	/********Check if Application number already exists**********/
	if exists (	
	select 1
	from KYP.ADM_Case where Number = @Number
	)
	begin	
	select @CaseID = CaseID
	from KYP.ADM_Case 
	where Number = @Number 
	return @CaseID	
	end	
	else 
	return -1   	
END


GO

