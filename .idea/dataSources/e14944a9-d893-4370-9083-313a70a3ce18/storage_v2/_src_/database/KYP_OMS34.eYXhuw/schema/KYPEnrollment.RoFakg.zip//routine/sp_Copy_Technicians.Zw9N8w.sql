-- =============================================
-- Author:		<clopez>
-- Create date: <01/26/2018 15:00:00>
-- Description:	<This procedure copy all Technicians for portable imaging package>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Technicians]
	@new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT,
	@last_Action_User_ID VARCHAR(100)

AS
BEGIN

	SET NOCOUNT ON;
declare @temp table (pk int identity(1,1),PartyID int,NumberID int,PersonID int, QuestionID int )
declare @tot int
declare @cont int,@sub_party int,@add_party int,@add_person int,@add_number int,@add_providerQ int,
@loc int,@new_sub_party int,@new_address int,@remarks varchar(250)

	IF exists (SELECT * FROM KYPPORTAL.PortalKYP.pPDM_Party WHERE ParentPartyID=@party_Id AND (Type='TechnicianLicense'))
	BEGIN

		INSERT INTO @temp (PartyID,NumberID,PersonID,QuestionID)
		SELECT     p.PartyID, n.NumberID, o.PersonID, q.QuestionID
		FROM       [KYPPORTAL].[PortalKYP].[pPDM_party] p
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_ProviderQuestionnarie] q ON p.PartyID=q.PartyID
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Number] n ON p.PartyID=n.PartyID
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Person] o ON p.PartyID=o.PartyID
		WHERE      p.ParentPartyID=@party_Id AND p.Type='TechnicianLicense'
		AND        p.IsDeleted=0 AND n.IsDeleted=0 AND q.IsDeleted = 0
		AND        q.TargetPath NOT LIKE  '%|%' AND n.TargetPath NOT LIKE  '%|%' AND o.TargetPath NOT LIKE  '%|%'

		SELECT @tot =MAX(pk) FROM @temp
		set @cont=1;

		WHILE @cont<=@tot
		BEGIN

			SELECT @add_party=t.PartyID, @add_person=t.PersonID, @add_number = t.NumberID, @add_providerQ=t.QuestionID  FROM @temp t WHERE t.pk=@cont
			EXEC @new_sub_party = [KYPEnrollment].[sp_Copy_Party] 	@add_party,	@new_Party_Id,	@new_Account_Id,	@last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_Person] @new_sub_party, @add_party,  @last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByName] @add_party, @new_sub_party, 'checkTechnicianNotApplicableMore';
			EXEC [KYPEnrollment].[sp_Copy_Number]	@new_sub_party,	@add_party,	@last_Action_User_ID,'';

			set @cont= @cont + 1

		END

	END

END


GO

