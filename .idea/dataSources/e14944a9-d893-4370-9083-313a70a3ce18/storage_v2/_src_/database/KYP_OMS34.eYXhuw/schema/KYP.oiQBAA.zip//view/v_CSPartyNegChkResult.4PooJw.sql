






CREATE VIEW [KYP].[v_CSPartyNegChkResult] AS

SELECT * FROM (

/** Name **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Name' As Field,D.Name AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Party D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Name Verification' 
				where C.StrAttr1 = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** NPI **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'NPI' As Field,DisclosedNPI AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.SDM_ProvMasterData D ON D.ScreeningID = P.ScreeningID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'NPI Verification'
				where C.NPI = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** Specailty **/



SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Specialty' As Field,D.PrimarySpecialty AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Provider D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Specialty Verification'
				where C.Specialty = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** Taxonomy **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Taxonomy' As Field,D.Taxonomy AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN 
				(
					SELECT T.* FROM(
						SELECT PartyID,Taxonomy,TaxonomyDesc,
						ROW_NUMBER() OVER(Partition By [PartyID] ORDER BY[TaxonomyID]) AS TINC 
						FROM KYP.PDM_Taxonomy
					)T WHERE T.TINC = 1
				)
				 D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Taxonomy Verification'
				where C.TAXONOMY_STATUS = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** License **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'License' As Field,D.DisclosedData AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN 
				(
					SELECT * FROM(
						SELECT V.ScreeningID,V.DisclosedData,ROW_NUMBER() OVER(PARTITION BY [PartyID] ORDER BY[MoreValueID]) AS LICIN 
						FROM KYP.SDM_MoreValue V INNER JOIN KYP.SDM_ApplicationParty P 
						ON V.ScreeningID = P.ScreeningID AND P.IsActive = 1 AND P.PartyRole = 'Provider' AND V.Category = 'PRACTICE' 
						AND V.AttributeName = 'LIC' AND V.MatchResult = 'F'
						)LIC WHERE LIC.LICIN = 1
				)
				 D ON D.ScreeningID = P.ScreeningID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'License Verification'
				where C.License = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** DEA **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'DEA' As Field,D.DEA AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Provider D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'DEA Verification'
				where C.DEA = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** CLIA **/
SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'CLIA' As Field,D.CLIA AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Provider D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'CLIA Verification'
				where C.CLIA = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** Address **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Address' As Field,COALESCE(D.AddressLine1,'') + COALESCE((',' + D.City),'') + COALESCE((',' + D.State),'') + COALESCE((',' + CONVERT(VARCHAR,D.Zip)),'') As Value, 
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN 
				(
					SELECT * FROM (
						Select P.PartyID,P.ScreeningID,A.AddressLine1,A.AddressLine2,A.City,A.State,A.Zip,
						ROW_NUMBER() OVER(PARTITION BY[ScreeningID] ORDER BY[LocationID]) As AINC
						from KYP.SDM_ApplicationParty P INNER JOIN KYP.PDM_Location L 
						ON L.PartyID = P.PartyID AND P.IsActive = 1 AND P.PartyType = 'Provider'
						INNER JOIN KYP.PDM_Address A ON A.AddressID = L.AddressID 
					)ADR WHERE ADR.AINC = 1
				)
				 D ON D.ScreeningID = P.ScreeningID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Address Verification'
				where C.City = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** Phone **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Phone' As Field,D.Phone1 As Value, 
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN 
				(
					SELECT * FROM (
						Select P.PartyID,P.ScreeningID,A.AddressLine1,L.Phone1,
						ROW_NUMBER() OVER(PARTITION BY[ScreeningID] ORDER BY[LocationID]) As AINC
						from KYP.SDM_ApplicationParty P INNER JOIN KYP.PDM_Location L 
						ON L.PartyID = P.PartyID AND P.IsActive = 1 AND P.PartyType = 'Provider'
						INNER JOIN KYP.PDM_Address A ON A.AddressID = L.AddressID 
					)ADR WHERE ADR.AINC = 1
				)
				 D ON D.ScreeningID = P.ScreeningID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Phone Verification'
				where C.PhoneNo = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** SSN **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'SSN' As Field,D.SSN AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Person D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'SSN Verification'
				where C.SSN = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'SSN' As Field,D.SSN AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Organization D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'SSN Verification'
				where C.SSN = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** TIN **/

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'TIN' As Field,D.TaxId AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Person D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'TaxID Verification'
				where C.TIN = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

SELECT Y.Field,Y.Value,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'TIN' As Field,D.TIN AS Value, COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 
				INNER JOIN KYP.PDM_Organization D ON D.PartyID = P.PartyID 
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID  AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'TaxID Verification'
				where C.TIN = 'F' 
	)X  
)Y WHERE  Y.SortOrder = 1




)X


GO

