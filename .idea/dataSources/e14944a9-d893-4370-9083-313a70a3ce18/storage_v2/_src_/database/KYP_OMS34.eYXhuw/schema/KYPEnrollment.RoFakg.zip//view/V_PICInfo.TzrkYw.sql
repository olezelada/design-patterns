
CREATE VIEW [KYPEnrollment].[V_PICInfo] as
SELECT  ROW_NUMBER() OVER(ORDER BY A.AccountNumber ASC) AS RID, C.FirstName,C.LastName,
C.MiddleName,C.SSN,D.NumberDoc AS DriverLicense, E.Number,D.StateIssued,F.Value AS SelfInsured,
A.AccountNumber,A.AccountID,A.ProviderTypeCode,F.Type as QueType, F.Name as QueName
 FROM KYPEnrollment.pADM_Account A 
INNER JOIN KYPEnrollment.pAccount_PDM_Party B
on A.PartyID=B.ParentPartyID and B.Type='PharmacistInformation' 
INNER JOIN KYPEnrollment.pAccount_PDM_Person C
on B.PartyID=C.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Document D
ON C.PartyID =D.PartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Number E   
ON D.PartyID=E.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_ProviderQuestionnarie F
on A.PartyID=F.PartyID 
 --AND F.Type='businessProfile' AND F.Name='ownedOperate'


GO

