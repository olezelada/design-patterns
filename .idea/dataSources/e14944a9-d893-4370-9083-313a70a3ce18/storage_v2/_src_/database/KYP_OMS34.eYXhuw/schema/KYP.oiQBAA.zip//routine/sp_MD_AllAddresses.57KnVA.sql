









-- =============================================
-- Author: Rahul Raghavendra    
-- Create date: 07-09-2017
-- Description:   
-- =============================================

CREATE PROCEDURE [KYP].[sp_MD_AllAddresses] 
      -- Add the parameters for the stored procedure here
     @Number varchar(20) ,
     @Username varchar(50)

AS
BEGIN


INSERT INTO [KYP].[MD_AllAddresses]
           (AddressLine1
           ,AddressLine2
           ,City
           ,State
           ,ZipPlus4
           ,Number
           ,Type
           ,ApplnType
           ,AccountNo
           ,Group_AccountNumber
           ,UserID
           )
--select A1.AddressLine1,A1.City,a1.ZipPlus4,a1.State,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber	
--	from KYPPORTAL.PortalKYP.pPDM_Location l1 
--	Inner join  KYPPORTAL.PortalKYP.pPDM_Address  A1 on l1.addressID=A1.addressID 
--	Inner join  KYPPORTAL.PortalKYP.pADM_Application p1 on p1.PartyID=l1.PartyID 
--	Inner join kyp.ADM_Case A2 on  A2.Number=p1.ApplicationNo  
--	Where A1.AddressLine1 is not null and A1.AddressLine2 is not null 
--	and A2.ApplnType not in ('New Rendering','Rendering-S')
	
--UNION

--	select p4.AddressLine1,p4.AddressLine2,p4.City,p4.StateCode,p4.ZipPlus4,A1.Number as ApplicationNo,p3.Type,A1.ApplnType,A1.AccountNo,
--	A1.Group_AccountNumber,@Username 
--from kyp.ADM_Case A1
--	Inner Join KYPPORTAL.PortalKYP.pRenderingAffiliation p1 on P1.rendering_providerNumber=A1.Number 
--	Inner Join KYPPORTAL.PortalKYP.pADM_Application p2 on p2.ApplicationNo=p1.group_providerNumber  
--	Inner Join KYPPORTAL.PortalKYP.pPDM_Location p3 on p3.PartyID = p2.PartyID
--	Inner Join KYPPORTAL.PortalKYP.pPDM_Address  p4 on p4.AddressID = p3.AddressID
--	Where ISNUMERIC(p1.group_providerNumber)=0 
--	and A1.ApplnType  in ('New Rendering','Rendering-S') and A1.Number=@Number
 
--UNION
 
-- select  p4.AddressLine1,p4.AddressLine2,p4.City,p5.Abreviation,p4.ZipPlus4,A1.Number as ApplicationNo,p3.Type,A1.ApplnType,
-- A1.AccountNo,A1.Group_AccountNumber,@Username 
-- from kyp.ADM_Case A1
--	Inner Join KYPPORTAL.PortalKYP.pRenderingAffiliation p1 on P1.rendering_providerNumber=A1.Number 
--	Inner Join KYPEnrollment.pADM_Account p2 on p2.AccountNumber=p1.group_providerNumber
--	Inner Join kypenrollment.pAccount_PDM_Location p3 on p3.PartyID=p2.PartyID
--	Inner Join kypenrollment.pAccount_PDM_address  p4 on P3.AddressID=p4.AddressID
--	Inner join KYP.LK_Screening p5 on p4.State=p5.Description
--	where ISNUMERIC(p1.group_providerNumber)=1 
--	and p2.LegacyAccountNo is null 
--	and A1.ApplnType  in ('New Rendering','Rendering-S') and A1.Number=@Number
 
	
--UNION

--select p4.AddressLine1,p4.AddressLine2,p4.City,p5.Abreviation,p4.ZipPlus4,AC.Number As ApplicationNo,p3.Type,Ac.ApplnType,
--Ac.AccountNo,Ac.Group_AccountNumber,@Username
--	from kyp.adm_case AC 
--	Inner Join kypenrollment.padm_Account p2 on AC.Group_AccountNumber=p2.AccountNumber
--	Inner join kypenrollment.pAccount_PDM_Location P3 on p3.PartyID=p2.PartyID
--	Inner join kypenrollment.pAccount_PDM_address  p4 on P3.AddressID=p4.AddressID
--	Inner join KYP.LK_Screening p5 on p4.State=p5.Description
--	Where Ac.AccountNo is not null
--	And P2.LegacyAccountno is not null
--	and ApplnType in ('Rendering-S','New Rendering') and AC.Number=@Number
	
 
--Union  
--select top 1 p4.AddressLine1,p4.AddressLine2,p4.City,p5.Abreviation,p4.ZipPlus4,A1.Number as ApplicationNo,p3.Type,
--A1.ApplnType,A1.AccountNo,A1.Group_AccountNumber ,@Username
--from kyp.ADM_Case A1
--	Join KYPEnrollment.pADM_Account A on A1.AccountNo = A.AccountNumber
--	--Join kypenrollment.pAccount_RenderingAffiliation RA on Ra.AffiliatedAccountID=A.AccountID	
--	--Join KYPEnrollment.pADM_Account GA on GA.AccountID = RA.AccountID
--	Join KYPEnrollment.pAccount_PDM_Location p3 on p3.PartyID = A.PartyID
--	Join KYPEnrollment.pAccount_PDM_Address  p4 on p4.AddressID = p3.AddressID
--	join KYP.LK_Screening p5 on p4.State=p5.Description
--	and  A1.P_PRACT_TY_CD in ('Rendering','RS','NMP')and A1.ApplnType not in ('New Rendering','Rendering-S')
--	and p3.Type = 'Mailing' and A1.Number=@Number

select p4.AddressLine1,p4.AddressLine2,p4.City,p4.StateCode,p4.ZipPlus4,AC.Number As ApplicationNo,p3.Type,Ac.ApplnType,
Ac.AccountNo,Ac.Group_AccountNumber,@Username
from KYPPORTAL.PortalKYP.pADM_Application p1
inner join KYPPORTAL.PortalKYP.pPDM_Location p3 on p1.PartyID=p3.PartyID
Inner join  KYPPORTAL.PortalKYP.pPDM_Address p4  on p3.AddressID=p4.AddressID
inner join KYP.ADM_Case AC on AC.Number=p1.ApplicationNo
where p1.ApplicationNo=@Number and AC.P_PRACT_TY_CD in ('Rendering','RS','NMP') and p3.Type='Individual Profile'

--union
--select top 1 p4.AddressLine1,p4.AddressLine2,p4.City,p5.Abreviation,p4.ZipPlus4,A1.Number as ApplicationNo,p3.Type,
--A1.ApplnType,A1.AccountNo,A1.Group_AccountNumber ,@Username
--from kyp.ADM_Case A1
--	Join KYPEnrollment.pADM_Account A on A1.AccountNo = A.AccountNumber
--	Join KYPEnrollment.pAccount_PDM_Location p3 on p3.PartyID = A.PartyID
--	Join KYPEnrollment.pAccount_PDM_Address  p4 on p4.AddressID = p3.AddressID
--	join KYP.LK_Screening p5 on p4.State=p5.Description
--	where
--	A1.P_PRACT_TY_CD in ('Rendering','RS','NMP')and A1.ApplnType in ('Rendering-S')
--	and p3.Type = 'Mailing' and A1.Number=@Number
END


GO

