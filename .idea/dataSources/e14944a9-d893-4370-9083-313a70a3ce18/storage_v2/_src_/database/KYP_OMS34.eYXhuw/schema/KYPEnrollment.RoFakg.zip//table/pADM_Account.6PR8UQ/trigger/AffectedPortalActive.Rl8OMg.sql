


-- =============================================

-- Author:   <Lperez>

-- =============================================

CREATE TRIGGER [KYPEnrollment].[AffectedPortalActive] ON [KYPEnrollment].[pADM_Account]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
BEGIN


	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF @Row_Updation_Source IN ( 'KYP.p_UpdateAlertonAccount','KYPEnrollment.SP_SuperUserHistory') AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END

	
	DECLARE @applicatioNo  varchar(50),
			@resolutionStatus varchar(100),			
			@message varchar(100)
			
	if (update(StatusAcc))
	BEGIN  		
		SELECT @applicatioNo = [ApplicationNumber], @resolutionStatus = [StatusAcc] FROM inserted
		SELECT @message = 'Account ' + CONVERT(char(50), @resolutionStatus)
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		IF @resolutionStatus='Active'
		BEGIN	
			EXECUTE [KYPEnrollment].[p_Affecting_Portal] @applicatioNo,	@resolutionStatus;
		END
	END
END


GO

