  
CREATE VIEW [KYPEnrollment].[viewProviderDirectoryData] AS
	
	SELECT row_number() over (order by LegalName ASC) AS ViewID, result.*
		FROM(
			SELECT acc.ProviderType
			,acc.LegalName
			,acc.DBAName
			,acc.Gender
			,acc.Title
			,acc.NPI
			,acc.NPIType
			,acc.PracticeAddress			
			,acc.Phone
			,sp.TaxonomyCode            
		    ,sp.Speciality_Code			    
		    ,ISNULL(acc.ProviderType+' ', '') + ISNULL(acc.LegalName+' ', '') 
		    + ISNULL(acc.DBAName+' ', '') + ISNULL(acc.Title+' ', '') + ISNULL(acc.NPI+' ', '')
		    + ISNULL(acc.NPIType+' ', '') + ISNULL(acc.PracticeAddress+' ', '')
		    + ISNULL(acc.Phone+' ', '') + ISNULL(sp.TaxonomyCode+' ', '')
		    + ISNULL(sp.Speciality_Code+' ', '') ProviderData
		    
		FROM [KYPEnrollment].[pADM_Account] acc, [KYPEnrollment].[pAccount_PDM_Speciality] sp
			
		WHERE acc.PartyID = sp.PartyID AND acc.StatusAcc='1 - Active' AND sp.IsDeleted = 'false' 
		)
		AS result


GO

