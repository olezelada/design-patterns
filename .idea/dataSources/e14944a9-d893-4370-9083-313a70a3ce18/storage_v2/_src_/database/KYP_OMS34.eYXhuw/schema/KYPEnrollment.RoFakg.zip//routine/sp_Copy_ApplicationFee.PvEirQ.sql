
/* ==========================================================
-- Author:		<JVera>
-- PROCEDURE: create ApplicationFee form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ApplicationFee]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON
DECLARE @date_created DATE;
SET @date_created =  GETDATE();


INSERT INTO [KYPEnrollment].[pAccount_PDM_ApplicationFee]
           ([PartyID]
           ,[FeeNumber]
           ,[FeeOption]
           ,[State]           
           ,[DateCreated]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
SELECT @party_account_id
           ,[FeeNumber]
           ,[FeeOption]
           ,[State]           
           ,@date_created
           ,[IsDeleted]
           ,'C'
           ,@date_created
           ,@last_action_user_id
           ,@last_action_user_id
           ,1
FROM [KYPPORTAL].[PortalKYP].[pPDM_ApplicationFee] WHERE PartyID =@party_app_id 

PRINT 'New ApplicationFee'       
END


GO

