

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Adverse Action.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @type_x : this is the type to Adverse Action will be create.
-- @adverse_action_id : this is the adverseActionID Application that will be Create in Update Account, it is Null when account is create. 
-- ============================================================*/

CREATE  PROCEDURE [KYPEnrollment].[sp_Copy_Adverse_Action]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@type_x VARCHAR(100),
@adverse_action_id INT
AS
BEGIN
SET NOCOUNT ON; 
DECLARE @date_created DATE;
SET @date_created =  GETDATE();
IF @adverse_action_id IS NULL
 BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
			   ([PartyID]
			   ,[Type_x]    
			   ,[Date_x]
			   ,[EffectiveDate]
			   ,[ProgramType]
			   ,[Where_x]
			   ,[Action_x]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag]
			   ,[ProgramTypeOther]
				 ,[AppAdverseActionID])
	SELECT @party_account_id
			   ,@type_x    
			   ,[Date_x]
			   ,[EffectiveDate]
			   ,[ProgramType]
			   ,[Where_x]
			   ,[Action_x]
			   ,[CreatedBy]
			   ,@date_created
			   ,[IsDeleted]
			   ,'C'
			   ,@date_created
			   ,@last_action_user_id
			   ,@last_action_user_id
			   ,1
			   ,[ProgramTypeOther]
				 ,[AdverseActionID]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE PartyID=@party_app_id AND Type_x = @type_x
	AND (IsDeleted IS NULL OR IsDeleted = 'false') 
  END
  ELSE
  BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
			   ([PartyID]
			   ,[Type_x]    
			   ,[Date_x]
			   ,[EffectiveDate]
			   ,[ProgramType]
			   ,[Where_x]
			   ,[Action_x]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag]
			   ,[ProgramTypeOther]
			   ,[AppAdverseActionID])
	SELECT @party_account_id
			   ,[Type_x]    
			   ,[Date_x]
			   ,[EffectiveDate]
			   ,[ProgramType]
			   ,[Where_x]
			   ,[Action_x]
			   ,[CreatedBy]
			   ,@date_created
			   ,[IsDeleted]
			   ,'C'
			   ,@date_created
			   ,@last_action_user_id
			   ,@last_action_user_id
			   ,1
			   ,[ProgramTypeOther]
			   ,[AdverseActionID]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE AdverseActionID=@adverse_action_id
	AND IsDeleted = 'false'
  END

	DECLARE @tot INT
	DECLARE @cont INT
	DECLARE @documentInstanceId INT, @accountAdverseActionId INT
	
					INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, DocumentInstanceId, AccountEntityId, EntityName, PrimaryKeyName)					
					SELECT NULL, appAC.documentInstanceId, accAC.AdverseActionID,'pAccount_PDM_AdverseAction','AdverseActionID'
					FROM KYPEnrollment.pAccount_PDM_AdverseAction accAc
					INNER JOIN KYPPORTAL.PortalKYP.pPDM_AdverseAction appAC on appAC.AdverseActionID = accAc.AppAdverseActionID
					WHERE accAc.PartyID = @party_account_id
					AND NOT EXISTS ( SELECT * FROM KYPEnrollment.pAccount_Attachments
									 WHERE DocumentInstanceId = appAC.documentInstanceId
									 AND AccountEntityId = accAC.AdverseActionID AND EntityName = 'pAccount_PDM_AdverseAction' )
					AND appAC.documentInstanceId IS NOT NULL AND appAC.documentInstanceId IS NOT NULL
				  

END

GO

