
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_InsertAppNo]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- =============================================
	-- Author:		<Author,,Name>
	-- Create date: <Create Date,,>
	-- Description:	<Description,,>
	DECLARE @Src_Group_PNO VARCHAR(20)
		,@Src_Member_PNO VARCHAR(20)
		,@Group_PNO VARCHAR(20)
		,@Member_PNO VARCHAR(20)
		,@Type VARCHAR(25)
		,@Count INT

	DECLARE grpCursor CURSOR
	FOR
	SELECT [Group_ProviderNO]
		,[Member_ProviderNO]
		,[Type]
	FROM [KYP].[PDM_MasterGroupProvider]

	OPEN grpCursor

	FETCH NEXT
	FROM grpCursor
	INTO @Src_Group_PNO
		,@Src_Member_PNO
		,@Type

	WHILE @@Fetch_Status = 0
	BEGIN
		SELECT @Group_PNO = Number
		FROM KYP.ADM_Case
		WHERE Provider_NPI = @Src_Group_PNO

		SELECT @Member_PNO = Number
		FROM KYP.ADM_Case
		WHERE Provider_NPI = @Src_Member_PNO

		IF NOT EXISTS (
				SELECT 1
				FROM [KYP].[PDM_GroupProvider]
				WHERE Group_ProviderNO = @Group_PNO
					AND Member_ProviderNO = @Member_PNO
				)
		BEGIN
			INSERT INTO [KYP].[PDM_GroupProvider] (
				[Group_ProviderNO]
				,[Member_ProviderNO]
				,[Type]
				)
			VALUES (
				@Group_PNO
				,@Member_PNO
				,@Type
				)
		END

		FETCH NEXT
		FROM grpCursor
		INTO @Src_Group_PNO
			,@Src_Member_PNO
			,@Type
	END -- End of Fetch

	CLOSE grpCursor

	DEALLOCATE grpCursor
END


GO

