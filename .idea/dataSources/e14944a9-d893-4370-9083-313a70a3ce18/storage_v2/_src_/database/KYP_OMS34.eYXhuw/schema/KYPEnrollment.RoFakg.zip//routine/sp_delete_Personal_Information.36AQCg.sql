-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Personal_Information] 
@new_Account_Id int

AS
BEGIN
Declare @person int
	SET NOCOUNT ON;

select @person = pe.PersonID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON pe.PartyID=p.PartyID
where a.AccountID=@new_Account_Id and pe.CurrentRecordFlag=1

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Person','PersonID',@person

END


GO

