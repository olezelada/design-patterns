







CREATE VIEW [KYP].[v_CSAppReviewFailDetails] AS

SELECT X.CaseID,X.FindingDetails,X.Tag,X.ExplDetails,X.NameDocument  FROM(

SELECT DISTINCT CONVERT(VARCHAR,C.PortalCaseID) As CaseID,F.fieldFinding As NameDocument,F.tagsFinding As Tag, 
		COALESCE(CONVERT(VARCHAR,F.addedon,101) + ' ' + RIGHT(CONVERT(CHAR(20), F.addedon, 22), 11),'') + COALESCE((': '+F.addedby),'') + COALESCE((' created '+ LOWER(F.isexternaldesc) + ' finding# '),'')
		+ COALESCE(CONVERT(VARCHAR,F.findingID),'') +  COALESCE(('; Finding Title: '+ CONVERT(VARCHAR,F.titleFinding)),'') +
		COALESCE(('. '+ F.findingDescription),'')  As FindingDetails,
		CASE WHEN ISDate(E.CreatedDate) = 1 THEN
		 COALESCE(CONVERT(VARCHAR,E.CreatedDate,101) + ' ' + RIGHT(CONVERT(CHAR(20),E.CreatedDate, 22), 11),'') + COALESCE((': '+ISNULL(E.PortalUser,'')),'') + 
		ISNULL(E.Description,'') ELSE NULL END
		 As ExplDetails
 FROM KYP.ADM_Case C 
 INNER JOIN 
 (SELECT  a.DateCreated addedon, 
          CASE WHEN a.Type IN ('Application Review') THEN cast(fe.PCaseID + '' AS int) ELSE cast(a.CaseID + '' AS int) END caseIDFinding,
          CASE WHEN a.ExternalYesNO IS NULL THEN 'N/D' 
                     WHEN (a.ExternalYesNO = '1' OR    a.ExternalYesNO = 'Yes') THEN 'EXTERNAL' 
                     WHEN (a.ExternalYesNO = '0' OR    a.ExternalYesNO = 'NO') THEN 'INTERNAL' ELSE NULL END AS isexternaldesc,
          a.Name titleFinding,
          CASE WHEN a.Type IN ('Application Review') THEN ISNULL((SELECT     TOP 1 fl.fieldLabel
                   FROM         KYPEnrollment.FieldLabel fl
                   WHERE     fe.PFieldID = fl.fieldID AND fe.PAppID = fl.ApplicationID AND fe.PSubFormID = fl.SubFormID), '') ELSE '' END AS fieldFinding ,
          CONVERT( varchar(200),a.tags) tagsFinding,
          (SELECT     p.LastName + ' ' + p.FirstName fROM          KYP.OIS_Person p, KYP.OIS_User u    WHERE      p.PersonID = u.PersonID AND u.UserID = a.UserID) AS addedby ,
          a.NoteID findingID ,
          CAST(a.UnformattedContent AS varchar(max))  findingDescription                             
												
        FROM 
        kyp.OIS_Note a   JOIN   kyp.MDM_JournalBasicInfo fe ON a.PInID = fe.infoid 
        WHERE      (((a.Type = 'Application Review' AND a.ReasonCode IS NOT NULL) OR  a.Type <> 'Application Review' ) AND isnull(a.Deleted,'0')<>'1')
  )F ON F.caseIDFinding = C.PortalCaseID AND ISNULL(F.fieldFinding ,'') != ''
 LEFT JOIN KYPEnrollment.FieldDocExpComments E ON E.PortalCaseID = C.PortalCaseID  
 WHERE F.tagsFinding = 'Document Verification' 
 
 
 UNION 
 
 
 SELECT DISTINCT CONVERT(VARCHAR,C.PortalCaseID) As CaseID,F.fieldFinding As NameDocument,'Field Verification' As Tag, 
		COALESCE(CONVERT(VARCHAR,F.addedon,101) + ' ' + RIGHT(CONVERT(CHAR(20), F.addedon, 22), 11),'') + COALESCE((': '+F.addedby),'') + COALESCE((' created '+ LOWER(F.isexternaldesc) + ' finding# '),'')
		+ COALESCE(CONVERT(VARCHAR,F.findingID),'') +  COALESCE(('; Finding Title: '+ CONVERT(VARCHAR,F.titleFinding)),'') +
		COALESCE(('. '+ F.findingDescription),'')  As FindingDetails,
		CASE WHEN ISDate(E.CreatedDate) = 1 THEN
		 COALESCE(CONVERT(VARCHAR,E.CreatedDate,101) + ' ' + RIGHT(CONVERT(CHAR(20),E.CreatedDate, 22), 11),'') + COALESCE((': '+ISNULL(E.PortalUser,'')),'') + 
		ISNULL(E.Description,'') ELSE NULL END
		 As ExplDetails
 FROM KYP.ADM_Case C 
 INNER JOIN
 (SELECT  a.DateCreated addedon, 
          CASE WHEN a.Type IN ('Application Review') THEN cast(fe.PCaseID + '' AS int) ELSE cast(a.CaseID + '' AS int) END caseIDFinding,
          CASE WHEN a.ExternalYesNO IS NULL THEN 'N/D' 
                     WHEN (a.ExternalYesNO = '1' OR    a.ExternalYesNO = 'Yes') THEN 'EXTERNAL' 
                     WHEN (a.ExternalYesNO = '0' OR    a.ExternalYesNO = 'NO') THEN 'INTERNAL' ELSE NULL END AS isexternaldesc,
          a.Name titleFinding,
          CASE WHEN a.Type IN ('Application Review') THEN ISNULL((SELECT     TOP 1 fl.fieldLabel
                   FROM         KYPEnrollment.FieldLabel fl
                   WHERE     fe.PFieldID = fl.fieldID AND fe.PAppID = fl.ApplicationID AND fe.PSubFormID = fl.SubFormID), '') ELSE '' END AS fieldFinding ,
          CONVERT( varchar(200),a.tags) tagsFinding,
          (SELECT     p.LastName + ' ' + p.FirstName fROM          KYP.OIS_Person p, KYP.OIS_User u    WHERE      p.PersonID = u.PersonID AND u.UserID = a.UserID) AS addedby ,
          a.NoteID findingID ,
          CAST(a.UnformattedContent AS varchar(max))  findingDescription                             
												
        FROM 
        kyp.OIS_Note a   JOIN   kyp.MDM_JournalBasicInfo fe ON a.PInID = fe.infoid 
        WHERE      (((a.Type = 'Application Review' AND a.ReasonCode IS NOT NULL) OR  a.Type <> 'Application Review' ) AND isnull(a.Deleted,'0')<>'1')
 
 )F ON F.caseIDFinding = C.PortalCaseID AND ISNULL(F.fieldFinding ,'') != ''
 LEFT JOIN KYPEnrollment.FieldDocExpComments E ON E.PortalCaseID = C.PortalCaseID  
 WHERE (F.tagsFinding = 'Document Verification' OR F.tagsFinding = 'Field Verification') 
 )X


GO

