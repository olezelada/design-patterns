






CREATE VIEW [KYP].[v_RiskRangeAcceptReject]
AS

 Select ROW_NUMBER() OVER(order by ApplicationID) ID,  X.* from(
   Select DISTINCT P.ApplicationID,A.Number,A.ProviderName,A.TypeDescription,P.NormalizedRisk,P.CompositeRisk ,A.StatusSubName As Status
 ,A.DateAssigned,A.DateResolved,A.DateReceived,A.CurrentlyAssignedToName,
 Case WHEN P.NormalizedRisk > 500 THEN '>500' 
	 WHEN P.NormalizedRisk <=500 AND P.NormalizedRisk >400 THEN '401-500'
	 WHEN P.NormalizedRisk <=400 AND P.NormalizedRisk >300 THEN '301-400'
	 WHEN P.NormalizedRisk <=300 AND P.NormalizedRisk >200 THEN '201-300'
	 WHEN P.NormalizedRisk <=200 AND P.NormalizedRisk >100 THEN '100-200'
	 WHEN P.NormalizedRisk < 100  THEN '<100'
 END As Range
   from KYP.ADM_Case A inner join KYP.ADM_Application P ON A.Number = P.ApplicationNo  
 WHERE (A.WFStatus = 'Completed' OR A.ActivityStatus = 'Completed') 
	AND A.StatusSubName IN ('Approved','Rejected')
 AND P.NormalizedRisk is not null
 )X


GO

