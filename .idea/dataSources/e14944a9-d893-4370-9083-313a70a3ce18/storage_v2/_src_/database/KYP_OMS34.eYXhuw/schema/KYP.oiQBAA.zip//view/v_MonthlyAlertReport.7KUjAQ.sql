

CREATE VIEW [KYP].[v_MonthlyAlertReport]
AS
SELECT row_number() OVER (
		ORDER BY AID ASC
		) AS ID
	,*
FROM (
	SELECT A.AlertID AS AID
		,A.AlertNo
		,A.WatchedPartyName AS [MatchedEntity]
		,A.WatchedPartyName AS [ProviderName]
		,A.MedicaidID AS [MedicaidID]
		,A.MatchPercent
		,A.MatchStatusIndicator AS STATUS
		,A.Assignee AS [Assignedto]
		,A.DateInitiated AS [AlertDate]
		,'Owner' AS RelationshipName
		,A.WatchlistName AS watchlist
		,A.MatchStatusIndicatorDesc AS StatusAbbreaviation
		,A.Priority
		,A.NPI
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Party B ON A.WatchedPartyID = B.PartyID
	INNER JOIN KYP.PDM_Owner C ON B.PartyID = C.PartyID
	--INNER JOIN KYP.PDM_Provider D ON C.ProviderID = D.ProvID
	--INNER JOIN KYP.PDM_Party EProvParty ON EProvParty.PartyId = D.PartyID
	--LEFT JOIN KYP.OIS_User F ON A.AssignedToUserID = F.PersonID
	--WHERE A.WFStatus = 'Completed'
	
	
	UNION
	
	SELECT A.AlertID
		,A.AlertNo
		,A.WatchedPartyName AS [MatchedEntity]
		,A.WatchedPartyName AS [ProviderName]
		,A.MedicaidID AS [MedicaidID]
		,A.MatchPercent
		,A.MatchStatusIndicator AS STATUS
		,A.Assignee AS [Assignedto]
		,A.DateInitiated AS [AlertDate]
		,'Employee' AS RelationshipName
		,A.WatchlistName AS watchlist
		,A.MatchStatusIndicatorDesc AS StatusAbbreaviation
		,A.Priority
		,A.NPI
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Party B ON A.WatchedPartyID = B.PartyID
	INNER JOIN KYP.PDM_Employee C ON B.PartyID = C.PartyID
	--INNER JOIN KYP.PDM_Provider D ON C.ProviderID = D.ProvID
	--INNER JOIN KYP.PDM_Party EProvParty ON EProvParty.PartyId = D.PartyID
	--LEFT JOIN KYP.OIS_User F ON A.AssignedToUserID = F.PersonID
	--INNER JOIN KYP.OIS_User G ON A.AssignedToUserID = G.PersonID
	--WHERE A.WFStatus = 'Completed'

	UNION
	
	SELECT A.AlertID
		,A.AlertNo
		,A.WatchedPartyName AS [MatchedEntity]
		,A.WatchedPartyName AS [ProviderName]
		,A.MedicaidID AS [MedicaidID]
		,A.MatchPercent
		,A.MatchStatusIndicator AS STATUS
		,A.Assignee AS [Assignedto]
		,A.DateInitiated AS [AlertDate]
		,'Billing Provider' AS RelationshipName
		,A.WatchlistName AS watchlist
		,A.MatchStatusIndicatorDesc AS StatusAbbreaviation
		,A.Priority
		,A.NPI
	FROM KYP.MDM_Alert A
	  INNER JOIN KYP.PDM_Provider B ON A.WatchedPartyID = B.PartyID
	  WHERE B.EnrolStatusCode in (1,9)
	--INNER JOIN KYP.PDM_Provider D ON B.PartyID = D.PartyID
	--LEFT JOIN KYP.OIS_User F ON A.AssignedToUserID = F.PersonID
	--WHERE A.WFStatus = 'Completed'
	
	UNION
	
	SELECT A.AlertID
		,A.AlertNo
		,A.WatchedPartyName AS [MatchedEntity]
		,A.WatchedPartyName AS [ProviderName]
		,A.MedicaidID AS [MedicaidID]
		,A.MatchPercent
		,A.MatchStatusIndicator AS STATUS
		,A.Assignee AS [Assignedto]
		,A.DateInitiated AS [AlertDate]
		,'Rendering Provider' AS RelationshipName
		,A.WatchlistName AS watchlist
		,A.MatchStatusIndicatorDesc AS StatusAbbreaviation
		,A.Priority
		,A.NPI
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Provider B ON A.WatchedPartyID = B.PartyID
	WHERE B.EnrolStatusCode='7'
	--INNER JOIN KYP.PDM_Provider D ON B.PartyID = D.PartyID
	--LEFT JOIN KYP.OIS_User F ON A.AssignedToUserID = F.PersonID
	--WHERE A.WFStatus = 'Completed'
	) A


GO

