CREATE PROCedure [KYP].[p_InsertADMAppLicense]
(@ApplicationID int
 ,@LicenseAuthority varchar(100)= NULL
 ,@EffectiveDate datetime =NULL
 ,@ExpiryDate datetime = NULL
 ,@LicenseType int=NULL
 ,@LicenseSubType varchar(25)=NULL
 ,@LicenseCode varchar(30)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@State varchar(50)=NULL

)
as begin 

INSERT INTO [KYP].[ADM_App_License]
           ([ApplicationID]
           ,[LicenseAuthority]
           ,[EffectiveDate]
           ,[ExpiryDate]
           ,[LicenseType]
           ,[LicenseSubType]
           ,[LicenseCode]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[State])
     VALUES
           (@ApplicationID
           ,@LicenseAuthority
           ,@EffectiveDate
           ,@ExpiryDate
           ,@LicenseType
           ,@LicenseSubType
           ,@LicenseCode
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@State)

	return IDENT_CURRENT('[KYP].[ADM_App_License]')

end


GO

