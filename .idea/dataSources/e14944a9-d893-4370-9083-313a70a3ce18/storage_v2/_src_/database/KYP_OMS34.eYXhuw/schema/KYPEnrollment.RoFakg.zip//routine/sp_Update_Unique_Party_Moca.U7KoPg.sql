
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Unique Party Moca.   
-- PARAMETERS: 
-- @party_account_id : PartyId Account that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Unique_Party_Moca]
@party_account_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON 
	DECLARE  @party_acc_owner_id INT, @party_type VARCHAR(50),@is_update BIT
	

	--DECLARE owner_cursor CURSOR FAST_FORWARD READ_ONLY FOR
	declare @owner table (PartyID int ,Type varchar(50))
	--SELECT PartyID,Type
	--into #owner
	insert into @owner
	select PartyID,Type
	FROM [KYPEnrollment].[pAccount_PDM_Party]
	WHERE (Type ='Entity Ownership' OR Type ='Individual Ownership')AND CurrentRecordFlag=1
	AND ParentPartyID=@party_account_id 
	
	
	--OPEN owner_cursor
	--FETCH NEXT FROM owner_cursor INTO @party_acc_owner_id,@party_type
	--WHILE @@FETCH_STATUS = 0
	
	while exists(select * from @owner)
	BEGIN
	    select top 1 @party_acc_owner_id=PartyID,@party_type= type from @owner 
		IF @party_type = 'Entity Ownership'
		BEGIN			
			EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id,'Entity',@last_action_user_id,1;
		END
		ELSE
		BEGIN		
			EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id,'Individual',@last_action_user_id,1;
		END
			
		delete from @owner where PartyID=@party_acc_owner_id 		
		--FETCH NEXT FROM owner_cursor INTO @party_acc_owner_id,@party_type
		
	END
	--drop table #owner 
	--CLOSE owner_cursor;
	--DEALLOCATE owner_cursor;
	
END


GO

