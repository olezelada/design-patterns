

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Party, Location, Address and Person row.   
-- PARAMETERS: 
-- @party_id : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @type : Party type.
-- @app_party_row_id : this is the PartyID Row to Application that will be Create in Update Account, it is Null when account is create.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Ind]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   @type                   VARCHAR (50),
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_individual    INT,
      @new_party_ind_id    INT,
      @count_association   INT,
      @main_party_id       INT,
      @is_prepopulated     BIT,
      @target_path         VARCHAR (200),
      @full_name_person    VARCHAR (100),
      @person_id           INT;
   PRINT '[sp_Copy_Party_Loc_Addr_Ind]';

   IF @app_party_row_id IS NULL
      --1
      BEGIN
         DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200)
                        )

         --DECLARE party_cursor CURSOR FAST_FORWARD READ_ONLY FOR
         --SELECT identity(int,1,1) as pk,PartyID
         --into #party
         INSERT INTO @party
            SELECT PartyID, IsPrepopulated, TargetPath
              FROM [KYPPORTAL].[PortalKYP].pPDM_Party
             WHERE     Type = @type
                   AND (IsDeleted = 0 OR IsDeleted = NULL)
                   AND ParentPartyID = @party_id

         --OPEN party_cursor;

         --FETCH NEXT FROM party_cursor INTO @party_individual
         DECLARE
            @cont   INT,
            @tot    INT
         SELECT @tot = MAX (pk) FROM @party
         SET @cont = 1

         WHILE @cont <= @tot
         --WHILE @@FETCH_STATUS = 0
         BEGIN
            SELECT @party_individual = PartyID,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath
            FROM @party
            WHERE pk = @cont

            IF (   @type = 'SubcontractorIndividual'
                OR @type = 'TransactionIndividual')
               BEGIN
                  SELECT @count_association = COUNT (OwnerRelationID)
                    FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                   WHERE     PartyIDOwned = @party_individual
                         AND (   TypeAssociation =
                                    'SubcontractorEntityAssociation'
                              OR TypeAssociation =
                                    'SubcontractorIndividualAssociation');

                  IF @count_association = 0
                     BEGIN
                        EXEC @new_party_ind_id =
                                [KYPEnrollment].[sp_Copy_Party] @party_individual,
                                                                @new_party_id,
                                                                @account_id,
                                                                @last_action_user_id;
                        EXEC @person_id =
                                [KYPEnrollment].[sp_Copy_Person] @new_party_ind_id,
                                                                 @party_individual,
                                                                 @last_action_user_id,
                                                                 'C';
                        EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_ind_id,
                                                               @party_individual,
                                                               NULL,
                                                               @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_individual,
                                                                           @new_party_ind_id,
                                                                           @last_action_user_id;

                        IF (@type = 'SubcontractorIndividual')
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_ind_id,
                                                                        @party_individual,
                                                                        @last_action_user_id,
                                                                        NULL,
                                                                        NULL;
                           END

                        IF (@type = 'TransactionIndividual' AND @is_group = 1)
                           BEGIN
                              IF (   @is_prepopulated IS NULL
                                  OR @is_prepopulated = 0)
                                 BEGIN
                                    SELECT @full_name_person =
                                              [FirstName] + ' ' + [LastName]
                                      FROM KYPEnrollment.pAccount_PDM_Person
                                     WHERE PersonID = @person_id;
                                    --EXEC [KYPEnrollment].[Create_Significat_TaxId] @new_party_ind_id,'Individual',@full_name_person, @new_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_ind_id,
                                                                                  @new_party_ind_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_individual;
                                 END
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @main_party_id = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @target_path,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @main_party_id = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @main_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                                  @new_party_ind_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_individual;
                                 END
                           END

                        IF (    @type = 'SubcontractorIndividual'
                            AND @is_group = 1)
                           BEGIN
                              IF (   @is_prepopulated IS NULL
                                  OR @is_prepopulated = 0)
                                 BEGIN
                                    SELECT @full_name_person =
                                              [FirstName] + ' ' + [LastName]
                                      FROM KYPEnrollment.pAccount_PDM_Person
                                     WHERE PersonID = @person_id;
                                    --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_ind_id,'Individual',@full_name_person, @new_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_ind_id,
                                                                                  @new_party_ind_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_individual;
                                 END
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @main_party_id = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @target_path,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @main_party_id = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @main_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                                  @new_party_ind_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_individual;
                                 END
                           END
                     END
               END
            ELSE
               BEGIN
                  EXEC @new_party_ind_id =
                          [KYPEnrollment].[sp_Copy_Party] @party_individual,
                                                          @new_party_id,
                                                          @account_id,
                                                          @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_Person] @new_party_ind_id,
                                                        @party_individual,
                                                        @last_action_user_id,
                                                        'C';
                  EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_ind_id,
                                                         @party_individual,
                                                         NULL,
                                                         @last_action_user_id;
               END

            SET @cont = @cont + 1
         --FETCH NEXT FROM party_cursor INTO @party_individual
         END
      --drop table #party
      --CLOSE party_cursor;
      --DEALLOCATE party_cursor;
      END
   --1
   ELSE
      BEGIN
         IF (   @type = 'SubcontractorIndividual'
             OR @type = 'TransactionIndividual')
            BEGIN
               EXEC @new_party_ind_id =
                       [KYPEnrollment].[sp_Copy_Party] @app_party_row_id,
                                                       @new_party_id,
                                                       @account_id,
                                                       @last_action_user_id;

               EXEC @person_id =
                       [KYPEnrollment].[sp_Copy_Person] @new_party_ind_id,
                                                        @app_party_row_id,
                                                        @last_action_user_id,
                                                        'C';

               EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_ind_id,
                                                      @app_party_row_id,
                                                      NULL,
                                                      @last_action_user_id;

               EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @app_party_row_id,
                                                                  @new_party_ind_id,
                                                                  @last_action_user_id;

               --mvc--
               INSERT
                 INTO #subcontractors (PartyID_Portal,
                                       Type_sub,
                                       PartyID_Enroll)
               VALUES (@app_party_row_id, @type, @new_Party_ind_id)

               IF (@type = 'SubcontractorIndividual')
                  BEGIN
                     EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_ind_id,
                                                               @party_individual,
                                                               @last_action_user_id,
                                                               NULL,
                                                               NULL;
                  END

               IF (@is_group = 1)
                  BEGIN
                     IF EXISTS
                           (SELECT ID
                              FROM #TaxIDChange
                             WHERE     PartyID = @app_party_row_id
                                   AND Type = @type)
                        BEGIN
                           IF @type = 'TransactionIndividual'
                              BEGIN
                                 SELECT @full_name_person =
                                           [FirstName] + ' ' + [LastName]
                                   FROM KYPEnrollment.pAccount_PDM_Person
                                  WHERE PersonID = @person_id;
                                 --EXEC [KYPEnrollment].[Create_Significat_TaxId] @new_party_ind_id,'Individual',@full_name_person, @new_party_id;
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_ind_id,
                                                                               @new_party_ind_id,
                                                                               @account_id,
                                                                               @type,
                                                                               @app_party_row_id;
                              END

                           IF @type = 'SubcontractorIndividual'
                              BEGIN
                                 SELECT @full_name_person =
                                           [FirstName] + ' ' + [LastName]
                                   FROM KYPEnrollment.pAccount_PDM_Person
                                  WHERE PersonID = @person_id;
                                 --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_ind_id,'Individual',@full_name_person, @new_party_id;
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_ind_id,
                                                                               @new_party_ind_id,
                                                                               @account_id,
                                                                               @type,
                                                                               @app_party_row_id;
                              END
                        END
                     ELSE
                        BEGIN
                           SELECT TOP 1
                                  @main_party_id = Item
                             FROM [KYPEnrollment].[SplitString] (
                                     @target_path,
                                     '|')
                           ORDER BY item;
                           SELECT TOP 1
                                  @main_party_id = MainPartyID
                           FROM [KYPEnrollment].[pAccount_Party_Associate]
                           WHERE PartyID = @main_party_id;
                           EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                         @new_party_ind_id,
                                                                         @account_id,
                                                                         @type,
                                                                         @app_party_row_id;
                        END
                  END
            END
         ELSE
            BEGIN
               EXEC @new_party_ind_id =
                       [KYPEnrollment].[sp_Copy_Party] @app_party_row_id,
                                                       @new_party_id,
                                                       @account_id,
                                                       @last_action_user_id;

               EXEC [KYPEnrollment].[sp_Copy_Person] @new_party_ind_id,
                                                     @app_party_row_id,
                                                     @last_action_user_id,
                                                     'C';

               EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_ind_id,
                                                      @app_party_row_id,
                                                      NULL,
                                                      @last_action_user_id;
            END

         RETURN @new_party_ind_id;
      END
END


GO

