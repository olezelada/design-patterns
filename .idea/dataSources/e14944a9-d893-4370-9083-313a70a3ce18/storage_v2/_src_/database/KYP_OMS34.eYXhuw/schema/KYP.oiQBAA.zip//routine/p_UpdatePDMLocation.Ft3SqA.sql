
CREATE PROCEDURE [KYP].[p_UpdatePDMLocation] (
	@AddressID INT
	,@PartyID INT
	,@ProviderID INT = NULL
	,@PersonID INT = NULL
	,@Type VARCHAR(25) = NULL
	,@WorkingDays VARCHAR(25) = NULL
	,@WorkingHours VARCHAR(25) = NULL
	,@Phone1 VARCHAR(15) = NULL
	,@Phone2 VARCHAR(15) = NULL
	,@Fax VARCHAR(15) = NULL
	,@Remarks VARCHAR(250) = NULL
	,@CurrentModule SMALLINT = NULL
	,@CreatedBy INT = NULL
	,@DateCreated SMALLDATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified SMALLDATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted SMALLDATETIME = NULL
	,@InActive BIT = NULL
	,@IsDeleted BIT = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF ISNULL(@ProviderID, '') = ''
	BEGIN
		SET @ProviderID = NULL;
	END

	IF ISNULL(@PersonID, '') = ''
	BEGIN
		SET @PersonID = NULL;
	END

	IF ISNULL(@InActive, '') = ''
	BEGIN
		SET @InActive = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END

	IF ISNULL(@IsDeleted, '') = ''
	BEGIN
		SET @IsDeleted = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Type, '')))) = ''
	BEGIN
		SET @Type = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@WorkingDays, '')))) = ''
	BEGIN
		SET @WorkingDays = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@WorkingHours, '')))) = ''
	BEGIN
		SET @WorkingHours = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone1, '')))) = ''
	BEGIN
		SET @Phone1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone2, '')))) = ''
	BEGIN
		SET @Phone2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Fax, '')))) = ''
	BEGIN
		SET @Fax = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remarks, '')))) = ''
	BEGIN
		SET @Remarks = NULL;
	END

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_Location] Set '

	IF @ProviderID IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProviderID] = ' + Convert(VARCHAR(12), @ProviderID)
		ELSE
			SET @updatelist = '[ProviderID] = ' + Convert(VARCHAR(12), @ProviderID)
	END

	IF @PersonID IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PersonID] = ' + Convert(VARCHAR(12), @PersonID)
		ELSE
			SET @updatelist = '[PersonID] = ' + Convert(VARCHAR(12), @PersonID)
	END

	IF @Type IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Type] = ''' + replace(@Type, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Type] = ''' + replace(@Type, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @WorkingDays IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[WorkingDays] = ''' + replace(@WorkingDays, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[WorkingDays] = ''' + replace(@WorkingDays, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @WorkingHours IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[WorkingHours] = ''' + replace(@WorkingHours, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[WorkingHours] = ''' + replace(@WorkingHours, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone2] = ''' + replace(@Phone2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone2] = ''' + replace(@Phone2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Fax IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Fax] = ''' + replace(@Fax, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Fax] = ''' + replace(@Fax, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Remarks IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	IF @InActive IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[InActive] = ' + CAST(@InActive AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[InActive] = ' + CAST(@InActive AS VARCHAR(1)) + ''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

