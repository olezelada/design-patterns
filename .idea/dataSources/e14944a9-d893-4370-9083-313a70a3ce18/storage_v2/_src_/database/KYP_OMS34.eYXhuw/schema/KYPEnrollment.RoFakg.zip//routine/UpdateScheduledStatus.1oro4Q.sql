





-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[UpdateScheduledStatus] 
	
AS
BEGIN
    DECLARE
	@AccountID varchar(300),
	@ScheduledStatus varchar(50),
	@StartDate smalldatetime,
	@FirstExtensionDate smalldatetime,
	@FinalExtensionDate smalldatetime,
	@TotalUpdateCount int = 0;
	
	
	create table #tblUpdatedID (ID int identity(1,1) Primary Key,AccountID varchar(300),SchedStatus varchar(50));
	
	insert into #tblUpdatedID
	SELECT * FROM(
	SELECT AccountID,'Started' AS SchedStatus FROM [KYPEnrollment].[AccountRevalidation] WHERE CAST(StartDate AS Date) = CAST(GETDATE() AS DATE)
	UNION ALL
	SELECT AccountID,'First Extension' AS SchedStatus FROM [KYPEnrollment].[AccountRevalidation] WHERE CAST(FirstExtensionDate AS Date) = CAST(GETDATE() AS DATE)
	UNION ALL
	SELECT AccountID,'Final Extension' AS SchedStatus FROM [KYPEnrollment].[AccountRevalidation] WHERE CAST(FinalExtensionDate AS Date) = CAST(GETDATE() AS DATE)
	)X
	
	SELECT @TotalUpdateCount = COUNT(ID) FROM #tblUpdatedID 
	
	PRINT @TotalUpdateCount
	WHILE(@TotalUpdateCount != 0)
	BEGIN
		
		SELECT @AccountID = AccountID, @ScheduledStatus = SchedStatus FROM #tblUpdatedID where ID = @TotalUpdateCount;
	 
		UPDATE [KYPEnrollment].[AccountRevalidation] SET ScheduledStatus = @ScheduledStatus where AccountID = @AccountID;	
		
		delete from #tblUpdatedID where ID = @TotalUpdateCount ;
		SET @TotalUpdateCount = @TotalUpdateCount - 1;
	
	END
	

	
	
	drop table #tblUpdatedID ;
	
	
	END


GO

