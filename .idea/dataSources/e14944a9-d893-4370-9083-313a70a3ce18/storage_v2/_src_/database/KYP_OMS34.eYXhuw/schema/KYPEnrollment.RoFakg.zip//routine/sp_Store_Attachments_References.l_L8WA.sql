-- =============================================
-- Author:		<Rloayza>
-- Create date: <07/15/2018>
-- Description:	<Store application account attachment references>
-- =============================================
CREATE PROCedure [KYPEnrollment].[sp_Store_Attachments_References]
  (
    @accountId INT,
    @documentInstanceId INT,
    @accountEntityId INT,
    @entityName VARCHAR(200),
    @primaryKeyName VARCHAR(200)
  )

AS

  BEGIN

    BEGIN TRY

    IF @documentInstanceId IS NOT NULL AND @accountEntityId IS NOT NULL AND @entityName IS NOT NULL AND @primaryKeyName IS NOT NULL
      BEGIN

        IF NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_Attachments
        WHERE DocumentInstanceId = @documentInstanceId
              AND AccountEntityId = @accountEntityId AND EntityName = @entityName)
          BEGIN
            INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, DocumentInstanceId, AccountEntityId, EntityName, PrimaryKeyName)
            VALUES(@accountId, @documentInstanceId, @accountEntityId, @entityName, @primaryKeyName)
          END
        RETURN
      END

    END TRY

    BEGIN CATCH

    Exec [KYPEnrollment].[Usp_LogError] @KeyField = @entityName,@KeyValue =@primaryKeyName

    END CATCH;

  END


GO

