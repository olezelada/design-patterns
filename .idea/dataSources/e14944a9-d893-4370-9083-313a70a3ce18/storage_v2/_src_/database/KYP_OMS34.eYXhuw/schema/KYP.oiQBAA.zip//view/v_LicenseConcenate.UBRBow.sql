
CREATE VIEW [KYP].[v_LicenseConcenate] AS

SELECT DISTINCT P.ApplicationID,CASE WHEN ISNULL(X.License,'') <> '' THEN X.License ELSE ISNULL(X.License,'-') END As License  
FROM KYP.SDM_ApplicationParty P INNER JOIN KYP.ADM_Application A ON P.ApplicationID = A.ApplicationID   INNER JOIN (
  SELECT DISTINCT EnrolCaseID ,STUFF((Select ';'+License from KYPEnrollment.PortalLicense T1 where T1.EnrolCaseID=T2.EnrolCaseID
  FOR XML PATH('')),1,1,'') As License from KYPEnrollment.PortalLicense T2 WHERE T2.IsDeleted = 0
 )X ON A.CaseID = X.EnrolCaseID AND P.IsActive = 1


GO

