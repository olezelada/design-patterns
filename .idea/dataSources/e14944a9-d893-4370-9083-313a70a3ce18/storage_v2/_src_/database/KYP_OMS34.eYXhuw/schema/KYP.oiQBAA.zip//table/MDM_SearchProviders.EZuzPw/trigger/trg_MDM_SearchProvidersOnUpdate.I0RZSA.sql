
-- =============================================
-- Author:		Nitish V. Gondkar
-- Create date: 19-Dec-2012
-- Description:	Fills the MDM_ImpProviders with Non Repeatative Provider Names
-- Required for Alert Providers
-- =============================================
CREATE TRIGGER [KYP].[trg_MDM_SearchProvidersOnUpdate] ON [KYP].[MDM_SearchProviders]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @alertID INT
		,@isMerged VARCHAR(2);

	SELECT @alertID = AlertID
	FROM Inserted

	--CAPAVE-133 , pd-95
	
	select x.alertid INTO #alertsActivityDate 
	from(select alertid from kyp.MDM_Alert with(nolock) 
		where AlertID=@alertID)x

	select alertid into #DatetoUpdate from (
	select alertid from #alertsActivityDate 
	union
	SELECT ChildAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ParentAlertID 
	in(	select alertid from #alertsActivityDate) AND isnull(IsDeleted, '0') = 0
	UNION
	SELECT ParentAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ChildAlertID 
	in(select alertid from #alertsActivityDate) AND isnull(IsDeleted, '0') = 0)x
		
		
	Update kyp.MDM_Alert set LastActivityDate = GETDATE()
		where alertid in(select alertid from #DatetoUpdate)
	--CAPAVE-133 , pd-95
	
	SELECT @isMerged = isMerged
	FROM kyp.MDM_Alert
	WHERE alertid = @alertID

	IF @isMerged = 'N'
	BEGIN
		EXEC calImpactedProviderCount @alertID
			,@isMerged
	END
	ELSE
	BEGIN
		SELECT @alertID = ParentAlertID
		FROM KYP.MDM_RelatedAlerts
		WHERE ChildAlertID = @alertID
			AND RelationshipType = 'Merged'

		EXEC calImpactedProviderCount @alertID
			,@isMerged
	END
END


GO

