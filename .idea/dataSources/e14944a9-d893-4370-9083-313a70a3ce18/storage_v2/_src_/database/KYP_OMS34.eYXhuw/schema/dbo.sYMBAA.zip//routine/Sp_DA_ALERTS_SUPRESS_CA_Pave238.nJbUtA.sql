


CREATE PROC [dbo].[Sp_DA_ALERTS_SUPRESS_CA_Pave238] as
Begin
Declare @date date
select @date=case when DIF=1 then MinDate else maxdate end from(
select day(MAX(createddate))-day(MIN(createddate)) Dif,MIN(Cast(createddate as DATE)) MinDate,
MAx(Cast(createddate as DATE)) MaxDate from KYP.MDM_ALERT A join( 
select YEAR(CreatedDate) year,month(createddate) Month,COUNT(distinct CAST(createddate as DATE)) cnt from KYP.MDM_ALERT 
where CAST(CREATEDDATE AS DATE) =(select MAX(CAST(A.CREATEDDATE AS DATE)) from KYP.MDM_ALERT a)
--where YEAR(CreatedDate)='2017'and month(createddate)='5'
group by YEAR(CreatedDate),month(createddate)
)B on YEAR(A.CreatedDate)=B.YEAR and month(A.createddate)=B.Month
)z


--drop table #IndParty
select A.PartyID  into #IndParty from kyp.PDM_Party A join Kyp.PDM_Provider B on A.PartyID=B.PartyID
join kyp.PDM_Person C on A.PartyID=C.PartyID
where A.CurrentModule='2'
union
select A.PartyID OwnerParty from kyp.PDM_Party A join Kyp.PDM_Owner B on A.PartyID=B.PartyID
join kyp.PDM_Person C on A.PartyID=C.PartyID
where A.CurrentModule='2'
---

--drop table #OrgParty
select A.PartyID  into #OrgParty from kyp.PDM_Party A join Kyp.PDM_Provider B on A.PartyID=B.PartyID
join kyp.PDM_Organization  C on A.PartyID=C.PartyID
where A.CurrentModule='2'
union
select A.PartyID OwnerParty from kyp.PDM_Party A join Kyp.PDM_Owner B on A.PartyID=B.PartyID
join kyp.PDM_Organization C on A.PartyID=C.PartyID
where A.CurrentModule='2'

---

--drop table #temp
select * into #temp from (
SELECT distinct 
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LastName ,w.FirstName  ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , nullif(W.NPI,'') NPI ,
nullif(w.ssn,'') ssn,nullif(w.taxid,'') taxid  ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME , LASTLOADDATE, 
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) createdate
 ,b.NPI rhs_npi,b.SSN rhs_ssn,b.TAXID rhs_TAXID
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #IndParty x
on a.WatchedPartyID  = x.PartyID 
join kyp.pdm_person w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_MedicaidTermination e
--on b.NPIID = e.Id 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Individual' and AlertGenCriteria like '%medicaid%'
and    CAST(A.CREATEDDATE AS DATE) >=@date ) p


-- medicaid org

--drop table #TEMP_ORG
SELECT * INTO #TEMP_ORG FROM (
SELECT distinct 
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LegalName   ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , 
nullif(W.NPI,'') NPI ,nullif(w.ssn,'') ssn,nullif(w.TIN,'') TIN ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME , LASTLOADDATE, 
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) createdate
 ,b.NPI rhs_npi,b.SSN rhs_ssn,b.TAXID rhs_TAXID
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #OrgParty  x
on a.WatchedPartyID  = x.PartyID 
join kyp.PDM_Organization  w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_MedicaidTermination e
--on b.NPIID = e.Id 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Institutional' and AlertGenCriteria like '%medicaid%'
and    CAST(A.CREATEDDATE AS DATE)>= @date ) l 



-- medicare individual

--drop table #temp3
select * into #temp3 from (
SELECT distinct 
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LastName ,w.FirstName  ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , W.NPI ,w.SSN ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME, 
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) k ,
b.NPI rhs_npi
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #IndParty  x
on a.WatchedPartyID  = x.PartyID 
join kyp.pdm_person w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_Medicare_IND_MIG_NPI_Summary e
--on b.NPIID = e.InitialSortOrder 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Individual'  and AlertGenCriteria like '%medicare%'
and    CAST(A.CREATEDDATE AS DATE) >= @date
union
SELECT distinct
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LastName ,w.FirstName  ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , W.NPI ,w.SSN ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME, 
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) k 
,b.NPI rhs_npi
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #IndParty  x
on a.WatchedPartyID  = x.PartyID 
join kyp.pdm_person w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_Medicare_Org_MIG_NPI_Summary e
--on b.NPIID = e.InitialSortOrder 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Individual'  and AlertGenCriteria like '%medicare%' and A.isTwoWayMatch=1
and    CAST(A.CREATEDDATE AS DATE) >= @date 
) p


-- org medicare
--drop table #temp4
select * into #temp4 from (
SELECT distinct 
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LegalName   ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , W.NPI ,w.SSN ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME ,
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) k,b.NPI rhs_npi
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #OrgParty   x
on a.WatchedPartyID  = x.PartyID 
join kyp.PDM_Organization  w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_Medicare_ORG_MIG_NPI_Summary e
--on b.NPIID = e.InitialSortOrder 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Institutional' and AlertGenCriteria like '%medicare%'
and    CAST(A.CREATEDDATE AS DATE) >= @date
union
SELECT distinct 
WATCHEDPARTYID,A.ALERTID,A.ALERTNO,WATCHEDPARTYNAME,noofmergedalerts,
w.LegalName   ,WATCHEDPARTYTYPE,MatchStatusIndicator,z.addressid , W.NPI ,w.SSN ,
z.AddressLine1 p_ad1,z.City p_city,z.State p_st,
PRIORITY,ACTIVITYSTATUS,ORGANIZATIONNAME,B.LNAME , B.FNAME ,
ALERTGENCRITERIA,NPIID,ISMERGED ,WATCHLISTNAME
,d.ADDRESSLINE1 , d.CITY,d.STATE ,d.ZIP,CAST(A.CREATEDDATE AS DATE) k ,b.NPI rhs_npi
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID  
join #OrgParty   x
on a.WatchedPartyID  = x.PartyID 
join kyp.PDM_Organization  w
on x.PartyID =w.partyid
join kyp.PDM_Location y
on x.PartyID = y.PartyID 
join  kyp.PDM_Address z
on y.addressid = z.addressid 
--join MCSIS_PECOS.dbo.MCSIS_Medicare_Ind_MIG_NPI_Summary e
--on b.NPIID = e.InitialSortOrder 
WHERE WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION' and A.isTwoWayMatch=1
and NPIID not like '%[a-z]%'
and WatchedPartyType = 'Institutional' and AlertGenCriteria like '%medicare%'
and    CAST(A.CREATEDDATE AS DATE) >= @date 
) p




--Alert Will not be suppress
--drop table #NotSuppress
select B.*,A.WatchlistName,C.NPIID,C.AlertGenCriteria into #NotSuppress from kyp.mdm_alert A join kyp.MDM_AlertDetail C on 
A.AlertID=C.AlertID join(
SELECT DISTINCT  WATCHEDPARTYID,ALERTID,ALERTNO,IsMerged ,noofmergedalerts  FROM #TEMP 
WHERE NPI=RHS_NPI 
OR TAXID= rhs_TAXID
OR ((LASTNAME+FIRSTNAME = LNAME + FNAME  OR LASTNAME+FIRSTNAME = FNAME +LNAME )
AND RIGHT(SSN,4) = RIGHT(RHS_SSN,4))
OR ((LASTNAME+FIRSTNAME = LNAME + FNAME  OR LASTNAME+FIRSTNAME = FNAME +LNAME )
AND ((LEFT(P_AD1 ,7) = LEFT(AddressLine1  ,7) AND P_ST = State  )))
-- POSSIBLE MATCH
--OR
--((LASTNAME+FIRSTNAME = LNAME + FNAME  OR LASTNAME+FIRSTNAME = FNAME +LNAME )
--AND ((P_CITY =City  AND P_ST = State  )))  --60% MATCH
		
OR ((LEFT(P_AD1 ,7) = LEFT(AddressLine1  ,7) and P_CITY =City  AND P_ST = State  )) 
union	
--2
select  DISTINCT  WATCHEDPARTYID,ALERTID,ALERTNO,IsMerged ,noofmergedalerts from #TEMP_ORG
where 
NPI = rhs_npi 
or TIN = rhs_TAXID 
or 
(((left(LegalName,10)= LEFT(ORGANIZATIONNAME,10) )  
and (LEFT(p_ad1 ,5) = LEFT(AddressLine1  ,5) AND p_st = state  )))
or (LEFT(p_ad1 ,10) = LEFT(AddressLine1  ,10) AND p_city = City and  p_st = State  )
union
--3
select DISTINCT  WATCHEDPARTYID,ALERTID,ALERTNO,IsMerged ,noofmergedalerts from #temp3 
where  
( 
 NPI = rhs_npi 
OR  
((LastName+FirstName = LName + fname  or LastName+FirstName = fname +LName )
and (LEFT(p_ad1 ,7) = LEFT(AddressLine1 ,7) AND  p_city=CITY and  p_st = STATE ))
--OR
--((LastName+FirstName = LName + fname  or LastName+FirstName = fname +LName )
--and ((ltrim(rtrim(p_city)) =ltrim(rtrim(CITY)) AND ltrim(rtrim(p_st)) = ltrim(rtrim(STATE)))
--))
)
and AlertGenCriteria  not like '%medicaid%'

union
--4
select  DISTINCT  WATCHEDPARTYID,ALERTID,ALERTNO,IsMerged ,noofmergedalerts from #temp4
where
(  
NPI = RHS_NPI 
OR (LEFT(LEGALNAME,10) = LEFT(ORGANIZATIONNAME ,10)  
AND ((LEFT(P_AD1 ,7) = LEFT(ADDRESSLINE1 ,7) AND p_city=CITY  and  P_ST = STATE )))
--OR (LEFT(LEGALNAME,10) = LEFT(ORGANIZATIONNAME ,10)  
--AND ((p_city = City  AND P_ST = STATE ) ))
)
and AlertGenCriteria not like '%medicaid%'
)B on A.AlertID=B.AlertID





---- alerts needs to be supressed from MCSIS

--drop table #alerts_supress_mcsis_generated
select * into #alerts_supress_mcsis_generated
from (
select DISTINCT  WATCHEDPARTYID,a.ALERTID,a.ALERTNO,IsMerged ,noofmergedalerts FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
where WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION' 
and  npiid not like '%[a-z]%'  
and    CAST(A.CREATEDDATE AS DATE) =@date
except
select WATCHEDPARTYID,ALERTID,ALERTNO,IsMerged,noofmergedalerts from #NotSuppress
)P

--drop table #alerts_supress_HMS_mcsis_generated
select * into #alerts_supress_HMS_mcsis_generated
from (

select WATCHEDPARTYID,A.ALERTID,A.ALERTNO,IsMerged ,noofmergedalerts FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
where WATCHLISTNAME = 'MEDICAID & MEDICARE EXCLUSION'
and NPIID  like '%[a-z]%'
and    CAST(A.CREATEDDATE AS DATE) >= @date    -- ALERTS FROM HMS NEED TO ELEMINATE
) p


-- ELEMINATE ALL INTERNAL WATCHLIST ALERTS--

--drop table #alerts_supress_gatekeeper_generated
select * into #alerts_supress_gatekeeper_generated
from (

SELECT WATCHEDPARTYID,A.ALERTID,A.ALERTNO,IsMerged ,noofmergedalerts
FROM KYP.MDM_ALERT A
JOIN KYP.MDM_ALERTDETAIL B
ON A.ALERTID = B.ALERTID 
JOIN  KYP.MDM_ALERTEXTNLOCATION C
ON A.ALERTID = C.ALERTID 
JOIN KYP.MDM_ALERTEXTNADDRESS D
ON C.ADDRESSID = D.ADDRESSID 
WHERE A.WATCHLISTNAME ='INTERNAL WATCHLIST'
AND CAST(A.CREATEDDATE AS DATE) >= @date 

) p



-- total alerts need to supress

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'dbo.SUPRESS_ALERTS') AND type in (N'U'))
DROP TABLE dbo.SUPRESS_ALERTS

select * into SUPRESS_ALERTS
from 
(
select * from #alerts_supress_mcsis_generated
union
select * from #alerts_supress_HMS_mcsis_generated
union
select * from #alerts_supress_gatekeeper_generated
) p



---True Positive:
Print('True-Positive')
select * from #NotSuppress

----cannot suppress
--Print('cannot suppress')
--select distinct A.*,B.ParentAlertID,C.WatchlistName,D.NPIID,D.AlertGenCriteria 
--from SUPRESS_ALERTS A left join KYP.MDM_RelatedAlerts B 
--on A.AlertID=B.ChildAlertID
--join kyp.MDM_Alert C on A.AlertID=C.AlertID
--join kyp.MDM_AlertDetail D on A.AlertID=d.AlertID
--except
--select distinct A.*,B.ParentAlertID,C.WatchlistName,D.NPIID,D.AlertGenCriteria from SUPRESS_ALERTS A 
--left join KYP.MDM_RelatedAlerts B 
--on A.AlertID=B.ChildAlertID
--join kyp.MDM_Alert C on A.AlertID=C.AlertID
--join kyp.MDM_AlertDetail D on A.AlertID=d.AlertID
--where (A.IsMerged='N' and A.NoOfMergedAlerts='0') or A.IsMerged='Y'

Print('suppress')
select distinct A.*,B.ParentAlertID,C.WatchlistName,D.NPIID,D.AlertGenCriteria 
from SUPRESS_ALERTS A 
left join KYP.MDM_RelatedAlerts B 
on A.AlertID=B.ChildAlertID
join kyp.MDM_Alert C on A.AlertID=C.AlertID
join kyp.MDM_AlertDetail D on A.AlertID=d.AlertID
--where (A.IsMerged='N' and A.NoOfMergedAlerts='0') or A.IsMerged='Y'
end


GO

