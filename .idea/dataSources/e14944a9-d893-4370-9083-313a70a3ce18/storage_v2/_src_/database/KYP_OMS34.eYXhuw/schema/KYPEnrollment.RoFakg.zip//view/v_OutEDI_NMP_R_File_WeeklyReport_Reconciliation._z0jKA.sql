



CREATE VIEW [KYPEnrollment].[v_OutEDI_NMP_R_File_WeeklyReport_Reconciliation] as
SELECT distinct
ac.npi BallingNPI,ac.OwnerNo,ac.ServiceLocationNo,ac.ProviderTypeCode
,A.NPI GroupRenderingNPI,left(A.ProviderTypeCode,1) GroupRenderingProviderType,raff.AffiliationStartDate,raff.AffiliationEndDate
from KYPEnrollment.pAccount_RenderingAffiliation RAff
join KYPEnrollment.pADM_Account Ac on raff.AccountID=ac.AccountID
join KYPEnrollment.pADM_Account A on isnull(raff.AffiliatedAccountID,0)=a.AccountID
where raff.AffiliatedAccountID is not null
and raff.TypeAffiliation like '%MIDLEVEL%'
and Ac.IsDeleted=0
and A.IsDeleted=0
and Ac.ProviderTypeCode<>'100' --Added to eliminate Mixed Group records


GO

