
CREATE VIEW [KYPEnrollment].[v_ModalityData] AS
SELECT  
ROW_NUMBER() over(order by M.PartyId Desc) As RID,
S.Description AS ServiceModality,
ISNULL(M.LicenseNumber,M.ModalityDocNumber)  AS LicenseNumber,
M.ReqTreatmentComp AS TreatmentComponent,
P.ParentPartyID,P.AccountID,M.PartyId AS ModalityPartyId
FROM KYPEnrollment.pAccount_PDM_Modalities M
INNER JOIN KYPEnrollment.pAccount_PDM_Party P on M.PartyId = P.PartyID
INNER JOIN KYP.LK_Screening S on M.ModlityCode = S.Abreviation
AND S.TypeID = 130
AND P.IsDeleted=0


GO

