

CREATE VIEW [dbo].[view_CitiesListForCounty] AS
	SELECT B.ID AS ID,A.CityCode AS CityCode,A.CityDescription AS CityName,CountyCode AS CountyCode,CountyDescription AS CountyName
	FROM dbo.CityStateCountyDetails A join CityDetails B on A.CityCode=B.CityCode WHERE A.State = 'CA'
	INTERSECT
	SELECT 
		CD.ID ID,
		CD.CityCode AS CityCode,
		CD.CityDescription AS CityName,
		CCD.CountyCode AS CountyCode,
		CCD.CountyDescription AS CountyName
	FROM 
		CityDetails CD,
		CountyDetails CCD
	WHERE
		CD.State = CCD.State AND 
		CD.State = 'CA' AND 
		CCD.State = 'CA'


GO

