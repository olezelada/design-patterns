CREATE PROCedure [KYP].[p_InsertPDMLicense]
(@PartyID int
 ,@LicenseState varchar(50)=NULL
 ,@LicenseAuthority varchar(100)= NULL
 ,@EffectiveDate datetime =NULL
 ,@ExpiryDate datetime = NULL
 ,@LicenseType varchar(25)=NULL
 ,@LicenseSubType varchar(25)=NULL
 ,@LicenseCode varchar(25)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime =NULL
 ,@ModifiedBy int=NULL
 ,@DateModified datetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[PDM_License]
           ([PartyID]
           ,[LicenseState]
           ,[LicenseAuthority]
           ,[EffectiveDate]
           ,[ExpiryDate]
           ,[LicenseType]
           ,[LicenseSubType]
           ,[LicenseCode]
           ,[Remarks]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@LicenseState
           ,@LicenseAuthority
           ,@EffectiveDate
           ,@ExpiryDate
           ,@LicenseType
           ,@LicenseSubType
           ,@LicenseCode
           ,@Remarks
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[PDM_License]')

end


GO

