
CREATE PROCEDURE [KYP].[p_ExecutiveUpdateEmail]
AS
BEGIN
	DECLARE 
		--COUNT Variables for Applications & Alerts
		@ApplnRec INT,
		@ApplnClosed INT,
		@ApplnRej INT,
		@ApplnAppr INT,
		@ApplnPend INT,
		
		
		@AlrtsOIG INT,
		@AlrtsEPLS INT,
		@AlrtsExpLic INT,
		@AlrtsNPIDeact INT,
		@AlrtsSSADMF INT,
		@AlrtsSanctions INT,
		@AlrtsMedicaid INT,
		@AlrtsKYPWL INT,
		
		@AlrtsConfirmed INT,
		@ProvSusp INT,
		@ProvOIG INT,
		@ProvPIU INT,
		@AccountSuspension INT,
		@AccountTermination INT,
		@AccountDeactivation INT,
		@AccountUpdated INT,
		@EnrollmentRecordUpdated  INT,
		@LetterSenttoProvider INT, 
		@ProviderNotification INT,
		@ReEnrollmentInitiation INT, 
		@ReferforInvestigation INT,
		@RefertoLegal INT,
		@NewKYPWatchlistCount INT,
--Start-CAMR-31-For new watchlist 'S&I Watchlist'
		@AlertsSnICount INT,
--End-CAMR-31-For new watchlist 'S&I Watchlist'
		
		@body NVARCHAR(MAX),
		@EmailAddTo VARCHAR(500),		
		@EmailAddCC VARCHAR(500),
		@Sub VARCHAR(MAX),
		@StateCode VARCHAR(2),
		@ProvPIUBody VARCHAR(500),
		@ALIASNAME VARCHAR(100)
		
		SELECT TOP 1 @ALIASNAME = KYPALIAS FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
        
		IF (@ALIASNAME IS NULL OR @ALIASNAME = '')
		BEGIN
			SET @ALIASNAME = 'KYP';
		END
		SELECT @EmailAddTo = ReminderToMailID FROM KYP.MDM_ReminderMailID WHERE ReminderName ='KYPExecutiveEmailUpdateRecipient'
		SELECT @EmailAddCC = ReminderToMailID FROM KYP.MDM_ReminderMailID WHERE ReminderName ='KYPExecutiveEmailUpdateCC'
		
		--------------------------------------------------------------------------------------------
		--ALERT COUNTS
		--------------------------------------------------------------------------------------------
		--Alerts Count Generated for GSA EPLS Last Week
		SELECT @AlrtsEPLS = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'SAM' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
		
		--Alerts Count Generated for OIG LEIE Last Week
		SELECT @AlrtsOIG = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'OIG LEIE' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
			
		--Alerts Count Generated for S&I Watchlist Last Week
		SELECT @AlertsSnICount = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'S&I Watchlist' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
		
		--Alerts Count Generated for Expired License Last Week
		SELECT @AlrtsExpLic = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'License Status' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
		
		--Alerts Count Generated for NPI Deactivation License Last Week
		SELECT @AlrtsNPIDeact = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'NPI Issues' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)	
		
		--Alerts Count Generated for SSA DMF License Last Week
		SELECT @AlrtsSSADMF = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'SSA DMF' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)	
		
		--Alerts Count Generated for Sanction Status License Last Week
		SELECT @AlrtsSanctions = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'Sanction Status' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)	
		
		--Alerts Count Generated for Sanction Status License Last Week
		SELECT @AlrtsMedicaid = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'Medicaid & Medicare Exclusion' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
			
			--Alerts Count Generated for KYP WatchList Last Week
			-- KYP Watchlist is renamed to Internal Watchlist /*KYP-9462*/
		SELECT @AlrtsKYPWL = COUNT(AlertID) FROM KYP.MDM_Alert WHERE WatchlistName = 'Internal Watchlist' AND 
		DateInitiated BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
			
				
		------------------------------------------------------------------------------------
		--Alerts Count confirmed last week
		SELECT @AlrtsConfirmed = COUNT(AlertID) FROM KYP.MDM_Alert WHERE IsMerged = 'N' AND
		(MatchStatusIndicator = 'C'
				OR
		1<= (SELECT COUNT(ChildAlertID) FROM KYP.MDM_RelatedAlerts 
				WHERE ParentAlertID = KYP.MDM_Alert.AlertID 
				AND 1 <= (SELECT COUNT(*) FROM KYP.MDM_Alert 
						  WHERE AlertID = ChildAlertID 
						  AND MatchStatusIndicator != 'C')
			)
		)
		AND DateConfirmed BETWEEN
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
		
		------------------------------------------------------------------------------------
		--Providers Counts for Identified for Suspension last week
		--SELECT @ProvSusp = COUNT(DISTINCT(ProviderMedicaidID)) FROM KYP.MDM_Alert AL INNER JOIN
		--KYP.MDM_AlertResolution A ON AL.AlertID = A.AlertID AND AL.WFStatus = 'Completed'
		--INNER JOIN KYP.MDM_AlertPvdSuspension B 
		--	ON A.ResolutionID = B.ResolutionID 
		--	AND  ISNULL(B.IsDeleted,0) = 0			
		--WHERE A.IsDeleted = 0 AND A.ResolutionType = 'Provider Suspension'
		--AND A.ResolutionDate BETWEEN 
		--	DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
		--	AND 
		--	DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
			
		------------------------------------------------------------------------------------
		--Providers Counts for Identified for OIG Referral last week
		SELECT @ProvOIG = COUNT(DISTINCT(ProviderMedicaidID)) FROM KYP.MDM_Alert AL INNER JOIN
		KYP.MDM_AlertResolution A ON AL.AlertID = A.AlertID AND AL.WFStatus = 'Completed'
		INNER JOIN KYP.MDM_AlertOIGReferral B 
			ON A.ResolutionID = B.ResolutionID 
			AND ISNULL(B.IsDeleted,0) = 0 			
		WHERE A.IsDeleted = 0 AND A.ResolutionType = 'OIG Referral'
		AND A.ResolutionDate BETWEEN 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
			AND 
			DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)		
			
		------------------------------------------------------------------------------------
		--Providers Counts for Referred to State Program Integrity Unit 
		SELECT @StateCode = StateCode FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
		IF @StateCode = 'NM'
			BEGIN
				SELECT @ProvPIU = COUNT(DISTINCT(ProviderMedicaidID)) FROM KYP.MDM_Alert AL INNER JOIN
				KYP.MDM_AlertResolution A ON AL.AlertID = A.AlertID AND AL.WFStatus = 'Completed' 
				INNER JOIN KYP.MDM_AlertPIUReferral B 
					ON A.ResolutionID = B.ResolutionID 
					AND B.IsDeleted = 0 
					AND B.ReferalMailSent = 1
				WHERE A.IsDeleted = 0 AND A.ResolutionType = 'Refer to Program Integrity'
				AND B.ReferralSendDate BETWEEN 
					DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
						AND 
					DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
				/*
				  Modified By : Shamim Ansari
				  Modified Date : 02 May 2014
				  Reviwed By : Vinoth Ramesh
				  Purpose : http://jira/browse/KYP-6696
				  Before Changed : '# Providers referred to the State Program Integrity Unit'
				  After Changed : '# Providers referred to Program Integrity'
				
				*/		
				SET @ProvPIUBody ='<tr>
								<td># Providers referred to Program Integrity</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@ProvPIU) + '</td>
							</tr>'
			END
		ELSE
		BEGIN
				SELECT @ProvPIU = COUNT(DISTINCT(ProviderMedicaidID)) FROM KYP.MDM_Alert AL INNER JOIN
				KYP.MDM_AlertResolution A ON AL.AlertID = A.AlertID AND AL.WFStatus = 'Completed' 
				INNER JOIN KYP.MDM_AlertPIUReferral B 
					ON A.ResolutionID = B.ResolutionID 
					AND B.IsDeleted = 0 
					AND B.ReferalMailSent = 1
				WHERE A.IsDeleted = 0 AND A.ResolutionType = 'Refer to Program Integrity'
				AND B.ReferralSendDate BETWEEN 
					DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7)
						AND 
					DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
				/*
				  Modified By : Shamim Ansari
				  Modified Date : 02 May 2014
				  Reviwed By : Vinoth Ramesh
				  Purpose : http://jira/browse/KYP-6696
				  Before Changed : '# Providers referred to the State Program Integrity Unit'
				  After Changed : '# Providers referred to Program Integrity'
				
				*/			
				SET @ProvPIUBody ='<tr>
								<td># Providers referred to Program Integrity</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@ProvPIU) + '</td>
							</tr>'
		END		
		
		------------------------------------------------------------------------------------
		--Providers Counts for Newly added Resolutions
		CREATE TABLE #TEMPRESOLUTIONCOUNT
		(
			ResolutionType VARCHAR(50),
			TotalResolutions INT
		)

		INSERT INTO #TEMPRESOLUTIONCOUNT 
			SELECT * FROM 
			(
				SELECT ResolutionType, COUNT(ResolutionID) AS TotalResolutions
				FROM KYP.MDM_Alert AL INNER JOIN
				KYP.MDM_AlertResolution A ON AL.AlertID = A.AlertID AND AL.WFStatus = 'Completed'
				WHERE	(
							A.ResolutionType NOT IN ('Send to State', 'Send to Xerox', 'Temp') 
							AND (
								ResolutionDate BETWEEN  
								DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7) 
								AND 
								DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1)
								)
							AND A.ResolutionType IS NOT NULL
							AND	ISNULL(A.IsDeleted, 0) = 0
						)
				GROUP BY ResolutionType
			) AS A
			
		SELECT @AccountSuspension = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Account Suspension'
		SELECT @AccountTermination = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Account Termination'
		--SELECT @AccountDeactivation = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Account Deactivation'
		SELECT @AccountUpdated = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Account Updated'
		SELECT @EnrollmentRecordUpdated = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Enrollment Record Updated'
		SELECT @LetterSenttoProvider = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Letter Sent to Provider'
		SELECT @ProviderNotification = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Provider Notification'
		SELECT @ReEnrollmentInitiation = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Re-Enrollment Initiation'
		SELECT @ReferforInvestigation = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Refer for Investigation'
		SELECT @RefertoLegal = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Refer to Legal'
		SELECT @NewKYPWatchlistCount = TotalResolutions FROM #TEMPRESOLUTIONCOUNT WHERE ResolutionType = 'Add to Internal Watchlist'
		
		TRUNCATE TABLE #TEMPRESOLUTIONCOUNT
		DROP TABLE #TEMPRESOLUTIONCOUNT

		------------------------------------------------------------------------------------
		--EMAIL PARAMETERS
		------------------------------------------------------------------------------------
		SET @Sub = '' + @ALIASNAME + ' Weekly Updates'

		SET @body = '<HTML><BODY>' + 
					'' + @ALIASNAME + ' weekly updates for ' + 
					CONVERT(VARCHAR(50),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -7),101) + 
					' to ' + 
					CONVERT(VARCHAR(50),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), -1),101) + 
					+ '<BR><BR>
						<table border = 1>
							<tr>
								<th bgcolor="#C0C0C0"> Alerts </th> <th bgcolor="#C0C0C0"> Total </th>
							</tr>
							
							<tr>
								<td># OIG Alerts generated
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsOIG) + '</td>
							</tr>
							
							<tr>
								<td># SAM Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsEPLS) + '</td>
							</tr>
							
							<tr>
								<td># License Status Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsExpLic) + '</td>
							</tr>
							
							<tr>
								<td># NPI Issues Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsNPIDeact) + '</td>
							</tr>
							
							<tr>
								<td># SSA DMF Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsSSADMF) + '</td>
							</tr>
							
							<tr>
								<td># Sanction Status Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsSanctions) + '</td>
							</tr>
							<tr>
								<td># Medicaid & Medicare Exclusion Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsMedicaid) + '</td>
							</tr>
							<tr>
								<td># Internal Watchlist Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsKYPWL) + '</td>
							</tr>
							<tr>
								<td># S&I Watchlist Alerts generated</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlertsSnICount) + '</td>
							</tr>
							
							
							<tr>
								<td># Alert confirmed</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@AlrtsConfirmed) + '</td>
							</tr>
							
							<tr>
								<td># Providers referred to OIG</td>
								<td align="Right">' + CONVERT(VARCHAR(50),@ProvOIG) + '</td>
							</tr>'
							+@ProvPIUBody+
							
							'<tr>
								<td># Providers identified for Account Suspension</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@AccountSuspension, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Account Termination</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@AccountTermination, 0)) + '</td>
							</tr>

							<tr>
								<td># Providers identified for Add to Internal Watchlist</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@NewKYPWatchlistCount, 0)) + '</td>
							</tr>

							<tr>
								<td># Providers identified for Updating the Account</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@AccountUpdated, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Updating the Enrollment Record</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@EnrollmentRecordUpdated, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Letter Sent to Provider</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@LetterSenttoProvider, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Provider Notification</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@ProviderNotification, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Re-Enrollment Initiation</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@ReEnrollmentInitiation, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Refer for Investigation</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@ReferforInvestigation, 0)) + '</td>
							</tr>
							
							<tr>
								<td># Providers identified for Refer to Legal</td>
								<td align="Right">' + CONVERT(VARCHAR(50), ISNULL(@RefertoLegal, 0)) + '</td>
							</tr>					
						</table>
						<BR>
						<BR>
						<BR>
						Disclaimer: < This message was automatically generated by the ' + @ALIASNAME + ' application. >
						</BODY>
						</HTML>
						'

	EXEC msdb.dbo.sp_send_dbmail
		@profile_name = 'administrator', -- replace with your SQL Database Mail Profile 
		@body = @body,
		@body_format ='HTML',		
		@recipients = @EmailAddTo,
		@copy_recipients = @EmailAddCC,
		@subject = @Sub ;
		
	SET NOCOUNT ON;
    
END


GO

