-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Payment Detail recive 3 parametros
-- @partyIdPortal party id old del portal,	@partyIdOMS nuevo party id de account, @lastActionUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_PaymentDetail]
	@partyIdPortal INT,
	@partyIdOMS INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF((SELECT COUNT([PaymentDetailID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_PaymentDetail] WHERE PartyID = @partyIdPortal)>0)
	BEGIN
	INSERT INTO [KYPEnrollment].pAccount_PDM_PaymentDetail
	(PartyID ,
	TypeOfPayment ,
	CardNumber ,
	CCV ,
	NameOnCard ,
	ExpirationDate ,
	Branch ,
	BankpAccountNumber ,
	RoutingNumber ,
	BankName ,
	StreetName ,
	City ,
	ZipPlus4 ,
	County ,
	StateTrans ,
	[LastAction],
	[LastActionDate],
	[LastActorUserID],
	[LastActionApprovedBy],
	[CurrentRecordFlag],
	FeeAmount ,
	isSameAppFee)
	SELECT @partyIdOMS
	,[TypeOfPayment]
	,[CardNumber]
	,[CCV]
	,[NameOnCard]
	,[ExpirationDate]
	,[Branch]
	,[BankAccountNumber]
	,[RoutingNumber]
	,[BankName]
	,[StreetName]
	,[City]
	,[ZipPlus4]
	,[County]
	,[StateTrans]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[FeeAmount]
	,[isSameAppFee]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_PaymentDetail] WHERE PartyID = @partyIdPortal
	SELECT @message = 'New PaymentDetail ' + CONVERT(char(10), 'PaymentDetail copy')
	RAISERROR(@message, 0, 1) WITH NOWAIT 
	END					
END


GO

