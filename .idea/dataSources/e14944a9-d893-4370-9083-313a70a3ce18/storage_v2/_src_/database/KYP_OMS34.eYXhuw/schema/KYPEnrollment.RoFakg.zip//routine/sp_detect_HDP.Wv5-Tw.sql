-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <11/09/2017>
-- Description:	<Procedure to detect and create a new account in case of Heroyn Detox Modality>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_detect_HDP](
	@new_Account_Id int,
	@new_Party_Id INT,
	@last_Action_User_ID VARCHAR(100),
	@application_Id INT
	)
	
AS
BEGIN
	DECLARE @new_acc int,@date_created DATE,@max_case int;
	SET @date_created =  GETDATE();
	SET NOCOUNT ON;
	
	if (select COUNT(ModalityId) from KYPEnrollment.pAccount_PDM_Modalities m INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON m.PartyId=p.PartyID where ModlityCode='HDP' and m.Deleted=0 and p.AccountID=@new_Account_Id) >= 1
	BEGIN
	
	
		SELECT @max_case = (MAX(CASEID) +1) FROM KYP.ADM_Case;
		EXEC [KYPEnrollment].[sp_Create_Account_TypeCode] @new_Party_Id,@application_Id,@last_Action_User_ID,'1','risk',1,@max_case,0,'051','F';
		
	END
END


GO

