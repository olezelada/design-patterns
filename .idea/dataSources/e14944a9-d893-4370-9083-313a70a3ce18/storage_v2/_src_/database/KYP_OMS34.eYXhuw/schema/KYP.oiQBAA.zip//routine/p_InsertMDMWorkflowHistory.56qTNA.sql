
-- =============================================
-- Author:		Rajesh Kumar Singh
-- Create date: 08 Spetember 2015
-- Description:	Added Assignee Column 
-- Reviewed By: Hareesha
-- =============================================

CREATE PROCEDURE [KYP].[p_InsertMDMWorkflowHistory] 
	
	@AlertID VARCHAR(50),
	@WorkflowStatus VARCHAR(50) = NULL,
	@DateTime DATETIME,
	@UserID VARCHAR(50),
	@UserFullName VARCHAR(100),
	@Notes VARCHAR(MAX),
	@RoleName VARCHAR(50) = NULL,
	@MajorStatus VARCHAR(50),
	@MinorStatus VARCHAR(50),
	@ActivityStatus VARCHAR(50),
	@Description VARCHAR(100),
	@EndDateTime DATETIME,
	@NoOfDays INT,
	@Type VARCHAR(50) = 'HISTORY',
	@SortDateTime DATETIME,
	@Assignee VARCHAR(100)
AS
BEGIN
	INSERT INTO [KYP].[MDM_WorkflowHistory]
           ([AlertID]
           ,[WorkflowStatus]
           ,[DateTime]
           ,[UserID]
           ,[UserFullName]
           ,[Notes]
           ,[RoleName]
           ,[MajorStatus]
           ,[MinorStatus]
           ,[ActivityStatus]
           ,[Description]
           ,[EndDateTime]
           ,[NoOfDays]
           ,[Type]
           ,[SortDateTime]
           ,[Assignee])
     VALUES
           (@AlertID
           ,@WorkflowStatus
           ,@DateTime
           ,@UserID
           ,@UserFullName
           ,@Notes
           ,@RoleName
           ,@MajorStatus
           ,@MinorStatus
           ,@ActivityStatus
           ,@Description
           ,@EndDateTime
           ,@NoOfDays
           ,@Type
           ,@SortDateTime
           ,@Assignee)
END


GO

