



/* ==========================================================
-- Author:		<Mvillarroel>

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_PartyAssociate_Profile]
@accountid int,
--@profileid_before varchar(40), --commented by Swati as it is not being used anywhere in the procedure
@profileid_after varchar(40)

 
AS

BEGIN
declare
@taxid varchar(10),
@cont int,
@uniqueid int

CREATE TABLE #profileafter
	(
		ID			INT PRIMARY KEY IDENTITY(1,1),
		IdUnique	int
		)

select @taxid=ein from kypenrollment.pADM_Account   where accountid=@accountid
--**
INSERT INTO #profileafter
SELECT UniqueMOCAsProfileTINWiseID
      FROM(SELECT *,ROW_NUMBER() OVER (PARTITION BY MOCAType,SSNorTIN,FirstName,LastName,LegalName ORDER BY UniqueMOCAsProfileTINwiseID) RowNumber
                  FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW
                  WHERE CurrentRecordFlag = 0 AND
                        NOT EXISTS (SELECT 1
                                          FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW1
                                          WHERE ISNULL(UMW.SSNorTIN,'')       = ISNULL(UMW1.SSNorTIN,'') AND 
                                                ISNULL(UMW.FirstName,'')      = ISNULL(UMW1.FirstName,'') AND
                                                ISNULL(UMW.LastName,'')       = ISNULL(UMW1.LastName,'') AND 
                                                ISNULL(UMW.LegalName,'')      = ISNULL(UMW1.LegalName,'') AND
                                                UMW1.ProfileID                = @profileid_after AND
                                                UMW1.TaxID                    = @TaxID AND
                                                UMW1.CurrentRecordFlag        = 1) AND
                        ProfileID   = @profileid_after AND
                        TaxID       = @TaxID) ILV
      WHERE ILV.RowNumber = 1
UNION
SELECT UniqueMOCAsProfileTINWiseID
      FROM KYPEnrollment.UniqueMOCAsProfileTINwise
      WHERE CurrentRecordFlag = 1 AND
            IsDeleted         = 0 AND
            ProfileID         = @profileid_after AND
            TaxID             = @TaxID
--**

--update currentrecordflag in the Party_associate with the status of de partys for the account
update assoc set currentrecordflag=part.currentrecordflag
from 
kypenrollment.pAccount_party_Associate assoc  inner join kypenrollment.pAccount_PDM_Party part on assoc.PartyID=part.PartyID 
where 
assoc.AccountID=@accountid
--merge the mocas of new profile to account 
 set @cont=1
 
WHILE @cont <= (SELECT COUNT(*) FROM #profileafter)
BEGIN
  SELECT @UniqueID=IdUnique 
  FROM #profileafter WHERE ID = @cont
  exec [KYPEnrollment].[sp_Update_PartyAssociate] @uniqueid
  set @cont=@cont+1
END

--if mainpartyid belong to profile distint of partyid then change mainpartyid
CREATE TABLE #difprofile
	(
		ID			INT PRIMARY KEY IDENTITY(1,1),
		mainparty 	int,
		party       int,
		profmain varchar(40),
		profparty varchar(40),
		changed bit 
		)
insert into #difprofile 
select associate.MainPartyID ,associate.PartyID,associate.profmain,profpart.ProfileID as profparty,0 as changed
from 
(select assoc.*,prof.ProfileID as profmain from 
kypenrollment.pAccount_TaxID_Associate tax inner join 
kypenrollment.pAccount_party_Associate assoc on tax.accountid=assoc.accountid inner join kypenrollment.pAccount_PDM_Party part on assoc.MainPartyID=part.PartyID 
inner join kypenrollment.pAccount_BizProfile_Details prof on part.accountid=prof.AccountID 
where tax.TaxID=@taxid and assoc.CurrentRecordFlag=1) associate inner join kypenrollment.pAccount_BizProfile_Details profpart on associate.AccountID=profpart.accountid
where associate.profmain<>profpart.profileid
declare
@mainpar int,@parpar int
set @cont=1
WHILE @cont <= (SELECT COUNT(*) FROM #difprofile)
begin
if (select changed from #difprofile where ID=@cont)=0
begin
 select @mainpar=mainparty,@parpar=party from #difprofile where ID=@cont
 update kypenrollment.pAccount_Party_Associate set mainpartyid=@parpar where MainPartyID=@mainpar
 update #difprofile set changed=1 where mainparty=@mainpar 
end
set @cont=@cont+1
end 

drop table #difprofile
drop table #profileafter

 
end


GO

