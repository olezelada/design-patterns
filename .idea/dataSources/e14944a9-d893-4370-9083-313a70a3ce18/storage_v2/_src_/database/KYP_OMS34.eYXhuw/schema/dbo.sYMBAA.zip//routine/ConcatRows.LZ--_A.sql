




CREATE FUNCTION [dbo].[ConcatRows]
(
   @ColumnName varchar(50),
   @ScreeningId varchar(50)
)
returns nvarchar(max)
AS
BEGIN
  
DECLARE @returnString VARCHAR(8000)  
DECLARE @EXCLUDATE VARCHAR(25) 
DECLARE @CheckResult VARCHAR(25)
  
	IF @ColumnName='EXCLUTYPE' 
		BEGIN
			SELECT @returnString = COALESCE(@returnString  +',','') +(SELECT DESCRIPTION FROM KYP.HMS_ProvORG_OIGLEIE_ExclusionType B WHERE ISNULL(B.EXCLTYPE,'') = ISNULL(KYP.ReportWatchListData.EXCLUTYPE,''))  
			FROM  KYP.ReportWatchListData where ScreeningID= @ScreeningId
		END
		
		IF @returnString IS NOT NULL AND @returnString <> ''
				BEGIN 
					SET @returnString = 'Type: related to '+@returnString 
				END
	ELSE IF @ColumnName='EXCLUDATE' 
		BEGIN
			SELECT @EXCLUDATE=EXCLUDATE FROM KYP.ReportWatchListData where ScreeningID= @ScreeningId 
			
				IF @EXCLUDATE IS NOT NULL AND @EXCLUDATE <> ''
					BEGIN
						SET @EXCLUDATE=CONVERT(VARCHAR(25), CONVERT(DATETIME, @EXCLUDATE), 101)
					END 		
			SELECT @returnString = COALESCE(@returnString  +',','') +@EXCLUDATE FROM  KYP.ReportWatchListData where ScreeningID= @ScreeningId AND EXCLUDATE IS NOT NULL AND EXCLUDATE <> ''
		
		IF @returnString IS NOT NULL AND @returnString <> ''
				BEGIN 
					SET @returnString = 'Date: '+@returnString 
				END
		END
	ELSE IF @ColumnName='ACTIONDATE' 
		BEGIN
			SELECT @returnString = COALESCE(@returnString   +',','')+ISNULL(ACTIONDATE,'')  FROM  KYP.ReportWatchListData where ScreeningID= @ScreeningId AND ACTIONDATE IS NOT NULL AND ACTIONDATE <> ''
		
		IF @returnString IS NOT NULL AND @returnString <> ''
				BEGIN 
					SET @returnString = 'Date: '+@returnString 
				END
		END
	ELSE IF @ColumnName='ACTIONTYPE' 
		BEGIN
			SELECT @returnString = COALESCE(@returnString  +',','') +ISNULL(ACTIONTYPE,'')  FROM  KYP.ReportWatchListData where ScreeningID= @ScreeningId AND ACTIONTYPE IS NOT NULL AND ACTIONTYPE <> ''
		
		IF @returnString IS NOT NULL AND @returnString <> ''
				BEGIN 
					SET @returnString = 'Agency: related to '+@returnString 
				END
		END 
	ELSE IF @ColumnName='DisclosedData' 
		BEGIN
			SELECT @returnString = COALESCE(@returnString  +',','')+ISNULL(DisclosedData,'')  FROM  KYP.v_MoreValueDetail where ScreeningID= @ScreeningId and AttributeName='LIC'
		END
	--------------------------------- Modification for 3.3 req 14 Started----------------------------------------	
	ELSE IF(@ColumnName = 'AddressSection' OR @ColumnName = 'RelativeSection' OR @ColumnName = 'AKASection' OR @ColumnName = 'SSNFraudAlertSection' OR @ColumnName = 'CriminalSection' OR @ColumnName = 'LienJudgmentSection' OR @ColumnName = 'InfractionSection' OR @ColumnName = 'BankruptciesSection' OR @ColumnName = 'BusinessResponseDetail' OR @ColumnName = 'FillingOfficeName' OR @ColumnName = 'SanctionsRecord' OR @ColumnName = 'CriminalRecord' OR @ColumnName = 'LienJudgeDolanRecord')
		BEGIN
			SELECT @returnString =COALESCE(@returnString  +',','')+ISNULL(Description,'')+','  FROM KYP.SDM_AdverseActionDetail WHERE ScreeningID= @ScreeningId AND TYPE = @ColumnName
		END	
	--------------------------------- Modification for 3.3 req 14 Ended----------------------------------------	
	ELSE IF @ColumnName='MatchResult' 
		BEGIN
			SELECT @CheckResult=MatchResult  FROM  KYP.v_MoreValueDetail where ScreeningID= @ScreeningId and AttributeName='LIC'
				IF @CheckResult IS NOT NULL AND @CheckResult <> ''
					BEGIN
						select @CheckResult =
						CASE 
						WHEN @CheckResult = 'T' THEN 'True' 
						WHEN @CheckResult = 'P' THEN 'Partial' 
						WHEN @CheckResult = 'U' THEN 'Unknown/Not Applicable' 
						WHEN @CheckResult = 'F' THEN 'Negative' 
						WHEN @CheckResult = 'X' THEN 'Not Found' 
						WHEN @CheckResult = 'Y' THEN 'Found (Not Disclosed)'
						END 
						
					END 
			SELECT @returnString = COALESCE(@returnString  +',','') +@CheckResult FROM  KYP.v_MoreValueDetail where ScreeningID= @ScreeningId and AttributeName='LIC'
		END 
SET @returnString = REPLACE(@returnString,',',CHAR(13)+CHAR(10)) 
RETURN LTRIM(RTRIM(@returnString))

END


GO

