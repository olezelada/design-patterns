
CREATE PROCEDURE [KYPEnrollment].[InsertUpdateMOCANewModel](
  @account_id INT,
  @party_id_account INT,
  @tax_id VARCHAR(100),
  @application_id INT,
  @party_id_app INT,
  @last_Action_User_ID VARCHAR(100),
  @accepted BIT,
  @application_type VARCHAR(50) = NULL
)
AS
BEGIN
 print 'InsertUpdateMOCANewModel'
 DECLARE @profile_id varchar(40)

 SELECT @profile_id = ProfileID
 FROM KYPEnrollment.pAccount_BizProfile_Details
 WHERE AccountID = @account_id
 
 if @tax_id is null
 select @tax_id=replace(ein,'-','') from kypportal.portalkyp.ppdm_organization where partyid=@party_id_app
-- select @tax_id=ein from kypenrollment.pADM_Account where AccountID=@account_id

 EXEC [KYPEnrollment].[Add_Association_TaxID_NewModel]@account_id,@party_id_account,@tax_id,@application_id,@party_id_app,@last_Action_User_ID,@accepted,@application_type;


 EXEC [KYPEnrollment].[Update_All_Account_NewModel] @account_id,@party_id_account,@tax_id,@application_id,@party_id_app,@last_Action_User_ID, @accepted,@application_type;

 


END


GO

