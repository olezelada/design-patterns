



CREATE PROCEDURE [KYPEnrollment].[Add_Association_TaxID_NewModel]
   @account_id             INT,
   @party_id_account       INT,
   @tax_id                 VARCHAR (100),
   @application_id         INT,
   @party_id_app           INT,
   @last_Action_User_ID    VARCHAR (100),
   @accepted               BIT,
   @application_type       VARCHAR (50) = NULL
AS
BEGIN
   SET  NOCOUNT ON

   IF @application_type = 'CHOW'
      BEGIN
         SET @accepted = 1;
      END

   DECLARE
      @date_Create   DATE,
      @profile_id    VARCHAR (40)
 --++
  --Ken-17328
  declare @ScreenedAppNo varchar(15)--Application number
  declare @ScreenedAccountNo varchar(20)--Account number
  declare @ScreenedOn smalldatetime
  
  -- 
    --mvc--
   DECLARE
      @npi       VARCHAR (10),
      @ownerno   VARCHAR (3),
      @packagename varchar(100)      

   SET @date_Create = GETDATE ()
   SELECT TOP 1
          @profile_id = ProfileID
   FROM KYPEnrollment.pAccount_BizProfile_Details
   WHERE AccountID = @account_id                    
   --mvc--
   SELECT @npi = npi,
          @ownerno = ownerno,
          @packagename=PackageName ,
          @ScreenedAccountNo=accountnumber
   FROM kypenrollment.padm_account
   WHERE accountid = @account_id
--ken-17328
   select @ScreenedAppNo=applicationno from kypportal.portalkyp.pADM_Application where partyid=@party_id_app 
   
   select t3.partyperssn,case when t3.partytype='Owner Person' then 'Individual Ownership' else 'Entity Ownership' end as typePortal,t3.PartyOrgtin, T3.ScreenedOn 
   into #screen
   from KYP.ADM_Case T1 inner join KYP.ADM_Application t2 on t1.Number=t2.applicationno 
   inner join KYP.view_DBChecksSummary T3 on t2.ApplicationID=t3.applicationid
   where  
   PartyType in ('Owner Person','Owner Organization') and
   T1.Number=@ScreenedAppNo 
   
   SELECT  par.PartyID, screen.ScreenedOn 
   into #ScreenedON
	FROM 
	[KYPPORTAL].[PortalKYP].[pPDM_Party] par
	left join kypportal.portalkyp.pPDM_Person per on  par.partyid=per.partyid
	left join kypportal.portalkyp.ppdm_organization org on org.partyid=par.partyid
	left join #screen screen on par.Type=screen.typePortal and isnull(replace(per.SSN,'-',''),'')=isnull(replace(screen.PartyPerSSN,'-',''),'')
	and ISNULL(replace(org.EIN,'-',''),'')=isnull(replace(screen.PartyOrgTIN,'-',''),'') 
    WHERE    ParentPartyID = @party_id_app
         AND (   Type  = 'Entity Ownership' OR Type = 'Individual Ownership')
         AND par.IsDeleted = 0 and isnull(par.isprepopulated,0)=0
   create nonclustered index idx_screen on #screenedon (partyid asc)
   
      
  --++
  --++
  -- date submitted
    declare @datesubmit smalldatetime
	SELECT  top 1 @datesubmit=tra.DateTracking 
	FROM KYPPORTAL.PortalKYP.pADM_Application ap
	INNER JOIN kypportal.PortalKYP.pApplicationHistoryTracking tra ON  ap.applicationNo = tra.applicationNumber  
	where 
	tra.applicationMilestone = 'Submitted'  and ap.PartyID = @party_id_app
	order by tra.DateTracking desc
	  
  --++
   CREATE TABLE #PartyPortal
   (
      PartyID          INT,
      ParentPartyID    INT,
      Type             VARCHAR (50),
      IsPrepopulated   BIT,
      TargetPath       VARCHAR (200),
      UUID             VARCHAR (200),
      Partyenroll      VARCHAR (200)
   )

   INSERT INTO #PartyPortal
      SELECT PartyID,
             ParentPartyID,
             Type,
             IsPrepopulated,
             TargetPath,
             UUID,
             SUBSTRING (
                targetpath,
                CHARINDEX ('pAccount_PDM_Party|PartyID|', TargetPath, 1) + 27,
                LEN (targetpath))
                AS partyenroll
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
       WHERE     (   (       ParentPartyID = @party_id_app
                         AND (   Type = 'SubcontractorEntity'
                              OR Type = 'SubcontractorIndividual'
                              OR Type = 'TransactionEntity'
                              OR Type = 'TransactionIndividual'
                              OR Type = 'Entity Ownership'
                              
                              OR Type = 'Individual Ownership'
                              OR Type = 'SignificantTransactionEntity'
                              OR Type = 'SignificantTransactionIndividual'
                              )
                              
                      OR (ParentPartyID IN
                             (SELECT PartyID
                                FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                               WHERE     ParentPartyID = @party_id_app
                                     AND (   Type = 'Entity Ownership'
                                          OR Type = 'Individual Ownership'
                                          OR type='SubcontractorEntity'
                                          OR Type = 'SignificantTransactionEntity'
                                          ))))
                  OR PartyID = @party_id_app)
             AND IsDeleted = 0;

   WITH PartyLevels (partyidlevel,
                     type,
                     IsPrepopulated,
                     partypadre,
                     partyabuelo,
                     partylevel,
                     partyenroll,
                     partyenrollmain,
                     UUID,
                     TargetPath,
                     Accepted,
                     IsPastOwner)
           AS (SELECT PartyID,
                      Type,
                      IsPrepopulated,
                      NULL,
                      NULL,
                      0 AS partylevel,
                      partyenroll,
                      NULL,
                      UUID,
                      TargetPath,
                      0,
                      0
                 FROM #PartyPortal
                WHERE ParentPartyID IS NULL
               UNION ALL
               SELECT p.PartyID,
                      p.Type,
                      p.IsPrepopulated,
                      pe.partyidlevel,
                      pe.partypadre,
                      partylevel + 1,
                      P.partyenroll,
                      NULL,
                      p.UUID,
                      p.TargetPath,
                      0,
                      0
                 FROM #PartyPortal AS p
                      INNER JOIN PartyLevels pe
                         ON p.ParentPartyID = pe.partyidlevel)
   SELECT *
     INTO #PartiesLevelTable
     FROM PartyLevels;

    --mvc partyenroll
   SELECT pl.*,
          pl.partyenroll as MainPartyID,
          pl.partyenroll AS partyIDEnrollment,
          case when part.partyid is null then @account_id  else part.accountid end as AccountID,
          CONVERT (VARCHAR (40), ' ') AS ProfileID,
          CONVERT (VARCHAR (10), ' ') AS npi,
          CONVERT (VARCHAR (3), '') AS ownerno
     INTO #Associations
     FROM #PartiesLevelTable pl
     left join kypenrollment.paccount_pdm_party part  ON (ISNULL (pl.partyenroll, '') = CONVERT (VARCHAR (10), part.partyid))
     
     
   UPDATE association
      SET association.ProfileID = details.ProfileID
     FROM KYPEnrollment.pAccount_BizProfile_Details details
          INNER JOIN #Associations association
             ON (association.AccountID = details.AccountID)

   UPDATE association
      SET association.Accepted = field.Accepted
     FROM #Associations association,
          [KYPPORTAL].[PortalKYP].[FieldValuesTracking] field
    WHERE     (   association.UUID = field.RowUUID
               OR association.TargetPath = field.TargetPath)
          AND field.ApplicationID = @application_id
          AND (IsPrepopulated IS NULL OR IsPrepopulated = 0)

   --mvc
   UPDATE association
      SET association.IsPastOwner = account.IsPastOwner,
          npi = account.npi,
          ownerno = account.ownerno
     FROM KYPEnrollment.pADM_Account account
          INNER JOIN #Associations association
             ON (association.AccountID = account.AccountID)
  
   DELETE #Associations
    WHERE (    ProfileID <> @profile_id
           AND ProfileID <> ''
           AND ProfileID IS NOT NULL);

   --validate duplicate moca
   --**
    declare @taxidprofileid int
	SET @taxidprofileid=0
	select @taxidprofileid=isnull(taxidprofileid,0) from kypenrollment.TaxIDProfile where profileID=@profile_id and TaxID=@tax_id
	--Taxid and profileid new, insert new records in the TaxIDProfile table
	 if  @taxidprofileid=0 
		  begin
		  Insert into kypenrollment.TaxIDProfile(profileID,taxID,CreatedBy,CreatedOn) values (@profile_id,@tax_id,@last_Action_User_ID,getdate())
		  SELECT @taxidprofileid = SCOPE_IDENTITY()
		  end
    --recovery all mocas actives for this  @taxidprofileid 
    

 
   --**

   CREATE TABLE #mocaexist
   (
      partyid     INT,
      type        VARCHAR (100),
      accountid   INT,
      ssn         VARCHAR (100),
      firstname   VARCHAR (200),
      lastname    VARCHAR (200),
      legalname   VARCHAR (200),
      Tin         VARCHAR (100),
      moca        VARCHAR (200)
   )

   INSERT INTO #mocaexist
      SELECT part.partyid,
             part.type,
             part.accountid,
             per.ssn,
             per.firstname,
             per.lastname,
             org.legalname,
             org.ein,
            ISNULL ( CONVERT (VARCHAR (200), per.ssn),'')+ 
              isnull ( CONVERT (VARCHAR (200), org.ein),'')+
              isnull (CONVERT (VARCHAR (200), org.legalname),'')+
              isnull (per.lastname, '') + isnull (per.firstname, '') 
                AS aux
        FROM  kypenrollment.paccount_pdm_party part
               LEFT JOIN kypenrollment.paccount_pdm_person per
                ON part.partyid = per.partyid
             LEFT JOIN kypenrollment.paccount_pdm_organization org
                ON part.partyid = org.partyid
       WHERE     part.CurrentRecordFlag = 1
             AND part.type IN ('Entity Ownership',
                               'Individual Ownership',
                               'SubcontractorIndividual',
                               'SubcontractorEntity',
                               'TransactionIndividual',
                               'TransactionEntity',
                               'SignificantTransactionEntity',
                               'SignificantTransactionIndividual')
             and                  
            part.IsDeleted=0 and part.CurrentRecordFlag=1 and part.taxIDprofileID =@taxidprofileid and 
            
            (part.MOCARelationshipEndDate is null  OR part.MOCARelationshipEndDate > GETDATE()) 

--the other always will be created
   INSERT INTO #mocaexist
      SELECT part.partyid,
             part.type,
             part.accountid,
             per.ssn,
             per.firstname,
             per.lastname,
             org.legalname,
             org.ein,
            ISNULL ( CONVERT (VARCHAR (200), per.ssn),'')+ 
              isnull ( CONVERT (VARCHAR (200), org.ein),'')+
              isnull (CONVERT (VARCHAR (200), org.legalname),'')+
              isnull (per.lastname, '') + isnull (per.firstname, '') 
                AS aux
        FROM #mocaexist taxp
             INNER JOIN kypenrollment.paccount_pdm_party part
                ON taxp.partyid = part.parentpartyid
             LEFT JOIN kypenrollment.paccount_pdm_person per
                ON part.partyid = per.partyid
             LEFT JOIN kypenrollment.paccount_pdm_organization org
                ON part.partyid = org.partyid
       WHERE     part.CurrentRecordFlag = 1
             AND part.type IN (
             'OtherOwnershipIndividual',
             'OtherOwnershipEntity'
             )
                                     
   SELECT
          @account_id as account_id_asso,
          @party_id_account as parent_party_acc,
          @PackageName as packagename,
          part.*,
              ISNULL ( CONVERT (VARCHAR (200), per.ssn),'')+ 
              isnull ( CONVERT (VARCHAR (200), org.ein),'')+
              isnull (CONVERT (VARCHAR (200), org.legalname),'')+
              isnull (per.lastname, '') + isnull (per.firstname, '') 
                AS moca
     INTO #associations1
     FROM #Associations part
          LEFT JOIN kypportal.portalkyp.ppdm_person per
             ON part.partyidlevel = per.partyid
          LEFT JOIN kypportal.portalkyp.ppdm_organization org
             ON part.partyidlevel = org.partyid
          
     where   
     (   part.IsPrepopulated IS NULL
         OR part.IsPrepopulated = 0)   


   SELECT  a.*
     INTO #associations2
     FROM #associations1 a
          LEFT JOIN #mocaexist b
             ON     a.type = b.type
                AND a.moca = b.moca
                --AND a.account_id_asso = b.accountid
    WHERE b.PartyID IS NULL
    -- mvc
    select distinct
   partyidlevel,	type,	IsPrepopulated,	partypadre,partyabuelo,	partylevel,	partyenroll,	partyenrollmain	,UUID	,TargetPath,	Accepted,	IsPastOwner	,MainPartyID,	partyIDEnrollment,	AccountID,	ProfileID,	npi,	ownerno
   into #associations3
   from #Associations2
  

BEGIN TRY

   --  1 level
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate,
                                                     MOCARelationshipStartDate,
                                                     TaxidProfileID,
                                                     LastMOCARelationshipUpdateBy,
													 LastMOCAUpdateBy ,
                                                     ScreenedOn,
                                                     ScreenedAppNo,
                                                     ScreenedAccountNo    )
      SELECT #Associations2.Type,
             NULL,
             #Associations2.account_id_asso,
             #Associations2.Partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             @datesubmit,
             @taxidprofileid ,
             'P',
             'P',
			 case when #Associations2.type IN ('Individual Ownership') then (select top 1 ScreenedOn from #ScreenedON screen where screen.partyid=partyidlevel )else null end,
             case when #Associations2.type IN ('Individual Ownership') then   @ScreenedAppNo else NULL END,
             case when #Associations2.type IN ('Individual Ownership') then @ScreenedAccountNo  ELSE NULL END

			 
        FROM #Associations2
       WHERE     #Associations2.type IN ('Individual Ownership',
                                         'SubcontractorIndividual',
                                         'SubcontractorEntity',
                                         'TransactionEntity',
                                         'TransactionIndividual',
                                         'SignificantTransactionEntity',
                                         'SignificantTransactionIndividual')
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND #Associations2.account_id_asso NOT IN
                    (SELECT AccountID
                       FROM #Associations2
                      WHERE IsPastOwner = 1)

   --not add entity ownership in packagename in (IGSP_P_DM  para physicians,IGSP_NP_AP       para allied)
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate,
                                                     MOCARelationshipStartDate,
                                                     TaxidProfileID,
                                                     LastMOCARelationshipUpdateBy,
                                                     LastMOCAUpdateBy,
													 ScreenedOn,
                                                     ScreenedAppNo,
                                                     ScreenedAccountNo )
      SELECT #Associations2.Type,
           NULL,
             #Associations2.account_id_asso,
             #Associations2.Partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             @datesubmit,
             @TaxidProfileID,
             'P',
             'P',
			 case when #Associations2.type IN ('Entity Ownership') then (select top 1 ScreenedOn from #ScreenedON screen where screen.partyid=partyidlevel )else null end,
             case when #Associations2.type IN ('Entity Ownership') then   @ScreenedAppNo else NULL END,
             case when #Associations2.type IN ('Entity Ownership') then @ScreenedAccountNo  ELSE NULL END

        FROM #Associations2
       WHERE     #Associations2.PackageName NOT IN
                    ('IGSP_P_DM', 'IGSP_NP_AP')
             AND #Associations2.type IN ('Entity Ownership')
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND #Associations2.account_id_asso NOT IN
                    (SELECT AccountID
                       FROM #Associations2
                      WHERE IsPastOwner = 1)

  
   --2 level
   --when father is new all party child must be created
  --for ownersubcontractor use table filter
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate,
                                                     MOCARelationshipStartDate,
                                                     TaxidProfileID
                                                     )
      SELECT 
              #Associations3.type,
             [KYPEnrollment].[pAccount_PDM_Party].PartyID,
             [KYPEnrollment].[pAccount_PDM_Party].AccountID,
             #Associations3.partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             --@datesubmit,
             NULL,
             NULL
              
        FROM #Associations3
             INNER JOIN [KYPEnrollment].[pAccount_PDM_Party]
                ON [KYPEnrollment].[pAccount_PDM_Party].TempPartyID =
                      #Associations3.partypadre
       WHERE     #Associations3.type  IN ('SubcontractorOwnerIndividual','SubcontractorOwnerEntity','OtherOwnershipIndividual','OtherOwnershipEntity',  'SignificantOwnerIndividual', 'SignificantOwnerEntity' )
             AND (   #Associations3.IsPrepopulated IS NULL
                  OR #Associations3.IsPrepopulated = 0)
             AND #Associations3.Accepted = @accepted
             AND [KYPEnrollment].[pAccount_PDM_Party].AccountID =
                    @account_id
             AND #Associations3.IsPastOwner = 0
             
     --**
	 --for child of ownership use table general
     INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate,
                                                     MOCARelationshipStartDate
                                                   
                                                     )
     SELECT 
              #Associations.type,
             [KYPEnrollment].[pAccount_PDM_Party].PartyID,
             [KYPEnrollment].[pAccount_PDM_Party].AccountID,
             #Associations.partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             --@datesubmit
             NULL
              
        FROM #Associations
             INNER JOIN [KYPEnrollment].[pAccount_PDM_Party]
                ON [KYPEnrollment].[pAccount_PDM_Party].TempPartyID =
                      #Associations.partypadre
       WHERE     #Associations.type NOT IN ('Entity Ownership',
                                             'Individual Ownership',
                                             'SubcontractorIndividual',
                                             'SubcontractorEntity',
                                             'TransactionEntity',
                                             'TransactionIndividual',
                                             'SubcontractorOwnerIndividual',
                                             'SubcontractorOwnerEntity',
                                             'OtherOwnershipIndividual',
                                             'OtherOwnershipEntity',
                                             'SignificantTransactionEntity',
                                             'SignificantTransactionIndividual',
                                             'SignificantOwnerIndividual',
                                             'SignificantOwnerEntity'
                                             )
             AND (   #Associations.IsPrepopulated IS NULL
                  OR #Associations.IsPrepopulated = 0)
             AND #Associations.Accepted = @accepted
             AND [KYPEnrollment].[pAccount_PDM_Party].AccountID =
                    @account_id
             AND #Associations.IsPastOwner = 0        
   
   --when father is prepopulated and is subcontractorentity
   --insert only new child  
   

   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate)
      SELECT #Associations3.type,
             associacioAcco.partyIDEnrollment,
             associacioAcco.AccountID,
             #Associations3.partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM #Associations3
             INNER JOIN #Associations AS associacioAcco
                ON #Associations3.partypadre = associacioAcco.partyidlevel
       WHERE  associacioAcco.type in  ( 'SubcontractorEntity','Entity Ownership','Individual Ownership', 'SignificantTransactionEntity') and
	         associacioAcco.IsPrepopulated = 1
             AND associacioAcco.ProfileID = @profile_id
             AND (   #Associations3.IsPrepopulated IS NULL
                  OR #Associations3.IsPrepopulated = 0)
             AND #Associations3.Accepted = @accepted
            
             AND #Associations3.IsPastOwner = 0
             AND associacioAcco.IsPastOwner = 0


	EXEC [KYPEnrollment].[sp_Copy_TaxIDAssocSignif_NewModel] @party_id_app,@party_id_account,@last_action_user_id,NULL,@account_id,@taxidprofileid;
	
	EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_SignifSecondAdd_NewModel @party_id_app,@party_id_account,@last_action_user_id,NULL,@account_id,@taxidprofileid;
---

   /*PERSON*/
   
   
   DECLARE @Person_Table TABLE
                         (
                            ID                  INT IDENTITY (1, 1),
                            PersonID            INT,
                            PartyID             INT,
                            SSN                 VARCHAR (11),
                            FirstName           VARCHAR (25),
                            LastName            VARCHAR (25),
                            MiddleName          VARCHAR (25),
                            ProfessionalTitle   VARCHAR (50),
                            DoB                 DATETIME,
                            IsDeleted           BIT,
                            TargetPath          VARCHAR (200),
                            phone1              varchar(15)
                            
                         )

   INSERT INTO @Person_Table
      SELECT PersonID,
             PartyID,
             SSN,
             FirstName,
             LastName,
             MiddleName,
             ProfessionalTitle,
             DoB,
             Deleted,
             TargetPath,
             phone1
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Person]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ORGANIZATION*/
   DECLARE @Organization_Table TABLE
                               (
                                  ID              INT IDENTITY (1, 1),
                                  OrgID           INT,
                                  PartyID         INT,
                                  LegalName       VARCHAR (100),
                                  DBAName1        VARCHAR (MAX),
                                  Phone1          VARCHAR (15),
                                  Remarks         VARCHAR (25),
                                  NPI             VARCHAR (10),
                                  EIN             VARCHAR (30),
                                  IsCorporation   BIT,
                                  Extension       VARCHAR (12),
                                  BusinessName    VARCHAR (200),
                                  IsDeleted       BIT,
                                  TargetPath      VARCHAR (200),
                                  orgnumber       varchar(25)
                               )

   INSERT INTO @Organization_Table
      SELECT OrgID,
             PartyID,
             LegalName,
             DBAName1,
             Phone1,
             Remarks,
             NPI,
             EIN,
             IsCorporation,
             Extension,
             BusinessName,
             IsDeleted,
             TargetPath,
             orgnumber
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ADDRESS LOCATION*/
   DECLARE @Address_Table TABLE
                          (
                             ID              INT IDENTITY (1, 1),
                             PartyID         INT,
                             AddressID       INT,
                             LocationID      INT,
                             AddressLine1    VARCHAR (250),
                             AddressLine2    VARCHAR (50),
                             County          VARCHAR (25),
                             City            VARCHAR (25),
                             ZipPlus4        VARCHAR (50),
                             State           VARCHAR (40),
                             IsDeleted       BIT,
                             TargetPathAdd   VARCHAR (200),
                             Type            VARCHAR (25),
                             IsDeletedLoc    BIT,
                             TargetPathLoc   VARCHAR (200)
                          )

   INSERT INTO @Address_Table
      SELECT location.PartyID,
             address.AddressID,
             location.LocationID,
             address.AddressLine1,
             address.AddressLine2,
             address.County,
             address.City,
             address.ZipPlus4,
             address.State,
             address.IsDeleted,
             address.TargetPath,
             location.Type,
             location.IsDeleted,
             location.TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] address,
             [KYPPORTAL].[PortalKYP].[pPDM_Location] location
       WHERE     address.AddressID = location.AddressID
             AND location.PartyID IN
                    (SELECT DISTINCT Partyidlevel
                       FROM #Associations
                      WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*DOCUMENT*/
   DECLARE @Document_Table TABLE
                           (
                              ID           INT IDENTITY (1, 1),
                              DocumentID   INT,
                              PartyID      INT,
                              TypeDoc      VARCHAR (15),
                              NumberDoc    VARCHAR (16),
                              IsDeleted    BIT,
                              TargetPath   VARCHAR (200)
                           )

   INSERT INTO @Document_Table
      SELECT DocumentID,
             PartyID,
             TypeDoc,
             NumberDoc,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Document]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*TRANSACTION*/
   DECLARE @Trasaction_Table TABLE
                             (
                                ID              INT IDENTITY (1, 1),
                                TransactionID   INT,
                                PartyID         INT,
                                Description     VARCHAR (150),
                                Amount          VARCHAR (10),
                                IsDeleted       BIT,
                                TargetPath      VARCHAR (200)
                             )

   INSERT INTO @Trasaction_Table
      SELECT TransactionID,
             PartyID,
             Description,
             Amount,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnerhipTransaction]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*Owner Relation*/
   DECLARE @Ownership_Relationship_Table TABLE
                                         (
                                            ID                     INT IDENTITY (1, 1),
                                            OwnerRelationID        INT,
                                            PartyIdOwner           INT,
                                            PartyIdOwned           INT,
                                            TypeAssociation        VARCHAR (100),
                                            FamiliarRelationship   VARCHAR (50),
                                            FamiliarRelationshipOther  VARCHAR (50),
                                            IsDeleted              BIT,
                                            TargetPath             VARCHAR (200),
                                            ParentPartyIdAssociation INT
                                         )

   INSERT INTO @Ownership_Relationship_Table
      SELECT OwnerRelationID,
             PartyIdOwner,
             PartyIdOwned,
             TypeAssociation,
             FamiliarRelationship,
             FamiliarRelationshipOther,
             IsDeleted,
             TargetPath,
             ParentPartyIdAssociation
        FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
       WHERE   
         typeassociation not in ('ProviderSubcontractorOwnerAssociation','ProviderSubcontractorAssociation')-- exclude WhollyOnwer
		and 
		(
        PartyIdOwner IN
                   (SELECT DISTINCT Partyidlevel
                      FROM #Associations
                     WHERE Type <> 'Provider' AND IsPastOwner = 0)
             OR PartyIdOwned IN
                   (SELECT DISTINCT Partyidlevel
                      FROM #Associations
                     WHERE Type <> 'Provider' AND IsPastOwner = 0)
	   )
   /*ROLE*/
   DECLARE @Role_Table TABLE
                       (
                          ID                INT IDENTITY (1, 1),
                          PdmOwnerID        INT,
                          PartyID           INT,
                          TypeForm          VARCHAR (100),
                          PercentCheck      BIT,
                          PercentValue      VARCHAR (150),
                          Partner           BIT,
                          PartnerValue      VARCHAR (150),
                          Managing          BIT,
                          Director          BIT,
                          DirectorValue     VARCHAR (150),
                          Other             BIT,
                          OtherValue        VARCHAR (150),
                          IsDeleted         BIT,
                          PercentDate       SMALLDATETIME,
                          PartnerDate       SMALLDATETIME,
                          ManagingDate      SMALLDATETIME,
                          OtherDate         SMALLDATETIME,
                          Agent             BIT,
                          OwnerRelationID   INT,
                          SoleOwner         BIT,
                          TargetPath        VARCHAR (200),
                          OtherDateRole		smalldatetime,
						  LessPercent		bit,
						  BoardMember		bit,
						  BoardMemberDate	smalldatetime,
              ClinicalDirector bit,
              ExecutiveDirector bit,
              IsOwner VARCHAR(10)
                       )

   INSERT INTO @Role_Table
      SELECT PdmOwnerID,
             PartyID,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             OwnerRelationID,
             SoleOwner,
             TargetPath,
             OtherDateRole,
             LessPercent,
             BoardMember,
             BoardMemberDate,
             ClinicalDirector,
             ExecutiveDirector,
             IsOwner
             
             
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role]
       WHERE    PartyID IN (SELECT DISTINCT Partyidlevel
                              FROM #Associations
                             WHERE Type <> 'Provider' AND IsPastOwner = 0)
             OR OwnerRelationID IN
                   (SELECT DISTINCT OwnerRelationID
                      FROM @Ownership_Relationship_Table
                     WHERE    PartyIdOwner IN
                                 (SELECT DISTINCT Partyidlevel
                                    FROM #Associations
                                   WHERE     Type <> 'Provider'
                                         AND IsPastOwner = 0)
                           OR PartyIdOwned IN
                                 (SELECT DISTINCT Partyidlevel
                                    FROM #Associations
                                   WHERE     Type <> 'Provider'
                                         AND IsPastOwner = 0))

   /*PROVIDER*/
   DECLARE @Provider_Table TABLE
                           (
                              ID           INT IDENTITY (1, 1),
                              ProvID       INT,
                              PartyID      INT,
                              NPI          BIGINT,
                              IsDeleted    BIT,
                              TargetPath   VARCHAR (200),
                              ProviderIdentification varchar(20)
                           )

   INSERT INTO @Provider_Table
      SELECT ProvID,
             PartyID,
             NPI,
             IsDeleted,
             TargetPath,
             ProviderIdentification
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Provider]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ADVERSE ACTION*/
   DECLARE @Adverse_Action_Table TABLE
                                 (
                                    ID                INT IDENTITY (1, 1),
                                    AdverseActionID   INT,
                                    PartyID           INT,
                                    Type_x            VARCHAR (100),
                                    Date_x            DATETIME,
                                    EffectiveDate     DATETIME,
                                    ProgramType       VARCHAR (50),
                                    Where_x           VARCHAR (100),
                                    Action_x          VARCHAR (1000),
                                    IsDeleted         BIT,
                                    TargetPath        VARCHAR (200)
                                 )

   INSERT INTO @Adverse_Action_Table
      SELECT AdverseActionID,
             PartyID,
             Type_x,
             Date_x,
             EffectiveDate,
             ProgramType,
             Where_x,
             Action_x,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)


  /*PROVIDER QUESTIONNAIRE*/
  DECLARE @ProviderQuestionnaire_Table TABLE
                         (
                            ID                   INT IDENTITY (1, 1),
                            QuestionID           INT,
                            Type                 VARCHAR (50),
                            Name                 VARCHAR (100),
                            Value                VARCHAR (100),
                            IsDeleted            BIT,
                            PartyID              INT,
                            TargetPath           VARCHAR (200),
                            Description          VARCHAR (500),
                            documentInstanceId   INT
                         )

   INSERT INTO @ProviderQuestionnaire_Table
      SELECT  QuestionID,
              Type,
              Name,
              Value,
              IsDeleted,
              PartyID,
              TargetPath,
              Description,
              documentInstanceId
        FROM [KYPPORTAL].[PortalKYP].[pPDM_ProviderQuestionnarie]
       WHERE PartyID IN ( SELECT DISTINCT Partyidlevel
                          FROM #Associations
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*INSERT*/
   INSERT INTO KYPEnrollment.pAccount_PDM_Person (PartyID,
                                                  SSN,
                                                  FirstName,
                                                  LastName,
                                                  MiddleName,
                                                  Salutation,
                                                  DoB,
                                                  Deleted,
                                                  CurrentRecordFlag,
                                                  LastAction,
                                                  LastActorUserID,
                                                  LastActionApprovedBy,
                                                  LastActionDate,
                                                  phone1)
      SELECT party.PartyID,
             SSN,
             FirstName,
             LastName,
             MiddleName,
             person.ProfessionalTitle,
             DoB,
             person.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             phone1
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Person_Table person
                ON     (party.TempPartyID = person.PartyID)
                   AND person.IsDeleted = 0

/* logic for sp_create_unique_party_moca*/
--For individual ownership
select uniq.uniquepartyid,party.PartyID,person.LastName,person.FirstName,replace(person.SSN,'-','') as ssn,ISNULL(person.middlename,'') as middlename,person.DoB  
into #uniqueIndividual
from KYPEnrollment.pAccount_PDM_Party party 
INNER JOIN @Person_Table person      ON     (party.TempPartyID = person.PartyID)  AND person.IsDeleted = 0
left join kypenrollment.pAccount_UniqueParty   uniq on person.LastName=uniq.LastName and person.FirstName=uniq.FistName and  replace(person.SSN,'-','')=uniq.SSN 
where TYPE='Individual Ownership' and UniquePartyID is null 

insert into kypenrollment.pAccount_UniqueParty (SSN,LastName,MiddleName,fistname,DOB,LastAction,LastActorUserID,LastActionDate,LastActionApprovedByUsedId )
select ssn,lastname,middlename,firstname,dob,'C',@last_Action_User_ID,GETDATE(),@last_Action_User_ID  from #uniqueIndividual  

drop table #uniqueIndividual

select uniq.uniquepartyid,party.PartyID,person.LastName,person.FirstName,replace(person.SSN,'-','') as ssn,ISNULL(person.middlename,'') as middlename,person.DoB  
into #uniqueIndividual1
from KYPEnrollment.pAccount_PDM_Party party 
INNER JOIN @Person_Table person      ON     (party.TempPartyID = person.PartyID)  AND person.IsDeleted = 0
inner join kypenrollment.pAccount_UniqueParty   uniq on person.LastName=uniq.LastName and person.FirstName=uniq.FistName and  replace(person.SSN,'-','')=uniq.SSN 
where TYPE='Individual Ownership' 

insert into kypenrollment.pAccount_UniqueParty_MOCAMapping (UniquePartyID,MOCAPartyID,EffectiveBeingDate,LastAction,LastActionDate,LastActoryUserID,LastActionApprovedByUsedID,CurrentRecordFlag)
select UniquePartyID,PartyID,GETDATE(),'C',GETDATE(),@last_Action_User_ID,@last_Action_User_ID,'TRUE'
from #uniqueIndividual1 

drop table #uniqueindividual1

--*****
   INSERT INTO KYPEnrollment.pAccount_PDM_Organization (PartyID,
                                                        LegalName,
                                                        DBAName1,
                                                        Phone1,
                                                        Remarks,
                                                        NPI,
                                                        EIN,
                                                        IsCorporation,
                                                        Extension,
                                                        BusinessName,
                                                        IsDeleted,
                                                        CurrentRecordFlag,
                                                        LastAction,
                                                        LastActionApprovedBy,
                                                        LastActorUserID,
                                                        LastActionDate,
                                                        OrgNumber)
      SELECT party.PartyID,
             LegalName,
             DBAName1,
             Phone1,
             Remarks,
             NPI,
             EIN,
             IsCorporation,
             Extension,
             BusinessName,
             org.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             orgnumber
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Organization_Table org
                ON (party.TempPartyID = org.PartyID) AND org.IsDeleted = 0

/* logic for sp_create_unique_party_moca*/
--For entity ownership
select 
(SELECT TOP 1 ISNULL(UniquePartyID,0)
 FROM [KYPEnrollment].[pAccount_UniqueParty] 
 WHERE (0.98<=(select f.Score from [dbo].[CompareStringMetrics](BusinessLegalName, org.legalName) f where f.metric='JaroWinkler'))
 AND EIN =replace(org.EIN,'-','')) as uniquepartyid,
 party.PartyID,legalname,replace(ein,'-','') as ein,isnull(dbaname1,'') as dbaname  
into #uniqueentity
from KYPEnrollment.pAccount_PDM_Party party 
INNER JOIN @organization_Table org      ON     (party.TempPartyID = org.PartyID)  AND org.IsDeleted = 0
where TYPE='Entity Ownership' 


insert into kypenrollment.pAccount_UniqueParty (EIN,businesslegalname,businessdbaname,LastAction,LastActorUserID,LastActionDate,LastActionApprovedByUsedId )
select ein,legalname,legalname,'C',@last_Action_User_ID,GETDATE(),@last_Action_User_ID  from #uniqueentity where isnull(uniquepartyid,0)=0  

drop table #uniqueentity
select 
(SELECT TOP 1  ISNULL(UniquePartyID,0)
 FROM [KYPEnrollment].[pAccount_UniqueParty] 
 WHERE (0.98<=(select f.Score from [dbo].[CompareStringMetrics](BusinessLegalName, org.legalName) f where f.metric='JaroWinkler'))
 AND EIN =replace(org.EIN,'-','')) as uniquepartyid,
 party.PartyID,legalname,replace(ein,'-','') as ein,isnull(dbaname1,'') as dbaname  
into #uniqueentity1
from KYPEnrollment.pAccount_PDM_Party party 
INNER JOIN @organization_Table org      ON     (party.TempPartyID = org.PartyID)  AND org.IsDeleted = 0
where TYPE='Entity Ownership' 



insert into kypenrollment.pAccount_UniqueParty_MOCAMapping (UniquePartyID,MOCAPartyID,EffectiveBeingDate,LastAction,LastActionDate,LastActoryUserID,LastActionApprovedByUsedID,CurrentRecordFlag)
select UniquePartyID,PartyID,GETDATE(),'C',GETDATE(),@last_Action_User_ID,@last_Action_User_ID,'TRUE'
from #uniqueentity1

drop table #uniqueentity1

--****


   INSERT INTO KYPEnrollment.pAccount_PDM_Address (
                  TempAddressID,
                  AddressLine1,
                  AddressLine2,
                  County,
                  City,
                  ZipPlus4,
                  State,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedByUsedID,
                  LastActionUserID,
                  LastActionDate)
      SELECT   addr.addressid,
             AddressLine1,
             AddressLine2,
             County,
             City,
             ZipPlus4,
             State,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM  @Address_Table addr
       where addr.IsDeleted = 0


   INSERT INTO KYPEnrollment.pAccount_PDM_Location (PartyID,
                                                    AddressID,
                                                    Type,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate)
      SELECT DISTINCT
             part.partyid,
             addr.AddressID,
             location.Type,
             IsDeletedLoc,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Address_Table location
             INNER JOIN KYPEnrollment.pAccount_PDM_Address addr on location.addressid=addr.tempaddressid
             inner join kypenrollment.paccount_pdm_party part on location.partyid=part.temppartyid
        where  addr.tempaddressid is not null and location.IsDeletedLoc = 0


   INSERT INTO KYPEnrollment.pAccount_PDM_Document (PartyID,
                                                    TypeDoc,
                                                    NumberDoc,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate)
      SELECT party.PartyID,
             TypeDoc,
             NumberDoc,
             document.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Document_Table document
                ON     (party.TempPartyID = document.PartyID)
                   AND document.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_OwnerhipTransaction (
                  PartyID,
                  Description,
                  Amount,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate)
      SELECT party.PartyID,
             Description,
             Amount,
             transactions.IsDeleted,
             1,
             'C',--C
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Trasaction_Table transactions
                ON     (party.TempPartyID = transactions.PartyID)
                   AND transactions.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_Provider (PartyID,
                                                    NPI,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate,
                                                    ProviderIdentification)
      SELECT party.PartyID,
             NPI,
             provider.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             ProviderIdentification
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Provider_Table provider
                ON     (party.TempPartyID = provider.PartyID)
                   AND provider.IsDeleted = 0

   /*OWNER RELATIONSHIP*/
   --new association for owner and owned prepopulated

   INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] (
                  TempRelationshipID,
                  DateCreated,
                  PartyIDOwner,
                  PartyIDOwned,
                  TypeAssociation,
                  FamiliarRelationship,
                  FamiliarRelationshipOther,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate,
                  ParentPartyIdAssociation)
      SELECT relation.OwnerRelationID,
             @date_Create,
             asso.partyIDEnrollment AS ownerEnroll,
             asso2.partyIDEnrollment,
             TypeAssociation,
             FamiliarRelationship,
             FamiliarRelationshipOther,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             CASE
				        WHEN (ISNULL(relation.TypeAssociation, '') = 'SubcontractorIndividualOwnerAssociation')
				        THEN ([KYPEnrollment].[GetPartyAccountId](relation.ParentPartyIdAssociation))
				        ELSE NULL
			       END
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations asso
                ON relation.PartyIDOwner = asso.partyidlevel
             INNER JOIN #Associations asso2
                ON relation.PartyIDOwned = asso2.partyidlevel
       WHERE   
             relation.IsDeleted = 0
             AND relation.TargetPath NOT LIKE
                    'pAccount_PDM_OwnershipRelationship%'
             AND asso.IsPrepopulated = 1
             AND asso2.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso2.ProfileID = @profile_id
            
             AND asso.IsPastOwner = 0
             AND asso2.IsPastOwner = 0

      UNION ALL

      /*owner prepo owned new*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             asso.partyIDEnrollment AS ownerEnroll,
             party.PartyID,
             TypeAssociation,
             FamiliarRelationship,
             FamiliarRelationshipOther,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             CASE
				        WHEN (ISNULL(relation.TypeAssociation, '') = 'SubcontractorIndividualOwnerAssociation')
				        THEN ([KYPEnrollment].[GetPartyAccountId](relation.ParentPartyIdAssociation))
				        ELSE NULL
			       END
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations asso
                ON relation.PartyIDOwner = asso.partyidlevel
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwned = party.TempPartyID
       WHERE    
             relation.TargetPath NOT LIKE    'pAccount_PDM_OwnershipRelationship%'
              AND asso.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso.IsPastOwner = 0
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND relation.IsDeleted = 0
            
        union all     
                
      /*owner new owned prep*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             party.PartyID,
             asso.partyIDEnrollment AS ownerEnroll,
             TypeAssociation,
             FamiliarRelationship,
             FamiliarRelationshipOther,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             CASE
				        WHEN (ISNULL(relation.TypeAssociation, '') = 'SubcontractorIndividualOwnerAssociation')
				        THEN ([KYPEnrollment].[GetPartyAccountId](relation.ParentPartyIdAssociation))
				        ELSE NULL
			       END
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations asso
                ON relation.PartyIDOwned = asso.partyidlevel
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwner = party.TempPartyID
       WHERE   
            relation.TargetPath NOT LIKE   'pAccount_PDM_OwnershipRelationship%'
             AND asso.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso.IsPastOwner = 0
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND relation.IsDeleted = 0

      UNION ALL

      /*owner new and new owned*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             party.PartyID,
             party2.PartyID AS Partyowned,
             TypeAssociation,
             FamiliarRelationship,
              FamiliarRelationshipOther,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             CASE
				        WHEN (ISNULL(relation.TypeAssociation, '') = 'SubcontractorIndividualOwnerAssociation')
				        THEN ([KYPEnrollment].[GetPartyAccountId](relation.ParentPartyIdAssociation))
				        ELSE NULL
			       END
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwner = party.TempPartyID
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party2
                ON relation.PartyIDOwned = party2.TempPartyID
       WHERE     
       
       relation.TargetPath NOT LIKE   'pAccount_PDM_OwnershipRelationship%' and
       party.AccountID = party2.AccountID
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND NOT EXISTS
                    (SELECT assoExists.partyidlevel
                       FROM #Associations assoExists
                      WHERE     assoExists.partyidlevel = party2.TempPartyID
                            AND assoExists.IsPrepopulated = 1
                            AND assoExists.IsPastOwner = 0)
             AND relation.IsDeleted = 0
             AND party.AccountID = @account_id

   /*OWNER ROLE*/

   INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role (OwnerRelationID,
                                                      DateCreated,
                                                      TypeForm,
                                                      PercentCheck,
                                                      PercentValue,
                                                      Partner,
                                                      PartnerValue,
                                                      Managing,
                                                      Director,
                                                      DirectorValue,
                                                      Other,
                                                      OtherValue,
                                                      IsDeleted,
                                                      PercentDate,
                                                      PartnerDate,
                                                      ManagingDate,
                                                      OtherDate,
                                                      Agent,
                                                      SoleOwner,
                                                      CurrentRecordFlag,
                                                      LastAction,
                                                      LastActionApprovedBy,
                                                      LastActorUserID,
                                                      LastActionDate,
                                                      OtherDateRole,
													  LessPercent,
													  BoardMember,
													  BoardMemberDate,
                            ClinicalDirector,
                            ExecutiveDirector,
                            IsOwner
   )
      SELECT relation.OwnerRelationID,
             @date_Create,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             ownerRole.IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             SoleOwner,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             OtherDateRole,
             LessPercent,
             BoardMember,
             BoardMemberDate,
             ClinicalDirector,
             ExecutiveDirector,
             IsOwner
             
        FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] relation
             INNER JOIN @Role_Table ownerRole
                ON     (relation.TempRelationshipID =
                           ownerRole.OwnerRelationID)
                   AND ownerRole.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role (PartyID,
                                                      DateCreated,
                                                      TypeForm,
                                                      PercentCheck,
                                                      PercentValue,
                                                      Partner,
                                                      PartnerValue,
                                                      Managing,
                                                      Director,
                                                      DirectorValue,
                                                      Other,
                                                      OtherValue,
                                                      IsDeleted,
                                                      PercentDate,
                                                      PartnerDate,
                                                      ManagingDate,
                                                      OtherDate,
                                                      Agent,
                                                      SoleOwner,
                                                      CurrentRecordFlag,
                                                      LastAction,
                                                      LastActionApprovedBy,
                                                      LastActorUserID,
                                                      LastActionDate,
                                                      OtherDateRole,
													  LessPercent,
													  BoardMember,
													  BoardMemberDate,
                            ClinicalDirector,
                            ExecutiveDirector,
                            IsOwner
   )
      SELECT party.PartyID,
             @date_Create,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             ownerRole.IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             SoleOwner,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             OtherDateRole,
             LessPercent,
             BoardMember,
             BoardMemberDate,
             ClinicalDirector,
             ExecutiveDirector,
             IsOwner
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Role_Table ownerRole
                ON (party.TempPartyID = ownerRole.PartyID)
       WHERE ownerRole.IsDeleted = 0


       ----** Attachments OwnerRole - **
  INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, ApplicationPartyId, AccountPartyId)
  select partyAccount.AccountID,ownerRole.PartyID, partyAccount.PartyID
  from @Role_Table ownerRole
  inner join KYPPORTAL.PortalKYP.pApplicationDocumentFile appDocFile on ownerRole.PartyID = appDocFile.partyId
  INNER JOIN KYPEnrollment.pAccount_PDM_Party partyAccount on partyAccount.TempPartyID = appDocFile.PartyID
  where appDocFile.documentInstanceId is null and appDocFile.isDeleted = 0
   AND NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_Attachments
                            WHERE AccountPartyId = partyAccount.PartyID AND ApplicationPartyId = ownerRole.PartyID AND IsDeleted = 0
                            and documentInstanceId is null)

   /*ADVERSE ACTION*/
   --when the ownership is new or the related party is new
   declare @newadverseActionDocuments table (AccAdverseActionID int, AppAdverseActionID int)
   INSERT INTO KYPEnrollment.pAccount_PDM_AdverseAction (
                  PartyID,
                  Type_x,
                  Date_x,
                  EffectiveDate,
                  ProgramType,
                  Where_x,
                  Action_x,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate,
                  AppAdverseActionID)
     output inserted.AdverseActionID ,inserted.appadverseactionid into  @newadverseActionDocuments  
      SELECT party.PartyID,
             Type_x,
             Date_x,
             EffectiveDate,
             ProgramType,
             Where_x,
             Action_x,
             adverseAction.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             adverseAction.AdverseActionID
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Adverse_Action_Table adverseAction
                ON     (party.TempPartyID = adverseAction.PartyID)
                   AND adverseAction.IsDeleted = 0

     ----** Attachments tablas  Adverse Actions**
	 INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, DocumentInstanceId, AccountEntityId, EntityName, PrimaryKeyName,ApplicationPartyId, AccountPartyId)					
	SELECT NULL, appAC.documentInstanceId, accAC.AdverseActionID,'pAccount_PDM_AdverseAction','AdverseActionID', appAC.PartyID, accAc.PartyID
	FROM KYPEnrollment.pAccount_PDM_AdverseAction accAc 
	INNER JOIN KYPPORTAL.PortalKYP.pPDM_AdverseAction appAC on appAC.AdverseActionID = accAc.AppAdverseActionID
	inner join @newadverseActionDocuments newadverse on accAc.adverseactionid=newadverse.AccAdverseActionID
	WHERE 
	 NOT EXISTS ( SELECT * FROM KYPEnrollment.pAccount_Attachments
					 WHERE DocumentInstanceId = appAC.documentInstanceId
					 AND AccountEntityId = accAC.AdverseActionID AND EntityName = 'pAccount_PDM_AdverseAction' )
	AND appAC.documentInstanceId IS NOT NULL AND appAC.documentInstanceId IS NOT NULL
                    



    /*PROVIDER QUESTIONNAIRE*/
   INSERT INTO KYPEnrollment.pAccount_PDM_ProviderQuestionnarie ( PartyID,
                                                                  Type,
                                                                  Name,
                                                                  Value,
                                                                  IsDeleted,
                                                                  Description,
                                                                  CurrentRecordFlag,
                                                                  LastAction,
                                                                  LastActorUserID,
                                                                  LastActionApprovedBy,
                                                                  LastActionDate)
      SELECT  party.PartyID,
              providerQ.Type,
              providerQ.Name,
              providerQ.Value,
              providerQ.IsDeleted,
              providerQ.Description,
              1,
              'C',
              @last_Action_User_ID,
              @last_Action_User_ID,
              @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
            INNER JOIN @ProviderQuestionnaire_Table providerQ
            ON (party.TempPartyID = providerQ.PartyID) AND providerQ.IsDeleted = 0


    --For new records in providerQuestionnarie for moca prepopulated

     INSERT INTO KYPEnrollment.pAccount_PDM_ProviderQuestionnarie ( PartyID,
                                                                  Type,
                                                                  Name,
                                                                  Value,
                                                                  IsDeleted,
                                                                  Description,
                                                                  CurrentRecordFlag,
                                                                  LastAction,
                                                                  LastActorUserID,
                                                                  LastActionApprovedBy,
                                                                  LastActionDate)
      SELECT  assoc.partyIDEnrollment,
              providerQ.Type,
              providerQ.Name,
              providerQ.Value,
              providerQ.IsDeleted,
              providerQ.Description,
              1,
              'C',
              @last_Action_User_ID,
              @last_Action_User_ID,
              @date_Create
        FROM  @ProviderQuestionnaire_Table providerQ inner join
              #Associations assoc on providerQ.PartyID=assoc.partyidlevel
              where
              assoc.IsPrepopulated=1 and providerQ.IsDeleted=0
              and  charindex('pAccount_PDM_ProviderQuestionnarie',providerQ.targetpath )=0


--for insert all new records of adverseaction for prepopulated ownership
  declare @newadverseActionDocumentsPrep table (AccAdverseActionID int, AppAdverseActionID int)
INSERT INTO KYPEnrollment.pAccount_PDM_AdverseAction (
                  PartyID,
                  Type_x,
                  Date_x,
                  EffectiveDate,
                  ProgramType,
                  Where_x,
                  Action_x,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate,
                  AppAdverseActionID)
    output inserted.AdverseActionID ,inserted.appadverseactionid into  @newadverseActionDocumentsPrep        
      SELECT assoc.partyIDEnrollment,
             Type_x,
             Date_x,
             EffectiveDate,
             ProgramType,
             Where_x,
             Action_x,
             adverseAction.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create,
             adverseAction.AdverseActionID
        FROM 
        @Adverse_Action_Table adverseAction inner join
        #Associations assoc on adverseaction.PartyID=assoc.partyidlevel
        where 
        charindex('pAccount_PDM_AdverseAction',adverseaction.targetpath )=0 and
       
        assoc.IsPrepopulated=1 and adverseAction.IsDeleted=0
        
    ----** Attachments tablas  Adverse Actions for prepopulated ownership**   
    INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, DocumentInstanceId, AccountEntityId, EntityName, PrimaryKeyName,ApplicationPartyId, AccountPartyId)					
	SELECT NULL, appAC.documentInstanceId, accAC.AdverseActionID,'pAccount_PDM_AdverseAction','AdverseActionID', appAC.PartyID, accAc.PartyID
	FROM KYPEnrollment.pAccount_PDM_AdverseAction accAc 
	INNER JOIN KYPPORTAL.PortalKYP.pPDM_AdverseAction appAC on appAC.AdverseActionID = accAc.AppAdverseActionID
	inner join @newadverseActionDocumentsPrep newadverse on accAc.adverseactionid=newadverse.AccAdverseActionID
	WHERE 	 NOT EXISTS ( SELECT * FROM KYPEnrollment.pAccount_Attachments
					 WHERE DocumentInstanceId = appAC.documentInstanceId
					 AND AccountEntityId = accAC.AdverseActionID AND EntityName = 'pAccount_PDM_AdverseAction' )
	AND appAC.documentInstanceId IS NOT NULL AND appAC.documentInstanceId IS NOT NULL
 


---

   UPDATE KYPEnrollment.pAccount_PDM_Address
      SET TempAddressID = NULL
    WHERE TempAddressID IS NOT NULL

   UPDATE KYPEnrollment.pAccount_PDM_OwnershipRelationship
      SET TempRelationshipID = NULL
    WHERE TempRelationshipID IS NOT NULL

   DROP TABLE #PartiesLevelTable
   DROP TABLE #PartyPortal
   DROP TABLE #Associations
   DROP TABLE #Associations2
   DROP TABLE #Associations1
   drop table #associations3
   DROP TABLE #mocaexist
   drop table #screen
   drop table #ScreenedON 
   
  
END TRY

BEGIN CATCH

	DECLARE    @error_message NVARCHAR(4000),@error_severity INT;
	SELECT     @error_message = ERROR_MESSAGE()
		      ,@error_severity = ERROR_SEVERITY();
	RAISERROR (@error_message
              ,@error_severity
              ,1);
              
	EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @application_id             
              
END CATCH


END


GO

