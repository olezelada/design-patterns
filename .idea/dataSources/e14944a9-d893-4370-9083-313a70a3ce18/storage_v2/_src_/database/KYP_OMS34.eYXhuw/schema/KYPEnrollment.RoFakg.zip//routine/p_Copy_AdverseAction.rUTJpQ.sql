

-- =============================================
-- Author:		<Author,,Lperez>
-- copiar adverse Action recive cuatro para metros
--ID Adverse action ID y PartyID en esta variable puede venir dos tipos de valores que puede ser ID Adverse action o ID Party
-- New party ID 
-- type sql identificador del typo de sql a realizar (insert apartir del party id o insert apartir del adverse action ID)
-- nombre de usuario que modifico 
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_AdverseAction]
	@AdverseActionPartyID INT,
	@newPartyID INT,
	@typeSQL varchar(15),
	@lastActionUserID varchar(100)
	
AS
BEGIN

    DECLARE @sql nvarchar(MAX),@ParmDefinition nvarchar(500),@name varchar(17),@isTrue INT,
			@message varchar(100),@dateCreated date,@lastAction varchar(1)
	
	SET @name ='';
	SET @isTrue = 0;
	SET @dateCreated = GETDATE();
	SET @lastAction = 'C';
		
	IF @typeSQL ='party'
	BEGIN
		SET @name ='[PartyID]';
		SET @isTrue = 1;
	END
	ELSE
	BEGIN
		IF @typeSQL ='AdverseAction'
		BEGIN
			SET @name ='[AdverseActionID]';
			SET @isTrue = 1;
		END
	END
	--validamos si el valor que se envia es distinto de nulo
	IF(@isTrue=1 AND (ISNULL(@AdverseActionPartyID,0) <> 0))
	BEGIN		
		-- sql en formato string que sera evaluado	
		SET @sql =N'INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
			([PartyID] ,[Type_x] ,[Reason] ,[State_x] ,[Date_x] ,[DateType] ,[EffectiveDate] ,[NPI] ,[City] ,[ProgramType] ,[Where_x] ,[Action_x] ,[LicenseAuthority] ,
			[LastAction] ,
			[LastActionDate] ,
			[LastActorUserID] ,
			[LastActionApprovedBy] ,
			[CurrentRecordFlag] ,
			[LegalName] ,[DBA] ,[AppFormID])
			SELECT @newPartyID,[Type_x],[Reason],[State_x],[Date_x],[DateType],[EffectiveDate],[NPI],[City],[ProgramType],[Where_x],[Action_x],[LicenseAuthority],
			@lastAction,
			@dateCreated,
			@lastActionUserID,
			@lastActionUserID,
			(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end),
			[LegalName],[DBA],[AppFormID]
			FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE '+@name+'=@AdverseActionPartyID';
			-- Definimos los para metros que se van a enviar al sql, que se definio anteriormente
			-- En la consulta existe @lastAction,lastActionUserID ....... estos son los para metros que esperan un valor
			-- para enviar un valor a un para metro se debe de finir que tipo es: de salida o ingreso los valores de salida son OUTPUT y los valores de ingreso son INTPUT o no lo defines.
		SET @ParmDefinition = N'@newPartyID INT OUTPUT,@lastAction VARCHAR(1) OUTPUT,@dateCreated DATE OUTPUT,@lastActionUserID VARCHAR(100) OUTPUT, @AdverseActionPartyID INT';
		-- funcion que ejecuta el sql con los para metros NOTA: se debe enviar en el orden definido
		EXECUTE  sp_executesql @sql,@ParmDefinition,@newPartyID=@newPartyID,@lastAction=@lastAction,@dateCreated=@dateCreated,@lastActionUserID=@lastActionUserID,@AdverseActionPartyID=@AdverseActionPartyID;
		
		SELECT @message = '[pAccount_PDM_AdverseAction] @AdverseActionID: ' + CONVERT(char(10), 'OK')
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		
	END			
END


GO

