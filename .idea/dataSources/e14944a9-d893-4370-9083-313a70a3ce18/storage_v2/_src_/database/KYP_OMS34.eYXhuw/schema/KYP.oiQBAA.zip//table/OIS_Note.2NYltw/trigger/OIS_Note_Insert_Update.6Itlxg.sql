
-- =============================================
-- Author:		Sundar
-- Create date: 25 Feb 2019
-- Description:	Updated LastActionDate with CurrentDate for Elk Implmentation
-- =============================================
CREATE TRIGGER [KYP].[OIS_Note_Insert_Update] 
   ON  [KYP].[OIS_Note] 
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

	DECLARE @Row_Updation_Source VARCHAR(100),
			@NoteID int
	Begin TRy	
		SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
		IF isnull(@Row_Updation_Source,'') in ( 'KYP.p_InsertOISNote') AND Update(Row_Updation_Source)
		BEGIN
			PRINT 'Going to return to prevent deadlock schema M locks'
			RETURN
		END
		
		Select @NoteID=NoteID from Inserted
	
		Update KYP.OIS_NOTE 
		Set LastActionDate = Getdate(),
			Row_Updation_Source = 'KYP.p_InsertOISNote'
		Where NoteID in (Select NoteID from Inserted);
	End Try
	Begin Catch
	   IF @@TRANCOUNT > 0  
	   ROLLBACK TRANSACTION   
	      
	   Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'NoteID',@KeyValue = @NoteID;   
	     
	End Catch

END

GO

