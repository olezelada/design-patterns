CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_CAMMIS_Acc_Field]
	@en_db_column VARCHAR(100),
	@last_action_user_id VARCHAR(100),
	@section_nanme VARCHAR(100),
	@account_party_id INT,
	@new_value_text VARCHAR (250),
	@target_path varchar(200),
	@is_deleted BIT
AS
BEGIN
    -- For subForm Identification when it not has object Documents in an Account Cammis
    DECLARE @acc_document_id INT
    DECLARE @current_record_flag BIT = 1
    DECLARE @today_date DATE = GETDATE()
	  DECLARE @last_action VARCHAR(1) = 'C'

	  PRINT 'sp_Create_Update_CAMMIS_Acc_Field'

    IF @section_nanme = 'Identification'
    BEGIN

        SELECT @acc_document_id = DocumentID
                            FROM KYPEnrollment.pAccount_PDM_Document doc,
                                  KYPEnrollment.pAccount_PDM_Party par
                            WHERE par.PartyID = doc.PartyID AND par.PartyID = @account_party_id AND doc.TypeDoc IN ('Driver''s License','State Issued ID','No Data')

        IF (@acc_document_id is null OR @acc_document_id = 0) AND @en_db_column is not null AND @target_path is null
          BEGIN
            INSERT INTO KYPEnrollment.pAccount_PDM_Document ([PartyID],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                     VALUES (@account_party_id,@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

            SET @acc_document_id = SCOPE_IDENTITY()

          END

          IF @en_db_column = 'TypeDoc'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set TypeDoc = @new_value_text WHERE DocumentID = @acc_document_id
            END

          IF @en_db_column = 'NumberDoc'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set NumberDoc = @new_value_text WHERE DocumentID = @acc_document_id
            END

          IF @en_db_column = 'StateIssued'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set StateIssued = @new_value_text WHERE DocumentID = @acc_document_id
            END
    END
 END


GO

