
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <14/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
create PROCEDURE [KYPEnrollment].[sp_delete_License_Certificates] 
@new_Account_Id int

AS
BEGIN

SET NOCOUNT ON;

update d set currentrecordflag=0 
FROM KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].pAccount_PDM_DEA d ON a.PartyID=d.PartyID
where a.IsDeleted=0 and d.CurrentRecordFlag=1 and a.AccountID=@new_Account_Id

update C set currentrecordflag=0 
FROM KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].pAccount_PDM_Clia c ON a.PartyID=c.PartyID
where a.IsDeleted=0 and c.CurrentRecordFlag=1 and a.AccountID=@new_Account_Id

--for packageName'F_OOS_OE'
IF EXISTS (SELECT a.AccountID FROM KYPEnrollment.pADM_Account a where a.AccountID =@new_Account_Id AND a.PackageName='F_OOS_OE')
BEGIN

  update n set CurrentRecordFlag=0, IsDeleted=1
  from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Number n ON a.PartyID=n.PartyID
  where n.IsDeleted=0 and n.CurrentRecordFlag=1 and a.IsDeleted=0 and a.AccountID=@new_Account_Id AND n.Type='LabHospital'

END

END
GO

