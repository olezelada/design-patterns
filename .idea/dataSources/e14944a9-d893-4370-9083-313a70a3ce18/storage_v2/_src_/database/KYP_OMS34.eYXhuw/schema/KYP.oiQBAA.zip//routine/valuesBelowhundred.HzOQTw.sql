
-- =============================================
-- Author:		Vinoth
-- Create date: 18th June 2014
-- Description:	To get the number in words below twenty
-- =============================================
CREATE FUNCTION [KYP].[valuesBelowhundred] 
(
	@num INT
)
RETURNS VARCHAR(50)
AS
BEGIN

	DECLARE @Name VARCHAR(25)

	IF(@Num=2) SET @Name='Twenty'
	IF(@Num=3) SET @Name='Thirty'
	IF(@Num=4) SET @Name='Fourty'
	IF(@Num=5) SET @Name='Fifty'
	IF(@Num=6) SET @Name='Sixty'
	IF(@Num=7) SET @Name='Seventy'
	IF(@Num=8) SET @Name='Eighty'
	IF(@Num=9) SET @Name='Ninety'
	
	RETURN @Name
END


GO

