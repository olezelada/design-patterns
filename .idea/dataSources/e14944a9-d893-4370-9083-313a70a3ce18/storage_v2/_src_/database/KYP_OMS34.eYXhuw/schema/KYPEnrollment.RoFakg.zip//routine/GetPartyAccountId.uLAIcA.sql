


CREATE FUNCTION [KYPEnrollment].[GetPartyAccountId](@PartyID INT)

RETURNS INT

AS
BEGIN

  DECLARE @partyAccountId INT, @targetPath VARCHAR (200), @isPrepopulated BIT;

  IF (@PartyID IS NOT NULL )
  BEGIN
    SELECT @targetPath = REVERSE(SUBSTRING(REVERSE(TargetPath), 0, PATINDEX('%|%', (REVERSE(TargetPath))))), @isPrepopulated = IsPrepopulated FROM KYPPORTAL.PortalKYP.pPDM_Party WHERE PartyID = @PartyID
    IF (@isPrepopulated IS NOT NULL AND @isPrepopulated = 1)
    BEGIN
      SET @partyAccountId = CONVERT(INT, ISNULL(@targetPath,''));
    END
    ELSE
    BEGIN
      SELECT @partyAccountId = PartyID FROM KYPEnrollment.pAccount_PDM_Party WHERE TempPartyID = @PartyID
    END
  END

  RETURN @partyAccountId ;
END


GO

