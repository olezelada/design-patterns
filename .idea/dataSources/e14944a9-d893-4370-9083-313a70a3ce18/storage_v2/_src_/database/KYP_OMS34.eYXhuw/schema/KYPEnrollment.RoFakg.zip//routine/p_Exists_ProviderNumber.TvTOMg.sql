
-- =============================================
-- Author:		<Author,,Lperez>
-- PROCEDURE que valida si tiene renderings
-- RETURN Number COUNT cantidad de renderings si tiene 4 por lo menos dos deben de estar aprobados en account 
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Exists_ProviderNumber]
	@providerNumber varchar(15)
AS
BEGIN
    DECLARE @sqlProviderNumber nvarchar(MAX),
			@isCount INT,
			@item VARCHAR(15),
			@message varchar(100)
	SET @isCount = 0
	SET @sqlProviderNumber = ''
	-- se selecciona los numero de aplicaciones de los renderings 		
	Select   
	@sqlProviderNumber =Substring((Select ',' + [rendering_providerNumber]  From [KYPPORTAL].[PortalKYP].pRenderingAffiliation B Where B.[group_providerNumber]=A.[group_providerNumber] For XML Path('')),2,8000) 
	From [KYPPORTAL].[PortalKYP].pRenderingAffiliation A  
	WHERE [group_providerNumber] = @providerNumber Group By [group_providerNumber];
		
	IF(@sqlProviderNumber<>'')
	BEGIN
		DECLARE PartyIdsA_Cursor CURSOR FOR 		
		SELECT Item	FROM [KYPEnrollment].[SplitString](@sqlProviderNumber, ',')
		
		OPEN PartyIdsA_Cursor;
		FETCH NEXT FROM PartyIdsA_Cursor INTO @item		
		WHILE @@FETCH_STATUS = 0
		BEGIN							
        	            	print @item;					
			IF((SELECT COUNT(DISTINCT [AccountID]) FROM [KYPEnrollment].pADM_Account	WHERE ([AccountNumber] is not null  AND [AccountNumber]<>'' AND (IsDeleted = 0 or IsDeleted is null) AND [ApplicationNumber] = @item))>0)
			BEGIN
				SET @isCount = @isCount+1				
			END
			FETCH NEXT FROM PartyIdsA_Cursor INTO @item
		END;
		CLOSE PartyIdsA_Cursor;
		DEALLOCATE PartyIdsA_Cursor;		
		
	END	
	return @isCount
END


GO

