--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.	Author		Date			Description
---------------------------------------------------------------------------------------
-- #1					Pullaiah	08-Mar-2017		Telephone number was coming as NULL so we are taking it from ORG table or Person without any condition.because of that category condition is ignored.
-- #2		CAPAVE-1244	Sundar		08-Mar-2017		Changed the calculation for ApplicationDate to consider ADM_Case.DateReceived for Portal records (LegacyAccountNo is null)
-- #3		CAPAVE-1221 Sundar		08-Mar-2017		Changed the field mappings for Specialty code and Date.			
-- #4		CAPAVE-1753	Sundar		03-Jul-2017		Changed for Analyst, Reviewer and Supervisor Names
-- #5		MD-4		Sundar		20-Jul-2017		Implemented Input Doc. for MD
-- #6		Ken-12838, 12835	Sundar		29-Aug-2017		Implemented Input Doc 3.0 enhancements
-- #7		PI-829,830	Sundar		1-Sep-2017		Changed the field from CO to CNO
-- #8		CAPAVE-1244	Sundar		12-Sep-2017		Changed the "Application Date" field mapping from DateReceived to DateCreated
-- #9		PI-831		Sundar		18-Sep-2017		Changed ProviderTypeDetail value from Code+Description to only Code
--#10		KEN-14452	Sundar		15-Nov-2017		Query tuning activities
-- #11		CAPAVE-2587	Sundar		14-Feb-2018		Changed the reference table for the field Business name from pADM_Account to Paccount_PDM_Organization
-- #12      CAPAVE-2576 Ramya       20-April-2018		Changed the reference table for the field Rejectreasoncode  from EDM_AccountInternalUse to pADM_Account
-- #13		CAPAVE-2666 Sundar		28-Feb-2018		Revereted the reference table for the field Business name from pADM_Account to Paccount_PDM_Organization
-- #14		KEN-13850	Sundar		8-Mar-2018		Biller ProviderTypeCode should always display the first 3 characters (Ex. 087a) for DMC in Input Document.
-- #15		KEN-15462	Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- #15		KEN-15462	Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- #16     MD-1286&1287	Ramya		04-April-2018		--MD inpatient and outpatient changes for inputdoc(newly added columns ,NCPDP,FacilityType,NumberOfBed)
-- #17		KEN-16102	Sundar		12-Apr-2018		Added logic for the second account creation
-- #18  	KEN-16102	Sundar		12-Apr-2018		Added logic for the second account creation
-- 19		CAPAVE-3142, 3139 Sundar	8-May-2018	Added EDM_AccountInternalMany.IsApproved = 1 to consider only the approved IUD changes
-- 20       KEN-16609    Ramya       6-June-2018     condition added to display LIC number and effective date based on LIC type and providertype code
-- 21		KEN-17854	Sundar		19-June-2018	Implemented logic to handle "Update Pay-To address for Same NPI & OwnerNo"
-- 22					Sundar		29-June-2018	Tuned this to avoid Blocking session.
-- 23		CAPAVE-3576	 Sundar		13-July-2018	If "Same as SSN" option is selected for EIN field in Portal then, EIN value should not displayed in Input document
-- 24		CAPAVE-3612	 Sundar		13-July-2018	Service County should be displayed only if OutofStateInd is 0
-- 25		KEN-18239	 Sundar		27-Jul-2018		Considered IsPrimary Field for displaying License
-- 26		KEN-19009	 Sundar		1-Oct-2018		Added IsDeleted=0 in Person and Organization tables to eliminate deleted records
-- 27		CAPAVE-3812  Sundar		4-Jan-2019		Spreading LegalName based on NPI and OwnerNo and Spreading BusinessName and MailToAddress based on NPI, OwnerNo and ServiceLocationNo
-- 28		KEN-21177	 Sundar		27-Mar-2019		Added "MFCertificate" type for Mastectomy ProviderType implementation

CREATE PROCEDURE [KYPEnrollment].[sp_Insert_AccountInputDoc]
@acc_party_id INT,
@Username varchar(100),
@UserDate date

AS

BEGIN

	Declare @party_id int
			,@StateCode varchar(2) --Added for #5 MD-4
			,@AccountNumber varchar(20)

	--Added for #17 KEN-16102
	--Added 7/13/18
	IF OBJECT_ID('tempdb..#Tab_MultipleAccounts') IS NOT NULL DROP TABLE #Tab_MultipleAccounts
	Create Table #Tab_MultipleAccounts (AccountID int, PartyID Int);
	Create nonclustered index IDX_TMA on #Tab_MultipleAccounts(accountid,partyid)
		
	Select @AccountNumber = AccountNumber from kypenrollment.padm_Account 
							where AccountID=@acc_party_id
	
	--Added for #17 KEN-16102
	Insert into #Tab_MultipleAccounts(AccountId,Partyid)
	Select AccountID,PartyID 
	from kypenrollment.padm_Account
	Where AccountID = @acc_party_id

	Insert into #Tab_MultipleAccounts(AccountId,Partyid)
	Select AccountID,PartyID 
	from kypenrollment.padm_Account
	Where ApplicationNumber = 
	(Select Top 1 ApplicationNumber
		From Kypenrollment.AccountTransactions
		Where AccountID = @acc_party_id
		Order by AccountTransactionID desc)
	Except
	Select AccountID,PartyID 
	from kypenrollment.padm_Account
		
	/*Added for "Pay-To Address Update happen for Same NPI & OwnerNo" Implementation KEN-17854 Begin */
	IF Exists (select C.CaseID
					from (Select Max(CaseID) CaseID
							From kyp.adm_case With (nolock)
							Where AccountNo=@AccountNumber
							and ResolutionStatus not in ('Denied')
							and MILESTONE='Closed'
							and ActivityStatus='Completed') C
					Join kyp.adm_Case t1 With (nolock) on C.CaseID=T1.CaseID
					Join KYPPORTAL.PortalKYP.padm_application t2 on t1.Number=t2.applicationno
					Join kypenrollment.view_FieldTracking t3 on T2.ApplicationID=t3.ApplicationID
					Where t3.Section in ('Pay to Address','Pay-to Address'))
	Begin
		Insert into #Tab_MultipleAccounts(AccountId,Partyid)
		select t2.AccountID,t2.PartyID 
		From kypenrollment.pADM_Account t1 
		join kypenrollment.pADM_Account t2 on t1.NPI=t2.NPI and t1.OwnerNo=t2.OwnerNo 
		where t1.AccountID = @acc_party_id and T2.AccountID ! = t1.AccountID
		Except
		Select AccountId,Partyid From #Tab_MultipleAccounts
	End	
	/*Added for "Pay-To Address Update happen for Same NPI & OwnerNo" Implementation KEN-17854 End */	
			
	/*Added for Spreading Fields CAPAVE-3812 Begin */
	IF Exists (select C.CaseID
					from (Select Max(CaseID) CaseID
							From kyp.adm_case With (nolock)
							Where AccountNo=@AccountNumber
							and ResolutionStatus <> 'Denied'
							and MILESTONE='Closed'
							and ActivityStatus='Completed') C
					Join kyp.adm_Case t1 With (nolock) on C.CaseID=T1.CaseID
					Join KYPPORTAL.PortalKYP.padm_application t2 on t1.Number=t2.applicationno
					Where t2.UpdateLegalName=1)
	Begin
		Insert into #Tab_MultipleAccounts(AccountId,Partyid)
		select t2.AccountID,t2.PartyID 
		From kypenrollment.pADM_Account t1 
		join kypenrollment.pADM_Account t2 on t1.NPI=t2.NPI and t1.OwnerNo=t2.OwnerNo 
		where t1.AccountID = @acc_party_id and T2.AccountID ! = t1.AccountID
		Except
		Select AccountId,Partyid From #Tab_MultipleAccounts
	End	
	
	IF Exists (select C.CaseID
					from (Select Max(CaseID) CaseID
							From kyp.adm_case With (nolock)
							Where AccountNo=@AccountNumber
							and ResolutionStatus <> 'Denied'
							and MILESTONE='Closed'
							and ActivityStatus='Completed') C
					Join kyp.adm_Case t1 With (nolock) on C.CaseID=T1.CaseID
					Join KYPPORTAL.PortalKYP.padm_application t2 on t1.Number=t2.applicationno
					Where t2.UpdateBusinessName=1 or T2.UpdateMailToAddress=1)
	Begin
		Insert into #Tab_MultipleAccounts(AccountId,Partyid)
		select t2.AccountID,t2.PartyID 
		From kypenrollment.pADM_Account t1 
		join kypenrollment.pADM_Account t2 on t1.NPI=t2.NPI and t1.OwnerNo=t2.OwnerNo and T1.ServiceLocationNo=t2.ServiceLocationNo
		where t1.AccountID = @acc_party_id and T2.AccountID ! = t1.AccountID
		Except
		Select AccountId,Partyid From #Tab_MultipleAccounts
	End		
	/*Added for Spreading Fields CAPAVE-3812 End */
	
	--Added for #5 MD-4
	Select @StateCode = StateCode
	From kyp.OIS_App_Version
			
	-- temp table changes
	SELECT * INTO #INPUT_DOC_TEMP_pADM_Account 
	FROM  KYPEnrollment.pADM_Account 
	where AccountID --= @acc_party_id
					IN (Select AccountID from #Tab_MultipleAccounts)--Added for #17 KEN-16102	

	--set @party_id=(select PartyID from #INPUT_DOC_TEMP_pADM_Account where AccountID=@acc_party_id ) Commented for #17 KEN-16102 

	select H.AddressLine1,H.AddressLine2,H.City,LS.Abreviation,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County,X.Type INTO #INPUT_DOC_TEMP_Address_Location from KYPEnrollment.pAccount_PDM_Address H 
	inner join KYPEnrollment.pAccount_PDM_Location X
		 on H.AddressID = X.AddressID 
		 and X.CurrentRecordFlag=1
		 and X.PartyID --= @party_id
						IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102		 
		 Left join kyp.LK_Screening LS on H.State=LS.Description
		 
	--Changed the logic for #6 Ken-12838, 12835
	--SELECT * INTO #INPUT_DOC_TEMP_pAccount_PDM_Number	 
	--FROM KYPEnrollment.pAccount_PDM_Number where Type='Professional License' AND CurrentRecordFlag=1 and PartyID = @party_id	
	--Select PartyID,Number,EffectiveDate INTO #INPUT_DOC_TEMP_pAccount_PDM_Number	 
	--From (Select PartyId,Number,Type,LastActionDate,EffectiveDate,Row_Number() Over(Partition by Partyid order by Type desc,LastActionDate desc) R
	--		from KYPEnrollment.pAccount_PDM_Number
	--		where PartyID --= @party_id
	--					IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102			
	--			and Type in ('Professional License','Certificate') 
	--			AND CurrentRecordFlag=1) T
	--		Where T.R = 1
	Select PartyID,Number,EffectiveDate INTO #INPUT_DOC_TEMP_pAccount_PDM_Number
	From (Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Row_Number() Over(Partition by t1.Partyid order by isnull(T1.IsPrimary,0) Desc,t1.Type desc,t1.LastActionDate desc) R
			from KYPEnrollment.pAccount_PDM_Number T1
			Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
			where t1.CurrentRecordFlag=1
			and t1.PartyID IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102
			and Type in ('Professional License','Certificate')
			and T2.ProviderTypeCode not in ('021','029')
		Union all
		Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Row_Number() Over(Partition by t1.Partyid order by isnull(T1.IsPrimary,0) Desc,t1.LastActionDate desc) R
			from KYPEnrollment.pAccount_PDM_Number T1
			Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
			where t1.CurrentRecordFlag=1
			and t1.PartyID IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102
			and T1.Number is not null
			and Type in ('orthotistBOC','orthotistABCOP')
			and T2.ProviderTypeCode = '021'	
		Union all
		(Select Tab.PartyID,Tab.Number,Tab.Type,Tab.LastActionDate,Tab.EffectiveDate,Row_Number() Over(Partition by tab.Partyid order by Tab.IsPrimary Desc,tab.LastActionDate desc) R
		From (Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Isnull(T1.IsPrimary,0) IsPrimary
				from KYPEnrollment.pAccount_PDM_Number T1
				Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
				where t1.CurrentRecordFlag=1
				and t1.PartyID IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102
				and T1.Number is not null
				and T2.ProviderTypeCode = '029'	
				and Type in ('prosthetistBOC','prosthetistABCOP','orthProsthABCOP','MFCertificate') --Added "MFCertificate" type for KEN-21177
				Union all
				Select T1.PartyId,SecondNumber,Type,t1.LastActionDate,T1.SecondEffectiveDate,Isnull(T1.IsPrimary,0) IsPrimary
				from KYPEnrollment.pAccount_PDM_Number T1
				Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
				where t1.CurrentRecordFlag=1
				and t1.PartyID IN (Select PartyID from #Tab_MultipleAccounts)--Added for #17 KEN-16102
				and T1.SecondNumber is NOT null
				and T2.ProviderTypeCode = '029'	
				and Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')
				) Tab
			)		
		) T
		Where T.R = 1	

	IF EXISTS(SELECT 1 FROM KYPEnrollment.AccountInputDocFullLoad WHERE AccountID--=@acc_party_id)
																		IN (Select AccountID From #Tab_MultipleAccounts))--Added for #17 KEN-16102	
		delete from KYPEnrollment.AccountInputDocFullLoad where AccountID--=@acc_party_id
																		IN (Select AccountID From #Tab_MultipleAccounts)--Added for #17 KEN-16102			

	IF (@StateCode = 'CA' OR @StateCode IS NULL)	--Added for #5 MD-4
	Begin	--Added for #5 MD-4
	/*	INSERT INTO [KYPEnrollment].[AccountInputDocFullLoad]
			   ([AccountID]
			   ,[PartyID]
			   ,[ProvNameScan]
			   ,[NPI]
			   ,[OwnerNo]
			   ,[SerLocNo]
			   ,[ProviderType]
			   ,[LegalName]
			   ,[SSN]
			   ,[EffectiveBeingDate]
			   ,[EffEndDT]
			   ,[EIN]
			   ,[TINUpdateDate]
			   ,[TINUpdateType]
			   ,[facility]
			   ,[AccountType]
			   ,[ProvLocTypeCd]
			   ,[DBAName]
			   ,[Phone1]
			   ,[AdsL1]
			   ,[AdsL2]
			   ,[City]
			   ,[Acc_State]
			   ,[ZipPlus4]
			   ,[MAdsL1]
			   ,[MAdsL2]
			   ,[MCity]
			   ,[MState]
			   ,[MZipPlus4]
			   ,[SAdsL1]
			   ,[SAdsL2]
			   ,[SCity]
			   ,[SState]
			   ,[SZipPlus4]
			   ,[OutOfStateInd]
			   ,[AppDT]
			   ,[ProvTypeDetail]
			   ,[PracticeCode]
			   ,[StatusAcc]
			   ,[StatusBgnDt]
			   ,[RejResCode]
			   ,[Number]
			   ,[EffDT]
			   ,[CliaNumber]
			   ,[SpecProcTypeCode]
			   ,[CHDPCode]
			   ,[ProvCode]
			   ,[ProvCodeDT]
			   ,[ReEnrollIn]
			   ,[ReEnrollDate]
			   ,[GRPIDTY]
			   ,[LABStat]
			   ,[LABEFFDT]
			   ,[DocNo]
			   ,[ProfileID]
			   ,[FName] --Added for #6 KEN-12838
			   ,[MName] --Added for #6 KEN-12838
			   ,[LName] --Added for #6 KEN-12838
			   ,[Title] --Added for #6 KEN-12838
			   ,[Suffix] --Added for #6 KEN-12838
			   ,CNO --County Code Added for #6 KEN-12838,	Changed for #7 PI-829,830		   
			   )
		select  DISTINCT x.AccountID
				,x.PartyID
				,x.ProvNameScan	
				,NPI
				,OwnerNo
				,ServiceLocationNo as SerLocNo 
				,ProviderTypeCode AS ProviderType
				,LegalName
				,SSN
				,CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffectiveBeingDate
				,CASE CONVERT(varchar(10),x.EffectiveEndDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT
				,EIN
				,CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdateDate
				,TINUpdateType
				,x.facility
				,x.AccountType
				,ProvLocTypeCd
				,BusinessName as DBAName
				,Phone1
				,AddressLine1 as AdsL1
				,AddressLine2 as AdsL2
				,City
				,Acc_State
				,ZipPlus4
				,MAddressLine1 AS MAdsL1
				,MAddressLine2 as MAdsL2
				,MCity
				,MState
				,MZipPlus4
				,SAddressLine1 as SAdsL1 
				,SAddressLine2 as SAdsL2
				,SCity
				,SState
				,SZipPlus4
				,OutOfStateInd--PSS055 PROVIDER DETAIL SCREEN
				,CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT
				--,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail --Commented for #9 PI-831
				,ProviderTypeCode AS ProvTypeDetail --Added for #9 PI-831				
				,PracticeCode
				,StatusAcc
				,CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt
				,StatusReasonCode AS RejResCode--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
				,Number
				,CASE CONVERT(varchar(10),x.EffectiveDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT
				,x.CliaNumber
				,x.SpecProcTypeCode
				,x.CHDPCode
				,x.ProvisionalCode as ProvCode
				,CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT
				,ReEnrolInd as ReEnrollIn,ReEnrollDate
				,GRPIDTY
				,LABStat
				,LABEFFDT
				,AccountNumber AS DocNo
				,ProfileID
				--,@Username
				,FirstName  --Added for #6 KEN-12838
				,MiddleName  --Added for #6 KEN-12838
				,LastName  --Added for #6 KEN-12838
				,Title  --Added for #6 KEN-12838
				,Suffix  --Added for #6 KEN-12838
				,SCounty --Added for #6 KEN-12838		
		from (SELECT 
					A.AccountID As AccountID,
					A.LastActionDate,
					A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
					A.PartyID ,
					A.LegalName AS ProvNameScan,
					A.NPI,
					A.OwnerNo,
					A.ServiceLocationNo,
					Left(A.ProviderTypeCode,3) ProviderTypeCode, --Consider only the first 3 characters for #13 KEN-13850 
					A.ProviderType,
					--PSS059 OWNER SCREEN
					A.LegalName,
					A.SSN,
					isnull(B.EffectiveBeingDate,C.BillingBeginDate) as EffectiveBeingDate,
					isnull(B.EffectiveEndDate,isnull(C.BillingEndDate,'12/31/2069')) as EffectiveEndDate,
					A.EIN,
					C.TINUpdateDate,
					C.TINUpdateType,
					A.ProvLocTypeCd as facility,
					A.AccountType as AccountType,
					c.ProvisionalCode AS ProvLocTypeCd,
					NULL AS CodeIdentification,
					--PSS070 LOCATION SCREEN 
					Case When isnull(A.BusinessName,'')='' Then A.LegalName
							Else A.BusinessName End as BusinessName,--Commented for #10 CAPAVE-2587 --Changed the field reference for CAPAVE-2666 --Changed for #12 CAPAVE-2666 --Added case statement for CAPAVE-2990
					--Q.BusinessName, --Changed for #10 CAPAVE-2587
					(
					Case when T.ParentPartyID is not null and A.AccountType='R' and A.IsDeleted<>'1' 
					and S.PartyID is not null
					and A.IsProvOwnedData='1' then S.Phone1 
					else ISNULL(P.Phone1,Q.Phone1)end   
					)Phone1, /*1*/
					-- TO PAY ADDRESS
					F.AddressLine1,F.AddressLine2,F.City,F.Abreviation as Acc_State,F.ZipPlus4 AS ZipPlus4,
					--MAILING ADDRESS
					G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.Abreviation AS MState,G.ZipPlus4 AS MZipPlus4,
					--SERVICE ADDRESS
					H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.Abreviation AS SState,H.ZipPlus4 AS SZipPlus4,
					C.OutOfStateInd,
					--PSS055 PROVIDER DETAIL SCREEN
					Case when A.LegacyAccountNo is NOT null then A.ApplicationDate
					else --AC.DateReceived
						AC.DateCreated -- Changed the field mapping for #8 CAPAVE-1244					
					End ApplicationDate, --#2	
					A.ProviderType AS ProviderTypeDETAIL,
					C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,
					A.StatusAcc,
					A.StatusBeginDate,
					--C.RejectReasonCode StatusReasonCode, --CAPAVE-2576 Ramya       22-Feb-2018		Changed the reference table for the field --Rejectreasoncode  from EDM_AccountInternalUse to pADM_Account
					replace(LEFT(A.StatusReasonCode , 2),' ','') StatusReasonCode,
					J.Number,
					J.EffectiveDate, --as LIC_EFF_DT,
					K.CliaNumber, --as CLIA_NO,
					C.SpecProcTypeCode, --as SPEC_PROC_TYP,
					C.CHDPCode as CHDPCode, /*Added for CHDP Code*/
					C.ProvisionalCode,
					C.ProvisionalCodeDate,
					C.ReEnrolInd,
					CONVERT(varchar(10),C.ReEnrolDate,101) as ReEnrollDate,
					--PSS038 PHYSICIAN CERTIFICATION
					--L.Speciality_Code,
					Case when(A.AccountType='G') then
					'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
					ELSE 
					'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
					END AS GRPIDTY,
					C.LabStatusCode AS LABStat,
					convert(varchar(10),C.LabStatusCodeDate,101) as LABEFFDT,
					A.AccountNumber
					,Z.ProfileID As ProfileID
					,E.FirstName --Added for #6 KEN-12838
					,E.MiddleName --Added for #6 KEN-12838
					,E.LastName --Added for #6 KEN-12838
					,isnull(E.ProfessionalTitle,E.Salutation) Title --Added for #6 KEN-12838
					,E.Sufix Suffix --Added for #6 KEN-12838
					,CC.Code SCounty --Added for #6 KEN-12838					
			from #INPUT_DOC_TEMP_pADM_Account A 
			LEFT OUTER JOIN 
			KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
			LEFT OUTER JOIN	KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID --and C.CurrentRecordFlag = 1 Reomved since protal data was not setting.
																AND (C.IsApproved = 1 OR C.IsApproved is null) --#15 KEN-15462
			--LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
			--																AND (D.IsApproved = 1 OR D.IsApproved is null)--#19	CAPAVE-3142, 3139											
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
											AND isnull(E.Deleted,0)=0 --Added this condition by Sundar for KEN-21501 on 7-Mar-2019 
			--This is for Pay-to Address Details
			left outer join #INPUT_DOC_TEMP_Address_Location F on F.PartyID = a.PartyID and F.Type='Pay-to'
			--This is for Service Address Details	 
			left outer join #INPUT_DOC_TEMP_Address_Location H on H.PartyID = a.PartyID and H.Type='Servicing'
			Left Join kyp.CA_CountyCodes CC on H.County = CC.Name	--County code Added for #6 KEN-12838			 
			left outer join #INPUT_DOC_TEMP_Address_Location G on G.PartyID = a.PartyID and G.Type='Mailing'
			Left Outer Join #INPUT_DOC_TEMP_pAccount_PDM_Number J ON J.PartyID=A.PartyID --Added for  #6 Ken-12838, 12835			
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party T ON A.PartyID=T.ParentPartyID --Added /*2*/
																			AND T.Type = 'Contact Person' --Added for CAPAVE-910 on 31-Mar-2017 By Sundar
			LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person S ON S.PartyID=T.PartyID  --Added /*2*/
			Left Join kyp.ADM_Case AC with (nolock) on A.ApplicationNumber=AC.Number --#2	
		)x
		where x.AccountID--=@acc_party_id;	
						IN (Select AccountID From #Tab_MultipleAccounts); --Added for #17 KEN-16102*/
						--Added 7/13/18
							;with cte1 as
					(
					select  row_number() over(partition by AccountID		
				order by AccountID) as id,
				x.AccountID
				,x.PartyID
				,x.ProvNameScan	
				,NPI
				,OwnerNo
				,ServiceLocationNo as SerLocNo 
				,ProviderTypeCode AS ProviderType
				,LegalName
				,SSN
				,CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffectiveBeingDate
				,CASE CONVERT(varchar(10),x.EffectiveEndDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT
				,EIN
				,CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdateDate
				,TINUpdateType
				,x.facility
				,x.AccountType
				,ProvLocTypeCd
				,BusinessName as DBAName
				,Phone1
				,AddressLine1 as AdsL1
				,AddressLine2 as AdsL2
				,City
				,Acc_State
				,ZipPlus4
				,MAddressLine1 AS MAdsL1
				,MAddressLine2 as MAdsL2
				,MCity
				,MState
				,MZipPlus4
				,SAddressLine1 as SAdsL1 
				,SAddressLine2 as SAdsL2
				,SCity
				,SState
				,SZipPlus4
				,OutOfStateInd--PSS055 PROVIDER DETAIL SCREEN
				,CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT
				--,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail --Commented for #9 PI-831
				,ProviderTypeCode AS ProvTypeDetail --Added for #9 PI-831				
				,PracticeCode
				,StatusAcc
				,CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt
				,StatusReasonCode AS RejResCode--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
				,Number
				,CASE CONVERT(varchar(10),x.EffectiveDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT
				,x.CliaNumber
				,x.SpecProcTypeCode
				,x.CHDPCode
				,x.ProvisionalCode as ProvCode
				,CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT
				,ReEnrolInd as ReEnrollIn,ReEnrollDate
				,GRPIDTY
				,LABStat
				,LABEFFDT
				,AccountNumber AS DocNo
				,ProfileID
				--,@Username
				,FirstName  --Added for #6 KEN-12838
				,MiddleName  --Added for #6 KEN-12838
				,LastName  --Added for #6 KEN-12838
				,Title  --Added for #6 KEN-12838
				,Suffix  --Added for #6 KEN-12838
				,SCounty --Added for #6 KEN-12838		
		from (SELECT 
					A.AccountID As AccountID,
					A.LastActionDate,
					A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
					A.PartyID ,
					A.LegalName AS ProvNameScan,
					A.NPI,
					A.OwnerNo,
					A.ServiceLocationNo,
					Left(A.ProviderTypeCode,3) ProviderTypeCode, --Consider only the first 3 characters for #13 KEN-13850 
					A.ProviderType,
					--PSS059 OWNER SCREEN
					A.LegalName,
					A.SSN,
					isnull(B.EffectiveBeingDate,C.BillingBeginDate) as EffectiveBeingDate,
					isnull(B.EffectiveEndDate,isnull(C.BillingEndDate,'12/31/2069')) as EffectiveEndDate,
					Case When isnull(A.SSNasEIN,0) = 1 Then NULL Else A.EIN End as EIN, --Added Case Stat. for #23 CAPAVE-3576
					C.TINUpdateDate,
					C.TINUpdateType,
					A.ProvLocTypeCd as facility,
					A.AccountType as AccountType,
					c.ProvisionalCode AS ProvLocTypeCd,
					NULL AS CodeIdentification,
					--PSS070 LOCATION SCREEN 
					Case When isnull(A.BusinessName,'')='' Then A.LegalName
							Else A.BusinessName End as BusinessName,--Commented for #10 CAPAVE-2587 --Changed the field reference for CAPAVE-2666 --Changed for #12 CAPAVE-2666 --Added case statement for CAPAVE-2990
					--Q.BusinessName, --Changed for #10 CAPAVE-2587
					(
					Case when T.ParentPartyID is not null and A.AccountType='R' and A.IsDeleted<>'1' 
					and S.PartyID is not null
					and A.IsProvOwnedData='1' then S.Phone1 
					else ISNULL(P.Phone1,Q.Phone1)end   
					)Phone1, /*1*/
					-- TO PAY ADDRESS
					F.AddressLine1,F.AddressLine2,F.City,F.Abreviation as Acc_State,F.ZipPlus4 AS ZipPlus4,
					--MAILING ADDRESS
					G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.Abreviation AS MState,G.ZipPlus4 AS MZipPlus4,
					--SERVICE ADDRESS
					H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.Abreviation AS SState,H.ZipPlus4 AS SZipPlus4,
					C.OutOfStateInd,
					--PSS055 PROVIDER DETAIL SCREEN
					Case when A.LegacyAccountNo is NOT null then A.ApplicationDate
					else --AC.DateReceived
						AC.DateCreated -- Changed the field mapping for #8 CAPAVE-1244					
					End ApplicationDate, --#2	
					A.ProviderType AS ProviderTypeDETAIL,
					C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,
					A.StatusAcc,
					A.StatusBeginDate,
					--C.RejectReasonCode StatusReasonCode, --CAPAVE-2576 Ramya       22-Feb-2018		Changed the reference table for the field --Rejectreasoncode  from EDM_AccountInternalUse to pADM_Account
					replace(LEFT(A.StatusReasonCode , 2),' ','') StatusReasonCode,
					J.Number,
					J.EffectiveDate, --as LIC_EFF_DT,
					K.CliaNumber, --as CLIA_NO,
					C.SpecProcTypeCode, --as SPEC_PROC_TYP,
					C.CHDPCode as CHDPCode, /*Added for CHDP Code*/
					C.ProvisionalCode,
					C.ProvisionalCodeDate,
					C.ReEnrolInd,
					CONVERT(varchar(10),C.ReEnrolDate,101) as ReEnrollDate,
					--PSS038 PHYSICIAN CERTIFICATION
					--L.Speciality_Code,
					Case when(A.AccountType='G') then
					'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
					ELSE 
					'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
					END AS GRPIDTY,
					C.LabStatusCode AS LABStat,
					convert(varchar(10),C.LabStatusCodeDate,101) as LABEFFDT,
					A.AccountNumber
					,Z.ProfileID As ProfileID
					,E.FirstName --Added for #6 KEN-12838
					,E.MiddleName --Added for #6 KEN-12838
					,E.LastName --Added for #6 KEN-12838
					,isnull(E.ProfessionalTitle,E.Salutation) Title --Added for #6 KEN-12838
					,E.Sufix Suffix --Added for #6 KEN-12838
					--Added for #6 KEN-12838	
					,Case When Isnull(C.OutOfStateInd,'0') = '0' Then CC.Code Else Null End SCounty --Added Case Statement for #24 CAPAVE-3612 									
			from #INPUT_DOC_TEMP_pADM_Account A 
			LEFT OUTER JOIN 
			KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
			LEFT OUTER JOIN	KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID --and C.CurrentRecordFlag = 1 Reomved since protal data was not setting.
																AND (C.IsApproved = 1 OR C.IsApproved is null
																) --#15 KEN-15462
			--LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
			--																AND (D.IsApproved = 1 OR D.IsApproved is null)--#19	CAPAVE-3142, 3139											
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
			--This is for Pay-to Address Details
			left outer join #INPUT_DOC_TEMP_Address_Location F on F.PartyID = a.PartyID and F.Type='Pay-to'
			--This is for Service Address Details	 
			left outer join #INPUT_DOC_TEMP_Address_Location H on H.PartyID = a.PartyID and H.Type='Servicing'
			Left Join kyp.CA_CountyCodes CC on H.County = CC.Name	--County code Added for #6 KEN-12838			 
			left outer join #INPUT_DOC_TEMP_Address_Location G on G.PartyID = a.PartyID and G.Type='Mailing'
			Left Outer Join #INPUT_DOC_TEMP_pAccount_PDM_Number J ON J.PartyID=A.PartyID --Added for  #6 Ken-12838, 12835			
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
																			and isnull(P.Deleted,0)=0 --Added this condition for 26 KEN-19009			
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
																			and isnull(Q.IsDeleted,0)=0 --Added this condition for 26 KEN-19009			
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID
			LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party T ON A.PartyID=T.ParentPartyID --Added /*2*/
																			AND T.Type = 'Contact Person' --Added for CAPAVE-910 on 31-Mar-2017 By Sundar
			LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person S ON S.PartyID=T.PartyID  --Added /*2*/
			Left Join kyp.ADM_Case AC with (nolock) on A.ApplicationNumber=AC.Number --#2	
		)x
		where x.AccountID--=@acc_party_id;	
						IN (Select AccountID From #Tab_MultipleAccounts) --Added for #17 KEN-16102
	)

		INSERT INTO [KYPEnrollment].[AccountInputDocFullLoad]
			   ([AccountID]
			   ,[PartyID]
			   ,[ProvNameScan]
			   ,[NPI]
			   ,[OwnerNo]
			   ,[SerLocNo]
			   ,[ProviderType]
			   ,[LegalName]
			   ,[SSN]
			   ,[EffectiveBeingDate]
			   ,[EffEndDT]
			   ,[EIN]
			   ,[TINUpdateDate]
			   ,[TINUpdateType]
			   ,[facility]
			   ,[AccountType]
			   ,[ProvLocTypeCd]
			   ,[DBAName]
			   ,[Phone1]
			   ,[AdsL1]
			   ,[AdsL2]
			   ,[City]
			   ,[Acc_State]
			   ,[ZipPlus4]
			   ,[MAdsL1]
			   ,[MAdsL2]
			   ,[MCity]
			   ,[MState]
			   ,[MZipPlus4]
			   ,[SAdsL1]
			   ,[SAdsL2]
			   ,[SCity]
			   ,[SState]
			   ,[SZipPlus4]
			   ,[OutOfStateInd]
			   ,[AppDT]
			   ,[ProvTypeDetail]
			   ,[PracticeCode]
			   ,[StatusAcc]
			   ,[StatusBgnDt]
			   ,[RejResCode]
			   ,[Number]
			   ,[EffDT]
			   ,[CliaNumber]
			   ,[SpecProcTypeCode]
			   ,[CHDPCode]
			   ,[ProvCode]
			   ,[ProvCodeDT]
			   ,[ReEnrollIn]
			   ,[ReEnrollDate]
			   ,[GRPIDTY]
			   ,[LABStat]
			   ,[LABEFFDT]
			   ,[DocNo]
			   ,[ProfileID]
			   ,[FName] --Added for #6 KEN-12838
			   ,[MName] --Added for #6 KEN-12838
			   ,[LName] --Added for #6 KEN-12838
			   ,[Title] --Added for #6 KEN-12838
			   ,[Suffix] --Added for #6 KEN-12838
			   ,CNO --County Code Added for #6 KEN-12838,	Changed for #7 PI-829,830		   
			   )
	select AccountID
				,PartyID
				,ProvNameScan	
				,NPI
				,OwnerNo
				, SerLocNo 
				, ProviderType
				,LegalName
				,SSN
				, EffectiveBeingDate
				, EffEndDT
				,EIN
				,TINUpdateDate
				,TINUpdateType
				,facility
				,AccountType
				,ProvLocTypeCd
				,DBAName
				,Phone1
				, AdsL1
				, AdsL2
				,City
				,Acc_State
				,ZipPlus4
				, MAdsL1
				, MAdsL2
				,MCity
				,MState
				,MZipPlus4
				, SAdsL1 
				, SAdsL2
				,SCity
				,SState
				,SZipPlus4
				,OutOfStateInd--PSS055 PROVIDER DETAIL SCREEN
				,  AppDT
				--,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail --Commented for #9 PI-831
				, ProvTypeDetail --Added for #9 PI-831				
				,PracticeCode
				,StatusAcc
				, StatusBgnDt
				,RejResCode--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
				,Number
				, EffDT
				,CliaNumber
				,SpecProcTypeCode
				,CHDPCode
				,ProvCode
				, ProvCodeDT
				,ReEnrollIn
				,ReEnrollDate
				,GRPIDTY
				,LABStat
				,LABEFFDT
				, DocNo
				,ProfileID
				--,@Username
				,FirstName  --Added for #6 KEN-12838
				,MiddleName  --Added for #6 KEN-12838
				,LastName  --Added for #6 KEN-12838
				,Title  --Added for #6 KEN-12838
				,Suffix  --Added for #6 KEN-12838
				,SCounty  
				from cte1  where id = 1
	
		
	End --Added for #5 MD-4
	
	--Added the IF statement for #5 MD-4
	If @StateCode = 'MD'
	Begin
		INSERT INTO [KYPEnrollment].[AccountInputDocFullLoad]
			   ([AccountID]
				,MA_ID
				,[NPI]
				,[LegalName]
				,DOB
				,[SAdsL1]
				,[SAdsL2]
				,[SCity]
				,[SState]
				,[SZipPlus4]
				,[SCounty]
				,[OutOfStateInd]
				,[Phone1]
				,[ProviderType]
				,Sort
				,[EIN]			   			   			   			   
				,[SSN]
				,[Number]
				,[EffDT]
				,LicenseExpiryDate
				,[CliaNumber]
				,[LabPermitNo]
				,[DEA]
				,[PracticeType]
				,[RevalidationDate]
				,AppDT
				,StatusAcc
				,StatusBgnDt
				,[PrevProv]
				,[Audit]
				,[AuditDate]
				,[EPSDT]		
				,[AdsL1]
				,[AdsL2]
				,[City]
				,[Acc_State]
				,[ZipPlus4]
				,[MAdsL1]
				,[MAdsL2]
				,[MCity]
				,[MState]
				,[MZipPlus4]							   			   
				--,[MCAIDAgreement]
				--,[NCPDP] --Added for #16
	   --        ,[FacilityType] --Added for #16
	   --        ,[NumberOfBed] --Added for #16
				,UserName	
				,LastLoadedDate							   		
				)
		SELECT 
			AccountID	
			,MAID						
			,NPI	
			,LegalName
			,DOB
			,SAddressLine1
			,SAddressLine2
			,SCity
			,SState
			,SZipPlus4
			,County --Changed for mapping table from Pdm_Address to Edm_AccountInternalUse
			,OutOfStateInd
			,Phone1
			,ProviderType
			,Sort
			,TaxID							
			,SSN
			,LicNo
			,LicBeginDate
			,LicEndDate
			,CliaNumber
			,LabPermitNumber			
			,DEA
			,PracTypeCode									
			,RevalidationDate --Changed for mapping table from Edm_AccountInternalUse to Padm_Account.ReenrollmentDate
			,ApplicationDate
			,StateStatusAcc
			,StatusBeginDate
			,PrevProviderNo
			,AuditIndicator
			,AuditDate
			,EPSDT
			,AddressLine1
			,AddressLine2
			,City
			,Acc_State
			,ZipPlus4	
			,MAddressLine1
			,MAddressLine2
			,MCity
			,MState
			,MZipPlus4
			--,NCPDP --Added for #16
	  --      ,FacilityType --Added for #16
	  --      ,NumberOfBed --Added for #16
			,UserName
			,Getdate()				
		From [kypenrollment].[Vw_MD_InputDoc_FullLoad]			
		Where AccountID=@acc_party_id
		OPTION (MAXDOP 4)
	End	

	drop table #INPUT_DOC_TEMP_pADM_Account
	drop table #INPUT_DOC_TEMP_Address_Location
	drop table #INPUT_DOC_TEMP_pAccount_PDM_Number
	--drop table #userrole --Commented for #4

	--exec KYPEnrollment.Usp_IDoc_Biller @acc_party_id,@Username,@UserDate
 
END

GO

