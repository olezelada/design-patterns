
/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Update_Program_Participation]
	@PartyOwner INT,
	@party_id INT,
	@last_action VARCHAR(1)
AS

BEGIN

	DECLARE @mainParty INT, @TypeAssociation VARCHAR(50), @new_Party_Id INT
	
	DECLARE @partyMoca TABLE (ID INT IDENTITY(1,1),PartyID INT, AccountId int)
	 INSERT INTO  @partyMoca SELECT PartyID, AccountID FROM [KYPEnrollment].[pAccount_PDM_Party] WHERE ParentPartyID= @party_id AND Type='Individual Identification';
	 
	 DECLARE @count_partyMoca_Id INT,@top_PartyMocaId INT, @partyMocaIdUpdate INT, @typeMocaUpdate VARCHAR(20), @account_id int
	 SELECT @top_PartyMocaId = MAX(ID) FROM @partyMoca; 
	 SET @count_partyMoca_Id = 1
	 WHILE @count_partyMoca_Id <= @top_PartyMocaId
	 BEGIN
		dECLARE @PartyAdverse int, @locationID int, @addresID int, @newAddressID int, @realtion int, @ccountid int
		
		select  @PartyAdverse = PartyID,@account_id=AccountId  from @partyMoca where ID=@count_partyMoca_Id;	
		
		select @ccountid = party.AccountID
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID=@PartyOwner and party.Type='Individual Identification'
		
		update addr set CurrentRecordFlag=0		
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID=@PartyOwner and party.Type='Individual Identification'
		
		update party set CurrentRecordFlag=0
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID= @PartyOwner and party.Type='Individual Identification'
		
		update loc set CurrentRecordFlag=0
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID= @PartyOwner and party.Type='Individual Identification'
		
		update prov set CurrentRecordFlag=0
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID= @PartyOwner and party.Type='Individual Identification'
		
		update org set CurrentRecordFlag=0
		from KYPEnrollment.[pAccount_PDM_Party] party 
		inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		inner join [KYPEnrollment].[pAccount_PDM_Organization] org on party.PartyID = org.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Provider] prov on party.PartyID = prov.PartyID
		WHERE party.ParentPartyID= @PartyOwner and party.Type='Individual Identification'
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] 	
			([ParentPartyID],[Type], [AccountID] ,[Name] ,[IsProvider] ,[IsEnrolled] ,[IsTemp] ,[IsActive] ,[LoadType] ,[LoadID] ,[LastLoadDate] ,[DateModified] ,[CurrentRecordFlag]
			,[Source] ,[LastAction] ,[LastActionDate] ,[profile_id],[IsDeleted],[LastActorUserID],[LastActionApprovedBy])
		SELECT @PartyOwner, [Type], @ccountid,[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],[DateModified]
			,1,[Source],@last_action,[DateCreated],[profile_id],[IsDeleted],[LastActorUserID],[LastActorUserID]
			FROM [KYPEnrollment].[pAccount_PDM_Party] WHERE PartyID = @PartyAdverse AND CurrentRecordFlag = 0 AND Type='Individual Identification'
			
		SELECT @new_Party_Id = SCOPE_IDENTITY();
		

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           ([PartyID],[LegalName],[DBAName1],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionReason]
           ,[LastActionComments],[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,[LegalName],[DBAName1],@last_action
           ,[LastActionDate],[LastActorUserID],[LastActionReason]
           ,[LastActionComments],[LastActionApprovedBy],1 FROM [KYPEnrollment].[pAccount_PDM_Organization] WHERE PartyID=@PartyAdverse and CurrentRecordFlag = 0
           

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID],[Category],[Type],[CreatedBy] ,[DateCreated],[IsDeleted],[NPI],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,[Category],[Type],[CreatedBy] ,[DateCreated],[IsDeleted],[NPI],@last_action
           ,[LastActionDate],[LastActorUserID],[LastActionApprovedBy],1 FROM [KYPEnrollment].[pAccount_PDM_Provider] WHERE PartyID=@PartyAdverse and CurrentRecordFlag = 0
           
        INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
           ([AddressLine1],[City], [State], [County], [ZipPlus4]
           ,[LastActionDate],[LastActionReason],[LastActionComments]
           ,[CurrentRecordFlag])
		SELECT [AddressLine1],[City], [State], [County], [ZipPlus4]
           ,[LastActionDate],[LastActionReason],[LastActionComments]
           ,1 FROM [KYPEnrollment].[pAccount_PDM_Address] WHERE AddressID=@addresID and CurrentRecordFlag = 0
           
        SELECT @newAddressID = SCOPE_IDENTITY();
        
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
           ([PartyID],[AddressID],[Type],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,@newAddressID,[type], @last_action
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],1 FROM [KYPEnrollment].[pAccount_PDM_Location] WHERE LocationID=@locationID and CurrentRecordFlag = 0
           
	  SET @count_partyMoca_Id = @count_partyMoca_Id+1
	 END
END


GO

