-- =============================================
-- Author:		Sundar
-- Create date: 
-- Description:	To update flags for EIN, SSN and ServiceAddress for NPI Spreading. CAPAVE-3812
-- =============================================
CREATE TRIGGER TrI_NPI_Spread_UpdateFlags 
   ON  KYP.NPI_Spread_Update_Flag
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;

	Declare @Number varchar(15),
			@SSN varchar(20),
			@EIN varchar(20),
			@NPI varchar(15),
			@OWnerNo  varchar(3)

	Select @Number = ApplicationNo
	From inserted
	
	Select @SSN = Provider_SSN,
			@EIN = Provider_TIN,
			@NPI = Provider_NPI
	from kyp.ADM_Case
	Where Number = @Number
	
	Select @OWnerNo= MAX(OwnerNo)
	from kypenrollment.pADM_Account t1
	Where NPI = @NPI

	
	IF @EIN is not null
	Begin
		IF Exists(Select AccountId
					from kypenrollment.pADM_Account
					Where NPI = @NPI and OwnerNo = @OWnerNo
					and IsDeleted = 0
					and LEFT(StatusAcc,1) in ('1','7','9')
					and AccProcessing=0
					and isnull(EIN,'') <> ''
					and replace(EIN,'-','') <> @EIN)
		Begin
			Update KYP.NPI_Spread_Update_Flag
			Set EIN_Flag = 1
			Where ApplicationNo = @Number;
		End
	End

	IF @SSN is not null
	Begin
		IF Exists(Select AccountId
					from kypenrollment.pADM_Account
					Where NPI = @NPI and OwnerNo = @OWnerNo
					and IsDeleted = 0
					and LEFT(StatusAcc,1) in ('1','7','9')
					and AccProcessing=0
					and isnull(SSN,'') <> ''
					and replace(SSN,'-','') <> @SSN)
		Begin
			Update KYP.NPI_Spread_Update_Flag
			Set SSN_Flag = 1
			Where ApplicationNo = @Number;
		End
	End
	
	IF Exists (	Select IsServiceAddressChange
					from kyp.ADM_CaseExtended
					Where Number=@Number
					and IsServiceAddressChange=1)
	Begin
		If Exists (Select T3.AccountID
						From kyp.ADM_CASE t1
						Join kypenrollment.pADM_Account t2 on t1.AccountNo = AccountNumber
						Join kypenrollment.pADM_Account t3 on T2.NPI=t3.NPI and T2.OwnerNo=T3.OwnerNo and T2.ServiceLocationNo=T3.ServiceLocationNo
						Where T2.AccountID <> t3.AccountID
						and t3.IsDeleted=0
						and LEFT(t3.StatusAcc,1) in ('1','7','9')
						and t3.AccProcessing=0
						and T1.Number = @Number)
		Begin
			Update KYP.NPI_Spread_Update_Flag
			Set ServiceAddress_Flag = 1
			Where ApplicationNo = @Number;		
		End	
	End

END
GO

