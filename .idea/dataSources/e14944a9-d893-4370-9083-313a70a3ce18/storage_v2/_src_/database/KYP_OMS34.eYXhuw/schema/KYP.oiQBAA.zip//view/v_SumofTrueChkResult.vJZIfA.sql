


CREATE VIEW [KYP].[v_SumofTrueChkResult] AS

SELECT SUM(X.cPositive) As cPositive,ApplicationID FROM (

SELECT 
    COUNT(GSAEPLS) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1   where GSAEPLS = 'T' 
GROUP BY ApplicationID, GSAEPLS 

UNION ALL

SELECT 
    COUNT(OIGLEIE) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where OIGLEIE = 'T' 
GROUP BY ApplicationID, OIGLEIE 

UNION ALL

SELECT 
    COUNT(SOR) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SOR = 'T' 
GROUP BY ApplicationID, SOR 

UNION ALL

SELECT 
    COUNT(SSADMF) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SSADMF = 'T' 
GROUP BY ApplicationID, SSADMF 

UNION ALL

SELECT 
    COUNT(DMF) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where DMF = 'T' 
GROUP BY ApplicationID, DMF 

UNION ALL

SELECT 
    COUNT(CourtCheck) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where CourtCheck = 'T' 
GROUP BY ApplicationID, CourtCheck 

UNION ALL


SELECT 
    COUNT(HMSSanction) AS cPositive, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where HMSSanction = 'T' 
GROUP BY ApplicationID, HMSSanction 

UNION ALL


SELECT COUNT(KYP_Watchlist) As cPositive,ApplicationID FROM(

SELECT  IW_NPI_STATUS As KYP_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_NPI_STATUS = 'T'  
	UNION ALL
SELECT  IW_LICENSE_STATUS As KYP_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_LICENSE_STATUS = 'T'  
 UNION ALL
 SELECT  IW_NAME_ADDRESS_STATUS As KYP_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_NAME_ADDRESS_STATUS = 'T'  
 )X GROUP BY ApplicationID,KYP_Watchlist 

UNION ALL



SELECT COUNT(MCSIS_Watchlist) As cPositive,ApplicationID FROM(
SELECT 
    MCSIS_MR_NPI_STATUS AS MCSIS_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NPI_STATUS = 'T' 
GROUP BY ApplicationID, MCSIS_MR_NPI_STATUS 

UNION ALL

SELECT 
    MCSIS_MR_NAME_ADDR_STATUS AS MCSIS_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NAME_ADDR_STATUS = 'T' 
GROUP BY ApplicationID, MCSIS_MR_NAME_ADDR_STATUS 

UNION ALL

SELECT 
    MCSIS_MD_NPI_STATUS AS MCSIS_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NPI_STATUS = 'T' 
GROUP BY ApplicationID, MCSIS_MD_NPI_STATUS 

UNION ALL

SELECT 
    MCSIS_MD_NAME_ADDR_STATUS AS MCSIS_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NAME_ADDR_STATUS = 'T' 
GROUP BY ApplicationID, MCSIS_MD_NAME_ADDR_STATUS 
)X GROUP BY ApplicationID,MCSIS_Watchlist 


UNION ALL
SELECT COUNT(SANDI_Watchlist) As cPositive,ApplicationID FROM(
SELECT 
    SANDI_NPI_STATUS AS SANDI_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_NPI_STATUS = 'T' 
GROUP BY ApplicationID, SANDI_NPI_STATUS 

UNION ALL

SELECT 
    SANDI_LICENSE_STATUS AS SANDI_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_LICENSE_STATUS = 'T' 
GROUP BY ApplicationID, SANDI_LICENSE_STATUS 

UNION ALL

SELECT 
    SANDI_ADDRESS_STATUS AS SANDI_Watchlist, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_ADDRESS_STATUS = 'T' 
GROUP BY ApplicationID, SANDI_ADDRESS_STATUS 
)X GROUP BY ApplicationID,SANDI_Watchlist




)X 
GROUP BY X.ApplicationID


GO

