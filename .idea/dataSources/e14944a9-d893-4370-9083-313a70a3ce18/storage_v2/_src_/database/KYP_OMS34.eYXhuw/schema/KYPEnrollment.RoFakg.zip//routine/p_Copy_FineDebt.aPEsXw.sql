
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar FineDebt recive 3 parametros
-- @partyIdPortal id party old portal ,@partyIdOMS nuevo party id Account, @lastActionUserID nombre de usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_FineDebt]
	@partyIdPortal INT,
	@partyIdOMS INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF((SELECT COUNT([FineDebtID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_FineDebt] WHERE PartyID = @partyIdPortal)>0)
	BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_FineDebt]
	([PartyID] ,
	[Type] ,
	[AgencyName] ,
	[Amount] ,
	[DateIssued] ,
	[DatePaidInFull] ,
	[LastAction],
	[LastActionDate],
	[LastActorUserID]	,
	[LastActionApprovedBy],
	[CurrentRecordFlag],
	[documentInstanceId])
	SELECT @partyIdOMS
	,[Type]
	,[AgencyName]
	,[Amount]
	,[DateIssued]
	,[DatePaidInFull]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[documentInstanceId]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_FineDebt] WHERE PartyID = @partyIdPortal

	SELECT @message = 'New Account_PDM_FineDebt ' + CONVERT(char(10), 'FineDebt copy')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	END					
END


GO

