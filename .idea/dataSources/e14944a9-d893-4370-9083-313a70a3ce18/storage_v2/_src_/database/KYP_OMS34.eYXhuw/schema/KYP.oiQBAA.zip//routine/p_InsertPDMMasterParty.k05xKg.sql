CREATE PROCedure [KYP].[p_InsertPDMMasterParty]
(@ProviderNumber varchar(20) 
 ,@PDM_PartyID int= NULL
 ,@PDM_PartyName varchar(100)
 ,@Type varchar(30) =NULL
 ,@IsDeleted bit = 0

)
as begin 

INSERT INTO [KYP].[PDM_MasterParty]
           ([ProviderNumber]
           ,[PDM_PartyID]
           ,[PDM_PartyName]
           ,[Type]
           ,[IsDeleted])
     VALUES
           (@ProviderNumber
           ,@PDM_PartyID
           ,@PDM_PartyName
           ,@Type
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[PDM_MasterParty]')

end


GO

