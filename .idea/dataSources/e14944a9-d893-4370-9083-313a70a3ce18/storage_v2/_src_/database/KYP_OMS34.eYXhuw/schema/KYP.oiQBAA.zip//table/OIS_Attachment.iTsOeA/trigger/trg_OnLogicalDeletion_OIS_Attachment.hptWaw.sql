




-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle attachment count in the table KYP.FrameworkCount
--				On logical delete in the table KYP.OIS_Attachment
--				The trigger is written with the assumption that logical deletion on table KYP.OIS_Attachment
--				means setting the deleted flag in the table to 1
-- =============================================
CREATE TRIGGER [KYP].[trg_OnLogicalDeletion_OIS_Attachment]
   ON  [KYP].[OIS_Attachment]
   AFTER UPDATE
AS 
BEGIN


	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	--CAPAVE-133 , pd-95
	declare @Alertno varchar(6),
			@Row_Updation_Source varchar(100)
			
	Select @Row_Updation_Source	= Row_Updation_Source From Inserted;
	
	If (@Row_Updation_Source = 'OIS_Attachment') and Update(Row_Updation_Source)
	Begin
		Print 'Skip OIS_Attachment Trigger Execution'
		Return	
	End
	
	select @Alertno = SUBSTRING (AbsolutePath,1,6) from inserted;
		
	select x.alertid INTO #alertsActivityDate 
	from(select alertid from kyp.MDM_Alert with(nolock) 
		where AlertNo=@Alertno and @Alertno is not null)x

	
	select alertid into #DatetoUpdate from (
	select alertid from #alertsActivityDate 
	union
	SELECT ChildAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ParentAlertID 
	in(	select alertid from #alertsActivityDate)
	UNION
	SELECT ParentAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ChildAlertID 
	in(select alertid from #alertsActivityDate))x
		
		
	Update kyp.MDM_Alert set LastActivityDate = GETDATE()
		where alertid in(select alertid from #DatetoUpdate)
	--CAPAVE-133 , pd-95
	
	IF EXISTS (
			SELECT 1 
			FROM INSERTED A 
				INNER JOIN KYP.AttachmentEntity B 
					ON A.AttachmentID = B.AttachmentID 
						AND A.deleted=1
				INNER JOIN KYP.FrameworkCount C
					ON B.AttachmentEntityType = C.FrameworkEntityType 	
						AND B.AttachmentEntityTypeID = C.FrameworkEntityTypeID
		)
	UPDATE A 
		SET A.DocumentCount = case 
									when A.DocumentCount>1 then A.DocumentCount -1 
									else 0  
								end ,
			A.ModifiedDate = getdate(),
			A.ModifiedBy = 'Document Decreased'	
	FROM KYP.FrameworkCount A	
	INNER JOIN KYP.AttachmentEntity B 
		ON A.FrameworkEntityType = B.AttachmentEntityType 
			AND A.FrameworkEntityTypeID = B.AttachmentEntityTypeID
	INNER JOIN INSERTED C
		ON B.AttachmentID = C.AttachmentID 
			AND C.deleted=1
   OPTION(MAXDOP 1)
   


END


GO

