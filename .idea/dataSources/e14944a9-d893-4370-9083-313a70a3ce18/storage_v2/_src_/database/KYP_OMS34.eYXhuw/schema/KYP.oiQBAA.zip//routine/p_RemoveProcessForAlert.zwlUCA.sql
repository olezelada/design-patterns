--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket				Description
--------------------------------------------------------------------------------------------------------
-- 1		03-Apr-2017		Sundar		PI-716					Fix for deleting process Entry issue


CREATE PROCEDURE [KYP].[p_RemoveProcessForAlert] @AlertNo VARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @PARENTID NVARCHAR(MAX)
	DECLARE @Count INT
	DECLARE @parentNos INT

	SET @parentNos = 1

	/*Start #1 PI-176*/		
	Declare @Tab_ProcessEntry Table(
			Id int identity(1,1),
			ParentID int)

	Insert into @Tab_ProcessEntry(ParentId)
	SELECT DISTINCT parent
	FROM [dbo].[PROCESS_TABLE]
	WHERE PROCESSID IN (
			SELECT PROCESSID
			FROM PJ_MDM_ALERT
			WHERE ALERTID IN (
					SELECT ALERTID
					FROM kyp.MDM_Alert
					WHERE AlertNo = @alertno
					)
			);	
	SET @Count = @@RowCount;
		
	--SELECT @Count = count(DISTINCT parent)
	--FROM [dbo].[PROCESS_TABLE]
	--WHERE PROCESSID IN (
	--		SELECT PROCESSID
	--		FROM PJ_MDM_ALERT
	--		WHERE ALERTID IN (
	--				SELECT ALERTID
	--				FROM kyp.MDM_Alert
	--				WHERE AlertNo = @alertno
	--				)
	--		)
	/*End #1 PI-716*/
	
	WHILE (@parentNos <= @Count)
	BEGIN
		--Commented for #1
		--SELECT @PARENTID = x.parent
		--FROM (
		--	SELECT DISTINCT parent
		--		,ROW_NUMBER() OVER (
		--			ORDER BY parent
		--			) AS row
		--	FROM [dbo].[PROCESS_TABLE]
		--	WHERE PROCESSID IN (
		--			SELECT PROCESSID
		--			FROM PJ_MDM_ALERT
		--			WHERE ALERTID IN (
		--					SELECT ALERTID
		--					FROM kyp.MDM_Alert
		--					WHERE AlertNo = @alertno
		--					)
		--			)
		--	) x
		--WHERE x.row = @parentNos
		
		--Added for #1
		Select @PARENTID = ParentId
		From @Tab_ProcessEntry
		Where ID = @parentNos;

		--Commented for #1
		--DELETE
		--FROM [dbo].[PROCESS_TABLE]
		--WHERE PROCESSID IN (
		--		SELECT PROCESSID
		--		FROM dbo.PROCESS_TABLE
		--		WHERE PARENT = @PARENTID
		--		)

		DELETE
		FROM dbo.PROCESS_ACTORS_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_ATTRIBUTES_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_INPUTS_ARRAY_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_INPUTS_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_OUTPUTS_ARRAY_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_RESOURCES_TABLE
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PJ_MDM_ALERT
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_EDGE_TABLE
		WHERE PROCESS_ID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PJ_OIS_USER
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)
		
		--Added for #1
		DELETE
		FROM [dbo].[PROCESS_TABLE]
		WHERE PROCESSID IN (
				SELECT PROCESSID
				FROM dbo.PROCESS_TABLE
				WHERE PARENT = @PARENTID
				)

		DELETE
		FROM dbo.PROCESS_TABLE
		WHERE PARENT = @PARENTID

		SET @parentNos = @parentNos + 1
Print 'Inside RemoveProcessSP:'+@AlertNo+Convert(varchar(10),@parentNos);
	END
END
GO

