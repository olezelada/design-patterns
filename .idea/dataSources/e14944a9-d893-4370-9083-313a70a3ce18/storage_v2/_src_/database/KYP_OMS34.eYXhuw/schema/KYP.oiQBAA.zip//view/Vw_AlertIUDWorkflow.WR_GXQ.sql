

Create View [KYP].[Vw_AlertIUDWorkflow] as
Select
	ROW_NUMBER() over(order by (Select 1)) as AlertIUDID
	,AccountID
    ,AccountNumber
    ,AlertNumber
    ,IUDFildName
    ,UserFullName
    ,Max(case when Old=1 then OldValue else Null end) OldValue
    ,Max(case when new=1 then NewValue else Null end) NewValue
    ,Max(Case when Old=1 then BeginDateOld else Null End) BeginDateOld
    ,Max(Case when Old=1 then BeginDateNew else Null End) BeginDateNew
    ,Max(Case when Old=1 then EndDateOld else Null End) EndDateOld
    ,Max(Case when Old=1 then EndDateNew else Null End) EndDateNew
    ,Max(Case when Old=1 then CHDPOld else Null End) CHDPOld
    ,Max(Case when Old=1 then CHDPNew else Null End) CHDPNew
    from (select *
            ,ROW_NUMBER() over(partition by AccountId,AlertNumber,IUDFildName order by UpdateSummary) Old
            ,ROW_NUMBER() over(partition by AccountId,AlertNumber,IUDFildName order by UpdateSummary desc) New
        from KYPEnrollment.EDM_IUDAlertUpdateSummary
        ) T
    Where (Old=1 or New=1)
    Group by AccountID,AccountNumber,AlertNumber,IUDFildName,UserFullName


GO

