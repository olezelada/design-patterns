

CREATE VIEW [KYP].[v_ApplicationProcessingTimeReport] 
AS
	

	
SELECT 
	ROW_NUMBER() over(order by A.DateReceived Desc) As RID,
	A.CaseID as caseID,
	A.Number As ApplicationNumber,
	A.ApplnType As ApplicationType,
	A.ProviderName As ProviderName,
	COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
	A.TypeDescription As ProviderType,
	--convert(varchar(10), cast(A.DateReceived as date), 101) As DateReceived,	
	A.DateReceived As DateReceived,	
	
	CASE WHEN B.[Received] IS NOT NULL AND B.[Assigned] IS NOT NULL THEN
	DATEDIFF(DAY,[Received],[Assigned])+1
	END AS TimeToAssign,
	
	CASE WHEN B.[Automated Screening Completed] IS NOT NULL AND B.[Closed] IS NOT NULL THEN 
	DATEDIFF(DAY,[Automated Screening Completed],[Closed])+1
	END AS TimeToResolution,
	
	CASE WHEN B.[Accepted] IS NOT NULL AND B.[Assigned] IS NOT NULL THEN 
	DATEDIFF(DAY,[Accepted],[Assigned])+1
	END AS TimeToAccept,
	
	CASE WHEN B.[Assigned] IS NOT NULL AND B.[Proposed Approval] IS NOT NULL THEN 
	DATEDIFF(DAY,[Assigned],[Proposed Approval])+1
	END AS TimeToReview,
	
	CASE WHEN B.[Proposed Approval] IS NOT NULL AND B.[Closed] IS NOT NULL THEN 
	DATEDIFF(DAY,[Proposed Approval],[Closed])+1
	END AS TimeToConfirm,
	
	CASE WHEN B.[Proposed Denial] IS NOT NULL AND B.[Closed] IS NOT NULL THEN 
	DATEDIFF(DAY,[Proposed Denial],[Closed])+1
	END AS TimeToDeny,
	
	CASE WHEN B.[Return to Provider] IS NOT NULL AND B.[Re-Submitted] IS NOT NULL THEN 
	DATEDIFF(DAY,[Return to Provider],[Re-Submitted])+1
	END AS TimeToRTP,
	
	CASE WHEN (B.[Referred to Other] IS NOT NULL OR B.[Referred to Benefits Division] IS NOT NULL OR B.[Referred to Lab Field Services] IS NOT NULL OR B.[Referred to Pharmacy] IS NOT NULL OR B.[Referred to Office of Legal Services (OLS)] IS NOT NULL OR B.[Referred to Audits and Investigations (A&I)] IS NOT NULL OR B.[Referred to Licensing and Certification (L&C)] IS NOT NULL) AND B.[Reverted] IS NOT NULL THEN 
	DATEDIFF(DAY,([Referred to Other]+[Referred to Benefits Division]+[Referred to Lab Field Services]+[Referred to Pharmacy]+[Referred to Office of Legal Services (OLS)]+[Referred to Audits and Investigations (A&I)]+[Referred to Licensing and Certification (L&C)]),[Reverted])+1
	END AS TimeToRefer,
	
	CASE WHEN A.DateResolved is not null then convert(varchar(10),A.DateResolved,101) else 'NA' END As DateClosed,
	COALESCE(LTRIM(RTRIM(NULLIF(A.MILESTONE,''))),'NA') As Milestone,
	COALESCE(LTRIM(RTRIM(NULLIF(A.CurrentlyAssignedToName,''))),'NA') As CurrentUserName
	FROM KYP.ADM_Case A 
	Left JOIN (	Select *
				From (Select CaseID,TemplateValue,MAX(isnull(CompletionDate,GETDATE())) CompletionDate
							From KYP.Milestone_CaseDetail
							Where CompletionDate is not null
							Group by CaseID,TemplateValue) Src Pivot(Max(CompletionDate) for Templatevalue in ([Approved],[Referred to Lab Field Services],[Accepted],
																		[Referred to Other],[Referred to Benefits Division],[Assigned],[Return to Provider],[Moratorium Review Pending],[Referred to Pharmacy],[Close As Duplicate],
																		[Referred to Audits and Investigations (A&I)],[Referred to Licensing and Certification (L&C)],[Automated Screening Completed],[Proposed Approval/Denial],
																		[Reverted],[Re-Submitted],[Withdrawn],[Referred to Office of Legal Services (OLS)],[Proposed Denial],[Resubmitted Application Review],[Screening Reviewed],
																		[Proposed Approval],[Auto-Denial],[Application Reviewed],[Received],[Approved/Denied],[Denied],[Submitted],[RTP Response Not Received],[Closed],[In Portal])) P
																		) B ON B.CaseID = A.CaseID						
	WHERE A.IsPPURequired = 0  AND A.WFProcessing = 0


GO

