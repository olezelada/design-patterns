
CREATE TRIGGER [KYP].[trg_Migrating_Ois_UserLinkedAppDetail] ON [KYP].[OIS_User]
AFTER INSERT
AS
BEGIN

	DECLARE @PersonID INT
	,@UserID VARCHAR(100)
	,@FullName VARCHAR(100)

	SELECT @PersonID = PersonID
		,@UserID = UserID
		,@FullName = FullName
	FROM inserted

	INSERT INTO KYP.OIS_UserLinkedAppDetail(Count,UserID,ApplicationNo,GroupApplicationNo,PersonID,LastActorUserID,LastActionDate,FullName)
	SELECT DISTINCT 0,@UserID,NULL,GroupApplicationNo,@PersonID,NULL,GETDATE(),@FullName
	FROM KYP.OIS_UserLinkedAppDetail

END


GO

