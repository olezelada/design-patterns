



CREATE VIEW [KYPEnrollment].[v_OutEDI_NMP_D_File]
AS
SELECT row_number() OVER (ORDER BY AccountID ASC) AS ID, *
FROM         
(
 Select DISTINCT x.AccountID,x.AccountType,x.IsDeleted,x.LastActionDate,DateCreated ,x.AccountUpdatedBy
 
 ,x.RequestType,x.TransactionType ,x.NPI,SUBSTRING(x.LegalName,1,28) AS LegalName -- Leave on empty column
,SUBSTRING(x.SAddressLine1,1,100) AS SAddressLine1,SUBSTRING(x.SAddressLine2,1,100) AS SAddressLine2,SUBSTRING(x.SCity,1,50) AS SCity
,(SELECT Abreviation FROM [KYP].[LK_Screening] where TypeID=4 and Description=x.SState) AS SState,SUBSTRING(x.SZipPlus4,1,5) AS SZip
,SUBSTRING(x.SZipPlus4,7,10) AS SZipPlus4
-- Leave on empty column
,SUBSTRING(x.MAddressLine1,1,100) AS MAddressLine1N,SUBSTRING(x.MAddressLine2,1,100) AS MAddressLine2,SUBSTRING(x.MCity,1,50) AS MCity
,(SELECT Abreviation FROM [KYP].[LK_Screening] where TypeID=4 and Description=x.MState) AS MState,SUBSTRING(x.MZipPlus4,1,5) AS MZip,SUBSTRING(x.MZipPlus4,7,10) AS MZipPlus4

,x.SSN --Check with Swati 
,x.StatusValue1,x.EffectiveBeginDate1,x.EffectiveEndDate1
,x.StatusValue2,x.EffectiveBeginDate2,x.EffectiveEndDate2
,x.StatusValue3,x.EffectiveBeginDate3,x.EffectiveEndDate3
,x.StatusValue4,x.EffectiveBeginDate4,x.EffectiveEndDate4
,x.StatusValue5,x.EffectiveBeginDate5,x.EffectiveEndDate5

,x.Reenrollment,x.ReenrollmentDate,NULL as CN404R31,x.ProvisionalCode,x.ProvisionalCodeDate,x.AccountUpdateDate

from( 
select 
Case When(CONVERT(VARCHAR, A.DateCreated , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)) then 'ADDP' else 'UPDP' END AS RequestType
,'N' AS TransactionType,A.LastActionDate --LastActionDate for fetch the data based on specific date
,A.NPI,A.LegalName,A.SSN,A.StatusAcc,A.ReenrollmentIndicator,A.AccountUpdateDate,A.AccountID,A.AccountType,A.IsDeleted,A.DateCreated,A.AccountUpdatedBy
,B.AddressLine1 AS SAddressLine1,B.AddressLine2 AS SAddressLine2,B.City AS SCity,B.State AS SState,B.ZipPlus4 AS SZipPlus4
,C.AddressLine1 AS MAddressLine1,C.AddressLine2 AS MAddressLine2,C.City AS MCity,C.State AS MState,C.ZipPlus4 AS MZipPlus4
,D.ProvisionalCode,D.ProvisionalCodeDate,'Column Not Found' as Reenrollment,'Column Not Found' as ReenrollmentDate
-- 5 occurence of "Provider NMP-ENROL-STAT-DATA Table 
,AS1.StatusValue AS StatusValue1 ,AS1.EffectiveBeginDate AS EffectiveBeginDate1,AS1.EffectiveEndDate AS EffectiveEndDate1

,AS2.StatusValue AS StatusValue2 ,AS2.EffectiveBeginDate AS EffectiveBeginDate2,AS2.EffectiveEndDate AS EffectiveEndDate2
,AS3.StatusValue AS StatusValue3 ,AS3.EffectiveBeginDate AS EffectiveBeginDate3,AS3.EffectiveEndDate AS EffectiveEndDate3
,AS4.StatusValue AS StatusValue4 ,AS4.EffectiveBeginDate AS EffectiveBeginDate4,AS4.EffectiveEndDate AS EffectiveEndDate4
,AS5.StatusValue AS StatusValue5 ,AS5.EffectiveBeginDate AS EffectiveBeginDate5,AS5.EffectiveEndDate AS EffectiveEndDate5

from KYPEnrollment.pADM_Account A
--This is for Service Address Details
left outer join KYPEnrollment.pAccount_PDM_Address B on B.AddressID =(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Servicing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1 )

--This is for Mailing Address Details
left outer join KYPEnrollment.pAccount_PDM_Address C on C.AddressID =(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Mailing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1 )

LEFT OUTER JOIN KYPEnrollment.pADM_AccountStatus AS1 on AS1.AccountStatusID=(Select AccountStatusID from (Select AccountStatusID,ROW_NUMBER()over(PARTITION by AccountID order by CurrentRecordFlag,AccountStatusID desc) as row from KYPEnrollment.pADM_AccountStatus where AccountID=A.AccountID ) X where X.row=1 )

LEFT OUTER JOIN KYPEnrollment.pADM_AccountStatus AS2 on AS2.AccountStatusID=(Select AccountStatusID from (Select AccountStatusID,ROW_NUMBER()over(PARTITION by AccountID order by CurrentRecordFlag,AccountStatusID desc) as row from KYPEnrollment.pADM_AccountStatus where AccountID=A.AccountID ) X where X.row=2 )
LEFT OUTER JOIN KYPEnrollment.pADM_AccountStatus AS3 on AS3.AccountStatusID=(Select AccountStatusID from (Select AccountStatusID,ROW_NUMBER()over(PARTITION by AccountID order by CurrentRecordFlag,AccountStatusID desc) as row from KYPEnrollment.pADM_AccountStatus where AccountID=A.AccountID ) X where X.row=3 )
LEFT OUTER JOIN KYPEnrollment.pADM_AccountStatus AS4 on AS4.AccountStatusID=(Select AccountStatusID from (Select AccountStatusID,ROW_NUMBER()over(PARTITION by AccountID order by CurrentRecordFlag,AccountStatusID desc) as row from KYPEnrollment.pADM_AccountStatus where AccountID=A.AccountID ) X where X.row=4 )
LEFT OUTER JOIN KYPEnrollment.pADM_AccountStatus AS5 on AS5.AccountStatusID=(Select AccountStatusID from (Select AccountStatusID,ROW_NUMBER()over(PARTITION by AccountID order by CurrentRecordFlag,AccountStatusID desc) as row from KYPEnrollment.pADM_AccountStatus where AccountID=A.AccountID ) X where X.row=5 )

left outer join KYPEnrollment.EDM_AccountInternalUse D on D.AccountInternalUseID=(select AccountInternalUseID from KYPEnrollment.EDM_AccountInternalUse where  AccountID=A.AccountID AND CurrentRecordFlag=1)


)  x where x.AccountType='NMP' AND x.IsDeleted=0 AND (x.AccountUpdatedBy is not null or x.AccountUpdatedBy != 'M' )
	AND CONVERT(VARCHAR, x.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE(), 101) 
) z


GO

