
/* ==========================================================
-- Author:		<Juan Zapata>
-- PROCEDURE: create Internal Use Data and return PK ID.   
-- PARAMETERS: 
-- @account_id 
-- @last_Action_User_ID 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_InternalUseData] 	
	@account_id INT,
	@last_Action_User_ID varchar(100)
AS
BEGIN
SET NOCOUNT ON 
	DECLARE 
		@AccountInternalUseID INT,
        @date_Create smalldatetime,
        @message	varchar(200);
		
		SET @date_Create = GETDATE()

 BEGIN
		 INSERT INTO 
			  KYPEnrollment.EDM_AccountInternalUse
			(
			  AccountID,
			  LastAction,
			  LastActorUserID,
			  CurrentRecordFlag,
              LastActionDate
			) 
			VALUES (
			  @account_id,
			  'C',
			  @last_Action_User_ID,
			  1,
              @date_Create
			);
			
		SELECT @AccountInternalUseID = SCOPE_IDENTITY()
	
 END
  SELECT @message = 'New Account Internal Use Data is : ' + CONVERT(char(10), @AccountInternalUseID)
  RAISERROR(@message, 0, 1) WITH NOWAIT  
  RETURN @AccountInternalUseID
END


GO

