-- =============================================
-- Author:		<Zelada Olegario>
-- Create date: <20/08/2018>
-- Description:	<Detects if the new apps have accounts relateds and if his pay to address was modified updates it in all the relateds accounts>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Detect_PayToAddress_NewApps]

@application_no varchar(20),
@last_Action_User_ID VARCHAR(100),
@party_id_app int,
@profile int,
@npi varchar(15),
@main_app_npi varchar(15),
@applicationId int,
@application_type varchar (50)
AS
BEGIN

DECLARE @accounts_affected table (pk int identity(1,1),account_id int);
DECLARE @count int,@account_id int, @tot int,@party_id_acc int,@party_Id int;
DECLARE @ownerNumber varchar (5)

   SELECT @ownerNumber = BillingFutureStatus FROM KYPEnrollment.EDM_ApplicationInternalUse WHERE Applicationnumber = @application_no

    IF (@ownerNumber is null)
        BEGIN
          SELECT @ownerNumber = BillingFutureStatus FROM KYPEnrollment.EDM_SupplementalInternalUse WHERE LastActionComments = @application_no
        END

  IF ((select count(a.AccountID)
      from KYPEnrollment.pADM_Account a
      where a.NPI=@main_app_npi AND a.OwnerNo = @ownerNumber and a.IsDeleted=0 ) > 0 )
  BEGIN

      INSERT INTO @accounts_affected (account_id)
      select a.AccountID from KYPEnrollment.pADM_Account a
      where a.NPI = @npi AND a.OwnerNo = @ownerNumber and a.IsDeleted = 0

      select @tot = COUNT(*) from @accounts_affected

	  --Added the below Update statement for KEN-21574 by Sundar on 5-Apr-2019
      Update T2
      Set T2.IsProvOwnedData = 1,
			T2.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
      From @accounts_affected t1
      Join kypenrollment.Padm_Account t2 on t1.account_id = T2.AccountID
      Where T2.IsDeleted=0

      print '@tot:'
      print @tot
      SET @count=1;

      WHILE @count<=@tot
        BEGIN

          select @account_id = account_id from @accounts_affected where pk = @count
          select @party_id_acc = PartyID from KYPEnrollment.pADM_Account a where AccountID=@account_id

          EXEC [KYPEnrollment].[sp_Update_Payto_Addresses] @party_id_acc,@party_id_app,'Pay-to';
          SET @count = @count + 1

        END

  END

  ELSE
    return 0
  END
GO

