CREATE VIEW [KYP].[v_MD_RevalidationReport]

As
Select ROW_NUMBER() OVER(order by ID ASC) RowID,  X.* from(

select A.ID,
A.ScheduledBy,
A.RevalidationStartDate as RevalidationStartDate,
A.CreatedOn as RevalidationScheduledDate,
A.FirstExtensionStartDate as FirstExtensionStartDate,
A.FirstExtensionENDDate as StateReviewDate,
A.RevalidationEndDate as RevalidateEndDate,
case when (A.ScheduleType='RE') then 'Re-Enrollment' else 'Revalidation' end as ScheduleType,  
B.ScheduleID,B.ID as AccountRevalidationID ,
CONVERT(varchar(10),A.RevalidationStartDate,101) as AccountID
,C.AccountNumber,
C.LegacyAccountNo,C.LegalName,C.NPI,C.ProviderType, 
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then 'Yes' else 'NO' end AS ApplicationSubmitted,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then convert(varchar(10),D.DateCreated,101) else 'N/A' end AS ApplicationReceivedDate,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then D.Number else 'N/A' end AS Application,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then D.MILESTONE else 'N/A' end AS CurrentMilestone,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then E.FullName  else 'N/A' end AS AssignedUser,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then case when(D.ActivityStatus='Completed') then 
case when (D.ResolutionStatus='Enrolled/Provisional Status Granted' ) then 
'Approved' else 'Denied'end else'N/A' end else 'N/A' end AS RevalidationStatus,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then case when(D.ActivityStatus='Completed') then
convert(varchar(10),D.DateResolved,101) else 'N/A' end else 'N/A' end AS RevalidationEndDate,
case when(B.ReenrollmentStatus in('In Progress (w Enrollment)','Completed'))then case when((D.ResolutionStatus='Denied' 
and D.ActivityStatus='Completed')) then D.ReviewStatus else 'N/A' end else 'N/A' end AS DenialReason,
case when(C.NPIType='Organization') then (isnull (G.Phone1,'N/A')) else  (isnull (F.Phone1,'N/A')) end as PhoneNumber
from 

KYPEnrollment.ScheduledAccounts A
left join KYPEnrollment.AccountRevalidation B on A.ID=B.ScheduleID
left join KYPEnrollment.pADM_Account C on B.AccountID=C.AccountID
--left join KYP.ADM_Case D on D.AccountNo=C.AccountNumber
left join KYP.ADM_Case D on D.Number=b.ApplicationNumber
left join KYP.OIS_User E on D.CurrentlyAssignedToID=E.PersonID
left join KYPEnrollment.pAccount_PDM_Person F on F.Partyid=C.Partyid
left join KYPEnrollment.pAccount_PDM_Organization G on G.Partyid=C.Partyid

)X

--GO














