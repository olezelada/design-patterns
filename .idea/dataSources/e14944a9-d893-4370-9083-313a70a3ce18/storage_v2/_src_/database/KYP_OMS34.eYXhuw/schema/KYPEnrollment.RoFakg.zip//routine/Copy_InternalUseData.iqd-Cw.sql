












-- =============================================
-- Author:		<Rahul Raghavendra>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		KEN-13797			Sundar		19-Sep-2017		Populated LastActionDate in EDM_AccountInternalMany table
-- 2		KEN-13754(CAPAVE-1274)	Sundar	17-Nov-2017		Added CurrentRecordFlag while inserting data to EDM_AccountInternalMany	

CREATE PROCEDURE [KYPEnrollment].[Copy_InternalUseData] 
@applicatioNo VARCHAR(50)

	
AS
BEGIN

SET NOCOUNT ON;

Declare
	@AccountID int,
	@BillingStatus varchar(30),
	@BillingBeginDate smalldatetime,
	@BillingEndDate smalldatetime,
	@BillingFutureStatus varchar(30),
	@BillingFutureDate smalldatetime,
	@BillingComments varchar(500),
	@BillingFutureComments varchar(500),
	@ProvisionalCode varchar(2),
	@ProvisionalCodeDate smalldatetime,
	@ProvisionalCodeDesc varchar(200),
	@LabStatusCode varchar(30),
	@LabSpecCodeDesc varchar(200),
	@LabStatusCodeDate smalldatetime,
	@OutOfStateInd varchar(1),
	@OutOfStateIndDesc varchar(200),
	@SpecProcTypeCodeDesc varchar(200),
	@SpecProcTypeCode varchar(10),
	@ProvCrossReferenceValue varchar(20),
	@CHDPCode varchar(150),
	@AtypicalProviderNo varchar(11),
	@PhyCertCode varchar(2),
	@PhyCertCodeDesc varchar(200),
	@PhyCertCodeEfDate smalldatetime,
	@PracTypeCode1 varchar(1),
	@PracTypeCode1Desc varchar(250),
	@PracTypeCode2 varchar(1),
	@PracTypeCode2Desc varchar(250),
	@TINUpdateType varchar(5),
	@TINUpdateTypeDesc varchar(250),
	@TINUpdateDate smalldatetime,
	@AccInternalUseID int,
	@County varchar(2),
	@CountyDesc varchar(25),
	@PrevProviderNo varchar(20),
	@AuditIndicator varchar(1),
	@AuditDate datetime,
	@PracTypeCode varchar(3),
	@EPSDT varchar(5),
	@CurrentPage Varchar(50),
	@LastActionReaso varchar(max),
	@LastActionComm varchar(500),
	@ApplicationStatusAcc varchar(50),
	@ApplicationReasonCode varchar(max),
	@ApplicationComments varchar(500),
	@FutureStatus varchar(50),
	@FutureStatusReasonCode varchar(max),
	@FutureEnrollComments varchar(500),
	@FutureDate smalldatetime,
	@ApplicationBeginDate smalldatetime,
	@LastActionDat smalldatetime,
	@LastActionDate smalldatetime, 
    @CodeIdentification varchar(10),
    @CodeDescription varchar(250),
    @CodeType varchar(10),
    @CodeDateEffDate smalldatetime,
    @CodeDateExpDate smalldatetime,
    @CreatedBy varchar(100),
    @LastActionReason varchar(MAX),
    @providertypecode varchar(50),
    @Partyid int ,
    @AccountCount int,
    @AppCount int,
    @AccountInternalUseID int,
    @accManyUserID int,
    @state varchar(20),
    @ReEnrolInd varchar(10),
    @ReEnrolDate smalldatetime,
    @SanctionCodeDesc varchAr(20),
    @ISFBP bit,
    @ProvCrossReferenceCode varchar(20),
    @CountSuperUser int,
    @Priority int,
    @Risk varchar(20),
    @AccStatus varchar(50),
    @AccStatusBeginDate smalldatetime,
    @FullName varchar(250)
    
     
BEGIN TRY

select @state=StateCode from KYP.OIS_App_Version

select  @CountSuperUser=count(InfoID)
	from KYP.MDM_JournalBasicInfo journal
	inner join kyp.OIS_Note note on  note.PInID=journal.infoid 
	inner join KYP.ADM_case A on journal.CaseID=A.CaseID
	where A.Number = @applicatioNo and note.Tags='Application Update'
	
select @Priority=AdmCase.Priority,@FullName=oisUser.FullName,@Risk = AdmCase.Risk 
	from KYP.ADM_Case AdmCase
	inner join KYP.OIS_User oisUser on AdmCase.CurrentlyAssignedToID=oisUser.PersonID
	where AdmCase.Number=@applicatioNo
	
	exec Kypenrollment.Usp_DeActivate_Account @applicatioNo
	
update KYP.ADM_case set isRequiresUpdate= case when (@CountSuperUser>0)then 1 else 0 END where Number=@applicatioNo

select @ISFBP=IsFacilityBasedProvider from KYP.ADM_CaseExtended where number=@applicatioNo

if(@ISFBP=1)
BEGIN

	EXEC [KYPEnrollment].[Copy_InternalUseDataForFBP] @applicatioNo
END
else
BEGIN

    SELECT @AccountCount= COUNT(AccountID) FROM [KYPEnrollment].[PAdm_Account]
		WHERE ApplicationNumber =@applicatioNo
	
	while(@AccountCount>0)
		BEGIN
			
			SELECT @providertypecode=Y.ProviderTypeCode,@AccountID = Y.AccountID FROM(
			SELECT row_number() OVER(order by ProviderTypeCode) As RowNumber,ProviderTypeCode,AccountID
			FROM [KYPEnrollment].[PAdm_Account] WHERE ApplicationNumber =@applicatioNo )Y WHERE Y.RowNumber = @AccountCount 
			 
			SELECT  @AccountInternalUseID=[AccountInternalUseID],@BillingStatus =[BillingStatus],@BillingBeginDate =[BillingBeginDate],@BillingEndDate =[BillingEndDate],
					@BillingFutureStatus =[BillingFutureStatus],@BillingFutureDate =[BillingFutureDate],@BillingComments =[BillingComments],
					@BillingFutureComments =[BillingFutureComments],@ProvisionalCode =[ProvisionalCode],@ProvisionalCodeDate =[ProvisionalCodeDate],
					@ProvisionalCodeDesc =[ProvisionalCodeDesc],@LabStatusCode =[LabStatusCode],@LabSpecCodeDesc =[LabSpecCodeDesc],@LabStatusCodeDate =[LabStatusCodeDate],
					@OutOfStateInd =[OutOfStateInd],@OutOfStateIndDesc =[OutOfStateIndDesc],@SpecProcTypeCode =[SpecProcTypeCode],@SpecProcTypeCodeDesc =[SpecProcTypeCodeDesc],
					@ProvCrossReferenceValue =[ProvCrossReferenceValue],@CHDPCode =[CHDPCode], @AtypicalProviderNo =[AtypicalProviderNo],@PhyCertCode =[PhyCertCode],
					@PhyCertCodeDesc =[PhyCertCodeDesc],@PhyCertCodeEfDate =[PhyCertCodeEfDate],@PracTypeCode1 =[PracTypeCode1], @PracTypeCode1Desc=[PracTypeCode1Desc],
					@PracTypeCode2 =[PracTypeCode2],@PracTypeCode2Desc =[PracTypeCode2Desc],@TINUpdateType =[TINUpdateType], @TINUpdateTypeDesc=[TINUpdateTypeDesc],
					@TINUpdateDate =[TINUpdateDate] ,@County=County, @CountyDesc=CountyDesc, @PrevProviderNo=PrevProviderNo, @AuditIndicator=AuditIndicator,
					@AuditDate=AuditDate,  @PracTypeCode=PracTypeCode, @EPSDT=EPSDT,@CurrentPage=[CurrentPage],@LastActionReaso = [LastActionReason],
					@LastActionComm =[LastActionComments], @LastActionDat=[LastActionDate], @ApplicationStatusAcc=[ApplicationStatusAcc],@ApplicationBeginDate=[ApplicationBeginDate],
					@ApplicationReasonCode =[ApplicationReasonCode],@ApplicationComments=[ApplicationComments], @FutureDate=[FutureDate],@FutureStatus=[FutureStatus],
					@FutureStatusReasonCode =[FutureStatusReasonCode],@FutureEnrollComments=[FutureEnrollComments],@ReEnrolInd=[ReEnrolInd],@ReEnrolDate=[ReEnrolDate],
					@SanctionCodeDesc=SanctionCodeDesc,@ProvCrossReferenceCode=ProvCrossReferenceCode
			FROM [KYPEnrollment].[EDM_ApplicationInternalUse]
			WHERE ApplicationNumber= @applicatioNo and  ProviderTypeCode=@providertypecode
					
			
			UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
				SET
					 AccountID = @AccountID
					,BillingStatus = @BillingStatus 
					,BillingBeginDate = @BillingBeginDate 
					,BillingEndDate = @BillingEndDate 
					,BillingFutureStatus = @BillingFutureStatus
					,BillingFutureDate = @BillingFutureDate
					,BillingComments = @BillingComments
					,BillingFutureComments = @BillingFutureComments
					,ProvisionalCode = @ProvisionalCode
					,ProvisionalCodeDate = @ProvisionalCodeDate
					,ProvisionalCodeDesc = @ProvisionalCodeDesc
					,LabStatusCode = @LabStatusCode
					,LabSpecCodeDesc = @LabSpecCodeDesc
					,LabStatusCodeDate = @LabStatusCodeDate
					,OutOfStateInd = @OutOfStateInd
					,OutOfStateIndDesc = @OutOfStateIndDesc
					,SpecProcTypeCode = @SpecProcTypeCode
					,SpecProcTypeCodeDesc = @SpecProcTypeCodeDesc
					,ProvCrossReferenceValue = @ProvCrossReferenceValue
					,CHDPCode = @CHDPCode
					,AtypicalProviderNo = @AtypicalProviderNo
					,PhyCertCode = @PhyCertCode
					,PhyCertCodeDesc = @PhyCertCodeDesc
					,PhyCertCodeEfDate = @PhyCertCodeEfDate
					,PracTypeCode1 = @PracTypeCode1
					,PracTypeCode1Desc = @PracTypeCode1Desc
					,PracTypeCode2 = @PracTypeCode2
					,PracTypeCode2Desc = @PracTypeCode2Desc
					,TINUpdateType = @TINUpdateType
					,TINUpdateTypeDesc = @TINUpdateTypeDesc
					,TINUpdateDate = @TINUpdateDate
					,County=@County
					,CountyDesc=@CountyDesc
					,PrevProviderNo=@PrevProviderNo
					,AuditIndicator=@AuditIndicator
					,AuditDate=@AuditDate
					,PracTypeCode=@PracTypeCode
					,EPSDT=@EPSDT
					,ReEnrolInd=@ReEnrolInd
					,ReEnrolDate=@ReEnrolDate
		WHERE ApplicationNumber= @applicatioNo AND ProviderTypeCode=@providertypecode
		
		UPDATE [KYPEnrollment].[EDM_ApplicationInternalUse]SET AccountID = @AccountID
		WHERE ApplicationNumber = @applicatioNo AND ProviderTypeCode=@providertypecode
		
				
		IF @ReEnrolDate is null --KEN-17331
		BEGIN
			SELECT @ReEnrolDate= ReenrollmentDate FROM [KYPEnrollment].[pADM_Account] where AccountID = @AccountID
		END
		
		--IF(isNULL(@LastActionDat,'') = '' OR isNULL(@FutureDate,'') <> '')
		IF(convert(date,@ApplicationBeginDate)>convert(date,getDate()))
		BEGIN
		UPDATE [KYPEnrollment].[pADM_Account]
		SET
				 StatusAcc = '3 - Pending',
				 StatusBeginDate = @LastActionDat,
				 EnrollStatusComments = @LastActionComm,
				 StatusReasonCode = @LastActionReaso,
				 ApplicationBeginDate = @ApplicationBeginDate,
				 ApplicationComments = @ApplicationComments,
				 ApplicationReasonCode = @ApplicationReasonCode,
				 ApplicationStatusAcc = @ApplicationStatusAcc,
				 FutureDate = @FutureDate,
				 FutureEnrollComments = @FutureEnrollComments,
				 FutureStatus = @FutureStatus,
				 FutureStatusReasonCode = @FutureStatusReasonCode,
				 StateStatusAcc=@ApplicationReasonCode,
				 LegacyAccountNo=@SanctionCodeDesc,
				 ReenrollmentDate=@ReEnrolDate,
				 OwnerNo=case when (@state='MD') then '01' else @BillingFutureStatus END,
				 ServiceLocationNo=case when (@state='MD')then '001' else @ProvCrossReferenceCode END,	
				 UpdateRequired= case when (@CountSuperUser>0)then 1 else 0 END,
				 DeActivationDate= case when isnull(@FutureStatus,'')=''then @FutureDate else @FutureDate-1 END,
				 Risk = @Priority,
				 RiskDescriptor = @Risk,
				 CreatedBy=@FullName,
				 IsDeleted=0,
				 AccProcessing=0,
				 DateCreated=GETDATE()
				 --LastActionDate=GETDATE()
		WHERE AccountID = @AccountID
		END
		ELSE
		BEGIN
		UPDATE [KYPEnrollment].[pADM_Account]
		SET
				 StatusAcc = Isnull(@CurrentPage,'3 - Pending'),
				 StatusBeginDate = @ApplicationBeginDate,
				 EnrollStatusComments = @LastActionComm,
				 StatusReasonCode = @LastActionReaso,
				 ApplicationBeginDate = @ApplicationBeginDate,
				 ApplicationComments = @ApplicationComments,
				 ApplicationReasonCode = @ApplicationReasonCode,
				 ApplicationStatusAcc = @ApplicationStatusAcc,
				 FutureDate = @FutureDate,
				 FutureEnrollComments = @FutureEnrollComments,
				 FutureStatus = @FutureStatus,
				 FutureStatusReasonCode = @FutureStatusReasonCode,
				 StateStatusAcc=@ApplicationReasonCode,
				 LegacyAccountNo=@SanctionCodeDesc,
				 ReenrollmentDate=@ReEnrolDate,
				 OwnerNo=case when (@state='MD') then '01' else @BillingFutureStatus END,
				 ServiceLocationNo=case when (@state='MD')then '001' else @ProvCrossReferenceCode END,	
				 UpdateRequired= case when (@CountSuperUser>0)then 1 else 0 END,
				 Risk = @Priority,
				 RiskDescriptor = @Risk,
				 CreatedBy=@FullName,
				 IsDeleted=0,
				 AccProcessing=0,
				 DateCreated=GETDATE()
				 --LastActionDate=GETDATE()
		WHERE AccountID = @AccountID
		END
		
		--Start the IF statement for CAPAVE-3404
		
		SELECT @AccStatus = [StatusAcc],@AccStatusBeginDate=[StatusBeginDate] FROM KYPEnrollment.pADM_Account WHERE AccountID = @AccountID
		IF(@AccStatus = '1 - Active' OR @AccStatus = '7 - Active Rendering (indirect)') 
		BEGIN
		UPDATE KYPEnrollment.pADM_Account SET ActivationDate= @AccStatusBeginDate WHERE AccountID = @AccountID
		END
		
		-- End the IF statement for CAPAVE-3404
		
		
		declare @MILESTONE varchar(200);
		SELECT @MILESTONE= MILESTONE FROM KYP.ADM_CASE WHERE Number=@applicatioNo;
		
		/*Added for CAPAVE-2629 by Khalid on 22 Feb 2018 STart*/
		If Not Exists(Select AccountID from Kypenrollment.pAccount_Owner Where AccountID = @AccountID)
		Begin
			Insert into KYPEnrollment.pAccount_Owner(AccountID, OwnerNo, EffectiveBeingDate, EffectiveEndDate, LastAction, LastActionDate, LastActorUserID, CurrentRecordFlag)
			Select T1.AccountID, T1.OwnerNo, T2.OwnerEffectiveDate, '2069-12-31', 'c',GETDATE(), 'System', 1
			From Kypenrollment.pADM_Account T1
			Join Kypenrollment.EDM_ApplicationInternalUse T2 on T1.AccountID = T2.AccountID
			Where 
			T1.AccountID = @AccountID
		End
		Else
		Begin
			Update T1
			Set T1.EffectiveBeingDate = T2.OwnerEffectiveDate
			From kypenrollment.pAccount_Owner T1
			Join Kypenrollment.EDM_ApplicationInternalUse T2 on T1.AccountID = T2.AccountID
			Where T1.AccountID = @AccountID;
		End
		/*Added for CAPAVE-2629 by Khalid on 22 Feb 2018 End*/	
		
		Update KYPEnrollment.pAccount_BizProfile_Details
		SET 
		 AccountBillingStatus =@BillingStatus
		,AccountEnrollmentStatus= isnull(@CurrentPage,'3 - Pending')
		,CurrentRecordFlag=1
		,EffectiveBeginDate=@ApplicationBeginDate
		where 
		AccountID=@AccountID
		OPTION (MAXDOP 1);
		
		SELECT @AppCount = COUNT(AccInternalUseManyID) FROM [KYPEnrollment].[EDM_ApplicationInternalMany]
		WHERE AccountInternalUseID =@AccountInternalUseID

		/*update portal table with value Approved*/
			update KYPPORTAL.PortalKYP.pADM_Case set Status='Approved' where Number=@applicatioNo
		/*update portal table with value Approved END*/
		
		--update KYPEnrollment.pADM_Account set AccProcessing=0 where AccountID = @AccountID
		
		if(@state='MD')
		BEGIN
			Declare @MDStatusAcc Varchar(50);
			Select @Partyid= Partyid from [KYPEnrollment].pADM_Account where AccountID=@AccountID
			update [KYPEnrollment].[pAccount_PDM_Speciality] set ISUpdate=1, Partyid=@Partyid where AppNumber=@applicatioNo
			Select @MDStatusAcc=StatusAcc from kypenrollment.padm_account where AccountID=@AccountID
			update kypenrollment.pAccount_BizProfile_Details Set AccountEnrollmentStatus=@MDStatusAcc where AccountID=@AccountID

		END
	
	    SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_AccountInternalUse] WHERE AccountID=@AccountID
		
		WHILE(@AppCount > 0)
			BEGIN

				SELECT @accManyUserID=X.AccInternalUseManyID FROM(
				SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
				FROM [KYPEnrollment].[EDM_ApplicationInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID )X WHERE X.RowNumber = @AppCount
			
				SELECT @CodeIdentification =[CodeIdentification],@CodeDescription =[CodeDescription],@CodeType =[CodeType],
				@CodeDateEffDate =[CodeDateEffDate],@CodeDateExpDate =[CodeDateExpDate],@CreatedBy =[CreatedBy],@LastActionReason =[LastActionReason]
				,@LastActionDate = LastActionDate --Added for #1 KEN-13797		
				FROM [KYPEnrollment].[EDM_ApplicationInternalMany]
				WHERE AccInternalUseManyID =@accManyUserID AND ISNULL(isDeleted,0) = 0

		
				IF NOT EXISTS(SELECT 1 FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID = @AccInternalUseID
			    AND CodeIdentification = @CodeIdentification AND ISNULL(isDeleted,0) = 0)
					BEGIN
							INSERT INTO [KYPEnrollment].[EDM_AccountInternalMany]
							([AccountInternalUseID]
							,[CodeIdentification]
							,[CodeDescription]
							,[CodeType]
							,[CodeDateEffDate]
							,[CodeDateExpDate]
							,[CreatedBy]
							,[LastActionReason]
							,LastActionDate --Added for #1 KEN-13797		
							,CurrentRecordFlag
							,isDeleted --Added for CAPAVE-1274
							,Row_Updation_Source --Added for DBAB-321 on 21-Sep-2018 by Sundar
							)
							VALUES(
							@AccInternalUseID,
							@CodeIdentification 
							,@CodeDescription 
							,@CodeType 
							,@CodeDateEffDate
							,@CodeDateExpDate
							,@CreatedBy
							,@LastActionReason
							,@LastActionDate --Added for #1 KEN-13797
							,1 --Added for CAPAVE-1274
							,0
							,'Trigger_return'	--Added for DBAB-321 on 21-Sep-2018 by Sundar		
							)
					END
								
			SET @AppCount = @AppCount - 1
			
	
		END
		SET @AccountCount = @AccountCount - 1

		/*Start - Added the below 2 Update statements by Sundar for Elk Implementation on 25 Feb 2019*/
		Update T1
		Set T1.LastActionDate = Getdate()
		From kypenrollment.paccount_BizProfile_Master t1
		Join kypenrollment.paccount_BizProfile_Details t2 on t1.ProfileID = t2.ProfileID
		Where T2.AccountId = @AccountID
		OPTION (MAXDOP 1);
		
		Update kypenrollment.pAccount_PDM_Number
		Set LastActionDate = GETDATE()
		Where PartyID = (Select PartyID from Kypenrollment.pADM_Account where AccountID = @AccountID);
		/*End - Added the 2 Update statements by Sundar for Elk Implementation on 25 Feb 2019*/	

	END
	END
END TRY	
BEGIN CATCH
 IF @@TRANCOUNT > 0
 ROLLBACK TRANSACTION 
 
 
 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'ApplicationNo',@KeyValue = @applicatioNo; 
 
 END CATCH	
END


GO

