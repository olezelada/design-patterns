CREATE VIEW [KYP].[v_RelatedAlerts]
AS
SELECT TOP (100) PERCENT   
					row_number() OVER (ORDER BY Par.AlertNo,Chi.AlertNo  ASC) AS ID,	
					R.ParentAlertID,
					Par.AlertNo as ParentAlertNo,
					R.ChildAlertID,
					Chi.AlertNo as ChildAlertNo,
					R.RelationshipType,
					Chi.MatchPercent,
					Chi.WatchedPartyName as PartyName,	
					Chi.WatchlistName,
					Chi.DateInitiated as Date,
					Chi.CurrentWFMinorStatus as WorkFlowStep							
FROM 
KYP.MDM_RelatedAlerts R 
INNER JOIN KYP.MDM_Alert Par
	ON R.ParentAlertID = Par.AlertID AND ISNULL(R.IsDeleted,0) = 1 AND ISNULL(Par.IsDeleted,0) = 1 				
INNER JOIN KYP.MDM_Alert Chi
	ON R.ChildAlertID = Chi.AlertID AND ISNULL(Chi.IsDeleted,0) = 1 				

ORDER BY Par.AlertNo ASC


GO

