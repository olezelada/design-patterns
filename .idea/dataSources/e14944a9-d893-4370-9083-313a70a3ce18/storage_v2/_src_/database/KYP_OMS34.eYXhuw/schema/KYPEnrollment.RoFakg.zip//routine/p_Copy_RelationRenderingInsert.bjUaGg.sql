

-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_RelationRenderingInsert]
	@accountID INT,
	@providerNumber varchar(15),
	@lastActionUserID varchar(100)
AS
BEGIN
    DECLARE @renderingID INT,
			@affiliatedAccountID INT,
			@providerNumberA varchar(15),
			@isCount INT,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
			
	DECLARE RelationRendering_Cursor CURSOR FOR 	
	select pren.[rendering_affiliation_id],pren.[rendering_providerNumber] from [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] AS pren WHERE [group_providerNumber] = @providerNumber
	
	OPEN RelationRendering_Cursor;
	FETCH NEXT FROM RelationRendering_Cursor INTO @renderingID, @providerNumberA
	
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		SET @isCount = 0
				
		SELECT @isCount = COUNT(DISTINCT [Number])FROM [KYP].[ADM_Case] WHERE ([ResolutionStatus]='Approved' AND [Number] = @providerNumberA);
		SELECT @affiliatedAccountID = acc.AccountID FROM [KYPEnrollment].[pADM_Account] acc WHERE ApplicationNumber = @providerNumber and IsDeleted = '1'
		IF(@isCount=1)
		BEGIN
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			([AccountID]
			,[AffiliatedAccountID]
			,[TypeAffiliation]
			,[LastActionDate]
			,[LastActorUserID]
			,[LastActionApprovedBy]
			,[CurrentRecordFlag]
			,[LastAction]
			,[isDeleted])
			SELECT @accountID
			,@affiliatedAccountID
			,[type_affiliation]
			,@dateCreated
			,@lastActionUserID
			,@lastActionUserID
			,'1'
			,'C'
			,0
			FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] WHERE [rendering_affiliation_id] = @renderingID
		END
		FETCH NEXT FROM RelationRendering_Cursor INTO @renderingID, @providerNumberA			
	END;
	CLOSE RelationRendering_Cursor;
	DEALLOCATE RelationRendering_Cursor;
END


GO

