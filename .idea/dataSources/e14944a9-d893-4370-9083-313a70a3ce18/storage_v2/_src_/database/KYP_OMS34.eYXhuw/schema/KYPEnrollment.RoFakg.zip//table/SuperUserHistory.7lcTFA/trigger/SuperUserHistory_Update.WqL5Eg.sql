


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYPEnrollment].[SuperUserHistory_Update] ON [KYPEnrollment].[SuperUserHistory]
AFTER INSERT
AS
BEGIN
--SET NOCOUNT  ON
Declare
@AccountID int,
@TabName varchar(500),
@FieldName varchar(500),
@OldValue varchar(500),
@NewValue varchar(500),
@LastActionDate smalldatetime,
@LastActorUserID varchar(100),
@ManyKeyField varchar(500),
@ManyKeyValue varchar(500),
@FindingID int,
@Comments varchar(500),
@PrimaryID int,
@SectionName varchar(500)

SET @AccountID = (select AccountID from inserted);
SET @TabName = (select TabName from inserted);
SET @FieldName = (select FieldName from inserted);
SET @OldValue = (select OldValue from inserted);
SET @NewValue = (select NewValue from inserted);
SET @LastActionDate = (select LastActionDate from inserted);
SET @LastActorUserID = (select LastActorUserID from inserted);
SET @ManyKeyField = (select ManyKeyField from inserted);
SET @ManyKeyValue = (select ManyKeyValue from inserted);
SET @FindingID = (select FindingID from inserted);
SET @Comments = (select Comments from inserted);
SET @PrimaryID = (select PrimaryID from inserted);
SET @SectionName = (select SectionName from inserted);



EXEC [KYPEnrollment].[SP_SuperUserHistory] @AccountID,@TabName,@FieldName,@OldValue,@NewValue,@LastActionDate,@LastActorUserID,@ManyKeyField,@ManyKeyValue,
@FindingID,@Comments,@PrimaryID,@SectionName
END


GO

