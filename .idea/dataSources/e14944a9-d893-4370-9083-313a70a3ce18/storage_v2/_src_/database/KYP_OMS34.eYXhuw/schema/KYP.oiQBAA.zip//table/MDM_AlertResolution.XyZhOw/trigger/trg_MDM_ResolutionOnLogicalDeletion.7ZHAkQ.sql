

-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 13/03/2015
-- Description:	Ensure that Logical Deletion in MDM_AlertResolution is propagated to all child tables
-- =============================================
CREATE TRIGGER [KYP].[trg_MDM_ResolutionOnLogicalDeletion] ON [KYP].[MDM_AlertResolution]
AFTER UPDATE
AS
BEGIN

	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF @Row_Updation_Source = 'KYP.p_WF_DeleteRelatedData' AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END

	--CAPAVE-133 , pd-95
	declare @Alertid int
	
	select @Alertid = AlertID from inserted;
		
	select x.alertid INTO #alertsActivityDate 
	from(select alertid from kyp.MDM_Alert with(nolock) 
		where AlertID=@Alertid and @AlertID is not null)x

	
	select alertid into #DatetoUpdate from (
	select alertid from #alertsActivityDate 
	union
	SELECT ChildAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ParentAlertID 
	in(	select alertid from #alertsActivityDate)
	UNION
	SELECT ParentAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ChildAlertID 
	in(select alertid from #alertsActivityDate))x
		
		
	Update kyp.MDM_Alert set LastActivityDate = GETDATE()
		where alertid in(select alertid from #DatetoUpdate)
	--CAPAVE-133 , pd-95
	
	
	IF NOT EXISTS (
			SELECT 1
			FROM inserted
			WHERE IsDeleted = 1
			)
		RETURN;
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.MDM_AlertNewResolutions A WITH (NOLOCK)
			JOIN inserted B WITH (NOLOCK) ON A.ResolutionID = B.ResolutionID
			)
		UPDATE A
		SET IsDeleted = 1
		FROM KYP.MDM_AlertNewResolutions A
		JOIN inserted B ON A.ResolutionID = B.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.MDM_AlertOIGReferral A WITH (NOLOCK)
			JOIN inserted B WITH (NOLOCK) ON A.ResolutionID = B.ResolutionID
			)
		UPDATE A
		SET IsDeleted = 1
		FROM KYP.MDM_AlertOIGReferral A
		JOIN inserted B ON A.ResolutionID = B.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.MDM_AlertPIUReferral A WITH (NOLOCK)
			JOIN inserted B WITH (NOLOCK) ON A.ResolutionID = B.ResolutionID
			)
		UPDATE A
		SET IsDeleted = 1
		FROM KYP.MDM_AlertPIUReferral A
		JOIN inserted B ON A.ResolutionID = B.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.MDM_AlertPvdSuspension A WITH (NOLOCK)
			JOIN inserted B WITH (NOLOCK) ON A.ResolutionID = B.ResolutionID
			)
		UPDATE A
		SET IsDeleted = 1
		FROM KYP.MDM_AlertPvdSuspension A
		JOIN inserted B ON A.ResolutionID = B.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.OIS_Note A WITH (NOLOCK)
			JOIN KYP.MDM_AlertPvdSuspension B WITH (NOLOCK) ON A.NoteID = B.ResolutionNoteID
			JOIN inserted C WITH (NOLOCK) ON B.ResolutionID = C.ResolutionID
			)
		UPDATE A
		SET Deleted = 1
		FROM KYP.OIS_Note A
		JOIN KYP.MDM_AlertPvdSuspension B ON A.NoteID = B.ResolutionNoteID
		JOIN inserted C ON B.ResolutionID = C.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.OIS_Note A WITH (NOLOCK)
			JOIN KYP.MDM_AlertPIUReferral B WITH (NOLOCK) ON A.NoteID = B.ResolutionNoteID
			JOIN inserted C WITH (NOLOCK) ON B.ResolutionID = C.ResolutionID
			)
		UPDATE A
		SET Deleted = 1
		FROM KYP.OIS_Note A
		JOIN KYP.MDM_AlertPIUReferral B ON A.NoteID = B.ResolutionNoteID
		JOIN inserted C ON B.ResolutionID = C.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.OIS_Note A WITH (NOLOCK)
			JOIN KYP.MDM_AlertOIGReferral B WITH (NOLOCK) ON A.NoteID = B.ResolutionNoteID
			JOIN inserted C WITH (NOLOCK) ON B.ResolutionID = C.ResolutionID
			)
		UPDATE A
		SET Deleted = 1
		FROM KYP.OIS_Note A
		JOIN KYP.MDM_AlertOIGReferral B ON A.NoteID = B.ResolutionNoteID
		JOIN inserted C ON B.ResolutionID = C.ResolutionID

	IF EXISTS (
			SELECT 1
			FROM KYP.OIS_Note A WITH (NOLOCK)
			JOIN KYP.MDM_AlertNewResolutions B WITH (NOLOCK) ON A.NoteID = B.ResolutionNoteID
			JOIN inserted C WITH (NOLOCK) ON B.ResolutionID = C.ResolutionID
			)
		UPDATE A
		SET Deleted = 1
		FROM KYP.OIS_Note A
		JOIN KYP.MDM_AlertNewResolutions B ON A.NoteID = B.ResolutionNoteID
		JOIN inserted C ON B.ResolutionID = C.ResolutionID
END


GO

