

CREATE PROCEDURE [KYPEnrollment].[ORP_Service_Address](
 @account_id INT,
 @acc_party_id INT,
 @is_update BIT = 0
)
AS
BEGIN
 SET NOCOUNT ON 

 DECLARE 
 @address_id INT,
 @new_address_id INT,
 @full_address VARCHAR(250)

 SELECT TOP 1 @address_id = address.AddressID FROM KYPEnrollment.pAccount_PDM_Location location INNER JOIN KYPEnrollment.pAccount_PDM_Address address
 ON location.AddressID = address.AddressID WHERE location.PartyID IN (SELECT PartyID FROM KYPEnrollment.pAccount_PDM_Party WHERE ParentPartyID=@acc_party_id and Type='BusinessProfileOrp') 
 AND location.Type= 'BusinessProfileOrp' AND location.CurrentRecordFlag=1 AND address.CurrentRecordFlag=1 ORDER BY address.AddressID ASC
 
 IF @is_update = 0 AND NOT EXISTS(SELECT AddressID FROM KYPEnrollment.pAccount_PDM_Location WHERE PartyID =@acc_party_id AND Type= 'Servicing')
 BEGIN
  PRINT 'CREATE SERVICE ADDRESS ORP'
  INSERT INTO [KYPEnrollment].[pAccount_PDM_Address] (
    [AddressLine1] ,
	[AddressLine2] ,
	[County] ,
	[City] ,
	[Zip] ,
	[ZipPlus4] ,
	[State] ,
	[Country] ,
	[Latitude] ,
	[Longitude] ,
	[GeographicArea],	
	[LastAction],
    [LastActionDate],
    [LastActionUserID],
    [LastActionApprovedByUsedID],
    [CurrentRecordFlag])
   SELECT [AddressLine1] ,
	[AddressLine2] ,
	[County] ,
	[City] ,
	[Zip] ,
	[ZipPlus4] ,
	[State] ,
	[Country] ,
	[Latitude] ,
	[Longitude] ,
	[GeographicArea],	
	[LastAction],
    [LastActionDate],
    [LastActionUserID],
    [LastActionApprovedByUsedID],
    [CurrentRecordFlag] 
   FROM [KYPEnrollment].[pAccount_PDM_Address] WHERE AddressID=@address_id;
   
   SET @new_address_id = SCOPE_IDENTITY();
   
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
	([AddressID] ,
	[PartyID] ,
	[Type] ,
	[WorkingDays] ,
	[WorkingHours] ,
	[Phone1] ,
	[Phone2] ,
	[Fax] ,
	[Remarks] ,
	[InActive] ,
	[Email] ,
	[IsLicensed] ,
	[IsRented] ,
	[Status] ,
	[Name],
	[IsDeleted],
	[LastAction],
    [LastActionDate],
    [LastActorUserID],
    [LastActionApprovedBy],
    [CurrentRecordFlag])
    SELECT @new_address_id ,
	@acc_party_id ,
	'Servicing' ,
	[WorkingDays] ,
	[WorkingHours] ,
	[Phone1] ,
	[Phone2] ,
	[Fax] ,
	[Remarks] ,
	[InActive] ,
	[Email] ,
	[IsLicensed] ,
	[IsRented] ,
	[Status] ,
	[Name],
	[IsDeleted],
	[LastAction],
    [LastActionDate],
    [LastActorUserID],
    [LastActionApprovedBy],
    [CurrentRecordFlag] 
    FROM [KYPEnrollment].[pAccount_PDM_Location] WHERE AddressID=@address_id;
    
    					 
	SELECT @full_address = (ad.AddressLine1+', '+ISNULL(ad.AddressLine2,'')+', '+ISNULL(ad.City,'')+' - '+
								 (ISNULL((SELECT TOP 1 lks.Abreviation 
									FROM [KYP].LK_Screening lks 
									WHERE lks.Description = ad.State) ,''))
								 +', '+ISNULL(ad.ZipPlus4,'') )
	FROM [KYPEnrollment].[pAccount_PDM_Address] AS ad  WHERE AddressID = @address_id;						 
								 
	SET @full_address = REPLACE(@full_address,', ,',', ');
	
	UPDATE [KYPEnrollment].[pADM_Account] SET PracticeAddress = ISNULL(@full_address,'') WHERE AccountID=@account_id;
 END
 ELSE
 BEGIN
  PRINT 'UPDATE SERVICE ADDRESS ORP'
  SELECT @new_address_id = AddressID FROM KYPEnrollment.pAccount_PDM_Location WHERE PartyID =@acc_party_id  AND Type= 'Servicing' AND CurrentRecordFlag=1
  
  UPDATE serviceAddress SET serviceAddress.[AddressLine1]=orpAddress.[AddressLine1],
   serviceAddress.[AddressLine2]=orpAddress.[AddressLine2],
   serviceAddress.[County] = orpAddress.[County],
   serviceAddress.[City] = orpAddress.[City],
   serviceAddress.[Zip] = orpAddress.[Zip],
   serviceAddress.[ZipPlus4] = orpAddress.[ZipPlus4],
   serviceAddress.[State] = orpAddress.[State],
   serviceAddress.[Country] = orpAddress.[Country],
   serviceAddress.[Latitude] = orpAddress.[Latitude],
   serviceAddress.[Longitude] = orpAddress.[Longitude],
   serviceAddress.[GeographicArea] = orpAddress.[GeographicArea],	
   serviceAddress.[LastAction] = orpAddress.[LastAction],
   serviceAddress.[LastActionDate] = orpAddress.[LastActionDate],
   serviceAddress.[LastActionUserID] = orpAddress.[LastActionUserID],
   serviceAddress.[LastActionApprovedByUsedID] = orpAddress.[LastActionApprovedByUsedID],
   serviceAddress.[CurrentRecordFlag] = orpAddress.[CurrentRecordFlag] 
   FROM KYPEnrollment.pAccount_PDM_Address serviceAddress,KYPEnrollment.pAccount_PDM_Address orpAddress
   WHERE serviceAddress.AddressID= @new_address_id AND orpAddress.AddressID=@address_id;
   
   UPDATE serviceLocation SET serviceLocation.[WorkingDays] = orpLocation.[WorkingDays],
	serviceLocation.[WorkingHours] = orpLocation.[WorkingHours],
	serviceLocation.[Phone1] = orpLocation.[Phone1],
	serviceLocation.[Phone2] = orpLocation.[Phone2],
	serviceLocation.[Fax] = orpLocation.[Fax],
	serviceLocation.[Remarks] = orpLocation.[Remarks],
	serviceLocation.[InActive] = orpLocation.[InActive],
	serviceLocation.[Email] = orpLocation.[Email],
	serviceLocation.[IsLicensed] = orpLocation.[IsLicensed],
	serviceLocation.[IsRented] = orpLocation.[IsRented],
	serviceLocation.[Status] = orpLocation.[Status],
	serviceLocation.[Name] = orpLocation.[Name],
	serviceLocation.[IsDeleted] = orpLocation.[IsDeleted],
	serviceLocation.[LastAction] = orpLocation.[LastAction],
    serviceLocation.[LastActionDate] = orpLocation.[LastActionDate],
    serviceLocation.[LastActorUserID] = orpLocation.[LastActorUserID],
    serviceLocation.[LastActionApprovedBy] = orpLocation.[LastActionApprovedBy],
    serviceLocation.[CurrentRecordFlag] = orpLocation.[CurrentRecordFlag]
    FROM KYPEnrollment.pAccount_PDM_Location serviceLocation,KYPEnrollment.pAccount_PDM_Location orpLocation
   WHERE serviceLocation.AddressID= @new_address_id AND orpLocation.AddressID=@address_id;
  
  SELECT @full_address = (ad.AddressLine1+', '+ISNULL(ad.AddressLine2,'')+', '+ISNULL(ad.City,'')+' - '+
								 (ISNULL((SELECT TOP 1 lks.Abreviation 
									FROM [KYP].LK_Screening lks 
									WHERE lks.Description = ad.State) ,''))
								 +', '+ISNULL(ad.ZipPlus4,'') )
  FROM [KYPEnrollment].[pAccount_PDM_Address] AS ad  WHERE AddressID = @address_id;						 
								 
  SET @full_address = REPLACE(@full_address,', ,',', ');
	
  UPDATE [KYPEnrollment].[pADM_Account] SET PracticeAddress = ISNULL(@full_address,'') WHERE AccountID=@account_id;
 END
END


GO

