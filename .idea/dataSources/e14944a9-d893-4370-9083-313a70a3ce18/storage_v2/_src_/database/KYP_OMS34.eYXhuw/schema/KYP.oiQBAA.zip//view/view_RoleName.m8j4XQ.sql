





CREATE VIEW [KYP].[view_RoleName]
AS
select ROW_NUMBER() over(order by newid()) RoleUID,stuff((
    select ','+ [RoleName]
    FROM (select [RoleName]
    FROM 
 KYP.WF_RoleWF A
left join KYP.OIS_App_Version B on A.StateCode=B.StateCode ) RN
for XML PATH('')), 1, 1, '') RoleName


GO

