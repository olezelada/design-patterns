



CREATE VIEW [KYP].[v_SummaryOrganizationReport]
AS
SELECT     
convert(varchar(20),AppPartyID)+'-'+isnull(CONVERT(varchar(20),nid),'') as id,
--row_number() OVER (ORDER BY Q.PartyID ASC) AS ID,
 *
FROM         
(
SELECT  TOP (100) PERCENT n.id as nid,A.PartyID, D.AddressLine1, D.AddressLine2, D.State, D.Zip, D.ZipPlus4, 
H.NPI AS NPICheck, 
               
               CASE 
					WHEN H.StrAttr1 = 'Y' THEN 'Not Disclosed' 
					ELSE A.LegalName
               END LegalName,
               
               CASE 
					WHEN H.NPI = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),A.NPI)
               END NPI,
               
                CASE 
					WHEN H.TIN = 'Y' THEN 'Not Disclosed' 
					ELSE (
				     SUBSTRING(A.TIN, 1, 2) + '-' + 
                    SUBSTRING(A.TIN, 3,15)
                  )
               END TIN,
               --CASE 
				--	WHEN H.TIN = 'Y' THEN 'Not Disclosed' 
				--	ELSE CONVERT(varchar(15),A.TIN)
             --  END TIN,
               
               CASE 
					WHEN H.City = 'Y' THEN 'Not Disclosed' 
					ELSE D.City
               END City,
               
               CASE 
					WHEN H.OIGLEIE = 'T' THEN 'Active' 
					WHEN H.OIGLEIE = 'F' THEN 'Not Present' 
					WHEN H.OIGLEIE = 'P' THEN 'Likely Active'
					ELSE 'Not Present'
				END AS OIGLEIECheckResult, 
               CASE 
					WHEN H.GSAEPLS = 'T' THEN 'Active' 
					WHEN H.GSAEPLS = 'F' THEN 'Not Present' 
					WHEN H.GSAEPLS = 'P' THEN 'Likely Active'
					ELSE 'Not Present'
				END AS GSAEPLSCheckResult, 
				
			   CASE
					 WHEN H.SANDI_NPI_STATUS = 'T' OR H.SANDI_LICENSE_STATUS = 'T' OR H.SANDI_ADDRESS_STATUS = 'T' THEN 'Active'
					 WHEN H.SANDI_NPI_STATUS = 'P' OR H.SANDI_LICENSE_STATUS = 'P' OR H.SANDI_ADDRESS_STATUS = 'P' THEN 'Likely Active'
					 ELSE 'Not Present'
			   END AS SandICheckResult,
					 	
               CASE 
					WHEN H.StrAttr1 = 'T' THEN 'True' 
					WHEN H.StrAttr1 = 'P' THEN 'Partial' 
					WHEN H.StrAttr1 = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.StrAttr1 = 'N' THEN 'Negative'
					WHEN H.StrAttr1 = 'X' THEN 'Not Found' 
					WHEN H.StrAttr1 = 'Y' THEN 'Found (Not Disclosed)'
               END AS NameCheckResult, 
               CASE 
					WHEN H.NPI = 'T' THEN 'True' 
					WHEN H.NPI = 'P' THEN 'Partial' 
					WHEN H.NPI = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.NPI = 'F' THEN 'Negative'
					WHEN H.NPI = 'X' THEN 'Not Found' 
					WHEN H.NPI = 'Y' THEN 'Found (Not Disclosed)' 
			    END AS NPICheckResult,
                CASE 
					WHEN H.TIN = 'T' THEN 'True' 
					WHEN H.TIN = 'P' THEN 'Partial' 
					WHEN H.TIN = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.TIN = 'F' THEN 'Negative'
					WHEN H.TIN = 'X' THEN 'Not Found' 
					WHEN H.TIN = 'Y' THEN 'Found (Not Disclosed)'  
				END AS TAXIDCheckResult,
                CASE 
					WHEN H.City = 'T' THEN 'True' 
					WHEN H.City = 'P' THEN 'Partial' 
					WHEN H.City = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.City = 'F' THEN 'Negative'
					WHEN H.City = 'X' THEN 'Not Found' 
					WHEN H.City = 'Y' THEN 'Found (Not Disclosed)'   
                END AS AddressCheckResult,
                CASE 
					WHEN H.CourtCheck = 'T' THEN 'Yes'
					ELSE 'None' 
                END AS AddverseActionCheck,
                
                 CASE
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'')))='' THEN NULL 
					WHEN I.AffiliationCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.AffiliationCount)+' Found' 
                 END AS AffiliationCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(I.SanctionCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.SanctionCount,'')))='' THEN NULL 
					WHEN I.SanctionCount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,I.SanctionCount)+' Found' 
                 END AS SanctionCount,
                 
                 CASE 
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'0')))='0' THEN 'None'
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'')))='' THEN 'None' 
					WHEN I.AffiliationCount IS NULL THEN 'None'
					ELSE 'Found (Not Disclosed)' 
                 END AS AffiliationCheckResult,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(I.OrgBankruptciesCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.OrgBankruptciesCount,'')))='' THEN NULL 
					WHEN I.OrgBankruptciesCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.OrgBankruptciesCount)+' Bankruptcies Found' 
                 END AS OrgBankruptciesCount,
                 CASE
					WHEN ltrim(rtrim(isnull(I.OrgBusinessSearchCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.OrgBusinessSearchCount,'')))='' THEN NULL 
					WHEN I.OrgBusinessSearchCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.OrgBusinessSearchCount)+' BusinessSearch Found' 
                 END AS OrgBusinessSearchCount,
                 CASE
					WHEN ltrim(rtrim(isnull(I.OrgSanctionsCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.OrgSanctionsCount,'')))='' THEN NULL  
					WHEN I.OrgSanctionsCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.OrgSanctionsCount)+' Sanctions Found' 
                 END AS OrgSanctionsCount,
                 
                 CASE 
					WHEN ltrim(rtrim(isnull(I.OrgCriminalCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.OrgCriminalCount,'')))='' THEN NULL 
					WHEN I.OrgCriminalCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.OrgCriminalCount)+' Criminal Found' 
                 END AS OrgCriminalCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(I.OrgTaxLiensCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.OrgTaxLiensCount,'')))='' THEN NULL 
					WHEN I.OrgTaxLiensCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.OrgTaxLiensCount)+' TaxLiens Found' 
                 END AS OrgTaxLiensCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSADDRESSCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSADDRESSCount,'')))='' THEN NULL  
					WHEN N.HMSADDRESSCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,N.HMSADDRESSCount)+' Found' 
                 END AS HMSADDRESSCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSDEACount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSDEACount,'')))='' THEN NULL   
					WHEN N.HMSDEACount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,N.HMSDEACount)+' Found' 
                 END AS HMSDEACount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSLICENSECount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSLICENSECount,'')))='' THEN NULL  
					WHEN N.HMSLICENSECount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,N.HMSLICENSECount)+' Found' 
                 END AS HMSLICENSECount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSNPICount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSNPICount,'')))='' THEN NULL   
					WHEN N.HMSNPICount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,N.HMSNPICount)+' Found' 
                 END AS HMSNPICount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSTAXIDCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSTAXIDCount,'')))='' THEN NULL  
					WHEN N.HMSTAXIDCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,N.HMSTAXIDCount)+' Found' 
                 END AS HMSTAXIDCount,
                 
                 CASE 
					 WHEN H.IW_NPI_STATUS = 'T' OR H.IW_LICENSE_STATUS = 'T' OR H.IW_NAME_ADDRESS_STATUS = 'T' THEN 'Active'
					 ELSE 'Not Present'
                  END AS KYPWATCHLIST,
                  CASE 
					 WHEN H.MCSIS_MD_NAME_ADDR_STATUS = 'T' OR H.MCSIS_MD_NPI_STATUS = 'T' OR H.MCSIS_MR_NAME_ADDR_STATUS = 'T' OR H.MCSIS_MR_NPI_STATUS='T' THEN 'Active'
					 ELSE 'Not Present'
                  END AS MCSISWATCHLIST,
                 
                 CASE 
					WHEN H.OIGLEIE = 'T' THEN X.EXCLUDATE 
					WHEN H.OIGLEIE ='F' THEN '' 
				  END AS EXCLUDATE,
				 CASE 
					WHEN H.OIGLEIE = 'T' THEN  X.EXCLUTYPE 
					WHEN H.OIGLEIE ='F' THEN '' 
				  END AS EXCLUTYPE,
				  
				 CASE 
					WHEN H.GSAEPLS = 'T' THEN X.ACTIONDATE 
					WHEN H.GSAEPLS ='F' THEN '' 
				  END AS ACTIONDATE,
				  CASE 
					WHEN H.GSAEPLS = 'T' THEN X.ACTIONTYPE 
					WHEN H.GSAEPLS ='F' THEN '' 
				  END AS ACTIONTYPE,
				 NULL AS BusResDetail, 
				 NULL AS FillingOfficeName,
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='SanctionsRecord') + ' Found' AS SanctionsRecord,			 
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='CriminalRecord') + ' Found' AS CriminalRecord,
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='LienJudgeDolanRecord')+ ' Found' AS LienJudgeDolanRecord,
				 'Name' as NameText,'Address' as AddressText,'Name:' as NameColonText,'Role:' as RoleText,
				 'Adverse Actions/ Negative News' as AdverseActionsText,'OIG LEIE' as OIGLEIEText,'SAM' as SAMText,
				 'MCSIS' as MCSISText,'KYP Watchlist' as KYPWatchlistText,
				 'NPI' as NPIText,'TAXID' as TAXIDText,'Affiliations' as AffiliationsText,
				 'Type:' as TypeText,'Date:' as DateText,'Agency:' as ActionText,
				 CASE WHEN (SELECT COUNT(*) FROM KYP.OIS_App_Version WHERE StateCode = 'MD')>0
				 THEN 'DEEM Watchlist '
				 ELSE 'S&I Watchlist ' 
				 END
				 as SandIWatchlistText,
				 
                H.TIN AS TINCheck, H.City AS CityCheck, H.GSAEPLS, H.OIGLEIE, G.AppPartyID, G.ScreeningID, B.Name,B.Name+';' as NameComaText , G.PartyType AS PartyRole
                
FROM  KYP.SDM_ApplicationParty AS G 
		LEFT JOIN KYP.PDM_Organization AS A ON A.PartyID = G.PartyID AND G.IsActive=1
		LEFT JOIN KYP.PDM_Party AS B ON A.PartyID = B.PartyID AND B.IsDeleted <> 1 
		LEFT JOIN KYP.PDM_Location AS C ON A.PartyID = C.PartyID AND C.IsDeleted <> 1 
		AND C.LocationID in(select MAX(LocationID) from KYP.PDM_Location where PartyID = A.PartyID)
		LEFT JOIN KYP.PDM_Address AS D ON C.AddressID = D.AddressID 
		LEFT JOIN KYP.SDM_DBCheckResult AS H ON G.ScreeningID = H.ScreeningID 
		LEFT JOIN KYP.SDM_DBCheckDetail AS I ON I.DBChkResultID = H.DBChkResultID 
		LEFT JOIN KYP.SDM_ProvMasterData AS N ON N.ScreeningID=G.ScreeningID 
		LEFT JOIN (
					SELECT 'Date: '+ CONVERT(VARCHAR(25), CONVERT(DATETIME, EXCLUDATE), 101) + ' Found' AS EXCLUDATE,
					COALESCE('Type: related to '  +',','') +(SELECT DESCRIPTION FROM KYP.HMS_ProvORG_OIGLEIE_ExclusionType B WHERE ISNULL(B.EXCLTYPE,'') = ISNULL(KYP.ReportWatchListData.EXCLUTYPE,''))  
					+ ' Found' AS EXCLUTYPE,
					'Date: '+ CONVERT(VARCHAR(25), CONVERT(DATETIME, ACTIONDATE), 101) + ' Found' AS ACTIONDATE,
					'Agency: related to ' + ACTIONTYPE + ' Found' AS ACTIONTYPE,
					ScreeningID
			FROM KYP.ReportWatchListData WHERE OIGPartyID IS NOT NULL AND OIGPartyID <> ''
		)X ON G.ScreeningID = X.ScreeningID  
		
	 
		
)Q


GO

