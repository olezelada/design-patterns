

--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket					Description
--------------------------------------------------------------------------------------------------------
-- 1		30-Jun-2017		Sundar		CAPAVE-254					Updated 5 fields from MDM_StageAlerts to KYP.MDM_AlertDetailPartyMatch
-- 2		04-Jul-2017		Sundar(Rajesh)		CAPAVE-334					Update NPI from MDM_Alert with the value of PDM_PartyNPI from MDM_AlertDetailPartyMatch table

CREATE PROCEDURE [KYP].[p_AlertDetailColorMatch]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Cursor_AlertID INT
		,@Cursor_forFunction VARCHAR(200)
		,@Cursor_Specialty VARCHAR(150)
		,@Cursor_TaxID VARCHAR(20)
		,@Cursor_NPI INT
		,@Cursor_License VARCHAR(20)
		,@Cursor_dbFlag VARCHAR(20)
		,@Cursor_LicenseState VARCHAR(20)
		,@Cursor_Address VARCHAR(400)
		,@Cursor_AddressLine1 VARCHAR(100)
		,@Cursor_City VARCHAR(25)
		,@Cursor_State VARCHAR(25)
		,@Cursor_Zip VARCHAR(25)
		,
		/*TYPE OF MATCH & COLOR*/
		@MatchValNone VARCHAR(20)
		,@MatchValPartial VARCHAR(20)
		,@MatchValFull VARCHAR(20)
		,@MatchValNoneColor VARCHAR(30) = NULL
		,--added by Hareesha Panoor. http://jira/browse/KYP-4230
		@MatchValPartialColor VARCHAR(30)
		,@MatchValFullColor VARCHAR(30)
		,@WatchedPartyID INT
		,@WatchedPartyType VARCHAR(50)
		,
		/*Variables used for Name Matching*/
		@Split1 VARCHAR(50)
		,@Split2 VARCHAR(50)
		,@NameMatchCount INT
		,@iter INT
		,@found VARCHAR(10)
		,
		/*Variables used for DOB Matching*/
		@WL_DOBNullCheck VARCHAR(30)
		,@PDM_DOBNullCheck VARCHAR(30)
		,
		/*Variables used for Speciality*/
		@PDM_SpecialtyCount INT
		,@SpecialtyPriority INT = 0
		,
		/*Variables used for TaxID*/
		@PDM_TaxIDCount INT
		,@PDM_TaxIDOMSCount INT
		,@TaxIDPriority INT = 0
		,
		/*Variables used for NPI*/
		@PDM_NPICount INT
		,@NPIPriority INT = 0
		,
		/*Variables used for License*/
		@PDM_LicenseCount INT
		,@LicensePriority INT = 0
		,
		/*Variables used for Address*/
		@PDM_AddressCount INT
		,@AddressPriority INT = 0
		,
		/*INSERT VARIABLES*/
		@WL_FullName VARCHAR(500)
		,@WL_FName VARCHAR(50)
		,@WL_MName VARCHAR(50)
		,@WL_LName VARCHAR(50)
		,@WL_OrgName VARCHAR(500)
		,@PDM_PartyFullName VARCHAR(500)
		,@PDM_PartyFName VARCHAR(100)
		,@PDM_PartyMName VARCHAR(100)
		,@PDM_PartyLName VARCHAR(100)
		,@WL_DOB DATETIME
		,@PDM_PartyDOB DATETIME
		,@WL_DOD DATETIME
		,--New Watchlist change (Hareesha Panoor)
		@WL_SSN VARCHAR(15)
		,@PDM_PartySSN VARCHAR(15)
		,@PDM_PartySSNSource VARCHAR(50)
		,@WL_UPIN VARCHAR(10)
		,@PDM_PartyUPIN VARCHAR(10)
		,@WL_Alias VARCHAR(50)
		,@PDM_PartyAlias VARCHAR(50)
		,@WL_TaxID VARCHAR(20)
		,@PDM_PartyTaxID VARCHAR(20)
		,@PDM_PartyTaxIDSource VARCHAR(50)
		,@PDM_PartyTaxIDOMSSource VARCHAR(50)
		,@WL_NPI INT
		,@PDM_PartyNPI INT
		,@WL_License VARCHAR(20)
		,@WL_LicenseState VARCHAR(2)
		,@PDM_PartyLicense VARCHAR(20)
		,@PDM_PartyLicenseSource VARCHAR(20)
		,@PDM_PartyLicenseState VARCHAR(2)
		,@WL_Specialty VARCHAR(150)
		,@PDM_PartySpecialty VARCHAR(150)
		,@WL_Address VARCHAR(300)
		,@PDM_PartyAddress VARCHAR(MAX)
		,@WL_AddressLine1 VARCHAR(100)
		,@WL_City VARCHAR(25)
		,@WL_State VARCHAR(25)
		,@WL_Zip VARCHAR(5)
		,@PDM_PartyAddressLine1 VARCHAR(100)
		,@PDM_PartyCity VARCHAR(25)
		,@PDM_PartyState VARCHAR(25)
		,@PDM_PartyZip VARCHAR(5)
		,
		/*INSERT MATCH & COLOR MATCH VARIABLES*/
		@NameMatch VARCHAR(20)
		,@NameMatchColor VARCHAR(50)
		,@DOBMatch VARCHAR(20)
		,@DOBMatchColor VARCHAR(50)
		,@SSNMatch VARCHAR(20)
		,@SSNMatchColor VARCHAR(50)
		,@UPINMatch VARCHAR(20)
		,@UPINMatchColor VARCHAR(50)
		,@AliasMatch VARCHAR(20)
		,@AliasMatchColor VARCHAR(50)
		,@TaxIDMatch VARCHAR(20)
		,@TaxIDMatchColor VARCHAR(50)
		,@NPIMatch VARCHAR(20)
		,@NPIMatchColor VARCHAR(50)
		,@LicenseMatch VARCHAR(20)
		,@LicenseMatchColor VARCHAR(50)
		,@LicenseState VARCHAR(2)
		,@SpecialtyMatch VARCHAR(20)
		,@SpecialtyMatchColor VARCHAR(50)
		,@AddressMatch VARCHAR(20)
		,@AddressMatchColor VARCHAR(50)
		,@SanctionOffense VARCHAR(255)
		,@SanctionBoard VARCHAR(255)
		,@SanctionAction VARCHAR(255)
		,@SanctionDate DATETIME
		,@SAM_TermDate VARCHAR(25)
		,@SAM_ActionDate VARCHAR(25)
		,@SAM_Agency VARCHAR(25)
		,@LEIE_EXCLType VARCHAR(50)
		,@LEIE_EXCLDate VARCHAR(25)
		,@LEIE_REINDATE VARCHAR(25)
		,@IdentCurrent INT
		,@List VARCHAR(MAX)
		,@isTwoWay BIT --Hareesha Panoor: to populate 2 way name and other details, http://jira/browse/KYP-8044

	--TRUNCATE TABLE KYP.MDM_AlertDetailPartyMatch
	/*SET MATCH VALUE AND MATCH COLOR HERE*/
	SELECT @MatchValNone = 'NoMatch'

	SELECT @MatchValPartial = 'NoMatch' /*Removed the color details (KYP-18883) 'PartialMatch'*/

	SELECT @MatchValFull = 'NoMatch' /*Removed the color details (KYP-18883) 'FullMatch'*/

	--commented by Hareesha Panoor . http://jira/browse/KYP-4230
	SELECT @MatchValNoneColor = 'Color[r=255,g=255,b=255]' /*COLORS ARE CHANGED BY:PULLAIAH.*/

	SELECT @MatchValPartialColor = 'Color[r=255,g=255,b=255]' /*Removed the color details (KYP-18883) 'Color[r=255,g=255,b=204]'*/

	SELECT @MatchValFullColor = 'Color[r=255,g=255,b=255]' /*Removed the color details (KYP-18883) 'Color[r=204,g=255,b=204]'*/

	DECLARE @pmfloaddate DATETIME

	SELECT TOP 1 @pmfloaddate = fileloaddate
	FROM KYP.MDM_MonthlyActiveProvider
	ORDER BY id DESC
	
	UPDATE KYP.MDM_AlertDetail SET NPI = NULL WHERE NPI = '0'
	
	UPDATE KYP.MDM_PartyDetail SET NPI = NULL WHERE NPI = '0'
	
	DELETE x
	FROM KYP.MDM_AlertDetailPartyMatch x
	INNER JOIN KYP.MDM_Alert B ON x.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate

	DECLARE mycursor CURSOR
	FOR
	SELECT AlertID
	FROM KYP.MDM_Alert
	WHERE dateinitiated >= @pmfloaddate

	OPEN mycursor

	FETCH NEXT
	FROM mycursor
	INTO @Cursor_AlertID

	/**CURSOR START**/
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @WatchedPartyType = WatchedPartyType
			,@isTwoWay = isTwoWayMatch
		FROM KYP.MDM_Alert
		WHERE AlertID = @Cursor_AlertID

		IF (
				@WatchedPartyType = 'Individual'
				AND @isTwoWay IS NULL
				)
			OR (
				@WatchedPartyType = 'Institutional'
				AND @isTwoWay = 1
				) --Hareesha Panoor: http://jira/browse/KYP-8044
		BEGIN
			/************************** MATCHING NAME FOR INDIVIDUAL ******************************/
			SELECT @WL_FName = ISNULL(FName, '')
				,@WL_MName = ISNULL(MName, '')
				,@WL_LName = ISNULL(LName, '')
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = @Cursor_AlertID

			--SELECT @WL_FullName = @WL_LName + ', ' + @WL_FName + ' ' + @WL_MName
			/** Added below code to fix http://jira/browse/KYP-9180 **/
			SET @WL_FullName = CASE 
					WHEN @WL_LName <> ''
						AND @WL_FName <> ''
						THEN @WL_LName + ', ' + @WL_FName + ' ' + @WL_MName
					WHEN @WL_LName <> ''
						AND @WL_FName = ''
						THEN @WL_LName + ', ' + @WL_MName
					ELSE @WL_LName + ' ' + @WL_FName + ' ' + @WL_MName
					END
			SET @WL_FullName = ltrim(rtrim(@WL_FullName))

			SELECT @NameMatchCount = 0

			--Removing Spaces, Commas and Dots
			SELECT @WL_MName = LTRIM(RTRIM(@WL_MName))

			SELECT @WL_MName = REPLACE(@WL_MName, '.', '')

			SELECT @WL_MName = REPLACE(@WL_MName, ',', '')

			SELECT @WatchedPartyID = WatchedPartyID
			FROM KYP.MDM_Alert
			WHERE AlertID = @Cursor_AlertID

			SELECT @PDM_PartyFullName = ISNULL(NAME, '')
			FROM KYP.PDM_Party
			WHERE PartyID = @WatchedPartyID

			SELECT @Split1 = RTRIM(LTRIM(SUBSTRING(@PDM_PartyFullName, PATINDEX('%,%', @PDM_PartyFullName) + 1, LEN(@PDM_PartyFullName))))

			SELECT @Split2 = RTRIM(LTRIM(SUBSTRING(@PDM_PartyFullName, 0, PATINDEX('%,%', @PDM_PartyFullName))))

			SELECT @PDM_PartyLName = @Split2

			IF PATINDEX('% %', @Split1) = 0
			BEGIN
				SELECT @PDM_PartyFName = @Split1

				SELECT @PDM_PartyMName = ''
			END
			ELSE
			BEGIN
				SELECT @PDM_PartyFName = RTRIM(LTRIM(SUBSTRING(@Split1, 0, PATINDEX('% %', @Split1))))

				SELECT @PDM_PartyMName = RTRIM(LTRIM(SUBSTRING(@Split1, PATINDEX('% %', @Split1), LEN(@Split1))))
			END

			--Removing Spaces, Commas and Dots
			SELECT @PDM_PartyFName = REPLACE(@PDM_PartyFName, '.', '')

			SELECT @PDM_PartyFName = REPLACE(@PDM_PartyFName, ',', '')

			SELECT @PDM_PartyLName = REPLACE(@PDM_PartyLName, '.', '')

			SELECT @PDM_PartyLName = REPLACE(@PDM_PartyLName, ',', '')

			SELECT @PDM_PartyMName = REPLACE(@PDM_PartyMName, '.', '')

			SELECT @PDM_PartyMName = REPLACE(@PDM_PartyMName, ',', '')

			IF (
					@WL_MName = ''
					AND @PDM_PartyMName = ''
					)
			BEGIN
				IF (
						(@WL_FName = @PDM_PartyFName AND @WL_FName <> '')
						OR (@WL_LName = @PDM_PartyFName AND @WL_LName <> '')
						)
				BEGIN
					SELECT @NameMatchCount = @NameMatchCount + 1
				END

				IF (
						(@WL_FName = @PDM_PartyLName AND @WL_FName <> '')
						OR (@WL_LName = @PDM_PartyLName AND @WL_LName <> '')
						)
				BEGIN
					SELECT @NameMatchCount = @NameMatchCount + 1
				END

				IF @NameMatchCount = 0
				BEGIN
					SELECT @NameMatch = @MatchValNone

					SELECT @NameMatchColor = @MatchValNoneColor
				END
				ELSE IF @NameMatchCount = 1
				BEGIN
					SELECT @NameMatch = @MatchValPartial

					SELECT @NameMatchColor = @MatchValPartialColor
				END
				ELSE IF @NameMatchCount = 2
				BEGIN
					SELECT @NameMatch = @MatchValFull

					SELECT @NameMatchColor = @MatchValFullColor
				END
			END
			ELSE
			BEGIN
				IF (
						(
							(@WL_FName = @PDM_PartyFName)
							OR (@WL_FName = @PDM_PartyMName)
							OR (@WL_FName = @PDM_PartyLName)
							)
						AND (
							(@WL_MName = @PDM_PartyFName)
							OR (@WL_MName = @PDM_PartyMName)
							OR (@WL_MName = @PDM_PartyLName)
							)
						AND (
							(@WL_LName = @PDM_PartyFName)
							OR (@WL_LName = @PDM_PartyMName)
							OR (@WL_LName = @PDM_PartyLName)
							)
						)
				BEGIN
					SELECT @NameMatch = @MatchValFull

					SELECT @NameMatchColor = @MatchValFullColor
				END
				ELSE IF (
						(
							(@WL_FName <> @PDM_PartyFName)
							AND (@WL_FName <> @PDM_PartyMName)
							AND (@WL_FName <> @PDM_PartyLName)
							)
						AND (
							(@WL_MName <> @PDM_PartyFName)
							AND (@WL_MName <> @PDM_PartyMName)
							AND (@WL_MName <> @PDM_PartyLName)
							)
						AND (
							(@WL_LName <> @PDM_PartyFName)
							AND (@WL_LName <> @PDM_PartyMName)
							AND (@WL_LName <> @PDM_PartyLName)
							)
						)
				BEGIN
					SELECT @NameMatch = @MatchValNone

					SELECT @NameMatchColor = @MatchValNoneColor
				END
				ELSE
				BEGIN
					SELECT @NameMatch = @MatchValPartial

					SELECT @NameMatchColor = @MatchValPartialColor
				END
			END
					/************************** END:MATCHING NAME FOR INDIVIDUAL ******************************/
		END
		ELSE IF (
				@WatchedPartyType = 'Institutional'
				AND @isTwoWay IS NULL
				)
			OR (
				@WatchedPartyType = 'Individual'
				AND @isTwoWay = 1
				) --Hareesha Panoor: http://jira/browse/KYP-8044 
		BEGIN
			/************************** START:MATCHING NAME FOR ORGANIZATION ******************************/
			SELECT @WL_OrgName = ISNULL(OrganizationName, '')
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = @Cursor_AlertID

			SELECT @WL_FullName = ISNULL(@WL_OrgName, '')

			SELECT @WatchedPartyID = WatchedPartyID
			FROM KYP.MDM_Alert
			WHERE AlertID = @Cursor_AlertID

			SELECT @PDM_PartyFullName = ISNULL(NAME, '')
			FROM KYP.PDM_Party
			WHERE PartyID = @WatchedPartyID

			IF @WL_OrgName = @PDM_PartyFullName
			BEGIN
				SELECT @NameMatch = @MatchValFull

				SELECT @NameMatchColor = @MatchValFullColor
			END
			ELSE
			BEGIN
				SELECT @WL_OrgName = UPPER(@WL_OrgName)

				SELECT @WL_OrgName = REPLACE(@WL_OrgName, '.', '')

				SELECT @WL_OrgName = REPLACE(@WL_OrgName, ',', '')

				SELECT @PDM_PartyFullName = LTRIM(RTRIM(UPPER(@PDM_PartyFullName)))

				SELECT @found = 'false'

				DECLARE fnCursor CURSOR
				FOR
				SELECT item
				FROM dbo.fnSplitString(@WL_OrgName, ' ')

				OPEN fnCursor

				FETCH NEXT
				FROM fnCursor
				INTO @Cursor_forFunction

				WHILE @@FETCH_STATUS = 0
				BEGIN
					IF PATINDEX('%' + @Cursor_forFunction + '%', @PDM_PartyFullName) > 0
					BEGIN
						SELECT @found = 'true'

						BREAK;
					END

					FETCH NEXT
					FROM fnCursor
					INTO @Cursor_forFunction
				END

				CLOSE fnCursor

				DEALLOCATE fnCursor

				IF @found = 'true'
				BEGIN
					SELECT @NameMatch = @MatchValPartial

					SELECT @NameMatchColor = @MatchValPartialColor
				END
				ELSE
				BEGIN
					SELECT @NameMatch = @MatchValNone

					SELECT @NameMatchColor = @MatchValNoneColor
				END
			END
					/************************** END: MATCHING NAME FOR ORGANIZATION ******************************/
		END

		IF (
				@WatchedPartyType = 'Individual'
				AND @isTwoWay IS NULL
				)
			OR (
				@WatchedPartyType = 'Institutional'
				AND @isTwoWay = 1
				) --Hareesha Panoor: http://jira/browse/KYP-8044
		BEGIN
			/************************** START: MATCHING DOB FOR INDIVIDUAL ONLY (DOB N/A for Organization) ******************************/
			SELECT @WatchedPartyID = WatchedPartyID
			FROM KYP.MDM_Alert
			WHERE AlertID = @Cursor_AlertID

			SELECT @PDM_PartyDOB = DoB
			FROM KYP.PDM_Person
			WHERE PartyID = @WatchedPartyID

			SELECT @WL_DOB = DOB
				,@WL_DOD = DOD
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = @Cursor_AlertID

			IF @PDM_PartyDOB IS NOT NULL
			BEGIN
				SET @PDM_DOBNullCheck = ''
			END

			IF @WL_DOB IS NOT NULL
			BEGIN
				SET @WL_DOBNullCheck = ''
			END

			IF @PDM_PartyDOB IS NOT NULL
				AND @WL_DOB IS NOT NULL
			BEGIN
				IF @PDM_PartyDOB = @WL_DOB
				BEGIN
					SELECT @DOBMatch = @MatchValFull

					SELECT @DOBMatchColor = @MatchValFullColor
				END
				ELSE
				BEGIN
					SELECT @DOBMatch = @MatchValNone

					SELECT @DOBMatchColor = @MatchValNoneColor
				END
			END
			ELSE
			BEGIN
				SELECT @DOBMatch = @MatchValNone

				SELECT @DOBMatchColor = @MatchValNoneColor
			END
		END

		/************************** END: MATCHING DOB FOR INDIVIDUAL ONLY (DOB N/A for Organization) ******************************/
		/************************** START: SSN MATCH ******************************/
		SELECT @WatchedPartyID = WatchedPartyID
		FROM KYP.MDM_Alert
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_SSN = ISNULL(SSN, '')
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_PartySSN = ISNULL(SSN, '')
		FROM KYP.PDM_Person
		WHERE PartyID = @WatchedPartyID

		SELECT @PDM_PartySSNSource = ''

		/*CHECK FOR SSN VALUE IN HMS IF NOT AVAILABLE IN OMS DB*/
		/*IF @PDM_PartySSN = ''
		BEGIN
			SELECT TOP 1 @PDM_PartySSN = SSN
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND db_Flag = 'HMS'
			ORDER BY SSN DESC

			IF @PDM_PartySSN <> ''
			BEGIN
				SET @PDM_PartySSNSource = 'HMS'
			END
			ELSE
			BEGIN
				SET @PDM_PartySSNSource = ''
			END
		END */

		IF @PDM_PartySSN <> ''
			AND @WL_SSN <> ''
		BEGIN
			IF @PDM_PartySSN = @WL_SSN
			BEGIN
				SELECT @SSNMatch = @MatchValFull

				SELECT @SSNMatchColor = @MatchValFullColor
			END
			ELSE
			BEGIN
				SELECT @SSNMatch = @MatchValNone

				SELECT @SSNMatchColor = @MatchValNoneColor
			END
		END
		ELSE
		BEGIN
			SELECT @SSNMatch = @MatchValNone

			SELECT @SSNMatchColor = @MatchValNoneColor
		END

		SELECT @WL_TaxID = ISNULL(TAXID, '')
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_PartyTaxID = ISNULL(TaxId, '')
		FROM KYP.PDM_Person
		WHERE PartyID = @WatchedPartyID

		SELECT @PDM_PartyTaxIDSource = ''

		/*IF @PDM_PartyTaxID = ''
		BEGIN
			SELECT TOP 1 @PDM_PartyTaxID = TaxID
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND db_Flag = 'HMS'
			ORDER BY TaxID DESC

			IF @PDM_PartyTaxID <> ''
			BEGIN
				SET @PDM_PartyTaxIDSource = 'HMS'
			END
			ELSE
			BEGIN
				SET @PDM_PartyTaxIDSource = ''
			END
		END */

		IF @PDM_PartyTaxID <> ''
			AND @WL_TaxID <> ''
		BEGIN
			IF @PDM_PartyTaxID = @WL_TaxID
			BEGIN
				SET @TaxIDMatch = @MatchValFull
				SET @TaxIDMatchColor = @MatchValFullColor
			END
			ELSE
			BEGIN
				SET @TaxIDMatch = @MatchValNone
				SET @TaxIDMatchColor = @MatchValNoneColor
			END
		END

		/************************** END: SSN MATCH ******************************/
		/************************** START: UPIN MATCH ******************************/
		SELECT @WatchedPartyID = WatchedPartyID
		FROM KYP.MDM_Alert
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_UPIN = ISNULL(UPIN, '')
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_PartyUPIN = ISNULL(UPIN, '')
		FROM KYP.PDM_Provider
		WHERE PartyID = @WatchedPartyID

		IF @PDM_PartyUPIN <> ''
			AND @WL_UPIN <> ''
		BEGIN
			IF @PDM_PartyUPIN = @WL_UPIN
			BEGIN
				SELECT @UPINMatch = @MatchValFull

				SELECT @UPINMatchColor = @MatchValFullColor
			END
			ELSE
			BEGIN
				SELECT @UPINMatch = @MatchValNone

				SELECT @UPINMatchColor = @MatchValNoneColor
			END
		END
		ELSE
		BEGIN
			SELECT @UPINMatch = @MatchValNone

			SELECT @UPINMatchColor = @MatchValNoneColor
		END

		/************************** END: UPIN MATCH ******************************/
		/************************** START: ALIAS MATCH ******************************/
		SELECT @WL_Alias = ISNULL(AliasName, '')
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		IF @WatchedPartyType = 'Individual'
		BEGIN
			SELECT @PDM_PartyAlias = Alias1
			FROM KYP.PDM_Person
			WHERE PartyID = @WatchedPartyID
		END
		ELSE
		BEGIN
			SELECT @PDM_PartyAlias = DBAName1
			FROM KYP.PDM_Organization
			WHERE PartyID = @WatchedPartyID
		END

		/* NO Color Matching Done alias since it's not found in application also
		 * Alias values mostly does not come in WL data i.e. MDM_AlertDetail
		 */
		/************************** END: ALIAS MATCH ******************************/
		/************************** START: OIG LEIE DATA ******************************/
		SELECT @LEIE_EXCLType = LEIE_EXCLType
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @LEIE_EXCLDate = CASE 
				WHEN LEIE_EXCLDate IS NOT NULL
					THEN CONVERT(VARCHAR(25), CONVERT(DATETIME, LEIE_EXCLDate), 101)
				WHEN LEIE_EXCLDate IS NULL
					THEN NULL
				END
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @LEIE_REINDATE = CASE 
				WHEN LEIE_REINDATE IN ('00000000')
					OR LEIE_REINDATE IN ('0')
					THEN NULL
				WHEN LEIE_REINDATE IS NOT NULL
					THEN CONVERT(VARCHAR(25), CONVERT(DATETIME, LEIE_REINDATE), 101)
				WHEN LEIE_REINDATE IS NULL
					THEN NULL
				END
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		/************************** END: OIG LEIE DATA ******************************/
		/************************** START: SAM DATA ******************************/
		SELECT @SAM_ActionDate = CASE 
				WHEN EPLS_ActionDate IN (
						'PERM.'
						,'INDEF.'
						,'INDEFINITE'
						)
					THEN 'INDEFINITE'
				WHEN (EPLS_ActionDate IS NULL)
					OR (LTRIM(RTRIM(EPLS_ActionDate)) = '')
					THEN NULL
				WHEN EPLS_ActionDate IS NOT NULL
					THEN CONVERT(VARCHAR(25), CONVERT(DATETIME, EPLS_ActionDate), 101)
				END
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @SAM_Agency = EPLS_Agency
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @SAM_TermDate = CASE 
				WHEN EPLS_TermDate IN (
						'PERM.'
						,'INDEF.'
						,'INDEFINITE'
						)
					THEN 'INDEFINITE'
				WHEN EPLS_TermDate IS NULL
					THEN NULL
				WHEN EPLS_TermDate IS NOT NULL
					THEN CONVERT(VARCHAR(25), CONVERT(DATETIME, EPLS_TermDate), 101)
				END
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		/************************** END: SAM DATA ******************************/
		/************************** START: SANCTIONS DATA ******************************/
		SELECT @SanctionAction = Action_Description
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @SanctionBoard = Board_Description
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @SanctionOffense = Offense_Description
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @SanctionDate = CASE 
				WHEN Action_Date IS NOT NULL
					THEN CONVERT(DATETIME, Action_Date, 120)
				WHEN Action_Date IS NULL
					THEN NULL
				END
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		/************************** END: SANCTIONS DATA ******************************/
		/* WL Single Items */
		SELECT @WL_TaxID = LTRIM(RTRIM(TAXID))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_NPI = NPI
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_License = LTRIM(RTRIM(LicenseNo))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_LicenseState = LTRIM(RTRIM(License_State))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_Specialty = LTRIM(RTRIM(Speciality))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @WL_Address = LTRIM(RTRIM(ISNULL(AddressLine1, '') + ' ' + ISNULL(City, '') + ' ' + ISNULL(STATE, '') + ' ' + ISNULL(Zip, '')))
			,@WL_AddressLine1 = AddressLine1
			,@WL_City = City
			,@WL_State = STATE
			,@WL_Zip = Zip
		FROM KYP.MDM_AlertExtnAddress A
		INNER JOIN KYP.MDM_AlertExtnLocation B ON A.AddressID = B.AddressID
		WHERE B.AlertID = @Cursor_AlertID

		----------------------------------------------------------
		/*INSERT FOR SINGLE VALUED MATCHES*/
		EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
			,@InsWL_FullName = @WL_FullName
			,@InsWL_FName = @WL_FName
			,@InsWL_MName = @WL_MName
			,@InsWL_LName = @WL_LName
			,@InsPDM_PartyFullName = @PDM_PartyFullName
			,@InsPDM_PartyFName = @PDM_PartyFName
			,@InsPDM_PartyMName = @PDM_PartyMName
			,@InsPDM_PartyLName = @PDM_PartyLName
			,@InsNameMatch = @NameMatch
			,@InsNameMatchColor = @NameMatchColor
			,@InsWL_DOB = @WL_DOB
			,@InsPDM_PartyDOB = @PDM_PartyDOB
			,@InsDOBMatch = @DOBMatch
			,@InsDOBMatchColor = @DOBMatchColor
			,@InsWL_SSN = @WL_SSN
			,@InsPDM_PartySSN = @PDM_PartySSN
			,@InsPDM_PartySSNSource = @PDM_PartySSNSource
			,@InsSSNMatch = @SSNMatch
			,@InsSSNMatchColor = @SSNMatchColor
			,@InsWL_UPIN = @WL_UPIN
			,@InsPDM_PartyUPIN = @PDM_PartyUPIN
			,@InsUPINMatch = @UPINMatch
			,@InsUPINMatchColor = @UPINMatchColor
			,@InsWL_Alias = @WL_Alias
			,@InsPDM_PartyAlias = @PDM_PartyAlias
			,@InsAliasMatch = @AliasMatch
			,@InsAliasMatchColor = @AliasMatchColor
			---------------------------------------------------------
			,@InsWL_TaxID = @WL_TaxID
			,@InsWL_NPI = @WL_NPI
			,@InsWL_License = @WL_License
			,@InsWL_LicenseState = @WL_LicenseState
			,@InsWL_Speciality = @WL_Specialty
			,@InsWL_Address = @WL_Address
			,@InsWL_DOD = @WL_DOD
			,@InsSAM_ActionDate = @SAM_ActionDate
			,@InsSAM_TermDate = @SAM_TermDate
			,@InsSAM_Agency = @SAM_Agency
			,@InsLEIE_ExclusionType = @LEIE_EXCLType
			,@InsLEIE_ExclusionDate = @LEIE_EXCLDate
			,@InsLEIE_ReinstatedDate = @LEIE_REINDATE
			,@InsSanctionOffense = @SanctionOffense
			,@InsSanctionBoard = @SanctionBoard
			,@InsSanctionAction = @SanctionAction
			,@InsSanctionDate = @SanctionDate

		SELECT @IdentCurrent = IDENT_CURRENT('[KYP].[MDM_AlertDetailPartyMatch]')

		/*#############################################################################################*/
		/************************** START: TAXID MATCH ******************************/
		SELECT @WL_SSN = ISNULL(SSN, '')
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_PartySSN = ISNULL(SSN, '')
		FROM KYP.PDM_Organization
		WHERE PartyID = @WatchedPartyID

		SELECT @PDM_PartySSNSource = ''

		/*IF @PDM_PartySSN = ''
		BEGIN
			SELECT TOP 1 @PDM_PartySSN = SSN
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND db_Flag = 'HMS'
			ORDER BY SSN DESC

			IF @PDM_PartySSN <> ''
			BEGIN
				SET @PDM_PartySSNSource = 'HMS'
			END
			ELSE
			BEGIN
				SET @PDM_PartySSNSource = ''
			END
		END */

		IF @PDM_PartySSN <> ''
			AND @WL_SSN <> ''
		BEGIN
			IF @PDM_PartySSN = @WL_SSN
			BEGIN
				SELECT @SSNMatch = @MatchValFull

				SELECT @SSNMatchColor = @MatchValFullColor
			END
			ELSE
			BEGIN
				SELECT @SSNMatch = @MatchValNone

				SELECT @SSNMatchColor = @MatchValNoneColor
			END
		END

		SELECT @WL_TaxID = LTRIM(RTRIM(TAXID))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT TOP 1 @PDM_PartyTaxIDSource = db_Flag
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID /*and db_Flag = 'HMS'*/
		ORDER BY db_Flag DESC

		SELECT TOP 1 @PDM_PartyTaxIDOMSSource = db_Flag
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND db_Flag = 'OMS'

		SELECT @PDM_TaxIDCount = COUNT(DISTINCT (TaxID))
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND TaxID IS NOT NULL
			AND db_Flag = 'OMS'

		SELECT @PDM_TaxIDOMSCount = COUNT(DISTINCT (TaxID))
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND TaxID IS NOT NULL
			AND db_Flag = 'OMS'

		IF @PDM_TaxIDOMSCount > 1
		BEGIN
			DECLARE tinCursor CURSOR
			FOR
			SELECT DISTINCT (TaxID)
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND TaxID IS NOT NULL
				AND db_Flag = 'OMS'

			OPEN tinCursor

			FETCH NEXT
			FROM tinCursor
			INTO @Cursor_TaxID

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartyTaxID = @Cursor_TaxID

				IF @Cursor_TaxID = @WL_TaxID
				BEGIN
					SET @TaxIDMatch = @MatchValFull
					SET @TaxIDMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET TaxIDMatch = @MatchValFull
						,TaxIDMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @TaxIDPriority = 1
				END
				ELSE
				BEGIN
					SET @TaxIDMatch = @MatchValNone
					SET @TaxIDMatchColor = @MatchValNoneColor

					IF @TaxIDPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET TaxIDMatch = @MatchValNone
							,TaxIDMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_TaxID = @WL_TaxID
					,@InsPDM_PartyTaxID = @PDM_PartyTaxID
					,@InsPDM_PartyTaxIDSource = @PDM_PartyTaxIDOMSSource
					,@InsTaxIDMatch = @TaxIDMatch
					,@InsTaxIDMatchColor = @TaxIDMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_TaxID = NULL// Commented to make watch list taxID value available to all iterations 
				SET @PDM_PartyTaxID = NULL
				SET @PDM_PartyTaxIDSource = NULL
				SET @TaxIDMatch = NULL
				SET @TaxIDMatchColor = NULL

				FETCH NEXT
				FROM tinCursor
				INTO @Cursor_TaxID
			END

			CLOSE tinCursor

			DEALLOCATE tinCursor
		END
		ELSE IF @PDM_TaxIDCount > 1
		BEGIN
			DECLARE tinCursor CURSOR
			FOR
			SELECT DISTINCT (TaxID)
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND TaxID IS NOT NULL
				AND db_Flag = 'OMS'

			OPEN tinCursor

			FETCH NEXT
			FROM tinCursor
			INTO @Cursor_TaxID

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartyTaxID = @Cursor_TaxID

				IF @Cursor_TaxID = @WL_TaxID
				BEGIN
					SET @TaxIDMatch = @MatchValFull
					SET @TaxIDMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET TaxIDMatch = @MatchValFull
						,TaxIDMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @TaxIDPriority = 1
				END
				ELSE
				BEGIN
					SET @TaxIDMatch = @MatchValNone
					SET @TaxIDMatchColor = @MatchValNoneColor

					IF @TaxIDPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET TaxIDMatch = @MatchValNone
							,TaxIDMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_TaxID = @WL_TaxID
					,@InsPDM_PartyTaxID = @PDM_PartyTaxID
					,@InsPDM_PartyTaxIDSource = @PDM_PartyTaxIDSource
					,@InsTaxIDMatch = @TaxIDMatch
					,@InsTaxIDMatchColor = @TaxIDMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_TaxID = NULL// Commented to make watch list taxID value available to all iterations 
				SET @PDM_PartyTaxID = NULL
				SET @PDM_PartyTaxIDSource = NULL
				SET @TaxIDMatch = NULL
				SET @TaxIDMatchColor = NULL

				FETCH NEXT
				FROM tinCursor
				INTO @Cursor_TaxID
			END

			CLOSE tinCursor

			DEALLOCATE tinCursor
		END
		ELSE
		BEGIN
			SELECT TOP 1 @PDM_PartyTaxID = LTRIM(RTRIM(TIN))
			FROM KYP.PDM_Organization
			WHERE PartyID = @WatchedPartyID

			IF @PDM_PartyTaxID = @WL_TaxID
			BEGIN
				SET @TaxIDMatch = @MatchValFull
				SET @TaxIDMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET TaxIDMatch = @MatchValFull
					,TaxIDMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END
			ELSE
			BEGIN
				SET @TaxIDMatch = @MatchValNone
				SET @TaxIDMatchColor = @MatchValNoneColor

				UPDATE MDM_AlertDetailPartyMatch
				SET TaxIDMatch = @MatchValNone
					,TaxIDMatchColor = @MatchValNoneColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END

			EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
				,@InsWL_FullName = @WL_FullName
				,@InsWL_FName = @WL_FName
				,@InsWL_MName = @WL_MName
				,@InsWL_LName = @WL_LName
				,@InsPDM_PartyFullName = @PDM_PartyFullName
				,@InsPDM_PartyFName = @PDM_PartyFName
				,@InsPDM_PartyMName = @PDM_PartyMName
				,@InsPDM_PartyLName = @PDM_PartyLName
				,@InsNameMatch = @NameMatch
				,@InsNameMatchColor = @NameMatchColor
				,@InsWL_DOB = @WL_DOB
				,@InsPDM_PartyDOB = @PDM_PartyDOB
				,@InsDOBMatch = @DOBMatch
				,@InsDOBMatchColor = @DOBMatchColor
				,@InsWL_SSN = @WL_SSN
				,@InsPDM_PartySSN = @PDM_PartySSN
				,@InsPDM_PartySSNSource = @PDM_PartySSNSource
				,@InsSSNMatch = @SSNMatch
				,@InsSSNMatchColor = @SSNMatchColor
				,@InsWL_UPIN = @WL_UPIN
				,@InsPDM_PartyUPIN = @PDM_PartyUPIN
				,@InsUPINMatch = @UPINMatch
				,@InsUPINMatchColor = @UPINMatchColor
				,@InsWL_Alias = @WL_Alias
				,@InsPDM_PartyAlias = @PDM_PartyAlias
				,@InsAliasMatch = @AliasMatch
				,@InsAliasMatchColor = @AliasMatchColor
				,
				----------------------------------------------------------
				@InsWL_TaxID = @WL_TaxID
				,@InsPDM_PartyTaxID = @PDM_PartyTaxID
				,@InsPDM_PartyTaxIDSource = @PDM_PartyTaxIDSource
				,@InsTaxIDMatch = @TaxIDMatch
				,@InsTaxIDMatchColor = @TaxIDMatchColor
				,@InsWL_DOD = @WL_DOD
		END

		/************************** END: TAXID MATCH ******************************/
		/************************** START: NPI MATCH ******************************/
		SELECT @WL_NPI = NPI
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_NPICount = COUNT(DISTINCT (NPI))
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND NPI IS NOT NULL
			AND db_Flag = 'OMS'

		IF @PDM_NPICount > 1
		BEGIN
			DECLARE npiCursor CURSOR
			FOR
			SELECT DISTINCT (NPI)
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND NPI IS NOT NULL
				AND db_Flag = 'OMS'


			OPEN npiCursor

			FETCH NEXT
			FROM npiCursor
			INTO @Cursor_NPI

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartyNPI = @Cursor_NPI

				IF @Cursor_NPI = @WL_NPI
				BEGIN
					SET @NPIMatch = @MatchValFull
					SET @NPIMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET NPIMatch = @MatchValFull
						,NPIMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @NPIPriority = 1
				END
				ELSE
				BEGIN
					SET @NPIMatch = @MatchValNone
					SET @NPIMatchColor = @MatchValNoneColor

					IF @NPIPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET NPIMatch = @MatchValNone
							,NPIMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_NPI = @WL_NPI
					,@InsPDM_PartyNPI = @PDM_PartyNPI
					,@InsNPIMatch = @NPIMatch
					,@InsNPIMatchColor = @NPIMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_NPI = NULL // Commented to make watch list NPI value available to all iterations
				SET @PDM_PartyNPI = NULL
				SET @NPIMatch = NULL
				SET @NPIMatchColor = NULL

				FETCH NEXT
				FROM npiCursor
				INTO @Cursor_NPI
			END

			CLOSE npiCursor

			DEALLOCATE npiCursor
		END
		ELSE
		BEGIN
			SELECT TOP 1 @PDM_PartyNPI = NPI
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND NPI IS NOT NULL
                AND db_Flag = 'OMS'
                
			IF @WL_NPI = @PDM_PartyNPI
			BEGIN
				SET @NPIMatch = @MatchValFull
				SET @NPIMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET NPIMatch = @MatchValFull
					,NPIMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END
			ELSE
			BEGIN
				SET @NPIMatch = @MatchValNone
				SET @NPIMatchColor = @MatchValNoneColor

				UPDATE MDM_AlertDetailPartyMatch
				SET NPIMatch = @MatchValNone
					,NPIMatchColor = @MatchValNoneColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END

			EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
				,@InsWL_FullName = @WL_FullName
				,@InsWL_FName = @WL_FName
				,@InsWL_MName = @WL_MName
				,@InsWL_LName = @WL_LName
				,@InsPDM_PartyFullName = @PDM_PartyFullName
				,@InsPDM_PartyFName = @PDM_PartyFName
				,@InsPDM_PartyMName = @PDM_PartyMName
				,@InsPDM_PartyLName = @PDM_PartyLName
				,@InsNameMatch = @NameMatch
				,@InsNameMatchColor = @NameMatchColor
				,@InsWL_DOB = @WL_DOB
				,@InsPDM_PartyDOB = @PDM_PartyDOB
				,@InsDOBMatch = @DOBMatch
				,@InsDOBMatchColor = @DOBMatchColor
				,@InsWL_SSN = @WL_SSN
				,@InsPDM_PartySSN = @PDM_PartySSN
				,@InsPDM_PartySSNSource = @PDM_PartySSNSource
				,@InsSSNMatch = @SSNMatch
				,@InsSSNMatchColor = @SSNMatchColor
				,@InsWL_UPIN = @WL_UPIN
				,@InsPDM_PartyUPIN = @PDM_PartyUPIN
				,@InsUPINMatch = @UPINMatch
				,@InsUPINMatchColor = @UPINMatchColor
				,@InsWL_Alias = @WL_Alias
				,@InsPDM_PartyAlias = @PDM_PartyAlias
				,@InsAliasMatch = @AliasMatch
				,@InsAliasMatchColor = @AliasMatchColor
				,
				----------------------------------------------------------
				@InsWL_NPI = @WL_NPI
				,@InsPDM_PartyNPI = @PDM_PartyNPI
				,@InsNPIMatch = @NPIMatch
				,@InsNPIMatchColor = @NPIMatchColor
				,@InsWL_DOD = @WL_DOD
		END

		/************************** END: NPI MATCH ******************************/
		/************************** START: LICENSE MATCH ******************************/
		SELECT @WL_License = LTRIM(RTRIM(LicenseNo))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID
	

		SELECT @WL_LicenseState = LTRIM(RTRIM(License_State))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID

		SELECT @PDM_LicenseCount = COUNT(DISTINCT (License))
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND License IS NOT NULL
			AND db_Flag = 'OMS'

		IF @PDM_LicenseCount > 1
		BEGIN
			DECLARE licenseCursor CURSOR
			FOR
			SELECT DISTINCT (License)
				,db_Flag
				,LicenseState
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND License IS NOT NULL
				AND db_Flag = 'OMS'

			OPEN licenseCursor

			FETCH NEXT
			FROM licenseCursor
			INTO @Cursor_License
				,@Cursor_dbFlag
				,@Cursor_LicenseState

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartyLicense = @Cursor_License
				SET @PDM_PartyLicenseSource = @Cursor_dbFlag
				SET @PDM_PartyLicenseState = @Cursor_LicenseState

				IF @Cursor_License = @WL_License
				BEGIN
					SET @LicenseMatch = @MatchValFull
					SET @LicenseMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET LicenseMatch = @MatchValFull
						,LicenseMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @LicensePriority = 1
				END
				ELSE
				BEGIN
					SET @LicenseMatch = @MatchValNone
					SET @LicenseMatchColor = @MatchValNoneColor

					IF @LicensePriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET LicenseMatch = @MatchValNone
							,LicenseMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_License = @WL_License
					,@InsWL_LicenseState = @WL_LicenseState
					,@InsPDM_PartyLicense = @PDM_PartyLicense
					,@InsPDM_PartyLicenseSource = @PDM_PartyLicenseSource
					,@InsPDM_PartyLicenseState = @PDM_PartyLicenseState
					,@InsLicenseMatch = @LicenseMatch
					,@InsLicenseMatchColor = @LicenseMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_License = NULL// Commented to make watch list License ID value available to all iterations
				SET @PDM_PartyLicense = NULL
				SET @PDM_PartyLicenseSource = NULL
				SET @LicenseMatch = NULL
				SET @LicenseMatchColor = NULL

				FETCH NEXT
				FROM licenseCursor
				INTO @Cursor_License
					,@Cursor_dbFlag
					,@Cursor_LicenseState
			END

			CLOSE licenseCursor

			DEALLOCATE licenseCursor
		END
		ELSE
		BEGIN
			--added @PDM_PartyLicenseSource= db_Flag KYP-12736  
			SELECT TOP 1 @PDM_PartyLicense = License
				,@PDM_PartyLicenseState = LicenseState
				,@PDM_PartyLicenseSource = db_Flag
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND License IS NOT NULL
				AND db_Flag = 'OMS'

			IF @WL_License = @PDM_PartyLicense
			BEGIN
				SET @LicenseMatch = @MatchValFull
				SET @LicenseMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET LicenseMatch = @MatchValFull
					,LicenseMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END
			ELSE
			BEGIN
				SET @LicenseMatch = @MatchValNone
				SET @LicenseMatchColor = @MatchValNoneColor

				UPDATE MDM_AlertDetailPartyMatch
				SET LicenseMatch = @MatchValNone
					,LicenseMatchColor = @MatchValNoneColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END

			EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
				,@InsWL_FullName = @WL_FullName
				,@InsWL_FName = @WL_FName
				,@InsWL_MName = @WL_MName
				,@InsWL_LName = @WL_LName
				,@InsPDM_PartyFullName = @PDM_PartyFullName
				,@InsPDM_PartyFName = @PDM_PartyFName
				,@InsPDM_PartyMName = @PDM_PartyMName
				,@InsPDM_PartyLName = @PDM_PartyLName
				,@InsNameMatch = @NameMatch
				,@InsNameMatchColor = @NameMatchColor
				,@InsWL_DOB = @WL_DOB
				,@InsPDM_PartyDOB = @PDM_PartyDOB
				,@InsDOBMatch = @DOBMatch
				,@InsDOBMatchColor = @DOBMatchColor
				,@InsWL_SSN = @WL_SSN
				,@InsPDM_PartySSN = @PDM_PartySSN
				,@InsPDM_PartySSNSource = @PDM_PartySSNSource
				,@InsSSNMatch = @SSNMatch
				,@InsSSNMatchColor = @SSNMatchColor
				,@InsWL_UPIN = @WL_UPIN
				,@InsPDM_PartyUPIN = @PDM_PartyUPIN
				,@InsUPINMatch = @UPINMatch
				,@InsUPINMatchColor = @UPINMatchColor
				,@InsWL_Alias = @WL_Alias
				,@InsPDM_PartyAlias = @PDM_PartyAlias
				,@InsAliasMatch = @AliasMatch
				,@InsAliasMatchColor = @AliasMatchColor
				,
				----------------------------------------------------------
				@InsWL_License = @WL_License
				,@InsWL_LicenseState = @WL_LicenseState
				,@InsPDM_PartyLicense = @PDM_PartyLicense
				,@InsPDM_PartyLicenseSource = @PDM_PartyLicenseSource
				,@InsPDM_PartyLicenseState = @PDM_PartyLicenseState
				,@InsLicenseMatch = @LicenseMatch
				,@InsLicenseMatchColor = @LicenseMatchColor
				,@InsWL_DOD = @WL_DOD
		END

		/************************** END: LICENSE MATCH ******************************/
		/************************** START: SPECIALTY MATCH ******************************/
		SELECT @WL_Specialty = LTRIM(RTRIM(Speciality))
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @Cursor_AlertID
		

		SELECT @PDM_SpecialtyCount = COUNT(DISTINCT (Speciality))
		FROM KYP.MDM_PartyDetail
		WHERE PartyID = @WatchedPartyID
			AND Speciality IS NOT NULL
			AND db_Flag = 'OMS'

		IF @PDM_SpecialtyCount > 1
		BEGIN
			DECLARE specialtyCursor CURSOR
			FOR
			SELECT DISTINCT (Speciality)
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND Speciality IS NOT NULL
				AND db_Flag = 'OMS'

			OPEN specialtyCursor

			FETCH NEXT
			FROM specialtyCursor
			INTO @Cursor_Specialty

			/**SPECIALITY CURSOR START**/
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartySpecialty = @Cursor_Specialty

				IF @Cursor_Specialty = @WL_Specialty
				BEGIN
					SET @SpecialtyMatch = @MatchValFull
					SET @SpecialtyMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET SpecialityMatch = @MatchValFull
						,SpecialityMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @SpecialtyPriority = 1
				END
				ELSE
				BEGIN
					SET @SpecialtyMatch = @MatchValNone
					SET @SpecialtyMatchColor = @MatchValNoneColor

					IF @SpecialtyPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET SpecialityMatch = @MatchValNone
							,SpecialityMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_Speciality = @WL_Specialty
					,@InsPDM_PartySpeciality = @PDM_PartySpecialty
					,@InsSpecialityMatch = @SpecialtyMatch
					,@InsSpecialityMatchColor = @SpecialtyMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_Specialty = NULL //// Commented to make watch list Speciality value available to all iterations
				SET @PDM_PartySpecialty = NULL
				SET @SpecialtyMatch = NULL
				SET @SpecialtyMatchColor = NULL

				FETCH NEXT
				FROM specialtyCursor
				INTO @Cursor_Specialty
					/**SPECIALITY CURSOR END**/
			END

			CLOSE specialtyCursor

			DEALLOCATE specialtyCursor
				/************************** END: SPECIALTY MATCH ******************************/
		END /*END OF Check @PDM_SpecialtyCount > 1*/
		ELSE /*If speciality is only one*/
		BEGIN
			SELECT @PDM_PartySpecialty = Speciality
			FROM KYP.MDM_PartyDetail
			WHERE PartyID = @WatchedPartyID
				AND Speciality IS NOT NULL
				AND db_Flag = 'OMS'

			IF @WL_Specialty = @PDM_PartySpecialty
			BEGIN
				SET @SpecialtyMatch = @MatchValFull
				SET @SpecialtyMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET SpecialityMatch = @MatchValFull
					,SpecialityMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END
			ELSE
			BEGIN
				SET @SpecialtyMatch = @MatchValNone
				SET @SpecialtyMatchColor = @MatchValNoneColor

				UPDATE MDM_AlertDetailPartyMatch
				SET SpecialityMatch = @MatchValNone
					,SpecialityMatchColor = @MatchValNoneColor
				WHERE AlrtDetMatchID = @IdentCurrent
			END

			EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
				,@InsWL_FullName = @WL_FullName
				,@InsWL_FName = @WL_FName
				,@InsWL_MName = @WL_MName
				,@InsWL_LName = @WL_LName
				,@InsPDM_PartyFullName = @PDM_PartyFullName
				,@InsPDM_PartyFName = @PDM_PartyFName
				,@InsPDM_PartyMName = @PDM_PartyMName
				,@InsPDM_PartyLName = @PDM_PartyLName
				,@InsNameMatch = @NameMatch
				,@InsNameMatchColor = @NameMatchColor
				,@InsWL_DOB = @WL_DOB
				,@InsPDM_PartyDOB = @PDM_PartyDOB
				,@InsDOBMatch = @DOBMatch
				,@InsDOBMatchColor = @DOBMatchColor
				,@InsWL_SSN = @WL_SSN
				,@InsPDM_PartySSN = @PDM_PartySSN
				,@InsPDM_PartySSNSource = @PDM_PartySSNSource
				,@InsSSNMatch = @SSNMatch
				,@InsSSNMatchColor = @SSNMatchColor
				,@InsWL_UPIN = @WL_UPIN
				,@InsPDM_PartyUPIN = @PDM_PartyUPIN
				,@InsUPINMatch = @UPINMatch
				,@InsUPINMatchColor = @UPINMatchColor
				,@InsWL_Alias = @WL_Alias
				,@InsPDM_PartyAlias = @PDM_PartyAlias
				,@InsAliasMatch = @AliasMatch
				,@InsAliasMatchColor = @AliasMatchColor
				,
				----------------------------------------------------------
				@InsWL_Speciality = @WL_Specialty
				,@InsPDM_PartySpeciality = @PDM_PartySpecialty
				,@InsSpecialityMatch = @SpecialtyMatch
				,@InsSpecialityMatchColor = @SpecialtyMatchColor
				,@InsWL_DOD = @WL_DOD
		END

		/************************** END: SPECIALTY MATCH ******************************/
		--replace to address1 and city added by Hareesha Panoor to fix, http://jira/browse/KYP-7831
		/************************** START: ADDRESS MATCH ******************************/
		SELECT @WL_Address = LTRIM(RTRIM(ISNULL(AddressLine1, '') + ' ' + ISNULL(City, '') + ' ' + ISNULL(STATE, '') + ' ' + ISNULL(Zip, '')))
			,@WL_AddressLine1 = replace(replace(AddressLine1, '.', ''), ',', '')
			,@WL_City = replace(replace(City, '.', ''), ',', '')
			,@WL_State = STATE
			,@WL_Zip = Zip
		FROM KYP.MDM_AlertExtnAddress A
		INNER JOIN KYP.MDM_AlertExtnLocation B ON A.AddressID = B.AddressID
		WHERE B.AlertID = @Cursor_AlertID

		SELECT @PDM_AddressCount = COUNT(DISTINCT (Address))
		FROM KYP.MDM_PartyAddress
		WHERE PartyID = @WatchedPartyID

		IF @PDM_AddressCount > 1
		BEGIN
			DECLARE addressCursor CURSOR
			FOR
			SELECT DISTINCT (Address)
				,replace(replace(Address1, '.', ''), ',', '')
				,replace(replace(City, '.', ''), ',', '')
				,STATE
				,Zip
			FROM KYP.MDM_PartyAddress
			WHERE PartyID = @WatchedPartyID

			OPEN addressCursor

			FETCH NEXT
			FROM addressCursor
			INTO @Cursor_Address
				,@Cursor_AddressLine1
				,@Cursor_City
				,@Cursor_State
				,@Cursor_Zip

			/**Address CURSOR START**/
			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @PDM_PartyAddress = @Cursor_Address
				SET @PDM_PartyAddressLine1 = @Cursor_AddressLine1
				SET @PDM_PartyCity = @Cursor_City
				SET @PDM_PartyState = @Cursor_State
				SET @PDM_PartyZip = @Cursor_Zip

				/*Address Full Matches*/
				IF @WL_AddressLine1 = @Cursor_AddressLine1
					AND @WL_City = @Cursor_City
					AND @WL_State = @Cursor_State
				BEGIN
					SET @AddressMatch = @MatchValFull
					SET @AddressMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValFull
						,AddressMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 1
				END
				ELSE IF @WL_AddressLine1 = @Cursor_AddressLine1
					AND @WL_Zip = @Cursor_Zip
				BEGIN
					SET @AddressMatch = @MatchValFull
					SET @AddressMatchColor = @MatchValFullColor

					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValFull
						,AddressMatchColor = @MatchValFullColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 1
				END
						/*Address Partial Matches*/
				ELSE IF @WL_City = @Cursor_City
					AND @WL_State = @Cursor_State
				BEGIN
					SET @AddressMatch = @MatchValPartial
					SET @AddressMatchColor = @MatchValPartialColor

					IF @AddressPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET AddressMatch = @MatchValPartial
							,AddressMatchColor = @MatchValPartialColor
						WHERE AlrtDetMatchID = @IdentCurrent

						SET @AddressPriority = 2
					END
				END
				ELSE IF @WL_AddressLine1 = @Cursor_AddressLine1
				BEGIN
					SET @AddressMatch = @MatchValPartial
					SET @AddressMatchColor = @MatchValPartialColor

					IF @AddressPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET AddressMatch = @MatchValPartial
							,AddressMatchColor = @MatchValPartialColor
						WHERE AlrtDetMatchID = @IdentCurrent

						SET @AddressPriority = 2
					END
				END
				ELSE IF @WL_Zip = @Cursor_Zip
				BEGIN
					SET @AddressMatch = @MatchValPartial
					SET @AddressMatchColor = @MatchValPartialColor

					IF @AddressPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET AddressMatch = @MatchValPartial
							,AddressMatchColor = @MatchValPartialColor
						WHERE AlrtDetMatchID = @IdentCurrent

						SET @AddressPriority = 2
					END
				END
				ELSE IF @WL_City = @Cursor_City
				BEGIN
					SET @AddressMatch = @MatchValPartial
					SET @AddressMatchColor = @MatchValPartialColor

					IF @AddressPriority <> 1
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET AddressMatch = @MatchValPartial
							,AddressMatchColor = @MatchValPartialColor
						WHERE AlrtDetMatchID = @IdentCurrent

						SET @AddressPriority = 2
					END
				END
						/*Address No Matches*/
				ELSE
				BEGIN
					SET @AddressMatch = @MatchValNone
					SET @AddressMatchColor = @MatchValNoneColor

					IF @AddressPriority <> 1
						AND @AddressPriority <> 2
					BEGIN
						UPDATE MDM_AlertDetailPartyMatch
						SET AddressMatch = @MatchValNone
							,AddressMatchColor = @MatchValNoneColor
						WHERE AlrtDetMatchID = @IdentCurrent
					END
				END

				EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
					,@InsWL_FullName = @WL_FullName
					,@InsWL_FName = @WL_FName
					,@InsWL_MName = @WL_MName
					,@InsWL_LName = @WL_LName
					,@InsPDM_PartyFullName = @PDM_PartyFullName
					,@InsPDM_PartyFName = @PDM_PartyFName
					,@InsPDM_PartyMName = @PDM_PartyMName
					,@InsPDM_PartyLName = @PDM_PartyLName
					,@InsNameMatch = @NameMatch
					,@InsNameMatchColor = @NameMatchColor
					,@InsWL_DOB = @WL_DOB
					,@InsPDM_PartyDOB = @PDM_PartyDOB
					,@InsDOBMatch = @DOBMatch
					,@InsDOBMatchColor = @DOBMatchColor
					,@InsWL_SSN = @WL_SSN
					,@InsPDM_PartySSN = @PDM_PartySSN
					,@InsPDM_PartySSNSource = @PDM_PartySSNSource
					,@InsSSNMatch = @SSNMatch
					,@InsSSNMatchColor = @SSNMatchColor
					,@InsWL_UPIN = @WL_UPIN
					,@InsPDM_PartyUPIN = @PDM_PartyUPIN
					,@InsUPINMatch = @UPINMatch
					,@InsUPINMatchColor = @UPINMatchColor
					,@InsWL_Alias = @WL_Alias
					,@InsPDM_PartyAlias = @PDM_PartyAlias
					,@InsAliasMatch = @AliasMatch
					,@InsAliasMatchColor = @AliasMatchColor
					,
					----------------------------------------------------------
					@InsWL_Address = @WL_Address
					,@InsPDM_PartyAddress = @PDM_PartyAddress
					,@InsPDM_PartyAddr1 = @PDM_PartyAddressLine1
					,@InsPDM_PartyCity = @PDM_PartyCity
					,@InsPDM_PartyState = @PDM_PartyState
					,@InsPDM_PartyZip = @PDM_PartyZip
					,@InsAddressMatch = @AddressMatch
					,@InsAddressMatchColor = @AddressMatchColor
					,@InsWL_DOD = @WL_DOD

				--SET @WL_Address = NULL // Commented to make watch list Address value available to all iterations
				SET @PDM_PartyAddress = NULL
				SET @AddressMatch = NULL
				SET @AddressMatchColor = NULL

				FETCH NEXT
				FROM addressCursor
				INTO @Cursor_Address
					,@Cursor_AddressLine1
					,@Cursor_City
					,@Cursor_State
					,@Cursor_Zip
			END

			CLOSE addressCursor

			DEALLOCATE addressCursor
		END
		ELSE
		BEGIN
			SELECT TOP 1 @PDM_PartyAddress = Address
				,@PDM_PartyAddressLine1 = replace(replace(Address1, '.', ''), ',', '')
				,@PDM_PartyCity = replace(replace(City, '.', ''), ',', '')
				,@PDM_PartyState = STATE
				,@PDM_PartyZip = Zip
			FROM KYP.MDM_PartyAddress
			WHERE PartyID = @WatchedPartyID
			ORDER BY ID DESC

			IF @WL_AddressLine1 = @PDM_PartyAddressLine1
				AND @WL_City = @PDM_PartyCity
				AND @WL_State = @PDM_PartyState
			BEGIN
				SET @AddressMatch = @MatchValFull
				SET @AddressMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET AddressMatch = @MatchValFull
					,AddressMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent

				SET @AddressPriority = 1
			END
			ELSE IF @WL_AddressLine1 = @PDM_PartyAddressLine1
				AND @WL_Zip = @PDM_PartyZip
			BEGIN
				SET @AddressMatch = @MatchValFull
				SET @AddressMatchColor = @MatchValFullColor

				UPDATE MDM_AlertDetailPartyMatch
				SET AddressMatch = @MatchValFull
					,AddressMatchColor = @MatchValFullColor
				WHERE AlrtDetMatchID = @IdentCurrent

				SET @AddressPriority = 1
			END
			ELSE IF @WL_City = @PDM_PartyCity
				AND @WL_State = @PDM_PartyState
			BEGIN
				SET @AddressMatch = @MatchValPartial
				SET @AddressMatchColor = @MatchValPartialColor

				IF @AddressPriority <> 1
				BEGIN
					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValPartial
						,AddressMatchColor = @MatchValPartialColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 2
				END
			END
			ELSE IF @WL_AddressLine1 = @PDM_PartyAddressLine1
			BEGIN
				SET @AddressMatch = @MatchValPartial
				SET @AddressMatchColor = @MatchValPartialColor

				IF @AddressPriority <> 1
				BEGIN
					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValPartial
						,AddressMatchColor = @MatchValPartialColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 2
				END
			END
			ELSE IF @WL_Zip = @PDM_PartyZip
			BEGIN
				SET @AddressMatch = @MatchValPartial
				SET @AddressMatchColor = @MatchValPartialColor

				IF @AddressPriority <> 1
				BEGIN
					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValPartial
						,AddressMatchColor = @MatchValPartialColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 2
				END
			END
			ELSE IF @WL_City = @PDM_PartyCity
			BEGIN
				SET @AddressMatch = @MatchValPartial
				SET @AddressMatchColor = @MatchValPartialColor

				IF @AddressPriority <> 1
				BEGIN
					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValPartial
						,AddressMatchColor = @MatchValPartialColor
					WHERE AlrtDetMatchID = @IdentCurrent

					SET @AddressPriority = 2
				END
			END
			ELSE
			BEGIN
				SET @AddressMatch = @MatchValNone
				SET @AddressMatchColor = @MatchValNoneColor

				IF @AddressPriority <> 1
					AND @AddressPriority <> 2
				BEGIN
					UPDATE MDM_AlertDetailPartyMatch
					SET AddressMatch = @MatchValNone
						,AddressMatchColor = @MatchValNoneColor
					WHERE AlrtDetMatchID = @IdentCurrent
				END
			END

			EXEC [KYP].[p_InsertMDMAlertDetailPartyMatch] @InsAlertID = @Cursor_AlertID
				,@InsWL_FullName = @WL_FullName
				,@InsWL_FName = @WL_FName
				,@InsWL_MName = @WL_MName
				,@InsWL_LName = @WL_LName
				,@InsPDM_PartyFullName = @PDM_PartyFullName
				,@InsPDM_PartyFName = @PDM_PartyFName
				,@InsPDM_PartyMName = @PDM_PartyMName
				,@InsPDM_PartyLName = @PDM_PartyLName
				,@InsNameMatch = @NameMatch
				,@InsNameMatchColor = @NameMatchColor
				,@InsWL_DOB = @WL_DOB
				,@InsPDM_PartyDOB = @PDM_PartyDOB
				,@InsDOBMatch = @DOBMatch
				,@InsDOBMatchColor = @DOBMatchColor
				,@InsWL_SSN = @WL_SSN
				,@InsPDM_PartySSN = @PDM_PartySSN
				,@InsPDM_PartySSNSource = @PDM_PartySSNSource
				,@InsSSNMatch = @SSNMatch
				,@InsSSNMatchColor = @SSNMatchColor
				,@InsWL_UPIN = @WL_UPIN
				,@InsPDM_PartyUPIN = @PDM_PartyUPIN
				,@InsUPINMatch = @UPINMatch
				,@InsUPINMatchColor = @UPINMatchColor
				,@InsWL_Alias = @WL_Alias
				,@InsPDM_PartyAlias = @PDM_PartyAlias
				,@InsAliasMatch = @AliasMatch
				,@InsAliasMatchColor = @AliasMatchColor
				,
				----------------------------------------------------------
				@InsWL_Address = @WL_Address
				,@InsPDM_PartyAddress = @PDM_PartyAddress
				,@InsPDM_PartyAddr1 = @PDM_PartyAddressLine1
				,@InsPDM_PartyCity = @PDM_PartyCity
				,@InsPDM_PartyState = @PDM_PartyState
				,@InsPDM_PartyZip = @PDM_PartyZip
				,@InsAddressMatch = @AddressMatch
				,@InsAddressMatchColor = @AddressMatchColor
				,@InsWL_DOD = @WL_DOD
		END

		/************************** END: ADDRESS MATCH ******************************/
		/*CLEAR ALL VARIABLES BEFORE NEXT CURSOR CYCLE*/
		SET @Cursor_AlertID = NULL
		SET @WL_FullName = NULL
		SET @WL_FName = NULL
		SET @WL_MName = NULL
		SET @WL_LName = NULL
		SET @PDM_PartyFullName = NULL
		SET @PDM_PartyFName = NULL
		SET @PDM_PartyMName = NULL
		SET @PDM_PartyLName = NULL
		SET @NameMatch = NULL
		SET @NameMatchColor = NULL
		SET @WL_DOB = NULL
		SET @WL_DOD = NULL --New Watchlist changes
		SET @PDM_PartyDOB = NULL
		SET @DOBMatch = NULL
		SET @DOBMatchColor = NULL
		SET @WL_SSN = NULL
		SET @PDM_PartySSN = NULL
		SET @PDM_PartySSNSource = NULL
		SET @SSNMatch = NULL
		SET @SSNMatchColor = NULL
		SET @WL_UPIN = NULL
		SET @PDM_PartyUPIN = NULL
		SET @UPINMatch = NULL
		SET @UPINMatchColor = NULL
		SET @WL_Alias = NULL
		SET @PDM_PartyAlias = NULL
		SET @AliasMatch = NULL
		SET @AliasMatchColor = NULL
		SET @WL_TaxID = NULL
		SET @PDM_PartyTaxID = NULL
		SET @PDM_PartyTaxIDSource = NULL
		SET @PDM_PartyTaxIDOMSSource = NULL
		SET @TaxIDMatch = NULL
		SET @TaxIDMatchColor = NULL
		SET @WL_NPI = NULL
		SET @PDM_PartyNPI = NULL
		SET @NPIMatch = NULL
		SET @NPIMatchColor = NULL
		SET @WL_License = NULL
		SET @WL_LicenseState = NULL
		SET @PDM_PartyLicense = NULL
		SET @PDM_PartyLicenseSource = NULL
		SET @LicenseMatch = NULL
		SET @LicenseMatchColor = NULL
		SET @WL_Specialty = NULL
		SET @PDM_PartySpecialty = NULL
		SET @SpecialtyMatch = NULL
		SET @SpecialtyMatchColor = NULL
		SET @WL_Address = NULL
		SET @PDM_PartyAddress = NULL
		SET @AddressMatch = NULL
		SET @AddressMatchColor = NULL
		SET @TaxIDPriority = 0
		SET @NPIPriority = 0
		SET @LicensePriority = 0
		SET @SpecialtyPriority = 0
		SET @AddressPriority = 0

		FETCH NEXT
		FROM mycursor
		INTO @Cursor_AlertID
	END

	/**CURSOR END**/
	CLOSE mycursor

	DEALLOCATE mycursor	

	update kyp.MDM_AlertDetailPartyMatch set PDM_PartyNPI=null where PDM_PartyNPI=0

	UPDATE x
	SET x.PDM_PartySSN = y.PDM_PartySSN
	FROM kyp.MDM_AlertDetailPartyMatch x
	INNER JOIN (
		SELECT DISTINCT A.AlertID
			,PDM_PartySSN
		FROM kyp.MDM_AlertDetailPartyMatch A INNER JOIN
		KYP.MDM_Alert B ON A.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate
		WHERE coalesce(PDM_PartySSN, '') <> ''
		) y ON x.AlertID = y.AlertID
	WHERE coalesce(x.PDM_PartySSN, '') = ''

	UPDATE x
	SET x.WL_SSN = y.WL_SSN
	FROM kyp.MDM_AlertDetailPartyMatch x
	INNER JOIN (
		SELECT DISTINCT A.AlertID
			,WL_SSN
		FROM kyp.MDM_AlertDetailPartyMatch A INNER JOIN
		KYP.MDM_Alert B ON A.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate
		WHERE coalesce(WL_SSN, '') <> ''
		) y ON x.AlertID = y.AlertID
	WHERE coalesce(x.WL_SSN, '') = ''

	UPDATE x
	SET x.SSNMatch = 'NoMatch'
		,x.SSNMatchColor = 'Color[r=255,g=255,b=255]'
	FROM kyp.MDM_AlertDetailPartyMatch x
	INNER JOIN KYP.MDM_Alert B ON x.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate
	WHERE x.WL_SSN = x.PDM_PartySSN
		AND coalesce(x.WL_SSN, '') <> ''
		AND coalesce(x.PDM_PartySSN, '') <> ''

	UPDATE x
	SET x.SSNMatch = 'NoMatch'
		,x.SSNMatchColor = 'Color[r=255,g=255,b=255]'
	FROM kyp.MDM_AlertDetailPartyMatch x
	INNER JOIN KYP.MDM_Alert B ON x.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate
	WHERE x.WL_SSN <> x.PDM_PartySSN
		OR coalesce(x.WL_SSN, '') = ''
		OR coalesce(x.PDM_PartySSN, '') = ''

	UPDATE kyp.MDM_AlertDetailPartyMatch
	SET PDM_PartySpeciality = NULL
	WHERE PDM_PartySpeciality = 'unknown'

	UPDATE kyp.MDM_AlertDetailPartyMatch
	SET WL_Speciality = NULL
	WHERE WL_Speciality = 'unknown'

	/*CAPAVE-254 STart */
	Update P
	Set P.TerminatingState=D.Board_Description,
	P.TerminationCause=D.Offense_Description,
	P.TerminationEffectiveDate=isnull(convert(date,D.Action_Date),D.TerminationEffectiveDate), --Added Convert to Date part by Sundar on 4-Sep-2018
	P.TerminationImportDate=D.TerminationImportDate,
	P.AdditionalComments=D.AdditionalComments
	From kyp.MDM_Alert A
	Join kyp.MDM_AlertDetail D on A.AlertID = D.AlertID
	Join kyp.MDM_AlertDetailPartyMatch P on D.AlertID = P.AlertID
	Where A.WatchlistName = 'Medicaid & Medicare Exclusion'
	and D.AlertGenCriteria like '%MCSIS Medica%'

	Update P
	Set P.TerminatingAgency = 'CMS MCSIS - Medicaid'
	From kyp.MDM_Alert A
	Join kyp.MDM_AlertDetail D on A.AlertID = D.AlertID
	Join kyp.MDM_AlertDetailPartyMatch P on D.AlertID = P.AlertID
	Where A.WatchlistName = 'Medicaid & Medicare Exclusion'
	and D.AlertGenCriteria like '%MCSIS Medicaid%'

	Update P
	Set P.TerminatingAgency = 'CMS MCSIS - Medicare'
	From kyp.MDM_Alert A
	Join kyp.MDM_AlertDetail D on A.AlertID = D.AlertID
	Join kyp.MDM_AlertDetailPartyMatch P on D.AlertID = P.AlertID
	Where A.WatchlistName = 'Medicaid & Medicare Exclusion'
	and D.AlertGenCriteria like '%MCSIS Medicare%'
	/*CAPAVE-254 End */

	UPDATE x
	SET x.NPI = y.npi
	FROM kyp.MDM_Alert x
	INNER JOIN kyp.pdm_provider y ON x.WatchedPartyID = y.PartyID
	WHERE x.NPI IS NULL
		AND x.DateInitiated >= @pmfloaddate

	UPDATE x
	SET x.ProviderType = z.ProviderTypeDescription
	FROM kyp.MDM_Alert x
	INNER JOIN kyp.pdm_provider y ON x.WatchedPartyID = y.PartyID
	INNER JOIN kyp.PDM_ProviderTypeCode z ON y.Type = z.ProviderTypeCode
	WHERE x.ProviderType IS NULL
		AND x.DateInitiated >= @pmfloaddate

	UPDATE A
	SET A.SSN = B.SSN
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Person B ON A.WatchedPartyID = B.PartyID
		AND A.WatchedPartyType = 'Individual'
	WHERE A.SSN IS NULL
		AND A.DateInitiated >= @pmfloaddate

	UPDATE A
	SET A.TAXID = B.TaxId
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Person B ON A.WatchedPartyID = B.PartyID
		AND A.WatchedPartyType = 'Individual'
	WHERE A.TAXID IS NULL
		AND A.DateInitiated >= @pmfloaddate

	UPDATE A
	SET A.TAXID = C.TIN
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Organization C ON A.WatchedPartyID = C.PartyID
		AND A.WatchedPartyType = 'Institutional'
	WHERE A.TAXID IS NULL
		AND A.DateInitiated >= @pmfloaddate

	UPDATE A
	SET A.SSN = C.SSN
	FROM KYP.MDM_Alert A
	INNER JOIN KYP.PDM_Organization C ON A.WatchedPartyID = C.PartyID
		AND A.WatchedPartyType = 'Institutional'
	WHERE A.SSN IS NULL
		AND A.DateInitiated >= @pmfloaddate

	/*CAPAVE-228*/
	UPDATE ADPM
	SET ADPM.Board_Code = AD.Board_Code
	FROM KYP.MDM_AlertDetailPartyMatch ADPM
	INNER JOIN KYP.MDM_AlertDetail AD ON AD.AlertID = ADPM.AlertID
	INNER JOIN KYP.MDM_Alert B ON AD.AlertID = B.AlertID AND B.DateInitiated >= @pmfloaddate
	WHERE AD.Board_Code IS NOT NULL
		/*CAPAVE-228*/

	/* #2 CAPAVE-334 Start*/
	Update X set X.NPI=Y.pdm_partynpi
	from kyp.MDM_Alert X
	inner join
	(
		  select pdm_partynpi,alertid from KYP.MDM_AlertDetailPartyMatch where pdm_partynpi is not null
	)Y
	on X.alertid=Y.alertid
	where X.NPI is not null 
	and X.NPI<>Y.pdm_partynpi
	/*#2 CAPAVE-334 End*/
END


GO

