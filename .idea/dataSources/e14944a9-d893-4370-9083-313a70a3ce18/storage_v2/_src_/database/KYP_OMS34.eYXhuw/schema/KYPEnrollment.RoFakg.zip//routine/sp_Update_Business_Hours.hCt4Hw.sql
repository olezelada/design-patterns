
/* ==========================================================
-- Author:		<NRojas>
-- PROCEDURE: Update Business Hours by Traking.   
-- PARAMETERS: 
-- @party_account_id: Party from account.
-- @application_id : Application ID. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Business_Hours]
   @party_account_id       INT,
   @application_id         INT,
   @last_action_user_id    VARCHAR (100)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE,
		   @fullHoursService VARCHAR(200),
		   @logisticDay VARCHAR(50),
		   @logisticFrom VARCHAR(50),
		   @logisticTo VARCHAR(50),
		   @action_taken VARCHAR(20),
		   @acc_pk_value INT,
		   @fullHoursServiceApp VARCHAR(200);

   SET @date_created = GETDATE ();

   SELECT @fullHoursService = FullHoursService
    FROM KYPEnrollment.PADM_BusinessService
    WHERE PartyID = @party_account_id;
    
    SELECT @fullHoursServiceApp = bus.FullHoursService
	  FROM KYPPORTAL.PortalKYP.pADM_Application por 
		  inner join KYPEnrollment.pADM_Account acc on por.ApplicationNo = acc.ApplicationNumber
		  inner join KYPPORTAL.PortalKYP.pPDM_BusinessService bus on por.PartyID = bus.PartyID
	  WHERE acc.PartyID = @party_account_id;
    
    IF @fullHoursService = 'Open 24/7'
    BEGIN
		UPDATE [KYPEnrollment].[PADM_BusinessHours]
		SET isDeleted = 1
		WHERE PartyID = @party_account_id;

		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Monday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Tuesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Wednesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Thursday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Friday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Saturday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES ('Sunday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0,1)
    END 
	ELSE
	BEGIN
		IF (@fullHoursService <> @fullHoursServiceApp) AND EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'fullHoursService')
		BEGIN
			UPDATE [KYPEnrollment].[PADM_BusinessHours]
			SET isDeleted = 1
			WHERE PartyID = @party_account_id;
		END

		-- Monday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('bShoursMonday','timeToMo','timeFromMo') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted' OR EnDbColumn='IsDeleted') and Accepted=1 )
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken, @acc_pk_value = AccPKValue
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id and Accepted=1
			AND FieldCode LIKE 'bShoursMonday';
	
			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'bShoursMonday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'timeFromMo';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'timeToMo';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1, 1)
			END
						
			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromMo' and Accepted=1)
				BEGIN
					
					--DELETED:
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromMo') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromMo';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
						
					END
					
					ELSE
					--UPDATED:
					BEGIN
					
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromMo';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToMo')
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToMo') and (NewValueText is null OR NewValueText = '') and Accepted=1)
					BEGIN				
						
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToMo';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
						
					END
					
					ELSE
					
					BEGIN
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToMo';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Monday';
			END
		END  

		-- Tuesday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('bShoursTuesday','timeFromTu','timeToTu') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted'  OR EnDbColumn='IsDeleted') and Accepted=1 )
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode = 'bShoursTuesday';

			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'bShoursTuesday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'timeFromTu';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id and Accepted=1
				AND FieldCode = 'timeToTu';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1,1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromTu' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromTu') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeFromTu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromTu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
				
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToTu' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToTu') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
										
						print 'Inside If of Tuesday'
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeToTu';
						
						print '@acc_pk_value'
						print @acc_pk_value
						print '@party_account_id'
						print @party_account_id

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
						IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToTu') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
						BEGIN
					
							SELECT @acc_pk_value = AccPKValue
							FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
							WHERE ApplicationID = @application_id AND Accepted=1
							AND FieldCode = 'timeToTu';

							UPDATE [KYPEnrollment].[PADM_BusinessHours]
							SET TimeTo = NULL
							WHERE PartyID = @party_account_id
							AND BusinessHoursID = @acc_pk_value;
						END
					
------------------------------------------------------					
						ELSE
					
						BEGIN
					
							SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
							FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
							WHERE ApplicationID = @application_id and Accepted=1
							AND FieldCode = 'timeToTu';

							UPDATE [KYPEnrollment].[PADM_BusinessHours]
							SET TimeTo = '1/1/1970 ' + @logisticTo
							WHERE PartyID = @party_account_id
							AND BusinessHoursID = @acc_pk_value;
					
						END
					END
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Tuesday';
			END
		END  

		-- Wednesday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('bShoursWednesday','timeFromW','timeToW') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted' OR EnDbColumn='IsDeleted') AND Accepted=1)
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode LIKE 'bShoursWednesday';

			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'bShoursWednesday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeFromW';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeToW';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1,1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromW' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromW') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeFromW';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromW';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END				
					
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToW' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToW') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeToW';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
				
					END
				
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToW';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
							
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Wednesday';
			END
		END  

		-- Thursday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('timeToTh','timeFromTh','bShoursThursday') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted'  OR EnDbColumn='IsDeleted') and Accepted=1 )
		BEGIN
		
			print 'entro a thursday'
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode LIKE 'bShoursThursday';

			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'bShoursThursday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeFromTh';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeToTh';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1, 1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromTh' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromTh') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
					
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeFromTh';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END					
					
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromTh';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToTh' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToTh') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeToTh';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToTh';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Thursday';
			END
		END  

		-- Friday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('bShoursFriday','timeToF','timeFromF') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted'  OR EnDbColumn='IsDeleted') and Accepted=1)
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode LIKE 'bShoursFriday';

			IF @action_taken = 'Added'
			BEGIN
				
				
				
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'bShoursFriday';

				----------------
				print 'timeFromF 1'
				----------------
				

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeFromF';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeToF';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1,1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromF' and Accepted=1)
				BEGIN
					
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromF') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
												
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeFromF';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = null
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromF';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END			
					
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToF' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToF') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN					
					
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id AND Accepted=1
						AND FieldCode = 'timeToF';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = NULL
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToF';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END				
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Friday';
			END
		END

		-- Saturday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('timeToSa','timeFromSa','bShoursSaturday') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted'  OR EnDbColumn='IsDeleted') and Accepted=1)
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode LIKE 'bShoursSaturday';

			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'bShoursSaturday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeFromSa';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeToSa';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1, 1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromSa' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromSa') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
						
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromSa';
						
						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = null
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
										
					END
					
					ELSE	
					
					BEGIN
				
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromSa';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
						
					END
									
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToSa' and Accepted=1)
				BEGIN	
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToSa') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
			
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToSa';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = null
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeToSa';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END				
					
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Saturday';
			END
		END

		-- Sunday
		IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode in ('timeToSu','timeFromSu','bShoursSunday') AND (NewValueText IS NOT NULL OR ActionTaken = 'Deleted'  OR EnDbColumn='IsDeleted') and Accepted=1)
		BEGIN
			SELECT TOP 1 @action_taken = ActionTaken
			FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
			WHERE ApplicationID = @application_id 
			AND FieldCode LIKE 'bShoursSunday';
			
			IF @action_taken = 'Added'
			BEGIN
				SELECT @logisticDay = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'bShoursSunday';

				SELECT @logisticFrom = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeFromSu';

				SELECT @logisticTo = NewValueText
				FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
				WHERE ApplicationID = @application_id  and Accepted=1
				AND FieldCode = 'timeToSu';

				INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted], [CurrentRecordFlag]) VALUES (@logisticDay, '1/1/1970 ' + @logisticFrom, '1/1/1970 ' + @logisticTo, @party_account_id, 1, 1)
			END

			IF @action_taken = 'Updated'
			BEGIN
				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeFromSu' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeFromSu') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
				
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromSu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = null
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
						
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticFrom = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id and Accepted=1
						AND FieldCode = 'timeFromSu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeFrom = '1/1/1970 ' + @logisticFrom
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
									
				END

				IF EXISTS (SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'timeToSu' and Accepted=1)
				BEGIN
				
					IF EXISTS(select FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking where ApplicationID = @application_id and FieldCode in ('timeToSu') and (NewValueText is null OR NewValueText = '') and Accepted=1 )
					BEGIN
							
						SELECT @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id  and Accepted=1
						AND FieldCode = 'timeToSu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = null
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
					ELSE
					
					BEGIN
					
						SELECT @logisticTo = NewValueText, @acc_pk_value = AccPKValue
						FROM KYPPORTAL.PortalKYP.FieldValuesTracking 
						WHERE ApplicationID = @application_id  and Accepted=1
						AND FieldCode = 'timeToSu';

						UPDATE [KYPEnrollment].[PADM_BusinessHours]
						SET TimeTo = '1/1/1970 ' + @logisticTo
						WHERE PartyID = @party_account_id
						AND BusinessHoursID = @acc_pk_value;
					
					END
					
				END
			END

			IF @action_taken = 'Deleted'
			BEGIN
				UPDATE [KYPEnrollment].[PADM_BusinessHours]
				SET IsDeleted = 1
				WHERE PartyID = @party_account_id
				AND Day = 'Sunday';
			END
		END
	END 
END


GO

