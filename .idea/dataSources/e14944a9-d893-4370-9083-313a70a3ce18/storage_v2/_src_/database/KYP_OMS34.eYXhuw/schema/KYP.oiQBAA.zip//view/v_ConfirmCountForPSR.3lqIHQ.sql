


CREATE VIEW [KYP].[v_ConfirmCountForPSR] AS
Select COUNT(AlertNo) TotalConfirmed,UserID from KYP.MDM_WorkflowHistory a inner join kyp.MDM_Alert b on a.alertid=b.alertid
where  a.activitystatus='Updated Alert Status' and b.MatchStatusIndicator='C' --and wfstatus='Completed' 
and b.IsMerged='N'
and b.IsDeleted='false'
group by UserID


GO

