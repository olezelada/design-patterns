
CREATE VIEW [KYPEnrollment].[v_OutEDIGroupRFile_WeeklyReport]
AS
SELECT row_number() OVER (ORDER BY RenderingAffiliationID ASC) AS ID, *
FROM         
(
Select DISTINCT x.TypeAffiliation,x.RenderingAffiliationID --,x.LastUpdatedBy
,x.LastActionDate --LastActionDate for fetch the data based on specific date
,x.BallingNPI,x.OwnerNo,x.ServiceLocationNo,x.ProviderTypeCode,x.GroupRenderingNPI 

from( 
select RAff.TypeAffiliation,RAff.RenderingAffiliationID,RAff.LastActionDate,RAff.LastUpdatedBy
-- Field of pADM_Account A (Billing)
,A.NPI AS BallingNPI,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode,A.IsDeleted
-- Field of pADM_Account AR (Group Rendring)
,AR.NPI AS GroupRenderingNPI
from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
-- This is for Group Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
--where RAff.AffiliationStartDate!=RAff.AffiliationEndDate
 where RAff.TypeAffiliation='Group-Rendering'
) x --where x.TypeAffiliation='Group-Rendering' AND x.LastUpdatedBy != 'M'
	--AND CONVERT(VARCHAR, x.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-7, 101) and CONVERT(VARCHAR, x.LastActionDate , 101) <=  CONVERT(VARCHAR, GETDATE(), 101)
--where CONVERT(VARCHAR, x.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-1, 101) 

) z

------------------------------------------- Close of Group Relationship file ------------------------------------------------------------------------------


GO

