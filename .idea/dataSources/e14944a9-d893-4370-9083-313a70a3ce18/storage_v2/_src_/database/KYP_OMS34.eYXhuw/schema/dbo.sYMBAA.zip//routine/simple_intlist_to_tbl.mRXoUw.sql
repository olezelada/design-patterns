CREATE FUNCTION [dbo].[simple_intlist_to_tbl] (@list nvarchar(MAX))
   RETURNS @tbl TABLE (number varchar(100)  NULL,NoteEntityType varchar(100)  null, NoteEntityTypeID varchar(100) null,
   NoteEntityDep varchar(100) null,NoteEntityDepID varchar(100) null,Level int null
   ,IsLastLevel bit null
   ) AS
BEGIN
   DECLARE @pos        int,
           @nextpos    int,
           @valuelen   int,
           @pos1        int,
           @nextpos1    int,
           @valuelen1 int,
           @value varchar(500),
           @value2 varchar(100),
           @value3 varchar(100),
           @Temp varchar(150),
           @pos2 int,
           @valuelen2 int,
           @nextpos3 int,
           @nextpos2 int,
           @valuelen3 int,
           @pos3 int,
           @value4 varchar(100),
           @value5 varchar(100),
           @Level int

   SELECT @pos = 0, @nextpos = 1,@pos2=0,@pos3=0
   SELECT @pos1 = 0, @nextpos1 = 1,@nextpos2=1
   WHILE @nextpos > 0
   BEGIN
      SELECT @nextpos = charindex('|', @list, @pos + 1)
      SELECT @valuelen = CASE WHEN @nextpos > 0 THEN @nextpos
                              ELSE len(@list) + 1
                              
                               END - @pos - 1
                        
       Select @value = substring(@list, @pos + 1, @valuelen)
      
       SELECT @nextpos1 = charindex('-', @value, @pos1 + 1)
       SELECT @valuelen1 = CASE WHEN @nextpos1 > 0
                              THEN @nextpos1
                              ELSE len(@value) + 1
                         END - @pos1 - 1
       
       
        select @value2=substring(@value, @pos1 + 1, @valuelen1)
        select @value3=substring(@value,@valuelen1+2,len(@value)-1)
        
       if @pos >0
       begin
         SELECT @nextpos2 = charindex('|', left(@list,@pos), @pos)
         SELECT @valuelen2 = CASE WHEN @nextpos2 > 0 
								THEN @nextpos2
                              ELSE len(Left(@list,@pos)) + 1
                              
                               END - @pos2 - 1
           --SELECT @valuelen2=@nextpos2
          --select @Temp=substring(@list,@pos,@nextpos2) 
         -- select @Temp=convert(varchar,@pos2)
          
          --select @Temp=left(@list,@pos)
         --Select @Temp= substring(left(@list,@pos), 0, @valuelen2)
         select @Temp=substring(@list,@pos2+1,len(substring(@list,@pos2+1,@valuelen2)))
         
         SELECT @nextpos3 = charindex('-', @Temp, @pos3 + 1)
         SELECT @valuelen3 = CASE WHEN @nextpos3 > 0
                              THEN @nextpos3
                              ELSE len(@Temp) + 1
                         END - @pos3 - 1
         select @value4=substring(@Temp, @pos3 + 1, @valuelen3)
         select @value5=substring(@Temp,@valuelen3+2,len(@Temp)-1)
         Select @Level=@Level+1
         
         --select @Temp=convert(varchar,len(substring(@list,@pos,@valuelen2)))
         select @pos2=@nextpos2
         
       
       end 
       
       else
       begin
        select @Temp=substring(@value, @pos1 + 1, @valuelen1)
        select @value4=substring(@value, @pos1 + 1, @valuelen1)
        select @value5=substring(@value,@valuelen1+2,len(@value)-1)
        Select @Level=0
        
       end
       
        
        
    
        INSERT @tbl (number,NoteEntityType,NoteEntityTypeID,NoteEntityDep,NoteEntityDepID,Level,IsLastLevel)
         VALUES (convert(varchar, substring(@value, @pos1 + 1, @valuelen1)),@value2,@value3,@value4,@value5,@Level,0) 
         
      
        
       
      SELECT @pos = @nextpos
   END
   update @tbl set IsLastLevel=1 where Level= @Level
   RETURN
END


GO

