
-- =============================================
-- Author:		Sundar
-- Create date: 19-Jun-2019
-- Description:	To Update OIS_EnrollUserRole data on any DML from OIS_JT_UserRole table
-- =============================================
CREATE TRIGGER [KYP].[Trg_OIS_JT_UserRole_Insert_Delete] 
   ON [KYP].[OIS_JT_UserRole]
   AFTER INSERT,DELETE
AS 
BEGIN
	SET NOCOUNT ON;

	IF Exists(Select * from inserted)
	Begin
		Insert into KYP.OIS_EnrollUserRole(UserID,RoleID)
		Select UserID, RoleID From inserted
		Except
		Select UserId, RoleID From KYP.OIS_EnrollUserRole;
	End
	
	IF Exists(Select * from deleted)
	Begin
		Delete A 
		From KYP.OIS_EnrollUserRole A
		Join Deleted B on A.RoleId = B.RoleID AND A.UserID = B.UserID
	End	

END

GO

