



CREATE VIEW [KYPEnrollment].[V_AccountUpdatedYesterday_capave_4272] AS

select Distinct (IH.AccountID), 'system' as userName,
			CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate, 
			PA.AccountType  as AccountType
			,PA.AccountNumber
			from  KYPEnrollment.INPUTDOC_BILLER  IH
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= IH.AccountID
			where Cast(IH.DateModified as DATE)=Cast(GETDATE()-1 as DATE) AND PA.IsDeleted!=1
			UNION				
		--Start: For newly created account from portal
			Select distinct(AccountID),'system' as userName,CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate,
			AccountType
			,AccountNumber
			from KYPEnrollment.pADM_Account where Cast(DateCreated as DATE)=Cast(GETDATE()-1 as DATE) AND IsDeleted!=1 
			and LegacyAccountNo is null 
		--End: For newly created account from portal
			UNION		
			SELECT Distinct RA.AccountID, 'system' as userName,
			CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate, 
			PA.AccountType  as AccountType
			,PA.AccountNumber
			FROM KYPEnrollment.pAccount_RenderingAffiliation  RA
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= RA.AccountID
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PRA on  PRA.AccountID= RA.AffiliatedAccountID				
			where Cast(RA.LASTACTIONDATE as DATE)=Cast(GETDATE()-1 as DATE) 
			AND PA.IsDeleted!=1 
			and RA.LastActorUserID<>'System' 	
			and RA.affiliatedaccountid is not null /*Added to remove unwanted Data*/
			and PRA.NPI not like '%[a-z]%'			
			--UNION
			--SELECT Distinct IMH.AccountID, 'system' as userName,
			--CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate, 
			--PA.AccountType  as AccountType
			--,PA.AccountNumber
			--FROM KYPEnrollment.INPUTDOC_MOCAHistory IMH
			--Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= IMH.AccountID
			--where Cast(IMH.DateModified as DATE)=Cast(GETDATE()-1 as DATE) AND PA.IsDeleted!=1
			UNION
			SELECT Distinct IRH.AccountID, 'system' as userName,
			CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate, 
			PA.AccountType  as AccountType
			,PA.AccountNumber
			FROM KYPEnrollment.INPUTDOC_RenderingHistory IRH
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= IRH.AccountID
			where Cast(IRH.DateModified as DATE)=Cast(GETDATE()-1 as DATE) AND PA.IsDeleted!=1
			
			Union
			Select Distinct A.AccountID, 'System' as UserName, Cast(Cast(Getdate()-1 as Date) as Datetime) as UserDate,
			A.AccountType
			,A.AccountNumber
			From kypenrollment.pADM_Account A
			Join KYPEnrollment.EDM_AccountInternalUse IU on A.AccountID=IU.AccountID
			Join KYPEnrollment.EDM_AccountInternalMany IM on IU.AccountInternalUseID=IM.AccountInternalUseID
			where IM.LastActorUserID is null
			and A.IsDeleted=0 --Added this statment to fix the SFTP inpudoc issue :Ramya on 12Jun2018
			and IM.CodeType = 'Sanction'
			and A.AccountUpdatedBy <> 'M'
			and convert(date,A.LastActionDate)=convert(date,Getdate()-1)
			and (IU.IsApproved = 1 OR IU.IsApproved is null)
			and (IM.IsApproved = 1 OR IM.IsApproved is null) --Added for CAPAVE-3142, 3139 by Sundar on 8May2018
			UNION		
			SELECT AccountID , 'system' as userName,
			CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate, 
			AccountType  as AccountType
			,AccountNumber
			FROM KYPEnrollment.pADM_Account 
			where AccountNumber in (SELECT  DISTINCT AccountNo 
									FROM KYP.ADM_Case a 
									where a.SupUpdateFlag='5A'
										AND convert(date,DateReceived)=Convert(date,GETDATE()-1))


GO

