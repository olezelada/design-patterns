

CREATE FUNCTION [KYP].[checkListValues] (@TemplateName varchar(50), @ExpectedValue varchar(50)
)
RETURNS bit
AS
BEGIN
Declare @res bit
Set @res = 0
	if(@TemplateName='Milestones Checklist')
    BEGIN
 	 if(@ExpectedValue='In Portal' or @ExpectedValue='Submitted' or @ExpectedValue='Received' 
        or @ExpectedValue='Accepted' or @ExpectedValue='Automated Screening Completed' )
     	BEGIN
        Set @res = 1
        END 
    END
    
    return @res
END


GO

