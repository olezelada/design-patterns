






CREATE TRIGGER [KYPEnrollment].[CreateIUDNewAccountData] ON [KYPEnrollment].[EDM_ApplicationInternalUse]
WITH EXECUTE AS CALLER
 AFTER INSERT
AS 
BEGIN


Declare

@AccountInternalUseID int,
@LastActionComments varchar(255),
@ProviderTypeCode varchar(20)


SET @AccountInternalUseID = (select AccountInternalUseID from inserted);
SET @LastActionComments = (select ApplicationNumber from inserted);
SET @ProviderTypeCode = (select ProviderTypeCode from inserted);

 
if(@ProviderTypeCode='002' or @ProviderTypeCode='024')
BEGIN
EXECUTE [KYPEnrollment].[Copy_AccountNewInternalUseData]  @AccountInternalUseID,@LastActionComments,@ProviderTypeCode
END
END


GO

