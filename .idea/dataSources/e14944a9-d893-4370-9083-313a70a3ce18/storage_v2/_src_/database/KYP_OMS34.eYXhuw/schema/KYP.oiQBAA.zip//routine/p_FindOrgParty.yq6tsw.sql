
-- =============================================
-- Author:		Yogesh Sharma
-- Create date: July 28 2012
-- Description:	Finds Organizational Party based on OrganizationName+TAXID+NPI 
-- Modified: Nitish Gondkar
-- Modified Date: 02-Aug-2013
-- Modified Description: Removed ISNULL check from TAXID & NPI
-- =============================================
CREATE PROCEDURE [KYP].[p_FindOrgParty]
	-- Add the parameters for the stored procedure here
	@OrgName VARCHAR(200)
	,@TAXID VARCHAR(9) = NULL
	,@NPI VARCHAR(10) = NULL
	,@City VARCHAR(25) = NULL
	,@ZIP VARCHAR(5) = NULL
	,@Adr_Line1 VARCHAR(50) = NULL
	,@DBAName1 VARCHAR(200) = NULL
	,@CurrentModule SMALLINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @PartyID INT

	IF (LTRIM(RTRIM(ISNULL(@OrgName, '')))) = ''
	BEGIN
		SET @OrgName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@DBAName1, '')))) = ''
	BEGIN
		SET @DBAName1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@TAXID, '')))) = ''
	BEGIN
		SET @TAXID = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@NPI, '')))) = ''
	BEGIN
		SET @NPI = NULL;
	END

	/********Do a OrganizationName+TAXID+NPI match**********/
	IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND B.DBAName1 = @DBAName1
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND B.DBAName1 = @DBAName1
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND B.DBAName1 = @DBAName1
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND B.DBAName1 = @DBAName1
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND B.DBAName1 = @DBAName1
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND B.DBAName1 = @DBAName1
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.DBAName1 = @DBAName1
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.DBAName1 = @DBAName1
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.DBAName1 = @DBAName1
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.DBAName1 = @DBAName1
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND (B.NPI = @NPI AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.DBAName1 = @DBAName1
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.DBAName1 = @DBAName1
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LegalName = @OrgName
				AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LegalName = @OrgName
			AND (B.TIN = @TAXID AND ISNULL(B.TIN, '0') <> '0')

		RETURN @PartyID
	END
	ELSE
		RETURN - 1
END


GO

