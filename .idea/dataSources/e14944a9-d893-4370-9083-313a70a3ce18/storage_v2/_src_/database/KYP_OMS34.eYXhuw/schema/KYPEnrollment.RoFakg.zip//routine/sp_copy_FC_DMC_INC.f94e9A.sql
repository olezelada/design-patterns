-- =============================================
-- Author:		<Lacunza,Giresse>
-- Create date: <2017-05-09>
-- Description:	<Description, This procedure copy Person, Provider, Party, Number and Alias from Portal into Enrollment for Counselor type Partys>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_FC_DMC_INC] (

	@new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT, 
	@last_Action_User_ID VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@application_type varchar (100))
	
	
AS
BEGIN

DECLARE 
	@new_Address_Id INT,
	@new_person_id INT,
	@party_contact_id INT,
	@party_contact_id_portal INT,
	@npi_Type VARCHAR(25),
	@npi VARCHAR (10),
	@provider_type_code VARCHAR(5),
	@account_number VARCHAR(20),

--others
	@new_party_id_account INT,
	@party_id_portal INT,
	@new_party_counselor INT
	SET @new_party_id_account = @new_Party_Id;
	SET @party_id_portal=@party_Id;
	
 
--Social Form: Business Information: 
 
	--Business Profile	
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Business_Profile]@new_Party_Id, @party_Id,@last_Action_User_ID;
	--Contact Person
    EXEC [KYPEnrollment].[sp_Contact_Person] @party_id_portal, @new_party_id_account,@last_action_user_id,@new_account_id;	
	--Addresses
   	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Mailing', @last_Action_User_ID;
	--Insurance
    EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id, @party_Id,@last_action_user_id;   
    
--Social Form: Drug Clinic Services:    
  
    
 
--Social Form: Disclosure Information:

	--Program Participation
    EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id; 
	--Adverse Action	
    EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id; 
	--Fines/Debts   
    EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_id_portal, @new_party_id_account, @last_action_user_id,NULL;

	--Subcontractor
	EXEC [KYPEnrollment].[sp_Copy_Subcontractor]@party_Id, @new_Party_Id, @last_Action_User_ID,@new_Account_Id;     
    
	--Owner Interest
	EXEC [KYPEnrollment].[sp_Copy_Owner_Interest] @new_Party_Id, @party_Id,@last_Action_User_ID,NULL,@new_Account_Id,0;  
        
	--Significant Transaction
	EXEC [KYPEnrollment].[sp_Copy_Significant_Transaction] @party_Id, @new_Party_Id, @last_Action_User_ID,@new_Account_Id;
	
--Social Form: Treatment Staff:

	--Affiliation
	EXEC [KYPEnrollment].[sp_Copy_Affiliarion]@new_Account_Id,@party_Id,@last_Action_User_ID ,'Affiliation',@application_no,@application_Id;
    
    --Counselors:
    
    EXEC @new_party_counselor = [KYPEnrollment].[sp_Copy_Party_Counselor] @Party_id,@new_Party_Id,@new_Account_Id,@last_Action_User_ID;
    EXEC [KYPEnrollment].[sp_Copy_Personal_Inf_Identification] @new_party_counselor, @party_Id,@last_Action_User_ID;
    EXEC [KYPEnrollment].[sp_Copy_Provider] @new_party_counselor,@party_Id,@last_Action_User_ID;       
       
        


	/*BizProfile Details*/
	-- DISABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,@new_Account_Id,@new_Party_Id,@last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';
	-- ENABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	
	
	
	
	


	/* Prof. Licenses Certificates*/
	EXEC [KYPEnrollment].[sp_Copy_Dea] @new_Party_Id, @party_Id, @last_action_user_id, NULL;
	EXEC [KYPEnrollment].[sp_Copy_Clia] @new_Party_Id, @party_Id, @last_action_user_id, NULL;

	EXEC [KYPEnrollment].[sp_detect_HDP] @new_Party_Id,@last_Action_User_ID,@application_Id,'HDP','051';



	SELECT @npi_Type = NPIType FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id, @party_Id, 0, @provider_type_code, @account_number, NULL,'F',@application_Id,1,@application_type;


END


GO

