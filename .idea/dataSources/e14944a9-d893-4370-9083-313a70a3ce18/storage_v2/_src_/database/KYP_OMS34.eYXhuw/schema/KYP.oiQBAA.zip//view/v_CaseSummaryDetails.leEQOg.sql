





CREATE VIEW [KYP].[v_CaseSummaryDetails] AS
SELECT DISTINCT CONVERT(VARCHAR,C.CaseID) AS CaseID,
      CONVERT(VARCHAR,C.PortalCaseID) AS PortalCaseID,
      CONVERT(VARCHAR,C.AccountID ) AS AccountID,     
C.MILESTONE,(CONVERT(VARCHAR(20), M.CurrentMilestoneStep) + ' out of ' + CONVERT(VARCHAR(20), M.TotalMilestoneStep) + ' completed') AS 'CompletedTasks',CONVERT(VARCHAR,C.DAYS_REMAINING)  AS DAYS_REMAINING, 
CONVERT(VARCHAR(12), GETDATE(), 107) AS PDate, 
CASE WHEN C.THRESHOLD = 'Normal' OR C.THRESHOLD = 'RTPNormal'  THEN 'rgb(112,173,71)'
      WHEN C.THRESHOLD = 'Warning' OR  C.THRESHOLD = 'RTPWarning' THEN '#FFA500'
      WHEN C.THRESHOLD = 'Critical' OR C.THRESHOLD = 'RTPCritical' THEN '#FF0000'
      WHEN C.THRESHOLD = 'Overdue' OR  C.THRESHOLD = 'RTPOverDue' THEN '#800000'
      ELSE '#ffffff;' END AS DayRmBGColor,
CASE WHEN C.THRESHOLD = 'Normal' OR C.THRESHOLD = 'RTPNormal' OR C.THRESHOLD = 'Warning' OR  C.THRESHOLD = 'RTPWarning' 
            OR C.THRESHOLD = 'Critical' OR C.THRESHOLD = 'RTPCritical' OR C.THRESHOLD = 'Overdue' OR  C.THRESHOLD = 'RTPOverDue' THEN 'white' 
       ELSE 'black' END AS DayRmForeColor,
      ISNULL(CONVERT(VARCHAR,C.CompositeRisk),'NA') AS CompositeRisk,C.ProviderName,C.Number,ISNULL(CONVERT(VARCHAR,C.Provider_NPI),'NA') AS NPI,ISNULL(C.AccountNo,'-') As AccountNo,C.P_PRACT_TY_CD As PracticeType,C.TypeDescription AS ProviderType,
CASE WHEN C.Priority = 3 THEN 'High'
      WHEN C.Priority = 2 THEN 'Moderate'
      ELSE 'Limited' END AS ScreeningLevel,
CASE WHEN C.Priority = 3 THEN 'red-flag.png'
      WHEN C.Priority = 2 THEN 'yellow-flag.png'
      ELSE 'green-flag.png' END AS ScrLevelFlag,     
      U.FullName As CurrentlyAssignedToName,
      convert(varchar(10), cast(C.DateReceived as date), 101) As DateReceived,     
       C.ApplnTypeAlias As ApplicationType,
      convert(varchar(10), cast(C.DueDate as date), 101) As DueDate,
      ISNULL(N.ResolutionType,'-') as ResolutionStatus,
CASE WHEN N.ResolutionType = 'Referred-Licensing and Certification (L&C)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Enrolled/Provisional Status Granted' THEN 'rgb(29, 204, 6);'
      WHEN N.ResolutionType = 'NPI Change' THEN 'rgb(29, 204, 6);'
      WHEN N.ResolutionType = 'Denied' THEN 'rgb(255, 0, 0);'
      WHEN N.ResolutionType = 'Referred-Office of Legal Services (OLS)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Deficiency Notice Sent' THEN 'rgb(255, 174, 0);'
      WHEN N.ResolutionType = 'Referred-Audits and Investigations (A&I)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Benefits Division' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Lab Field Services' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Other' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Pharmacy' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Appeals and Exclusions' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Behavioral Health' THEN 'rgb(0, 0, 255);' 
      WHEN N.ResolutionType = 'Referred-Children Services' THEN 'rgb(0, 0, 255);' 
      WHEN N.ResolutionType = 'Referred-Dental, Clinics and Laboratory Services (DDCLS)' THEN 'rgb(0, 0, 255);' 
      WHEN N.ResolutionType = 'Referred-Moderate Risk Site Visit Unit' THEN 'rgb(0, 0, 255);' 
      WHEN N.ResolutionType = 'Referred-DDA Services Providers' THEN 'rgb(0, 0, 255);' 
      WHEN N.ResolutionType = 'Referred-Provider Compliance' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Institutional Long Term Care(ILTC)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Nursing, Transportation and Waivers(NTW)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Community Long Term Care(CLTC)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-Health Choice & Acute Care(HCAC)' THEN 'rgb(0, 0, 255);'
      WHEN N.ResolutionType = 'Referred-AHS Pending' THEN 'rgb(0, 0, 255);'     
      WHEN N.ResolutionType = 'Review Cancelled - Close as duplicate' THEN 'rgb(255, 128, 0);'
      WHEN N.ResolutionType = 'Closed as Duplicate' THEN 'rgb(255, 128, 0);'
      WHEN N.ResolutionType = 'Approve' THEN 'rgb(29, 204, 6);'
      WHEN N.ResolutionType = 'Approved' THEN 'rgb(29, 204, 6);'
      WHEN N.ResolutionType = 'Close without account update' THEN 'rgb(255, 174, 0);'
      WHEN N.ResolutionType = 'Dis-Enrolled by Provider' THEN 'rgb(128, 128, 128);'
      WHEN N.ResolutionType = 'Review Cancelled - Application Withdrawn' THEN 'rgb(0, 128, 128);' 
       WHEN N.ResolutionType = 'Ignored' THEN 'rgb(255, 174, 0);'
      WHEN N.ResolutionType = 'Referred' THEN 'rgb(0, 0, 255);'
       WHEN N.ResolutionType = 'Exempt' THEN 'rgb(29, 204, 6);' 
	  WHEN N.ResolutionType = 'Reject' THEN 'rgb(255, 0, 0);'   
       ELSE '#FFFFFF;' END As RSBGColor,
       isnull(convert(varchar,kyp.fn_alldatafindings(c.caseid,C.PortalCaseID,'EXTERNAL')),'0') as ExtFinding,
       --ISNULL(CONVERT(VARCHAR,(SELECT COUNT(ViewID) FROM KYPEnrollment.view_AllDataFindings where (caseIDFinding = C.CaseID OR caseIDFinding = C.PortalCaseID)  AND isexternaldesc = 'EXTERNAL'  GROUP BY isexternaldesc)),'0')  As ExtFinding,
       isnull(convert(varchar,kyp.fn_alldatafindings(c.caseid,C.PortalCaseID,'INTERNAL')),'0') as intFinding,
       --ISNULL(CONVERT(VARCHAR,(SELECT COUNT(ViewID) FROM KYPEnrollment.view_AllDataFindings where (caseIDFinding = C.CaseID OR caseIDFinding = C.PortalCaseID) AND isexternaldesc = 'INTERNAL'  GROUP BY isexternaldesc)),'0')  As IntFinding, 
       L.License,
      Case when iSNULL(S.AddressLine1,'') !='' and ISNULL(S.AddressLine2,'') !='' then 
        S.AddressLine1 + ','+S.AddressLine2 
        when iSNULL(S.AddressLine1,'') !='' and ISNULL(S.AddressLine2,'') ='' 
        then S.AddressLine1
        when ISNULL(S.AddressLine1,'') =''
        then 'Not Exist'
        End As AddressLine1,
      S.City+ ',' As City,
      --S.State,
     -- LS.Abreviation [State],  
		S.statecode [State],	 
       S.ZipPlus4+isnull(' '+S.County,'') as Zip,
      C.SupUpdateFlag as ServiceAddress,
      ISNULL(CONVERT(VARCHAR,R.RedFlag),'0') AS RedFlag
      ,ISNULL(CONVERT(VARCHAR,(SELECT cNegative FROM KYP.v_SumofNegChkResult where ApplicationID = A.ApplicationID )),'0')  As CountOfNegative,
      ISNULL(CONVERT(VARCHAR,(SELECT cPositive FROM KYP.v_SumofTrueChkResult where ApplicationID = A.ApplicationID )),'0')  As CountOfPositive,
      ISNULL( X.LegacyAccountNo,'-') As LegacyAccountNo,
      --For CaseSummary Report KEN-15602  
      CASE WHEN ISNULL(C.CrossOverApp,'N') = 'X' THEN 'Y' ELSE 'N' END As CrossOverApp,
      CASE WHEN ISNULL(C.IsMoratoria,0) = 1 THEN 'Y' ELSE 'N' END As Moratorium,
      CASE WHEN ISNULL(C.IsTribalAppln,0) = 1 THEN 'Y' ELSE 'N' END As TribalAppln,
      CASE WHEN ISNULL(CE.IsExempt,0) = 1 THEN 'Y' ELSE 'N' END As IsExempt 
      
FROM KYP.ADM_Case C INNER JOIN KYP.ADM_Application A ON C.CaseID = A.CaseID
LEFT JOIN KYP.ADM_CaseExtended CE ON C.CaseID = CE.CaseID 
 INNER JOIN KYP.OIS_EntityCount M ON C.CaseID = M.CaseID AND C.IsPPURequired = 0
LEFT JOIN KYP.v_LicenseConcenate L ON L.ApplicationID = A.ApplicationID 
 --LEFT JOIN (Select EnrollCaseId,Max(AID) AID From KYPEnrollment.PortalAddress
  --                Where Type = 'Servicing'
   --               Group by EnrollCaseID) S1 ON S1.EnrollCaseID = C.CaseID
--Left Join KYPEnrollment.PortalAddress S on S1.AID = S.AID 
Left Join [KYP].[View_AllAddresses] S on s.ApplicationNo = c.Number and S.Type='Servicing' 
LEFT JOIN KYP.v_TotalRedFlags R ON R.ApplicationID = A.ApplicationID 
 LEFT JOIN KYP.OIS_User U ON C.CurrentlyAssignedToID  = U.PersonID  
 LEFT JOIN KYPEnrollment.pADM_Account X ON X.AccountNumber = C.AccountNo
LEFT JOIN KYP.SDM_Resolution N ON N.ApplicationID = A.ApplicationID AND N.ResolutionID IN (
  Select TOP 1 ResolutionID FROM KYP.SDM_Resolution Z WHERE Z.ApplicationID = A.ApplicationID AND Z.IsDeleted = 0 Order by 1 desc)
   -- Left Join KYP.LK_Screening LS ON LS.Description=S.State and LS.TypeID=4


GO

