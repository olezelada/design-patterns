CREATE VIEW [KYP].[v_EDIFileForNMProvider]
AS


SELECT 
B.ProvNumber AS 'PROV_NUM',
CASE WHEN A.Type = 'Person' THEN
	(SELECT FirstName FROM KYP.PDM_Person WHERE PartyID = A.PartyID)
END AS 'PROV_FNAME',
CASE WHEN A.Type = 'Person' THEN
	(SELECT LastName FROM KYP.PDM_Person WHERE PartyID = A.PartyID)
END AS 'PROV_LNAME',
CASE WHEN A.Type = 'Person' THEN
	(SELECT MiddleName FROM KYP.PDM_Person WHERE PartyID = A.PartyID)
END AS 'PROV_MNAME',
CASE
	WHEN A.Type = 'Organization' THEN A.Name
	ELSE NULL
END AS 'ORG_NAME',
CASE
	WHEN A.Type = 'Organization' 
		THEN (SELECT NPI FROM KYP.PDM_Organization WHERE PartyID = A.PartyID)
	WHEN A.Type = 'Person' 
		THEN (SELECT NPI FROM KYP.PDM_Person WHERE PartyID = A.PartyID)
END AS 'PROV_NPI',
CASE WHEN A.Type = 'Person' 
	THEN (SELECT DoB FROM KYP.PDM_Person WHERE PartyID = A.PartyID)
END AS 'PROV_DOB',

(SELECT TOP 1 Addr.AddressLine1 FROM KYP.PDM_Location Loc
	INNER JOIN KYP.PDM_Address Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.PartyID = A.PartyID
	ORDER BY Addr.AddressID DESC
) AS 'PROV_ADDR1',

(SELECT TOP 1 Addr.City FROM KYP.PDM_Location Loc
	INNER JOIN KYP.PDM_Address Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.PartyID = A.PartyID
	ORDER BY Addr.AddressID DESC
) AS 'PROV_CITY',

(SELECT TOP 1 Addr.State FROM KYP.PDM_Location Loc
	INNER JOIN KYP.PDM_Address Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.PartyID = A.PartyID
	ORDER BY Addr.AddressID DESC
) AS 'PROV_STATE',

(SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert 
 WHERE WatchedPartyID = A.PartyID 
 AND MedicaidID = B.ProvNumber
 ORDER BY MatchPercent DESC) AS 'MCH_PER',
 
(SELECT TOP 1 DateInitiated FROM KYP.MDM_Alert
 WHERE WatchedPartyID = A.PartyID
 ORDER BY MatchPercent DESC) AS 'DATE_REC', 
 
(SELECT TOP 1 WatchlistName FROM KYP.MDM_Alert
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_LIST',

(SELECT TOP 1 FName FROM KYP.MDM_AlertDetail AlrtDet 
INNER JOIN KYP.MDM_Alert Alrt ON AlrtDet.AlertID = Alrt.AlertID
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_PROV_FNAME',

(SELECT TOP 1 LName FROM KYP.MDM_AlertDetail AlrtDet 
INNER JOIN KYP.MDM_Alert Alrt ON AlrtDet.AlertID = Alrt.AlertID
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_PROV_LNAME',

(SELECT TOP 1 MName FROM KYP.MDM_AlertDetail AlrtDet 
INNER JOIN KYP.MDM_Alert Alrt ON AlrtDet.AlertID = Alrt.AlertID
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_PROV_MNAME',

(SELECT TOP 1 OrganizationName FROM KYP.MDM_AlertDetail AlrtDet 
INNER JOIN KYP.MDM_Alert Alrt ON AlrtDet.AlertID = Alrt.AlertID
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_ORG_NAME',

(SELECT TOP 1 DOB FROM KYP.MDM_AlertDetail AlrtDet 
INNER JOIN KYP.MDM_Alert Alrt ON AlrtDet.AlertID = Alrt.AlertID
 WHERE WatchedPartyID = A.PartyID AND
 MatchPercent = (SELECT TOP 1 MatchPercent FROM KYP.MDM_Alert
						WHERE WatchedPartyID = A.PartyID ORDER BY MatchPercent DESC)
) AS 'WCH_DOB',


(SELECT TOP 1 Addr.AddressLine1 FROM KYP.MDM_AlertExtnLocation Loc
	INNER JOIN KYP.MDM_AlertExtnAddress Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.AlertID IN (SELECT AlertID FROM KYP.MDM_Alert WHERE WatchedPartyID = A.PartyID)
	ORDER BY Addr.AddressID DESC
) AS 'WCH_ADDR1',

(SELECT TOP 1 Addr.City FROM KYP.MDM_AlertExtnLocation Loc
	INNER JOIN KYP.MDM_AlertExtnAddress Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.AlertID IN (SELECT AlertID FROM KYP.MDM_Alert WHERE WatchedPartyID = A.PartyID)
	ORDER BY Addr.AddressID DESC
) AS 'WCH_CITY',


(SELECT TOP 1 Addr.State FROM KYP.MDM_AlertExtnLocation Loc
	INNER JOIN KYP.MDM_AlertExtnAddress Addr 
	ON Addr.AddressID = Loc.AddressID 
	WHERE Loc.AlertID IN (SELECT AlertID FROM KYP.MDM_Alert WHERE WatchedPartyID = A.PartyID)
	ORDER BY Addr.AddressID DESC
) AS 'WCH_STATE'


FROM KYP.PDM_Party A
INNER JOIN KYP.PDM_Provider B ON A.PartyID = B.PartyID
WHERE A.IsDeleted <> 1
AND B.IsDeleted <> 1


GO

