






--select PrevStatusCodeNumber, * from kyp.adm_case where caseid=276  order by  1desc 
--execute [KYP].[sp_WFBulkTeamDecline]	
--execute [KYP].[sp_WFBulkTeamDecline] 276

CREATE PROCEDURE [KYP].[sp_WFBulkDecline]
	-- Add the parameters for the stored procedure here
	@CaseID VARCHAR(100)
	,@Note VARCHAR(MAX)
	,@isMessageEnable VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ProviderName VARCHAR(100)
		,@PreviousUserID VARCHAR(100)
		,@PrevioueUserFullName VARCHAR(100)
		,@CurrentlyAssigneToRole VARCHAR(100)
		,@CurrentUserID VARCHAR(100)
		,@MessageID VARCHAR(100)
		,@PartyName VARCHAR(100)
		,@EntityID VARCHAR(100)
		,@EntityName VARCHAR(100)
		,@Description VARCHAR(500)
		,@UserSend VARCHAR(100)
		,@Subject VARCHAR(500)
		,@RelatedEntityType VARCHAR(100)
		,@CC VARCHAR(100)
		,@CurrentMinorDisposition VARCHAR(100)
		,@WFStatus VARCHAR(100)
		,@WFMajorStep VARCHAR(100)
		,@WFMinorStep VARCHAR(100)
		,@isEmailEnable INT
		,@UserID VARCHAR(100)
		,@UserFullName VARCHAR(100)
		,@Content VARCHAR(500)
		,@D_DateTime DATETIME
		,@Provider_NPI VARCHAR(100)
		,@Group_NPI VARCHAR(100)
		,@MajorStatus VARCHAR(100)
		,@MinorStatus VARCHAR(100)
		,@ApplicationNo VARCHAR(15)
		,@group_providerNumber VARCHAR(15)
		,@WFActivityStep int
		,@ProcessName VARCHAR(100)
		,@D_MajorDispositionStatus  VARCHAR(100)
		,@MajorStepID VARCHAR(100)
		,@PersonID INT
		,@InternalAppStatus bit
		,@Assignee VARCHAR(100);
	--	,@Note VARCHAR(MAX);
	SELECT @UserID = CurrentlyAssignedToName
		,@CurrentlyAssigneToRole = CurrentlyAssignedToRole
		,@Provider_NPI = Provider_NPI
		,@Group_NPI = Group_NPI
		,@ApplicationNo = Number
		,@WFActivityStep = WFActivityStep
		,@InternalAppStatus = InternalAppStatus
	FROM KYP.ADM_CASE
	WHERE CaseID = @CaseID

	SELECT @UserFullName = FullName
	FROM KYP.OIS_User
	WHERE UserID = @UserID
	
	SELECT @group_providerNumber = group_providerNumber
	FROM KYPPortal.PortalKYP.pRenderingAffiliation
	WHERE group_providerNumber = @ApplicationNo
		OR rendering_providerNumber = @ApplicationNo
		
	SELECT @UserFullName = FullName
		,@PersonID = PersonID
	FROM KYP.OIS_User
	WHERE UserID = @UserID
	
	SELECT @Assignee=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT AssignedFromID FROM kyp.ADM_Case WHERE CaseID=@CaseID);
	

	SET @D_DateTime = GETDATE();

	IF (@CurrentlyAssigneToRole = 'Reviewer' AND  @WFActivityStep != 200)
	BEGIN
		SET @CurrentMinorDisposition = 'Provider Check'
		SET @WFStatus = 'Pending Initial Assignment'
		SET @WFMajorStep = 'Pending Initial Assignment'
		SET @WFMinorStep = 'Unassigned'
		SET @MajorStatus = 'Assign application'
		SET @MinorStatus = 'Assign application'
		SET @Description = 'Automated Screening Completed'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Confirmer' AND  @WFActivityStep != 200 )
	BEGIN
		SET @CurrentMinorDisposition = 'Accepts or Declines Assignment'
		SET @WFStatus = 'Accept Assignment'
		SET @WFMajorStep = 'Accept Assignment'
		SET @WFMinorStep = 'Proposed Approval'
		SET @MajorStatus = 'Pending Confirmer Assignment'
		SET @MinorStatus = 'Assign application'
		SET @Description = 'Proposed Approval'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Approver' AND  @WFActivityStep != 200 )
	BEGIN
		SET @CurrentMinorDisposition = 'Accepts or Declines Assignment'
		SET @WFStatus = 'Accept Assignment'
		SET @WFMajorStep = 'Accept Assignment'
		SET @WFMinorStep = 'Proposed Approval'
		SET @MajorStatus = 'Pending Approver Assignment'
		SET @MinorStatus = 'Assign application'
		SET @Description = 'Proposed Denial/ Proposed Denial and Debarment'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Referrer' AND  @WFActivityStep != 200)
	BEGIN
		SET @CurrentMinorDisposition = 'Referred'
		SET @WFStatus = 'Accept Assignment'
		SET @WFMajorStep = 'Accept Assignment'
		SET @WFMinorStep = 'Proposed Approval'
		SET @MajorStatus = 'Pending Approver Assignment'
		SET @MinorStatus = 'Assign application'
		SET @Description = 'Proposed Denial/ Proposed Denial and Debarment'
	END
	ELSE IF (@WFActivityStep = 200)
	BEGIN
		SET @ProcessName = 'Resolution'
		SET @D_MajorDispositionStatus = 'Assign Application'
		SET @Description = 'Assigned'
		SET @MajorStepID = '2'
	END
	ELSE IF (@WFActivityStep = 200)
	BEGIN
		SET @ProcessName = 'ResolutionConf'
		SET @D_MajorDispositionStatus = 'Assign Application'
		SET @Description = 'Proposed Resolution'
		SET @MajorStepID = '4'
	END
	ELSE IF (@WFActivityStep = 200)
	BEGIN
		SET @ProcessName = 'ResolutionConf'
		SET @D_MajorDispositionStatus = 'Assign Application'
		SET @Description = 'Proposed Resolution'
		SET @MajorStepID = '5'
	END
	
	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,'2'
		,@D_DateTime
		,@UserID
		,@UserFullName
		,@Description
		,NULL
		,'Accept Assignment'
		,NULL
		,'Declined'
		,NULL
		,@D_DateTime
		,0
		,'HISTORY'
		,DATEADD(SS, 2, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_CASE
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'

	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'Completed'
		,UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL(DATETIME, GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 4, @D_DateTime)
		,Assignee=@Assignee
	WHERE ActivityStatus = 'In Progress'
		AND CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				--AND CurrentMinorDisposition <> 'Referred'
			)

	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,1
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,NULL
		,@MajorStatus
		,@MinorStatus
		,'In Progress'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 6, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_CASE
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'

	UPDATE X
	SET CurrentMinorDisposition = @CurrentMinorDisposition
		,CurrentlyAssignedToID = 'UserR' -- OU.UserID ken-13206
	FROM KYP.DSH_DashBoardTable X
	INNER JOIN KYP.ADM_CASE AC ON X.CaseID = AC.CaseID
	INNER JOIN KYP.OIS_User OU ON AC.ASSIGNED_BY_NAME = OU.FullName
	WHERE X.CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_CASE AC
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND AC.IsPPURequired <> 1
				AND AC.CurrentMinorDisposition <> 'Escalate'
				AND AC.CurrentMinorDisposition <> 'Consult'
				--AND AC.CurrentMinorDisposition <> 'Referred'
			)

	UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application]
	SET IsReviewStatus = 1
	WHERE (
			IsReviewStatus = 0
			OR IsReviewStatus IS NULL
			)
		AND ApplicationNo IN (
			SELECT Number
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				--AND CurrentMinorDisposition <> 'Referred'
			)
    IF(@InternalAppStatus = 1)
    BEGIN
	UPDATE X
	SET StatusCodeNumber = '8'
		,STATUS = 'Decline'
		,CurrentlyAssignedToID = X.AssignedFromID
		,CurrentlyAssignedToName = (
			SELECT UserID
			FROM KYP.OIS_User
			WHERE PersonID = X.AssignedFromID
			)
		,CurrentMinorDisposition = @CurrentMinorDisposition
		,WFStatus = @WFStatus
		,WFMajorStep = @WFMajorStep
		,WFMinorStep = @WFMinorStep
		,GenNo = 0
		,ASSIGNED_BY_NAME = @UserFullName
		,ASSIGN_BY_ID = 'System(Auto)'
		,CaseSource = NULL
	FROM KYP.ADM_CASE X
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
	END
	
ElSE
BEGIN
UPDATE X
	SET StatusCodeNumber = '10'
		,STATUS = 'Decline'
		,CurrentlyAssignedToID = X.AssignedFromID
		,CurrentlyAssignedToName = (
			SELECT UserID
			FROM KYP.OIS_User
			WHERE PersonID = X.AssignedFromID
			)
		,CurrentMinorDisposition = @CurrentMinorDisposition
		,WFStatus = @WFStatus
		,WFMajorStep = @WFMajorStep
		,WFMinorStep = @WFMinorStep
		,InternalAppStatus = 0
		,ASSIGNED_BY_NAME = @UserFullName
		,ASSIGN_BY_ID = @Assignee
		,UserFullName = @Assignee
		,CaseSource = NULL
	FROM KYP.ADM_CASE X
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND CurrentlyAssignedToName = @UserID
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
END	
		
		INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,'2'
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,NULL
		,'Declined'
		,NULL
		,'Declined'
		,NULL
		,@D_DateTime
		,0
		,'HISTORY'
		,@D_DateTime
		,@Assignee
	FROM KYP.ADM_Case	
	WHERE (	Number = @group_providerNumber
			OR Number IN (SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
						  )
			)	
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=9
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		
		
		
	


INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,2
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,'Declined'
		,NULL
		,'Declined'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 8, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE( Number = @group_providerNumber
			OR Number IN (SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
						 )
		)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=10
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		
	
	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'Completed'
		,UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 6, @D_DateTime)
		,Assignee=@Assignee
	WHERE 
		ActivityStatus = 'In Progress'
		AND CaseID IN(	SELECT CaseID FROM KYP.ADM_Case
						WHERE( Number = @group_providerNumber
							   OR Number IN (SELECT rendering_providerNumber FROM KYPPortal.PortalKYP.pRenderingAffiliation
												WHERE group_providerNumber = @group_providerNumber
											)
								)
						AND StatusCodeNumber = 9
						AND PrevStatusCodeNumber=9
						AND (WFActivityStep <> 100
						OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
						AND CurrentlyAssignedToName = @UserID
						AND IsPPURequired <> 1
						AND CurrentMinorDisposition <> 'Escalate'
						AND CurrentMinorDisposition <> 'Consult'
						)
		
	UPDATE KYP.ADM_WorkflowHistory
	SET 
		 UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 9, @D_DateTime)
		,Assignee=@Assignee
	WHERE 
		ActivityStatus = 'In Progress'
		AND CaseID IN(	SELECT CaseID FROM KYP.ADM_Case
						WHERE( Number = @group_providerNumber
							   OR Number IN (SELECT rendering_providerNumber FROM KYPPortal.PortalKYP.pRenderingAffiliation
												WHERE group_providerNumber = @group_providerNumber
											)
								)
						AND StatusCodeNumber = 9
						AND PrevStatusCodeNumber=10
						AND (WFActivityStep <> 100
						OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
						AND CurrentlyAssignedToName = @UserID
						AND IsPPURequired <> 1
						AND CurrentMinorDisposition <> 'Escalate'
						AND CurrentMinorDisposition <> 'Consult'
						
						
						
					)
					
		
	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,1
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,@D_MajorDispositionStatus
		,@D_MajorDispositionStatus
		,'In Progress'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 8, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE	(Number = @group_providerNumber
			OR Number IN (	SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
							)
			)
			AND StatusCodeNumber = 9
			AND PrevStatusCodeNumber=9
			AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
END


GO

