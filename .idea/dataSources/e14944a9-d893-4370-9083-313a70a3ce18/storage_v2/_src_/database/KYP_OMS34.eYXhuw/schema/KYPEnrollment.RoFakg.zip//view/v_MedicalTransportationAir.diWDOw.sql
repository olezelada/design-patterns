
CREATE VIEW [KYPEnrollment].[v_MedicalTransportationAir]
AS

		select 
		A.ParentPartyid,A.PartyID,C.AddressID,C.LocationID,B.VehicleSubType,B.CertificationNumber,B.IssueDate,B.VehicleType,C.Name,
		D.AddressLine1+ case when isnull(D.AddressLine2,'')='' then '' else +','+D.AddressLine2 end
		+','+D.City+','+D.State+','+D.ZipPlus4+','+D.County as Address

		from KYPEnrollment.pAccount_PDM_Party A
		inner join KYPEnrollment.pAccount_PDM_vehicle B on A.PartyID=B.PartyId
		inner join KYPEnrollment.pAccount_PDM_Location C on C.PartyId=B.Partyid 
		inner join KYPEnrollment.pAccount_PDM_Address D on D.AddressID=C.AddressID
		where B.VehicleType='Aircraft' and B.IsDeleted=0 and B.CurrentRecordFlag=1


GO

