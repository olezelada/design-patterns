
CREATE PROCEDURE [KYPEnrollment].[Update_Crossover_Indicator]
@account_id INT,
@isCrossoverFlag BIT

AS
  BEGIN
    PRINT 'Update IsCrossover Flag Indicator'
    UPDATE KYPEnrollment.pADM_Account set IsCrossover = @isCrossoverFlag WHERE AccountID = @account_id
  END


GO

