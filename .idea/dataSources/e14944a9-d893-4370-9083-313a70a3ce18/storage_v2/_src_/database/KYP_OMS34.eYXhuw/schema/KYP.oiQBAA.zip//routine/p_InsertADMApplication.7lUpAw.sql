


/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMApplication]
(@CaseID int
 ,@AppProvID int= NULL
 ,@ApplicationNo varchar(15) =NULL
 ,@Type varchar(15) = NULL
 ,@Remarks varchar(250)=NULL
 ,@Source varchar(25)=NULL
 ,@Status varchar(15)=NULL
 ,@RiskCategory varchar(15)=NULL
 ,@AutoRisk int=NULL
 ,@EDDRisk int=NULL
 ,@CompositeRisk int=NULL
 ,@DateSubmitted smalldatetime=NULL
 ,@DateReviewed smalldatetime=NULL
 ,@DateScreened smalldatetime=NULL
 ,@DateCompleted smalldatetime=NULL
 ,@ReviewedBy int=NULL
 ,@ScreenedBy int=NULL
 ,@CompletedBy int=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@ScreeningReminderDate datetime=NULL
 ,@CrossOverApp varchar(10) = NULL
 ,@FeeRequired bit=0
 ,@FeePaid bit=0
 ,@FeeExempted bit=0
 ,@MDCToMDL varchar(10) = 0
 ,@MDLToMDC varchar(10) = 0
 ,@FeeConfirmation bit = NULL
)
as begin 
BEGIN TRY

INSERT INTO [KYP].[ADM_Application]
           ([CaseID]
           ,[AppProvID]
           ,[ApplicationNo]
           ,[Type]
           ,[Remarks]
           ,[Source]
           ,[Status]
           ,[RiskCategory]
           ,[AutoRisk]
           ,[EDDRisk]
           ,[CompositeRisk]
           ,[DateSubmitted]
           ,[DateReviewed]
           ,[DateScreened]
           ,[DateCompleted]
           ,[ReviewedBy]
           ,[ScreenedBy]
           ,[CompletedBy]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[ScreeningReminderDate]
           ,[CrossOverApp]
		   ,[FeeRequired]
		   ,[FeePaid]
		   ,[FeeExempted]
		   ,[MDCToMDL]
		   ,[MDLToMDC]
		   ,[FeeConfirmation]
           )
     VALUES
           (@CaseID
           ,@AppProvID
           ,@ApplicationNo
           ,@Type
           ,@Remarks
           ,@Source
           ,@Status
           ,@RiskCategory
           ,@AutoRisk
           ,@EDDRisk
           ,@CompositeRisk
           ,@DateSubmitted
           ,@DateReviewed
           ,@DateScreened
           ,@DateCompleted
           ,@ReviewedBy
           ,@ScreenedBy
           ,@CompletedBy
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@ScreeningReminderDate
           ,@CrossOverApp
			,@FeeRequired
			,@FeePaid
			,@FeeExempted
			,@MDCToMDL
			,@MDLToMDC
			,@FeeConfirmation
           )

	return IDENT_CURRENT('[KYP].[ADM_Application]');
END TRY
BEGIN CATCH	
	 IF @@TRANCOUNT > 0
	 ROLLBACK TRANSACTION 

	Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'ADM_Application:ApplicationNo',@KeyValue =@ApplicationNo
END CATCH	
end


GO

