
/* ==========================================================
-- Author:		<Ralba,Tjaldin>
-- PROCEDURE: 
-- PARAMETERS: 

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Create_TaxID_Associate]
@account_id INT,
@party_account_id INT,
@account_number INT,
@date_created DATE,
@taxid VARCHAR(10) = NULL,
@linked_account INT = NULL,
@entity_name VARCHAR(150)= NULL

AS
BEGIN
SET NOCOUNT ON 
PRINT'[Create_TaxID_Associate]'
INSERT INTO [KYPEnrollment].[pAccount_TaxID_Associate](
			 AccountID,
			 PartyID,
			 EntityID,
			 TaxID,
		--	 LinkedAccount,
		--	 EntityName,
		--	 CreatedOn,
			 CurrentRecordFlag
 )VALUES(
			 @account_id,
			 @party_account_id,
			 @account_number,
			 ISNULL(@taxid,''),
		--	 ISNULL(@linked_account,NULL),
		--	 ISNULL(@entity_name,''),
		--	 @date_created,
			 1
 )

END


GO

