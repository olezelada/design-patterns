




CREATE PROCEDURE [KYPEnrollment].[sp_Update_PaymentDetail]	
	@npi VARCHAR (10),
	@party_account_id INT,
	@application_id int
	
AS
BEGIN
--Update LastActorUserID on pAccount_PDM_PaymentDetail as "UserR" for Supplemental NR applications just if the previous value was "system"
	declare @SupUpdateFlag varchar(20)
	declare @application_type VARCHAR(50)
	declare @LastActorUserID varchar(100)
	declare @modif int
	set @modif=0
	set @LastActorUserID=''
	select @SupUpdateFlag =Supupdateflag,@application_type =app.ApplicationType  from kyp.ADM_CASE cas inner join kypportal.portalkyp.pADM_Application app on cas.Number=app.ApplicationNo where app.ApplicationID=@application_id 
	SELECT @LastActorUserID=isnull(LastActorUserID,'')  FROM  KYPEnrollment.pAccount_PDM_PaymentDetail	 WHERE PartyID = @party_account_id
	--if @application_type='Supplemental' and @SupUpdateFlag ='5A' and @LastActorUserID ='system'
	--include all types KPP8042
	if  @LastActorUserID ='system'
	begin
		update KYPEnrollment.pAccount_PDM_PaymentDetail set LastActorUserID ='UserR' where PartyID=@party_account_id
		--set @modif=1
	end
	
	
	
/*UPDATE PAYMENT*/	


IF EXISTS (SELECT [PaymentDetailID] FROM KYPEnrollment.pAccount_PDM_PaymentDetail  WHERE PartyID IN (SELECT PartyID FROM KYPEnrollment.pADM_Account WHERE NPI=@npi AND IsPastOwner=0) AND PartyID != @party_account_id)
BEGIN
   PRINT 'UPDATE PAYMENT'
	DECLARE @paymentDetail TABLE
	 (           ID INT IDENTITY(1,1)
			   ,[PartyID] INT 
			   ,[TypeOfPayment] VARCHAR(40)
			   ,[BankpAccountNumber] VARCHAR(100)
			   ,[RoutingNumber] VARCHAR(30)
			   ,[BankName] VARCHAR(100)
			   ,[StreetName] VARCHAR(100)
			   ,[City] VARCHAR(100)
			   ,[ZipPlus4] VARCHAR(30)
			   ,[County] VARCHAR(100)
			   ,[StateTrans] VARCHAR(100)
			   ,[ProviderName]VARCHAR(300)
			   ,[ProviderContact] VARCHAR(50)
			   ,[ReasonForSubmission] VARCHAR (25)
               ,[LastAction] VARCHAR (1) NULL
               ,[LastActionDate] SMALLDATETIME NULL
               ,[Temp_EFT_Indicator]     VARCHAR (1) NULL
               
	 )
	 INSERT INTO @paymentDetail 
	 SELECT [PartyID] 
			   ,[TypeOfPayment]
			   ,[BankpAccountNumber] 
			   ,[RoutingNumber] 
			   ,[BankName] 
			   ,[StreetName] 
			   ,[City] 
			   ,[ZipPlus4] 
			   ,[County] 
			   ,[StateTrans] 
			   ,[ProviderName]
			   ,[ProviderContact] 
			   ,[ReasonForSubmission]
			   ,[LastAction]
               ,[LastActionDate]
               ,[Temp_EFT_Indicator]                    

	 FROM  KYPEnrollment.pAccount_PDM_PaymentDetail
	 WHERE PartyID = @party_account_id
	
		 UPDATE paymentA SET paymentA.[TypeOfPayment] = paymentDetail.[TypeOfPayment]
				   ,paymentA.[BankpAccountNumber] = paymentDetail.[BankpAccountNumber]
				   ,paymentA.[RoutingNumber] = paymentDetail.[RoutingNumber]
				   ,paymentA.[BankName] = paymentDetail.[BankName]
				   ,paymentA.[StreetName] = paymentDetail.[StreetName]
				   ,paymentA.[City] = paymentDetail.[City]
				   ,paymentA.[ZipPlus4] = paymentDetail.[ZipPlus4]
				   ,paymentA.[County] = paymentDetail.[County]
				   ,paymentA.[StateTrans] = paymentDetail.[StateTrans]
				   ,paymentA.[ProviderName]= paymentDetail.[ProviderName]
				   ,paymentA.[ProviderContact] = paymentDetail.[ProviderContact]
				   ,paymentA.[ReasonForSubmission] = paymentDetail.[ReasonForSubmission]
                   ,paymentA.[LastAction] = paymentDetail.[LastAction]
                   ,paymentA.[LastActionDate] = paymentDetail.[LastActionDate]
                   ,paymentA.[Temp_EFT_Indicator] = paymentDetail.[Temp_EFT_Indicator]
                   ,paymentA.[LastActorUserID]=CASE WHEN paymentA.[LastActorUserID]='system'  THEN 'UserR' ELSE [LastActorUserID] END

		 FROM KYPEnrollment.pAccount_PDM_PaymentDetail paymentA, @paymentDetail paymentDetail 
		 WHERE paymentA.PartyID IN (SELECT PartyID FROM KYPEnrollment.pADM_Account WHERE NPI=@npi AND IsPastOwner=0 AND PartyID != @party_account_id)
	
 END 
END


GO

