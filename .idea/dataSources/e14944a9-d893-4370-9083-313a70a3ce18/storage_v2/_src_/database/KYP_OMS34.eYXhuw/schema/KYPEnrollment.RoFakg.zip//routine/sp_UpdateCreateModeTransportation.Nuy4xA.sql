
/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: update Mode of Transportation.
-- PARAMETERS:
-- @new_account_id : accountId that was created.
-- @applicationCode : application code of the application.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_UpdateCreateModeTransportation] @new_account_id INT, @packageName VARCHAR (100), @main_app_number varchar(10),@main_app_npi varchar(10), @last_Action_User_ID VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON

IF ( @packageName IN ('FSP_MDT_IN', 'FSP_MDT_SP') AND @new_account_id IS NOT NULL )

  DECLARE @accountsTemp table (pk int identity(1,1),accID INT, accPartyId INT, providerCode VARCHAR (10))

  DECLARE @tot int,@cont int, @add int, @serviceAddress varchar (250),@ownerNo varchar(10),@serviceLocationNo varchar(10)

  SELECT @serviceAddress = PracticeAddress, @ownerNo = OwnerNo, @serviceLocationNo = ServiceLocationNo
  FROM KYPEnrollment.pADM_Account WHERE AccountID = @new_account_id

  INSERT INTO @accountsTemp (accID, accPartyId, providerCode)
	SELECT DISTINCT AccountID, PartyID, ProviderTypeCode
	FROM KYPEnrollment.pADM_Account
	WHERE(ApplicationNumber = @main_app_number OR NPI = @main_app_npi) AND PackageName = @packageName
		AND @serviceLocationNo = ServiceLocationNo AND IsPastOwner = 0 AND ((StatusAcc LIKE '1%' OR StatusAcc LIKE '7%') OR StatusAcc IS NULL)

    SELECT @tot =MAX(pk) from @accountsTemp
    SET @cont=1;

    WHILE @cont<=@tot
	    BEGIN
	      DECLARE @tempPartyId INT;
	      DECLARE @tempProCode INT;
	      SELECT @tempPartyId = accPartyId, @tempProCode = providerCode FROM @accountsTemp WHERE pk=@cont

	      IF('030' = @tempProCode)
	      BEGIN
	        EXEC [KYPEnrollment].[sp_UpdateCreateModeTranGround] @tempPartyId, @last_Action_User_ID;
	      END

	      IF('038' = @tempProCode)
	      BEGIN
	        EXEC [KYPEnrollment].[sp_UpdateCreateModeTranAir] @tempPartyId, @last_Action_User_ID;
	      END

	      SET @cont= @cont + 1
      END

  DELETE @accountsTemp;
END
GO

