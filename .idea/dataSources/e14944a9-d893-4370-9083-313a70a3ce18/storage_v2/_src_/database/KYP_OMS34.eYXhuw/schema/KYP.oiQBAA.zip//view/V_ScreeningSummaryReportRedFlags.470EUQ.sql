

CREATE VIEW [KYP].[V_ScreeningSummaryReportRedFlags] as
SELECT  row_number() OVER (ORDER BY Q.ScreeningID ASC) AS ID, *
FROM         
(

	SELECT 
	A.ScreeningID,
	A.FlagID,
	B.FlagType,
	B.Attribute,
	B.DisplayName,
	B.ToolTipText,
	B.Description,
	CASE WHEN B.Attribute = 'Address' THEN C.AddressLine1 +','+ C.city +','+C.state+','+C.zip ELSE C.AttributeValue END AttributeValue,        
	Z.Name, y.PartyType
	from KYP.PDM_Party as Z 
	right Join KYP.SDM_ApplicationParty as y on Z.PartyID=y.PartyID  
	right join KYP.SDM_RedFlag A on A.ScreeningID=y.ScreeningID
	INNER JOIN KYP.SDM_RedFlagDetails C ON A.RedFlagID = C.RedFlagID
	INNER JOIN KYP.LK_RedFlagConfiguration B ON A.FlagID = B.FlagID
	WHERE ISNULL(A.IsDeleted, 0) = 0 AND ISNULL(C.IsDeleted, 0) = 0
	
	)Q


GO

