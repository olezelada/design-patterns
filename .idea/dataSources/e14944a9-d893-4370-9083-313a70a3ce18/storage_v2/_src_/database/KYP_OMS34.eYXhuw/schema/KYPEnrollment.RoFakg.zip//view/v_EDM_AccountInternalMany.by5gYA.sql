
CREATE VIEW [KYPEnrollment].[v_EDM_AccountInternalMany]
AS
SELECT *
	,CASE ISNULL(CodeDescription, '')
		WHEN ''
			THEN CodeIdentification
		ELSE isnull(CodeIdentification,'') + ' - ' + CodeDescription
		END AS 'CodeDescriptionFull'
FROM KYPEnrollment.EDM_AccountInternalMany
where (isDeleted = 0 or isDeleted is null)


GO

