



CREATE PROCEDURE  [KYPEnrollment].[Clone_LinkedAccount]
  @account_id INT,
  @clone_account_id INT
AS
BEGIN

SET NOCOUNT ON 
INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
           ([AccountID]
           ,[LinkedWithAccountID]
           ,[LinkType]
           ,[LinkingEstabilishedBy]
           ,[LinkingCreatedByUserID]
           ,[LinkingRemarks]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
    SELECT  distinct
            @clone_account_id
           ,[LinkedWithAccountID]
           ,[LinkType]
           ,[LinkingEstabilishedBy]
           ,[LinkingCreatedByUserID]
           ,[LinkingRemarks]
           ,[LastAction]
           ,[LastActionDate]
           ,[LinkedAccountID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           FROM [KYPEnrollment].[pADM_LinkedAccount] WHERE AccountID = @account_id;
           
INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
           ([AccountID]
           ,[LinkedWithAccountID]
           ,[LinkType]
           ,[LinkingEstabilishedBy]
           ,[LinkingCreatedByUserID]
           ,[LinkingRemarks]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
    SELECT  distinct
            [AccountID]
           ,@clone_account_id
           ,[LinkType]
           ,[LinkingEstabilishedBy]
           ,[LinkingCreatedByUserID]
           ,[LinkingRemarks]
           ,[LastAction]
           ,[LastActionDate]
           ,[LinkedAccountID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           FROM [KYPEnrollment].[pADM_LinkedAccount] WHERE LinkedWithAccountID = @account_id;  
           
           
  INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
           ([Attribute]
           ,[Value]
           ,[LinkedAccountID])
     SELECT 
		   distinct --DBAB-83
		   [Attribute]
           ,[Value]
           ,linkAccount.[LinkedAccountID]
           FROM  [KYPEnrollment].[pADM_LinkedAccount] linkAccount,[KYPEnrollment].[pADM_LinkedAccountValue] linkValue
           WHERE linkValue.LinkedAccountID IN(SELECT LinkedAccountID FROM [KYPEnrollment].[pADM_LinkedAccount] WHERE LinkedWithAccountID = @account_id) AND (linkAccount.AccountID = @clone_account_id  OR linkAccount.LinkedWithAccountID =@clone_account_id);
 
                    
END


GO

