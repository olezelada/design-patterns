





CREATE VIEW [KYP].[view_InternalFindings]
AS

SELECT CONVERT(VARCHAR,E.findingID) AS ID,
	   CONVERT(VARCHAR,C.CaseID) AS CaseID,
	   CONVERT(VARCHAR,C.PortalCaseID) AS PortalCaseID,
	   E.titleFinding AS Title,	   
	   COALESCE(E.typeFinding,'') + COALESCE(('/'+E.ReasonCode),'') + COALESCE(('/'+
	   CASE WHEN E.isIgnoredMsg = 'Ignored' THEN 'Ignored' ELSE E.actionFinding END 
	   ),'') AS [Type_Reason_Action],
	   E.findingDescription  AS Description,
	   COALESCE(E.addedby,'') + COALESCE(('/ '+CONVERT(VARCHAR,E.addedon,101) + ' ' + RIGHT(CONVERT(CHAR(20), E.addedon, 22), 11)),'') AS [Addedby_on]
FROM KYPEnrollment.view_AllDataFindings E INNER JOIN KYP.ADM_Case C ON 
(E.caseIDFinding = C.CaseID AND E.category = 'SCREENING') OR 
(E.caseIDFinding = C.PortalCaseID AND E.category = 'APP REVIEW') 
WHERE  E.isexternaldesc = 'INTERNAL'


GO

