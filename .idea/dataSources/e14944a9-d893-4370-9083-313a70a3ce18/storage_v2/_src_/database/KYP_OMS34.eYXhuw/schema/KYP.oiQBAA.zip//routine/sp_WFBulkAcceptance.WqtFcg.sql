







CREATE PROCEDURE [KYP].[sp_WFBulkAcceptance]
	-- Add the parameters for the stored procedure here
	@CaseID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @D_DateTime DATETIME
		,@D_SortDateTime DATETIME
		,@RoleName VARCHAR(100)
		,@ProcessName VARCHAR(100)
		,@ActionName VARCHAR(100)
		,@D_MajorDispositionStatus VARCHAR(100)
		,@D_MajorDispStatus VARCHAR(100)
		,@UserID VARCHAR(100)
		,@Provider_NPI VARCHAR(100)
		,@UserFullName VARCHAR(100)
		,@CurrentlyAssigneToRole VARCHAR(100)
		,@Description VARCHAR(100)
		,@MajorStepID VARCHAR(100)
		,@PersonID INT
		,@Group_NPI VARCHAR(100)
		,@ApplicationNo VARCHAR(15)
		,@MILESTONE VARCHAR(20)
		,@group_providerNumber VARCHAR(15)
		,@InternalAppStatus bit
		,@Assignee VARCHAR(100);
    -- Try block
    BEGIN TRY
	SET @D_DateTime = GETDATE();
	SET @D_SortDateTime = DATEADD(SS, 2, @D_DateTime);

	SELECT @UserID = CurrentlyAssignedToName
		,@Provider_NPI = Provider_NPI
		,@CurrentlyAssigneToRole = CurrentlyAssignedToRole
		,@Group_NPI = Group_NPI
		,@ApplicationNo = Number
	FROM KYP.ADM_CASE
	WHERE CaseID = @CaseID

	SELECT @UserFullName = FullName
		,@PersonID = PersonID
	FROM KYP.OIS_User
	WHERE UserID = @UserID

	SELECT @group_providerNumber = group_providerNumber
	FROM KYPPortal.PortalKYP.pRenderingAffiliation
	WHERE group_providerNumber = @ApplicationNo
		OR rendering_providerNumber = @ApplicationNo
		
		SELECT @Assignee=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT CurrentlyAssignedToID FROM kyp.ADM_Case WHERE CaseID=@CaseID);

	IF (@CurrentlyAssigneToRole = 'Reviewer')
	BEGIN
		SET @ProcessName = 'Resolution'
		SET @D_MajorDispositionStatus = 'Review Application/Screening'
		SET @D_MajorDispStatus = 'Set resolution'
		SET @Description = 'Assigned'
		SET @MajorStepID = '2'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Confirmer')
	BEGIN
		SET @ProcessName = 'ResolutionConf'
		SET @D_MajorDispositionStatus = 'Set resolution'
		SET @Description = 'Proposed Resolution'
		SET @MajorStepID = '4'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Approver')
	BEGIN
		SET @ProcessName = 'ResolutionConf'
		SET @D_MajorDispositionStatus = 'Set resolution'
		SET @Description = 'Proposed Resolution'
		SET @MajorStepID = '5'
	END
	ELSE IF (@CurrentlyAssigneToRole = 'Referrer')
	BEGIN
		SET @ProcessName = 'ResolutionConf'
		SET @D_MajorDispositionStatus = 'Set resolution'
		SET @Description = 'Proposed Resolution'
		SET @MajorStepID = '2'
	END

	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,Assignee
		)
	SELECT CaseID
		,'2'
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,NULL
		,'Accept Assignment'
		,NULL
		,'Accepted'
		,NULL
		,@D_DateTime
		,0
		,'HISTORY'
		,@D_DateTime
		,@Assignee
	FROM KYP.ADM_Case
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'

	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'In Progress'
		,SortDateTime = DATEADD(SS, 4, @D_DateTime)
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), GETDATE())
		,Assignee=@Assignee
	WHERE ActivityStatus = 'In Progress'
		AND CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				--AND CurrentMinorDisposition <> 'Referred'
			)

	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'Completed'
		,UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 6, @D_DateTime)
		,Assignee=@Assignee
	WHERE ActivityStatus = 'In Progress'
		AND CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				--AND CurrentMinorDisposition <> 'Referred'
			)

	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,Assignee
		)
	SELECT CaseID
		,1
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,@D_MajorDispositionStatus
		,@D_MajorDispositionStatus
		,'In Progress'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 8, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'
		
		
	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'Completed'
		,SortDateTime = DATEADD(SS, 10, @D_DateTime)
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), GETDATE())
		,Assignee=@Assignee
	WHERE ActivityStatus = 'In Progress'
		AND CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				AND ApplnType ='Rendering-S'
				AND CurrentlyAssignedToRole ='Reviewer'
				--AND CurrentMinorDisposition <> 'Referred'
			)
INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,Assignee
		)
	SELECT CaseID
		,1
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,@D_MajorDispStatus
		,@D_MajorDispStatus
		,'In Progress'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 12, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND (WFActivityStep = 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND ApplnType ='Rendering-S'
		AND CurrentlyAssignedToRole ='Reviewer'
		
	UPDATE KYP.DSH_DashBoardTable
	SET CurrentMinorDisposition = 'Set resolution'
		,Statuscode = 1
	WHERE CaseID IN (
			SELECT CaseID
			FROM KYP.ADM_CASE AC
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND AC.IsPPURequired <> 1
				AND AC.CurrentMinorDisposition <> 'Escalate'
				AND AC.CurrentMinorDisposition <> 'Consult'
				--AND AC.CurrentMinorDisposition <> 'Referred'
			)

	UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application]
	SET IsReviewStatus = 1
	WHERE ApplicationNo IN (
			SELECT Number
			FROM KYP.ADM_Case
			WHERE (
					Number = @group_providerNumber
					OR Number IN (
						SELECT rendering_providerNumber
						FROM KYPPortal.PortalKYP.pRenderingAffiliation
						WHERE group_providerNumber = @group_providerNumber
						)
					)
				AND StatusCodeNumber = 9
				AND (WFActivityStep = 100
				OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
				AND CurrentlyAssignedToName = @UserID
				AND IsPPURequired <> 1
				AND CurrentMinorDisposition <> 'Escalate'
				AND CurrentMinorDisposition <> 'Consult'
				--AND CurrentMinorDisposition <> 'Referred'
			)

	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '10'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus=0
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND WFActivityStep = 100
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType <> 'Rendering-S'

	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '12'
		,GenNo = '12'
		,MajorStepID = @MajorStepID
		,MILESTONE = 'Application Reviewed'
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND WFActivityStep = 100
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType = 'Rendering-S'

	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,PrevStatusCodeNumber = StatusCodeNumber
		,WFMajorStep = 'Set resolution'
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND WFActivityStep = 100
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole <> 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND CurrentMinorDisposition <> 'Referred'
		
	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
	    ,GenNo='12'
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole <> 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		AND (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0)
		--UPDATE KYP.ADM_CASE
		--SET StatusCodeNumber = '10'
		--	,GenNo = '10'
		--	,WFActivityStep = '0'
		--	,PrevStatusCodeNumber = '10'
		--	,NewGenNo = '10'
		--	,CaseSource = NULL
		--WHERE (
		--		Group_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		OR Provider_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		)
		--	AND PrevStatusCodeNumber = 9
		--	AND StatusCodeNumber = 9
		--	AND WFActivityStep != 100
		--	AND CurrentlyAssignedToName = @UserID
		--	AND IsPPURequired <> 1
		--	AND CurrentlyAssignedToRole = 'Reviewer'
		--	AND CurrentMinorDisposition <> 'Escalate'
		--	AND CurrentMinorDisposition <> 'Consult'
		--	AND CurrentMinorDisposition <> 'Referred'
		--	AND (
		--		ApplnType = 'New Group'
		--		OR ApplnType = 'New Rendering'
		--		OR ApplnType = 'Rendering-S'
		--		OR (
		--			ApplnType = 'New'
		--			AND AffSupUpdateFlag = 'New Group'
		--			)
		--		)
		--UPDATE KYP.ADM_CASE
		--SET StatusCodeNumber = '10'
		--	,GenNo = NewGenNo
		--	,WFActivityStep = '0'
		--	,CaseSource = NULL
		--WHERE (
		--		Group_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		OR Provider_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		)
		--	AND PrevStatusCodeNumber != 9
		--	AND StatusCodeNumber = 9
		--	AND WFActivityStep != 100
		--	AND CurrentlyAssignedToName = @UserID
		--	AND IsPPURequired <> 1
		--	AND CurrentlyAssignedToRole = 'Reviewer'
		--	AND CurrentMinorDisposition <> 'Escalate'
		--	AND CurrentMinorDisposition <> 'Consult'
		--	AND CurrentMinorDisposition <> 'Referred'
		--	AND (
		--		ApplnType = 'New Group'
		--		OR ApplnType = 'New Rendering'
		--		OR ApplnType = 'Rendering-S'
		--		OR (
		--			ApplnType = 'New'
		--			AND AffSupUpdateFlag = 'New Group'
		--			)
		--		)
		--UPDATE KYP.ADM_CASE
		--SET StatusCodeNumber = '10'
		--	,GenNo = 0
		--	,WFActivityStep = 0
		--	,CaseSource = NULL
		--WHERE (
		--		Group_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		OR Provider_NPI IN (
		--			@Provider_NPI
		--			,@Group_NPI
		--			)
		--		)
		--	AND StatusCodeNumber = 9
		--	AND WFActivityStep != 100
		--	AND CurrentlyAssignedToName = @UserID
		--	AND IsPPURequired <> 1
		--	AND CurrentlyAssignedToRole <> 'Reviewer'
		--	AND CurrentMinorDisposition <> 'Escalate'
		--	AND CurrentMinorDisposition <> 'Consult'
		--	AND CurrentMinorDisposition <> 'Referred'
		--	AND (
		--		ApplnType = 'New Group'
		--		OR ApplnType = 'New Rendering'
		--		OR ApplnType = 'Rendering-S'
		--		OR (
		--			ApplnType = 'New'
		--			AND AffSupUpdateFlag = 'New Group'
		--			)
		--		)
		
		
		INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,'2'
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,NULL
		,'Accepted'
		,NULL
		,'Accepted'
		,NULL
		,@D_DateTime
		,0
		,'HISTORY'
		,@D_DateTime
		,@Assignee
	FROM KYP.ADM_Case	
	WHERE (	Number = @group_providerNumber
			OR Number IN (SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
						  )
			)	
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=9
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		
		
		
	


INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,2
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,'Accepted'
		,NULL
		,'Accepted'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 8, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE( Number = @group_providerNumber
			OR Number IN (SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
						 )
		)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=10
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		
	
	UPDATE KYP.ADM_WorkflowHistory
	SET ActivityStatus = 'Completed'
		,UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 6, @D_DateTime)
		,Assignee=@Assignee
	WHERE 
		ActivityStatus = 'In Progress'
		AND CaseID IN(	SELECT CaseID FROM KYP.ADM_Case
						WHERE( Number = @group_providerNumber
							   OR Number IN (SELECT rendering_providerNumber FROM KYPPortal.PortalKYP.pRenderingAffiliation
												WHERE group_providerNumber = @group_providerNumber
											)
								)
						AND StatusCodeNumber = 9
						AND PrevStatusCodeNumber=9
						AND (WFActivityStep <> 100
						OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
						AND CurrentlyAssignedToName = @UserID
						AND IsPPURequired <> 1
						AND CurrentMinorDisposition <> 'Escalate'
						AND CurrentMinorDisposition <> 'Consult'
						)
		
	UPDATE KYP.ADM_WorkflowHistory
	SET 
		 UserFullName = @UserFullName
		,UserID = @UserID
		,EndDateTime = @D_DateTime
		,NoOfDays = DATEDIFF(DD, ISNULL([DateTime], GETDATE()), @D_DateTime)
		,SortDateTime = DATEADD(SS, 9, @D_DateTime)
		,Assignee=@Assignee
	WHERE 
		ActivityStatus = 'In Progress'
		AND CaseID IN(	SELECT CaseID FROM KYP.ADM_Case
						WHERE( Number = @group_providerNumber
							   OR Number IN (SELECT rendering_providerNumber FROM KYPPortal.PortalKYP.pRenderingAffiliation
												WHERE group_providerNumber = @group_providerNumber
											)
								)
						AND StatusCodeNumber = 9
						AND PrevStatusCodeNumber=10
						AND (WFActivityStep <> 100
						OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
						AND CurrentlyAssignedToName = @UserID
						AND IsPPURequired <> 1
						AND CurrentMinorDisposition <> 'Escalate'
						AND CurrentMinorDisposition <> 'Consult'
						
						
						
					)
					
		
	
			
	INSERT INTO [KYP].[ADM_WorkflowHistory] (
		[CaseID]
		,[WorkflowStatus]
		,[DateTime]
		,[UserID]
		,[UserFullName]
		,[Notes]
		,[RoleName]
		,[MajorStatus]
		,[MinorStatus]
		,[ActivityStatus]
		,[Description]
		,[EndDateTime]
		,[NoOfDays]
		,[Type]
		,[SortDateTime]
		,[Assignee]
		)
	SELECT CaseID
		,1
		,@D_DateTime
		,@UserID
		,@UserFullName
		,NULL
		,@CurrentlyAssigneToRole
		,@D_MajorDispositionStatus
		,@D_MajorDispositionStatus
		,'In Progress'
		,@Description
		,NULL
		,NULL
		,'HISTORY'
		,DATEADD(SS, 8, @D_DateTime)
		,@Assignee
	FROM KYP.ADM_Case
	WHERE	(Number = @group_providerNumber
			OR Number IN (	SELECT rendering_providerNumber
							FROM KYPPortal.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @group_providerNumber
							)
			)
			AND StatusCodeNumber = 9
			AND PrevStatusCodeNumber=9
			AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'		
	


	
	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '10'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0
		,CaseSource = NULL
		,GenNo=0
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=9
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType <> 'Rendering-S'
		
		UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '10'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
		,GenNo=0
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=10
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType <> 'Rendering-S'
		

	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '12'
		,GenNo = '12'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=9
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType = 'Rendering-S'
		
		
		UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,WFMajorStep = 'Set resolution' -- PreStatusCodeNumber
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,NewGenNo = '12'
		,GenNo = '12'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=10
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole = 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		--AND CurrentMinorDisposition <> 'Referred'
		AND ApplnType = 'Rendering-S'
		

	UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,PrevStatusCodeNumber = StatusCodeNumber
		,WFMajorStep = 'Set resolution'
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
		,GenNo=0
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=9
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole <> 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		
		
		UPDATE KYP.ADM_CASE
	SET StatusCodeNumber = '10'
		,PrevStatusCodeNumber = StatusCodeNumber
		,WFMajorStep = 'Set resolution'
		,WFStatus = 'Set resolution'
		,ReviewerID = @PersonID
		,CurrentMinorDisposition = 'Set resolution'
		,MajorStepID = @MajorStepID
		,WFActivityStep = 0
		,InternalAppStatus =0 
		,CaseSource = NULL
		,GenNo=0
	WHERE (
			Number = @group_providerNumber
			OR Number IN (
				SELECT rendering_providerNumber
				FROM KYPPortal.PortalKYP.pRenderingAffiliation
				WHERE group_providerNumber = @group_providerNumber
				)
			)
		AND StatusCodeNumber = 9
		AND PrevStatusCodeNumber=10
		AND (WFActivityStep <> 100
		OR (CurrentMinorDisposition = 'Referred' and WFActivityStep = 0))
		AND CurrentlyAssignedToName = @UserID
		AND IsPPURequired <> 1
		AND CurrentlyAssignedToRole <> 'Reviewer'
		AND CurrentMinorDisposition <> 'Escalate'
		AND CurrentMinorDisposition <> 'Consult'
		

END TRY
	BEGIN CATCH
		IF @@TranCount>0
			Rollback Transaction;	
				
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'Case_ID',@KeyValue = @CaseID;
	END CATCH
END

GO

