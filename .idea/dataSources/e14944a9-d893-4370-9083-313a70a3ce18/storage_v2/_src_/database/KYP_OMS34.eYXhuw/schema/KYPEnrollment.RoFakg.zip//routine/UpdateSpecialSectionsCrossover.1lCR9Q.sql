
CREATE PROCEDURE [KYPEnrollment].[UpdateSpecialSectionsCrossover]
@application_Code VARCHAR (30)
,@account_party_id INT
,@last_action_user_id VARCHAR(100)
, @app_party_Id     INT

AS
BEGIN
        DECLARE @packageList TABLE (packageName varchar(30) primary key)
        INSERT into @packageList (packageName)
        VALUES ('ISP_P_DM'), ('GSP_P_DM'), ('ISP_NP_AP'), ('GSP_AL_BL'), ('IGSP_P_DM'), ('IGSP_NP_AP'), ('GISP_NP_AP'), ('GISP_P_DM');

        DECLARE @orthProsthPackageList TABLE (packageCode varchar(15) primary key)
			  INSERT into @orthProsthPackageList (packageCode)
			  VALUES ('ISP_OP_AP'), ('ISP_PP_AP'), ('ISP_OAP_AP'), ('GSP_OAP_BL'), ('GISP_OAP_AP'), ('IGSP_OP_AP'), ('IGSP_PP_AP'), ('IGSP_OAP_AP');

        DECLARE @deaId INT
        DECLARE @cliaId INT
        DECLARE @number_id INT
        DECLARE @liability_id INT
        DECLARE @malpractice_id INT
        DECLARE @business_permit_id INT
        DECLARE @today_date DATE = GETDATE()
		    DECLARE @is_deleted BIT = 0
		    DECLARE @current_record_flag BIT = 1
		    DECLARE @last_action VARCHAR(1) = 'C'

        --to subForm Professional Licenses
        IF @application_Code = 'ISP_P_DM'
          BEGIN
            SELECT @deaId = DeaID
            FROM KYPEnrollment.pAccount_PDM_DEA
            WHERE PartyID = @account_party_id AND CurrentRecordFlag=1
            IF @deaId is null OR @deaId = 0
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_DEA ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedBy])
                VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
              END
          END

          IF EXISTS (SELECT * FROM @packageList WHERE packageName = @application_Code)
          BEGIN
            SELECT @cliaId = CliaID
            FROM KYPEnrollment.pAccount_PDM_Clia
            WHERE PartyID = @account_party_id AND CurrentRecordFlag=1
            IF @cliaId is null OR @cliaId = 0
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_Clia ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedByUsedID])
                VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
              END
          END

        --to subForm Insurance
          IF EXISTS (SELECT * FROM @packageList WHERE packageName = @application_Code)
			    BEGIN
				    SELECT @liability_id = InsuranceID
            FROM KYPEnrollment.pAccount_PDM_Insurance
            WHERE PartyID = @account_party_id AND Type IN ('Insurance') AND CurrentRecordFlag=1

				    IF @liability_id is null OR @liability_id = 0
					  BEGIN
						  INSERT INTO KYPEnrollment.pAccount_PDM_Insurance ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                        VALUES (@account_party_id,'Insurance',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
					  END

					  SELECT @malpractice_id = InsuranceID
					  FROM KYPEnrollment.pAccount_PDM_Insurance
					  WHERE PartyID = @account_party_id AND Type IN ('InsurancePage3') AND CurrentRecordFlag=1

				    IF @malpractice_id is null OR @malpractice_id = 0
					  BEGIN
						  INSERT INTO KYPEnrollment.pAccount_PDM_Insurance ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                          VALUES (@account_party_id,'InsurancePage3',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
					  END
			    END

        --to subForm BusinessProfile -section BusinessPermit
          IF EXISTS (SELECT * FROM @packageList WHERE packageName = @application_Code)
          BEGIN
            SELECT @business_permit_id = NumberID
            FROM KYPEnrollment.pAccount_PDM_Number
            WHERE PartyID = @account_party_id AND Type IN ('BusinessPermits') AND CurrentRecordFlag=1

            IF @business_permit_id IS NULL OR @business_permit_id = 0
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_Number ([PartyID], [Type], [CurrentRecordFlag], [IsDeleted], [DateCreated], [LastAction], [LastActionDate], [LastActorUserID])
                VALUES (@account_party_id, 'BusinessPermits', @current_record_flag, @is_deleted, @today_date, @last_action,
                        @today_date, @last_action_user_id);
              END
          END
          --to insert a new professional certificates from croossover to full.
          IF EXISTS (SELECT * FROM @orthProsthPackageList WHERE packageCode = @application_Code)
          BEGIN
              EXEC [KYPEnrollment].[sp_Copy_Prof_Certificate_Orth_Prosth] @application_Code
                                                                          ,@account_party_id
                                                                          ,@last_action_user_id
                                                                          ,@app_party_Id
          END
END


GO

