/****************************************
12/8/17 Updated - S.Fletcher

Notes: Extended property commented out as property cannot be added. Developer, Please change
the extended property as you see fit.

*****************************************/
--set statistics io on

CREATE VIEW [KYP].[View_DBChecksSummary_DBA]
AS

SELECT   row_number() OVER (ORDER BY KYP.SDM_ApplicationParty.ApplicationID ) AS ID, KYP.SDM_ApplicationParty.ApplicationID, 
KYP.SDM_ApplicationParty.ScreeningID, KYP.SDM_ApplicationParty.PartyID, KYP.PDM_Party.Name, KYP.PDM_Party.Type,KYP.SDM_ApplicationParty.PartyType,KYP.SDM_ApplicationParty.PartyRole
, KYP.SDM_DBCheckResult.OIGLEIE, KYP.SDM_DBCheckResult.GSAEPLS, KYP.SDM_DBCheckResult.DMF,  KYP.SDM_DBCheckResult.CourtCheck, KYP.SDM_DBCheckResult.PhoneNo,
KYP.SDM_DBCheckResult.NPI, KYP.SDM_DBCheckResult.SSN, KYP.SDM_DBCheckResult.TIN, KYP.SDM_DBCheckResult.DEA, 
KYP.SDM_DBCheckResult.License As License, 
KYP.SDM_DBCheckResult.TAXONOMY_STATUS,
KYP.SDM_DBCheckResult.City,KYP.SDM_DBCheckResult.Specialty, KYP.SDM_DBCheckResult.CLIA,KYP.SDM_DBCheckResult.IW_NPI_STATUS,KYP.SDM_DBCheckResult.IW_LICENSE_STATUS,KYP.SDM_DBCheckResult.IW_NAME_ADDRESS_STATUS
,KYP.SDM_RedFlag.RedFlagCount,
[KYP].[numberToWords] (ISNULL(KYP.SDM_RedFlag.RedFlagCount, 0)) AS FlagCountText,
CASE
 WHEN KYP.SDM_DBCheckResult.IW_NPI_STATUS = 'T' OR KYP.SDM_DBCheckResult.IW_LICENSE_STATUS = 'T' OR KYP.SDM_DBCheckResult.IW_NAME_ADDRESS_STATUS = 'T'
 THEN 'T'
 ELSE
      'F'
 END As KYP_Watchlist,
 CASE
 WHEN KYP.SDM_DBCheckResult.MCSIS_MD_NPI_STATUS = 'T' THEN 'F'
 when KYP.SDM_DBCheckResult.MCSIS_MD_NPI_STATUS = 'P'THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_ADDR_STATUS = 'T' THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_ADDR_STATUS = 'P' THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_ADDR_STATUS = 'T'THEN 'F'
   when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_ADDR_STATUS = 'P' THEN 'F'
   when MCSIS_MR_NPI_STATUS = 'T' THEN 'F'
    when MCSIS_MR_NPI_STATUS = 'P'THEN 'F'
	 ELSE
      'T'
 END As MCSIS_Watchlist,
 CASE
 WHEN KYP.SDM_DBCheckResult.SANDI_NPI_STATUS = 'T' THEN 'T'
 when KYP.SDM_DBCheckResult.SANDI_LICENSE_STATUS = 'T' THEN 'T'
 when KYP.SDM_DBCheckResult.SANDI_ADDRESS_STATUS = 'T' THEN 'T'
  WHEN KYP.SDM_DBCheckResult.SANDI_NPI_STATUS = 'P' THEN 'P'
  when KYP.SDM_DBCheckResult.SANDI_LICENSE_STATUS = 'P' THEN 'P'
  when KYP.SDM_DBCheckResult.SANDI_ADDRESS_STATUS = 'P' THEN 'P'
 ELSE
      'U'
 END As SANDI_Watchlist,
 KYP.SDM_DBCheckResult.StrAttr2 AS 'TypeMismatch'
FROM         KYP.SDM_ApplicationParty INNER JOIN
                      KYP.PDM_Party ON KYP.SDM_ApplicationParty.PartyID = KYP.PDM_Party.PartyID INNER JOIN
                      KYP.SDM_PartyScreening ON KYP.SDM_ApplicationParty.ScreeningID = KYP.SDM_PartyScreening.ScreeningID AND 
                      KYP.PDM_Party.PartyID = KYP.SDM_PartyScreening.PartyID 
                      INNER JOIN
                      KYP.SDM_DBCheckResult ON KYP.SDM_PartyScreening.ScreeningID = KYP.SDM_DBCheckResult.ScreeningID AND KYP.SDM_ApplicationParty.IsActive = 1 
                      LEFT OUTER JOIN
                      KYP.SDM_RedFlag ON KYP.SDM_ApplicationParty.ScreeningID = KYP.SDM_RedFlag.ScreeningID AND KYP.SDM_RedFlag.IsDeleted = 0
						AND 
						(
							KYP.SDM_RedFlag.RedFlagID = 
							(SELECT Min(RedFlagID) FROM KYP.SDM_RedFlag Q  WHERE (Q.ScreeningID = KYP.SDM_ApplicationParty.ScreeningID 
							AND ISNULL(Q.IsDeleted, 0) = 0) )
						)
						
				
		


/*
EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane1', @value=N'[0E232FF0-B466-11cf-A24F-00AA00A3EFFF, 1.00]
Begin DesignProperties = 
   Begin PaneConfigurations = 
      Begin PaneConfiguration = 0
         NumPanes = 4
         Configuration = "(H (1[22] 4[17] 2[12] 3) )"
      End
      Begin PaneConfiguration = 1
         NumPanes = 3
         Configuration = "(H (1 [50] 4 [25] 3))"
      End
      Begin PaneConfiguration = 2
         NumPanes = 3
         Configuration = "(H (1 [50] 2 [25] 3))"
      End
      Begin PaneConfiguration = 3
         NumPanes = 3
         Configuration = "(H (4 [30] 2 [40] 3))"
      End
      Begin PaneConfiguration = 4
         NumPanes = 2
         Configuration = "(H (1 [56] 3))"
      End
      Begin PaneConfiguration = 5
         NumPanes = 2
         Configuration = "(H (2 [66] 3))"
      End
      Begin PaneConfiguration = 6
         NumPanes = 2
         Configuration = "(H (4 [50] 3))"
      End
      Begin PaneConfiguration = 7
         NumPanes = 1
         Configuration = "(V (3))"
      End
      Begin PaneConfiguration = 8
         NumPanes = 3
         Configuration = "(H (1[56] 4[18] 2) )"
      End
      Begin PaneConfiguration = 9
         NumPanes = 2
         Configuration = "(H (1 [75] 4))"
      End
      Begin PaneConfiguration = 10
         NumPanes = 2
         Configuration = "(H (1[66] 2) )"
      End
      Begin PaneConfiguration = 11
         NumPanes = 2
         Configuration = "(H (4 [60] 2))"
      End
      Begin PaneConfiguration = 12
         NumPanes = 1
         Configuration = "(H (1) )"
      End
      Begin PaneConfiguration = 13
         NumPanes = 1
         Configuration = "(V (4))"
      End
      Begin PaneConfiguration = 14
         NumPanes = 1
         Configuration = "(V (2))"
      End
      ActivePaneConfig = 0
   End
   Begin DiagramPane = 
      Begin Origin = 
         Top = -192
         Left = 0
      End
      Begin Tables = 
         Begin Table = "SDM_ApplicationParty (KYP)"
            Begin Extent = 
               Top = 17
               Left = 3
               Bottom = 132
               Right = 171
            End
            DisplayFlags = 280
            TopColumn = 5
         End
         Begin Table = "PDM_Party (KYP)"
            Begin Extent = 
               Top = 181
               Left = 150
               Bottom = 296
               Right = 310
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "SDM_PartyScreening (KYP)"
            Begin Extent = 
               Top = 6
               Left = 633
               Bottom = 121
               Right = 809
            End
            DisplayFlags = 280
            TopColumn = 0
         End
         Begin Table = "SDM_DBCheckResult (KYP)"
            Begin Extent = 
               Top = 101
               Left = 468
               Bottom = 216
               Right = 621
            End
            DisplayFlags = 280
            TopColumn = 0
         End
      End
   End
   Begin SQLPane = 
   End
   Begin DataPane = 
      Begin ParameterDefaults = ""
      End
      Begin ColumnWidths = 18
         Width = 284
         Width = 1500
         Width = 1500
         Width = 2850
         Width = 1500
         Width = 2190
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
         Width = 1500
      End
   End
   Begin CriteriaPane = 
      Begin ColumnWidths = 11
         Column = 1440
         Alias = 900
' , @level0type=N'SCHEMA',@level0name=N'KYP', @level1type=N'VIEW',@level1name=N'View_DBChecksSummary'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPane2', @value=N'
         Table = 1170
         Output = 720
         Append = 1400
         NewValue = 1170
         SortType = 1350
         SortOrder = 1410
         GroupBy = 1350
         Filter = 1350
         Or = 1350
         Or = 1350
         Or = 1350
      End
   End
End
' , @level0type=N'SCHEMA',@level0name=N'KYP', @level1type=N'VIEW',@level1name=N'View_DBChecksSummary'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_DiagramPaneCount', @value=2 , @level0type=N'SCHEMA',@level0name=N'KYP', @level1type=N'VIEW',@level1name=N'View_DBChecksSummary'
GO
*/



GO

