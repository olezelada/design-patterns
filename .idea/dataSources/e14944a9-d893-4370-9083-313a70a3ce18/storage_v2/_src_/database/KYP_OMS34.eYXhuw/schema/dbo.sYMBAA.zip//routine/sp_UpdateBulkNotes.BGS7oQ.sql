-- =============================================
-- Author:		Manikanta Donthu
-- Create date: 3/24/2014
-- Description:	it will update the record in mdm_basic journal info as well as falsepositive table and reason code in MDM_Alert
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateBulkNotes]
	-- Add the parameters for the stored procedure here 
	@AlertID NVARCHAR(500)
	,@AlertNo NVARCHAR(500)
	,@alertStatus NVARCHAR(50)
	,@description NVARCHAR(max)
	,@reasoncode VARCHAR(100)
	,@snozzedate VARCHAR(100)
	,@dateChanged NVARCHAR(50)
	,@PartyIDAttribute VARCHAR(100)
	,@WatchlistPartyID VARCHAR(100)
	,@NoteTitle VARCHAR(max)
	,@RelatedEntityType VARCHAR(50)
	,@Type VARCHAR(100)
	,@SubType VARCHAR(50)
	,@AssignedToUser INT
	,@FormattedContent VARCHAR(MAX)
AS
BEGIN
	DECLARE @ID NVARCHAR(300)
	DECLARE @SQLQuery NVARCHAR(4000)
	DECLARE @PARTYID INT
	DECLARE @WatchedPartyType VARCHAR(50)
	DECLARE @OrganizationName VARCHAR(200)
	DECLARE @WatchlistName VARCHAR(175)
	DECLARE @FName VARCHAR(50)
	DECLARE @MName VARCHAR(50)
	DECLARE @LName VARCHAR(50)
	DECLARE @Assignee VARCHAR(250)
	DECLARE @AssignedToUserID INT
	DECLARE @MatchStatusIndicatorDesc VARCHAR(25)

	DECLARE BULKNOTE_CURSOR CURSOR
	FOR
	SELECT Data
	FROM dbo.split(@AlertNo, ',')

	OPEN BULKNOTE_CURSOR

	FETCH NEXT
	FROM BULKNOTE_CURSOR
	INTO @ID

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @AlertNo = @ID

		/*--------------UPDATE THE REASONCODE IN MDM_ALERT-----------------*/
		IF @alertStatus = 'C'
		BEGIN
			SET @MatchStatusIndicatorDesc = 'Confirmed'
		END
		ELSE IF @alertStatus = 'F'
		BEGIN
			SET @MatchStatusIndicatorDesc = 'False Positive'
		END
		ELSE IF @alertStatus = 'I'
		BEGIN
			SET @MatchStatusIndicatorDesc = 'Ignored'
		END
		ELSE IF @alertStatus = 'U'
		BEGIN
			SET @MatchStatusIndicatorDesc = 'Unconfirmed'
		END

		UPDATE kyp.mdm_alert
		SET reasoncode = @reasoncode
		--,matchstatusindicator = @alertStatus
		--,MatchStatusIndicatorDesc = @MatchStatusIndicatorDesc
		WHERE AlertNo = @AlertNo

		IF @SubType = 'DispositionDetail'
		BEGIN
			IF @alertStatus = 'I'
				OR @alertStatus = 'F'
			BEGIN
				UPDATE kyp.mdm_alert
				SET CurrentMajorDisposition = 'Alert Resolution'
					,CurrentMinorDisposition = 'Alert Resolution Completed'
					,CurrentWFMinorStatus = 'Closed Alert'
					,CurrentWFStatus = 'CloseAlert'
				--,DateClosed = GETDATE()
				--,ActivityStatus = 'Closed'
				WHERE AlertNo = @AlertNo
			END
		END

		/*--------------GETTING THE WATCHED PARTY TYPE IT IS INDIVIDUAL OR ORGANISATION-----------------*/
		SELECT @WatchedPartyType = WatchedPartyType
		FROM KYP.MDM_Alert
		WHERE AlertNo = @AlertNo

		----SELECT @Assignee= Assignee FROM KYP.MDM_Alert WHERE AlertNo =@AlertNo
		SELECT @Assignee = UserID
		FROM KYP.OIS_User
		WHERE PersonID = @AssignedToUser --(SELECT TOP 1 AssignedToUserID FROM KYP.MDM_BulkTempNote WHERE AlertID =@AlertID)

		IF Ltrim(Rtrim(Isnull(@Assignee, ' '))) = ''
		BEGIN
			SET @Assignee = 'system';
		END

		SELECT @AlertID = AlertID
		FROM KYP.MDM_Alert
		WHERE AlertNo = @AlertNo

		SELECT @AssignedToUserID = AssignedToUserID
		FROM KYP.MDM_Alert
		WHERE AlertNo = @AlertNo

		SELECT @PARTYID = WatchedPartyID
		FROM KYP.MDM_Alert
		WHERE AlertNo = @AlertNo

		SELECT @WatchlistName = WatchlistName
		FROM KYP.MDM_Alert
		WHERE AlertNo = @AlertNo

		SELECT @WatchlistPartyID = NPIID
		FROM KYP.MDM_AlertDetail
		WHERE AlertID = @AlertID

		--IF @WatchlistName = 'SAM'
		--	BEGIN
		--		SELECT @WatchlistPartyID = SAMID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'OIG LEIE'
		--	BEGIN
		--		SELECT @WatchlistPartyID = OIGLEIE from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'NPI Issues'
		--	BEGIN
		--SELECT @WatchlistPartyID = NPIID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'License Status'
		--	BEGIN
		--		SELECT @WatchlistPartyID = LICENSEID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'SSA DMF'
		--	BEGIN
		--		SELECT @WatchlistPartyID = SSAMDFID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'Sanction Status'
		--	BEGIN
		--		SELECT @WatchlistPartyID = SANCTIONID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		--ELSE IF @WatchlistName = 'Medicaid & Medicare Exclusion'
		--	BEGIN
		--		SELECT @WatchlistPartyID = SANCTIONID from KYP.MDM_AlertDetail WHERE AlertID=@AlertID		
		--	END
		/*--------------BASED ON WATCHED PARTY GETTING THE FIRST,LAST,MIDDLE AND ORGANIZATION NAMES-----------------*/
		IF @WatchedPartyType = 'Individual'
		BEGIN
			/*
									*Modified By	: Ashok Chelimilla
									*MOdified date	: 7/15/2014
									*Reviewed By	: 
									*Description: To fix Bug:KYP-7669 (while doing builk closer storing the fname ,lname, Mname and orgName from PDM_PERSON and MDM_Alert insted of MDM_AlertDetails.)
									*/
			/*	SELECT @FName =FirstName FROM KYP.PDM_PERSON WHERE PartyID IN(SELECT WatchedPartyID FROM KYP.MDM_Alert WHERE AlertNo =@AlertNo)
										SELECT @LName =LastName FROM KYP.PDM_PERSON WHERE PartyID IN(SELECT WatchedPartyID FROM KYP.MDM_Alert WHERE AlertNo =@AlertNo)
										SELECT @MName =MiddleName FROM KYP.PDM_PERSON WHERE PartyID IN(SELECT WatchedPartyID FROM KYP.MDM_Alert WHERE AlertNo =@AlertNo)*/
			SELECT @FName = [FName]
				,@LName = [LName]
				,@MName = [MName]
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = (
					SELECT AlertID
					FROM KYP.MDM_Alert
					WHERE AlertNo = @AlertNo
					)

			SET @OrganizationName = NULL;
		END
		ELSE
		BEGIN
			SET @FName = NULL;
			SET @LName = NULL;
			SET @MName = NULL;

			--SELECT @OrganizationName=WatchedPartyName FROM KYP.MDM_Alert WHERE WatchedPartyID IN(SELECT WatchedPartyID FROM KYP.MDM_Alert WHERE AlertNo =@AlertNo)
			SELECT @OrganizationName = OrganizationName
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = (
					SELECT AlertID
					FROM KYP.MDM_Alert
					WHERE AlertNo = @AlertNo
					)
		END

		--End of Bug:KYP-7669 fix changes.
		/*--------------INSERT RECORD IN MDM_JOURNALINFO BECAUSE IT WILL INSERT AUTOMATICALLY IN OIS_NOTE-----------------*/
		/*
									Modified By:- bjena
									Reviewed By:- Vinoth
										   Date:- 5th May 2014
										   Server:- dhi-wlmdata
										   DB:- KYP31OMS
										  Issue:- http://jira/browse/KYP-6913
										   Desc:- During False Positive radio button selection the disposition note was 
										   inswering 2 times , one time from application side & one time from SP . 
										   So the bellow two lines were commented.
								*/
		IF @SubType = 'Disposition'
		BEGIN
			INSERT INTO KYP.MDM_JournalBasicInfo (
				UserName
				,AlertNo
				,AssignToUserID
				,NotesDescription
				,NotesTitle
				,RelatedEntityType
				,RelatedEntityID
				,Type
				,SubType
				,FormattedContent
				)
			VALUES (
				@Assignee
				,@AlertNo
				,@AssignedToUserID
				,@description
				,@NoteTitle
				,'MDM_Alert'
				,@AlertID
				,'Disposition'
				,'Disposition'
				,@FormattedContent
				)
		END

		/*--------------BASED ON SNOOZE DATE AND DATACHANGED WE ARE INSERTING RECORD IN FALSEPOSITIVE TABLE-----------------*/
		--print @snozzedate
		DELETE
		FROM [KYP].MDM_FalsePositiveAlert
		WHERE Alertid = @AlertID

		IF (@alertStatus = 'I')
		BEGIN
			SET @dateChanged = NULL

			IF (@snozzedate IS NULL)
			BEGIN
				SET @snozzedate = '5'
			END

			IF Ltrim(Rtrim(Isnull(@snozzedate, ''))) = '5'
			BEGIN
				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertId
					)
				VALUES (
					convert(VARCHAR(10), @PARTYID)
					,CONVERT(VARCHAR(10), Getdate() + 90, 126)
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
			ELSE IF Ltrim(Rtrim(Isnull(@snozzedate, ''))) = '6'
			BEGIN
				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertId
					)
				VALUES (
					convert(VARCHAR(10), @PARTYID)
					,Dateadd(day, - 1, (Dateadd(month, 6, Getdate())))
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
			ELSE IF Ltrim(Rtrim(Isnull(@snozzedate, ''))) = '7'
			BEGIN
				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertId
					)
				VALUES (
					convert(VARCHAR(10), @PARTYID)
					,Dateadd(day, - 1, (Dateadd(month, 12, Getdate())))
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);

				SET @snozzedate = '6'
			END
			ELSE IF Ltrim(Rtrim(Isnull(@snozzedate, ''))) = '8'
			BEGIN
				SET @snozzedate = NULL

				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertId
					)
				VALUES (
					convert(VARCHAR(10), @PARTYID)
					,@snozzedate
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
		END
		ELSE IF (@alertStatus = 'F')
		BEGIN
			SET @snozzedate = NULL

			IF (@dateChanged IS NULL)
			BEGIN
				SET @dateChanged = '3'
			END

			INSERT INTO [KYP].MDM_FalsePositiveAlert (
				PartyID
				,SnoozeDate
				,WatchlistName
				,FName
				,MName
				,LName
				,OrganizationName
				,WatchedPartyType
				,AlertStatus
				,DataChanged
				,PartyIDAttribute
				,WatchlistPartyID
				,AlertId
				)
			VALUES (
				convert(VARCHAR(10), @PARTYID)
				,@snozzedate
				,@WatchlistName
				,@FName
				,@MName
				,@LName
				,@OrganizationName
				,@WatchedPartyType
				,@alertStatus
				,@dateChanged
				,@PartyIDAttribute
				,@WatchlistPartyID
				,@AlertID
				);
		END

		FETCH NEXT
		FROM BULKNOTE_CURSOR
		INTO @ID
	END

	CLOSE BULKNOTE_CURSOR

	DEALLOCATE BULKNOTE_CURSOR
END
GO

