-- =============================================
-- Author:		<AVeliz>
-- Create date: <08/13/2018>
-- Description:	<Update internalSections forms application account attachment references>
-- =============================================
CREATE Procedure [KYPEnrollment].[sp_Update_Attachments_References_AppPartyId]
  (   @accountId INT
    , @applicationId INT
  )

AS

  BEGIN

    BEGIN TRY
    DECLARE @tempAppAttachment TABLE(id INT IDENTITY(1,1), appPartyId INT , targetPath VARCHAR(100));
    DECLARE @count INT, @total INT, @appPartyId INT, @accountPartyId INT;


    IF @accountId IS NOT NULL AND @applicationId IS NOT NULL
      BEGIN

		  INSERT INTO @tempAppAttachment (appPartyId, targetPath)
		  SELECT party.PartyID, party.TargetPath
      FROM KYPPORTAL.PortalKYP.pPDM_Party party INNER JOIN KYPPORTAL.PortalKYP.pApplicationDocumentFile doc ON party.PartyID = doc.partyId
      WHERE applicationId = @applicationId AND party.TargetPath Like ('pAccount_PDM_Party|PartyID|%')

		  SELECT @total = MAX(id) FROM @tempAppAttachment
		  SET @count = 1;

		    WHILE @count <= @total
			    BEGIN
		        SELECT @appPartyId = tmp.appPartyId, @accountPartyId = SUBSTRING(targetPath, 28, LEN(targetPath))
		        FROM @tempAppAttachment tmp
		        WHERE tmp.id = @count

		        IF(@accountPartyId IS NOT NULL AND @appPartyId IS NOT NULL)
			      BEGIN
				      UPDATE KYPEnrollment.pAccount_Attachments
				      SET ApplicationPartyId = @appPartyId
				      WHERE AccountPartyId = @accountPartyId
		      	END

		      SET @count = @count + 1;
	        END
          RETURN
      END

    END TRY

    BEGIN CATCH

    Exec [KYPEnrollment].[Usp_LogError] @KeyField = @applicationId,@KeyValue =@accountId

    END CATCH;

  END

GO

