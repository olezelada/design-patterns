

CREATE VIEW [KYP].[v_IndividualRAlerts]
AS
SELECT     KYP.MDM_Alert.AlertID, KYP.MDM_Alert.AlertNo, KYP.MDM_Alert.AssignedByUserID, KYP.MDM_Alert.DateInitiated, KYP.MDM_Alert.WatchlistName, 
                      KYP.MDM_Alert.WatchedPartyName, KYP.PDM_Person.FirstName, KYP.PDM_Person.MiddleName, KYP.PDM_Person.LastName, 
                      KYP.PDM_Person.SSN, KYP.MDM_Alert.MatchPercent, KYP.MDM_Alert.MatchStatusIndicator, KYP.MDM_Alert.WatchedPartyID, 
                      KYP.MDM_Alert.NoOfMergedAlerts, KYP.MDM_Alert.WatchedPartyType, KYP.MDM_Alert.AssignedToUserID, KYP.OIS_User.FullName, 
                      KYP.MDM_Alert.WFMinorDisposition AS 'CurrentWFMinorStatus', KYP.MDM_Alert.Priority
FROM         KYP.MDM_Alert LEFT OUTER JOIN
                      KYP.PDM_Person ON KYP.MDM_Alert.WatchedPartyID = KYP.PDM_Person.PartyID LEFT OUTER JOIN
                      KYP.OIS_User ON KYP.MDM_Alert.AssignedToUserID = KYP.OIS_User.PersonID
WHERE     (KYP.MDM_Alert.WatchedPartyType = 'Individual' AND KYP.MDM_Alert.ActivityStatus NOT IN ('Consulted'))


GO

