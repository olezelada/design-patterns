-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts copy al data related to the BUSINESS PROFILE SECTION of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Profile_Section] 
@new_Account_Id int,
@new_Party_Id int,
@party_Id int,
@last_action_user_id varchar(50),
@application_no varchar(100)

AS
BEGIN
Declare @new_person_id int,@npi_Type varchar(100),@new_Address_Id int,@npi varchar(100),@provider_type_code varchar(20),
@account_number varchar(100),@accountType varchar(10),@application_Id INT,@application_type VARCHAR(50),
@org int,@isgroup bit
	SET NOCOUNT ON;

SELECT @npi_Type = NPIType,@npi = NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber ,@accountType = AccountType
FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id

select @application_Id = ApplicationID,@application_type = ApplicationType from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo = @application_no and IsDeleted=0

	if @npi_type = 'Organization'
	BEGIN
		SET @isgroup = 1
	END
	else
	begin
		SET @isgroup = 0
	end


IF @npi_Type = 'Individual'
BEGIN

	SET @isgroup = 0

	select @new_person_id = PersonID from KYPEnrollment.pAccount_PDM_Person where PartyID=@new_Party_Id and Deleted=0
	IF @new_person_id is null
	BEGIN
	
		EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Person] @new_Party_Id,@party_Id,@last_action_user_id,NULL
	
	END
	
	EXEC [KYPEnrollment].[sp_Copy_Organization]   @new_Party_Id,
												  @party_Id,
												  @last_Action_User_ID	

	EXEC [KYPEnrollment].[p_Copy_EntityType]      @party_Id,@new_Party_Id,@last_action_user_id												  
		
	EXEC [KYPEnrollment].[sp_Copy_Number] @new_Party_Id,@party_Id, @last_Action_User_ID, NULL;

	SELECT top 1 @new_Address_Id = a.AddressID FROM KYPEnrollment.pAccount_PDM_Address a INNER JOIN KYPEnrollment.pAccount_PDM_Location l ON a.AddressID=l.AddressID
	where a.CurrentRecordFlag=1 and l.CurrentRecordFlag=1 and l.IsDeleted=0 and l.PartyID=@new_Party_Id and l.Type='Servicing'
	
	EXEC [KYPEnrollment].[FBP_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id, @party_Id, 1, @provider_type_code, @account_number, NULL,@accountType,@application_Id,@isgroup,@application_type,null;

END

ELSE
if @npi_type = 'Organization'
BEGIN
		
		EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Organization]   @new_Party_Id,
												  @party_Id,
												  @last_Action_User_ID	
		
		EXEC [KYPEnrollment].[p_Copy_EntityType]      @party_Id,@new_Party_Id,@last_action_user_id												  
		
		EXEC [KYPEnrollment].[sp_Copy_Number] @new_Party_Id,@party_Id, @last_Action_User_ID, NULL;
		
		select @new_Address_Id = a.AddressID from KYPEnrollment.pAccount_PDM_Location l INNER JOIN KYPEnrollment.pAccount_PDM_Address a ON l.AddressID=a.AddressID
		where l.PartyID=@new_Party_Id and l.IsDeleted=0 and a.CurrentRecordFlag=1 and l.Type='Servicing';
		
		EXEC [KYPEnrollment].[FBP_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id, @party_Id, 1, @provider_type_code, @account_number, NULL,@accountType,@application_Id,@isgroup,@application_type,null;
END


END


GO

