--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket					Description
--------------------------------------------------------------------------------------------------------
-- 1		2-Jan-2017		Sundar		CAPAVE-998					Fix for Alert Gen. Issue
-- 2		8-Jan-2017		Sundar		Alert Gen. Package Issue
-- 3		13-Apr-2017		Sundar		PI-749						Deleting the alerts based on owner/ Employee whose CurrentModule=1 (Screening Alerts)
-- 4		30-Jun-2017		Sundar		CAPAVE-254					Updated 5 fields from MDM_StageAlerts to KYP.MDM_AlertDetailPartyMatch

/******Script for insert procedure************/
CREATE PROCEDURE [dbo].[p_LoadAlertData]
AS
BEGIN
	/********Declare Alert Looping Variables*****************/
	DECLARE @FirstIAlert BIGINT
		,@LastIAlert BIGINT
		,@CurrentAlert BIGINT
	/*********Declare AlertID variable***********************/
	DECLARE @AlertID INT
		,@ProvID INT
		,@MedicaidID VARCHAR(20)
	/*********** Declare variables for Fname,lastname ,Orgname and other details obtained in intermittent table*******/
	DECLARE @PartyID INT
		,@FirstName VARCHAR(50)
		,@MiddleName VARCHAR(50)
		,@Lastname VARCHAR(50)
		,@Orgname VARCHAR(500)
		,@AliasName VARCHAR(500)
		,@AddressLine1 VARCHAR(250)
		,@AddressLine2 VARCHAR(250)
		,@City VARCHAR(50)
		,@State VARCHAR(5)
		,@ZIP VARCHAR(5)
		,@ZIP4 VARCHAR(4)
		,@DOB VARCHAR(10)
		,@NPI VARCHAR(10)
		,@SSN VARCHAR(9)
		,@UPIN VARCHAR(6)
		,@TAX_ID VARCHAR(10)
		,@HMS_PIID VARCHAR(10)
		,@HMS_POID VARCHAR(10)
		,@LoadID VARCHAR(30)
		,@LoadType VARCHAR(1)
		,@LastLoadDate DATETIME
		,@EPLS_TermDate VARCHAR(10)
		,@EPLS_ActionDate VARCHAR(10)
		,@EPLS_Agency VARCHAR(25)
		,@LEIE_EXCLType VARCHAR(50)
		,@LEIE_EXCLDate VARCHAR(10)
		,@LEIE_REINDATE VARCHAR(10)
		,@Offense_Description VARCHAR(255)
		,@Offense_Code VARCHAR(10)
		,@Offense_Date VARCHAR(10)
		,@Board_Description VARCHAR(255)
		,@Board_Code VARCHAR(15)
		,@Action_Description VARCHAR(255)
		,@Action_Code VARCHAR(10)
		,@Action_Date VARCHAR(10)
		,@Sanc_PeriodStartDt VARCHAR(10)
		,@Sanc_PeriodEndDt VARCHAR(10)
		,@Sanc_FineAmt VARCHAR(8)
		,@License_State VARCHAR(5)
		,@License_Number VARCHAR(25)
		,@License_Type VARCHAR(3)
		,@License_Status VARCHAR(1)
		,@License_Start_Date VARCHAR(10)
		,@License_Expire_Date VARCHAR(10)
		,@DEA_RANK VARCHAR(2)
		,@DEA_Expire VARCHAR(10)
		,@DEA_Active VARCHAR(1)
		,@MatchAccuracy INT
		,@MatchPercentage INT
		,@DEA VARCHAR(9)
		,@WatchlistName VARCHAR(50)
		,@now DATETIME
		,@WatchedPartyName VARCHAR(100)
		,@WatchedPartyType VARCHAR(50)
		,@AlertNumber VARCHAR(15)
		,@UniqueKey VARCHAR(550)
		,@DOD DATETIME
		,@isTwoWayMatch BIT
		,@NPIAlertType VARCHAR(50)
		,@gateKeeperId INT
		,@AKAName VARCHAR(500)
		,@MCSIS_ID INT
		,@WatchlistPartyid VARCHAR(20)
		,@AlertGenCriteria VARCHAR(250)
		,@TerminationEffectiveDate datetime --Added for #4 CAPAVE-254
		,@TerminationImportDate datetime --Added for #4 CAPAVE-254	
		,@AdditionalComments Varchar(500) --Added for #4 CAPAVE-254			

	Declare @AssignedUnAssignedAlertCount int = 0; --#1 Added for AlertGeneration Fix

	/*#3 PI-749 Start*/
	Delete from t1
	from kyp.mdm_stagealerts t1
	join kyp.pdm_owner t2 on t1.partyid=t2.partyid
	join kyp.pdm_provider t3 on t2.providerid=t3.provid
	join kyp.pdm_party t4 on t3.partyid=t4.partyid
	where t4.currentmodule=1

	Delete from t1
	from kyp.mdm_stagealerts t1
	join kyp.pdm_employee t2 on t1.partyid=t2.partyid
	join kyp.pdm_provider t3 on t2.providerid=t3.provid
	join kyp.pdm_party t4 on t3.partyid=t4.partyid
	where t4.currentmodule=1
	/*#3 PI-749 End */	
	
	/**********Looping ID's**************************************/
	SELECT @FirstIAlert = MIN(MDM_InterID)
		,@LastIAlert = MAX(MDM_InterID)
		,@CurrentAlert = MIN(MDM_InterID)
	FROM KYP.MDM_StageAlerts

	/********** Declare Varible for Duplicate RC_Count**************************************/
	DECLARE @RC_Count INT
	/***********************Declare variable for Address********/
	DECLARE @AddressID INT

	SELECT @now = GETDATE()

	DECLARE @CHECKMONTH INT
	DECLARE @CHECKYR INT

	SELECT TOP 1 @CHECKMONTH = [Month]
		,@CHECKYR = [Year]
	FROM KYP.MDM_MonthlyActiveProvider
	ORDER BY [Year] DESC
		,[Month] DESC

	ALTER TABLE KYP.MDM_Alert DISABLE TRIGGER trg_MDM_AlertOnUpdate

	WHILE (@CurrentAlert <= @LastIAlert)
	BEGIN
		BEGIN TRY
			BEGIN TRAN LoadAlertData

			SELECT @PartyID = [PartyID]
				,@FirstName = upper([FirstName])
				,@MiddleName = upper([MiddleName])
				,@Lastname = upper([Lastname])
				,@Orgname = upper(replace([Orgname], '"', ''))
				,@AddressLine1 = upper([AddressLine1])
				,@AddressLine2 = upper([AddressLine2])
				,@City = upper([City])
				,@State = upper([State])
				,@ZIP = [ZIP]
				,@ZIP4 = [ZIP4]
				,@DOB = [DOB]
				,@NPI = [NPI]
				,@SSN = [SSN]
				,@UPIN = [UPIN]
				,@TAX_ID = [TAX_ID]
				,@HMS_PIID = [HMS_PIID]
				,@HMS_POID = [HMS_POID]
				,@LoadID = [LoadID]
				,@LoadType = [LoadType]
				,@LastLoadDate = [LastLoadDate]
				,@EPLS_TermDate = [EPLS_TermDate]
				,@EPLS_ActionDate = [EPLS_ActionDate]
				,@EPLS_Agency = [EPLS_Agency]
				,@LEIE_EXCLType = [LEIE_EXCLType]
				,@LEIE_EXCLDate = [LEIE_EXCLDate]
				,@LEIE_REINDATE = [LEIE_REINDATE]
				,@Offense_Code = [Offense_Code]
				,@Offense_Date = [Offense_Date]
				,@Offense_Description = [Offense_Description]
				,@Board_Description = [Board_Description]
				,@Board_Code = [Board_Code]
				,@Action_Description = [Sanction_Description]
				,@Action_Code = [Action_Code]
				,@Action_Date = [Action_Date]
				,@Sanc_PeriodStartDt = [Sanc_PeriodStartDt]
				,@Sanc_PeriodEndDt = [Sanc_PeriodEndDt]
				,@Sanc_FineAmt = [Sanc_FineAmt]
				,@License_State = [License_State]
				,@License_Number = [License_Number]
				,@License_Type = [License_Type]
				,@License_Status = [License_Status]
				,@License_Start_Date = [License_Start_Date]
				,@License_Expire_Date = [License_Expire_Date]
				,@DEA_RANK = [DEA_RANK]
				,@DEA_Expire = [DEA_Expire]
				,@DEA_Active = [DEA_Active]
				,@MatchAccuracy = [MatchAccuracy]
				,@MatchPercentage = [MatchPercentage]
				,@WatchlistName = [WatchlistName]
				,@DEA = [DEA]
				,@UniqueKey = [UniqueKey]
				--Added Case statement to exclude Invalid dates '00000000' by Sundar on 4-May-2017
				,@DOD = Case when ([DOD] <> '00000000') THEN CONVERT(DATETIME, RIGHT([DOD], 4) + LEFT([DOD], 2) + SUBSTRING([DOD], 3, 2)) END --[DOD
				,@isTwoWayMatch = [isTwoWayMatch]
				,@NPIAlertType = [NPIAlertType]
				,@gateKeeperId = [GK_WL_Id]
				,@AKAName = AKAName
				,@MCSIS_ID = MCSIS_ID
				,@WatchlistPartyid = watchlistpartyid
				,@AlertGenCriteria = AlertGenCriteria
				,@TerminationEffectiveDate = TerminationEffectiveDate --Added for #4 CAPAVE-254
				,@TerminationImportDate = TerminationImportDate --Added for #4 CAPAVE-254	
				,@AdditionalComments = AdditionalComments --Added for #4 CAPAVE-254					
			FROM [KYP].[MDM_StageAlerts]
			WHERE MDM_InterID = @CurrentAlert

			/********Start KYP-1577 : Future DOB bug fix**********/
			SELECT @DOB = CASE 
					WHEN len(@DOB) = 8
						THEN STUFF(@DOB, 7, 0, '19')
					ELSE @DOB
					END

			/********End KYP-1577 : Future DOB bug fix**********/
			SELECT @ProvID = NULL
				,@MedicaidID = NULL
				,@AliasName = NULL

			SELECT @ProvID = ProvID
			FROM KYP.PDM_Provider
			WHERE PartyID = @PartyID

			IF @ProvID IS NULL
			BEGIN
				SELECT @ProvID = ProviderID
				FROM KYP.PDM_Owner
				WHERE PartyID = @PartyID
			END

			IF @ProvID IS NULL
			BEGIN
				SELECT @ProvID = ProviderID
				FROM KYP.PDM_Employee
				WHERE PartyID = @PartyID
			END

			SELECT @MedicaidID = ProvNumber
			FROM KYP.PDM_Provider
			WHERE ProvID = @ProvID

			IF (
					@WatchlistName IN (
						'SAM'
						,'OIG LEIE'
						,'NPI Issues'
						,'SSA DMF'
						,'Internal Watchlist'
						,'S&I Watchlist'
						)
					)
			BEGIN
				SELECT @RC_Count = COUNT(1)
				FROM KYP.MDM_Alert A
				JOIN KYP.MDM_AlertDetail D ON A.AlertID = D.AlertID
				WHERE COALESCE(D.npiid, '') = COALESCE(@WatchlistPartyid, '')
					AND A.WatchlistName = @WatchlistName
					AND A.WatchedPartyID = @PartyID
					AND A.WFStatus <> 'Completed'
					AND cast(@MatchPercentage AS INT) <= cast(a.matchpercent AS INT)
			END
			ELSE IF (@WatchlistName = 'License Status')
			BEGIN
				SELECT @RC_Count = COUNT(1)
				FROM KYP.MDM_Alert A
				JOIN KYP.MDM_AlertDetail D ON A.AlertID = D.AlertID
				WHERE A.WatchlistName = @WatchlistName
					AND A.WatchedPartyID = @PartyID
					AND coalesce(D.npiid, '') = coalesce(@WatchlistPartyid, '')
					AND right(coalesce(D.LicenseNo, ''), 4) = right(coalesce(@License_Number, ''), 4)
					AND coalesce(D.License_State, '') = coalesce(@License_State, '')
					AND A.WFStatus <> 'Completed'
					AND cast(@MatchPercentage AS INT) <= cast(a.matchpercent AS INT)
			END
			ELSE IF (
					@WatchlistName IN (
						'Sanction Status'
						,'Medicaid & Medicare Exclusion'
						)
					)
			BEGIN
				SELECT @RC_Count = COUNT(1)
				FROM KYP.MDM_Alert A
				JOIN KYP.MDM_AlertDetail D ON A.AlertID = D.AlertID
				WHERE A.WatchlistName = @WatchlistName
					AND A.WatchedPartyID = @PartyID
					AND coalesce(D.npiid, '') = coalesce(@WatchlistPartyid, '')
					AND coalesce(D.Offense_Code, '') = coalesce(@Offense_Code, '')
					AND coalesce(D.Board_Code, '') = coalesce(@Board_Code, '')
					AND coalesce(D.Action_Code, '') = coalesce(@Action_Code, '')
					AND A.WFStatus <> 'Completed'
					AND cast(@MatchPercentage AS INT) <= cast(a.matchpercent AS INT)
			END

			
			IF (@RC_Count = 0)
			BEGIN
				DECLARE @PDMPARTYDATE DATETIME
				DECLARE @ClosedDate DATETIME
				DECLARE @ChkCrMonth INT
				DECLARE @ChkCrYr INT
				DECLARE @ChkMoMonth INT
				DECLARE @ChkMoYr INT

				SELECT @PDMPARTYDATE = DateModified
					,@ChkCrYr = DATEPART(yyyy, datecreated)
					,@ChkCrMonth = DATEPART(mm, datecreated)
					,@ChkMoYr = DATEPART(yyyy, DateModified)
					,@ChkMoMonth = DATEPART(mm, DateModified)
				FROM KYP.PDM_Party
				WHERE PartyID = @PartyID

				SELECT @ClosedDate = LastDispositionDate
				FROM KYP.MDM_Alert
				WHERE WatchedPartyID = @PartyID
					AND WatchlistName = @WatchlistName
					AND WFStatus = 'Completed'

				IF (@ClosedDate > @PDMPARTYDATE)
				BEGIN
					SELECT @RC_Count = 1
				END
			END

			IF (@RC_Count = 0)
			BEGIN
				IF (
						(
							@CHECKYR = @ChkCrYr
							AND @CHECKMONTH = @ChkCrMonth
							)
						OR (
							@CHECKYR = @ChkMoYr
							AND @CHECKMONTH = @ChkMoMonth
							AND @ChkMoYr IS NOT NULL
							AND @ChkMoMonth IS NOT NULL
							)
						)
				BEGIN
					SELECT @RC_Count = 0
				END
				ELSE
				BEGIN
					SELECT @RC_Count = 1
				END
			END
			
			IF (@RC_Count = 0)
			BEGIN
				/**********WatchedPartyName******************/
				SELECT @WatchedPartyName = NAME
					,@WatchedPartyType = Type
				FROM KYP.PDM_Party
				WHERE PartyID = @PartyID
					AND CurrentModule = 2
					AND IsDeleted <> 1

				/*****Getting the Medicaid ID*************/
				IF @WatchedPartyType = 'Organization'
				BEGIN
					SET @WatchedPartyType = 'Institutional'
				END
				ELSE IF @WatchedPartyType = 'Person'
				BEGIN
					SET @WatchedPartyType = 'Individual'
				END
				
				--Commented for #2
				--SELECT TOP 1 @AlertNumber = AlertNo
				--FROM KYP.MDM_Alert ORDER BY convert(bigint,AlertNo) DESC
				
				--Added for #2
				SELECT @AlertNumber = MAX(Convert(Bigint,AlertNo))
				FROM KYP.MDM_Alert
								
				IF @AlertNumber IS NULL
					SELECT @AlertNumber = '40001'
				ELSE
					SELECT @AlertNumber = convert(VARCHAR(15), convert(INT, @AlertNumber) + 1)
				
				--Added for the Alert Generation Fix
				/*#1 Start Alert Generation Fix*/				
				Select @AssignedUnAssignedAlertCount = Count(1)
				from KYP.MDM_Alert A
				Left Join KYP.MDM_AlertResolution AR on A.AlertID=AR.AlertID
				where A.WatchedPartyID = @PartyID 
				and A.IsMerged='N'
				and (A.AssignedToUserID is null
					or (A.AssignedToUserID is not null
						and A.ActivityStatus<>'Completed'
						and AR.AlertID is null
						)
					)
				
				IF @AssignedUnAssignedAlertCount > 0
				BEGIN
					EXEC @AlertID = [KYP].[p_InsertMDMAlert] @AlertNo = @AlertNumber
						--Made StatusCodeNumber to 0 for resolving the issue KYP-17093
						--Status Code Number = 0 is not used any where.
						,@StatusCodeNumber = 0
						,@CurrentMajorDisposition = 'Initial Assignment'
						,@CurrentMinorDisposition = 'Unassigned'
						,@CurrentWFMinorStatus = 'Assign Alert'
						,@CurrentWFStatus = 'AssignAlert'
						,@DateInitiated = @now
						,@WatchlistName = @WatchlistName
						,@MatchPercent = @MatchPercentage
						,@WatchedPartyID = @PartyID
						,@WatchedPartyName = @WatchedPartyName
						,@WatchedPartyType = @WatchedPartyType
						,@MatchStatusIndicator = 'U'
						,@MatchStatusIndicatorDescription = 'Unconfirmed'
						,@ActivityStatus = 'Not Started'
						,@CreatedDate = @now
						,@IsDeleted = 0
						,@MedicaidID = @MedicaidID
						,@isTwoWayMatch = @isTwoWayMatch
						,@NPIAlertType = @NPIAlertType
						,@WFStatus = 'Assign Alert'
						,@WFMajorDisposition = 'Assign Alert'
						,@WFMinorDisposition = 'Pending Initial Assignment'
						,@GK_WL_Id = @gateKeeperId
						,@IsMerged = 'Y'
				
				END
				ELSE
				BEGIN
				/*#1 End Alert Generation Fix*/
					EXEC @AlertID = [KYP].[p_InsertMDMAlert] @AlertNo = @AlertNumber
						--Made StatusCodeNumber to 0 for resolving the issue KYP-17093
						--Status Code Number = 0 is not used any where.
						,@StatusCodeNumber = 0
						,@CurrentMajorDisposition = 'Initial Assignment'
						,@CurrentMinorDisposition = 'Unassigned'
						,@CurrentWFMinorStatus = 'Assign Alert'
						,@CurrentWFStatus = 'AssignAlert'
						,@DateInitiated = @now
						,@WatchlistName = @WatchlistName
						,@MatchPercent = @MatchPercentage
						,@WatchedPartyID = @PartyID
						,@WatchedPartyName = @WatchedPartyName
						,@WatchedPartyType = @WatchedPartyType
						,@MatchStatusIndicator = 'U'
						,@MatchStatusIndicatorDescription = 'Unconfirmed'
						,@ActivityStatus = 'Not Started'
						,@CreatedDate = @now
						,@IsDeleted = 0
						,@MedicaidID = @MedicaidID
						,@isTwoWayMatch = @isTwoWayMatch
						,@NPIAlertType = @NPIAlertType
						,@WFStatus = 'Assign Alert'
						,@WFMajorDisposition = 'Assign Alert'
						,@WFMinorDisposition = 'Pending Initial Assignment'
						,@GK_WL_Id = @gateKeeperId				
				END 				--#1 Added for the Alert Generation Fix
				
				EXEC [KYP].[p_InsertMDMAlertDetail] @AlertID = @AlertID
					,@FName = @FirstName
					,@MName = @MiddleName
					,@LName = @Lastname
					,@OrganizationName = @Orgname
					,@AliasName = @AliasName
					,@SSN = @SSN
					,@TAXID = @TAX_ID
					,@DOB = @DOB
					,@LicenseNo = @License_Number
					,@NPI = @NPI
					,@DEA = @DEA
					,@DBAName = NULL
					,@LegalName = @Orgname
					,@OwnerName = NULL
					,@CreatedDate = @now
					,@IsDeleted = 0
					,@UPIN = @UPIN
					,@HMS_PIID = @HMS_PIID
					,@HMS_POID = @HMS_POID
					,@LoadID = @LoadID
					,@LoadType = @LoadType
					,@LastLoadDate = @LastLoadDate
					,@EPLS_TermDate = @EPLS_TermDate
					,@EPLS_ActionDate = @EPLS_ActionDate
					,@EPLS_Agency = @EPLS_Agency
					,@LEIE_EXCLType = @LEIE_EXCLType
					,@LEIE_EXCLDate = @LEIE_EXCLDate
					,@LEIE_REINDATE = @LEIE_REINDATE
					,@Offense_Code = @Offense_Code
					,@Offense_Date = @Offense_Date
					,@Offense_Description = @Offense_Description
					,@Board_Code = @Board_Code
					,@Board_Description = @Board_Description
					,@Action_Date = @Action_Date
					,@Action_Code = @Action_Code
					,@Action_Description = @Action_Description
					,@Sanc_PeriodStartDt = @Sanc_PeriodStartDt
					,@Sanc_PeriodEndDt = @Sanc_PeriodEndDt
					,@Sanc_FineAmt = @Sanc_FineAmt
					,@License_State = @License_State
					,@License_Type = @License_Type
					,@License_Status = @License_Status
					,@License_Start_Date = @License_Start_Date
					,@License_Expire_Date = @License_Expire_Date
					,@DEA_RANK = @DEA_RANK
					,@DEA_Expire = @DEA_Expire
					,@DEA_Active = @DEA_Active
					,@UniqueKey = @UniqueKey
					,@DOD = @DOD
					,@MCSIS_ID = @MCSIS_ID
					,@WatchlistPartyID = @WatchlistPartyid
					,@AlertGenCriteria = @AlertGenCriteria
					,@TerminationEffectiveDate = @TerminationEffectiveDate --Added for #4 CAPAVE-254
					,@TerminationImportDate = @TerminationImportDate --Added for #4 CAPAVE-254	
					,@AdditionalComments = @AdditionalComments --Added for #4 CAPAVE-254					

				/************** Loading data in MDM_AlertExtnAddress**********************/
				EXEC @AddressID = [KYP].[p_InsertMDMAlertExtnAddress] @AlertID = @AlertID
					,@AddressLine1 = @AddressLine1
					,@AddressLine2 = @AddressLine2
					,@County = 'US'
					,@City = @City
					,@Zip = @Zip
					,@ZipPlus4 = @ZIP4
					,@State = @State
					,@Country = 'US'
					,@CreatedDate = @now
					,@IsDeleted = 0

				/*******************Loading data in MDM_AlertExtnLocation*********************/
				EXEC [KYP].[p_InsertMDMAlertExtnLocation] @AlertID = @AlertID
					,@AddressID = @AddressID
					,@Type = NULL
					,@State = @state
					,@CreatedDate = @now
					,@IsDeleted = 0
			END

			COMMIT TRAN LoadAlertData
		END TRY

		BEGIN CATCH
			IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRAN LoadAlertData
			END
			
			--Added the Insert Statement for #2
			INSERT INTO [dbo].[AlertGenerationErrors] (
				[ERNumber]
				,[Error_Severity]
				,[Error_State]
				,[Error_Procedure]
				,[Error_Line]
				,[Error_Message]
				,[Error_Time]
				--,AlertID
				)
				VALUES (ERROR_NUMBER()
					,ERROR_SEVERITY()
					,ERROR_STATE()
					,ERROR_PROCEDURE()
					,ERROR_LINE()
					,ERROR_MESSAGE()
					,GETDATE()
					--,@CurrentAlert
					)			
		END CATCH

		SELECT @CurrentAlert = MIN(MDM_InterID)
		FROM KYP.MDM_StageAlerts
		WHERE MDM_InterID > @CurrentAlert
	END

	--Shifted the below block of statements outside the loop for #2
	--CP-34 start
	begin
		Declare @AlertCreatedDate datetime

		select  Top 1 @AlertCreatedDate=fileloaddate from kyp.MDM_MonthlyActiveProvider order by ID desc
		
		INSERT into   KYPEnrollment.pAccount_History (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
		select distinct A.AlertID,Acc.AccountID,'53' ,A.CreatedDate,'System',GETDATE() ,'1' 
		from kyp.MDM_Alert A 
		inner join  KYP.MDM_SearchProviders PR on PR.AlertID =A.AlertID
		--inner join  dbo.pADM_AccProvMapping  AP on AP.AccountNumber=PR.MedicaidID
		inner join KYPEnrollment.pADM_Account Acc on Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode=PR.MedicaidID 
		where A.IsMerged='N'   and A.CreatedDate>=@AlertCreatedDate
			

		INSERT into   KYPEnrollment.pAccount_History (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
		select distinct A.AlertID,Acc.AccountID,'53' ,A.CreatedDate,'System',GETDATE() ,'1' 
		from kyp.MDM_Alert A 
		inner join KYP.MDM_RelatedAlerts RA on RA.ChildAlertID=A.AlertID and  RA.MergedByUserID=1
		inner join  KYP.MDM_SearchProviders PR on PR.AlertID =RA.ParentAlertID
		--  inner join  dbo.pADM_AccProvMapping  AP on AP.AccountNumber=PR.MedicaidID
		inner join KYPEnrollment.pADM_Account Acc on Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode=PR.MedicaidID 
		where A.CreatedDate>=@AlertCreatedDate
			
		INSERT into KYPEnrollment.HIS_Alert (AccountID,HistoryID,AlertNumber,MonStatus,MonRelevance,CreatedBy,DateCreate,WatchlistCategory,AlertPartyName) 
		select distinct AH.AccountID,AH.HistoryID,A.AlertNo,A.MatchStatusIndicatorDesc, A.Priority,'System',A.CreatedDate,A.WatchlistName,A.WatchedPartyName
		from kyp.MDM_Alert A 
		inner join KYPEnrollment.pAccount_History AH on AH.RelatedID=A.AlertID   and ActionID='53'
		where A.CreatedDate>=@AlertCreatedDate
		
	end 

	--CP-34 end

	ALTER TABLE KYP.MDM_Alert ENABLE TRIGGER trg_MDM_AlertOnUpdate
END
GO

