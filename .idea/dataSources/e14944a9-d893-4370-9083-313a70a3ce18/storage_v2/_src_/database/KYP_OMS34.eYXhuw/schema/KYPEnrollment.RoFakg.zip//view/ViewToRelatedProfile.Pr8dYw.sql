



-- =============================================

-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================

CREATE VIEW [KYPEnrollment].[ViewToRelatedProfile]
AS
select --(row_number() over ( order by r.CaseID)) AS ViewID, 
r.Caseid as Viewid,
r.*
from
-- for individual
(
	select 
	DISTINCT sap.PartyID,
	ca.CaseID,
	ca.IsPPURequired AS IsPPURequired,
	ISNULL(ca.WFStatus,'') As WFStatus,
	app.ApplicationID,
	app.Status,
	ca.Number as ApplicationNumber,
	ca.Number as ProviderNumber,
	ca.ProviderName as Name,
	ca.ApplnTypeAlias as ApplicationType,
	ca.MILESTONE as Milestone, 
	pps.NPI, 
	ISNULL(ca.Provider_SSN,'') as SSN,
	ISNULL(ca.Provider_TIN,'') as TIN,
	ISNULL(AD.AddressLine1 ,'') + ', ' + ISNULL(AD.AddressLine2 ,'') + ', ' + ISNULL(AD.City ,'')+', ' + ISNULL(ad.statecode ,'') + ', ' + ISNULL(AD.ZipPlus4 ,'') +  ', ' + ISNULL(AD.County,'') as PracticeAddress,	
	ca.TypeDescription as ProviderType, 
	'' as StatusLinked
	,
	(ISNULL((Select Substring((Select ',' + CONVERT(VARCHAR(15), CaseIDA) From 
	KYPEnrollment.Linked_ADM_Case where CaseIDM=cas.CaseID and StatusLinked='Link' For XML Path('')),2,8000) 
	From KYP.ADM_Case as cas WHERE cas.CaseID = ca.CaseID),'A')) as CaseIDLinked,
	ca.WFStatus Filter
	from KYP.PDM_Party pp
	INNER JOIN KYP.PDM_Provider as pps ON pps.PartyID=pp.PartyID
	INNER JOIN (KYP.SDM_ApplicationParty as sap 
	INNER JOIN (KYP.ADM_Application as app 
	INNER JOIN KYP.ADM_Case as ca ON ca.CaseID=app.CaseID) 
	ON app.ApplicationID=sap.ApplicationID and (app.IsDeleted is null or app.IsDeleted='false')) 
	ON sap.PartyID=pp.PartyID  and (sap.IsDeleted is null or sap.IsDeleted='false') 
	AND (sap.isActive = 1 OR ca.CrossOverApp = 'X' )
	Left Join [KYP].[View_AllAddresses] AD on AD.ApplicationNo = ca.Number and AD.Type='Servicing'
	where sap.PartyType='Provider' AND ISNULL(ca.WFStatus,'') <> '' 
	AND ca.IsPPURequired=0 AND ca.WFProcessing=0
) r


GO

