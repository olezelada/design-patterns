-- =============================================
-- Author:		<Sheetal>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[createAssignToOther] @AlertNo VARCHAR(MAX)
	,@JournalEvent VARCHAR(50)
	,@Username VARCHAR(25)
	,@AssignToUserID INT
	,@RelatedEntityType VARCHAR(50)
	,@NotesDescription VARCHAR(max)
	,@NotesTitle VARCHAR(120)
	,@Number VARCHAR(20)
	,@Currenttag VARCHAR(5)
	,@Type VARCHAR(100)
	,@SubType VARCHAR(100)
	,@AssignMode VARCHAR(100)
	,@FormattedContent VARCHAR(MAX)
AS
BEGIN
	DECLARE @AlertID INT
		,@Description VARCHAR(500)
		,@PersonID INT
		--,@FirstName VARCHAR(25)
		--,@LastName VARCHAR(25)
		,@Name VARCHAR(100)
		,@CurrentDate DATETIME
		,@JournalDescription VARCHAR(250)
		,@FullName VARCHAR(200)
		,@index INT
		,@sliceOfStringValue VARCHAR(2000)
		,@StringValue VARCHAR(max)
		,@Delimiter CHAR(1)
		--,@FullNameMail VARCHAR(500)
		,@NoteID INT
		,@Notenumber VARCHAR(15)
		--,@NoteEntityType VARCHAR(100)
		--,@NoteEntityTypeID VARCHAR(100)
		--,@NoteEntityDepID VARCHAR(100)
		--,@NoteEntityDep VARCHAR(100)
		--,@Level INT
		,@SmartletParameter VARCHAR(500)
		--,@IsLastLevel BIT
		,@RelatedEntityID INT
		,@CaseID INT
		,@IsExistID INT
		,@NoteCount INT
		,@AcceptanceCode INT
		--,@body NVARCHAR(MAX)
		--,@EmailAddTo VARCHAR(500)
		--,@EmailAddCC VARCHAR(500)
		--,@Sub VARCHAR(MAX)
		--,@ALIASNAME VARCHAR(100)
	DECLARE @AlertIDTable TABLE (AllParentChildAlerts INT)

	--SELECT @PersonID = PersonID, @FullName = FullName, @Name=FullName	
	--FROM KYP.OIS_User WHERE UserID = @Username
	SELECT @PersonID = PersonID
	FROM KYP.OIS_User
	WHERE UserID = @Username

	SELECT @FullName = FullName
	FROM KYP.OIS_User
	WHERE PersonID = @AssignToUserID

	SELECT @Name = LastName + COALESCE((', ' + FirstName), '')
	FROM KYP.OIS_Person
	WHERE PersonID = @PersonID

	/****
Yogesh

Only one call is sufficient
--	SELECT @FullName = FullName	FROM KYP.OIS_User WHERE PersonID = @AssignToUserID


***/
	--SELECT 
	----@FirstName = FirstName, 
	----@LastName = LastName, 
	--@Name = LastName + COALESCE((', ' + FirstName), '') FROM KYP.OIS_Person WHERE PersonID = @PersonID
	/****
Yogesh

Above section is not needed as FullName from OIS_User is sufficient

***/
	SELECT @CaseID = NULL
		,@CurrentDate = GETDATE()
		,@Description = 'Alert acknowledged by' + ' ' + @Name
		,@StringValue = @AlertNo
		,@Delimiter = ','
		,@IsExistID = 0
		,@NoteCount = 0

	/* changed */
	--insert into @AlertIDTable
	--Select AlertID from KYP.MDM_Alert with(nolock) where AlertID=@RelatedEntityID
	--union all
	--Select ChildAlertID from KYP.MDM_RelatedAlerts with(nolock) where ParentAlertID=@RelatedEntityID 
	--and RelationshipType='Merged' and ISNULL(IsDeleted, 0) = 0
	SELECT @index = 1

	WHILE @index <> 0
	BEGIN
		SELECT @index = CHARINDEX(@Delimiter, @StringValue)

		IF @index <> 0
		BEGIN
			SELECT @sliceOfStringValue = left(@StringValue, @index - 1)
		END
		ELSE
			SELECT @sliceOfStringValue = @StringValue

		IF (LEN(@sliceOfStringValue) > 0)
			SELECT @StringValue = right(@StringValue, LEN(@StringValue) - @index)

		IF LEN(@StringValue) = 0
			BREAK

		SELECT @AlertID = AlertID
		FROM KYP.MDM_Alert WITH (NOLOCK)
		WHERE AlertNo = @sliceOfStringValue

		DELETE
		FROM @AlertIDTable

		INSERT INTO @AlertIDTable
		SELECT AlertID
		FROM KYP.MDM_Alert WITH (NOLOCK)
		WHERE AlertID = @AlertID
		
		UNION ALL
		
		SELECT ChildAlertID
		FROM KYP.MDM_RelatedAlerts WITH (NOLOCK)
		WHERE ParentAlertID = @AlertID
			AND RelationshipType = 'Merged'
			AND ISNULL(IsDeleted, 0) = 0

		IF @AssignMode = '2'
		BEGIN
			SET @AcceptanceCode = 10
		END
		ELSE
		BEGIN
			SET @AcceptanceCode = 9
		END

		IF @JournalEvent = 'Team-Reassign'
		BEGIN
			IF @AssignToUserID IS NOT NULL
			BEGIN
				DECLARE @suspendedStatus VARCHAR(50);

				SELECT @suspendedStatus = ActivityStatus
				FROM kyp.MDM_Alert
				WHERE AlertID = @AlertID

				IF (@suspendedStatus <> 'Suspended')
				BEGIN
					UPDATE KYP.MDM_Alert
					SET AssignedByUserID = @PersonID
						,AssignedToUserID = @AssignToUserID
						,AssignedDate = GETDATE()
						,Assignee = @FullName
						,StatusCodeNumber = @AcceptanceCode
						,GenNo = 4
					WHERE AlertID IN (
							SELECT AllParentChildAlerts
							FROM @AlertIDTable
							)
				END
				ELSE IF (@suspendedStatus = 'Suspended')
				BEGIN
					DECLARE @D_ExisingHistory INT
						--,@D_StartDateTime DATETIME
						,@D_CheckSuspended VARCHAR(100);

					SELECT TOP 1 @D_ExisingHistory = ID
						--,@D_StartDateTime = [DateTime]
						,@D_CheckSuspended = ActivityStatus
					FROM KYP.MDM_WorkflowHistory
					WHERE ActivityStatus IN (
							'Escalated'
							,'Consulted'
							)
						AND AlertID = @AlertID
						AND [TYPE] = 'HISTORY'
					ORDER BY ID DESC

					IF @D_ExisingHistory IS NOT NULL
						AND @D_ExisingHistory <> ''
					BEGIN
					
						DECLARE @D_ExisingHistory1 INT
						SELECT TOP 1 @D_ExisingHistory1 = ID
							--,@D_StartDateTime = [DateTime]
							,@D_CheckSuspended = ActivityStatus
						FROM KYP.MDM_WorkflowHistory
						WHERE ActivityStatus IN (
								'Reverted'
								)
							AND AlertID = @AlertID
							AND [TYPE] = 'HISTORY'
							AND ID > @D_ExisingHistory
						ORDER BY ID DESC
						
						IF @D_ExisingHistory1 IS NOT NULL
							AND @D_ExisingHistory1 <> ''
						BEGIN
							UPDATE KYP.MDM_Alert
							SET AssignedByUserID = @PersonID
								,AssignedToUserID = @AssignToUserID
								,AssignedDate = GETDATE()
								,Assignee = @FullName
								,StatusCodeNumber = @AcceptanceCode
								,GenNo = 4
								,ActivityStatus = 'Open'
							WHERE AlertID IN (
									SELECT AllParentChildAlerts
									FROM @AlertIDTable
									)
						END
						ELSE
						BEGIN
							UPDATE KYP.MDM_Alert
							SET AssignedByUserID = @PersonID
								,AssignedToUserID = @AssignToUserID
								,AssignedDate = GETDATE()
								,Assignee = @FullName
								,StatusCodeNumber = @AcceptanceCode
								,GenNo = 4
								,ActivityStatus = @D_CheckSuspended
							WHERE AlertID IN (
									SELECT AllParentChildAlerts
									FROM @AlertIDTable
									)
						END
					END
					ELSE
					BEGIN
						UPDATE KYP.MDM_Alert
						SET AssignedByUserID = @PersonID
							,AssignedToUserID = @AssignToUserID
							,AssignedDate = GETDATE()
							,Assignee = @FullName
							,StatusCodeNumber = @AcceptanceCode
							,GenNo = 4
							,ActivityStatus = 'Open'
						WHERE AlertID IN (
								SELECT AllParentChildAlerts
								FROM @AlertIDTable
								)
					END
				END
				/* CAPAVE-1002 BEGIN
				Description :Updating the time of the Alert after its reassigned where activityStatus is In Progress
				*/
				Update kyp.MDM_WorkflowHistory set DateTime =GETDATE() where ActivityStatus='In Progress' and AlertID=@AlertID
			
				--CAPAVE-1002 END
			END
			ELSE
			BEGIN
				IF (@SubType = 'Not Assigned')
				BEGIN
					UPDATE KYP.MDM_Alert
					SET StatusCodeNumber = 12
						,AssignedByUserID = @PersonID
						,AssignedToUserID = NULL
						,AssignedDate = GETDATE()
						,Assignee = NULL
					WHERE AlertID IN (
							SELECT AllParentChildAlerts
							FROM @AlertIDTable
							)
				END
				ELSE
				BEGIN
					UPDATE KYP.MDM_Alert
					SET StatusCodeNumber = @AcceptanceCode
						,AssignedByUserID = NULL
						,AssignedToUserID = NULL
						,AssignedDate = NULL
						,CurrentWFMinorStatus = 'Accept Assignment'
						,CurrentMinorDisposition = 'Assigned'
						,CurrentMajorDisposition = 'Initial Assignment'
						,CurrentWFStatus = 'AcceptAssignment'
						,ActivityStatus = 'Open'
					WHERE AlertID IN (
							SELECT AllParentChildAlerts
							FROM @AlertIDTable
							)
				END
			END
		END

		SELECT @RelatedEntityID = @AlertID

		IF (@FormattedContent IS NULL)
		BEGIN
			SET @FormattedContent = @NotesDescription
		END

		INSERT INTO [KYP].[OIS_Note] (
			[UserID]
			,[Name]
			,[Type]
			,[SubType]
			,ParentID
			,[DateCreated]
			,[Author]
			,[RelatedEntityType]
			,[Content]
			,[UnformattedContent]
			,[Number]
			,[VersionNo]
			,[isWorkpaper]
			,[isAcknowledged]
			,[isAdverse]
			,[Deleted]
			,[IsImportant]
			,[IsLastVersion]
			,[IsSticky]
			,[IsReferenced]
			,[HasComments]
			,[HasDocuments]
			,[NumberSchemaInfo]
			,[LastVersion]
			,[AllowComments]
			,[RelatedEntityID]
			,[Importance]
			,[Score]
			)
		VALUES (
			@Username
			,@NotesTitle
			,@Type
			,@SubType
			,0
			,@CurrentDate
			,@Name
			,@RelatedEntityType
			,@FormattedContent
			,@NotesDescription
			,@Number
			,1
			,0
			,0
			,0
			,0
			,1
			,0
			,0
			,0
			,0
			,0
			,@Number
			,1
			,0
			,@RelatedEntityID
			,'Low'
			,0
			)

		SELECT @NoteID = SCOPE_IDENTITY()
		
		 exec [KYP].[p_GenerateNoteNumber] @NoteID,
				  @Notenumber=@Notenumber output
    
			 /******* Updating note number in OIS_Note***********/ 
				update KYP.OIS_Note set Number= @Notenumber where NoteID= @NoteID

		--IF @Currenttag IS NULL
		--BEGIN
		--	INSERT INTO [KYP].[OIS_Tag] ([Tag])
		--	VALUES (',')
		--END
		--INSERT INTO [KYP].[OIS_JT_NoteTag] (
		--	[NoteID]
		--	,[Tag]
		--	)
		--VALUES (
		--	@NoteID
		--	,','
		--	)
		----Get the notenumber------
		--EXEC [KYP].[p_GenerateNoteNumber] @Notenumber = @Notenumber OUTPUT
		--/******* Updating note number in OIS_Note***********/
		--UPDATE KYP.OIS_Note
		--SET Number = @Notenumber
		--WHERE NoteID = @NoteID
		/****
Yogesh

The above section is not needed for the same reason as CreateComplete WorkFlow

***/
		/********Creating Journal entry********************/
		SELECT @JournalDescription = 'Notes Added-' + ' ' + @Type + ' ' + @Notenumber + ' ' + 'was added to' + ' ' + @RelatedEntityType

		INSERT INTO [KYP].[OIS_Journal] (
			[UserID]
			,[ACTIONID]
			,[Date_x]
			,[DESCRIPTION]
			,[EntityTable]
			,[Entity]
			,[EntityID]
			,[CaseID]
			,[ShortDescription]
			)
		VALUES (
			@Username
			,1
			,@CurrentDate
			,@JournalDescription
			,'OIS_Note'
			,'Note'
			,@NoteID
			,@CaseID
			,@JournalDescription
			)

		/**********Segregate the smartlet parameter for noteentity entry************/
		--SELECT @SmartletParameter = 'MDM_Alert-' + convert(VARCHAR(10), @AlertNo)
		-- Changed for PI-500(Supervisor user is not able to re-assign the multiple alerts from the Team queue)
		SELECT @SmartletParameter = 'MDM_Alert-' + convert(VARCHAR(10), @sliceOfStringValue)


		--SELECT @NoteEntityType = NoteEntityType
		--	,@NoteEntityTypeID = NoteEntityTypeID
		--	,@NoteEntityDepID = NoteEntityDepID
		--	,@NoteEntityDep = NoteEntityDep
		--	,@Level = LEVEL
		--	,@IsLastLevel = IsLastLevel
		--FROM simple_intlist_to_tbl(@SmartletParameter)
		/********Insert into Noteentity*************/
		INSERT INTO [KYP].[NoteEntity] (
			[NoteNumber]
			,[NoteEntityType]
			,[NoteEntityDep]
			,[NoteEntityTypeID]
			,[NoteEntityDepID]
			,[Level]
			,[IsLastLevel]
			)
		SELECT @Notenumber
			,NoteEntityType
			,NoteEntityDep
			,NoteEntityTypeID
			,NoteEntityDepID
			,LEVEL
			,IsLastLevel
		FROM simple_intlist_to_tbl(@SmartletParameter)

		SELECT @IsExistID = ParentID
		FROM KYP.NoteCounts WITH (NOLOCK)
		WHERE ParentID = @RelatedEntityID
			AND ParentTable = @RelatedEntityType

		SELECT @NoteCount = count(RelatedEntityID)
		FROM KYP.OIS_Note WITH (NOLOCK)
		WHERE RelatedEntityID = @RelatedEntityID
			AND RelatedEntityType = @RelatedEntityType
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)

		IF @IsExistID = 0
		BEGIN
			INSERT INTO [KYP].[NoteCounts] (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@RelatedEntityID
				,@RelatedEntityType
				,@NoteCount
				)
		END
		ELSE
		BEGIN
			UPDATE [KYP].[NoteCounts]
			SET [ParentID] = @RelatedEntityID
				,[ParentTable] = @RelatedEntityType
				,[Counts] = @NoteCount
			WHERE ParentID = @RelatedEntityID
				AND ParentTable = @RelatedEntityType
		END --if @IsExistID

		------Insert into journal---------
		SET NOCOUNT ON;

		INSERT INTO KYP.MDM_AlertJournal
		SELECT AlertID
			,'Business Event'
			,@Description
			,GETDATE()
			,NULL
			,GETDATE()
			,@PersonID
			,NULL
			,NULL
			,NULL
			,NULL
			,0
		FROM KYP.MDM_Alert WITH (NOLOCK)
		WHERE AlertID = @AlertID
		
		UNION ALL
		
		SELECT ChildAlertID
			,'Business Event'
			,@Description
			,GETDATE()
			,NULL
			,GETDATE()
			,@PersonID
			,NULL
			,NULL
			,NULL
			,NULL
			,0
		FROM KYP.MDM_RelatedAlerts WITH (NOLOCK)
		WHERE ParentAlertID = @AlertID
			AND RelationshipType = 'Merged'
			AND ISNULL(IsDeleted, 0) = 0

		/****
Yogesh

With(nolock) has been added above and the portion has been moved down

***/
		SELECT @IsExistID = 0

		SELECT @NoteCount = 0
	END -- End WHILE
END
PRINT 'db_objects/03_STORED_PROCEDURES/028_DDL_sp_p_LoadAlertData.sql'
PRINT 'db_objects/03_STORED_PROCEDURES/003_DDL_p_UpdateAlertonAccount.sql'
GO

