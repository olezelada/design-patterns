


CREATE PROCEDURE [KYPEnrollment].[sp_RelatedAccountPopulationForSubmittedApplication_New]
AS
BEGIN

	DELETE FROM KYPEnrollment.RelatedAccount;

	INSERT INTO KYPEnrollment.RelatedAccount(AccountID,ApplicationNumber,IsGroupOrRendering)
		SELECT ACC.AccountID,Number,0 -- 136553
			FROM KYPEnrollment.pADM_Account ACC
			JOIN (SELECT PartyID,LOC.AddressID,Number,ILV.Type,ILV.AddressLine1,ILV.State,ILV.City
					FROM KYPEnrollment.pAccount_PDM_Location LOC
					JOIN (SELECT DISTINCT AddressID,Number,A.AddressLine1,A.City,A.State,Type
							FROM (SELECT Number,SUBSTRING(AddressLine1,1,10) AS AddressLine1,City,State,PA.Type
									FROM KYPEnrollment.PortalAddress PA
									JOIN KYP.ADM_Case C
									ON PA.EnrollCaseID	= C.CaseID AND
									   PA.Type			IN('Mailing','Pay-to','Servicing')
									WHERE ApplnType		NOT IN('Disaffiliation','Rendering-S')) A
							JOIN (SELECT AddressID,SUBSTRING(AddressLine1,1,10) AS AddressLine1,City,State,AddressType
									FROM KYPEnrollment.pAccount_PDM_Address
									WHERE AddressType	IN('Mailing','Pay-to','Servicing')) B
							ON	A.AddressLine1	= B.AddressLine1 AND
								A.State			= B.State AND
								A.City			= B.City AND
								A.Type			= B.AddressType) ILV
					ON LOC.AddressID = ILV.AddressID) ILV
			ON ACC.PartyID = ILV.PartyID
			WHERE ACC.IsDeleted = 0 --38
		UNION
		-- 15253
		SELECT ACC.AccountID,Number,0 --,Provider_NPI,Provider_SSN,Provider_TIN,B.NPI,B.SSN,B.EIN
			FROM KYP.ADM_CASE C
			JOIN KYPEnrollment.pADM_Account ACC
			ON C.Provider_NPI = ACC.NPI -- 3953
			WHERE ACC.IsDeleted = 0
		UNION
		SELECT ACC.AccountID,Number,0 --,Provider_NPI,Provider_SSN,Provider_TIN,B.NPI,B.SSN,B.EIN
			FROM KYP.ADM_CASE C
			JOIN KYPEnrollment.pADM_Account ACC
			ON C.Provider_SSN = ACC.SSN	-- 3159
			WHERE ACC.IsDeleted = 0
			-- and Provider_SSN NOT IN('123456789','111111111','555555555','444444444','777777777','222222222','666666666','999999999','333333333','888888888','111223333')
		UNION
		SELECT ACC.AccountID,Number,0 --,Provider_NPI,Provider_SSN,Provider_TIN,B.NPI,B.SSN,B.EIN
			FROM KYP.ADM_CASE C
			JOIN KYPEnrollment.pADM_Account ACC
			ON C.Provider_TIN = ACC.EIN
			WHERE PROVIDER_TIN	IS NOT NULL	AND
				  ACC.EIN		IS NOT NULL	AND -- 12071
				  ACC.IsDeleted = 0
		UNION
		SELECT RA.AffiliatedAccountID,ILV1.Number,1
			FROM KYPEnrollment.pAccount_RenderingAffiliation RA
			JOIN (SELECT AccountID,Number,AccountNumber
					FROM KYPEnrollment.pADM_Account ACC
					JOIN (SELECT Number
							FROM KYP.ADM_CASE C
							WHERE ApplnType = 'New Group') ILV
					ON ACC.ApplicationNumber = ILV.Number
					WHERE ACC.IsDeleted = 0) ILV1
			ON RA.AccountID = ILV1.AccountID
			WHERE RA.AccountID			IS NOT NULL AND
				  RA.CurrentRecordFlag	= 1 AND
				  RA.IsDeleted			= 0
		UNION
		SELECT RA.AccountID,ILV1.Number,1
			FROM KYPEnrollment.pAccount_RenderingAffiliation RA
			JOIN (SELECT AccountID,Number,AccountNumber
					FROM KYPEnrollment.pADM_Account ACC
					JOIN (SELECT Number
							FROM KYP.ADM_CASE C
							WHERE ApplnType = 'New Rendering') ILV
					ON ACC.ApplicationNumber = ILV.Number
					WHERE ACC.IsDeleted = 0) ILV1
			ON RA.AffiliatedAccountID = ILV1.AccountID
			WHERE RA.AccountID			IS NOT NULL AND
				  RA.CurrentRecordFlag	= 1 AND
				  RA.isDeleted			= 0
		UNION
		SELECT RA.AccountID,ILV1.Number,1
			FROM KYPEnrollment.pAccount_RenderingAffiliation RA
			JOIN (SELECT AccountID,Number,AccountNumber
					FROM KYPEnrollment.pADM_Account ACC
					JOIN (SELECT Provider_NPI,ProviderTypeCode,Number
							FROM KYP.ADM_CASE C
							WHERE ApplnType = 'Rendering-S') ILV
					ON ACC.NPI = ILV.Provider_NPI AND
					   ACC.ProviderTypeCode = ILV.ProviderTypeCode
					WHERE ACC.IsDeleted = 0) ILV1
			ON RA.AffiliatedAccountID = ILV1.AccountID
			WHERE RA.AccountID			IS NOT NULL AND
				  RA.CurrentRecordFlag	= 1 AND
				  RA.isDeleted			= 0
		UNION
		SELECT ACC.AccountID,Number,0
			FROM KYPEnrollment.pADM_Account ACC
			JOIN (SELECT DISTINCT PartyID,A.Number,LicenseType,License
					FROM (SELECT Number, LicenseType, License
							FROM KYPEnrollment.PortalLicense PL
							JOIN KYP.ADM_Case C
							ON PL.EnrolCaseID	= C.CaseID
							WHERE LicenseType = 'Professional License') A
					JOIN (SELECT PartyID,Type,Number
							FROM KYPEnrollment.pAccount_PDM_Number
							WHERE IsDeleted			= 0 AND
								  CurrentRecordFlag = 1 AND
								  Type				= 'Professional License') B
					ON	A.LicenseType	= B.Type AND
						A.License		= B.Number) ILV
			ON ACC.PartyID = ILV.PartyID
			WHERE ACC.IsDeleted = 0
		ORDER BY Number

	UPDATE KYPEnrollment.RelatedAccount
		SET NPI					= ACC.NPI,
			SSN					= ACC.SSN,
			TaxID				= ACC.EIN,
			AccountNumber		= ACC.AccountNumber,
			EnrollmentStatus	= ACC.StatusAcc,
			ProviderName		= ACC.LegalName,
			StatusEffectiveDate	= ACC.StatusBeginDate,
			AccountType			= CASE WHEN ACC.AccountType = 'UNK' THEN 'Unknown'
									ELSE
										ACC.AccountTypeDescriptor -- ACC.AccountType
									END,
			CurrentRecordFlag	= 1,
			DateCreated			= GETDATE(),
			CreatedBy			= 'System'
		FROM KYPEnrollment.RelatedAccount RA
		JOIN KYPEnrollment.pADM_Account ACC
		ON RA.AccountID = ACC.AccountID
-----improve for KEN-14528 Q 7
/*	UPDATE KYPEnrollment.RelatedAccount
		SET ServiceAddress = ILV.FullAddress
		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT DISTINCT ACC.AccountID,[KYPEnrollment].[MultipleColumnsValueintoSingleString](ADR.AddressLine1,ADR.AddressLine2,City,State,County,ZipPlus4) AS FullAddress
				FROM Kypenrollment.RelatedAccount RA
				JOIN KYPEnrollment.pADM_Account ACC
				ON RA.AccountID	= ACC.AccountID
				JOIN KYPEnrollment.pAccount_PDM_Location LOC
				ON ACC.PartyID = LOC.PartyID
				JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON LOC.AddressID = ADR.AddressID
				WHERE LOC.Type		  = 'Servicing' AND
					  ACC.IsDeleted	  = 0) ILV
			ON RA.AccountID	= ILV.AccountID
			*/
--
		UPDATE KYPEnrollment.RelatedAccount
		SET ServiceAddress = ILV.FullAddress
		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT distinct ACC.AccountID,
		isnull(adr.AddressLine1,'')+', '+ISNULL(adr.AddressLine2 ,'') + ISNULL(adr.City,'')
		+', '+ISNULL(adr.State,'')+', '+ISNULL(adr.County,'')+', '+ISNULL(adr.ZipPlus4 ,'') as fulladdress
		
		--[KYPEnrollment].[MultipleColumnsValueintoSingleString](ADR.AddressLine1,ADR.AddressLine2,City,State,County,ZipPlus4) AS FullAddress
				FROM Kypenrollment.RelatedAccount RA
				JOIN KYPEnrollment.pADM_Account ACC
				ON RA.AccountID	= ACC.AccountID
				JOIN KYPEnrollment.pAccount_PDM_Location LOC
				ON ACC.PartyID = LOC.PartyID
				JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON LOC.AddressID = ADR.AddressID
				WHERE LOC.Type		  = 'Servicing' AND
					  ACC.IsDeleted	  = 0) ILV
			ON RA.AccountID	= ILV.AccountID
--improve for KEN-14790
	UPDATE KYPEnrollment.RelatedAccount
	SET IsMatchingNPI	= ILV.IsMatchingNPI,
		IsMatchingSSN	= ILV.IsMatchingSSN,
		IsMatchingTaxID	= ILV.IsMatchingEIN
	FROM KYPEnrollment.RelatedAccount RA
	JOIN (SELECT RA.RelatedAccountID,CASE WHEN Provider_NPI = acc.NPI THEN 1 ELSE 0 END AS IsMatchingNPI,
		 CASE WHEN Provider_SSN = acc.SSN THEN 1 ELSE 0 END AS IsMatchingSSN,
		 CASE WHEN Provider_TIN = acc.EIN THEN 1 ELSE 0 END AS IsMatchingEIN
		FROM KYPEnrollment.RelatedAccount RA
		JOIN KYP.ADM_CASE C
		ON RA.ApplicationNumber = C.Number/*WHERE Number = '000B1694'*/
		JOIN KYPEnrollment.pADM_Account ACC
		ON RA.AccountID	= ACC.AccountID 
		) ILV
				
		ON RA.RelatedAccountID = ILV.RelatedAccountID
		WHERE IsGroupOrRendering = 0			

/*
	UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingNPI	= ILV.IsMatchingNPI,
			IsMatchingSSN	= ILV.IsMatchingSSN,
			IsMatchingTaxID	= ILV.IsMatchingEIN
		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT ILV1.RelatedAccountID,CASE WHEN Provider_NPI = NPI THEN 1 ELSE 0 END AS IsMatchingNPI,
					 CASE WHEN Provider_SSN = SSN THEN 1 ELSE 0 END AS IsMatchingSSN,
					 CASE WHEN Provider_TIN = EIN THEN 1 ELSE 0 END AS IsMatchingEIN
				FROM (SELECT RelatedAccountID,Provider_NPI,Provider_SSN,Provider_TIN
						FROM KYPEnrollment.RelatedAccount RA
						JOIN KYP.ADM_CASE C
						ON RA.ApplicationNumber = C.Number/*WHERE Number = '000B1694'*/) ILV1
				JOIN (SELECT RelatedAccountID,ACC.NPI,ACC.SSN,ACC.EIN
						FROM KYPEnrollment.RelatedAccount RA
						JOIN KYPEnrollment.pADM_Account ACC
						ON RA.AccountID	= ACC.AccountID /*WHERE RA.ApplicationNumber = '000B1694'*/) ILV2
				ON ILV1.RelatedAccountID = ILV2.RelatedAccountID) ILV
		ON RA.RelatedAccountID = ILV.RelatedAccountID
		WHERE IsGroupOrRendering = 0
		*/
		
		
--improve for KEN-14790
        UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingServiceAddress = Servicing,
			IsMatchingPayToAddress	 = [Pay-to],
			IsMatchingMailingAddress = Mailing

		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT RelatedAccountID,AccountID,Number AS ApplicationNumber,AddressLine1,City,State,[Mailing],[Pay-to],[Servicing]
				FROM(SELECT ILV1.RelatedAccountID,ILV1.ApplicationNumber,Number,ILV1.AccountID,ILV1.AddressLine1,ILV1.City,ILV1.State,ILV1.AddressType
						FROM 
				(SELECT RelatedAccountID,RA.ApplicationNumber,ACC.AccountID,number,SUBSTRING(ADR.AddressLine1,1,10) AS AddressLine1,adr.City,adr.State,adr.AddressType
				 FROM KYPEnrollment.RelatedAccount RA
				JOIN KYPEnrollment.pADM_Account ACC
				ON RA.AccountID	= ACC.AccountID
				JOIN KYPEnrollment.pAccount_PDM_Location LOC
				ON LOC.PartyID = ACC.PartyID
				JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON ADR.AddressID = LOC.AddressID AND    ADR.AddressType	= LOC.Type		
				
				JOIN KYP.ADM_CASE C ON RA.ApplicationNumber = C.Number and  ApplnType	NOT IN('Disaffiliation','Rendering-S')
				JOIN KYPEnrollment.PortalAddress PA	ON	PA.EnrollCaseID	= C.CaseID AND adr.addresstype=pa.type and
				ISNULL(SUBSTRING(ADR.AddressLine1,1,10),'')	= ISNULL(SUBSTRING(pa.AddressLine1,1,10),'')	AND
				ISNULL(adr.City,'')			= ISNULL(pa.City,'')			AND
				ISNULL(adr.State,'')		= ISNULL(pa.State,'')
				
				WHERE adr.AddressType	IN('Mailing','Pay-to','Servicing')
				) ILV1
				) SRC -- WHERE ILV1.AccountID IN (3301258,3274462,3263649,2652802,3255508,3251611,3228750)
				PIVOT(COUNT(ApplicationNumber) FOR AddressType IN ([Mailing],[Pay-to],[Servicing])) PIV) ILV
		ON RA.RelatedAccountID	= ILV.RelatedAccountID
		WHERE IsGroupOrRendering = 0
--**replace 
	/*UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingServiceAddress = Servicing,
			IsMatchingPayToAddress	 = [Pay-to],
			IsMatchingMailingAddress = Mailing
		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT RelatedAccountID,AccountID,Number AS ApplicationNumber,AddressLine1,City,State,[Mailing],[Pay-to],[Servicing]
				FROM(SELECT ILV1.RelatedAccountID,ILV1.ApplicationNumber,Number,ILV1.AccountID,ILV1.AddressLine1,ILV1.City,ILV1.State,ILV1.AddressType
						FROM (SELECT RelatedAccountID,RA.ApplicationNumber,ACC.AccountID,SUBSTRING(ADR.AddressLine1,1,10) AS AddressLine1,City,State,AddressType
									FROM KYPEnrollment.RelatedAccount RA
									JOIN KYPEnrollment.pADM_Account ACC
									ON RA.AccountID	= ACC.AccountID
									JOIN KYPEnrollment.pAccount_PDM_Location LOC
									ON LOC.PartyID = ACC.PartyID
									JOIN KYPEnrollment.pAccount_PDM_Address ADR
									ON ADR.AddressID = LOC.AddressID AND
									   ADR.AddressType	= LOC.Type		
									WHERE AddressType	IN('Mailing','Pay-to','Servicing')) ILV1
						JOIN (SELECT RelatedAccountID,RA.ApplicationNumber,RA.AccountID,Number,SUBSTRING(PA.AddressLine1,1,10) AS AddressLine1,PA.City,PA.State,PA.Type
								FROM KYPEnrollment.RelatedAccount RA
								JOIN KYP.ADM_CASE C
								ON RA.ApplicationNumber = C.Number
								JOIN KYPEnrollment.PortalAddress PA
								ON	PA.EnrollCaseID	= C.CaseID AND
									PA.Type			IN('Mailing','Pay-to','Servicing')
								WHERE ApplnType		NOT IN('Disaffiliation','Rendering-S')) ILV2
						ON	ILV1.RelatedAccountID			= ILV2.RelatedAccountID			AND
							ILV1.AccountID					= ILV2.AccountID				AND
							ILV1.AddressType				= ILV2.Type						AND
							ISNULL(ILV1.AddressLine1,'')	= ISNULL(ILV2.AddressLine1,'')	AND
							ISNULL(ILV1.City,'')			= ISNULL(ILV2.City,'')			AND
							ISNULL(ILV1.State,'')			= ISNULL(ILV2.State,'')) SRC -- WHERE ILV1.AccountID IN (3301258,3274462,3263649,2652802,3255508,3251611,3228750)
				PIVOT(COUNT(ApplicationNumber) FOR AddressType IN ([Mailing],[Pay-to],[Servicing])) PIV) ILV
		ON RA.RelatedAccountID	= ILV.RelatedAccountID
		WHERE IsGroupOrRendering = 0
		*/
	--
	UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingServiceAddress = 0
		WHERE IsMatchingServiceAddress IS NULL AND
			  IsGroupOrRendering = 0

	UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingPayToAddress = 0
		WHERE IsMatchingPayToAddress IS NULL AND
			  IsGroupOrRendering = 0

	UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingMailingAddress = 0
		WHERE IsMatchingMailingAddress IS NULL AND
			  IsGroupOrRendering = 0
	---improve for DBAB-14528 Q 5
	/*UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingLicenseNumber = 1
		FROM KYPEnrollment.RelatedAccount RA
		JOIN (SELECT DISTINCT ILV1.RelatedAccountID --,ILV1.AccountID,ILV1.APPLICATIONNUMBER,ILV1.Type,ilv2.LicenseType,ILV1.NUMBER,ILV2.License
				FROM (SELECT RelatedAccountID,RA.ApplicationNumber,ACC.AccountID,Type,Number
						FROM KYPEnrollment.RelatedAccount RA
						JOIN KYPEnrollment.pADM_Account ACC
						ON RA.AccountID	= ACC.AccountID
						JOIN KYPEnrollment.pAccount_PDM_Number LIC
						ON LIC.PartyID = ACC.PartyID
						WHERE Type = 'Professional License') ILV1
				JOIN (SELECT RelatedAccountID,RA.ApplicationNumber,RA.AccountID,LicenseType,License
						FROM KYPEnrollment.RelatedAccount RA
						JOIN KYP.ADM_CASE C
						ON RA.ApplicationNumber = C.Number
						JOIN KYPEnrollment.PortalLicense PL
						ON	PL.EnrolCaseID	= C.CaseID
						WHERE LicenseType = 'Professional License') ILV2
				ON	ILV1.RelatedAccountID	= ILV2.RelatedAccountID AND
					ILV1.Type				= ILV2.LicenseType AND
					ILV1.Number				= ILV2.License) ILV
		ON RA.RelatedAccountID = ILV.RelatedAccountID
		*/
	--Replace with
UPDATE KYPEnrollment.RelatedAccount
SET IsMatchingLicenseNumber = 1
FROM KYPEnrollment.RelatedAccount RA 	inner join 
(select distinct ra.relatedaccountid 
FROM KYPEnrollment.RelatedAccount RA
	JOIN KYPEnrollment.pADM_Account ACC
	ON RA.AccountID	= ACC.AccountID
	JOIN KYPEnrollment.pAccount_PDM_Number LIC
	ON LIC.PartyID = ACC.PartyID
	JOIN KYP.ADM_CASE C
	ON RA.ApplicationNumber = C.Number
	JOIN KYPEnrollment.PortalLicense PL
	ON	PL.EnrolCaseID	= C.CaseID and lic.Type=pl.LicenseType and lic.Number=pl.license
	WHERE lic.Type = 'Professional License'	) ILV	 on ra.relatedaccountid=ilv.relatedaccountid 				
			
	--	**
	
	
	
	
	UPDATE KYPEnrollment.RelatedAccount
		SET IsMatchingLicenseNumber = 0
		WHERE IsMatchingLicenseNumber IS NULL

	UPDATE KYPEnrollment.RelatedAccount
		SET NumberOfMatchingCriteria =	CONVERT(INT,[IsMatchingNPI]) + CONVERT(INT,[IsMatchingSSN]) + CONVERT(INT,[IsMatchingTaxID]) +
										CONVERT(INT,[IsMatchingServiceAddress]) + CONVERT(INT,[IsMatchingPayToAddress]) +
										CONVERT(INT,[IsMatchingMailingAddress]) + CONVERT(INT,[IsMatchingLicenseNumber])

END


GO

