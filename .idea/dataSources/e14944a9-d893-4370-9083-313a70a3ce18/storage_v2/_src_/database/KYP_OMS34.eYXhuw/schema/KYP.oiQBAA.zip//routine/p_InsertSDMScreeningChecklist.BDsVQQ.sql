CREATE PROCedure [KYP].[p_InsertSDMScreeningChecklist]
(@ApplicationID int
 ,@ChecklistQuestID int= NULL
 ,@Completed bit =NULL
 ,@NA bit = NULL
 ,@Remarks varchar(250)=NULL
 ,@CreatedBy bit=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@ChecklistID int=NULL
)
as begin 

INSERT INTO [KYP].[SDM_ScreeningChecklist]
           ([ApplicationID]
           ,[ChecklistQuestID]
           ,[Completed]
           ,[NA]
           ,[Remarks]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[ChecklistID])
     VALUES
           (@ApplicationID
           ,@ChecklistQuestID
           ,@Completed
           ,@NA
           ,@Remarks
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@ChecklistID)

	return IDENT_CURRENT('[KYP].[SDM_ScreeningChecklist]')

end


GO

