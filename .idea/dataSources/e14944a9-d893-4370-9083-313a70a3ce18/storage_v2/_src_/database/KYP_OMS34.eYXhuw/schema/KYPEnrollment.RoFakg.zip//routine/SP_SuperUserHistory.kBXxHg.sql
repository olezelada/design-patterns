
/*
01/16/2019 changed by Mvillarroel Commented all enabled/disabled trigger sentences for avoid deadlocks in padm_account table, instead the Row_Updation_Source field was used to skip the triggers


*/










-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Clia recive 3 parametros
-- @partyIdPortal id party old portal con el cual se realiza la insert ,@partyIdOMS nuevo id party para realizar el registro ,@lastActionUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[SP_SuperUserHistory]
	@AccountID int,
	@TabName varchar(500),
	@FieldName varchar(500),
	@OldValue varchar(500),
	@NewValue varchar(500),
	@LastActionDate smalldatetime,
	@LastActorUserID varchar(100),
	@ManyKeyField varchar(500),
	@ManyKeyValue varchar(500),
	@FindingID int,
	@Comments varchar(500),
	@PrimaryID int,
	@SectionName varchar(500)
AS
BEGIN
Declare @AliasesPersonId int,
		@AliasesLname varchar(500),
		@AliasesMname varchar(500),
		@AliasesFname varchar(500),
		@AddressLine1 varchar(500),
		@AddressLine2 varchar(500),
		@City varchar(200),
		@State varchar(200),
		@county varchar(200),
		@zip4 varchar(20),
		@zip int,
		@Number varchar(50),
		@EiffDate smalldatetime,
		@ExpDate smalldatetime,
		@LegalName varchar(500),
		@SSN1 varchar(4),
		@SSN2 varchar(4),
		@SSN3 varchar(4),
		@ProviderTypeCode varchar(5),
		@SecondProviderTypeCode varchar(5),
		@OldID varchar(250),
		@Type varchar(500)
		;

	Declare @Tab_MultipleAccounts Table (AccountID int, PartyID Int);
		
	--Added for #17 KEN-16102


	Insert into @Tab_MultipleAccounts(AccountId,Partyid)
	Select AccountID,PartyID 
	from kypenrollment.padm_Account
	Where AccountID = @AccountID
		
	Insert into @Tab_MultipleAccounts(AccountId,Partyid)
	Select t2.AccountID,t2.PartyID 
		from kypenrollment.padm_Account t1
		Join kypenrollment.padm_Account t2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo and T1.ServiceLocationNo=T2.ServiceLocationNo 
		and t2.ProviderTypeCode in ('030','038','015','016','051','076')
		Where t1.AccountID = @AccountID
	Except
	Select AccountID,PartyID 
	from @Tab_MultipleAccounts
		
	--CAPAVE-3812 - NPI Spreading - Start		
	If @FieldName in ('LastName','FirstName','MiddleName','LegalName') and @TabName = 'Profile'
	Begin
		Insert into @Tab_MultipleAccounts(AccountId,Partyid)
		Select t2.AccountID,t2.PartyID 
			from kypenrollment.padm_Account t1
			Join kypenrollment.padm_Account t2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo
			Where t1.AccountID = @AccountID
			and t1.AccountId <> t2.AccountID
			and T2.IsDeleted=0
		Except
		Select AccountID,PartyID 
		from @Tab_MultipleAccounts			
	End

	If Exists(Select AccountID From kypenrollment.padm_Account 
					Where AccountID = @AccountID and NPIType='Organization') and @FieldName = 'LegalName' and @TabName = 'Business'
	Begin
		Insert into @Tab_MultipleAccounts(AccountId,Partyid)
		Select t2.AccountID,t2.PartyID 
			from kypenrollment.padm_Account t1
			Join kypenrollment.padm_Account t2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo
			Where t1.AccountID = @AccountID
			and t1.AccountId <> t2.AccountID
			and T2.IsDeleted=0
		Except
		Select AccountID,PartyID 
		from @Tab_MultipleAccounts	
	End	

	If @FieldName in ('BusinessName','MailingAddress')
	Begin
		Insert into @Tab_MultipleAccounts(AccountId,Partyid)
		Select t2.AccountID,t2.PartyID 
			from kypenrollment.padm_Account t1
			Join kypenrollment.padm_Account t2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo and T1.ServiceLocationNo=T2.ServiceLocationNo
			Where t1.AccountID = @AccountID
			and t1.AccountId <> t2.AccountID
			and T2.IsDeleted=0
		Except
		Select AccountID,PartyID 
		from @Tab_MultipleAccounts			
	End	
	--CAPAVE-3812 - NPI Spreading - End	

		if(@FieldName='LastName')
		begin
		
		--Select AccountID from @Tab_MultipleAccounts
					--update [KYPEnrollment].PAccount_PDM_Person set LastName=@NewValue where PersonID=@PrimaryID;
			Update B
			Set B.LastName=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);

			Select @LegalName = isnull(person.LastName,'')+', '+isnull(person.FirstName,'')+' '+ ISNULL(left(person.MiddleName,1),'') 
			+' '+ISNULL(person.ProfessionalTitle, ISNULL (person.Salutation, ''))
			FROM [KYPEnrollment].pAccount_PDM_Party party
			inner join [KYPEnrollment].PAccount_PDM_Person person on party.PartyID=person.PartyID
			Join [KYPEnrollment].pADM_Account Ac ON Party.AccountID=Ac.AccountID 
			WHERE party.AccountID=@AccountID AND party.Type='Provider' AND party.CurrentRecordFlag=1 and person.CurrentRecordFlag=1;
			
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account ;
			Update kypenrollment.pADM_Account set LegalName = @LegalName,Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account ;
			
			Update KYPEnrollment.pAccount_Name Set Name= @LegalName Where NameType = 'LegalName'and  
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
	
			Update KYPEnrollment.pAccount_BizProfile_Details Set AccountLegalName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts)and CurrentRecordFlag=1;
			
			Update KYPEnrollment.AccountSearch set AccountName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Update Kypenrollment.AccountInputDocFullload Set LegalName = @LegalName,[ProvNameScan] = @LegalName where 
			AccountId in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE()
			From @Tab_MultipleAccounts
			
			--CAPAVE-3812 - NPI Spreading 
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE(),'Super User',@AccountID,@LastActorUserID			
			From @Tab_MultipleAccounts;			
			 			
		END
		else if(@FieldName='FirstName')
		begin
			--update [KYPEnrollment].PAccount_PDM_Person set FirstName=@NewValue where PersonID=@PrimaryID
			Update B
			Set B.FirstName=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
						
			Select @LegalName = isnull(person.LastName,'')+', '+isnull(person.FirstName,'')+' '+ ISNULL(left(person.MiddleName,1),'') 
			+' '+ISNULL(person.ProfessionalTitle, ISNULL (person.Salutation, ''))
			FROM [KYPEnrollment].pAccount_PDM_Party party
			inner join [KYPEnrollment].PAccount_PDM_Person person on party.PartyID=person.PartyID
			Join [KYPEnrollment].pADM_Account Ac ON Party.AccountID=Ac.AccountID 
			WHERE party.AccountID=@AccountID AND party.Type='Provider' AND party.CurrentRecordFlag=1 and person.CurrentRecordFlag=1;
			
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account ;
			Update kypenrollment.pADM_Account set LegalName = @LegalName,Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account ;
			
			Update KYPEnrollment.pAccount_Name Set Name= @LegalName Where NameType = 'LegalName'and  
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			Update KYPEnrollment.pAccount_BizProfile_Details Set AccountLegalName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			Update KYPEnrollment.AccountSearch set AccountName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Update Kypenrollment.AccountInputDocFullload Set LegalName = @LegalName,[ProvNameScan] = @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE()
			From @Tab_MultipleAccounts		
				
			--CAPAVE-3812 - NPI Spreading 
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE(),'Super User',@AccountID,@LastActorUserID			
			From @Tab_MultipleAccounts;			
		END
		else if(@FieldName='MiddleName')
		begin
			--update [KYPEnrollment].PAccount_PDM_Person set MiddleName=@NewValue where PersonID=@PrimaryID
			Update B
			Set B.MiddleName=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
						
			Select @LegalName = isnull(person.LastName,'')+', '+isnull(person.FirstName,'')+' '+ ISNULL(left(person.MiddleName,1),'') 
			+' '+ISNULL(person.ProfessionalTitle, ISNULL (person.Salutation, ''))
			FROM [KYPEnrollment].pAccount_PDM_Party party
			inner join [KYPEnrollment].PAccount_PDM_Person person on party.PartyID=person.PartyID
			Join [KYPEnrollment].pADM_Account Ac ON Party.AccountID=Ac.AccountID 
			WHERE party.AccountID=@AccountID AND party.Type='Provider' AND party.CurrentRecordFlag=1 and person.CurrentRecordFlag=1;
			
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account ;
			Update kypenrollment.pADM_Account set LegalName = @LegalName,Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account ;
			
			Update KYPEnrollment.pAccount_Name Set Name= @LegalName Where NameType = 'LegalName'and  
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			Update KYPEnrollment.pAccount_BizProfile_Details Set AccountLegalName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			Update KYPEnrollment.AccountSearch set AccountName= @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Update Kypenrollment.AccountInputDocFullload Set LegalName = @LegalName,[ProvNameScan] = @LegalName where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE()
			From @Tab_MultipleAccounts	
			
			--CAPAVE-3812 - NPI Spreading 
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'LegalName',NULL,@LegalName,GETDATE(),'Super User',@AccountID,@LastActorUserID			
			From @Tab_MultipleAccounts;				
		END
		else if(@FieldName='DOB')
		begin
			--update [KYPEnrollment].PAccount_PDM_Person set DoB=@NewValue where PersonID=@PrimaryID;
			Update B
			Set B.DoB=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			Update Kypenrollment.AccountInputDocFullload Set DOB = Convert(varchar(10),@NewValue,101) --Added Convert function by Sundar on 14-May-2019 for CAPAVE-5626
			where Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			--Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			--Values (@AccountID,'DOB',@OldValue,@NewValue,GETDATE());				
			
		END
		else if(@FieldName='SSN')
		begin
			select @SSN1=Item From dbo.fnSplitString(@NewValue,'-') where ID=1
			select @SSN2=Item From dbo.fnSplitString(@NewValue,'-') where ID=2
			select @SSN3=Item From dbo.fnSplitString(@NewValue,'-') where ID=3
			--update [KYPEnrollment].PAccount_PDM_Person set SSN=@NewValue where PersonID=@PrimaryID
			Update B
			Set B.SSN=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			
			Update KYPENrollment.AccountSearch set SSN=@NewValue where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Update KYPEnrollment.pAccount_BizProfile_Details set AccountSSN=@SSN1+@SSN2+@SSN3 where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set SSN=@SSN1+@SSN2+@SSN3,ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;

			Update KYPENrollment.pAccount_Owner set SSN=@SSN1+@SSN2+@SSN3 where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
			
			Update Kypenrollment.AccountInputDocFullload Set SSN = @SSN1+@SSN2+@SSN3 where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SSN',@OldValue,@NewValue,GETDATE()			
			From @Tab_MultipleAccounts			
			
		END
		else if(@FieldName='Aliases')
		begin
		
				select @AliasesLname=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AliasesFname=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @AliasesMname=Item From dbo.fnSplitString(@NewValue,':') where ID=3
			if(isnull(@PrimaryID,'')<>'')
			BEGIN		
				update KYPEnrollment.PAccount_PDM_Person_othername set FirstName=@AliasesFname,LastName=@AliasesLname,MiddleName=case when @AliasesMname=''then null else @AliasesMname end
				from
				KYPEnrollment.pADM_Account A
				Inner join KYPEnrollment.pAccount_PDM_Person B on A.PartyID=B.PartyID 
				Where Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
			END
			else
			BEGIN
				insert into KYPEnrollment.PAccount_PDM_Person_othername 
				select 			
				A.PersonId,Null,Null,@AliasesLname,@AliasesFname,@AliasesMname,Null,NULL,@LastActionDate,Null,NULL,NULL,NULL,0,'C',@LastActionDate,@LastActorUserID,
				NULL,NULL,@LastActorUserID,1
				from KYPEnrollment.pAccount_PDM_Person A
				inner join  KYPEnrollment.pAccount_PDM_Party B on A.Partyid=B.partyid   
				where B.Accountid in (Select AccountID from @Tab_MultipleAccounts) and B.Type='Provider' and B.CurrentRecordFlag=1
				--insert into KYPEnrollment.PAccount_PDM_Person_othername(PersonID,LastName,FirstName,MiddleName,DateCreated,IsDeleted,LastAction,
				--LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag) 
				--values(@AliasesPersonId,@AliasesLname,@AliasesFname,@AliasesMname,@LastActionDate,0,'C',@LastActionDate,@LastActorUserID,@LastActorUserID,1)
			END
		END
		else if(@FieldName='StateID')
		begin
			--update KYPEnrollment.pAccount_PDM_Document set TypeDoc=@NewValue where Documentid=@PrimaryID
				Update B
				set TypeDoc=@NewValue
				from
				KYPEnrollment.pADM_Account A
				Inner join KYPEnrollment.pAccount_PDM_Document B on A.PartyID=B.PartyID  and B.CurrentRecordFlag=1
				Where Accountid in (Select AccountID from @Tab_MultipleAccounts);
				
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
		END
		else if(@FieldName='StateIDNumber')
		begin
			--update KYPEnrollment.pAccount_PDM_Document set NumberDoc=@NewValue where Documentid=@PrimaryID
				Update B
				set NumberDoc=@NewValue
				from
				KYPEnrollment.pADM_Account A
				Inner join KYPEnrollment.pAccount_PDM_Document B on A.PartyID=B.PartyID  and B.CurrentRecordFlag=1
				Where Accountid in (Select AccountID from @Tab_MultipleAccounts);
				
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
		END
		else if(@FieldName='Email')
		
		begin
			--update [KYPEnrollment].PAccount_PDM_Person set Email1=@NewValue where PersonID=@PrimaryID
			Update B
			Set B.Email1=@NewValue 
			from KYPENROLLMENT.pADM_Account A
			inner join  KYPEnrollment.PAccount_PDM_Person B on A.PartyID=B.PartyID and B.CurrentRecordFlag=1
			where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
		END
		else if(@FieldName='Residential Address')
		begin		
			select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
			select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
			select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
			select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
			select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
			select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
			select @zip=Item From dbo.fnSplitString(@zip4,'-') where ID=1
			
			UPDATE C
			SET AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip
			FROM KYPEnrollment.pADM_Account A
			INNER JOIN KYPEnrollment.pAccount_PDM_Location B ON A.PartyID=B.PartyID AND TYPE='Individual Profile'
			INNER JOIN KYPEnrollment.pAccount_PDM_Address C ON C.AddressID=B.AddressID
			WHERE A.AccountID IN(Select AccountID from @Tab_MultipleAccounts)
			--update [KYPEnrollment].pAccount_PDM_Address set AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,
			--State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip where AddressID=@PrimaryID
		END
		else if(@FieldName='IssuingState')
		begin		
			--update KYPEnrollment.pAccount_PDM_Document set StateIssued=@NewValue where Documentid=@PrimaryID
				Update B
				set StateIssued=@NewValue
				from
				KYPEnrollment.pADM_Account A
				Inner join KYPEnrollment.pAccount_PDM_Document B on A.PartyID=B.PartyID  and B.CurrentRecordFlag=1
				Where Accountid in (Select AccountID from @Tab_MultipleAccounts);
				
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
		END
		else if(@FieldName='PLastName' and @SectionName='Person')
		Begin
			Update B
					Set B.LastName=@NewValue 
					from KYPEnrollment.pAccount_PDM_Party A
					inner join KYPEnrollment.pAccount_PDM_Person B On A.PartyID=B.PartyID and B.CurrentRecordFlag=1
					where 
					A.TYPE='Contact Person' and A.CurrentRecordFlag=1
					AND A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
		END	
		else if(@FieldName='PFName' and @SectionName='Person')
		Begin
			Update B
					Set B.FirstName=@NewValue 
					from KYPEnrollment.pAccount_PDM_Party A
					inner join KYPEnrollment.pAccount_PDM_Person B On A.PartyID=B.PartyID and B.CurrentRecordFlag=1
					where 
					A.TYPE='Contact Person' and A.CurrentRecordFlag=1
					AND A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
		END	
		else if(@FieldName='PTitlePosition' and @SectionName='Person')
		Begin
			Update B
					Set B.ProfessionalTitle=@NewValue 
					from KYPEnrollment.pAccount_PDM_Party A
					inner join KYPEnrollment.pAccount_PDM_Person B On A.PartyID=B.PartyID and B.CurrentRecordFlag=1
					where 
					A.TYPE='Provider' and A.CurrentRecordFlag=1
					AND A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
		END	
		else if(@FieldName='PPhoneNumber' and @SectionName='Person')
		Begin
			Update B
					Set B.Phone1=@NewValue 
					from KYPEnrollment.pAccount_PDM_Party A
					inner join KYPEnrollment.pAccount_PDM_Person B On A.PartyID=B.PartyID and B.CurrentRecordFlag=1
					where 
					A.TYPE='Contact Person' and A.CurrentRecordFlag=1
					AND A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
		END	
		else if(@FieldName='PEmail' and @SectionName='Person')
		Begin
			Update B
					Set B.Email1=@NewValue 
					from KYPEnrollment.pAccount_PDM_Party A
					inner join KYPEnrollment.pAccount_PDM_Person B On A.PartyID=B.PartyID and B.CurrentRecordFlag=1
					where 
					A.TYPE='Contact Person' and A.CurrentRecordFlag=1
					AND A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
		END
		else if(@FieldName='LegalName' and @SectionName='Organisation')
		Begin

			if((select NPIType from [KYPEnrollment].pADM_Account where AccountID=@AccountID)='Organization')
			Begin
					Update B
					Set B.LegalName=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Organization B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
					--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account ;
					Update kypenrollment.pADM_Account set LegalName = @NewValue ,Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory'
					where Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
					--Enable TRIGGER ALL ON kypenrollment.pADM_Account ;
					
					Update KYPEnrollment.pAccount_Name Set Name= @NewValue Where NameType = 'LegalName'and  
					Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
					
					Update KYPEnrollment.pAccount_BizProfile_Details Set AccountLegalName= @NewValue where 
					Accountid in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1;
					
					Update KYPEnrollment.AccountSearch set AccountName= @NewValue where 
					Accountid in (Select AccountID from @Tab_MultipleAccounts);
			
					Update Kypenrollment.AccountInputDocFullload Set LegalName = @NewValue where 
					Accountid in (Select AccountID from @Tab_MultipleAccounts);
					
					
			END	
			else
			Begin
					Update B
					Set B.LegalName=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Organization B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
					
			END	
								 			
			--CAPAVE-3812 - NPI Spreading 
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'LegalName',NULL,@NewValue,GETDATE(),'Super User',@AccountID,@LastActorUserID			
			From @Tab_MultipleAccounts;
						
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'LegalName',NULL,@NewValue,GETDATE()			
			From @Tab_MultipleAccounts			
				
				
		END	
		else if(@FieldName='EntityType' and @SectionName='Organisation')
		Begin
			update   KYPEnrollment.pAccount_PDM_EntityType set NameEntityType=@NewValue where EntityTypeID=@PrimaryID				
		END	
		else if(@FieldName='CorporateNumber')
		Begin
			update   KYPEnrollment.pAccount_PDM_EntityType set CorporateNumber=@NewValue where EntityTypeID=@PrimaryID				
		END	
		else if(@FieldName='BusinessName')
		Begin		
			--update [KYPEnrollment].pAccount_PDM_Organization set DBAName1=@NewValue,BusinessName=@NewValue where OrgID=@PrimaryID;
			Update B
					Set B.BusinessName=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Organization B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account ;
			update [KYPEnrollment].pADM_Account set BusinessName=@NewValue,Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			--Enable TRIGGER ALL ON kypenrollment.pADM_Account ;
			
			Update Kypenrollment.AccountInputDocFullload Set DBAName = @NewValue where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			--CAPAVE-3812 - NPI Spreading 
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'BusinessName',@OldValue,@NewValue,GETDATE(),'Super User',@AccountID,@LastActorUserID			
			From @Tab_MultipleAccounts;				
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'DBAName',@OldValue,@NewValue,GETDATE()			
			From @Tab_MultipleAccounts;		 			
												
		END	
		else if(@FieldName='PhoneNumber')
		Begin
		
			Update B
					Set B.Phone1=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Organization B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);		
			--update [KYPEnrollment].pAccount_PDM_Organization set Phone1=@NewValue where OrgID=@PrimaryID;

			Update Kypenrollment.AccountInputDocFullload Set Phone1 = @NewValue where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'Phone1',@OldValue,@NewValue,GETDATE()			
			From @Tab_MultipleAccounts;								
												
		END	
		else if(@FieldName='Extension')
		Begin		
			--update [KYPEnrollment].pAccount_PDM_Organization set Extension=@NewValue where OrgID=@PrimaryID;
			Update B
					Set B.Extension=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Organization B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts);			
												
		END
		else if(@FieldName='ContactPerson')
		Begin		
	
			select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
				select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
				select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
				--select @AliasesLname=Item From dbo.fnSplitString(@NewValue,':') where ID=7
				
				Update C
				Set LastName=@AddressLine1,FirstName= @AddressLine2,Position=@City,Phone1=@State,Extension=@county,Email1=@zip4
				from KYPEnrollment.pADM_Account A
				inner join KYPEnrollment.pAccount_PDM_Party B on A.AccountID=B.AccountID and B.Type='Contact Person' and B.CurrentRecordFlag=1
				Inner Join KYPEnrollment.pAccount_PDM_Person C on B.PartyID=C.PartyID and C.CurrentRecordFlag=1
				where A.AccountID in(Select AccountID from @Tab_MultipleAccounts)
					
			--update [KYPEnrollment].pAccount_PDM_Person set LastName=@AddressLine1,FirstName= @AddressLine2,MiddleName=@City,
			--Position=@State,Phone1=@county,Extension=@zip4,Email1=@AliasesLname where PersonID=@PrimaryID			
												
		END	
		else if(@FieldName='ServiceAddress')
		begin		
				select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
				select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
				select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
				select @zip=Item From dbo.fnSplitString(@zip4,'-') where ID=1
				
				UPDATE C
				SET AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip
				FROM KYPEnrollment.pADM_Account A
				INNER JOIN KYPEnrollment.pAccount_PDM_Location B ON A.PartyID=B.PartyID AND B.Type='Servicing' And  B.CurrentRecordFlag=1
				INNER JOIN KYPEnrollment.pAccount_PDM_Address C ON C.AddressID=B.AddressID And B.CurrentRecordFlag=1
				WHERE A.AccountID IN (Select AccountID from @Tab_MultipleAccounts);
				
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;	
			--update [KYPEnrollment].pAccount_PDM_Address set AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,
			--State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip where AddressID=@PrimaryID;
			
			Update Kypenrollment.AccountInputDocFullload 
			Set SAdsL1 = @AddressLine1, 
				SAdsL2 = @AddressLine2, 
				SCity = @City, 
				SState = (Select Abreviation From kyp.LK_Screening Where Description = @State), 
				SCounty = Case When A.OutOfStateInd = '0' Then (Select Code From kyp.CA_CountyCodes Where Name = @county) Else Null End,
				SZipPlus4 = @zip4
			From Kypenrollment.AccountInputDocFullload I
			Join Kypenrollment.EDM_AccountInternalUse A on I.AccountID = A.AccountID
			where I.AccountId IN (Select AccountID from @Tab_MultipleAccounts)
										
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SAdsL1',NULL,@AddressLine1,GETDATE()
			From @Tab_MultipleAccounts;
				
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SAdsL2',NULL,@AddressLine2,GETDATE()
			From @Tab_MultipleAccounts;
						
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SCity',NULL,@City,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SState',NULL,@State,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'SZipPlus4',NULL,@zip4,GETDATE()
			From @Tab_MultipleAccounts;									
					
		END
		else if(@FieldName='PayToAddress')
		begin		
				Insert into @Tab_MultipleAccounts(AccountId,Partyid)
				select t2.AccountID,t2.PartyID 
				From kypenrollment.pADM_Account t1 
				join kypenrollment.pADM_Account t2 on t1.NPI=t2.NPI and t1.OwnerNo=t2.OwnerNo 
				where t1.AccountID = @AccountID and T2.AccountID ! = t1.AccountID
				Except
				Select AccountId,Partyid From @Tab_MultipleAccounts		
		
				select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
				select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
				select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
				select @zip=Item From dbo.fnSplitString(@zip4,'-') where ID=1
					
			--update [KYPEnrollment].pAccount_PDM_Address 
			--set AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,
			--State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip where AddressID=@PrimaryID;
			UPDATE C
			SET AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip
			FROM KYPEnrollment.pADM_Account A
			INNER JOIN KYPEnrollment.pAccount_PDM_Location B ON A.PartyID=B.PartyID AND B.Type='Pay-to' And  B.CurrentRecordFlag=1
			INNER JOIN KYPEnrollment.pAccount_PDM_Address C ON C.AddressID=B.AddressID And B.CurrentRecordFlag=1
			WHERE A.AccountID IN(Select AccountID from @Tab_MultipleAccounts)
			
			Update Kypenrollment.AccountInputDocFullload 
			Set AdsL1 = @AddressLine1, 
				AdsL2 = @AddressLine2, 
				City = @City, 
				Acc_state = @State, 
				ZipPlus4 = @zip4 
			where AccountId IN (Select AccountID from @Tab_MultipleAccounts);

			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'AdsL1',NULL,@AddressLine1,GETDATE()
			From @Tab_MultipleAccounts;
				
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'AdsL2',NULL,@AddressLine2,GETDATE()
			From @Tab_MultipleAccounts;
						
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'City',NULL,@City,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'Acc_state',NULL,@State,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'ZipPlus4',NULL,@zip4,GETDATE()
			From @Tab_MultipleAccounts;	
		
		END
		else if(@FieldName='MailingAddress')
		begin		
				select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
				select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
				select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
				select @zip=Item From dbo.fnSplitString(@zip4,'-') where ID=1
					
			--update [KYPEnrollment].pAccount_PDM_Address set AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,
			--State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip where AddressID=@PrimaryID;
			UPDATE C
			SET AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip
			FROM KYPEnrollment.pADM_Account A
			INNER JOIN KYPEnrollment.pAccount_PDM_Location B ON A.PartyID=B.PartyID AND B.Type='Mailing' And  B.CurrentRecordFlag=1
			INNER JOIN KYPEnrollment.pAccount_PDM_Address C ON C.AddressID=B.AddressID And B.CurrentRecordFlag=1
			WHERE A.AccountID IN(Select AccountID from @Tab_MultipleAccounts)
			
			Update Kypenrollment.AccountInputDocFullload 
			Set MAdsL1 = @AddressLine1, 
				MAdsL2 = @AddressLine2, 
				MCity = @City, 
				Mstate = @State, 
				MZipPlus4 = @zip4 
			where AccountId IN (Select AccountID from @Tab_MultipleAccounts);

			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'MAdsL1',NULL,@AddressLine1,GETDATE()
			From @Tab_MultipleAccounts;
				
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'MAdsL2',NULL,@AddressLine2,GETDATE()
			From @Tab_MultipleAccounts;
						
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'MCity',NULL,@City,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'Mstate',NULL,@State,GETDATE()
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'MZipPlus4',NULL,@zip4,GETDATE()
			From @Tab_MultipleAccounts;
			
			--CAPAVE-3812 - NPI Spreading - Start
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'MAddressLine1',NULL,@AddressLine1,GETDATE(),'Super User',@AccountId,@LastActorUserID
			From @Tab_MultipleAccounts;
				
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'MAddressLine2',NULL,@AddressLine2,GETDATE(),'Super User',@AccountId,@LastActorUserID
			From @Tab_MultipleAccounts;
						
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'MCity',NULL,@City,GETDATE(),'Super User',@AccountId,@LastActorUserID
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'Mstate',NULL,@State,GETDATE(),'Super User',@AccountId,@LastActorUserID
			From @Tab_MultipleAccounts;
			
			Insert into kypenrollment.[NPI_SpreadHistory]([AccountID],[FieldName],[FromValue],[ToValue],[LoadDate],[SourceApplication],[SourceAccountID],[LastActorUserID])
			Select AccountID,'MZipPlus4',NULL,@zip4,GETDATE(),'Super User',@AccountId,@LastActorUserID
			From @Tab_MultipleAccounts;
			--CAPAVE-3812 - NPI Spreading - End							
					
		END								
		else if(@FieldName='Professional License') -- Practice Tab start
		begin	
			select @Number=Item From dbo.fnSplitString(@NewValue,':') where ID=1
			select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=2
			select @EiffDate=Item From dbo.fnSplitString(@NewValue,':') where ID=3
			select @ExpDate=Item From dbo.fnSplitString(@NewValue,':') where ID=4	
		
			--select @OldID=Number,@Type=Type from KYPEnrollment.pAccount_PDM_Number where Number=@PrimaryID
			--update KYPEnrollment.pAccount_PDM_Number set Number=@Number,State=@State,EffectiveDate=@EiffDate,ExpirationDate=@ExpDate where 
			--NumberID=@PrimaryID
			Update B
					Set B.Number=@Number,B.State=@State,B.EffectiveDate=@EiffDate,B.ExpirationDate=@ExpDate 
						,B.LastActionDate = Getdate() --Added by Sundar on 25Feb2019 for Elk Implementation
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Number B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) 
					and NumberID=@PrimaryID-- Number=@OldID and Type=@Type;
					
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
			
			Update Kypenrollment.AccountInputDocFullload 
			Set Number = @Number, EffDt = Convert(varchar(10),@EiffDate,101) --Added Convert function by Sundar on 14-May-2019 for CAPAVE-5626
			where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'Number',NULL,@Number,GETDATE()
			From @Tab_MultipleAccounts
			--Union all
			-- Select AccountID,'EffDT',Null,@EiffDate,Getdate()
			-- Conversion failed when converting character string to smalldatetime data type.
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)			
			Select AccountID,'EffDT',Null,Convert(varchar(10),@EiffDate,101),Getdate()
			From  @Tab_MultipleAccounts;			
		END
		else if(@FieldName='Professional License BB') -- Practice Tab start
		begin	
			select @Number=Item From dbo.fnSplitString(@NewValue,':') where ID=1
			select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=2
			select @EiffDate=Item From dbo.fnSplitString(@NewValue,':') where ID=3
			--select @ExpDate=Item From dbo.fnSplitString(@NewValue,':') where ID=4	
		
			--select @OldID=Number,@Type=Type from KYPEnrollment.pAccount_PDM_Number where Number=@PrimaryID
			update KYPEnrollment.pAccount_PDM_Number 
				set Number=@Number,EffectiveDate=@State,ExpirationDate=@EiffDate 
						,LastActionDate = Getdate() --Added by Sundar on 25Feb2019 for Elk Implementation
				where PartyID=@PrimaryID and type='LicenseAndCertificate'

			Update B
					Set B.Number=@Number,B.EffectiveDate=@State,B.ExpirationDate=@EiffDate 
						,B.LastActionDate = Getdate() --Added by Sundar on 25Feb2019 for Elk Implementation
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Number B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) 
					and NumberID=@PrimaryID--Number=@OldID and Type=@Type 
			
			Update Kypenrollment.AccountInputDocFullload 
			Set Number = @Number, EffDt = Convert(varchar(10),@EiffDate,101) --Added Convert function by Sundar on 14-May-2019 for CAPAVE-5626
			where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'Number',NULL,@Number,GETDATE()
			From @Tab_MultipleAccounts
			--Union all
			-- Select AccountID,'EffDT',Null,@EiffDate,Getdate()
			-- Conversion failed when converting character string to smalldatetime data type.
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)			
			Select AccountID,'EffDT',Null,Convert(varchar(10),@EiffDate,101),Getdate()
			From  @Tab_MultipleAccounts;			
		END
		else if(@FieldName='CLIA')
		begin
			IF LEn(@NewValue)>0
			Begin
				Set @NewValue = STUFF(@NewValue,3,0,'D');
			End
			
			Update B
					Set B.CliaNumber=@NewValue
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Clia B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and CurrentRecordFlag=1; --and CliaNumber=@OldValue 
					
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;					

			Update Kypenrollment.AccountInputDocFullload Set CliaNumber = @NewValue where AccountID in (Select AccountID from @Tab_MultipleAccounts);
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'CliaNumber',@OldValue,@NewValue,GETDATE()
			From @Tab_MultipleAccounts;					
		END
		/*CODE ADDED BY VASANT ON 18TH JULY FOR CERTIFICATE NUMBER (KEN-18185)*/
		else if(@FieldName='CertNo')
		begin 
			Update B
					Set B.CertificationNumber=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Clia B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and CertificationNumber=@OldValue  and CurrentRecordFlag=1;
			
				--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
				Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
				Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
				--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
			--update KYPEnrollment.pAccount_PDM_Clia set CertificationNumber=@NewValue where PartyID=@PrimaryID
   
			--Update Kypenrollment.AccountInputDocFullload Set CliaNumber = @NewValue where AccountId=@AccountID;
   
			--Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			--Values (@AccountID,'CliaNumber',@OldValue,@NewValue,GETDATE());    
		END
		else if(@FieldName='RegistrationNumber')
		begin	
			--update KYPEnrollment.pAccount_PDM_Clia set RegistrationNumber=@NewValue where CliaID=@PrimaryID
			Update B
					Set B.RegistrationNumber=@NewValue 
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Clia B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and RegistrationNumber=@OldValue  and CurrentRecordFlag=1;
					
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;	
		END
		else if(@FieldName='Speciality')
		begin
			select @OldID = Item From dbo.fnSplitString(@OldValue,'-') where ID=1
			select @Number=Item From dbo.fnSplitString(@NewValue,'-') where ID=1
			select @State=Item From dbo.fnSplitString(@NewValue,'-') where ID=2
			
			Update B
					Set Speciality_Code=@Number,TaxonomyCode=@State
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Speciality B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and B.Speciality_Code=@OldID and B.TYPE='Specialty Code' 
					and B.CurrentRecordFlag=1;
					
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory'  where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
			
			update KYPEnrollment.pAccount_PDM_Speciality set Speciality_Code=@Number,TaxonomyCode=@State where SpecialityID=@PrimaryID
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'LI',@OldID,@Number,GETDATE()
			From @Tab_MultipleAccounts;				
		END
		else if(@FieldName='Taxonomy')
		begin
		
			select @OldID = Item From dbo.fnSplitString(@OldValue,'-') where ID=1
			select @Number=Item From dbo.fnSplitString(@NewValue,'-') where ID=1
			select @State=Item From dbo.fnSplitString(@NewValue,'-') where ID=2
			
			Update B
					Set Speciality_Code=@Number,TaxonomyCode=@State
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_Speciality B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and B.Speciality_Code=@OldID and B.TYPE='Taxonomy Code' 
					and B.CurrentRecordFlag=1;
			update KYPEnrollment.pAccount_PDM_Speciality set Speciality_Code=@Number,TaxonomyCode=@State where SpecialityID=@PrimaryID
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
			
			Insert into kypenrollment.Inputdoc_Biller(AccountID,FieldName,FromValue,ToValue,DateModified)
			Select AccountID,'TaxnC1',@OldID,@Number,GETDATE()
			From @Tab_MultipleAccounts;				
		END
		else if(@FieldName='DEA Number')
		begin
			--update KYPEnrollment.pAccount_PDM_DEA set DEA=@NewValue where DEAID=@PrimaryID ExpiryDate
			Update B
					Set B.DEA=@NewValue
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_DEA B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and B.DEA=@OldValue and B.CurrentRecordFlag=1;
					
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
		END
		else if(@FieldName='DEA Expiration Date')
		begin
			--update KYPEnrollment.pAccount_PDM_DEA set ExpiryDate=@NewValue where DEAID=@PrimaryID
			select @OldID =DEA From KYPEnrollment.pAccount_PDM_DEA where DEAID=@PrimaryID
			Update B
					Set B.ExpiryDate=@NewValue
					from KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_PDM_DEA B on A.PartyID=B.PartyID
					where A.AccountID in (Select AccountID from @Tab_MultipleAccounts) and B.DEA=@OldID and B.CurrentRecordFlag=1;
					
			--DISABLE TRIGGER ALL ON kypenrollment.pADM_Account;
			Update KYPENrollment.pADM_Account set ScreeningValue='SR',Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory' where 
			Accountid in (Select AccountID from @Tab_MultipleAccounts) and IsDeleted=0;
			--ENABLE  TRIGGER ALL on kypenrollment.pADM_Account;
		END -- Practice Tab END
		else if(@FieldName='MocaName') -- Moca Tab Start
		begin
			if(@SectionName='Individual')
			BEGIN
				select @Number=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
					
				update KYPEnrollment.pAccount_PDM_Person set LastName=@Number,FirstName=@State,MiddleName=@City where PartyID=@PrimaryID
			END
			else
			BEGIN
				update KYPEnrollment.pAccount_PDM_Organization set LegalName=@NewValue where PartyID=@PrimaryID
			END
			
		END
		else if(@FieldName='MocaNPI')
		begin
			if(@SectionName='Individual')
			BEGIN					
				update KYPEnrollment.pAccount_PDM_Person set NPI=@NewValue where PartyID=@PrimaryID
				update KYPEnrollment.pAccount_PDM_Provider set NPI=@NewValue where PartyID=(select PartyID from KYPEnrollment.pAccount_PDM_Person  
				where PartyID=@PrimaryID)
			END
			else
			BEGIN
				update KYPEnrollment.pAccount_PDM_Organization set NPI=@NewValue where PartyID=@PrimaryID
			END
			
		END
		else if(@FieldName='MocaSSN')
		begin
			if(@SectionName='Individual')
			BEGIN
													
				update KYPEnrollment.pAccount_PDM_Person set SSN=@NewValue where PartyID=@PrimaryID
			END
			
			
		END
		else if(@FieldName='MOCAAddress')
		begin	
				select @AddressLine1=Item From dbo.fnSplitString(@NewValue,':') where ID=1
				select @AddressLine2=Item From dbo.fnSplitString(@NewValue,':') where ID=2
				select @City=Item From dbo.fnSplitString(@NewValue,':') where ID=3
				select @State=Item From dbo.fnSplitString(@NewValue,':') where ID=4
				select @county=Item From dbo.fnSplitString(@NewValue,':') where ID=5
				select @zip4=Item From dbo.fnSplitString(@NewValue,':') where ID=6
				select @zip=Item From dbo.fnSplitString(@zip4,'-') where ID=1
									
				select @zip=ads.AddressId from  kypenrollment.paccount_pdm_party Pa		
				JOIN KYPEnrollment.pAccount_PDM_Location lo ON lo.PartyID = pa.PartyID
				JOIN KYPEnrollment.pAccount_PDM_Address ads ON lo.AddressID = ads.AddressID	
				where Pa.PartyID=@PrimaryID	
						
				update [KYPEnrollment].pAccount_PDM_Address set AddressLine1=@AddressLine1,AddressLine2= @AddressLine2,City=@City,
				State=@State,County=@county,ZipPlus4=@zip4,Zip=@zip where AddressID=@zip
					
		END
		else if(@FieldName='MocaEffectiveDate')
		begin
			/*Commented by Vasant on 17th July to fix KEN-17663 (WRONG TABLE WAS UPDATING)*/
			--update KYPEnrollment.pAccount_PDM_Owner_Role set DateCreated=@NewValue where PartyID=@PrimaryID
   
			update KYPEnrollment.pAccount_pdm_party set MOCARelationshipStartDate=@NewValue where PartyID=@PrimaryID
			
		END -- Moca Tab END
		
		
			/*Inter Tracking table for Multiple account update*/
		Insert into Kypenrollment.SuperUserHistoryTrack(AccountID, TabName, SectionName, FieldName, OldValue, NewValue, LastActionDate, LastActorUserID, PrimaryID, CurrentRecordFlag, ParentAccountID)
		Select AccountID,@TabName,@SectionName,@FieldName,@OldValue,@NewValue,@LastActionDate,@LastActorUserID,@PrimaryID,1,@AccountID
		From @Tab_MultipleAccounts
		
	  --Added the below Update Statement for KEN-21574 by Sundar on 5-Apr-2019
	  -- modified by rahul for bug KEN-21930 tigger was throwing error since multiple accounts are updated
	  Update T2
	  Set T2.IsProvOwnedData = 1,
	  Row_Updation_Source='KYPEnrollment.SP_SuperUserHistory',
	  LastActionDate=getdate()
	  From @Tab_MultipleAccounts T1
	  Join kypenrollment.PADM_Account T2 on T1.AccountID = T2.AccountID
	  Where T2.IsDeleted = 0		
		
		
END


GO

