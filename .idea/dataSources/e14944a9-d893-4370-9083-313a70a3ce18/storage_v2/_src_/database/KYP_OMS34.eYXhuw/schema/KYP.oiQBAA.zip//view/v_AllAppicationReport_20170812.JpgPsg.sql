CREATE VIEW [KYP].[v_AllAppicationReport_20170812] 
AS
	SELECT 
	ROW_NUMBER() over(order by A.DateReceived Desc) As RID,
	A.CaseID,
	A.ProviderName,A.Number,
	COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
	COALESCE(LTRIM(RTRIM(NULLIF(A.ApplnType,''))),'NA') As ApplnType,
	COALESCE(LTRIM(RTRIM(NULLIF(A.TypeDescription	,''))),'NA') As TypeDescription,
	cast(A.DateReceived as datetime) As DateReceived,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DateResolved as date), 101),''))),'NA') As DateResolved,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DueDate as date), 101),''))),'NA') As DueDate,
	COALESCE(LTRIM(RTRIM(NULLIF(A.UserFullName,''))),'NA') As UserFullName,
	CASE WHEN A.ResolutionStatus='Approved' then 'Approve' else COALESCE(LTRIM(RTRIM(NULLIF(A.ResolutionStatus,''))),'NA')  
	 END As ResolutionStatus,
	A.WFStatus,A.IsPPURequired,A.MILESTONE
FROM KYP.ADM_Case A WHERE A.IsPPURequired = 0  AND A.WFProcessing = 0


GO

