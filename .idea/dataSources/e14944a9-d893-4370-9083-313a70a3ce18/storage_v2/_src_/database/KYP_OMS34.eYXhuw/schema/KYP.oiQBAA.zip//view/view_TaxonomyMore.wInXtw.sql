

CREATE VIEW [KYP].[view_TaxonomyMore]
AS
SELECT     V.MoreValueID, ScreeningID, HMSID, AttributeName, DisclosedData, FoundData, MatchResult, Category, SortOrder,FlagCount, pivat.DNPI, pivat.FNPI, 
                      pivat.DTaxonomyDesc, pivat.FTaxonomyDesc
FROM         (SELECT     D .MoreValueID, DetailAttributeName, DetailAttributeValue, row_number() OVER (partition BY DetailAttributeName
                       ORDER BY D .MoreValueID) rn
FROM         KYP.SDM_MoreValueDetail AS D, KYP.SDM_MoreValue AS V
WHERE     D .MoreValueID = V.MoreValueID) AS s PIVOT (MAX(DetailAttributeValue) FOR [DetailAttributeName] IN (DNPI, FNPI,DTaxonomyDesc,FTaxonomyDesc)) AS pivat RIGHT 
JOIN
KYP.SDM_MoreValue AS V ON pivat.MoreValueID = V.MoreValueID


GO

