
-- =============================================
-- Author:  <Lacunza, Giresse>
-- Create date: <22/09/2017>
-- Description: <This procedure generates package for the Transportation Mode Incorporated (Other Entities) >
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_FSP_MDT_IN] (
   @new_Account_Id         INT,
   @new_Party_Id           INT,
   @party_Id               INT,
   @last_Action_User_ID    VARCHAR (100),
   @application_no         VARCHAR (10),
   @application_Id         INT,
   @application_type       VARCHAR (40),
   @provider_type_code varchar(10))



AS
BEGIN
   DECLARE
      @new_Address_Id            INT,
      @npi_Type                  VARCHAR (20),
      @npi                       VARCHAR (10),
      @account_number            VARCHAR (20),
      @new_org_id                INT,
      @package					 varchar(10),
      @isGroup BIT ;
   --SET NOCOUNT ON;


      EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,
                                                        @new_Account_Id,
                                                        @new_Party_Id,
                                                        @last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';

    SELECT @npi_Type = NPIType,@account_number = AccountNumber, @npi = NPI, @package = PackageName FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id and IsDeleted=0
    select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id

   --Social Form: Profile Information:


   --Business Profile

   	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Main_Info] @new_Account_Id,@party_Id,  @last_Action_User_ID,NULL;

	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id
		
	  EXEC [KYPEnrollment].[sp_Copy_GeoLocations]	@new_Account_Id,	@new_Party_Id,	@party_Id, 	@last_Action_User_ID;

	  select @new_org_id = o.OrgID from KYPEnrollment.pAccount_PDM_Organization o where o.PartyID=@new_Party_Id and CurrentRecordFlag=1;


   --Logistics
   --Hours of Operation
   --Mode of Transportation

   EXEC [KYPEnrollment].[sp_Copy_All_transport] 	@new_Account_Id,
													@new_Party_Id,
													@party_Id,
													@application_Id,
													@application_type,
													@last_Action_User_ID,
													@provider_type_code;
													
													
   EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id,
											 @party_Id,
											 @last_Action_User_ID,
											  NULL;


   EXEC [KYPEnrollment].[sp_Copy_Business_Hours_CA] @new_Party_Id,@party_Id;
   
   
   EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id,@party_Id,@last_Action_User_ID;



		--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
		IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
		BEGIN
		
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_Party_Id, null,@application_Id,@party_Id, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
		
		END

    EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id,
                                                 @new_org_id,
                                                 @new_Address_Id,
                                                 @npi_Type,
                                                 @last_Action_User_ID,
                                                 @npi,
                                                 @new_Party_Id,
                                                 @party_Id,
                                                 0,
                                                 @provider_type_code,
                                                 @account_number,
                                                 NULL,
                                                 'F',
                                                 @application_Id,
                                                 @isGroup ,
                                                 @application_type;

END
GO

