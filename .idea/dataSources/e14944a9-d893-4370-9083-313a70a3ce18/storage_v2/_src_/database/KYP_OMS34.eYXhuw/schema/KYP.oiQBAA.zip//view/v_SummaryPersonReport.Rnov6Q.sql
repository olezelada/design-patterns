




CREATE VIEW [KYP].[v_SummaryPersonReport]
AS

SELECT     --row_number() OVER (ORDER BY Q.PartyID ASC) AS ID,
apppartyid as id,
 *
FROM         
(

SELECT TOP (100) PERCENT B.PartyID, D.AddressLine1, D.AddressLine2, D.City, D.State, D.Zip, D.ZipPlus4,
 H.TIN As TINCheck,H.SSN AS SSNCheck, H.GSAEPLS, H.OIGLEIE, H.DMF, 
			  CASE 
					WHEN H.TIN = 'Y' THEN 'Not Disclosed' 
					ELSE (
				  SUBSTRING(B.TaxId, 1, 2) + '-' + 
                  SUBSTRING(B.TaxId, 3,15)
                  )
               END TIN,
			   --CASE 
					--WHEN H.TIN = 'Y' THEN 'Not Disclosed' 
					--ELSE CONVERT(varchar(15),B.TaxId)
               --END TIN,
               
			   CASE 
					WHEN H.SSN = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),B.SSN)
               END SSN,
               
			   CASE 
					WHEN H.OIGLEIE = 'T' THEN 'Active'  
					WHEN H.OIGLEIE = 'F' THEN 'Not Present' 
					WHEN H.OIGLEIE = 'P' THEN 'Likely Active'
					ELSE 'Not Present'
				END AS OIGLEIECheckResult, 
               CASE 
					WHEN H.GSAEPLS = 'T' THEN 'Active' 
					WHEN H.GSAEPLS = 'F' THEN 'Not Present' 
					WHEN H.GSAEPLS = 'P' THEN 'Likely Active'
					ELSE 'Not Present'
				END AS GSAEPLSCheckResult, 
			   
			   CASE
					 WHEN H.SANDI_NPI_STATUS = 'T' OR H.SANDI_LICENSE_STATUS = 'T' OR H.SANDI_ADDRESS_STATUS = 'T' THEN 'Active'
					 WHEN H.SANDI_NPI_STATUS = 'P' OR H.SANDI_LICENSE_STATUS = 'P' OR H.SANDI_ADDRESS_STATUS = 'P' THEN 'Likely Active'
					 ELSE 'Not Present'
			   END AS SandICheckResult,	
				
               CASE 
					WHEN H.DMF = 'T' THEN 'Active' 
					WHEN H.DMF = 'F' THEN 'Not Present' 
				END AS SSADMFCheckResult, 
               CASE 
					WHEN H.CourtCheck = 'T' THEN 'True' 
					WHEN H.CourtCheck = 'P' THEN 'Partial' 
					WHEN H.CourtCheck = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.CourtCheck = 'F' THEN 'Negative' 
					WHEN H.CourtCheck = 'X' THEN 'Not Found' 
					WHEN H.CourtCheck = 'Y' THEN 'Found (Not Disclosed)'
					
					END AS CourtCheckResult,
					
				CASE 
					WHEN H.TIN = 'T' THEN 'True' 
					WHEN H.TIN = 'P' THEN 'Partial' 
					WHEN H.TIN = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.TIN = 'F' THEN 'Negative' 
					WHEN H.TIN = 'X' THEN 'Not Found' 
					WHEN H.TIN = 'Y' THEN 'Found (Not Disclosed)'
				END AS TINCheckResult, 
				
               CASE 
					WHEN H.SSN = 'T' THEN 'True' 
					WHEN H.SSN = 'P' THEN 'Partial' 
					WHEN H.SSN = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.SSN = 'F' THEN 'Negative' 
					WHEN H.SSN = 'X' THEN 'Not Found' 
					WHEN H.SSN = 'Y' THEN 'Found (Not Disclosed)'
				END AS SSNCheckResult,
				
				 CASE
					WHEN ltrim(rtrim(isnull(I.AddressesCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.AddressesCount,'')))='' THEN NULL
					WHEN I.AddressesCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.AddressesCount)+' Found' 
                 END AS AddressesCount,
                 
                 CASE 
					WHEN ltrim(rtrim(isnull(I.AdverseActionsCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.AdverseActionsCount,'')))='' THEN NULL
					WHEN I.AdverseActionsCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.AdverseActionsCount)+' Found' 
                 END AS AdverseActionsCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(I.SSNCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.SSNCount,'')))='' THEN NULL 
					WHEN I.SSNCount IS NULL THEN NULL
					ELSE CONVERT(VARCHAR,I.SSNCount)+' Fraud Alert Found' 
                 END AS SSNCount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(I.ProfileCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.ProfileCount,'')))='' THEN NULL  
					WHEN I.ProfileCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.ProfileCount)+' AKA Found' 
                 END AS ProfileCount,
                 
                 CASE 
					WHEN ltrim(rtrim(isnull(I.CriminalCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.CriminalCount,'')))='' THEN NULL
					WHEN I.CriminalCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.CriminalCount)+' Criminal Found' 
                 END AS CriminalCount,
                 
				 CASE
					WHEN ltrim(rtrim(isnull(I.CriminalExpansionsCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.CriminalExpansionsCount,'')))='' THEN NULL 
					WHEN I.CriminalExpansionsCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.CriminalExpansionsCount)+' CriminalExpansion Found' 
                 END AS CriminalExpansionsCount,
				 
				 CASE
					WHEN ltrim(rtrim(isnull(I.BankrupticesCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.BankrupticesCount,'')))='' THEN NULL  
					WHEN I.BankrupticesCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.BankrupticesCount)+' Bankruptice Found' 
                 END AS BankrupticesCount,
                 
                 CASE 
					WHEN ltrim(rtrim(isnull(I.PersonTaxLiensCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.PersonTaxLiensCount,'')))='' THEN NULL 
					WHEN I.PersonTaxLiensCount IS NULL THEN NULL
					ELSE 'Total '+CONVERT(VARCHAR,I.PersonTaxLiensCount)+' Infractions Found' 
                 END AS InfractionsCount,
                 
                 CASE 
					 WHEN H.IW_NPI_STATUS = 'T' OR H.IW_LICENSE_STATUS = 'T' OR H.IW_NAME_ADDRESS_STATUS = 'T' THEN 'Active'
					 ELSE 'Not Present'
                  END AS KYPWATCHLIST,
                  CASE 
					 WHEN H.MCSIS_MD_NAME_ADDR_STATUS = 'T' OR H.MCSIS_MD_NPI_STATUS = 'T' OR H.MCSIS_MR_NAME_ADDR_STATUS = 'T' OR H.MCSIS_MR_NPI_STATUS='T' THEN 'Active'
					 ELSE 'Not Present'
                  END AS MCSISWATCHLIST,
                  
                 X.EXCLUDATE ,
				 X.EXCLUTYPE,
				 X.ACTIONDATE,
				 X.ACTIONTYPE,
				 NULL AS AddressSection,
				 NULL AS RelativeSection,
				 NULL AS AKASection,
				 NULL AS SSNFraudAlertSection,				
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='CriminalSection')+ ' Found' AS CriminalSection,			 
				 'related to '+(select top 1 Description  FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='CriminalRecord')+ ' Found' AS InfractionSection,
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='LienJudgmentSection')+ ' Found' AS LienJudgmentSection,
				 'related to '+(select top 1 Description FROM KYP.SDM_AdverseActionDetail where ScreeningID=G.ScreeningID and Type='BankruptciesSection')+ ' Found' AS BankruptciesSection,
				 
                 'Name' as NameText,'Name:' as NameColonText,'Role:' as RoleText,'TAXID' AS TaxIDText, 'SSN' as SSNText,'Address' as AddressText,
				 'Adverse Actions/ Negative News' as AdverseActionsText,'OIG LEIE' as OIGLEIEText,'SAM' as SAMText,
				 'MCSIS' as MCSISText,'KYP Watchlist' as KYPWatchlistText,'SSA DMF' as SSADMFText,
				 'Type:' as TypeText,'Date:' as DateText,'Agency:' as ActionText,'Date of Death:' as DateDeathText,
				 CASE WHEN (SELECT COUNT(*) FROM KYP.OIS_App_Version WHERE StateCode = 'MD')>0
				 THEN 'DEEM Watchlist '
				 ELSE 'S&I Watchlist ' 
				 END
				 as SandIWatchlistText,
				 
				G.AppPartyID, G.ScreeningID ,A.Name, A.Name+';' as NameComaText ,G.PartyType AS PartyRole, G.ApplicationID, 
				
				CASE 
					WHEN K.DATE_OF_DEATH IS NOT NULL AND K.DATE_OF_DEATH <> '' THEN 'Date of Death: '+K.DATE_OF_DEATH
					ELSE K.DATE_OF_DEATH
				END AS DATEOFDEATH
				
FROM  KYP.SDM_ApplicationParty AS G
		LEFT JOIN KYP.PDM_Party AS A ON A.PartyID = G.PartyID AND G.IsActive=1  
		LEFT JOIN KYP.PDM_Person AS B ON A.PartyID = B.PartyID AND (A.IsDeleted <> 1 OR A.IsDeleted IS NULL) 
		LEFT JOIN KYP.PDM_Location AS C ON A.PartyID = C.PartyID 
		AND (C.IsDeleted <> 1 OR C.IsDeleted IS NULL) 
		AND C.LocationID in(select MAX(LocationID) from KYP.PDM_Location where PartyID = A.PartyID)
		LEFT JOIN KYP.PDM_Address AS D ON C.AddressID = D.AddressID 
		LEFT JOIN KYP.SDM_DBCheckResult AS H ON H.ScreeningID = G.ScreeningID 
		LEFT JOIN KYP.SDM_DBCheckDetail AS I ON I.DBChkResultID = H.DBChkResultID 
		LEFT JOIN KYP.SDM_DMFDeatils AS K ON I.DBChkDetailID = K.DBChkDetailID
		LEFT JOIN (
					SELECT 'Date: '+ CONVERT(VARCHAR(25), CONVERT(DATETIME, EXCLUDATE), 101) + ' Found' AS EXCLUDATE,
					COALESCE('Type: related to '  +',','') +(SELECT DESCRIPTION FROM KYP.HMS_ProvORG_OIGLEIE_ExclusionType B WHERE ISNULL(B.EXCLTYPE,'') = ISNULL(KYP.ReportWatchListData.EXCLUTYPE,''))  
					+ ' Found' AS EXCLUTYPE,
					'Date: '+ CONVERT(VARCHAR(25), CONVERT(DATETIME, ACTIONDATE), 101) + ' Found' AS ACTIONDATE,
					'Agency: related to ' + ACTIONTYPE + ' Found' AS ACTIONTYPE,
					ScreeningID
			FROM KYP.ReportWatchListData WHERE OIGPartyID IS NOT NULL AND OIGPartyID <> ''
		)X ON G.ScreeningID = X.ScreeningID 
		

		 
)Q


GO

