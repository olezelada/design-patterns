



CREATE  PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_SignifSecondAdd_NewModel]
	@party_id INT, 
	@new_party_id INT,	
	@last_action_user_id VARCHAR(100),
	@app_party_row_id INT,
	@account_id       INT,
	@taxidprofileid   INT

AS
BEGIN
	DECLARE @party_adr INT,
	@new_party_adr INT,
	@count_association INT,
	@main_party_id INT,
	@is_prepopulated BIT,
	@target_path VARCHAR(200),
	@full_name_person VARCHAR(100),
	@type VARCHAR (50),
	@org_id INT,
	@legal_name VARCHAR(100),
	@person_id INT;
	print '[sp_Copy_Party_Loc_Addr_Signif Second Add]';
	--new account
	IF @app_party_row_id IS NULL
	BEGIN
	   	    
	    declare @party table(pk int identity(1,1),PartyID INT,IsPrepopulated BIT, TargetPath VARCHAR(200),Type varchar(50))
	    --**
	    DECLARE @SubmissionDate date; 
	    SELECT  @SubmissionDate=trak.DateTracking 
         FROM KYPPORTAL.PortalKYP.pADM_Application ap  INNER JOIN KYPPORTAL.PortalKYP.pApplicationHistoryTracking trak ON  ap.applicationNo = trak.applicationNumber 
        where 
	       trak.applicationMilestone like 'Submitted' and ap.PartyID = @party_id
	       
	    DECLARE @date_Create DATE;
		SET @date_Create = GETDATE()   
	    --**
	   	
		insert into @party		
		select  p.PartyID, p.IsPrepopulated, p.TargetPath, p.type from Kypportal.PortalKYP.pPDM_Party p 
	    where ParentPartyID = @party_id and p.type='WhollyOwnedSupplied' and ( p.IsPrepopulated is null or p.IsPrepopulated =0)
		and isdeleted = 0
		
		declare  @parties table (partyEnroll int, partyPortal int) 
		--**Party**
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
		([Type] ,
		[Name] ,
		[IsProvider] ,
		[IsEnrolled] ,
		[IsTemp] ,
		[IsActive] ,
		[LoadType] ,
		[LoadID] ,
		[LastLoadDate] ,
		[IsDeleted],
		[DateModified] ,
		[CurrentRecordFlag] ,
		[Source] ,
		[LastAction] ,
		[LastActionDate] ,
		[profile_id],
		[ParentPartyID],
		[AccountID],
		[LastActorUserID],
		[LastActionApprovedBy],
		[TaxidProfileID],
		MOCARelationshipStartDate,
		LastMOCARelationshipUpdateBy,
        LastMOCAUpdateBy ,
        temppartyid 
		
		)
		output inserted.PartyID,inserted.TempPartyID into @parties
		SELECT [Type]
		,[Name]
		,[IsProvider]
		,[IsEnrolled]
		,[IsTemp]
		,[IsActive]
		,[LoadType]
		,[LoadID]
		,[LastLoadDate]
		,[IsDeleted]
		,[DateModified]
		,1
		,[Source]
		,'C'
		,@date_Create
		,[profile_id]
		,null
		--,@parent_party_Id
		,@account_id
		,@last_action_user_id
		,@last_action_user_id
		,@TaxidProfileID 
		,@SubmissionDate
		,'P'
		,'P'
		,partyid
		
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID  in (select partyid from @party)
		--**Organization**
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization] (
                  [PartyID],
                  [TIN],
                  [LegalName],
                  [DBAName1],
                  [BusinessName],
                  [Phone1],
                  [Remarks],
                  [CreatedBy],
                  [DateCreated],
                  [IsDeleted],
                  [Fax],
                  [NPI],
                  [License],
                  [EIN],
                  [Medicaid],
                  [DEA],
                  [Sellers],
                  [IsCorporation],
                  [Extension],
                  [CalOmsNumber],
                  [IsCalOms],
                  [LastAction],
                  [LastActionDate],
                  [LastActorUserID],
                  [LastActionApprovedBy],
                  [CurrentRecordFlag],
                  [OrgNumber])
      SELECT par.partyEnroll ,
             [TIN],
             [LegalName],
             [DBAName1],
             [BusinessName],
             [Phone1],
             [Remarks],
             org.[CreatedBy],
             @date_create,
             org.[IsDeleted],
             [Fax],
             [NPI],
             [License],
             [EIN],
             [Medicaid],
             [DEA],
             [Sellers],
             [IsCorporation],
             [Extension],
             [CalOmsNumber],
             [IsCalOms],
             'C',
             @date_create,
             @last_action_user_id,
             @last_action_user_id,
             1,
             [OrgNumber]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] org inner join @parties par on org.PartyID=par.partyPortal  
       WHERE org.PartyID in (select partyid from @party)
 
      --**Address and Location
      declare @adre table (partadreEnroll int, partadreportal int)
       INSERT INTO [KYPEnrollment].[pAccount_PDM_Address] (
                        [AddressLine1],
                        [AddressLine2],
                        [County],
                        [City],
                        [Zip],
                        [ZipPlus4],
                        [State],
                        [Country],
                        [Latitude],
                        [Longitude],
                        [GeographicArea],
                        [LastAction],
                        [LastActionDate],
                        [LastActionUserID],
                        [LastActionApprovedByUsedID],
                        [CurrentRecordFlag],
                        [AdaAccessible],   
                        [TtyCapacity],
                        [TtyNumber],
                        tempaddressid
                        )
              output inserted.AddressID,inserted.TempAddressID into @adre              
            SELECT [AddressLine1],
                   [AddressLine2],
                   [County],
                   [City],
                   [Zip],
                   [ZipPlus4],
                   [State],
                   [Country],
                   [Latitude],
                   [Longitude],
                   [GeographicArea],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [AdaAccessible]         -- New columns for new Packages MD.
                                  ,
                   [TtyCapacity],
                   [TtyNumber],
                   addr.addressid
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] addr inner join kypportal.portalkyp.ppdm_location  loc on addr.addressid=loc.addressid
              
              where loc.partyid in (select partyid from @party)
             

         INSERT INTO [KYPEnrollment].[pAccount_PDM_Location] (
                        [AddressID],
                        [PartyID],
                        [Type],
                        [WorkingDays],
                        [WorkingHours],
                        [Phone1],
                        [Phone2],
                        [Fax],
                        [Remarks],
                        [InActive],
                        [Email],
                        [IsLicensed],
                        [IsRented],
                        [Status],
                        [Name],
                        [IsSchoolSide],
                        [IsDonatedSpace],
                        [IsDeleted],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag])
            SELECT ad.partadreEnroll,
                   par.partyEnroll ,
                   [Type],
                   [WorkingDays],
                   [WorkingHours],
                   [Phone1],
                   [Phone2],
                   [Fax],
                   [Remarks],
                   [InActive],
                   [Email],
                   [IsLicensed],
                   [IsRented],
                   [Status],
                   [Name],
                   [IsSchoolSide],
                   [IsDonatedSpace],
                   [IsDeleted],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1
                   
              FROM  kypportal.portalkyp.ppdm_location loc  inner join @parties par on loc.partyid=par.partyportal
              inner join @adre ad on loc.AddressID=ad.partadreportal     
             

         update kypenrollment.pAccount_PDM_Address set TempAddressID =null where AddressID in (select partadreenroll from @adre)  
         
         --**ownershiptransaction
         INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction]
		(PartyID ,
		[Description] ,
		[Amount] ,
		[IsDeleted],
		[LastAction] ,	
		[LastActionDate] ,
		[LastActorUserID] ,
		[LastActionApprovedBy] ,
		[CurrentRecordFlag])
		SELECT par.partyEnroll
		,[Description]
		,[Amount]
		,[IsDeleted]
		,'C'
		,@date_create
		,@last_action_user_id
		,@last_action_user_id
		,1
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnerhipTransaction] trans inner join @parties par on trans.partyid=par.partyPortal 		
      --**owner_role
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Owner_Role] (
                        [TypeForm],
                        [PercentCheck],
                        [PercentValue],
                        [Partner],
                        [PartnerValue],
                        [Managing],
                        [ManagingValue],
                        [Director],
                        [DirectorValue],
                        [Other],
                        [OtherValue],
                        [ExecutiveDirector],
                        [ClinicalDirector],
                        [CreatedBy],
                        [DateCreated],
                        [IsDeleted],
                        [PercentDate],
                        [PartnerDate],
                        [ManagingDate],
                        [OtherDate],
                        [Agent],
                        [PartyID],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [SoleOwner],
                        [OtherDateRole],
                        [LessPercent],
                        [BoardMember],
                        [BoardMemberDate],
                        [IsOwner])
            SELECT [TypeForm],
                   [PercentCheck],
                   [PercentValue],
                   [Partner],
                   [PartnerValue],
                   [Managing],
                   [ManagingValue],
                   [Director],
                   [DirectorValue],
                   [Other],
                   [OtherValue],
                   [ExecutiveDirector],
                   [ClinicalDirector],
                   [CreatedBy],
                   @date_create,
                   [IsDeleted],
                   [PercentDate],
                   [PartnerDate],
                   [ManagingDate],
                   [OtherDate],
                   [Agent],
                   par.partyEnroll,
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [SoleOwner],
                   [OtherDateRole],
                   [LessPercent],
                   [BoardMember],
                   [BoardMemberDate],
                   [IsOwner]
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role] rol  inner join @parties par on rol.partyid=par.partyPortal 	
             
		--**
	        
      
        
	END


	
END


GO

