

CREATE VIEW [KYPEnrollment].[pViewGetCountAllFinding]
AS

-- Count Findings Screaning
SELECT (row_number() over ( order by totalFindings)) AS ViewID , totalFindings 
  FROM (
		SELECT (SELECT  COUNT (sf.FindingID) as onea
				 FROM KYP.SDM_ScreeningFinding sf,
					  KYP.OIS_Note n
				where n.NoteID = sf.FindingNoteID
				  and  sf.ScreeningID in ( select ap.ScreeningID
											 from KYP.ADM_Case c,
							  					  KYP.ADM_Application a,
												  KYP.SDM_ApplicationParty ap
											where c.CaseID = a.CaseID
											  and a.ApplicationID = ap.ApplicationID
											  --and ap.ScreeningID = 547
											  --and c.CaseID = 215))+ 
										  )
				)+ 
				(
				 -- Count Findings Enrolment
				 select COUNT (f.FindingID)as onea
				  from KYPEnrollment.pEDM_Findings f,
					   KYPEnrollment.pEDM_FindingEntity fe  	
				 where f.FindingID = fe.FindingID
				   and fe.EntityType = 'pADM_Case'
				) AS totalFindings
	   ) totalCount


GO

