
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [KYP].[RemoveDoubleQuotes] 
(
	@NameValue varchar(100)
)
RETURNS varchar(100)
AS
BEGIN
	--declare 
--@MyStr varchar(50)




select @NameValue =REPLACE(@NameValue,CHAR(34),'')



return @NameValue


END


GO

