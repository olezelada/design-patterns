





-- =============================================
-- Author: Rahul Raghavendra    
-- Create date: 25-Oct-2016
-- Description:   
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date		Description
---------------------------------------------------------------------------------------
-- 1		KEN-7639			Pulliah		14-Dec-2016		To display only one record old or new not both.
-- 2        CAPAVE-1147			Pullaiah    25-Jan-2017		To display StatusBeginDate and StatusEndDate from P_AdmAccount
-- 3		CAPAVE-1246			Sundar		06-Feb-2017		To fetch MOCA NPI from Provider table instead of Account table
-- 4		CAPAVE-1247	        Sundar		08-Feb-2017		Added the fields [NMPRendNPI_New] & [ProvTC_New] and Calculation for the same. Also,added the date 2069-12-31 when AffiliationEndDate is null for NMP
-- 5		CAPAVE-1284/1285	Sundar		16-Feb-2017		Added the condition LastActorUserID='System' to ignore the changes made by Delta load
-- 6		CAPAVE-1221			Sundar		16-Feb-2017		Changed the calculation of Specialty Code and Date for Biller
-- 7		PI-641				Sundar		03-Mar-2017		Implemented MOCA Color changes
-- 8		PI-755				Sundar		21-Mar-2017		Added Isnull condition for NMP Affiation End Date to display the default date (2069-12-31)
-- 9		PI-754				Sundar,Pullaiah		21-Mar-2017		Added Isnull condition for MOCA End Date, Getting the PartyID 
-- 10		CAPAVE-1393			Sundar		10-Mar-2017		Added Update state to populate the Correct Legal Name
-- 11		CAPAVE-1373			Sundar		19-Apr-2017		Changed the calculation for the field RequestType in Group Rendering and Group Association sections.
-- 12		CAPAVE-1573			Sundar		22-Apr-2017		Changed TIN field for MOCA from TIN to EIN.
-- 13		CAPAVE-1246, 1275	Sundar		3-May-2017		Changed MOCA Start DAte logic for Portal records to consider OtherDAte.
-- 14		CAPAVE-1575			Sundar		10-May-2017		When Speciality Certification Date is null, StatusBeginDate from pADM_Account should be displayed
-- 15		CAPAVE-1247			Sundar		11-May-2017		Considered LastActionDate in place of AffiliationStartDate for highlighting in red color in NMP section for the fields AffiliationStartDate and AffiliationEndDate.
-- 16		CAPAVE-1725			Sundar		29-May-2017		When MOCA Deleted Date is '2069-12-31' then it should not be highlighted.
-- 17		PI-799				Sundar		31-May-2017		Created a separate SP for the Billing Provider Information section as it is been used in ORP SP also.
-- 18		CAPAVE-1739			Sundar		02-Jun-2017		When MOCA Deleted Date is null then the default date '2069-12-31' should be displayed
-- 19		PI-804				Sundar		06-Jun-2017		Fixed the issue in "Request Type" field that was not working for Disaffiliation scenario.
-- 20		CAPAVE-1742			Sundar		06-Jul-2017		Fixed the issue for MOCA Legal name not being highlighted.
-- 21		CAPAVE-1955			Sundar		09-Aug-2017		Suppressed legacy IDs for Group Affiliation and Association Sections of Input Doc.
-- 22		KEN-12838			Sundar		17-Aug-2017		Implemented PAVE 3.0 changes for Input Document
-- 23		PI-842				Sundar		4-Sep-2017		Added CurrentRecordFlag condition for Taxonomy
-- 24		PI-837				Sundar		4-Sep-2017		Changed the logic for MOCA NPI
-- 25		PI-840				Sundar		7-Sep-2017		Added Account created date <> LastActionDate condition
-- 26		KEN-13631			Sundar		13-Sep-2017		Changed the logic for Lab Specialty
-- 27		KEN-13742			Sundar		27-Sep-2017		When no data is available in the table then, blank rows are inserted to resolve the moca section missing issue
-- 28		KEN-13990			Pullaiah	18-Oct-2017		Changing the status begin date to to redering instead of pADM_Account line modified is 1012 A->AR
-- 29		CAPAVE-2103			Sundar		14-Oct-2017		Added CurrentRecordFlag=1 condition in Specialty Section
-- 30		CAPAVE-2467			Sundar		11-Jan-2018		Added default date when affiliation Start End date is null for Group Rendering and Group Association sections
-- 31		KEN-15078			Sundar		15-Jan-2018		Added If condition to avoid duplicate records on Input docs generated between Delta Load time and Input Doc posting time
-- 32		CAPAVE-2540			Sundar		1-Feb-2018		When MOCA NPI is 0 then Null should be displayed in MOCA Section
-- 33		CAPAVE-2541			Sundar		1-Feb-2018		Fixed the Sequence issue in the NMP Section
-- 34		CAPAVE-2570			Sundar		1-Feb-2018		Added isnull condition for FirstName, LastName in the Legal Name field in MOCA section
-- 35		KEN-14820			Sundar		9-Mar-2018		Changed the MOCA query to get data from TaxIDProfile table for MOCA Linking
-- 36		KEN-15462			Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- 37		CAPAVE-2270			Sundar		13-Mar-2018		Changed the MOCA Effective date field to MOCARelationshipStartdate for both MMIS and PAVE accounts
-- 38		CAPAVE-2763			Ganesh 		21-Mar-2018 	Input Doc: Invalid NMP affiliation duplicated with different BEG DTs
-- 39 		CAPAVE-2816			Ganesh		11-Apr-2018		Input Doc: Blank affiliation date on biller input doc for existing grp members
-- 40		CAPAVE-3142, 3139 Sundar	8-May-2018	Added EDM_AccountInternalMany.IsApproved = 1 to consider only the approved IUD changes
-- 41		CAPAVE-3235			Sundar		14-May-2018		Lab Specialty End Date should display the default date (2069-12-31) if it is blank.
-- 42							Sundar		15-May-2018		Switching Off MOCA in Input Document
-- 43       KEN-17237           Ramya       21-May-2018     added isdeleted condition(isdeleted=0 and isdeleted-is null) to remove the duplicates from the input doc
-- 44       KEN-18013           Ramya       03-july-2018     If the affiliation end date is future date(greater than current date) then action field should not show 'D'.
-- 45		CAPAVE-4277			Sundar		19-Nov-2018		Added condition for AffiliationEndDate field in the query for NMP Section

CREATE PROCEDURE [KYPEnrollment].[Usp_IDoc_Biller]  
      -- Add the parameters for the stored procedure here
      @acc_party_id int, 
      @Username varchar(50),
      @UserDate date
AS
BEGIN

	Declare @Date bigint

	Set @Date = convert(bigint,CONVERT(varchar(8),@UserDate,112));

	Exec kypenrollment.USP_IDoc_Biller_Info @acc_party_id, @Username, @UserDate; --Added for #17 PI-799

--Commented for #17 PI-799
      /*Declare @v_Str varchar(8000) = '',
                  @v_Select_Str varchar(4000) = '',
                  @v_Pivot_Str varchar(2000) = '',                
                  @v_Insert_Str varchar(4000) = '',
                  @v_Pivot_Qry varchar(4000) = '',
                  @Date bigint,
                  @SCodeIdty varchar(2000) = '',
                  @c int=0,
                  @StatusBeginDate varchar(10); --Added for #14 CAPAVE-1575                  
--	--BEGIN Try
	If exists (select object_id
						  from sys.objects
						  where name = 'Stage_InputDoc')
	Begin
		Drop table Stage_InputDoc;
	End                              

	Set @Date = convert(bigint,CONVERT(varchar(8),@UserDate,112));
	
	--Sanction Changes start
	
	Select @SCodeIdty = @SCodeIdty+''''+ coalesce(CodeIdentification,'')+''',',
			@c = @c+1
	from (
	SELECT C.AccountId, 
		isnull(CONVERT(varchar(20),(case when CodeIdentification = 'other' then left(UPPER(CodeDescription),5) else CodeIdentification end)),'') as CodeIdentification,
		ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID DESC)  R
	from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
	where AccountID=@acc_party_id/*2011886*/) T	
	Where R<9;

	select @SCodeIdty = @SCodeIdty+REPLICATE('NULL,',(8-@c))
	--Sanction Changes start
	
	--Added the below Select statement for #14 CAPAVE-1575
	Select @StatusBeginDate = Convert(varchar(10),StatusBeginDate,101)
	From KYPEnrollment.pADM_Account
	Where AccountID = @acc_party_id	
	
	select T1.AccountID,t1.FieldName, t1.ToValue into Stage_InputDoc
		from KYPENROLLMENT.INPUTDOC_BILLER T1
		Join (select FieldName,MAX(ID) ID
			  from KYPENROLLMENT.INPUTDOC_BILLER
			  where AccountID=@acc_party_id
			  and convert(bigint,DateSearch) >= @Date
			  and FieldName not in ('Spec_C','SpecCertDT') -- Added for #6 CAPAVE-1221
			  Group by FieldName
			  ) t2 on t1.ID=t2.id
			  
	--print @acc_party_id
	--print @Date

	--Insert clause Static fields 
	set @v_Insert_Str = '[AccountID],[PartyID],[ProvNameScan],[Analyst],[AnalystDT],[Reviewer],[ReviewerDT],[Supervisor],[SupervisorDT],[NPI],[OwnerNo],[SerLocNo],[ProviderType],[DocNo],[ProfileID],'
						--+'[Spec_C1_old],[Spec_C2_old],[Spec_C3_old],[SpecCertDT1_old],[SpecCertDT2_old],[SpecCertDT3_old],'--#6

	--Add ScodeIdentity fields
	Set @v_Insert_Str = @v_Insert_Str+'[ScodeIdty1_old],[ScodeIdty2_old],[ScodeIdty3_Old],[ScodeIdty4_Old],[ScodeIdty5_Old],[ScodeIdty6_Old],[ScodeIdty7_Old],[ScodeIdty8_Old],'
						
	--Insert clause Fields that are changed
	set @v_Insert_Str = @v_Insert_Str + isnull((select STUFF((select '['+FieldName+'_New],'
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,'')),'');

	--Insert clause Fields that are not changed									  
	set @v_Insert_Str = @v_Insert_Str+(select STUFF((select '['+FieldName+'_Old],'
									  from (Select Column_name FieldName
												  from INFORMATION_SCHEMA.COLUMNS
												  where TABLE_NAME='AccountInputDocFullLoad'
												  and COLUMN_NAME not in ('AccountID','UserNAme','ID',
																		'PartyID',
																		'ProvNameScan',
																		'Analyst',
																		'AnalystDT',
																		'Reviewer',
																		'ReviewerDT',
																		'Supervisor',
																		'SupervisorDT',
																		'NPI',
																		'OwnerNo',
																		'SerLocNo',
																		'ProviderType',
																		'DocNo',
																		'ProfileID',
																		'LastLoadedDate',
																		'ScodeIdty1',--Sanction Changes start
																		'ScodeIdty2',
																		'ScodeIdty3',
																		'ScodeIdty4',
																		'ScodeIdty5',
																		'ScodeIdty6',
																		'ScodeIdty7',
																		'ScodeIdty8',--Sanction Changes end
																		/*#6 CAPAVE-1221 Start*/
																		--'Spec_C1', --added for Spec code
																		--'Spec_C2',
																		--'Spec_C3',
																		--'SpecCertDT1',
																		--'SpecCertDT2',
																		--'SpecCertDT3' --added for Spec code
																		'Spec_C',
																		'SpecCertDT'																		
																		/*#6 CAPAVE-1221 End*/
																		
																		)
												  except
												  select FieldName
												  from Stage_InputDoc) S order by FieldName for xml path('')),1,0,''));     

	--Removing the trailing comma
	set @v_Insert_Str = LEFT(@v_Insert_Str,len(@v_Insert_Str)-1);									  
	
	--Pivot clause fields								  
	set @v_Pivot_Str = (select STUFF((select '['+FieldName+'],'
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,''));

	--Removing the trailing comma
	If isnull(len(@v_Pivot_Str),0)>0
	Begin                                    
	set @v_Pivot_Str = LEFT(@v_Pivot_Str,len(@v_Pivot_Str)-1);
	End

	--Select clause fields that are changed
	set @v_Select_Str = isnull((select STUFF((select 't2.['+FieldName+'],'
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,'')),'');

	--Select clause fields that are not changed
	set @v_Select_Str = @v_Select_Str+(select STUFF((select 't1.['+FieldName+'],'
									  from (Select Column_name FieldName
												  from INFORMATION_SCHEMA.COLUMNS
												  where TABLE_NAME='AccountInputDocFullLoad'
												  and COLUMN_NAME not in ('AccountID','UserNAme','ID',
																		'PartyID',
																		'ProvNameScan',
																		'Analyst',
																		'AnalystDT',
																		'Reviewer',
																		'ReviewerDT',
																		'Supervisor',
																		'SupervisorDT',
																		'NPI',
																		'OwnerNo',
																		'SerLocNo',
																		'ProviderType',
																		'DocNo',
																		'ProfileID',
																		'LastLoadedDate',
																		'ScodeIdty1',----Sanction Changes start
																		'ScodeIdty2',
																		'ScodeIdty3',
																		'ScodeIdty4',
																		'ScodeIdty5',
																		'ScodeIdty6',
																		'ScodeIdty7',
																		'ScodeIdty8',--Sanction Changes end
																		/*#6 CAPAVE-1221 Start*/
																		--'Spec_C1', --added for Spec code
																		--'Spec_C2',
																		--'Spec_C3',
																		--'SpecCertDT1',
																		--'SpecCertDT2',
																		--'SpecCertDT3' --added for Spec code
																		'Spec_C',
																		'SpecCertDT'
																		/*#6 CAPAVE-1221 End*/	
																		)
												  except
												  select FieldName
												  from Stage_InputDoc) S order by FieldName for xml path('')),1,0,''))

	--Removing the trailing comma
	set @v_Select_Str = LEFT(@v_Select_Str,len(@v_Select_Str)-1);

	--Query to get the changed values
	Set @v_Pivot_Qry = 'Left Join (select * '+
			  'From Stage_InputDoc S '+
			  'Pivot (MAX([ToValue]) for FieldName in ('+@v_Pivot_Str+') '+  
			  ' ) P) t2 on t1.AccountId = t2.AccountId'

	--Building the insert statement by joining full load table and the changed data table
	Set @v_Str = 'insert into kypenrollment.Idoc_Biller(UserName,'+@v_Insert_Str+') '+
		'Select '''+@Username+''',t1.AccountID,t1.PartyID,t1.ProvNameScan,t1.Analyst,t1.AnalystDT,t1.Reviewer,t1.ReviewerDT,'+
		't1.Supervisor,t1.SupervisorDT,t1.NPI,t1.OwnerNo,t1.SerLocNo,t1.ProviderType,t1.DocNo,BZ.ProfileId,'/*t1.Spec_C1,t1.Spec_C2,t1.Spec_C3,t1.SpecCertDT1,t1.SpecCertDT2,t1.SpecCertDT3,*/--#6 CAPAVE-1221
		+@SCodeIdty+@v_Select_Str+' '+ 		
		'from KYPENROLLMENT.AccountInputDocFullLoad t1 '
		+'Left Join KYPEnrollment.pAccount_BizProfile_Details BZ ON BZ.AccountID=t1.AccountID ' --PI-693
		+ISNULL(@v_Pivot_Qry,'')+
		' Where T1.AccountID='+convert(varchar(20),@acc_party_id)

	print @v_Str;

	--Execute the insert statement
	Exec (@v_Str)

	/*#6 CAPAVE-1221 Start*/
	--Specialty Code New is updated when there is any change in value for highlighting
	Update IB
	Set IB.Spec_C1_New = FL.Spec_C1,
		IB.SpecCertDT1_New = isnull(FL.SpecCertDT1,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C1 = ID.ToValue
					)
					
	Update IB
	Set IB.Spec_C2_New = FL.Spec_C2,
		IB.SpecCertDT2_New = isnull(FL.SpecCertDT2,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C2 = ID.ToValue
					)
					
	Update IB
	Set IB.Spec_C3_New = FL.Spec_C3,
		IB.SpecCertDT3_New = isnull(FL.SpecCertDT3,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C3 = ID.ToValue
					)								
	
	--Specialty Code Old fields are updated when there is no change in value				
	Update IB
	Set IB.Spec_C1_Old = Case When (IB.Spec_C1_New IS null) Then FL.Spec_C1 End,
	IB.SpecCertDT1_Old = Case When (IB.SpecCertDT1_New is null and FL.Spec_C1 IS Not Null) Then isnull(FL.SpecCertDT1,@StatusBeginDate) End, --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	IB.Spec_C2_Old = Case When (IB.Spec_C2_New IS null) Then FL.Spec_C2 End,
	IB.SpecCertDT2_Old = Case When (IB.SpecCertDT2_New is null and FL.Spec_C2 IS Not Null) Then isnull(FL.SpecCertDT2,@StatusBeginDate) End, --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575	
	IB.Spec_C3_Old = Case When (IB.Spec_C3_New IS null) Then FL.Spec_C3 End,
	IB.SpecCertDT3_Old = Case When (IB.SpecCertDT3_New is null and FL.Spec_C3 IS Not Null) Then isnull(FL.SpecCertDT3,@StatusBeginDate) End --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id	
	/*#6 CAPAVE-1221 End*/

	--#8 CAPAVE-1393
	Update IB
	Set IB.LegalName_New = A.LegalName
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.pADM_Account A on IB.AccountID=A.AccountID
	Where IB.AccountID = @acc_party_id
	AND IB.LegalName_New is not null
	and IB.LegalName_Old is null
	*/
	--truncate table Stage_InputDoc;

/* For colour changes*/

	/*KEN-12838 Start*/
	--Lab Classification 
	If Not Exists(Select Lab_ID
					From kypenrollment.ID_Biller_LAB
					Where AccountID = @acc_party_id)
	Begin	
		Insert into kypenrollment.ID_Biller_LAB(Seq, 
												AccountID, 
												LOld, 
												LNew, 
												LEfDt_Old,
												LEfDt_New,											
												LExDt_Old,
												LExDt_New,
												UserNAme)
		Select ROW_NUMBER() over(order by T.LastActionDate Desc) R,
				T.AccountID,
				T.Lab_Old,
				T.Lab_New,
				Convert(varchar(10),T.EffDt_Old,101),
				Convert(varchar(10),T.EffDt_New,101),
				Convert(varchar(10),T.EndDt_Old,101),
				Convert(varchar(10),T.EndDt_New,101),
				@Username
		From (Select IU.AccountID,NULL Lab_Old,IM.CodeIdentification Lab_New,NULL EffDt_Old,IM.CodeDateEffDate EffDt_New,NULL EndDt_Old,isnull(IM.CodeDateExpDate,'2069-12-31') EndDt_New,ISNULL(IM.LastActionDate,IU.LastActionDate) LastActionDate
				From kypenrollment.Edm_AccountInternalUse IU
				Join Kypenrollment.Edm_AccountInternalMany IM on IU.AccountInternalUseID = IM.AccountInternalUseID
				Where isnull(IM.IsDeleted,0) = 0  --Added Isnull condition on 1-Sep-2017 for #22
				And IM.CodeType = 'Specialty'
				And IU.AccountID = @acc_party_id
				and (IM.LastActorUserID <> 'System' or IM.LastActorUserID is null)
				and (Convert(date,Isnull(IM.LastActionDate,IU.LastActionDate)) >= @UserDate) --Changed for #26 KEN-13631
				and (IU.IsApproved=1 OR IU.IsApproved is null) -- #36 KEN-15462
				and (IM.IsApproved=1 OR IM.IsApproved is null) -- #40 CAPAVE-3142, 3139		
				Union all
				Select IU.AccountID,IM.CodeIdentification,NULL,IM.CodeDateEffDate,NULL,isnull(IM.CodeDateExpDate,'2069-12-31'),NULL,ISNULL(IM.LastActionDate,IU.LastActionDate) LastActionDate
				From kypenrollment.Edm_AccountInternalUse IU
				Join Kypenrollment.Edm_AccountInternalMany IM on IU.AccountInternalUseID = IM.AccountInternalUseID
				Where isnull(IM.IsDeleted,0) = 0  --Added Isnull condition on 1-Sep-2017 for #22
				And IM.CodeType = 'Specialty'
				And IU.AccountID = @acc_party_id
				and (IU.IsApproved=1 OR IU.IsApproved is null)-- #36 KEN-15462				
				and (Convert(date,Isnull(IM.LastActionDate,IU.LastActionDate)) < @UserDate --Changed AND condition to OR on 1-Sep-2017 for #22 --Changed for #26 KEN-13631 
					OR ISNULL(IM.LastActionDate,IU.LastActionDate) IS NULL -- Added this condition for KEN-13631 on 12Sep2017					
					OR IM.LastActorUserID = 'System')
				and (IM.IsApproved=1 OR IM.IsApproved is null) -- #40 CAPAVE-3142, 3139	
				) T
		Order by T.LastActionDate desc										

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into kypenrollment.ID_Biller_LAB(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End
	End;

	--Category of Services
	If Not Exists(Select COS_ID
					From kypenrollment.ID_Biller_COS
					Where AccountID = @acc_party_id)
	Begin	
		Insert into KYPEnrollment.ID_Biller_COS(Seq, 
												AccountID, 
												COld, 
												CNew, 
												CEfDt_Old, 
												CEfDt_New, 
												CExDt_Old, 
												CExDt_New,
												UserName)
		Select ROW_NUMBER() over(Order by T.LastActionDate desc) Seq,
				T.AccountID,
				T.CodeIdentification_Old,
				T.CodeIdentification_New,
				Convert(varchar(10),T.CodeDateEffDate_Old,101),
				Convert(varchar(10),T.CodeDateEffDate_New,101),
				Convert(varchar(10),T.CodeDateExpDate_Old,101),
				Convert(varchar(10),T.CodeDateExpDate_New,101),
				@Username
		From (Select C.AccountID, 
						NULL CodeIdentification_Old, 
						EDMAIM.CodeIdentification CodeIdentification_New, 
						NULL CodeDateEffDate_Old, 
						EDMAIM.CodeDateEffDate CodeDateEffDate_New, 
						NULL CodeDateExpDate_Old, 
						EDMAIM.CodeDateExpDate CodeDateExpDate_New, 
						EDMAIM.LastActionDate							
				From KYPEnrollment.EDM_AccountInternalMany EDMAIM  
				Inner join KYPEnrollment.EDM_AccountInternalUse C on EDMAIM.AccountInternalUseID=C.AccountInternalUseID 
				Where C.AccountID = @acc_party_id		
				and EDMAIM.CodeType = 'Category' and (EDMAIM.isDeleted=0 OR EDMAIM.isDeleted IS NULL) --#43
				and isnull(EDMAIM.currentrecordflag,1)=1
				And convert(date,EDMAIM.LastActionDate) >= @UserDate
				and (EDMAIM.LastActorUserID <> 'System' 
						or EDMAIM.LastActorUserID is null)
				and (C.IsApproved = 1 OR C.IsApproved is null)-- #36 KEN-15462
				and (EDMAIM.IsApproved=1 OR EDMAIM.IsApproved is null) -- #40 CAPAVE-3142, 3139	
				Union all
				Select C.AccountID, 
						EDMAIM.CodeIdentification, 
						NULL, 
						EDMAIM.CodeDateEffDate, 
						NULL, 
						EDMAIM.CodeDateExpDate, 
						NULL, 
						EDMAIM.LastActionDate								
				From KYPEnrollment.EDM_AccountInternalMany EDMAIM  
				Inner join KYPEnrollment.EDM_AccountInternalUse C on EDMAIM.AccountInternalUseID=C.AccountInternalUseID 
				Where C.AccountID = @acc_party_id		
				and EDMAIM.CodeType = 'Category' and (EDMAIM.isDeleted=0 OR EDMAIM.isDeleted IS NULL) --#43
				and isnull(EDMAIM.currentrecordflag,1)=1
				And ((convert(date,EDMAIM.LastActionDate) < @UserDate
						or EDMAIM.LastActionDate is null) --Added Isnull condition on 1-Sep-2017 for #22			
					or EDMAIM.LastActorUserID = 'System')
				and (C.IsApproved = 1 OR C.IsApproved is null)-- #36 KEN-15462	
				and (EDMAIM.IsApproved=1 OR EDMAIM.IsApproved is null) -- #40 CAPAVE-3142, 3139					
				) T
		Order by T.LastActionDate desc

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into KYPEnrollment.ID_Biller_COS(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End
	End;

	--Taxonomy Codes
	If Not Exists(Select Tax_ID
					From kypenrollment.ID_Biller_Taxonomy
					Where AccountID = @acc_party_id)
	Begin			
		Insert into KYPEnrollment.ID_Biller_Taxonomy(Seq, 
												AccountID, 
												TaxnC_Old, 
												TaxnC_New,
												UserName)
		Select ROW_NUMBER() over(Order by T.LastActionDate desc) Seq,
				T.AccountID,
				T.TaxonomyCode_Old,
				T.TaxonomyCode_New,
				@Username
		From (SELECT A.Accountid,
				NULL TaxonomyCode_Old, 
				P.Speciality_Code TaxonomyCode_New,
				P.LastActionDate
			FROM KYPEnrollment.pAccount_PDM_Speciality P
			inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
			Where A.AccountID = @acc_party_id
			and P.CurrentRecordFlag = 1 --Added for #23 PI-842
			and Convert(date,A.DateCreated) <> CONVERT(date,P.LastActionDate) --Added for #25 PI-840				
			and P.Type='Taxonomy Code'
			and P.LastActionDate >= @UserDate
			and (P.LastActorUserID <> 'System'
				OR P.LastActorUserID is null)			
			Union all
			SELECT A.Accountid, 
					P.Speciality_Code TaxonomyCode_Old,
					NULL TaxonomyCode_New,
					P.LastActionDate
			FROM KYPEnrollment.pAccount_PDM_Speciality P
			inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
			Where A.AccountID = @acc_party_id
			and P.CurrentRecordFlag = 1 --Added for #23 PI-842		
			and P.Type='Taxonomy Code'
			and (P.LastActionDate < @UserDate
				or P.LastActorUserID = 'System'
				or Convert(date,A.DateCreated) = CONVERT(date,P.LastActionDate) --Added for #25 PI-840			
				)
			) T
		Order by T.LastActionDate desc									

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into KYPEnrollment.ID_Biller_Taxonomy(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End
	End;
	
	--Specialty Code
	If Not Exists(Select Spec_ID
					From kypenrollment.ID_Biller_Specialty
					Where AccountID = @acc_party_id)
	Begin	
		Insert into kypenrollment.ID_Biller_Specialty(Seq, 
												AccountID, 
												SOld, 
												SNew, 
												LEfDt_Old, 
												LEfDt_New,
												UserName)
		Select ROW_NUMBER() over(Order by T.LastActionDate desc) Seq,
				T.AccountID,
				T.SpecialityCode_Old,
				T.SpecialityCode_New,
				Convert(varchar(10),T.SpecDate_Old,101),
				Convert(varchar(10),T.SpecDate_New,101),
				@Username
		From (SELECT A.Accountid,
				NULL SpecialityCode_Old, 
				P.Speciality_Code SpecialityCode_New,
				Null SpecDate_Old,			
				Isnull(P.SpecCertDate,A.StatusBeginDate) SpecDate_New, --Added Isnull then StatusBeginDate for #22 on 1Sep2017		
				P.LastActionDate
			FROM KYPEnrollment.pAccount_PDM_Speciality P
			inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
			Where A.AccountID = @acc_party_id
			and Convert(date,A.DateCreated) <> CONVERT(date,P.LastActionDate) --Added for #25 PI-840		
			and P.Type='Specialty Code'
			and P.LastActionDate >= @UserDate
			and (P.LastActorUserID <> 'System'
				OR P.LastActorUserID is null)
			and P.CurrentRecordFlag = 1	--Added for #29	CAPAVE-2103							
			Union all
			SELECT A.Accountid, 
					P.Speciality_Code SpecialityCode_Old,
					NULL SpecialityCode_New,
					Isnull(P.SpecCertDate,A.StatusBeginDate) SpecDate_Old, --Added Isnull then StatusBeginDate for #22 on 1Sep2017	
					Null SpecDate_New,				
					P.LastActionDate
			FROM KYPEnrollment.pAccount_PDM_Speciality P
			inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
			Where A.AccountID = @acc_party_id		
			and P.Type='Specialty Code'
			and (P.LastActionDate < @UserDate
				or P.LastActorUserID = 'System'
				or Convert(date,A.DateCreated) = CONVERT(date,P.LastActionDate) --Added for #25 PI-840				
				)
			and P.CurrentRecordFlag = 1	--Added for #29	CAPAVE-2103				
			) T
		Order by T.LastActionDate desc
		/*KEN-12838 End*/

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into kypenrollment.ID_Biller_Specialty(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End
	End

/* All new value bolck start*/
	--Changed the TableName and FieldNames to rectify the mapping issue in the template #22 Ken-12838
	If Not Exists(Select ID
					From kypenrollment.GroupRendForAccount
					Where AccountID = @acc_party_id)
	Begin	
		Insert into KYPENROLLMENT.GroupRendForAccount(
					Se, --Seq 
					GRPIDTY, 
					AccountID, 
					AO, --ReqType_Old
					AN, --ReqType_New
					ProO, --Provider_Old
					ProN, --Provider_New
					OO, --OwnerNo_Old
					[NO], --OwnerNo_New
					SO, --ServiceLocation_Old
					SN, --ServiceLocation_New
					ProvTypeOld, --ProviderType_Old
					ProvTypeNew, --ProviderType_New
					userName, 
					SDO, --AffiliationStartDate_Old
					SDN, --AffiliationStartDate_New
					EDO, --AffiliationEndDate_Old     
					EDN --AffiliationEndDate_New
					)
		select ROW_Number() over(Order by T.LastActionDate desc) as Seq, --#22 KEN-12838
				[GRPIDTY],
				AccountID,
				RequestType_Old,			
				RequestType_New,
				Provider_Old,			
				Provider_New,
				OwnerNo_Old,			
				OWNERNO_New,
				SLocNo_Old,
				SLocNo_New,
				ProvType_Old,			
				ProvType_New,
				UserName, -- added for order based on last action date(PI-601)			
				Convert(varchar(10),AffiliationStartDate_Old,101), --Added for #22 KEN-12838
				Convert(varchar(10),AffiliationStartDate_New,101), --Added for #22 KEN-12838			
				Convert(varchar(10),AffiliationEndDate_Old,101), --Added for #22 KEN-12838				
				Convert(varchar(10),AffiliationEndDate_New,101) --Added for #22 KEN-12838			
		from (select DISTINCT 'A' As GRPIDTY,
					RAff.AccountID,
					Null as RequestType_Old,
					Case 
						When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') and (RAff.AffiliationEndDate<=GETDATE()) then 'D' --Rearranged the When clause for #19 PI-804		 	
						--When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
						When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
						--When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D' 
						--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
						else
						 'E' END AS RequestType_New,				
					NULL as Provider_Old,
					AR.NPI AS Provider_New,
					Null as OwnerNo_Old,
					AR.OwnerNo AS OWNERNO_New,
					Null as SLocNo_Old,
					Ar.ServiceLocationNo AS SLocNo_New,
					Null as ProvType_Old,				
					Left(AR.ProviderTypeCode,3) + '- '+AR.ProviderType AS ProvType_New,--Added first 3 characters of ProviderTypeCode for KEN-13850 by Sundar on 31Mar2018
					@Username As UserName,
					Null as AffiliationStartDate_Old, --Added for #22 KEN-12838
					Raff.AffiliationStartDate AffiliationStartDate_New, --Added for #22 KEN-12838
					Null as AffiliationEndDate_Old, --Added for #22 KEN-12838				
					Isnull(Raff.AffiliationEndDate,'2069-12-31') AffiliationEndDate_New, --Added for #22 KEN-12838 --Added Default Date for #30 CAPAVE-2467
					--ROW_NUMBER() over(order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
					Raff.LastActionDate
				from KYPEnrollment.pAccount_RenderingAffiliation RAff
				LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
				LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
				where RAff.AffiliatedAccountID is not null 
					and RAff.AccountID=@acc_party_id 
					and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
					and(CONVERT(date,RAff.LastActionDate))>=@UserDate 
					and RAff.isDeleted=0 --KEN-7639
					and AR.isDeleted=0 --CAPAVE-2816
					and A.isDeleted=0 --CAPAVE-2816					
					and RAFF.LastActorUserID <> 'System' --#5 CAPAVE-1284, 1285
					and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955
				Union all
				select DISTINCT 'A' As GRPIDTY,
						RAff.AccountID,
						Case 
						When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') and (RAff.AffiliationEndDate<=GETDATE()) then 'D' --Rearranged the When clause for #19 PI-804		 	
						--When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
						When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
						--When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D'  
						--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
						else
						 'E' END AS RequestType_Old,
						Null as RequestType_New,
						AR.NPI AS Provider_Old,
						Null as Provider_New,
						AR.OwnerNo AS OWNERNO_Old,
						Null as OwnerNo_New,
						Ar.ServiceLocationNo AS SLocNo_Old,
						Null as SLocNo_New,
						Left(AR.ProviderTypeCode,3) + '- '+AR.ProviderType AS ProvType_Old,--Added first 3 characters of ProviderTypeCode for KEN-13850 by Sundar on 31Mar2018
						Null as ProvType_New, 
						@Username As UserName,
						Raff.AffiliationStartDate AffiliationStartDate_Old, --Added for #22 KEN-12838
						Null as AffiliationStartDate_New, --Added for #22 KEN-12838										
						Isnull(Raff.AffiliationEndDate,'2069-12-31') AffiliationEndDate_Old, --Added for #22 KEN-12838 --Added Default Date for #30 CAPAVE-2467
						Null as AffiliationEndtDate_New, --Added for #22 KEN-12838						
						--ROW_NUMBER() over(order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
						Raff.LastActionDate
				from KYPEnrollment.pAccount_RenderingAffiliation RAff
				LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
				LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
				where RAff.AffiliatedAccountID is not null 
					and RAff.AccountID=@acc_party_id 
					and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
					and ((CONVERT(date,RAff.LastActionDate))<@UserDate 
							OR Raff.LastActorUserID='System') --#5 CAPAVE-1284,1285 
					and RAff.isDeleted=0 --KEN-7639
					and AR.isDeleted=0 --CAPAVE-2816
					and A.isDeleted=0 --CAPAVE-2816					
					and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955
						
			)T
		order by ---R -- added for order based on last action date(PI-601)
		T.LastActionDate Desc
		/* All new value end */

		--Commented for #22 KEN-12838 as Old and New fields are handled in one single Insert statment instead of handled separately.	
		--INSERT INTO [KYPEnrollment].[GroupRenderingforAccount]
		--		   ([GRPIDTY]
		--		   ,[AccountID]
		--		   ,[ReqType_New]
		--		   ,[Provider_New]
		--		   ,[OWNERNO_New]
		--		   ,[SLocNo_New]
		--		   ,[ProvType_New]
		--		   ,[userName])
		       
		--select [GRPIDTY],AccountID,RequestType,Provider,OWNERNO,SLocNo,ProvType,UserName -- added for order based on last action date(PI-601)
		--from 
		--(
		--select DISTINCT 'A' As GRPIDTY,
		--RAff.AccountID,
		--Case 
		--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' --Rearranged the When clause for #19 PI-804		 	
		----When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
		--When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
		----When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D' 
		----When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
		--else
		-- 'E' END AS RequestType
		---- Field of pAccount_PDM_Number (For Rendring)
		--,AR.NPI AS Provider,
		--AR.OwnerNo AS OWNERNO,
		--Ar.ServiceLocationNo AS SLocNo,
		--AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType 
		--,@Username As UserName
		--,ROW_NUMBER() over(partition by A.AccountID order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
		--from KYPEnrollment.pAccount_RenderingAffiliation RAff
		---- This is for Billing 
		--LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
		---- This is for  Rendering
		--LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
		--where  RAff.AffiliatedAccountID is not null and RAff.AccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
		--and(CONVERT(date,RAff.LastActionDate))>=@UserDate 
		--and RAff.isDeleted=0 --KEN-7639
		--and RAFF.LastActorUserID <> 'System' --#5 CAPAVE-1284, 1285
		--and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955	
		--)T
		--order by R -- added for order based on last action date(PI-601)

		/* All new value end */

		/* All Old values block start*/
		--INSERT INTO [KYPEnrollment].[GroupRenderingforAccount]
		--		   ([GRPIDTY]
		--		   ,[AccountID]
		--		   ,[ReqType_Old]
		--		   ,[Provider_Old]
		--		   ,[OWNERNO_Old]
		--		   ,[SLocNo_Old]
		--		   ,[ProvType_Old]
		--		   ,[userName])	 
		--select [GRPIDTY],AccountID,RequestType,Provider,OWNERNO,SLocNo,ProvType,UserName -- added for order based on last action date(PI-601)
		--from 
		--(
		--select DISTINCT 'A' As GRPIDTY,
		--RAff.AccountID,
		--Case 
		--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' --Rearranged the When clause for #19 PI-804		 	
		----When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
		--When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
		----When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D'  
		----When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
		--else
		-- 'E' END AS RequestType
		---- Field of pAccount_PDM_Number (For Rendring)
		--,AR.NPI AS Provider,
		--AR.OwnerNo AS OWNERNO,
		--Ar.ServiceLocationNo AS SLocNo,
		--AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType 
		--,@Username As UserName
		--,ROW_NUMBER() over(partition by A.AccountID order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
		--from KYPEnrollment.pAccount_RenderingAffiliation RAff
		---- This is for Billing 
		--LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
		---- This is for  Rendering
		--LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
		--where  RAff.AffiliatedAccountID is not null and RAff.AccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
		--and ((CONVERT(date,RAff.LastActionDate))<@UserDate 
		--		OR Raff.LastActorUserID='System') --#5 CAPAVE-1284,1285 
		--and RAff.isDeleted=0 --KEN-7639
		--and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955		
		--)T
		--order by R -- added for order based on last action date(PI-601)

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into KYPENROLLMENT.GroupRendForAccount(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End;
	End;
	
	/* All new value bolck start*/

	/*PI-628 and CAPAVE-487*/
	/* For colour changes*/
	---------------------------------Billing Rendering---------------------------------------------------------------
	--Changed the TableName and FieldNames to rectify the mapping issue in the template #22 Ken-12838
	If Not Exists(Select ID
					From kypenrollment.GroupAssForAccount
					Where AccountID = @acc_party_id)
	Begin		
		Insert into Kypenrollment.GroupAssForAccount(
				Se, --Sequence
				GRPIDTY, 
				AccountID, 
				AO, --ReqType_Old
				AN, --ReqType_New
				ProO, --Provider_Old
				ProN, --Provider_New
				OO, --OwnerNo_Old
				NO, --OwnerNo_New
				SO, --ServiceLocation_Old
				SN, --ServiceLocation_New
				ProvTypeOld, --ProviderType_Old
				ProvTypeNew, --ProviderType_New
				userName, 
				SDO, --AffiliationStartDate_Old
				SDN, --AffiliationStartDate_New
				EDO, --AffiliationEndDate_Old     
				EDN --AffiliationEndDate_New
		)
		select Row_Number() over(Order by T.LastActionDate desc) Seq, --Added for #22 KEN-12838
				[GRPIDTY],
				AccountID,
				RequestType_Old,			
				RequestType_New,
				Provider_Old,			
				Provider_New,
				OwnerNo_Old,
				OWNERNO_New,
				SLocNo_Old,
				SLocNo_New,
				ProvType_Old,
				ProvType_New,
				UserName, -- added for order based on last action date(PI-601)			
				Convert(varchar(10),AffiliationStartDate_Old,101), --Added for #22 KEN-12838
				Convert(varchar(10),AffiliationStartDate_New,101), --Added for #22 KEN-12838			
				Convert(varchar(10),AffiliationEndDate_Old,101), --Added for #22 KEN-12838	
				Convert(varchar(10),AffiliationEndDate_New,101) --Added for #22 KEN-12838						
		from (select DISTINCT 'A' As GRPIDTY,
					A.AccountID,
					Null as RequestType_Old,
					Case 
					When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') and (RAff.AffiliationEndDate<=GETDATE()) then 'D' --Rearranged the When clause for #19 PI-804		 	
					--When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
					When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
					--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
					--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
					else
					 'E' END AS RequestType_New,
					Null as Provider_Old,
					AR.NPI AS Provider_New,
					Null as OwnerNo_Old,
					AR.OwnerNo AS OWNERNO_New,
					Null as SLocNo_Old,
					Ar.ServiceLocationNo AS SLocNo_New,
					Null as ProvType_Old,
					Left(AR.ProviderTypeCode,3) + '- '+AR.ProviderType AS ProvType_New,--Added first 3 characters of ProviderTypeCode for KEN-13850 by Sundar on 31Mar2018
					Null as AffiliationStartDate_Old, --Added for #22 KEN-12838					
					Raff.AffiliationStartDate AffiliationStartDate_New, --Added for #22 KEN-12838
					Null as AffiliationEndDate_Old, --Added for #22 KEN-12838				
					Isnull(Raff.AffiliationEndDate,'2069-12-31') AffiliationEndDate_New, --Added for #22 KEN-12838	--Added Default Date for #30 CAPAVE-2467			
					@Username As UserName,
					---ROW_NUMBER() over(order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
					RAff.LastActionDate
				from KYPEnrollment.pAccount_RenderingAffiliation RAff
				LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID
				LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
				where RAff.AccountID is not null 
					and RAff.AffiliatedAccountID=@acc_party_id 
					and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
					and(CONVERT(date,RAff.LastActionDate))>=@UserDate 
					and RAff.isDeleted=0 --KEN-7639
					and AR.isDeleted=0 --CAPAVE-2816
					and A.isDeleted=0 --CAPAVE-2816					
					and RAFF.LastActorUserID <> 'System' --#5 CAPAVE-1284, 1285	
					and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955
				Union all
				select DISTINCT 'A' As GRPIDTY,
						A.AccountID,
						Case When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') and (RAff.AffiliationEndDate<=GETDATE()) then 'D' --Rearranged the When clause for #19 PI-804		 	 
						--When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
						When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
						--When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D' 
						--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
						else
						 'E' END AS RequestType_Old,
						Null  AS RequestType_New,
						AR.NPI AS Provider_Old,
						Null as Provider_New,
						AR.OwnerNo AS OWNERNO_old,
						Null as OwnerNo_New,
						Ar.ServiceLocationNo AS SLocNo_old,
						Null as SLocNo_New,
						Left(AR.ProviderTypeCode,3) + '- '+AR.ProviderType AS ProvType_Old, --Added first 3 characters of ProviderTypeCode for KEN-13850 by Sundar on 31Mar2018
						Null as ProvType_New,
						Raff.AffiliationStartDate AffiliationStartDate_Old, --Added for #22 KEN-12838
						Null as AffiliationStartDate_New, --Added for #22 KEN-12838						
						Isnull(Raff.AffiliationEndDate,'2069-12-31') AffiliationEndDate_Old, --Added for #22 KEN-12838	--Added Default Date for #30 CAPAVE-2467
						Null as AffiliationEndtDate_New, --Added for #22 KEN-12838						
						@Username As UserName,
						--ROW_NUMBER() over(order by raff.LastActionDate desc) R-- added for order based on last action date(PI-601 billing point 6)
						RAff.LastActionDate
				from KYPEnrollment.pAccount_RenderingAffiliation RAff
				LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID
				LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
				where  RAff.AccountID is not null 
					and RAff.AffiliatedAccountID=@acc_party_id 
					and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
					and ((CONVERT(date,RAff.LastActionDate))<@UserDate
							OR Raff.LastActorUserID='System') --#5 CAPAVE-1284,1285 
					and RAff.isDeleted=0 --KEN-7639
					and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955
					and AR.isDeleted=0 --CAPAVE-2816
					and A.isDeleted=0 --CAPAVE-2816						
		)T
		order by --R -- added for order based on last action date(PI-601)
			T.LastActionDate Desc

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into KYPEnrollment.GroupAssForAccount(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End;
	End;
	
	/* All new value bolck start*/

	--Commented for #22 KEN-12838 as Old and New fields are handled in one single Insert statment instead of handled separately.	
	--INSERT INTO [KYPEnrollment].[GroupAssociationforAccount]
	--		   ([GRPIDTY]
	--		   ,[AccountID]
	--		   ,[ReqType_New]
	--		   ,[Provider_New]
	--		   ,[OWNERNO_New]
	--		   ,[SLocNo_New]
	--		   ,[ProvType_New]
	--		   ,[userName])
	--select [GRPIDTY],AccountID,RequestType,Provider,OWNERNO,SLocNo,ProvType,UserName -- added for order based on last action date(PI-601)
	--from 
	--(
	--select DISTINCT 'A' As GRPIDTY,
	--A.AccountID,
	--Case 
	--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' --Rearranged the When clause for #19 PI-804		 	
	----When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
	--When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
	----When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
	----When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
	--else
	-- 'E' END AS RequestType
	---- Field of pAccount_PDM_Number (For Rendring)
	--,AR.NPI AS Provider,
	--AR.OwnerNo AS OWNERNO,
	--Ar.ServiceLocationNo AS SLocNo,
	--AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType ,
	--@Username As UserName
	--,ROW_NUMBER() over(partition by RAff.AffiliatedAccountID order by raff.LastActionDate desc) R -- added for order based on last action date(PI-601 billing point 6)
	--from KYPEnrollment.pAccount_RenderingAffiliation RAff
	---- This is for Billing 
	--LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID
	---- This is for  Rendering
	--LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
	--where  RAff.AccountID is not null and RAff.AffiliatedAccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
	--and(CONVERT(date,RAff.LastActionDate))>=@UserDate 
	--and RAff.isDeleted=0 --KEN-7639
	--and RAFF.LastActorUserID <> 'System' --#5 CAPAVE-1284, 1285	
	--and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955	
	--)T
	--order by R -- added for order based on last action date(PI-601)

	--/* All new value bolck start*/

	--/* All Old values block start*/
	--INSERT INTO [KYPEnrollment].[GroupAssociationforAccount]
	--		   ([GRPIDTY]
	--		   ,[AccountID]
	--		   ,[ReqType_Old]
	--		   ,[Provider_Old]
	--		   ,[OWNERNO_Old]
	--		   ,[SLocNo_Old]
	--		   ,[ProvType_Old]
	--		   ,[userName])
	--select [GRPIDTY],AccountID,RequestType,Provider,OWNERNO,SLocNo,ProvType,UserName -- added for order based on last action date(PI-601)
	--from 
	--(
	--select DISTINCT 'A' As GRPIDTY,
	--A.AccountID,
	--Case
	--When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' --Rearranged the When clause for #19 PI-804		 	 
	----When(CONVERT(date, RAff.AffiliationStartDate) between   @UserDate and getdate()) then 'A'  --Commented for #11
	--When(CONVERT(date, RAff.LastActionDate) between @UserDate and getdate()) then 'A' --Added for #11	
	----When (CONVERT(date, RAff.AffiliationEndDate , 101) between @UserDate and getdate())  then 'D' 
	----When CONVERT(date, RAff.AffiliationEndDate , 101) IS NOT null  and (RAff.AffiliationEndDate!='2069-12-31') then 'D' 
	--else
	-- 'E' END AS RequestType
	---- Field of pAccount_PDM_Number (For Rendring)
	--,AR.NPI AS Provider,
	--AR.OwnerNo AS OWNERNO,
	--Ar.ServiceLocationNo AS SLocNo,
	--AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType ,
	--@Username As UserName
	--,ROW_NUMBER() over(partition by RAff.AffiliatedAccountID order by raff.LastActionDate desc) R-- added for order based on last action date(PI-601 billing point 6)
	--from KYPEnrollment.pAccount_RenderingAffiliation RAff
	---- This is for Billing 
	--LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID
	---- This is for  Rendering
	--LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
	--where  RAff.AccountID is not null and RAff.AffiliatedAccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
	--and ((CONVERT(date,RAff.LastActionDate))<@UserDate
	--		OR Raff.LastActorUserID='System') --#5 CAPAVE-1284,1285 
	--and RAff.isDeleted=0 --KEN-7639
	--and AR.NPI not like '%[a-z]%' --Added for #21 CAPAVE-1955	
	--)T
	--order by R
/*PI-628 and CAPAVE-487*/

---------------------------NMP---------------------------------------------------------
----------Colour chages block started-------------------------------------------------- 


	If Not Exists(Select ID
					From kypenrollment.[NMPRenderingForAccount]
					Where AccountID = @acc_party_id)
	Begin	
		;With N as 
		(Select t2.AccountID,T2.DateModified,T2.FieldName,T2.ToValue
			From (Select AccountID,FieldName,MAX(ID) ID		
					From KYPEnrollment.INPUTDOC_RenderingHistory
					Where DateSearch>=@Date
					and AccountID=@acc_party_id
					Group by AccountID,FieldName) T1
			Join KYPEnrollment.INPUTDOC_RenderingHistory T2 on T1.ID = T2.ID),
		NV as (Select *
				From N Pivot (MAX([ToValue]) for FieldName in (LegalName,SSN,ProvC,ProvCDate,StatusAcc,StsEffBnDT,StsEffEdDT,REENR,[REENR_DT],[srADD1],[srADD2],[srcity],[srstate],[srZip4])) P),	
		OV as (Select AR.NPI,
						A.AccountID,
						A.PartyID,
						AR.LegalName,
						AR.SSN,
						D.ProvisionalCode ProvC,
						D.ProvisionalCodeDate ProvCDate,
						AR.StatusAcc,
						isnull(acs.EffectiveBeginDate,AR.StatusBeginDate) as StsEffBnDT,--#2
						isnull(acs.EffectiveEndDate,'12/31/2069') as StsEffEdDT,--#2
						--acs.EffectiveBeginDate StsEffBnDT,--#2
						--acs.EffectiveEndDate StsEffEdDT,--#2
						
						-- CAPAVE-2552 - Re-Enrollment Date Appears on Input Doc for NMP - changed the table referecne from 
						-- currently Billing type Input Documents (under NMP Section) refers to PADM_ACCOUNT and it should be changed to EDM_ACCOUNT_INTERNAL_USE
						
						--START
						D.ReEnrolInd REENR,
						D.ReEnrolDate [REENR_DT],
						--END
						
							e.AddressLine1 [srADD1],
						e.AddressLine2 [srADD2],
						e.City [srcity],
						e.Abreviation [srstate],
						e.ZipPlus4 [srZip4],
						LIC.LastActionDate,
						LIC.Number,
						Case when (CONVERT(date,Lic.LastActionDate)>=@UserDate and Lic.LastActorUserID <> 'System') Then Lic.Number End as NMPRendLic_New, --#5 CAPAVE-1284				
						LEFT(AR.ProviderTypeCode,1) ProviderTypeCode,
						CONVERT(varchar(10),RAFF.AffiliationStartDate,101) AffiliationStartDate,
						--isnull(CONVERT(varchar(10),RAff.AffiliationEndDate,101),'12/31/2069') AffiliationEndDate, --#4				
						isnull(Case when 
									--(CONVERT(date,raff.AffiliationStartDate)<@UserDate) --Commented for #15 CAPAVE-1247
									CONVERT(date,raff.LastActionDate)<@UserDate --Added for #15 CAPAVE-1247 
									then CONVERT(varchar(10),RAff.AffiliationEndDate,101)
								When raff.LastActionDate is not null
									and raff.LastActorUserID = 'System'
									Then CONVERT(varchar(10),RAff.AffiliationEndDate,101) --#45 Added this When clause for CAPAVE-4277
									end,'12/31/2069') AffiliationEndDate, --#4  --#8 Added Isnull condition				
						RAff.AffiliationStartDate as AffiliationStartsort,
						case when(RAff.AffiliationEndDate!='2069-12-31')then RAff.AffiliationEndDate end  AS Affiliationsort,
						Case when (
									--CONVERT(date,raff.AffiliationStartDate)>=@UserDate --Commented for #15 CAPAVE-1247
									CONVERT(date,raff.LastActionDate)>=@UserDate --Added for #15 CAPAVE-1247
											and raff.LastActorUserID<>'System' --#5 CAPAVE-1284
											) then CONVERT(varchar(10),RAFF.AffiliationStartDate,101) end as AffiliationStartDate_New,
						--Case when (CONVERT(date,raff.AffiliationEndDate)>=@UserDate  and (raff.AffiliationEndDate!='12/31/2069')) then CONVERT(varchar(10),RAFF.AffiliationEndDate,101) end as AffiliationEndDate_New
						Case when (
									--CONVERT(date,raff.AffiliationEndDate)>=@UserDate --Commented for #15 CAPAVE-1247 
									--and CONVERT(date,raff.AffiliationStartDate)>=@UserDate --Commented for #15 CAPAVE-1247
									raff.AffiliationEndDate IS not null --Added for #15 CAPAVE-1247
									and CONVERT(date,raff.LastActionDate)>=@UserDate --Added for #15 CAPAVE-1247								
									and raff.LastActorUserID<>'System' --#5 CAPAVE-1284
									) then CONVERT(varchar(10),RAFF.AffiliationEndDate,101)
							  When (raff.AffiliationEndDate IS null 
									--and CONVERT(date,raff.AffiliationStartDate)>=@UserDate --Commented for #15 CAPAVE-1247
									and CONVERT(date,raff.LastActionDate)>=@UserDate --Added for #15 CAPAVE-1247
									and raff.LastActorUserID<>'System' --#5 CAPAVE-1284
									) Then '12/31/2069'
							  Else NULL end as AffiliationEndDate_New, --#4   	
						/*Start #22 KEN-12838*/			
						f.AddressLine1 [MADD1],
						f.AddressLine2 [MADD2],
						f.City [Mcity],
						f.Abreviation [Mstate],
						f.ZipPlus4 [MZip4]
						/*End #22 KEN-12838*/						  							
			from KYPEnrollment.pAccount_RenderingAffiliation RAff
			LEFT JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID 
			LEFT JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
			left join KYPEnrollment.EDM_AccountInternalUse D on  D.AccountID=RAff.AffiliatedAccountID 
																and (D.IsApproved = 1 OR D.IsApproved is null)--#36 KEN-15462
			left join (select PartyID,MAX(NumberID) NumberID
						From KYPEnrollment.pAccount_PDM_Number
						where Type='Professional License'
							AND CurrentRecordFlag=1
						Group by PartyID) LIC1 on LIC1.PartyID=AR.PartyID 
			LEFT JOIN KYPEnrollment.pAccount_PDM_Number LIC on LIC.NumberID=LIC1.NumberID			
			left join (select AccountID,MAX(AccountStatusID) AccountStatusID
						from KYPEnrollment.pADM_AccountStatus
						Where CurrentRecordFlag=1 AND StatusType='Enrollment'
						group by AccountID) ACS1 ON Acs1.AccountID=AR.AccountID
			left join KYPEnrollment.pADM_AccountStatus ACS on Acs.AccountStatusID=ACS1.AccountStatusID 
			left join (select SR.AddressLine1,SR.AddressLine2,SR.City ,LS.Abreviation,SR.ZipPlus4 ,SR.County,x.PartyID  
				from KYPEnrollment.pAccount_PDM_Address SR
				inner join KYPEnrollment.pAccount_PDM_Location X
				on SR.AddressID = X.AddressID 
				--and X.Type='Individual Profile' --Commented for #22 KEN-12838
				and X.Type='Servicing' --Added for #22 KEN-12838
				and X.CurrentRecordFlag=1
				Left join kyp.LK_Screening LS on SR.State=LS.Description
				) E on E.PartyID = AR.PartyID
			--Added the below select stat. for #22 KEN-12838
			left join (select SR.AddressLine1,SR.AddressLine2,SR.City ,LS.Abreviation,SR.ZipPlus4 ,SR.County,x.PartyID  
				from KYPEnrollment.pAccount_PDM_Address SR
				inner join KYPEnrollment.pAccount_PDM_Location X
				on SR.AddressID = X.AddressID 
				and X.Type='Mailing'
				and X.CurrentRecordFlag=1
				Left join kyp.LK_Screening LS on SR.State=LS.Description
				) F on F.PartyID = AR.PartyID				
			where RAff.AffiliatedAccountID is not null 
			and RAff.TypeAffiliation in ('NMP','NEW_RENDERING_MIDLEVEL_FROM_ACCOUNT','NEW_RENDERING_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_ACCOUNT') 
			and RAff.isDeleted=0 --KEN-7639
			and AR.isDeleted=0 --CAPAVE-2763
			and A.isDeleted=0 --CAPAVE-2763			
			)
		INSERT INTO [KYPEnrollment].[NMPRenderingForAccount]
					(	Seq, --Added for #22 KEN-12838
						[NMPRendNPI_New], --#4				
						[NMPRendNPI] ,
						[NMPRendLic_New],
						[NMPRendLic_Old],
						[ProvTC_New], --#4					
						[ProvTC],
						[RenAffStDT_New],
						[RenAffStDT_Old],
						[RenAffEndDT_New],
						[RenAffEndDT_Old],
						[AccountID],
						[LegalName_Old],
						[LegalName_New],				
						[SSN_Old],
						[SSN_New],				
						[ProvC_Old],
						[ProvC_New],
						[ProvCDate_Old],				
						[ProvCDate_New],
						[StatusAcc_Old],
						[StatusAcc_New],
						[StsEffBnDT_Old],
						[StsEffBnDT_New],
						[StsEffEdDT_Old],
						[StsEffEdDT_New],
						[REENR_Old],
						[REENR_New],
						[REENR_DT_O],
						[REENR_DT_N],
						[srADD1_Old],
						[srADD1_New],
						[srADD2_Old],
						[srADD2_New],
						[srcity_Old],
						[srcity_New],
						[srstate_Old],
						[srstate_New],
						[srZip4_Old],
						[srZip4_New],
						[LastActionDate],
						[AffiliationStartsort],
						[Affiliationsort],
						[userName],
						/*Start #22 KEN-12838*/	
						MADD1_Old,
						MADD2_Old,
						Mcity_Old,
						MState_Old,
						MZipPlus4_Old
						/*End #22 KEN-12838*/					
					)		
		Select 
			ROW_NUMBER() Over(order by convert(date,OV.LastActionDate) Desc,OV.Affiliationsort desc,OV.AffiliationStartsort desc) Seq, --Added for #22 KEN-12838 --Added Convert(date) condition for #33 CAPAVE-2541
			--OV.NPI NMPRendNPI, --#4
			/*#4 Start*/
			Case --When (CONVERT(date,OV.LastActionDate)>=@UserDate) Then OV.NPI --#5
					When (OV.NMPRendLic_New is NOT null) Then OV.NPI --#5
						When OV.AffiliationStartDate_New IS NOT null then OV.NPI
						When OV.AffiliationEndDate_New IS NOT null then OV.NPI	
						Else NULL		
						End as NMPRendNPI_New
			,Case When (--(CONVERT(date,OV.LastActionDate)<@UserDate) --#5
							(OV.NMPRendLic_New is null) --#5
						and OV.AffiliationStartDate_New is null 
						and OV.AffiliationEndDate_New is null) Then OV.NPI
					Else NULL 
					End AS NMPRendNPI 
			/*#4 End*/
			--,Case when (CONVERT(date,OV.LastActionDate)>=@UserDate) Then Number End as NMPRendLic_New --#5
			--,Case when (CONVERT(date,OV.LastActionDate)<@UserDate) Then OV.Number End --#1 --#5
			,OV.NMPRendLic_New as NMPRendLic_New--#5 CAPAVE-1284	
			,Case when (OV.NMPRendLic_New is null) Then OV.Number End --#5 CAPAVE-1284
			--,OV.ProviderTypeCode as ProvTC --#4
			/*#4 Start*/
			,Case When --(CONVERT(date,OV.LastActionDate)>=@UserDate) Then OV.ProviderTypeCode --#5
						(OV.NMPRendLic_New is not null) Then OV.ProviderTypeCode --#5
						When OV.AffiliationStartDate_New IS NOT null then OV.ProviderTypeCode
						When OV.AffiliationEndDate_New IS NOT null then OV.ProviderTypeCode	
						Else NULL		
						End as ProvTC_New
			,Case When (--(CONVERT(date,OV.LastActionDate)<@UserDate) --#5
						OV.NMPRendLic_New is null --#5
						and OV.AffiliationStartDate_New is null 
						and OV.AffiliationEndDate_New is null) Then OV.ProviderTypeCode
					Else NULL 
					End as ProvTC 
			/*#4 End*/	
			--,Case when (CONVERT(date,OV.AffiliationStartDate)>=@UserDate) then OV.AffiliationStartDate end AS AffiliationStartDate_New
			,OV.AffiliationStartDate_New
			,case when OV.AffiliationStartDate_New IS null then OV.AffiliationStartDate End AS AffiliationStartDate
			--,Case when (CONVERT(date,OV.AffiliationEndDate)>=@UserDate and (OV.AffiliationEndDate!='12/31/2069')) then OV.AffiliationEndDate end AS AffiliationEndDate_New
			,OV.AffiliationEndDate_New
			,case when OV.AffiliationEndDate_New IS null then OV.AffiliationEndDate End AS AffiliationEndDate
			--,OV.AffiliationEndDate AS AffiliationEndDate
			,OV.AccountID as AccountID
			,Case when NV.LegalName is null then OV.LegalName END LegalName_Old
			,NV.LegalName LegalName_New
			,Case when NV.SSN is null then OV.SSN END SSN_Old
			,NV.SSN SSN_New
			,Case when NV.ProvC is null then OV.ProvC END ProvC_Old
			,NV.ProvC ProvC_New
			,Case when NV.ProvCDate is null then convert(varchar(10),OV.ProvCDate,101) END ProvCDate_Old
			,convert(varchar(10),NV.ProvCDate,101) ProvCDate_New
			,Case when NV.StatusAcc is null then OV.StatusAcc END StatusAcc_Old
			,Case when NV.AccountID is not null then OV.StatusAcc END StatusAcc_New -- Added Case Statment for KEN-19169 on 4-Dec-2018 by Sundar
			,Case when NV.StsEffBnDT is null then convert(varchar(10),OV.StsEffBnDT,101) END StsEffBnDT_Old
			,convert(varchar(10),NV.StsEffBnDT,101) StsEffBnDT_New
			,Case when NV.StsEffEdDT is null then convert(varchar(10),OV.StsEffEdDT,101) END StsEffEdDT_Old
			,convert(varchar(10),NV.StsEffEdDT,101) StsEffEdDT_New
			,Case when NV.REENR is null then OV.REENR END REENR_Old
			,NV.REENR REENR_New
			,Case when NV.REENR_DT is null then convert(varchar(10),OV.REENR_DT,101) END REENR_DT_Old
			,convert(varchar(10),NV.REENR_DT,101) REENR_DT_New
			,Case when NV.srADD1 is null then OV.srADD1 END srADD1_Old
			,NV.srADD1 srADD1_New
			,Case when NV.srADD2 is null then OV.srADD2 END srADD2_Old
			,NV.srADD2 srADD2_New
			,Case when NV.srcity is null then OV.srcity END srcity_Old
			,NV.srcity srcity_New
			,Case when NV.srstate is null then OV.srstate END srstate_Old
			,NV.srstate srstate_New
			,Case when NV.srZip4 is null then OV.srZip4 END srZip4_Old
			,NV.srZip4 srZip4_New
			,OV.LastActionDate
			,OV.Affiliationsort
			,OV.AffiliationStartsort
			,@userName
			/*Start #22 KEN-12838*/	
			,OV.MADD1
			,OV.MADD2
			,OV.Mcity
			,OV.Mstate
			,OV.MZip4
			/*End #22 KEN-12838*/		
		from OV
		Left Join NV on OV.AccountID = NV.AccountID
		where ov.AccountID = @acc_party_id
		order by convert(date,OV.LastActionDate) desc,  OV.Affiliationsort desc,OV.AffiliationStartsort desc

		--Added the IF stat. for #27	
		IF @@RowCount = 0
		Begin
			Insert into KYPEnrollment.NMPRenderingForAccount(AccountId,UserName)
			Values (@acc_party_id,@Username);
		End;
	End

---------------------------MOca---------------------------------------------------------
----------Colour chages block started-------------------------------------------------- 

	--Commented for #42 Switching off MOCA
	/*
	If Not Exists(Select ID
					From kypenrollment.[MocaDetailforAccount]
					Where AccountID = @acc_party_id)
	Begin	
		;With N as 
		(Select t2.AccountID,T2.PartyID,T2.DateModified
				--,T2.FieldName --Commented for #20 CAPAVE-1742
				,T1.FieldName --Added for #20 CAPAVE-1742
				,T2.ToValue
			From (Select AccountID,PartyID
						,replace(replace(FieldName,'FirstName','LegalName'),'LastName','LegalName') FieldName --#9 PI-754
						,MAX(ID) ID		
					From KYPEnrollment.INPUTDOC_MOCAHistory
					Where DateSearch>=@Date
					and AccountID=@acc_party_id
					Group by AccountID,PartyID,FieldName) T1
			Join KYPEnrollment.INPUTDOC_MOCAHistory T2 on T1.ID = T2.ID),
		NV as (Select *
				From N Pivot (MAX([ToValue]) for FieldName in (NPI,SSN,TIN,MOCASrtDT,MOCAEdDT,LEGALNAME,DOB,/*MOCADelDT,*/[Type])) P),	--#7, #9 PI-754
		--OV as (Select A.AccountID,PRT.PartyID,--A.PartyID, //PI-754
		--			/*A.NPI,*/Case When isnull(PVDR.NPI,P.NPI) = 0 Then Null Else isnull(PVDR.NPI,P.NPI) End NPI,--#3 --Added Isnull condition for #24 PI-837 --#32 CAPAVE-2540
		--			P.SSN,NULL as TIN,
		--			--PRT.MOCARelationshipStartDate MOCASrtDT, --#3
		--			--PRT.MOCARelationshipEndDate MOCAEdDT, --#3
		--			/* #3 Start*/
		--			--Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipStartDate
		--			--	--Commented for #13 CAPAVE-1246, CAPAVE-1275						
		--			--	--Else (case 
		--			--	--		when owr.PercentCheck=1 then owr.PercentDate
		--			--	--		when owr.[Partner]=1 then owr.PartnerDate
		--			--	--		when owr.Managing=1 then owr.ManagingDate 
		--			--	--		when owr.Other=1 then owr.OtherDate
		--			--	--		end)
		--			--	Else Owr.OtherDate	--Added for #13 CAPAVE-1246, CAPAVE-1275					
		--			--	End as MOCASrtDT,
		--			PRT.MOCARelationshipStartDate as MOCASrtDT, -- Changed by Sundar for CAPAVE-2270 on 30 March 2018
		--			isnull(Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipEndDate
		--				--Else convert(smalldatetime,'2069-12-31')
		--				End,convert(smalldatetime,'2069-12-31')) MOCAEdDT, --Added Isnull condition for PI-754
		--			/*#3 End*/	
		--			isnull(P.LastName+', ','') + isnull(P.FirstName + ' ','')+ isnull(P.MiddleName,'') as LegalName, --Added Isnull condition for MiddleName by Sundar on 3Mar2017 #7 --Added Isnull condition for Firstname and LastName #34 CAPAVE-2570
		--			P.DoB,PRT.DateDeleted MOCADelDT,PRT.Type
		--			,P.LastActionDate --Added on 19Jul2017 by Sundar for CAPAVE-1742				
		--		from KYPEnrollment.pAccount_PDM_Party PRT
		--		left Join KYPEnrollment.pADM_Account A ON A.AccountID=PRT.AccountID
		--		--Join [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID
		--		left join KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
		--		Left Join [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID--#3
		--		Left Join KYPEnrollment.pAccount_PDM_Owner_Role owr on PRT.PartyID=owr.PartyID --#3		
		--		Where PRT.Type='Individual Ownership'
		--		and A.IsDeleted=0
		--		and PRT.IsDeleted=0
		--		Union all
		--		Select A.AccountID,PRT.PartyID,--A.PartyID,//PI-754
		--			/*A.NPI,*/Case When (ISNULL(PVDR.NPI,O.NPI) = 0) Then Null Else ISNULL(PVDR.NPI,O.NPI) End NPI, --#3 --Added Isnull condition for #24 PI-837 --#32 CAPAVE-2540
		--			NULL
		--			--,O.TIN--Commented for #12 CAPAVE-1573
		--			,O.EIN as TIN, --Added for #12 CAPAVE-1573
		--			--PRT.MOCARelationshipStartDate,--#3
		--			--PRT.MOCARelationshipEndDate,--#3
		--			/* #3 Start*/
		--			--,Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipStartDate
		--			--	--Commented for #13 CAPAVE-1246, CAPAVE-1275						
		--			--	--Else (case 
		--			--	--		when owr.PercentCheck=1 then owr.PercentDate
		--			--	--		when owr.[Partner]=1 then owr.PartnerDate
		--			--	--		when owr.Managing=1 then owr.ManagingDate 
		--			--	--		when owr.Other=1 then owr.OtherDate 
		--			--	--		end)
		--			--	Else Owr.OtherDate	--Added for #13 CAPAVE-1246, CAPAVE-1275					
		--			--	End as MOCASrtDT,
		--			PRT.MOCARelationshipStartDate as MOCASrtDT, -- Changed by Sundar for CAPAVE-2270 on 30 March 2018					
		--			isnull(Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipEndDate
		--				--Else convert(smalldatetime,'2069-12-31')
		--				End,convert(smalldatetime,'2069-12-31')) MOCAEdDT, --Added Isnull condition for PI-754
		--			/*#3 End*/		
		--			O.LEGALNAME, NULL,PRT.DateDeleted,PRT.Type
		--			,O.LastActionDate --Added on 19Jul2017 by Sundar for CAPAVE-1742				
		--		from KYPEnrollment.pAccount_PDM_Party PRT
		--		Join KYPEnrollment.pADM_Account A ON A.AccountID=PRT.AccountID
		--		--Join [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID
		--		left Join KYPEnrollment.pAccount_PDM_Organization O on O.PartyID=PRT.PartyID
		--		Left Join [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID--#3
		--		Left Join KYPEnrollment.pAccount_PDM_Owner_Role owr on PRT.PartyID=owr.PartyID --#3		
		--		Where PRT.Type='Entity Ownership'
		--		and A.IsDeleted=0
		--		and PRT.IsDeleted=0)
		--#35 KEN-14820 Changed the Select query for MOCA Linking Changes
		OV as (Select A.AccountID,PRT.PartyID,--A.PartyID, //PI-754
			/*A.NPI,*/Case When isnull(Convert(varchar(15),PVDR.NPI),P.NPI) = '0' Then Null Else isnull(Convert(varchar(15),PVDR.NPI),P.NPI) End NPI,--#3 --Added Isnull condition for #24 PI-837 --#32 CAPAVE-2540
			P.SSN,NULL as TIN,
			--PRT.MOCARelationshipStartDate MOCASrtDT, --#3
			--PRT.MOCARelationshipEndDate MOCAEdDT, --#3
			/* #3 Start*/
			--Commented for #37 CAPAVE-2270
			--Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipStartDate
			--	--Commented for #13 CAPAVE-1246, CAPAVE-1275						
			--	--Else (case 
			--	--		when owr.PercentCheck=1 then owr.PercentDate
			--	--		when owr.[Partner]=1 then owr.PartnerDate
			--	--		when owr.Managing=1 then owr.ManagingDate 
			--	--		when owr.Other=1 then owr.OtherDate
			--	--		end)
			--	Else Owr.OtherDate	--Added for #13 CAPAVE-1246, CAPAVE-1275					
			--	End as MOCASrtDT,
			PRT.MOCARelationshipStartDate as MOCASrtDT, --Changed for #37 CAPAVE-2270
			isnull(Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipEndDate
				--Else convert(smalldatetime,'2069-12-31')
				End,convert(smalldatetime,'2069-12-31')) MOCAEdDT, --Added Isnull condition for PI-754
			/*#3 End*/	
			isnull(P.LastName+', ','') + isnull(P.FirstName + ' ','')+ isnull(P.MiddleName,'') as LegalName, --Added Isnull condition for MiddleName by Sundar on 3Mar2017 #7 --Added Isnull condition for Firstname and LastName #34 CAPAVE-2570
			P.DoB,PRT.DateDeleted MOCADelDT,PRT.Type
			,P.LastActionDate --Added on 19Jul2017 by Sundar for CAPAVE-1742				
		from kypenrollment.pADM_Account A
		Join KYPEnrollment.pAccount_BizProfile_Details BP on A.AccountID = BP.AccountID and A.IsDeleted = 0
		Join KYPEnrollment.TaxIDProfile TxP on BP.ProfileID = TxP.profileID and A.EIN = TxP.taxID
		Join kypenrollment.pAccount_PDM_Party PRT On PRT.TaxIDProfileID = TxP.TaxIDProfileID and PRT.IsDeleted=0
		Join kypenrollment.pAccount_PDM_Person P on PRT.PartyID = P.PartyID and P.Deleted=0
		Left Join Kypenrollment.pAccount_PDM_Provider PVDR on PVDR.PartyID = PRT.PartyID
		Left Join KYPEnrollment.pAccount_PDM_Owner_Role Owr on PRT.PartyID=Owr.PartyID --#3		
		Where PRT.Type='Individual Ownership'
		Union all
		Select A.AccountID,PRT.PartyID,--A.PartyID,//PI-754
			/*A.NPI,*/Case When (ISNULL(Convert(varchar(15),PVDR.NPI),O.NPI) = '0') Then Null Else ISNULL(Convert(varchar(15),PVDR.NPI),O.NPI) End NPI, --#3 --Added Isnull condition for #24 PI-837 --#32 CAPAVE-2540
			NULL
			--,O.TIN--Commented for #12 CAPAVE-1573
			,O.EIN as TIN, --Added for #12 CAPAVE-1573
			--PRT.MOCARelationshipStartDate,--#3
			--PRT.MOCARelationshipEndDate,--#3
			/* #3 Start*/
			--,Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipStartDate
			--	--Commented for #13 CAPAVE-1246, CAPAVE-1275						
			--	--Else (case 
			--	--		when owr.PercentCheck=1 then owr.PercentDate
			--	--		when owr.[Partner]=1 then owr.PartnerDate
			--	--		when owr.Managing=1 then owr.ManagingDate 
			--	--		when owr.Other=1 then owr.OtherDate 
			--	--		end)
			--	Else Owr.OtherDate	--Added for #13 CAPAVE-1246, CAPAVE-1275					
			--	End as MOCASrtDT,
			PRT.MOCARelationshipStartDate as MOCASrtDT, --Changed for #37 CAPAVE-2270				
			isnull(Case When A.LegacyAccountNo is not null then PRT.MOCARelationshipEndDate
				--Else convert(smalldatetime,'2069-12-31')
				End,convert(smalldatetime,'2069-12-31')) MOCAEdDT, --Added Isnull condition for PI-754
			/*#3 End*/		
			O.LEGALNAME, NULL,PRT.DateDeleted,PRT.Type
			,O.LastActionDate --Added on 19Jul2017 by Sundar for CAPAVE-1742				
		from kypenrollment.pADM_Account A
		Join KYPEnrollment.pAccount_BizProfile_Details BP on A.AccountID = BP.AccountID and A.IsDeleted = 0
		Join KYPEnrollment.TaxIDProfile TxP on BP.ProfileID = TxP.profileID and A.EIN = TxP.taxID
		Join kypenrollment.pAccount_PDM_Party PRT On PRT.TaxIDProfileID = TxP.TaxIDProfileID and PRT.IsDeleted=0
		Join kypenrollment.pAccount_PDM_Organization O on PRT.PartyID = O.PartyID and O.IsDeleted=0
		Left Join Kypenrollment.pAccount_PDM_Provider PVDR on PVDR.PartyID = PRT.PartyID
		Left Join KYPEnrollment.pAccount_PDM_Owner_Role Owr on PRT.PartyID=Owr.PartyID --#3			
		Where PRT.Type='Entity Ownership')			
		INSERT INTO [KYPEnrollment].[MocaDetailforAccount]--Change [MocaDetailforAccount_1] to [MocaDetailforAccount]
				   (Seq, --Added for #22 KEN-12838
					[NPI_Old],
					[NPI_New],
					[SSN_Old],
					[SSN_New],
					[TIN_Old],
					[TIN_New],
					[MOCASrtDT_Old],
					[MOCASrtDT_New],
					[MOCAEdDT_Old],
					[MOCAEdDT_New],
					[LegalName_Old],
					[LegalName_New],
					[DOB_Old],
					--[DOB_New], --#7
					[MOCADelDT_Old],
					[MOCADelDT_New],
					[Type_Old],
					[Type_New],
					[PartyID],	
					[userName],
					[AccountID]           
				   )		
		Select ROW_NUMBER() Over(Order by OV.LastActionDate desc) Seq, --Added for #22 KEN-12838
				case when NV.NPI IS NULL then OV.NPI else null end NPI_Old,
				NV.NPI NPI_New,
				case when NV.SSN IS NULL then OV.SSN else null end SSN_Old,
				NV.SSN SSN_New,
				case when NV.TIN IS NULL then Replace(OV.TIN,'-','') else null end TIN_Old, --Changed for #12 CAPAVE-1573
				Replace(NV.TIN,'-','') TIN_New, --Changed for #12 CAPAVE-1573
				case when NV.MOCASrtDT IS NULL then convert(varchar(10),OV.MOCASrtDT,101) else null end MOCASrtDT_Old,
				convert(varchar(10),NV.MOCASrtDT,101) MOCASrtDT_New,
				case when NV.MOCAEdDT IS NULL then convert(varchar(10),OV.MOCAEdDT,101) else null end MOCAEdDT_Old,
				convert(varchar(10),NV.MOCAEdDT,101) MOCAEdDT_New,
				case when NV.LEGALNAME IS NULL/*NV.FirstName IS NULL and NV.LastName Is NULL*/ then OV.LEGALNAME end LEGALNAME_Old, --#7 --#9 PI-754 Uncommented
				--/*NV.LegalName*/NV.LastName+', '+NV.FirstName LEGALNAME_New, --#7
				Case When NV.LegalName IS NOT null then OV.LegalName END, --#9 PI-754
				--case when NV.DOB IS NULL then convert(varchar(10),OV.DOB,101) else null end DOB_Old, --#7
				convert(varchar(10),OV.DOB,101) DOB_Old, --#7
				--convert(varchar(10),NV.DOB,101) DOB_New, --#7
				--case when NV.MOCADelDT IS NULL then isnull(convert(varchar(10),OV.MOCADelDT,101),'12/31/2069') else null end MOCADelDT_Old, --#7
				--convert(varchar(10),NV.MOCADelDT,101) MOCADelDT_New, --#7
				case when (OV.MOCADelDT < @UserDate) then convert(varchar(10),OV.MOCADelDT,101) --#7
						When (OV.MOCADelDT = '2069-12-31') then CONVERT(varchar(10),OV.MOCADelDT,101) --Added this line for #16 CAPAVE-1725	
						When OV.MOCADelDT IS null then '12/31/2069' --Added for #18 CAPAVE-1739			
					 else null end MOCADelDT_Old,--#7
				case when (OV.MOCADelDT >= @UserDate
							and OV.MOCADelDT <> '2069-12-31' --Added this condition to handle default date (2069-12-31) for #16 CAPAVE-1725	
						) then convert(varchar(10),OV.MOCADelDT,101) End MOCADelDT_New, --#7
				case when NV.[Type] IS NULL then OV.[Type] else null end Type_Old,
				NV.[Type] [Type_New],
				OV.PartyID,
				@userName,
				OV.AccountID
		from OV
		Left Join NV on OV.PartyID = NV.PartyID
				AND OV.AccountID = NV.AccountID --#7
		where ov.AccountID = @acc_party_id
		Order by OV.LastActionDate Desc; --Added by Sundar on 17Jul2017 for CAPAVE-1742

		--Added the IF stat. for #27
		IF @@RowCount = 0
		Begin
			Insert into KYPEnrollment.MocaDetailforAccount(AccountId,PartyID,UserName)
			Values (@acc_party_id,0,@Username);
		End
		
		/*#7 PI-641 Start*/
		Update MA
		Set MA.[DOB_New] = CONVERT(varchar(10),P.DOB,101),
			MA.DOB_Old = NULL
		From [KYPEnrollment].[MocaDetailforAccount] MA
		Join KYPEnrollment.pAccount_PDM_Party PR on MA.AccountID=PR.AccountID and MA.PartyID=PR.PartyID
		Join KYPEnrollment.pAccount_PDM_Person P on PR.PartyID=P.PartyID
		Where MA.AccountID = @acc_party_id
		--and P.LastActionDate >= @UserDate
		and P.DoB is not null
		and Exists (Select H.ID	
						From KYPEnrollment.INPUTDOC_MOCAHistory H
						Where H.FieldName='DOB'
						and H.AccountID=MA.AccountID
						and H.DateSearch>=@Date
						and convert(date,P.DoB) = Convert(date,H.ToValue))
		/*#7 PI-641 End*/
	End
	*/
	--Added for #42 Switching off MOCA
	Insert into KYPEnrollment.MocaDetailforAccount(AccountId,PartyID,UserName)
	Values (@acc_party_id,0,@Username);	
	
END


GO

