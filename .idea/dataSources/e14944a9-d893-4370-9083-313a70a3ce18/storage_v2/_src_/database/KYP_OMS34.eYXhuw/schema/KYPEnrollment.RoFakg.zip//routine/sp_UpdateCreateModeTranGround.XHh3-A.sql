
/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: update Mode of Transportation.
-- PARAMETERS:
-- @accountPartyId : partyID to new Account that will be create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_UpdateCreateModeTranGround] @accountPartyId INT, @last_Action_User_ID VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON
DECLARE @date_created DATE = GETDATE();

--Variables and tempTables
CREATE TABLE #typesRows (instanceId INT, instanceType varchar(100));

INSERT INTO #typesRows (instanceId,instanceType)
SELECT o.OperatorId, p.Type
FROM KYPEnrollment.pAccount_PDM_Party p INNER JOIN KYPEnrollment.pAccount_PDM_Operator o ON p.PartyID = o.PartyId
WHERE p.ParentPartyID=@accountPartyId AND p.CurrentRecordFlag=1 AND o.CurrentRecordFlag=1 AND o.IsDeleted <>1 AND p.Type IN ('Non-Medical Operator','AmbulanceDriver','LitterWheelchairVanDriver');

INSERT INTO #typesRows (instanceId,instanceType)
SELECT v.VehicleId, p.Type
FROM KYPEnrollment.pAccount_PDM_Party p INNER JOIN KYPEnrollment.pAccount_PDM_Vehicle v ON p.PartyID = v.PartyId
WHERE p.ParentPartyID=@accountPartyId AND p.CurrentRecordFlag=1 AND v.CurrentRecordFlag=1 AND v.IsDeleted <>1  AND p.Type IN ('Non-Medical Vehicle','Ambulance','Van')

IF EXISTS(SELECT * FROM #typesRows)
BEGIN

	DECLARE @motId INT, @typeEmergency BIT, @nonemergency BIT, @nonmedical BIT, @ground BIT, @wheelchairVan BIT, @littlerVan BIT, @ambulance BIT;
	DECLARE @air BIT=0, @Helicopter BIT=0, @Fixedwing BIT=0;

	SELECT @motId = mot.MotId, @typeEmergency=mot.TypeEmergency, @nonemergency =mot.Nonemergency, @nonmedical= mot.Nonmedical,
	        @ground = mot.Ground, @wheelchairVan = mot.WheelchairVan, @littlerVan = mot.LittlerVan, @ambulance = mot.Ambulance
  FROM KYPEnrollment.pAccount_PDM_ModeOfTransportation mot INNER JOIN KYPEnrollment.pAccount_PDM_Party party ON mot.PartyId=party.PartyID
  WHERE party.CurrentRecordFlag = 1 AND mot.CurrentRecordFlag=1 AND party.IsDeleted <> 1 AND party.PartyID = @accountPartyId

	--NMT
	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('Non-Medical Operator', 'Non-Medical Vehicle')) > 0)
	BEGIN
    SET @nonmedical=1;
	  SET @ground=1;
	END
	--AMBULANCE
	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('AmbulanceDriver', 'Ambulance')) > 0)
	BEGIN
	  SET @ground=1;
	  SET @ambulance=1;
	END
	--VAN/LITTER
	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('LitterWheelchairVanDriver', 'Van')) > 0)
	BEGIN
	  SET @ground=1;
	  IF(@wheelchairVan IS NULL AND @littlerVan IS NULL)
	  BEGIN
	    SET @wheelchairVan=1;
	    SET @littlerVan=1;
	  END
	END

	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('LitterWheelchairVanDriver', 'Van', 'AmbulanceDriver', 'Ambulance')) > 0 AND @typeEmergency IS NULL AND @nonemergency IS NULL)
	BEGIN
	    SET @typeEmergency=1;
	    SET @nonemergency=1;
	END
	--update ModeOfTransportation
  IF( @motId IS NOT null)
  BEGIN
    UPDATE KYPEnrollment.pAccount_PDM_ModeOfTransportation
    SET TypeEmergency = @typeEmergency, Nonemergency = @nonemergency, Nonmedical = @nonmedical,
    Ground = @ground, WheelchairVan = @wheelchairVan, LittlerVan = @littlerVan, Ambulance = @ambulance,
    Air = @air, Helicopter = @Helicopter , Fixedwing = @Fixedwing
    WHERE MotId=@motId
  END
  ELSE
    BEGIN
      INSERT INTO KYPEnrollment.pAccount_PDM_ModeOfTransportation(
              TypeEmergency,
              Nonemergency,
              Air,
              Helicopter,
              Fixedwing,
              Ground,
              WheelchairVan,
              LittlerVan,
              Ambulance,
              PartyId,
              LastAction,
              LastActionDate,
              LastActionUserID,
              DateCreated,
              CurrentRecordFlag,
              Nonmedical)
      VALUES (
              @typeEmergency,
              @nonemergency,
              @air,
              @Helicopter,
              @Fixedwing,
              @ground,
              @wheelchairVan,
              @littlerVan,
              @ambulance,
              @accountPartyId,
              'C',
              @date_created,
              @last_Action_User_ID,
              @date_created,
              1,
              @nonmedical)
    END
END

DROP TABLE #typesRows;

END
GO

