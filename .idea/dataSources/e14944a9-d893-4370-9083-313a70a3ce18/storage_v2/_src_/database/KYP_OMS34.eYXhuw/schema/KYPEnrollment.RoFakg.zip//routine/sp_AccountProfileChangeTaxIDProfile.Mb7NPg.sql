CREATE PROCEDURE [KYPEnrollment].[sp_AccountProfileChangeTaxIDProfile]
(
	@AccountID		INT,
	@OldProfileID	VARCHAR(40),
	@NewProfileID	VARCHAR(40),
	@LoginUser		VARCHAR(100)
)
AS
BEGIN

	BEGIN TRY
	BEGIN TRAN

		DECLARE @TaxID									VARCHAR(10),
				/*@lCount									INT,*/
				@NumberOfAccountforOldProfileIDandTaxID	INT,
				/*@ParentPartyID							INT,
				@AccountExistForOldProfileCount			INT,*/
				@IsAccountEligibileForMOCATaxID			INT,
				@IsAccountEligibleForMixedGroup			INT,
				@NPI									VARCHAR(10),
				@ServiceLocationNo						VARCHAR(3),
				@OwnerNo								VARCHAR(3),
				@OldProfileName							VARCHAR(200),
				@NewProfileName							VARCHAR(200),
				/*@IsMOCAExistForOldProfileID				INT,
				@IsOldTaxIDProfileIDExist				INT,*/
				@IsNewTaxIDProfileIDExist				INT,
				@IsNewTaxIDProfileIDExist1				INT,
				@TaxIDProfileID							INT/*,
				@NewProfileTaxID						VARCHAR(10)*/
		
		DECLARE @TempPersonOrOrganization TABLE
			(
				PartyID						INT,
				Type						VARCHAR(50),
				Name						VARCHAR(100),
				IsProvider 					BIT,
				IsEnrolled 					BIT,
				IsTemp 						BIT,
				IsActive 					BIT,
				DateDeleted					SMALLDATETIME,
				MOCARelationshipStartDate	SMALLDATETIME,
				MOCARelationshipEndDate		SMALLDATETIME,
				CurrentRecordFlag 			BIT,
				SSN 						VARCHAR(11),
				Salutation					VARCHAR(50),
				FirstName					VARCHAR(25),
				MiddleName					VARCHAR(25),
				LastName					VARCHAR(25),
				DOB 						DATETIME,
				PersonOrOrganzationNPI		VARCHAR(10),
				OrgLegalName				VARCHAR(100),
				TIN							VARCHAR(11),
				EIN							VARCHAR(30),
				ProviderID					INT,
				ProviderNPI 				BIGINT,
				AddressID					INT,
				AddressLine1 				VARCHAR(250),
				AddressLine2 				VARCHAR(50),
				City 						VARCHAR(25),
				State 						VARCHAR(40),
				Zip 						VARCHAR(5),
				ZipPlus4 					VARCHAR(50),
				AddressType 				VARCHAR(30),
				LocationID					INT,
				LocAddressType 				VARCHAR(25),
				PdmOwnerID					INT,
				OtherDate 					SMALLDATETIME,
				TypeForm					VARCHAR(100),
				OtherValue					VARCHAR(150),
				DocumentID					INT,
				TypeDoc 					VARCHAR(40),
				NumberDoc 					VARCHAR(16),
				IsStateIssued 				BIT,
				StateIssued 				VARCHAR(40),
				TransactionID				INT,
				Description 				VARCHAR(150),
				Amount 						VARCHAR(10),
				AdverseActionID				INT,
				QuestionID					INT,
				Type_x 						VARCHAR(100),
				Reason 						VARCHAR(1000),
				State_x 					VARCHAR(40),
				Date_x 						DATETIME,
				DateType 					VARCHAR(40),
				EffectiveDate 				DATETIME,
				AdverseActionNPI 			VARCHAR(10),
				AdverseActionCity 			VARCHAR(25),
				ProgramType 				VARCHAR(50),
				Where_x 					VARCHAR(100),
				Action_x 					VARCHAR(50),
				LicenseAuthority 			VARCHAR(100),
				LegalName 					VARCHAR(100),
				DBA 						VARCHAR(100),
				AppFormID 					INT,
				DocumentInstanceID 			INT,
				ProgramTypeOther 			VARCHAR(100),
				OtherOwnershipParentPartyID	INT/*,
				OwnersOrOtherOwnershipFlag	INT*/
			)

		DELETE FROM KYPEnrollment.MOCAatTaxIDAccountProfileChangeHistory

		SELECT @OldProfileName = ProfileName
			FROM KYPEnrollment.pAccount_BizProfile_Master
			WHERE ProfileID = @OldProfileID
			
		SELECT @NewProfileName = ProfileName
			FROM KYPEnrollment.pAccount_BizProfile_Master
			WHERE ProfileID = @NewProfileID
		
		-- Whether Incoming Account is eligible for MOCA Linking or not
		SELECT @IsAccountEligibileForMOCATaxID = COUNT(1)
			FROM KYPEnrollment.pADM_Account ACC
			JOIN KYPEnrollment.pAccount_Owner OWN
			ON ACC.AccountID = OWN.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
			ON ACC.AccountID		= BPD.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
			ON BPD.ProfileId		= BPM.ProfileId
			WHERE	--ACC.EIN			= @TaxID		AND
					--BPM.ProfileID		= @OldProfileID	AND
					ACC.AccountID		= @AccountID AND
					/*ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND*/
					ACC.AccountType		= 'G' AND
					ACC.NPI				NOT LIKE '%[a-z]%' AND
					ACC.NPI				LIKE '1%' AND
					LEFT(StatusAcc,1)	IN ('1','7','9') AND
					ACC.IsDeleted		= 0 AND
					IsTempProfile		= 0 AND
					(ACC.EIN IS NOT NULL AND ACC.EIN != '') AND
					((LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)) AND
					(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE())

		SELECT @TaxID = EIN,@NPI = NPI,@ServiceLocationNo = ServiceLocationNo,@OwnerNo = OwnerNo -- ,@ParentPartyID = PartyID
			FROM KYPEnrollment.pADM_Account
			WHERE AccountID = @AccountID
			
		-- In the below query we are checking that incoming Account is a MG or SG of MG and falling in MOCA TaxID eligibility
		SELECT @IsAccountEligibleForMixedGroup = COUNT(1)
			FROM KYPEnrollment.pADM_Account ACC
			WHERE NPI				= @NPI AND
				  ServiceLocationNo	= @ServiceLocationNo AND
				  OwnerNo			= @OwnerNo AND
				  ProviderTypeCode	= '100' AND
				  IsDeleted			= 0 --AND
				  --@IsAccountEligibileForMOCATaxID	= 1

		-- We confirmed that if MG/SG Profile gets change then all its respective MG/SG Profile should also get change. It should never happen that few Accounts are sitting in P1 Profile and rest of the Accounts are sitting in P2 Profile in same TaxID.
		IF @IsAccountEligibleForMixedGroup > 0 /* AND @IsAccountEligibileForMOCATaxID > 0 (If the Incoming is MG/SG Account, its MG/SG Accounts Profile should get change as MG/SG Account Profile getting update)*/
				
		BEGIN
				
			UPDATE KYPEnrollment.pAccount_BizProfile_Details
				SET ProfileID				= @NewProfileID,
					[LastAction] 			= 'U',
					[LastActionDate] 		= CONVERT(DATE,GETDATE(),112),
					[LastActorUserID] 		= @LoginUser,
					[LastActionApprovedBy] 	= @LoginUser
				WHERE AccountID IN(SELECT AccountID
										FROM KYPEnrollment.pADM_Account ACC
										WHERE NPI					= @NPI AND
											  ServiceLocationNo		= @ServiceLocationNo AND
											  OwnerNo				= @OwnerNo AND
											  IsDeleted				= 0 AND
											  (LEN(ACCOUNTNUMBER)	= 13 OR ProviderTypeCode = '100')) AND
					  AccountID != @AccountID

		END

		-- Number of Account existing in TaxID and Old ProfileID
		SELECT @NumberOfAccountforOldProfileIDandTaxID = COUNT(1)
			FROM KYPEnrollment.pADM_Account ACC
			JOIN KYPEnrollment.pAccount_Owner OWN
			ON ACC.AccountID = OWN.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
			ON ACC.AccountID		= BPD.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
			ON BPD.ProfileId		= BPM.ProfileId
			WHERE	ACC.EIN				= @TaxID		AND
					BPM.ProfileID		= @OldProfileID	AND
					/*ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND*/
					ACC.AccountType		= 'G' AND
					ACC.NPI				NOT LIKE '%[a-z]%' AND
					ACC.NPI				LIKE '1%' AND
					LEFT(StatusAcc,1)	IN ('1','7','9') AND
					ACC.IsDeleted		= 0 AND
					IsTempProfile		= 0 AND
					((LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)) AND
					(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE())

		-- Entry exist in KYPEnrollment.TaxIDProfile table for TaxID and New ProfileID
		SELECT @IsNewTaxIDProfileIDExist = COUNT(1)
			FROM KYPEnrollment.TaxIDProfile
			WHERE	ProfileID	= @NewProfileID AND
					TaxID		= @TaxID

		-- Whether any MOCA existing in TaxID and New ProfileID
		/*SELECT @IsMOCAExistForOldProfileID = COUNT(1)
			FROM KYPEnrollment.TaxIDProfile TP
			JOIN KYPEnrollment.pAccount_PDM_Party P
			ON TP.TaxIDProfileID	= P.TaxIDProfileID
			WHERE	TaxID			= @TaxID		AND
					ProfileID		= @OldProfileID AND
					Type			IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual',
										'SubcontractorEntity','Individual Ownership','Entity Ownership') AND
					P.CurrentRecordFlag	= 1*/


		/*
			Insert the record in KYPEnrollment.TaxIDProfile table if 3 conditions are true.
			1. IF entry is not exist in KYPEnrollment.TaxIDProfile for TaxID and New ProfileID
			2. If the first conditions is true and we should check whether Old ProfileId having any MOCAs. If MOCAs are not there in Old ProfileID and there is no use to insert an entry in KYPEnrollment.TaxIDProfile table.
		*/
		
		IF @IsAccountEligibileForMOCATaxID > 0 AND @IsNewTaxIDProfileIDExist = 0/* AND @IsMOCAExistForOldProfileID > 0*/ -- AND @NewProfileTaxID = @TaxID
		
			BEGIN

				INSERT INTO KYPEnrollment.TaxIDProfile
				(
					ProfileID,
					TaxID,
					CreatedOn,
					CreatedBy
				)
				VALUES
				(
					@NewProfileID,
					@TaxID,
					CONVERT(DATE,GETDATE(),112),
					@LoginUser
				)

				SELECT @TaxIDProfileID = SCOPE_IDENTITY()

			END
		
		ELSE IF @IsAccountEligibileForMOCATaxID > 0 AND @IsNewTaxIDProfileIDExist > 0
		
			BEGIN
			
				SELECT @TaxIDProfileID = TaxIDProfileID
					FROM KYPEnrollment.TaxIDProfile
					WHERE	TaxID		= @TaxID AND
							ProfileID	= @NewProfileID
			
			END
		--SELECT @IsAccountEligibleForMixedGroup = COUNT(1)
		--	FROM KYPEnrollment.pADM_Account ACC
		--	JOIN KYPEnrollment.pADM_Account ACC1
		--	ON ACC.NPI					= ACC1.NPI AND
		--	   ACC.ServiceLocationNo	= ACC1.ServiceLocationNo AND
		--	   ACC.OwnerNo				= ACC1.OwnerNo
		--	WHERE ACC.AccountID						= @AccountID AND
		--		  ACC1.ProviderTypeCode				= '100' AND
		--		  @IsAccountEligibileForMOCATaxID	= 1
/*		
		SELECT @NewProfileTaxID = TaxID
			FROM KYPEnrollment.TaxIDProfile
			WHERE	ProfileID	= @NewProfileID AND
					TaxID		= @TaxID
*/		
		SELECT @IsNewTaxIDProfileIDExist1 = COUNT(1)
			FROM KYPEnrollment.TaxIDProfile
			WHERE	TaxID		= @TaxID AND
					ProfileID	= @NewProfileID

		/*SELECT @IsOldTaxIDProfileIDExist = COUNT(1)
			FROM KYPEnrollment.TaxIDProfile
			WHERE	TaxID		= @TaxID AND
					ProfileID	= @OldProfileID*/

		IF	@IsAccountEligibileForMOCATaxID > 0 AND @NumberOfAccountforOldProfileIDandTaxID = 1 AND /*@NewProfileTaxID = @TaxID AND*/
			/*@IsOldTaxIDProfileIDExist > 0 AND*/ @IsNewTaxIDProfileIDExist1 > 0
		
		BEGIN

			-- Insert all the MOCAs in #TempPartysOfAccount table for TaxID which are not exist for ProfileID and TaxID
			IF OBJECT_ID('tempdb..#TempPartysOfAccount') IS NOT NULL
			BEGIN
				DROP TABLE #TempPartysOfAccount
			END;

			CREATE TABLE #TempPartysOfAccount
			(
				ID			INT PRIMARY KEY IDENTITY(1,1),
				SSNorTIN	VARCHAR(30),
				Type		VARCHAR(50),
				FirstName	VARCHAR(100),
				LastName	VARCHAR(100),
				LegalName	VARCHAR(100)
			)

			SELECT *
				INTO #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN
				FROM (/*SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
							 MOCARelationshipEndDate,CurrentRecordFlag,SSN,Salutation,FirstName,MiddleName,LastName,DOB,NPI
						FROM (*/SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
									 MOCARelationshipEndDate,P.CurrentRecordFlag,PRS.SSN,PRS.Salutation,PRS.FirstName,PRS.MiddleName,PRS.LastName,
									 PRS.DOB,PRS.NPI/*,ROW_NUMBER() OVER (PARTITION BY P.Type,PRS.SSN,PRS.FirstName,PRS.LastName ORDER BY P.MocaRelationshipStartDate ASC) AS RN*/
								FROM KYPEnrollment.pADM_Account ACC
								JOIN KYPEnrollment.pAccount_Owner OWN
								ON ACC.AccountID = OWN.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
								ON	ACC.AccountID	= BPD.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
								ON	BPM.ProfileID	= @OldProfileID	AND
									BPD.ProfileID	= BPM.ProfileID AND
									IsTempProfile	= 0
								JOIN KYPEnrollment.TaxIDProfile TP
								ON	TP.TaxID			= ACC.EIN AND
									TP.ProfileID		= BPD.ProfileID
								JOIN KYPEnrollment.pAccount_PDM_Party P
								ON	TP.TaxIDProfileID	= P.TaxIDProfileID AND
									P.Type				IN('TransactionIndividual','SubcontractorIndividual','Individual Ownership') AND
									P.CurrentRecordFlag = 1
								JOIN KYPEnrollment.pAccount_PDM_Person PRS
								ON	P.PartyID			= PRS.PartyID
								WHERE	ACC.EIN				= @TaxID AND
										/*ACC.PackageName	IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND*/
										ACC.AccountType		= 'G' AND
										ACC.IsDeleted		= 0 AND
										(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND
										(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
										ACC.NPI				NOT LIKE '%[a-z]%' AND
										ACC.NPI				LIKE '1%' AND
										LEFT(StatusAcc,1)	IN ('1','7','9')/*) ILV
							WHERE ILV.RN = 1*/) ILV1

			-- Take unique Organization MOCAs from the Accounts having same TaxID and ProfileID. This temporary table we are using for Performance purpose(Inside the loop, this SQL query shouldn't execute for each loop).
			SELECT *
				INTO #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN
				FROM (/*SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
							 MOCARelationshipEndDate,CurrentRecordFlag,LegalName,TIN,NPI,EIN
						FROM (*/SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
									 MOCARelationshipEndDate,P.CurrentRecordFlag,ORG.LegalName,ORG.TIN,ORG.NPI,ORG.EIN/*,
									 ROW_NUMBER() OVER (PARTITION BY P.Type,ORG.EIN,ORG.LegalName ORDER BY P.MocaRelationshipStartDate ASC) AS RN*/
								FROM KYPEnrollment.pADM_Account ACC
								JOIN KYPEnrollment.pAccount_Owner OWN
								ON ACC.AccountID = OWN.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
								ON	ACC.AccountID	= BPD.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
								ON	BPM.ProfileID	= @OldProfileID	AND
									BPD.ProfileId	= BPM.ProfileID AND
									IsTempProfile	= 0
								JOIN KYPEnrollment.TaxIDProfile TP
								ON	TP.TaxID			= ACC.EIN AND
									TP.ProfileID		= BPD.ProfileID
								JOIN KYPEnrollment.pAccount_PDM_Party P
								ON	TP.TaxIDProfileID	= P.TaxIDProfileID AND
									P.Type				IN('TransactionEntity','SubcontractorEntity','Entity Ownership') AND
									P.CurrentRecordFlag = 1
								JOIN KYPEnrollment.pAccount_PDM_Organization ORG
								ON	P.PartyID		= ORG.PartyID
								WHERE	ACC.EIN				= @TaxID AND
										/*ACC.PackageName	IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND*/
										ACC.AccountType		= 'G' AND
										ACC.IsDeleted		= 0 AND
										(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND
										(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
										ACC.NPI				NOT LIKE '%[a-z]%' AND
										ACC.NPI				LIKE '1%' AND
										LEFT(StatusAcc,1) IN ('1','7','9')/*) ILV
							WHERE ILV.RN = 1*/) ILV1

			INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
				SELECT MPT.SSNorTIN,MPT.MOCAType,NULL,NULL,NULL
					FROM (SELECT ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
								 CASE	WHEN Type = 'Individual Ownership'	THEN PRS.SSN
										WHEN Type = 'Entity Ownership'		THEN ORG.EIN
									END AS SSNorTIN,PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
							FROM KYPEnrollment.pADM_Account ACC
							JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
							ON	ACC.AccountID	= BPD.AccountID
							JOIN KYPEnrollment.TaxIDProfile TP
							ON	TP.TaxID			= ACC.EIN AND
								TP.ProfileID		= BPD.ProfileID		
							JOIN KYPEnrollment.pAccount_PDM_Party P
							ON TP.TaxIDProfileID	= P.TaxIDProfileID
							LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
							ON	P.PartyID			= PRS.PartyID
							LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
							ON P.PartyID			= ORG.PartyID
							WHERE	ACC.EIN			= @TaxID AND
									BPD.ProfileID	= @OldProfileID AND
									/*ACC.AccountID			= @AccountID AND -- 2628742*/
									P.CurrentRecordFlag	= 1 AND
									Type					IN('Individual Ownership','Entity Ownership')) MPT /*KYPEnrollment.UniqueMOCAsProfileTINwise MPT*/
					LEFT JOIN (SELECT	ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
										PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
									FROM KYPEnrollment.pADM_Account ACC
									JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
									ON	ACC.AccountID	= BPD.AccountID
									JOIN KYPEnrollment.TaxIDProfile TP
									ON	TP.TaxID			= ACC.EIN AND
										TP.ProfileID		= BPD.ProfileID		
									JOIN KYPEnrollment.pAccount_PDM_Party P
									ON TP.TaxIDProfileID	= P.TaxIDProfileID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
									ON	P.PartyID			= PRS.PartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
									ON P.PartyID			= ORG.PartyID
									WHERE	ACC.EIN			= @TaxID AND
											BPD.ProfileID	= @NewProfileID AND
											/*ACC.AccountID			= @AccountID AND -- 2628742*/
											P.CurrentRecordFlag	= 1 AND
											Type					IN('Individual Ownership','Entity Ownership')) P
					ON -- P.EIN		= MPT.TAXID AND
					   -- P.ProfileID	= MPT.ProfileID AND
					   (REPLACE(P.SSN,'-','') = REPLACE(MPT.SSNorTIN,'-','') OR REPLACE(P.TIN,'-','') = REPLACE(MPT.SSNorTIN,'-','')) AND
						MPT.MOCAType	= P.MOCAType
					WHERE	/*MPT.ProfileID			= @NewProfileID	AND
							MPT.TaxID				= @TaxID		AND
							MPT.IsDeleted			= 0	AND
							MPT.CurrentRecordFlag	= 1	AND
							MPT.MOCAType			IN('Individual Ownership','Entity Ownership') AND*/
							P.PartyID				IS NULL;
				
				INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
					SELECT	MPT.SSNorTIN,MPT.MOCAType,MPT.FirstName,MPT.LastName,MPT.LegalName
						FROM (SELECT ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
									 CASE	WHEN Type IN('Individual Ownership','TransactionIndividual','SubcontractorIndividual') THEN PRS.SSN
											WHEN Type IN('Entity Ownership','TransactionEntity','SubcontractorEntity') THEN ORG.EIN
										END AS SSNorTIN,PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
									FROM KYPEnrollment.pADM_Account ACC
									JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
									ON	ACC.AccountID	= BPD.AccountID
									JOIN KYPEnrollment.TaxIDProfile TP
									ON	TP.TaxID			= ACC.EIN AND
										TP.ProfileID		= BPD.ProfileID	
									JOIN KYPEnrollment.pAccount_PDM_Party P
									ON TP.TaxIDProfileID	= P.TaxIDProfileID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
									ON	P.PartyID		= PRS.PartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
									ON P.PartyID		= ORG.PartyID
									WHERE ACC.EIN			= @TaxID AND
										  BPD.ProfileID		= @OldProfileID AND
										  /*ACC.AccountID			= @AccountID AND*/
										  P.CurrentRecordFlag	= 1 AND
										  Type					IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity')) MPT
						LEFT JOIN (SELECT ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
										  PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
										FROM KYPEnrollment.pADM_Account ACC
										JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
										ON	ACC.AccountID	= BPD.AccountID
										JOIN KYPEnrollment.TaxIDProfile TP
										ON	TP.TaxID			= ACC.EIN AND
											TP.ProfileID		= BPD.ProfileID	
										JOIN KYPEnrollment.pAccount_PDM_Party P
										ON TP.TaxIDProfileID	= P.TaxIDProfileID
										LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
										ON	P.PartyID		= PRS.PartyID
										LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
										ON P.PartyID		= ORG.PartyID
										WHERE ACC.EIN			= @TaxID AND
											  BPD.ProfileID		= @NewProfileID AND
											  /*ACC.AccountID			= @AccountID AND*/
											  P.CurrentRecordFlag	= 1 AND
											  Type					IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity')) P
						ON -- P.EIN		= MPT.TAXID AND
						   -- P.ProfileID	= MPT.ProfileID AND
						   (((MPT.FirstName IS NULL OR MPT.FirstName = '') AND (MPT.LastName IS NULL OR MPT.LastName = '')) OR (MPT.LegalName IS NULL OR MPT.LegalName = '')) AND
						   ((P.FirstName = MPT.FirstName AND P.LastName = MPT.LastName) OR P.LegalName = MPT.LegalName) AND
							 MPT.MOCAType	= P.MOCAType
						WHERE	/*MPT.ProfileID			= @NewProfileID	AND
								MPT.TaxID				= @TaxID		AND
								MPT.IsDeleted			= 0	AND
								MPT.CurrentRecordFlag	= 1	AND
								MPT.MOCAType			IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity') AND*/
								P.AccountID				IS NULL;

/*		
			INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
				SELECT MPT.SSNorTIN,MPT.MOCAType,NULL,NULL,NULL
					FROM KYPEnrollment.UniqueMOCAsProfileTINwise MPT
					LEFT JOIN (SELECT	ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
										PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
									FROM KYPEnrollment.pADM_Account ACC
									JOIN KYPEnrollment.pAccount_PDM_Party P
									ON ACC.PartyID		= P.ParentPartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
									ON	P.PartyID		= PRS.PartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
									ON P.PartyID		= ORG.PartyID
									WHERE ACC.AccountID			= @AccountID AND -- 2628742
										  P.CurrentRecordFlag	= 1 AND
										  Type					IN('Individual Ownership','Entity Ownership')) P
					ON -- P.EIN		= MPT.TAXID AND
					   -- P.ProfileID	= MPT.ProfileID AND
					   (REPLACE(P.SSN,'-','') = REPLACE(MPT.SSNorTIN,'-','') OR REPLACE(P.TIN,'-','') = REPLACE(MPT.SSNorTIN,'-','')) AND
						MPT.MOCAType	= P.MOCAType
					WHERE	MPT.ProfileID			= @NewProfileID	AND
							MPT.TaxID				= @TaxID		AND
							MPT.IsDeleted			= 0	AND
							MPT.CurrentRecordFlag	= 1	AND
							MPT.MOCAType			IN('Individual Ownership','Entity Ownership') AND
							P.AccountID				IS NULL;
				
			INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
				SELECT MPT.SSNorTIN,MPT.MOCAType,MPT.FirstName,MPT.LastName,MPT.LegalName
					FROM KYPEnrollment.UniqueMOCAsProfileTINwise MPT
					LEFT JOIN (SELECT	ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,-- BPM.ProfileID,
										PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag
									FROM KYPEnrollment.pADM_Account ACC
									JOIN KYPEnrollment.pAccount_PDM_Party P
									ON ACC.PartyID		= P.ParentPartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
									ON	P.PartyID		= PRS.PartyID
									LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
									ON P.PartyID		= ORG.PartyID
									WHERE ACC.AccountID			= @AccountID AND
										  P.CurrentRecordFlag	= 1 AND
										  Type					IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity')) P
					ON -- P.EIN		= MPT.TAXID AND
					   -- P.ProfileID	= MPT.ProfileID AND
					   (((MPT.FirstName IS NULL OR MPT.FirstName = '') AND (MPT.LastName IS NULL OR MPT.LastName = '')) OR (MPT.LegalName IS NULL OR MPT.LegalName = '')) AND
					   ((P.FirstName = MPT.FirstName AND P.LastName = MPT.LastName) OR P.LegalName = MPT.LegalName) AND
						 MPT.MOCAType	= P.MOCAType
					WHERE	MPT.ProfileID			= @NewProfileID	AND
							MPT.TaxID				= @TaxID		AND
							MPT.IsDeleted			= 0	AND
							MPT.CurrentRecordFlag	= 1	AND
							MPT.MOCAType			IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity') AND
							P.AccountID				IS NULL;*/


			MERGE KYPEnrollment.pAccount_PDM_Party TRGT
			USING
			(SELECT	NULL AS PartyID,ILV1.Type,ILV1.Name,ILV1.IsProvider,ILV1.IsEnrolled,ILV1.IsTemp,ILV1.IsActive,ILV1.DateDeleted,
					ILV1.MOCARelationshipStartDate,ILV1.MOCARelationshipEndDate,ILV1.CurrentRecordFlag,ILV1.SSN,ILV1.Salutation,
					ILV1.FirstName,ILV1.MiddleName,ILV1.LastName,ILV1.DOB,ILV1.NPI,PRV.ProvID,PRV.NPI AS ProviderNPI,ADR.AddressID,
					ADR.AddressLine1,ADR.AddressLine2,ADR.City,ADR.State,ADR.Zip,ADR.ZipPlus4,ADR.AddressType,LOC.LocationID,
					LOC.Type LocAddressType,POR.PdmOwnerID,POR.OtherDate,POR.TypeForm,POR.OtherValue,
					DOC.DocumentID,DOC.TypeDoc,DOC.NumberDoc,DOC.IsStateIssued,DOC.StateIssued,OT.TransactionID,OT.Description,OT.Amount,
					AA.AdverseActionID,AA.QuestionID,AA.Type_x,AA.Reason,AA.State_x,AA.Date_x,AA.DateType,AA.EffectiveDate,
					AA.NPI AS AdverseActionNPI,AA.City AS AdverseActionCity,AA.ProgramType,AA.Where_x,AA.Action_x,AA.LicenseAuthority,
					AA.LegalName,AA.DBA,AA.AppFormID,AA.DocumentInstanceID,AA.ProgramTypeOther
				FROM (SELECT PRS.*
						FROM #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN PRS
						JOIN #TempPartysOfAccount TEMP
						ON REPLACE(PRS.SSN,'-','') COLLATE DATABASE_DEFAULT = REPLACE(TEMP.SSNorTIN,'-','') COLLATE DATABASE_DEFAULT
						WHERE TEMP.Type	= 'Individual Ownership'
					  UNION
					  SELECT PRS.*
						FROM #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN PRS
						JOIN #TempPartysOfAccount TEMP
						ON PRS.FirstName COLLATE DATABASE_DEFAULT = TEMP.FirstName COLLATE DATABASE_DEFAULT AND
						   PRS.LastName	 COLLATE DATABASE_DEFAULT = TEMP.LastName  COLLATE DATABASE_DEFAULT AND
						   PRS.Type		 COLLATE DATABASE_DEFAULT = TEMP.Type	   COLLATE DATABASE_DEFAULT
						WHERE TEMP.Type	 IN ('TransactionIndividual','SubcontractorIndividual')) ILV1
				LEFT JOIN KYPEnrollment.pAccount_PDM_Provider PRV
				ON	ILV1.PartyID	= PRV.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Location LOC
				ON	ILV1.PartyID	= LOC.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON	LOC.AddressID	= ADR.AddressID					
				LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role POR
				ON	ILV1.PartyID	= POR.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Document DOC
				ON	ILV1.PartyID	= DOC.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction OT
				ON	ILV1.PartyID	= OT.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_AdverseAction AA
				ON	ILV1.PartyID	= AA.PartyID) SRC
			ON TRGT.PartyID = SRC.PartyID
			WHEN NOT MATCHED THEN
			INSERT(
					-- AccountID
					TaxIDProfileID
					,[Type]
					,[Name]
					,[IsProvider]
					,[IsEnrolled]
					,[IsTemp]
					,[IsActive]
					,[LoadType]
					,[LoadID]
					,[LastLoadDate]
					,[DateModified]
					,[IsDeleted]
					,[Source]
					,[CreatedBy]
					,[DateCreated]
					,[ModifiedBy]
					,[DeletedBy]
					,[DateDeleted]
					-- ,[ParentPartyID]
					,[profile_id]
					,[LastAction]
					,[LastActionDate]
					,[LastActorUserID]
					,[LastActionReason]
					,[LastActionComments]
					,[LastActionApprovedBy]
					,[LastMOCARelationshipUpdateBy]
					,[LastMOCAUpdateBy]
					,[MOCARelationshipStartDate]
					,[MOCARelationshipEndDate]
					,[CurrentRecordFlag]
				)
				VALUES
				(	
					-- @AccountID
					@TaxIDProfileID
					,SRC.[Type]
					,SRC.[Name]
					,SRC.[IsProvider]
					,SRC.[IsEnrolled]
					,SRC.[IsTemp]
					,SRC.[IsActive]
					,'AccountProfileChange'
					,CONVERT(VARCHAR(8), GETDATE(), 112)
					,CONVERT(DATE,GETDATE(),112)
					,NULL
					,0
					,NULL
					,NULL
					,CONVERT(DATE,GETDATE(),112)
					,NULL
					,NULL
					,SRC.[DateDeleted]
					-- ,@ParentPartyID
					,NULL
					,'C'
					,CONVERT(DATE,GETDATE(),112)
					,'system'
					,NULL
					,NULL
					,@LoginUser
					,'M'
					,'M'
					,SRC.[MOCARelationshipStartDate]
					,SRC.[MOCARelationshipEndDate]
					,SRC.[CurrentRecordFlag]
				)
				OUTPUT	INSERTED.PartyID,SRC.Type,SRC.Name,SRC.IsProvider,SRC.IsEnrolled,SRC.IsTemp,SRC.IsActive,SRC.DateDeleted,
						SRC.MOCARelationshipStartDate,SRC.MOCARelationshipEndDate,SRC.CurrentRecordFlag,
						SRC.SSN,SRC.Salutation,SRC.FirstName,SRC.MiddleName,SRC.LastName,SRC.DOB,SRC.NPI,SRC.ProvID,
						SRC.NPI AS ProviderNPI,SRC.AddressID,SRC.AddressLine1,SRC.AddressLine2,SRC.City,
						SRC.State,SRC.Zip,SRC.ZipPlus4,SRC.AddressType,SRC.LocationID,SRC.Type LocAddressType,SRC.PdmOwnerID,SRC.OtherDate,
						SRC.TypeForm,SRC.OtherValue,
						SRC.DocumentID,SRC.TypeDoc,SRC.NumberDoc,SRC.IsStateIssued,SRC.StateIssued,SRC.TransactionID,SRC.Description,SRC.Amount,
						SRC.AdverseActionID,SRC.QuestionID,SRC.Type_x,SRC.Reason,SRC.State_x,SRC.Date_x,SRC.DateType,SRC.EffectiveDate,SRC.NPI AS AdverseActionNPI,
						SRC.City AS AdverseActionCity,SRC.ProgramType,SRC.Where_x,SRC.Action_x,SRC.LicenseAuthority,SRC.LegalName,SRC.DBA,
						SRC.AppFormID,SRC.documentInstanceId,SRC.ProgramTypeOther/*,1*/
					INTO @TempPersonOrOrganization(PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
									 MOCARelationshipEndDate,CurrentRecordFlag,SSN,Salutation,FirstName,MiddleName,LastName,DOB,PersonOrOrganzationNPI,
									 ProviderID,ProviderNPI,AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,
									 LocAddressType,PdmOwnerID,OtherDate,TypeForm,OtherValue,DocumentID,TypeDoc,
									 NumberDoc,IsStateIssued,StateIssued,TransactionID,Description,Amount,AdverseActionID,QuestionID,Type_x,Reason,State_x,Date_x,DateType,EffectiveDate,
									 AdverseActionNPI,AdverseActionCity,ProgramType,Where_x,Action_x,LicenseAuthority,LegalName,DBA,
									 AppFormID,DocumentInstanceID,ProgramTypeOther/*,OwnersOrOtherOwnershipFlag*/);

			MERGE KYPEnrollment.pAccount_PDM_Party TRGT
			USING
			(SELECT	NULL AS PartyID,ILV1.Type,ILV1.Name,ILV1.IsProvider,ILV1.IsEnrolled,ILV1.IsTemp,ILV1.IsActive,ILV1.DateDeleted,
					ILV1.MOCARelationshipStartDate,ILV1.MOCARelationshipEndDate,ILV1.CurrentRecordFlag,ILV1.LegalName AS OrgLegalName,ILV1.TIN,
					ILV1.EIN,ILV1.NPI,PRV.ProvID,PRV.NPI AS ProviderNPI,ADR.AddressID,ADR.AddressLine1,ADR.AddressLine2,ADR.City,
					ADR.State,ADR.Zip,ADR.ZipPlus4,ADR.AddressType,LOC.LocationID,LOC.Type LocAddressType,POR.PdmOwnerID,POR.OtherDate,
					POR.TypeForm,POR.OtherValue,DOC.DocumentID,DOC.TypeDoc,DOC.NumberDoc,DOC.IsStateIssued,DOC.StateIssued,OT.TransactionID,
					OT.Description,OT.Amount,AA.AdverseActionID,AA.QuestionID,AA.Type_x,AA.Reason,AA.State_x,AA.Date_x,AA.DateType,AA.EffectiveDate,
					AA.NPI AS AdverseActionNPI,AA.City AS AdverseActionCity,AA.ProgramType,AA.Where_x,AA.Action_x,AA.LicenseAuthority,
					AA.LegalName,AA.DBA,AA.AppFormID,AA.DocumentInstanceID,AA.ProgramTypeOther
				FROM (SELECT ORG.*
						FROM #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN ORG
						JOIN #TempPartysOfAccount TEMP
						ON REPLACE(ORG.EIN,'-','') COLLATE DATABASE_DEFAULT = REPLACE(TEMP.SSNorTIN,'-','') COLLATE DATABASE_DEFAULT
						WHERE TEMP.Type	= 'Entity Ownership'
					  UNION					  
					  SELECT ORG.*
						FROM #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN ORG
						JOIN #TempPartysOfAccount TEMP
						ON ORG.LegalName COLLATE DATABASE_DEFAULT = TEMP.LegalName COLLATE DATABASE_DEFAULT AND
						   ORG.Type		 COLLATE DATABASE_DEFAULT = TEMP.Type	   COLLATE DATABASE_DEFAULT
						WHERE TEMP.Type IN ('TransactionEntity','SubcontractorEntity')) ILV1
				LEFT JOIN KYPEnrollment.pAccount_PDM_Provider PRV
				ON	ILV1.PartyID	= PRV.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Location LOC
				ON	ILV1.PartyID	= LOC.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON	LOC.AddressID	= ADR.AddressID					
				LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role POR
				ON	ILV1.PartyID	= POR.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Document DOC
				ON	ILV1.PartyID	= DOC.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction OT
				ON	ILV1.PartyID	= OT.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_AdverseAction AA
				ON	ILV1.PartyID	= AA.PartyID) SRC
			ON TRGT.PartyID = SRC.PartyID
			WHEN NOT MATCHED THEN
			INSERT
			(
				-- AccountID
				TaxIDProfileID
				,[Type]
				,[Name]
				,[IsProvider]
				,[IsEnrolled]
				,[IsTemp]
				,[IsActive]
				,[LoadType]
				,[LoadID]
				,[LastLoadDate]
				,[DateModified]
				,[IsDeleted]
				,[Source]
				,[CreatedBy]
				,[DateCreated]
				,[ModifiedBy]
				,[DeletedBy]
				,[DateDeleted]
				-- ,[ParentPartyID]
				,[profile_id]
				,[LastAction]
				,[LastActionDate]
				,[LastActorUserID]
				,[LastActionReason]
				,[LastActionComments]
				,[LastActionApprovedBy]
				,[LastMOCARelationshipUpdateBy]
				,[LastMOCAUpdateBy]
				,[MOCARelationshipStartDate]
				,[MOCARelationshipEndDate]
				,[CurrentRecordFlag]
			)
			VALUES
			(	
				-- @AccountID
				@TaxIDProfileID
				,SRC.[Type]
				,SRC.[Name]
				,SRC.[IsProvider]
				,SRC.[IsEnrolled]
				,SRC.[IsTemp]
				,SRC.[IsActive]
				,'DeltaAccLoad'
				,CONVERT(VARCHAR(8), GETDATE(), 112)
				,CONVERT(DATE,GETDATE(),112)
				,NULL
				,0
				,NULL
				,NULL
				,CONVERT(DATE,GETDATE(),112)
				,NULL
				,NULL
				,SRC.[DateDeleted]
				-- ,@ParentPartyID
				,NULL
				,'C'
				,CONVERT(DATE,GETDATE(),112)
				,'system'
				,NULL
				,NULL
				,@LoginUser
				,'M'
				,'M'
				,SRC.[MOCARelationshipStartDate]
				,SRC.[MOCARelationshipEndDate]
				,SRC.[CurrentRecordFlag]
			)
			OUTPUT	INSERTED.PartyID,SRC.Type,SRC.Name,SRC.IsProvider,SRC.IsEnrolled,SRC.IsTemp,SRC.IsActive,SRC.DateDeleted,
					SRC.MOCARelationshipStartDate,SRC.MOCARelationshipEndDate,SRC.CurrentRecordFlag,
					SRC.OrgLegalName AS OrgLegalName,SRC.TIN,SRC.EIN,SRC.NPI,
					SRC.ProvID,SRC.NPI AS ProviderNPI,SRC.AddressID,SRC.AddressLine1,SRC.AddressLine2,SRC.City,
					SRC.State,SRC.Zip,SRC.ZipPlus4,SRC.AddressType,SRC.LocationID,SRC.Type LocAddressType,SRC.PdmOwnerID,SRC.OtherDate,
					SRC.TypeForm,SRC.OtherValue,
					SRC.DocumentID,SRC.TypeDoc,SRC.NumberDoc,SRC.IsStateIssued,SRC.StateIssued,SRC.TransactionID,SRC.Description,SRC.Amount,
					SRC.AdverseActionID,SRC.QuestionID,SRC.Type_x,SRC.Reason,SRC.State_x,SRC.Date_x,SRC.DateType,SRC.EffectiveDate,
					SRC.NPI AS AdverseActionNPI,SRC.City AS AdverseActionCity,SRC.ProgramType,SRC.Where_x,SRC.Action_x,SRC.LicenseAuthority,
					SRC.LegalName,SRC.DBA,SRC.AppFormID,SRC.documentInstanceId,SRC.ProgramTypeOther/*,1*/
				INTO @TempPersonOrOrganization(PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
								 MOCARelationshipEndDate,CurrentRecordFlag,OrgLegalName,TIN,EIN,PersonOrOrganzationNPI,
								 ProviderID,ProviderNPI,AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,
								 LocAddressType,PdmOwnerID,OtherDate,TypeForm,OtherValue,DocumentID,TypeDoc,
								 NumberDoc,IsStateIssued,StateIssued,TransactionID,Description,Amount,AdverseActionID,QuestionID,Type_x,Reason,State_x,Date_x,DateType,EffectiveDate,
								 AdverseActionNPI,AdverseActionCity,ProgramType,Where_x,Action_x,LicenseAuthority,LegalName,DBA,
								 AppFormID,DocumentInstanceID,ProgramTypeOther/*,OwnersOrOtherOwnershipFlag*/);

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
			(
				PartyID,
				SSN,
				Salutation,
				FirstName,
				MiddleName,
				LastName,
				DoB,
				NPI,
				Deleted,
				DateCreated,
				DateDeleted,
				lastAction,
				LastActionDate,
				LastActorUserId,
				LastActionApprovedBy,
				CurrentRecordFlag
			)
			SELECT	PartyID,
					SSN,
					Salutation,
					FirstName,
					MiddleName,
					LastName,
					DOB,
					PersonOrOrganzationNPI,
					0,
					CONVERT(DATE,GETDATE(),112),
					NULL,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					@LoginUser,
					1  
				FROM @TempPersonOrOrganization
				WHERE Type IN('TransactionIndividual','SubcontractorIndividual','Individual Ownership'--,'OtherOwnershipIndividual'
				) /*AND
					  OwnersOrOtherOwnershipFlag = 1*/

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
				(
					PartyID,
					LegalName,
					DBAName1,
					TIN,
					NPI,
					IsDeleted,
					DateCreated,
					DateDeleted,
					lastAction,
					LastActionDate,
					LastActorUserID,
					LastActionApprovedBy,
					CurrentRecordFlag,
					EIN
				)
				SELECT	PartyID,
						OrgLegalName,
						NULL,
						TIN,
						PersonOrOrganzationNPI,
						0,
						CONVERT(DATE,GETDATE(),112),
						NULL,
						'C',
						CONVERT(DATE,GETDATE(),112),
						@LoginUser,
						@LoginUser,
						1,
						EIN
					FROM @TempPersonOrOrganization
					WHERE Type IN('TransactionEntity','SubcontractorEntity','Entity Ownership'--,'OtherOwnershipEntity'
					) /*AND
						  OwnersOrOtherOwnershipFlag = 1*/

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
		   (
				[PartyID],
				[DateCreated],
				[IsDeleted],
				[NPI],
				[LastAction],
				[LastActionDate],
				[LastActorUserID],
				[LastActionApprovedBy],
				[CurrentRecordFlag]
			)
			SELECT	PartyID,
					CONVERT(DATE,GETDATE(),112)
					,0
					,ProviderNPI
					,'C'
					,CONVERT(DATE,GETDATE(),112)
					,@LoginUser
					,@LoginUser
					,1
				FROM @TempPersonOrOrganization
				WHERE Type IN('Individual Ownership','Entity Ownership') AND
					  ProviderID IS NOT NULL AND ProviderID != ''
			
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
			(
				AddressLine1,
				AddressLine2,
				City,
				State,
				Zip,
				ZipPlus4,
				AddressType,
				LastAction,
				LastActionDate,
				LastActionUserID,
				LastActionApprovedByUsedID,
				CurrentRecordFlag,
				ServiceLocationNo,
				TempAddressID
			)
			SELECT	AddressLine1,
					AddressLine2,
					City,
					State,
					Zip,
					ZipPlus4,
					AddressType,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					@LoginUser,
					1,
					NULL,
					PartyID
				FROM @TempPersonOrOrganization
				WHERE AddressID IS NOT NULL AND AddressID != ''
										
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
			(
				AddressID,
				PartyID,
				ProviderID,
				DateCreated,
				InActive,
				IsDeleted,
				Type,
				LastAction,
				LastActionDate,
				LastActorUserID,
				LastActionApprovedBy,
				CurrentRecordFlag
			)
			SELECT	NULL,
					PartyID,
					NULL,
					CONVERT(DATE,GETDATE(),112),
					1,
					0,
					LocAddressType,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					@LoginUser,
					1
				FROM @TempPersonOrOrganization
				WHERE LocationID IS NOT NULL AND LocationID != ''
			
			UPDATE KYPEnrollment.pAccount_PDM_Location
				SET AddressID = ADR.AddressID
				FROM KYPEnrollment.pAccount_PDM_Location LOC
				JOIN KYPEnrollment.pAccount_PDM_Address ADR
				ON LOC.PartyID	= ADR.TempAddressID
				--WHERE TempAddressID	IN(SELECT PartyID
				--						FROM @TempPersonOrOrganization) AND
				--	  LOC.AddressID	IS NULL

			UPDATE [KYPEnrollment].[pAccount_PDM_Address]
				SET TempAddressID = NULL
				WHERE TempAddressID IN(SELECT PartyID
										FROM @TempPersonOrOrganization);

			INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role
			(
				TypeForm,
				IsDeleted,
				CurrentRecordFlag,
				Other,
				OtherValue,
				OtherDate,
				PartyID,
				DateCreated,
				LastAction,
				LastActionDate,
				LastActionApprovedBy,
				LastActorUserID
			)
			SELECT	TypeForm,
					0,
					1,
					1,
					OtherValue,
					OtherDate,
					PartyID,
					CONVERT(DATE,GETDATE(),112),
					'C',
					NULL,
					@LoginUser,
					@LoginUser  
				FROM @TempPersonOrOrganization
				WHERE Type IN ('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity') AND
					  PdmOwnerID IS NOT NULL AND PdmOwnerID != ''

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Document]
			(
				[PartyID],
				[TypeDoc],
				[NumberDoc],
				[IsStateIssued],
				[StateIssued],
				[CreatedBy],
				[DateCreated],
				[ModifiedBy],
				[DateModified],
				[DeletedBy],
				[DateDeleted],
				[IsDeleted],
				[LastAction],
				[LastActionDate],
				[LastActorUserID],
				[LastActionReason],
				[LastActionComments],
				[LastActionApprovedBy],
				[CurrentRecordFlag]
			)
			SELECT	PartyID,
					TypeDoc,
					NumberDoc,
					IsStateIssued,
					StateIssued,
					NULL,
					CONVERT(DATE,GETDATE(),112),
					NULL,
					NULL,
					NULL,
					NULL,
					0,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					NULL,
					NULL,
					@LoginUser,
					1				
				FROM @TempPersonOrOrganization
				WHERE Type IN('Individual Ownership','Entity Ownership') AND
					  DocumentID IS NOT NULL AND DocumentID != ''
			
			INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction]
			(
				[PartyID],
				[Description],
				[Amount],
				[CreatedBy],
				[DateCreated],
				[ModifiedBy],
				[DateModified],
				[DeletedBy],
				[DateDeleted],
				[IsDeleted],
				[LastAction],
				[LastActionDate],
				[LastActorUserID],
				[LastActionReason],
				[LastActionComments],
				[LastActionApprovedBy],
				[CurrentRecordFlag]
			)
			SELECT	PartyID,
					Description,
					Amount,
					NULL,
					CONVERT(DATE,GETDATE(),112),
					NULL,
					NULL,
					NULL,
					NULL,
					0,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					NULL,
					NULL,
					@LoginUser,
					1				
				FROM @TempPersonOrOrganization
				WHERE TransactionID IS NOT NULL AND TransactionID != ''
			
			INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
			(
				[QuestionID],
				[PartyID],
				[Type_x],
				[Reason],
				[State_x],
				[Date_x],
				[DateType],
				[EffectiveDate],
				[NPI],
				[City],
				[ProgramType],
				[Where_x],
				[Action_x],
				[LicenseAuthority],
				[CreatedBy],
				[DateCreated],
				[ModifiedBy],
				[DateModified],
				[DeletedBy],
				[DateDeleted],
				[IsDeleted],
				[LegalName],
				[DBA],
				[AppFormID],
				[documentInstanceId],
				[LastAction],
				[LastActionDate],
				[LastActorUserID],
				[LastActionReason],
				[LastActionComments],
				[LastActionApprovedBy],
				[CurrentRecordFlag],
				ProgramTypeOther
			)
			SELECT	QuestionID,
					PartyID,
					Type_x,
					Reason,
					State_x,
					Date_x,
					DateType,
					EffectiveDate,
					AdverseActionNPI,
					AdverseActionCity,
					ProgramType,
					Where_x,
					Action_x,
					LicenseAuthority,
					NULL,
					CONVERT(DATE,GETDATE(),112),
					NULL,
					NULL,
					NULL,
					NULL,
					0,
					LegalName,
					DBA,
					AppFormID,
					DocumentInstanceID,
					'C',
					CONVERT(DATE,GETDATE(),112),
					@LoginUser,
					NULL,
					NULL,
					@LoginUser,
					1,
					ProgramTypeOther
				FROM @TempPersonOrOrganization
				WHERE Type IN('Individual Ownership','Entity Ownership') AND
					  AdverseActionID IS NOT NULL AND AdverseActionID != ''

		END

		IF @IsAccountEligibleForMixedGroup > 0 /* AND @IsAccountEligibileForMOCATaxID > 0 (If Incoming MG Account is either eligible for MOCA Linking or not, its SG Accounts Profile should get change as MG Account Profile getting update)*/
		
		BEGIN
								  
			INSERT INTO KYPEnrollment.MOCAatTaxIDAccountProfileChangeHistory(AccountID,OldProfileID,NewProfileID,OldProfileName,NewProfileName)
				SELECT AccountID,@OldProfileID,@NewProfileID,@OldProfileName,@NewProfileName
					FROM KYPEnrollment.pADM_Account	
					WHERE AccountID IN(SELECT AccountID
												FROM KYPEnrollment.pADM_Account ACC
												WHERE NPI				= @NPI AND
													  ServiceLocationNo = @ServiceLocationNo AND
													  OwnerNo			= @OwnerNo AND
													  IsDeleted			= 0 AND
													  (LEN(ACCOUNTNUMBER) = 13 OR ProviderTypeCode = '100')) AND
						  AccountID != @AccountID
			
			SELECT * FROM KYPEnrollment.MOCAatTaxIDAccountProfileChangeHistory

			-- Below two Update statement is for counts of Linking and Unlinking Accounts
			UPDATE KYPEnrollment.pAccount_BizProfile_Master
				SET LinkedAccountCount = (SELECT COUNT(1)
											FROM KYPEnrollment.pAccount_BizProfile_Details
											WHERE ProfileID			= @OldProfileID AND
												  CurrentRecordFlag = 1)
				WHERE ProfileID	= @OldProfileID
			
			UPDATE KYPEnrollment.pAccount_BizProfile_Master
				SET LinkedAccountCount = (SELECT COUNT(1)
											FROM KYPEnrollment.pAccount_BizProfile_Details
											WHERE ProfileID			= @NewProfileID AND
												  CurrentRecordFlag = 1)
				WHERE ProfileID	= @NewProfileID
		
		END

	COMMIT TRAN
	SELECT 1 AS Result

	END TRY

	BEGIN CATCH

		ROLLBACK TRAN
		INSERT INTO kypenrollment.DeltaProcedureErrorLog(ErrorName,ErrorNumber,ErrorProcedure,ErrorMessage,ErrorLine,ErrorDate)
		SELECT 'Enrollment Profile changed MOCA at TaxID Procedure Error',ERROR_NUMBER(),ERROR_PROCEDURE(),ERROR_MESSAGE(),ERROR_LINE(),GETDATE()

		SELECT 0 AS Result

	END CATCH

END
GO

