



/* ==========================================================
-- Author:		<Mvillarroel>

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_PartyAssociate_Taxid]
 	@taxid varchar(10),
 	@profileid varchar(40)
AS

BEGIN
declare @cont       int,
        @UniqueID   int
        

CREATE TABLE #TempUnique
	(
		ID			INT PRIMARY KEY IDENTITY(1,1),
		Uniqueid	int
		)

/*insert into #TempUnique 
select UniqueMOCAsProfileTINwiseID 
from KYPEnrollment.UniqueMOCAsProfileTINwise where TaxID=@taxid and profileid=@profileid */
--***---
INSERT INTO #TempUnique
SELECT UniqueMOCAsProfileTINWiseID
      FROM(SELECT *,ROW_NUMBER() OVER (PARTITION BY MOCAType,SSNorTIN,FirstName,LastName,LegalName ORDER BY UniqueMOCAsProfileTINwiseID) RowNumber
                  FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW
                  WHERE CurrentRecordFlag = 0 AND
                        NOT EXISTS (SELECT 1
                                          FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW1
                                          WHERE ISNULL(UMW.SSNorTIN,'')       = ISNULL(UMW1.SSNorTIN,'') AND 
                                                ISNULL(UMW.FirstName,'')      = ISNULL(UMW1.FirstName,'') AND
                                                ISNULL(UMW.LastName,'')       = ISNULL(UMW1.LastName,'') AND 
                                                ISNULL(UMW.LegalName,'')      = ISNULL(UMW1.LegalName,'') AND
                                                UMW1.ProfileID                = @ProfileID AND
                                                UMW1.TaxID                    = @TaxID AND
                                                UMW1.CurrentRecordFlag        = 1) AND
                        ProfileID   = @ProfileID AND
                        TaxID       = @TaxID) ILV
      WHERE ILV.RowNumber = 1
UNION
SELECT UniqueMOCAsProfileTINWiseID
      FROM KYPEnrollment.UniqueMOCAsProfileTINwise
      WHERE CurrentRecordFlag = 1 AND
            IsDeleted         = 0 AND
            ProfileID         = @ProfileID AND
            TaxID             = @TaxID

---****--

set @cont=1
WHILE @cont <= (SELECT COUNT(*) FROM #TempUnique)
BEGIN
  SELECT @UniqueID=Uniqueid 
  FROM #TempUnique WHERE ID = @cont
  exec [KYPEnrollment].[sp_Update_PartyAssociate] @uniqueid
  set @cont=@cont+1
END

drop table #TempUnique

--recovery all taxid, accountid of accounts that not have mocas
SELECT	ACC.ACCOUNTID,BPM.ProfileID,ACC.EIN AS TaxID,acc.AccountNumber,acc.PartyID as Partyid_account
into #Tempacc
FROM KYPEnrollment.pADM_Account ACC
inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner JOIN KYPEnrollment.pAccount_BizProfile_Details BPD 	ON ACC.AccountID	= BPD.AccountID
inner join KYPEnrollment.pAccount_BizProfile_Master BPM 	ON BPD.ProfileId	= BPM.ProfileId
left JOIN KYPEnrollment.pAccount_PDM_Party P ON ACC.PartyID		= P.ParentPartyID and P.Type IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity','Individual Ownership','Entity Ownership') and
p.CurrentRecordFlag = 1

WHERE	ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND 
(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
BPM.ProfileID		=@profileid AND
ACC.EIN				=@taxid	AND
ACC.IsDeleted		= 0			AND
IsTempProfile		= 0			AND
IsPastOwner=0 and 
p.PartyID is null 
and acc.NPI  NOT LIKE '%[a-z]%'
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')

--insert into paccount_Taxid_associate
insert into kypenrollment.pAccount_TaxID_Associate(AccountID,PartyID,EntityID,TaxID,CurrentRecordFlag ) 
select AccountID,partyid_account,AccountNumber ,taxid,1 from #Tempacc  except
select ass.AccountID,PartyID,EntityID,taxid,1 from kypenrollment.pAccount_TaxID_Associate ass
inner join kypenrollment.paccount_bizprofile_details prof 
on ass.AccountID=prof.AccountID 
where TaxID=@taxid and prof.ProfileID=@profileid 

drop table #Tempacc

end


GO

