


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_SupplementalBusinessActivity] 

 @AccountInternalUseID int,@LastActionComments varchar(20),@ProviderTypeCode varchar(20)
	
AS
BEGIN

Declare
 @CodeIdentification varchar(10),
 @CodeDescription varchar(250),
 @CodeType varchar(10),
 @CreatedBy varchar(100),
 @CodeDateEffDate smalldatetime,
 @CodeDateExpDate smalldatetime,
 @AppCount int,
 @partyid int,
 @accManyUserID int,
 @Typeinertnal int

	if(@ProviderTypeCode='002')
	begin
	 set @Typeinertnal=100
	end
	else
	begin
	set @Typeinertnal=24
	end
	select @partyid=PartyID from  
	KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@LastActionComments
	
	select @AppCount=COUNT(ActivityID) from 
	KYPPORTAL.PortalKYP.pPDM_BusinessActivity   where PartyID = @partyid and isDeleted=0 and TargetPath not like 'pAccount_PDM_BusinessActivity|ActivityID|%'


	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.ActivityID FROM(
		SELECT row_number() OVER(order by ActivityID) As RowNumber,ActivityID
		FROM KYPPORTAL.PortalKYP.pPDM_BusinessActivity  WHERE PartyID = @partyid and isDeleted=0 and TargetPath not like 'pAccount_PDM_BusinessActivity|ActivityID|%')X WHERE X.RowNumber = @AppCount

		SELECT @CodeIdentification =B.Code,@CodeDescription =B.Descriptor,@CodeType ='Category',
		@CodeDateEffDate =A.EffectiveDate,@CodeDateExpDate =null,@CreatedBy ='System'
		FROM KYPPORTAL.PortalKYP.pPDM_BusinessActivity A
		inner join KYPEnrollment.LK_AccInternalUseDataCode B on A.Activity=B.Descriptor and TYPE=@Typeinertnal
		WHERE ActivityID =@accManyUserID
		
		
		
		INSERT INTO KYPEnrollment.EDM_SupplementalInteranlMany
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[isDeleted]
		)
		VALUES(
		@AccountInternalUseID,
		@CodeIdentification 
		,@CodeDescription 
		,@CodeType 
		,@CodeDateEffDate
		,@CodeDateExpDate
		,@CreatedBy
		,0
		)
		
		SET @AppCount = @AppCount - 1
	
	END
END


GO

