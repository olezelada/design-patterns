-- =============================================
-- Author:  <Ozelada>
-- Create date: <12/13/2017>
-- Description: <This procedure generates Professional certificates for O&P packages from Crossover >
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Prof_Certificate_Orth_Prosth] (
  @application_Code VARCHAR (30)
  ,@account_party_id INT
  ,@last_action_user_id VARCHAR(100)
  ,@app_party_Id INT)

AS
BEGIN

			DECLARE @prof_cert_id INT
			DECLARE @today_date DATE = GETDATE()
      DECLARE @is_deleted BIT = 0
      DECLARE @current_record_flag BIT = 1
      DECLARE @last_action VARCHAR(1) = 'C'

	 SELECT @prof_cert_id = NumberID
                                FROM KYPEnrollment.pAccount_PDM_Number
                                WHERE PartyID = @account_party_id AND Type IN ('orthotistBOC', 'orthotistABCOP', 'prosthetistBOC',
                                                         'prosthetistABCOP', 'orthBOCprosthBOC', 'orthABCOPprosthABCOP',
                                                         'orthBOCprosthABCOP', 'orthABCOPprosthBOC', 'orthProsthABCOP', 'MFCertificate')
        IF @prof_cert_id is null or @prof_cert_id = 0
        BEGIN
             INSERT INTO KYPEnrollment.pAccount_PDM_Number
                    ([PartyID],
                    [Type],
                    [Number],
                    [EffectiveDate],
                    [ExpirationDate],
                    [SecondNumber],
                    [SecondEffectiveDate],
                    [SecondExpirationDate],
                    [CurrentRecordFlag],
                    [IsDeleted],
                    [DateCreated],
                    [LastAction],
                    [LastActionDate],
                    [LastActorUserID])
            SELECT  @account_party_id,
                    number.Type,
                    number.Number,
                    number.EffectiveDate,
                    number.ExpirationDate,
                    number.SecondNumber,
                    number.SecondEffectiveDate,
                    number.SecondExpirationDate,
                    @current_record_flag,
                    @is_deleted,
                    @today_date,
                    @last_action,
                    @today_date,
                    @last_action_user_id
            FROM [KYPPORTAL].[PortalKYP].pPDM_Number number
              INNER JOIN [KYPPORTAL].[PortalKYP].pADM_App_Form appForm INNER JOIN [KYPPORTAL].[PortalKYP].pPDM_Party party
                ON party.PartyID = appForm.PartyID ON appForm.PartyID = number.PartyID
            WHERE
              party.PartyID = @app_party_Id AND appForm.Type = 'ProfCertificate' AND number.TypeForm = 'ProfCertificate'
              AND number.IsDeleted = 'false'
        END

END
GO

