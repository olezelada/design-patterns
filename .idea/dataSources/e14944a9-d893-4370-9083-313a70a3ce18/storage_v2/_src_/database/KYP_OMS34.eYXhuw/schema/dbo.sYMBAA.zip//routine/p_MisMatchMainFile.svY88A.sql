-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_MisMatchMainFile] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



Insert into dbo.FileCountMatch(FileName,CA_MMISCount)
select'Main', COUNT(1) as MMISMainCount from dbo.MMIS_Main_PMF_File
union 
select 'MOCA Detail', COUNT(1) as MMISMocaDetailCount from dbo.MMIS_MOCADetailFile
union
select'MOCA Billing Ref',COUNT(1) as MMISMocaRelCount from dbo.MMIS_MOCARelationShipFile
union
select'NMP Detail',COUNT(1) as MMISNMPDCount from dbo.MMIS_NMPDetailFile
union
select'NMP Billing Ref',COUNT(1) as MMISNMPRCount from dbo.MMIS_NMPRelationshipFile
union
select'ORP',COUNT(1) as MMISORPDCount from dbo.MMIS_ORPDetailFile
union
select'Group Billing Ref',COUNT(1) as MMISGrpCount from dbo.MMIS_GroupProvider

update dbo.FileCountMatch
set PAVECount=x.PaveMainCount
,Diff= CA_MMISCount - x.PaveMainCount
from(select COUNT(1) as PaveMainCount from dbo.PAVE_Main_PMF_File)x
where FileName='Main'

update dbo.FileCountMatch
set PAVECount=x.PaveMocaDetailCount
,Diff= CA_MMISCount - x.PaveMocaDetailCount
from(select COUNT(1) as PaveMocaDetailCount from dbo.PAVE_MOCADetailFile)x
where FileName='MOCA Detail'

update dbo.FileCountMatch
set PAVECount=x.PaveMocaRelCount
,Diff= CA_MMISCount - x.PaveMocaRelCount
from(select COUNT(1) as PaveMocaRelCount from dbo.PAVE_MOCARelationShipFile)x
where FileName='MOCA Billing Ref'


update dbo.FileCountMatch
set PAVECount=x.PaveNMPDCount
,Diff= CA_MMISCount - x.PaveNMPDCount
from(select COUNT(1) as PaveNMPDCount from dbo.PAVE_NMPDetailFile)x
where FileName='NMP Detail'

update dbo.FileCountMatch
set PAVECount=x.PaveNMPRCount
,Diff= CA_MMISCount - x.PaveNMPRCount
from(select COUNT(1) as PaveNMPRCount from dbo.PAVE_NMPRelationshipFile)x
where FileName='NMP Billing Ref'

update dbo.FileCountMatch
set PAVECount=x.PaveORPDCount
,Diff= CA_MMISCount - x.PaveORPDCount
from(select COUNT(1) as PaveORPDCount from dbo.PAVE_ORPDetailFile)x
where FileName='ORP'

update dbo.FileCountMatch
set PAVECount=x.PaveGrpCount
,Diff= CA_MMISCount - x.PaveGrpCount
from(select COUNT(1) as PaveGrpCount from dbo.PAVE_GroupProvider)x
where FileName='Group Billing Ref'

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
insert into dbo.MainFileFound_Report(ProvNumber,OwnerNum,ServLocNum,ProvType,FoundInMMIS_PAVE)
select x.DH_PROV_NUMBER,x.DH_OWNER_NUM,x.DH_SERV_LOC_NUM,x.DH_PROV_TYP, 'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_Main_PMF_File x
 left join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where y.DH_PROV_NUMBER is null and y.DH_OWNER_NUM is null and y.DH_SERV_LOC_NUM is null and y.DH_PROV_TYP is null
UNION ALL 
select x.DH_PROV_NUMBER,x.DH_OWNER_NUM,x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_Main_PMF_File x
 left join dbo.MMIS_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where y.DH_PROV_NUMBER is null and y.DH_OWNER_NUM is null and y.DH_SERV_LOC_NUM is null and y.DH_PROV_TYP is null

-----------------------------------------------------

insert into dbo.GRRelationshipFileFound_Report(ProvNumber,OwnerNum,ServLocNum,ProvType,FoundInMMIS_PAVE)
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP], 'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_GroupProvider x
 left join dbo.PAVE_GroupProvider y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
 and x.[PM-PROV-NOS-IN-GRP]=y.[PM-PROV-NOS-IN-GRP]
where y.[PM-PROV-NUMBER] is null and y.[PM-OWNER-NUM] is null and y.[PM-SERV-LOC-NUM] is null and y.[PM-KEY-PROV-TYP] is null
UNION ALL 
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP], 'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_GroupProvider x
 left join dbo.MMIS_GroupProvider y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
 and x.[PM-PROV-NOS-IN-GRP]=y.[PM-PROV-NOS-IN-GRP]
where y.[PM-PROV-NUMBER] is null and y.[PM-OWNER-NUM] is null and y.[PM-SERV-LOC-NUM] is null and y.[PM-KEY-PROV-TYP] is null

-----------------------------------------------------

insert into dbo.NMPRelationshipFileFound_Report(ProvNumber,OwnerNum,ServLocNum,ProvType,RenderingProvNumber,FoundInMMIS_Pave)
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], 'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_NMPRelationshipFile x
 left join dbo.PAVE_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
 and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where y.[PM-PROV-NUMBER] is null and y.[PM-OWNER-NUM] is null and y.[PM-SERV-LOC-NUM] is null and y.[PM-KEY-PROV-TYP] is null
UNION ALL 
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], 'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_NMPRelationshipFile x
 left join dbo.MMIS_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
 and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where y.[PM-PROV-NUMBER] is null and y.[PM-OWNER-NUM] is null and y.[PM-SERV-LOC-NUM] is null and y.[PM-KEY-PROV-TYP] is null

-----------------------------------------------------

insert into dbo.NMPDetailFileFound_Report(NMPProvNumber,FoundInMMIS_PAVE)
select x.NMP_PROV_NO, 'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_NMPDetailFile x
 left join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where y.NMP_PROV_NO is null 
UNION ALL 
select x.NMP_PROV_NO, 'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_NMPDetailFile x
 left join dbo.MMIS_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where y.NMP_PROV_NO is null 

-----------------------------------------------------

insert into dbo.MOCARelationShipFileFound_Report(ProvNumber,OwnerNum,ServLocNum,ProvType,MOCASSN,MOCATIN,FoundInMMIS_PAVE)
select x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE,x.DH_MOCA_BILL_SSN,x.DH_MOCA_BILL_TIN, 'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_MOCARelationShipFile x
 left join dbo.PAVE_MOCARelationShipFile y
 on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
 and x.DH_MOCA_BILL_OWNER=y.DH_MOCA_BILL_OWNER
 and x.DH_MOCA_BILL_LOCATION= y.DH_MOCA_BILL_LOCATION
 and x.DH_MOCA_BILL_PROV_TYPE= y.DH_MOCA_BILL_PROV_TYPE
 and x.DH_MOCA_BILL_SSN= y.DH_MOCA_BILL_SSN
 and x.DH_MOCA_BILL_TIN = y.DH_MOCA_BILL_TIN
where y.DH_MOCA_BILL_PROV_NO is null and y.DH_MOCA_BILL_OWNER is null and y.DH_MOCA_BILL_LOCATION is null and 
y.DH_MOCA_BILL_PROV_TYPE is null and y.DH_MOCA_BILL_SSN is null and y.DH_MOCA_BILL_TIN is null
UNION ALL 
select x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE,x.DH_MOCA_BILL_SSN,x.DH_MOCA_BILL_TIN, 'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_MOCARelationShipFile x
 left join dbo.MMIS_MOCARelationShipFile y
 on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
 and x.DH_MOCA_BILL_OWNER=y.DH_MOCA_BILL_OWNER
 and x.DH_MOCA_BILL_LOCATION= y.DH_MOCA_BILL_LOCATION
 and x.DH_MOCA_BILL_PROV_TYPE= y.DH_MOCA_BILL_PROV_TYPE
 and x.DH_MOCA_BILL_SSN= y.DH_MOCA_BILL_SSN
 and x.DH_MOCA_BILL_TIN = y.DH_MOCA_BILL_TIN
where y.DH_MOCA_BILL_PROV_NO is null and y.DH_MOCA_BILL_OWNER is null and y.DH_MOCA_BILL_LOCATION is null and 
y.DH_MOCA_BILL_PROV_TYPE is null and y.DH_MOCA_BILL_SSN is null and y.DH_MOCA_BILL_TIN is null

-----------------------------------------------------

insert into dbo.MOCADetailFileFound_Report(MOCASSN,MOCATIN,FoundInMMIS_PAVE)
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'MMIS'  as FoundInMMIS_PAVE
 from dbo.MMIS_MOCADetailFile x
 left join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where y.DH_MOCA_SSN is null and y.DH_MOCA_TIN is null
UNION ALL 
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'PAVE'  as FoundInMMIS_PAVE
 from dbo.PAVE_MOCADetailFile x
 left join dbo.MMIS_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where y.DH_MOCA_SSN is null and y.DH_MOCA_TIN is null

-----------------------------------------------------

insert into dbo.ORPProvidersFileFound_Report(ORPProvNumber,FoundInMMIS_PAVE)
select x.[MCAL-ORP-PROV-NO],'MMIS' as FoundInMMIS_PAVE
 from dbo.MMIS_ORPDetailFile x
 left join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where y.[MCAL-ORP-PROV-NO] is null
UNION ALL 
select x.[MCAL-ORP-PROV-NO],'MMIS' as FoundInMMIS_PAVE
 from dbo.PAVE_ORPDetailFile x
 left join dbo.MMIS_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where y.[MCAL-ORP-PROV-NO] is null

----------------------------------------------------
--delete x from (select *, ROW_NUMBER()over(order by provnumber)as row from dbo.GRRelationshipFileFound_Report)x
--where x.row>65535

--delete x from (select *, ROW_NUMBER()over(order by provnumber)as row from dbo.MainFileFound_Report)x
--where x.row>65535

-------------------------

----------------------------------
-------------------------------------Main File Mismatch-------------------------    
insert into dbo.MainfileMismatch_Report(ProvNumber,OwnerNum,ServLocNum,ProvType,FieldName,MMISValue,PAVEValueCompared)
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_OWNER_EFFEC_BEG_DT' as FieldName,x.DH_OWNER_EFFEC_BEG_DT as MMISValue ,y.DH_OWNER_EFFEC_BEG_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_OWNER_EFFEC_BEG_DT ,101)<>convert(varchar(10),y.DH_OWNER_EFFEC_BEG_DT ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_OWNER_EFFEC_END_DT' as FieldName,x.DH_OWNER_EFFEC_END_DT as MMISValue,y.DH_OWNER_EFFEC_END_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_OWNER_EFFEC_END_DT ,101)<>convert(varchar(10),y.DH_OWNER_EFFEC_END_DT ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_LEGAL_NAME' as FieldName,x.DH_LEGAL_NAME as MMISValue,y.DH_LEGAL_NAME as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING( x.DH_LEGAL_NAME,1,28)<>SUBSTRING(y.DH_LEGAL_NAME,1,28)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_EMP_ID_NO' as FieldName,x.DH_EMP_ID_NO as MMISValue,y.DH_EMP_ID_NO as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_EMP_ID_NO<>y.DH_EMP_ID_NO 
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SSN' as FieldName,x.DH_SSN as MMISValue,y.DH_SSN as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SSN<>y.DH_SSN
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PIN' as FieldName,x.DH_PIN as MMISValue,y.DH_PIN as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PIN<>y.DH_PIN
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_TIN_UPDATE_TYPE' as FieldName,x.DH_TIN_UPDATE_TYPE as MMISValue,y.DH_TIN_UPDATE_TYPE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_TIN_UPDATE_TYPE<>y.DH_TIN_UPDATE_TYPE
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_TIN_UPDATE_DATE' as FieldName,x.DH_TIN_UPDATE_DATE as MMISValue,y.DH_TIN_UPDATE_DATE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_TIN_UPDATE_DATE ,101)<>convert(varchar(10),y.DH_TIN_UPDATE_DATE ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_LN1' as FieldName,x.DH_PAY_TO_LN1 as MMISValue,y.DH_PAY_TO_LN1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_PAY_TO_LN1,1,24)<>SUBSTRING(y.DH_PAY_TO_LN1,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_LN2' as FieldName,x.DH_PAY_TO_LN2 as MMISValue,y.DH_PAY_TO_LN2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_PAY_TO_LN2,1,24)<>SUBSTRING(y.DH_PAY_TO_LN2,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_CITY' as FieldName,x.DH_PAY_TO_CITY as MMISValue,y.DH_PAY_TO_CITY as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_PAY_TO_CITY,1,17)<>SUBSTRING(y.DH_PAY_TO_CITY,1,17)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_STATE' as FieldName,x.DH_PAY_TO_STATE as MMISValue,y.DH_PAY_TO_STATE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PAY_TO_STATE<>y.DH_PAY_TO_STATE
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_ZIP5' as FieldName,x.DH_PAY_TO_ZIP5 as MMISValue,y.DH_PAY_TO_ZIP5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PAY_TO_ZIP5<>y.DH_PAY_TO_ZIP5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PAY_TO_ZIP4' as FieldName,x.DH_PAY_TO_ZIP4 as MMISValue,y.DH_PAY_TO_ZIP4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PAY_TO_ZIP4<>y.DH_PAY_TO_ZIP4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_DT_PROV_ADDED' as FieldName,x.DH_DT_PROV_ADDED as MMISValue,y.DH_DT_PROV_ADDED as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_DT_PROV_ADDED <>y.DH_DT_PROV_ADDED 
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_LAST_ACTY_DT' as FieldName,x.DH_LAST_ACTY_DT as MMISValue,y.DH_LAST_ACTY_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_LAST_ACTY_DT ,101)<>convert(varchar(10),y.DH_LAST_ACTY_DT ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_1' as FieldName,x.DH_SANCTION_TXT_1 as MMISValue,y.DH_SANCTION_TXT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_1<>y.DH_SANCTION_TXT_1
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_2' as FieldName,x.DH_SANCTION_TXT_2 as MMISValue,y.DH_SANCTION_TXT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_2<>y.DH_SANCTION_TXT_2
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_3' as FieldName,x.DH_SANCTION_TXT_3 as MMISValue,y.DH_SANCTION_TXT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_3<>y.DH_SANCTION_TXT_3
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_4' as FieldName,x.DH_SANCTION_TXT_4 as MMISValue,y.DH_SANCTION_TXT_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_4<>y.DH_SANCTION_TXT_4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_5' as FieldName,x.DH_SANCTION_TXT_5 as MMISValue,y.DH_SANCTION_TXT_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_5<>y.DH_SANCTION_TXT_5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_6' as FieldName,x.DH_SANCTION_TXT_6 as MMISValue,y.DH_SANCTION_TXT_6 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_6<>y.DH_SANCTION_TXT_6
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_7' as FieldName,x.DH_SANCTION_TXT_7 as MMISValue,y.DH_SANCTION_TXT_7 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_7<>y.DH_SANCTION_TXT_7
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SANCTION_TXT_8' as FieldName,x.DH_SANCTION_TXT_8 as MMISValue,y.DH_SANCTION_TXT_8 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SANCTION_TXT_8<>y.DH_SANCTION_TXT_8
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_LOC_TYPE_CD' as FieldName,x.DH_PROV_LOC_TYPE_CD as MMISValue,y.DH_PROV_LOC_TYPE_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_LOC_TYPE_CD<>y.DH_PROV_LOC_TYPE_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_BUSINESS_NAME' as FieldName,x.DH_PROV_BUSINESS_NAME as MMISValue,y.DH_PROV_BUSINESS_NAME as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_PROV_BUSINESS_NAME,1,28)<>SUBSTRING(y.DH_PROV_BUSINESS_NAME,1,28)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_LN1' as FieldName,x.DH_ADDR_LN1 as MMISValue,y.DH_ADDR_LN1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_ADDR_LN1,1,24)<>SUBSTRING(y.DH_ADDR_LN1,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_LN2' as FieldName,x.DH_ADDR_LN2 as MMISValue,y.DH_ADDR_LN2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_ADDR_LN2,1,24)<>SUBSTRING(y.DH_ADDR_LN2,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_CITY' as FieldName,x.DH_ADDR_CITY as MMISValue,y.DH_ADDR_CITY as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_ADDR_CITY,1,17)<>SUBSTRING(y.DH_ADDR_CITY,1,17)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_STATE' as FieldName,x.DH_ADDR_STATE as MMISValue,y.DH_ADDR_STATE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ADDR_STATE<>y.DH_ADDR_STATE
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_ZIP5' as FieldName,x.DH_ADDR_ZIP5 as MMISValue,y.DH_ADDR_ZIP5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ADDR_ZIP5<>y.DH_ADDR_ZIP5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ADDR_ZIP4' as FieldName,x.DH_ADDR_ZIP4 as MMISValue,y.DH_ADDR_ZIP4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ADDR_ZIP4<>y.DH_ADDR_ZIP4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_CNTY_CD' as FieldName,x.DH_PROV_CNTY_CD as MMISValue,y.DH_PROV_CNTY_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_CNTY_CD<>y.DH_PROV_CNTY_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_TELE_NO' as FieldName,x.DH_PROV_TELE_NO as MMISValue,y.DH_PROV_TELE_NO as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_TELE_NO<>y.DH_PROV_TELE_NO
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_NAME_OF_FAC_ADMIN' as FieldName,x.DH_NAME_OF_FAC_ADMIN as MMISValue,y.DH_NAME_OF_FAC_ADMIN as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_NAME_OF_FAC_ADMIN,1,28)<>SUBSTRING(y.DH_NAME_OF_FAC_ADMIN,1,28)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_LN1' as FieldName,x.DH_MAIL_TO_LN1 as MMISValue,y.DH_MAIL_TO_LN1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_MAIL_TO_LN1,1,24)<>SUBSTRING(y.DH_MAIL_TO_LN1,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_LN2' as FieldName,x.DH_MAIL_TO_LN2 as MMISValue,y.DH_MAIL_TO_LN2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_MAIL_TO_LN2,1,24)<>SUBSTRING(y.DH_MAIL_TO_LN2,1,24)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_CITY' as FieldName,x.DH_MAIL_TO_CITY as MMISValue,y.DH_MAIL_TO_CITY as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where SUBSTRING(x.DH_MAIL_TO_CITY,1,17)<>SUBSTRING(y.DH_MAIL_TO_CITY,1,17)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_STATE' as FieldName,x.DH_MAIL_TO_STATE as MMISValue,y.DH_MAIL_TO_STATE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_MAIL_TO_STATE<>y.DH_MAIL_TO_STATE
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_ZIP5' as FieldName,x.DH_MAIL_TO_ZIP5 as MMISValue,y.DH_MAIL_TO_ZIP5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_MAIL_TO_ZIP5<>y.DH_MAIL_TO_ZIP5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_MAIL_TO_ZIP4' as FieldName,x.DH_MAIL_TO_ZIP4 as MMISValue,y.DH_MAIL_TO_ZIP4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_MAIL_TO_ZIP4<>y.DH_MAIL_TO_ZIP4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_OUT_OF_STATE_IND' as FieldName,x.DH_OUT_OF_STATE_IND as MMISValue,y.DH_OUT_OF_STATE_IND as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_OUT_OF_STATE_IND<>y.DH_OUT_OF_STATE_IND
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_TYP' as FieldName,x.DH_PROV_TYP as MMISValue,y.DH_PROV_TYP as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_TYP<>y.DH_PROV_TYP
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ENROL_STAT_CD_1' as FieldName,x.DH_ENROL_STAT_CD_1 as MMISValue,y.DH_ENROL_STAT_CD_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ENROL_STAT_CD_1<>y.DH_ENROL_STAT_CD_1
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_EFF_DT_1' as FieldName,x.DH_STAT_EFF_DT_1 as MMISValue,y.DH_STAT_EFF_DT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_EFF_DT_1  ,101)<>convert(varchar(10),y.DH_STAT_EFF_DT_1  ,101)
and coalesce(x.DH_STAT_EFF_DT_1,'')<>'' and coalesce(y.DH_STAT_EFF_DT_1,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_END_DT_1' as FieldName,x.DH_STAT_END_DT_1 as MMISValue,y.DH_STAT_END_DT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_END_DT_1  ,101)<>convert(varchar(10),y.DH_STAT_END_DT_1  ,101)
and coalesce(x.DH_STAT_END_DT_1,'')<>'' and coalesce(y.DH_STAT_END_DT_1,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ENROL_STAT_CD_2' as FieldName,x.DH_ENROL_STAT_CD_2 as MMISValue,y.DH_ENROL_STAT_CD_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ENROL_STAT_CD_2<>y.DH_ENROL_STAT_CD_2
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_EFF_DT_2' as FieldName,x.DH_STAT_EFF_DT_2 as MMISValue,y.DH_STAT_EFF_DT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_EFF_DT_2  ,101)<>convert(varchar(10),y.DH_STAT_EFF_DT_2  ,101)
and coalesce(x.DH_STAT_EFF_DT_2,'')<>'' and coalesce(y.DH_STAT_EFF_DT_2,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_END_DT_2' as FieldName,x.DH_STAT_END_DT_2 as MMISValue,y.DH_STAT_END_DT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_END_DT_2  ,101)<>convert(varchar(10),y.DH_STAT_END_DT_2  ,101)
and coalesce(x.DH_STAT_END_DT_2,'')<>'' and coalesce(y.DH_STAT_END_DT_2,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ENROL_STAT_CD_3' as FieldName,x.DH_ENROL_STAT_CD_3 as MMISValue,y.DH_ENROL_STAT_CD_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ENROL_STAT_CD_3<>y.DH_ENROL_STAT_CD_3
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_EFF_DT_3' as FieldName,x.DH_STAT_EFF_DT_3 as MMISValue,y.DH_STAT_EFF_DT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_EFF_DT_3 ,101)<>convert(varchar(10),y.DH_STAT_EFF_DT_3 ,101)
and coalesce(x.DH_STAT_EFF_DT_3,'')<>'' and coalesce(y.DH_STAT_EFF_DT_3,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_END_DT_3' as FieldName,x.DH_STAT_END_DT_3 as MMISValue,y.DH_STAT_END_DT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_END_DT_3 ,101)<>convert(varchar(10),y.DH_STAT_END_DT_3 ,101)
and coalesce(x.DH_STAT_END_DT_3,'')<>'' and coalesce(y.DH_STAT_END_DT_3,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ENROL_STAT_CD_4' as FieldName,x.DH_ENROL_STAT_CD_4 as MMISValue,y.DH_ENROL_STAT_CD_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ENROL_STAT_CD_4<>y.DH_ENROL_STAT_CD_4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_EFF_DT_4' as FieldName,x.DH_STAT_EFF_DT_4 as MMISValue,y.DH_STAT_EFF_DT_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_EFF_DT_4 ,101)<>convert(varchar(10),y.DH_STAT_EFF_DT_4 ,101)
and coalesce(x.DH_STAT_EFF_DT_4,'')<>'' and coalesce(y.DH_STAT_EFF_DT_4,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_END_DT_4' as FieldName,x.DH_STAT_END_DT_4 as MMISValue,y.DH_STAT_END_DT_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_END_DT_4 ,101)<>convert(varchar(10),y.DH_STAT_END_DT_4 ,101)
and coalesce(x.DH_STAT_END_DT_4,'')<>'' and coalesce(y.DH_STAT_END_DT_4,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_ENROL_STAT_CD_5' as FieldName,x.DH_ENROL_STAT_CD_5 as MMISValue,y.DH_ENROL_STAT_CD_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_ENROL_STAT_CD_5<>y.DH_ENROL_STAT_CD_5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_EFF_DT_5' as FieldName,x.DH_STAT_EFF_DT_5 as MMISValue,y.DH_STAT_EFF_DT_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_EFF_DT_5,101)<>convert(varchar(10),y.DH_STAT_EFF_DT_5,101)
and coalesce(x.DH_STAT_EFF_DT_5,'')<>'' and coalesce(y.DH_STAT_EFF_DT_5,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_STAT_END_DT_5' as FieldName,x.DH_STAT_END_DT_5 as MMISValue,y.DH_STAT_END_DT_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_STAT_END_DT_5,101)<>convert(varchar(10),y.DH_STAT_END_DT_5,101)
and coalesce(x.DH_STAT_END_DT_5,'')<>'' and coalesce(y.DH_STAT_END_DT_5,'')<>''
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_1' as FieldName,x.DH_CATSERV_CD_1 as MMISValue,y.DH_CATSERV_CD_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_1<>y.DH_CATSERV_CD_1
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_1' as FieldName,x.DH_CATSERV_BEGIN_DT_1 as MMISValue,y.DH_CATSERV_BEGIN_DT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_1 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_1 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_1' as FieldName,x.DH_CATSERV_END_DT_1 as MMISValue,y.DH_CATSERV_END_DT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_1 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_1 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_2' as FieldName,x.DH_CATSERV_CD_2 as MMISValue,y.DH_CATSERV_CD_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_2<>y.DH_CATSERV_CD_2
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_2' as FieldName,x.DH_CATSERV_BEGIN_DT_2 as MMISValue,y.DH_CATSERV_BEGIN_DT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_2  ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_2 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_2' as FieldName,x.DH_CATSERV_END_DT_2 as MMISValue,y.DH_CATSERV_END_DT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_2 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_2 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_3' as FieldName,x.DH_CATSERV_CD_3 as MMISValue,y.DH_CATSERV_CD_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_3<>y.DH_CATSERV_CD_3
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_3' as FieldName,x.DH_CATSERV_BEGIN_DT_3 as MMISValue,y.DH_CATSERV_BEGIN_DT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_3  ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_3 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_3' as FieldName,x.DH_CATSERV_END_DT_3 as MMISValue,y.DH_CATSERV_END_DT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_3 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_3 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_4' as FieldName,x.DH_CATSERV_CD_4 as MMISValue,y.DH_CATSERV_CD_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_4<>y.DH_CATSERV_CD_4
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_4' as FieldName,x.DH_CATSERV_BEGIN_DT_4 as MMISValue,y.DH_CATSERV_BEGIN_DT_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_4 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_4 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_4' as FieldName,x.DH_CATSERV_END_DT_4 as MMISValue,y.DH_CATSERV_END_DT_4 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_4 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_4 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_5' as FieldName,x.DH_CATSERV_CD_5 as MMISValue,y.DH_CATSERV_CD_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_5<>y.DH_CATSERV_CD_5
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_5' as FieldName,x.DH_CATSERV_BEGIN_DT_5 as MMISValue,y.DH_CATSERV_BEGIN_DT_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_5 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_5 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_5' as FieldName,x.DH_CATSERV_END_DT_5 as MMISValue,y.DH_CATSERV_END_DT_5 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_5 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_5 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_6' as FieldName,x.DH_CATSERV_CD_6 as MMISValue,y.DH_CATSERV_CD_6 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_6<>y.DH_CATSERV_CD_6
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_6' as FieldName,x.DH_CATSERV_BEGIN_DT_6 as MMISValue,y.DH_CATSERV_BEGIN_DT_6 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_6 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_6 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_6' as FieldName,x.DH_CATSERV_END_DT_6 as MMISValue,y.DH_CATSERV_END_DT_6 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_6 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_6 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_7' as FieldName,x.DH_CATSERV_CD_7 as MMISValue,y.DH_CATSERV_CD_7 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_7<>y.DH_CATSERV_CD_7
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_7' as FieldName,x.DH_CATSERV_BEGIN_DT_7 as MMISValue,y.DH_CATSERV_BEGIN_DT_7 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_7 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_7 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_7' as FieldName,x.DH_CATSERV_END_DT_7 as MMISValue,y.DH_CATSERV_END_DT_7 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_7 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_7 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_8' as FieldName,x.DH_CATSERV_CD_8 as MMISValue,y.DH_CATSERV_CD_8 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_8<>y.DH_CATSERV_CD_8
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_8' as FieldName,x.DH_CATSERV_BEGIN_DT_8 as MMISValue,y.DH_CATSERV_BEGIN_DT_8 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_8 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_8 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_8' as FieldName,x.DH_CATSERV_END_DT_8 as MMISValue,y.DH_CATSERV_END_DT_8 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_8 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_8 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_9' as FieldName,x.DH_CATSERV_CD_9 as MMISValue,y.DH_CATSERV_CD_9 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_9<>y.DH_CATSERV_CD_9
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_9' as FieldName,x.DH_CATSERV_BEGIN_DT_9 as MMISValue,y.DH_CATSERV_BEGIN_DT_9 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_9 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_9 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_9' as FieldName,x.DH_CATSERV_END_DT_9 as MMISValue,y.DH_CATSERV_END_DT_9 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_9 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_9 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_10' as FieldName,x.DH_CATSERV_CD_10 as MMISValue,y.DH_CATSERV_CD_10 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_10<>y.DH_CATSERV_CD_10
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_10' as FieldName,x.DH_CATSERV_BEGIN_DT_10 as MMISValue,y.DH_CATSERV_BEGIN_DT_10 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_10 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_10 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_10' as FieldName,x.DH_CATSERV_END_DT_10 as MMISValue,y.DH_CATSERV_END_DT_10 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_10 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_10 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_11' as FieldName,x.DH_CATSERV_CD_11 as MMISValue,y.DH_CATSERV_CD_11 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_11<>y.DH_CATSERV_CD_11
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_11' as FieldName,x.DH_CATSERV_BEGIN_DT_11 as MMISValue,y.DH_CATSERV_BEGIN_DT_11 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_11 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_11 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_11' as FieldName,x.DH_CATSERV_END_DT_11 as MMISValue,y.DH_CATSERV_END_DT_11 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_11 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_11 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_12' as FieldName,x.DH_CATSERV_CD_12 as MMISValue,y.DH_CATSERV_CD_12 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_12<>y.DH_CATSERV_CD_12
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_12' as FieldName,x.DH_CATSERV_BEGIN_DT_12 as MMISValue,y.DH_CATSERV_BEGIN_DT_12 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_12 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_12 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_12' as FieldName,x.DH_CATSERV_END_DT_12 as MMISValue,y.DH_CATSERV_END_DT_12 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_12 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_12 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_13' as FieldName,x.DH_CATSERV_CD_13 as MMISValue,y.DH_CATSERV_CD_13 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_13<>y.DH_CATSERV_CD_13
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_13' as FieldName,x.DH_CATSERV_BEGIN_DT_13 as MMISValue,y.DH_CATSERV_BEGIN_DT_13 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_13 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_13 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_13' as FieldName,x.DH_CATSERV_END_DT_13 as MMISValue,y.DH_CATSERV_END_DT_13 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_13 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_13 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_14' as FieldName,x.DH_CATSERV_CD_14 as MMISValue,y.DH_CATSERV_CD_14 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_14<>y.DH_CATSERV_CD_14
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_14' as FieldName,x.DH_CATSERV_BEGIN_DT_14 as MMISValue,y.DH_CATSERV_BEGIN_DT_14 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_14 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_14 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_14' as FieldName,x.DH_CATSERV_END_DT_14 as MMISValue,y.DH_CATSERV_END_DT_14 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_14 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_14 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_15' as FieldName,x.DH_CATSERV_CD_15 as MMISValue,y.DH_CATSERV_CD_15 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_15<>y.DH_CATSERV_CD_15
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_15' as FieldName,x.DH_CATSERV_BEGIN_DT_15 as MMISValue,y.DH_CATSERV_BEGIN_DT_15 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_15 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_15 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_15' as FieldName,x.DH_CATSERV_END_DT_15 as MMISValue,y.DH_CATSERV_END_DT_15 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_15 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_15 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_16' as FieldName,x.DH_CATSERV_CD_16 as MMISValue,y.DH_CATSERV_CD_16 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_16<>y.DH_CATSERV_CD_16
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_16' as FieldName,x.DH_CATSERV_BEGIN_DT_16 as MMISValue,y.DH_CATSERV_BEGIN_DT_16 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_16 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_16 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_16' as FieldName,x.DH_CATSERV_END_DT_16 as MMISValue,y.DH_CATSERV_END_DT_16 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_16 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_16 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_17' as FieldName,x.DH_CATSERV_CD_17 as MMISValue,y.DH_CATSERV_CD_17 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_17<>y.DH_CATSERV_CD_17
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_17' as FieldName,x.DH_CATSERV_BEGIN_DT_17 as MMISValue,y.DH_CATSERV_BEGIN_DT_17 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_17 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_17 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_17' as FieldName,x.DH_CATSERV_END_DT_17 as MMISValue,y.DH_CATSERV_END_DT_17 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_17 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_17 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_18' as FieldName,x.DH_CATSERV_CD_18 as MMISValue,y.DH_CATSERV_CD_18 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_18<>y.DH_CATSERV_CD_18
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_18' as FieldName,x.DH_CATSERV_BEGIN_DT_18 as MMISValue,y.DH_CATSERV_BEGIN_DT_18 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_18 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_18 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_18' as FieldName,x.DH_CATSERV_END_DT_18 as MMISValue,y.DH_CATSERV_END_DT_18 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_18 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_18 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_19' as FieldName,x.DH_CATSERV_CD_19 as MMISValue,y.DH_CATSERV_CD_19 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_19<>y.DH_CATSERV_CD_19
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_19' as FieldName,x.DH_CATSERV_BEGIN_DT_19 as MMISValue,y.DH_CATSERV_BEGIN_DT_19 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_19 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_19 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_19' as FieldName,x.DH_CATSERV_END_DT_19 as MMISValue,y.DH_CATSERV_END_DT_19 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_19 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_19 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_CD_20' as FieldName,x.DH_CATSERV_CD_20 as MMISValue,y.DH_CATSERV_CD_20 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CATSERV_CD_20<>y.DH_CATSERV_CD_20
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_BEGIN_DT_20' as FieldName,x.DH_CATSERV_BEGIN_DT_20 as MMISValue,y.DH_CATSERV_BEGIN_DT_20 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_BEGIN_DT_20 ,101)<>convert(varchar(10),y.DH_CATSERV_BEGIN_DT_20 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CATSERV_END_DT_20' as FieldName,x.DH_CATSERV_END_DT_20 as MMISValue,y.DH_CATSERV_END_DT_20 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_CATSERV_END_DT_20 ,101)<>convert(varchar(10),y.DH_CATSERV_END_DT_20 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CD_1' as FieldName,x.DH_SPE_CD_1 as MMISValue,y.DH_SPE_CD_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SPE_CD_1<>y.DH_SPE_CD_1
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CERT_DT_1' as FieldName,x.DH_SPE_CERT_DT_1 as MMISValue,y.DH_SPE_CERT_DT_1 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_SPE_CERT_DT_1 ,101)<>convert(varchar(10),y.DH_SPE_CERT_DT_1 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CD_2' as FieldName,x.DH_SPE_CD_2 as MMISValue,y.DH_SPE_CD_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SPE_CD_2<>y.DH_SPE_CD_2
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CERT_DT_2' as FieldName,x.DH_SPE_CERT_DT_2 as MMISValue,y.DH_SPE_CERT_DT_2 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_SPE_CERT_DT_2 ,101)<>convert(varchar(10),y.DH_SPE_CERT_DT_2 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CD_3' as FieldName,x.DH_SPE_CD_3 as MMISValue,y.DH_SPE_CD_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SPE_CD_3<>y.DH_SPE_CD_3
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPE_CERT_DT_3' as FieldName,x.DH_SPE_CERT_DT_3 as MMISValue,y.DH_SPE_CERT_DT_3 as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_SPE_CERT_DT_3 ,101)<>convert(varchar(10),y.DH_SPE_CERT_DT_3 ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_SPEC_PROCESS_TYPE_CD' as FieldName,x.DH_SPEC_PROCESS_TYPE_CD as MMISValue,y.DH_SPEC_PROCESS_TYPE_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_SPEC_PROCESS_TYPE_CD<>y.DH_SPEC_PROCESS_TYPE_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_IMD_FACIL_TYPE' as FieldName,x.DH_IMD_FACIL_TYPE as MMISValue,y.DH_IMD_FACIL_TYPE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_IMD_FACIL_TYPE<>y.DH_IMD_FACIL_TYPE
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_TYP_OF_PRAC_ORG' as FieldName,x.DH_TYP_OF_PRAC_ORG as MMISValue,y.DH_TYP_OF_PRAC_ORG as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_TYP_OF_PRAC_ORG<>y.DH_TYP_OF_PRAC_ORG
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_APP_DT' as FieldName,x.DH_APP_DT as MMISValue,y.DH_APP_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_APP_DT ,101)<>convert(varchar(10),y.DH_APP_DT ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_REJECT_REASON_CD' as FieldName,x.DH_REJECT_REASON_CD as MMISValue,y.DH_REJECT_REASON_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_REJECT_REASON_CD<>y.DH_REJECT_REASON_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_EXCEPTION_IND' as FieldName,x.DH_EXCEPTION_IND as MMISValue,y.DH_EXCEPTION_IND as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_EXCEPTION_IND<>y.DH_EXCEPTION_IND
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROVIS_ENROLL_CD' as FieldName,x.DH_PROVIS_ENROLL_CD as MMISValue,y.DH_PROVIS_ENROLL_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where ltrim(rtrim(x.DH_PROVIS_ENROLL_CD))<>y.DH_PROVIS_ENROLL_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROVIS_ENROLL_EFFEC_DT' as FieldName,x.DH_PROVIS_ENROLL_EFFEC_DT as MMISValue,y.DH_PROVIS_ENROLL_EFFEC_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_PROVIS_ENROLL_EFFEC_DT ,101)<>convert(varchar(10),y.DH_PROVIS_ENROLL_EFFEC_DT ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_RE_ENROLLMENT_IND' as FieldName,x.DH_RE_ENROLLMENT_IND as MMISValue,y.DH_RE_ENROLLMENT_IND as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_RE_ENROLLMENT_IND<>y.DH_RE_ENROLLMENT_IND
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_RE_ENROLL_EFF_DATE' as FieldName,x.DH_RE_ENROLL_EFF_DATE as MMISValue,y.DH_RE_ENROLL_EFF_DATE as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where convert(varchar(10),x.DH_RE_ENROLL_EFF_DATE ,101)<>convert(varchar(10),y.DH_RE_ENROLL_EFF_DATE ,101)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_LIC_NO' as FieldName,x.DH_PROV_LIC_NO as MMISValue,y.DH_PROV_LIC_NO as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_LIC_NO<>y.DH_PROV_LIC_NO
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_LIC_BOARD_CD' as FieldName,x.DH_PROV_LIC_BOARD_CD as MMISValue,y.DH_PROV_LIC_BOARD_CD as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_PROV_LIC_BOARD_CD<>y.DH_PROV_LIC_BOARD_CD
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_PROV_LIC_DT' as FieldName,x.DH_PROV_LIC_DT as MMISValue,y.DH_PROV_LIC_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where cast(convert(varchar(10),x.DH_PROV_LIC_DT ,101)as DATE)<>cast(convert(varchar(10),y.DH_PROV_LIC_DT ,101)as DATE)
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CLIA_NUMBER' as FieldName,x.DH_CLIA_NUMBER as MMISValue,y.DH_CLIA_NUMBER as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CLIA_NUMBER<>y.DH_CLIA_NUMBER
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_CLIA_TYPE_CERTIFICATION' as FieldName,x.DH_CLIA_TYPE_CERTIFICATION as MMISValue,y.DH_CLIA_TYPE_CERTIFICATION as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where x.DH_CLIA_TYPE_CERTIFICATION<>y.DH_CLIA_TYPE_CERTIFICATION
union all 
select x.DH_PROV_NUMBER, x.DH_OWNER_NUM, x.DH_SERV_LOC_NUM,x.DH_PROV_TYP,
'DH_TYPE_LAST_ACTY_DT' as FieldName,x.DH_TYPE_LAST_ACTY_DT as MMISValue,y.DH_TYPE_LAST_ACTY_DT as PAVEValue
 from dbo.MMIS_Main_PMF_File x
 inner join dbo.PAVE_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
 and x.DH_PROV_TYP=y.DH_PROV_TYP
where cast(convert(varchar(10),x.DH_TYPE_LAST_ACTY_DT ,101)as date)<>cast(convert(varchar(10),y.DH_TYPE_LAST_ACTY_DT  ,101)as DATE)


------------------------------------Main file mismatch end----------------------------

------------------------------------ORP File Mismatch start---------------------------
insert into dbo.ORPProvidersFileMismatch_Report(ORPProvNumber,FieldName,MMISValue,PAVEValueCompared)
select x.[MCAL-ORP-PROV-NO], '[MCAL-ORP-LEGAL-NAME]' as FieldName,x.[MCAL-ORP-LEGAL-NAME] as MMISValue ,y.[MCAL-ORP-LEGAL-NAME] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-LEGAL-NAME]))<>ltrim(rtrim(y.[MCAL-ORP-LEGAL-NAME]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-SSN]' as FieldName,
x.[MCAL-ORP-SSN] as MMISValue ,
y.[MCAL-ORP-SSN] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-SSN]))<>ltrim(rtrim(y.[MCAL-ORP-SSN]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-LN1]' as FieldName,
x.[MCAL-ORP-ADDR-LN1] as MMISValue ,
y.[MCAL-ORP-ADDR-LN1] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-ADDR-LN1])),1,24)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-ADDR-LN1])),1,24)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-LN2]' as FieldName,
x.[MCAL-ORP-ADDR-LN2] as MMISValue ,
y.[MCAL-ORP-ADDR-LN2] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-ADDR-LN2])),1,24)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-ADDR-LN2])),1,24)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-CITY]' as FieldName,
x.[MCAL-ORP-ADDR-CITY] as MMISValue ,
y.[MCAL-ORP-ADDR-CITY] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-ADDR-CITY])),1,17)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-ADDR-CITY])),1,17)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-STATE]' as FieldName,
x.[MCAL-ORP-ADDR-STATE] as MMISValue ,
y.[MCAL-ORP-ADDR-STATE] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ADDR-STATE]))<>ltrim(rtrim(y.[MCAL-ORP-ADDR-STATE]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-ZIP_5]' as FieldName,
x.[MCAL-ORP-ADDR-ZIP_5] as MMISValue ,
y.[MCAL-ORP-ADDR-ZIP_5] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ADDR-ZIP_5]))<>ltrim(rtrim(y.[MCAL-ORP-ADDR-ZIP_5]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ADDR-ZIP_4]' as FieldName,
x.[MCAL-ORP-ADDR-ZIP_4] as MMISValue ,
y.[MCAL-ORP-ADDR-ZIP_4] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ADDR-ZIP_4]))<>ltrim(rtrim(y.[MCAL-ORP-ADDR-ZIP_4]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-LN1]' as FieldName,
x.[MCAL-ORP-MAIL-TO-LN1] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-LN1] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-LN1])),1,24)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-LN1])),1,24)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-LN2]' as FieldName,
x.[MCAL-ORP-MAIL-TO-LN2] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-LN2] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-LN2])),1,24)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-LN2])),1,24)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-CITY]' as FieldName,
x.[MCAL-ORP-MAIL-TO-CITY] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-CITY] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where SUBSTRING(ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-CITY])),1,17)<>SUBSTRING(ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-CITY])),1,17)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-STATE]' as FieldName,
x.[MCAL-ORP-MAIL-TO-STATE] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-STATE] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-STATE]))<>ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-STATE]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-ZIP5]' as FieldName,
x.[MCAL-ORP-MAIL-TO-ZIP5] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-ZIP5] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-ZIP5]))<>ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-ZIP5]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-MAIL-TO-ZIP4]' as FieldName,
x.[MCAL-ORP-MAIL-TO-ZIP4] as MMISValue ,
y.[MCAL-ORP-MAIL-TO-ZIP4] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-MAIL-TO-ZIP4]))<>ltrim(rtrim(y.[MCAL-ORP-MAIL-TO-ZIP4]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-PROV-TYPE]' as FieldName,
x.[MCAL-ORP-PROV-TYPE] as MMISValue ,
y.[MCAL-ORP-PROV-TYPE] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-PROV-TYPE]))<>ltrim(rtrim(y.[MCAL-ORP-PROV-TYPE]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ENROL-STAT-CD_1]' as FieldName,
x.[MCAL-ORP-ENROL-STAT-CD_1] as MMISValue ,
y.[MCAL-ORP-ENROL-STAT-CD_1] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ENROL-STAT-CD_1]))<>ltrim(rtrim(y.[MCAL-ORP-ENROL-STAT-CD_1]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-EFF-DT_1]' as FieldName,
x.[MCAL-ORP-STAT-EFF-DT_1] as MMISValue ,
y.[MCAL-ORP-STAT-EFF-DT_1] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-EFF-DT_1] ,101)<>convert(varchar(10),y.[MCAL-ORP-STAT-EFF-DT_1] ,101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-END-DT_1]' as FieldName,
x.[MCAL-ORP-STAT-END-DT_1] as MMISValue ,
y.[MCAL-ORP-STAT-END-DT_1] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-END-DT_1] ,101)<>convert(varchar(10),y.[MCAL-ORP-STAT-END-DT_1] ,101)

UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ENROL-STAT-CD_2]' as FieldName,
x.[MCAL-ORP-ENROL-STAT-CD_2] as MMISValue ,
y.[MCAL-ORP-ENROL-STAT-CD_2] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ENROL-STAT-CD_2]))<>ltrim(rtrim(y.[MCAL-ORP-ENROL-STAT-CD_2]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-EFF-DT_2]' as FieldName,
x.[MCAL-ORP-STAT-EFF-DT_2] as MMISValue ,
y.[MCAL-ORP-STAT-EFF-DT_2] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-EFF-DT_2],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-EFF-DT_2],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-END-DT_2]' as FieldName,
x.[MCAL-ORP-STAT-END-DT_2] as MMISValue ,
y.[MCAL-ORP-STAT-END-DT_2] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-END-DT_2],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-END-DT_2],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ENROL-STAT-CD_3]' as FieldName,
x.[MCAL-ORP-ENROL-STAT-CD_3] as MMISValue ,
y.[MCAL-ORP-ENROL-STAT-CD_3] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ENROL-STAT-CD_3]))<>ltrim(rtrim(y.[MCAL-ORP-ENROL-STAT-CD_3]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-EFF-DT_3]' as FieldName,
x.[MCAL-ORP-STAT-EFF-DT_3] as MMISValue ,
y.[MCAL-ORP-STAT-EFF-DT_3] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-EFF-DT_3],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-EFF-DT_3],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-END-DT_3]' as FieldName,
x.[MCAL-ORP-STAT-END-DT_3] as MMISValue ,
y.[MCAL-ORP-STAT-END-DT_3] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-END-DT_3],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-END-DT_3],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ENROL-STAT-CD_4]' as FieldName,
x.[MCAL-ORP-ENROL-STAT-CD_4] as MMISValue ,
y.[MCAL-ORP-ENROL-STAT-CD_4] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ENROL-STAT-CD_4]))<>ltrim(rtrim(y.[MCAL-ORP-ENROL-STAT-CD_4]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-EFF-DT_4]' as FieldName,
x.[MCAL-ORP-STAT-EFF-DT_4] as MMISValue ,
y.[MCAL-ORP-STAT-EFF-DT_4] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-EFF-DT_4],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-EFF-DT_4],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-END-DT_4]' as FieldName,
x.[MCAL-ORP-STAT-END-DT_4] as MMISValue ,
y.[MCAL-ORP-STAT-END-DT_4] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-END-DT_4],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-END-DT_4],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-ENROL-STAT-CD_5]' as FieldName,
x.[MCAL-ORP-ENROL-STAT-CD_5] as MMISValue ,
y.[MCAL-ORP-ENROL-STAT-CD_5] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-ENROL-STAT-CD_5]))<>ltrim(rtrim(y.[MCAL-ORP-ENROL-STAT-CD_5]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-EFF-DT_5]' as FieldName,
x.[MCAL-ORP-STAT-EFF-DT_5] as MMISValue ,
y.[MCAL-ORP-STAT-EFF-DT_5] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-EFF-DT_5],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-EFF-DT_5],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-STAT-END-DT_5]' as FieldName,
x.[MCAL-ORP-STAT-END-DT_5] as MMISValue ,
y.[MCAL-ORP-STAT-END-DT_5] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-STAT-END-DT_5],101)<>convert(varchar(10),y.[MCAL-ORP-STAT-END-DT_5],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-PROF-LIC-NO]' as FieldName,
x.[MCAL-ORP-PROF-LIC-NO] as MMISValue ,
y.[MCAL-ORP-PROF-LIC-NO] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-PROF-LIC-NO]))<>ltrim(rtrim(y.[MCAL-ORP-PROF-LIC-NO]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-PROF-LIC-EFF-DT]' as FieldName,
x.[MCAL-ORP-PROF-LIC-EFF-DT] as MMISValue ,
y.[MCAL-ORP-PROF-LIC-EFF-DT] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-PROF-LIC-EFF-DT],101)<>convert(varchar(10),y.[MCAL-ORP-PROF-LIC-EFF-DT],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-PROVIS-ENROLL-IND]' as FieldName,
x.[MCAL-ORP-PROVIS-ENROLL-IND] as MMISValue ,
y.[MCAL-ORP-PROVIS-ENROLL-IND] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-PROVIS-ENROLL-IND]))<>ltrim(rtrim(y.[MCAL-ORP-PROVIS-ENROLL-IND]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT]' as FieldName,
x.[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT] as MMISValue ,
y.[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT],101)<>convert(varchar(10),y.[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-RE-ENROMENT-IN]' as FieldName,
x.[MCAL-ORP-RE-ENROMENT-IN] as MMISValue ,
y.[MCAL-ORP-RE-ENROMENT-IN] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-RE-ENROMENT-IN]))<>ltrim(rtrim(y.[MCAL-ORP-RE-ENROMENT-IN]))
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-RE-ENR-EFF-DATE]' as FieldName,
x.[MCAL-ORP-RE-ENR-EFF-DATE] as MMISValue ,
y.[MCAL-ORP-RE-ENR-EFF-DATE] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),x.[MCAL-ORP-RE-ENR-EFF-DATE],101)<>convert(varchar(10),y.[MCAL-ORP-RE-ENR-EFF-DATE],101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-LAST-ACTVT-DT]' as FieldName,
x.[MCAL-ORP-LAST-ACTVT-DT] as MMISValue ,
y.[MCAL-ORP-LAST-ACTVT-DT] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where convert(varchar(10),replace(ltrim(rtrim(x.[MCAL-ORP-LAST-ACTVT-DT])),'',null),101)<>convert(varchar(10),replace(ltrim(rtrim(y.[MCAL-ORP-LAST-ACTVT-DT])),'',null),101)
UNION ALL
select x.[MCAL-ORP-PROV-NO], 
'[MCAL-ORP-LAST-UPDT-USER]' as FieldName,
x.[MCAL-ORP-LAST-UPDT-USER] as MMISValue ,
y.[MCAL-ORP-LAST-UPDT-USER] as PAVEValue
 from dbo.MMIS_ORPDetailFile x
 inner join dbo.PAVE_ORPDetailFile y
 on x.[MCAL-ORP-PROV-NO]=y.[MCAL-ORP-PROV-NO]
where ltrim(rtrim(x.[MCAL-ORP-LAST-UPDT-USER]))<>ltrim(rtrim(y.[MCAL-ORP-LAST-UPDT-USER]))

------------------------------------ORP File Mismatch end---------------------------


------------------------------------NMP File Mismatch start-------------------------

insert into dbo.NMPDetailFileMismatch_Report(NMPProvNumber,FieldName,MMISValue,PaveValueCompared)
select x.NMP_PROV_NO, 'NMP_LEGAL_NAME' as FieldName,x.NMP_LEGAL_NAME as MMISValue ,y.NMP_LEGAL_NAME as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_LEGAL_NAME,1,28)<>SUBSTRING(y.NMP_LEGAL_NAME,1,28)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_LN1' as FieldName,x.NMP_ADDR_LN1 as MMISValue ,y.NMP_ADDR_LN1 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_ADDR_LN1,1,24)<>SUBSTRING(y.NMP_ADDR_LN1,1,24)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_LN2' as FieldName,x.NMP_ADDR_LN2 as MMISValue ,y.NMP_ADDR_LN2 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_ADDR_LN2,1,24)<>SUBSTRING(y.NMP_ADDR_LN2,1,24)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_CITY' as FieldName,
x.NMP_ADDR_CITY as MMISValue ,
y.NMP_ADDR_CITY as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_ADDR_CITY,1,17)<>SUBSTRING(y.NMP_ADDR_CITY,1,17)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_STATE' as FieldName,
x.NMP_ADDR_STATE as MMISValue ,
y.NMP_ADDR_STATE as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ADDR_STATE<>y.NMP_ADDR_STATE
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_ZIP_5' as FieldName,
x.NMP_ADDR_ZIP_5 as MMISValue ,
y.NMP_ADDR_ZIP_5 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ADDR_ZIP_5<>y.NMP_ADDR_ZIP_5
UNION ALL
select x.NMP_PROV_NO, 'NMP_ADDR_ZIP_4' as FieldName,
x.NMP_ADDR_ZIP_4 as MMISValue ,
y.NMP_ADDR_ZIP_4 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ADDR_ZIP_4<>y.NMP_ADDR_ZIP_4
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_LN1' as FieldName,
x.NMP_MAIL_TO_LN1 as MMISValue ,
y.NMP_MAIL_TO_LN1 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_MAIL_TO_LN1,1,24)<>SUBSTRING(y.NMP_MAIL_TO_LN1,1,24)
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_LN2' as FieldName,
x.NMP_MAIL_TO_LN2 as MMISValue ,
y.NMP_MAIL_TO_LN2 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_MAIL_TO_LN2,1,24)<>SUBSTRING(y.NMP_MAIL_TO_LN2,1,24)
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_CITY' as FieldName,
x.NMP_MAIL_TO_CITY as MMISValue ,
y.NMP_MAIL_TO_CITY as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where SUBSTRING(x.NMP_MAIL_TO_CITY,1,17)<>SUBSTRING(y.NMP_MAIL_TO_CITY,1,17)
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_STATE' as FieldName,
x.NMP_MAIL_TO_STATE as MMISValue ,
y.NMP_MAIL_TO_STATE as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_MAIL_TO_STATE<>y.NMP_MAIL_TO_STATE
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_ZIP_5' as FieldName,
x.NMP_MAIL_TO_ZIP_5 as MMISValue ,
y.NMP_MAIL_TO_ZIP_5 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_MAIL_TO_ZIP_5<>y.NMP_MAIL_TO_ZIP_5
UNION ALL
select x.NMP_PROV_NO, 'NMP_MAIL_TO_ZIP_4' as FieldName,
x.NMP_MAIL_TO_ZIP_4 as MMISValue ,
y.NMP_MAIL_TO_ZIP_4 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_MAIL_TO_ZIP_4<>y.NMP_MAIL_TO_ZIP_4
UNION ALL
select x.NMP_PROV_NO, 'DH_NMP_SSN' as FieldName,
x.DH_NMP_SSN as MMISValue ,
y.DH_NMP_SSN as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.DH_NMP_SSN<>y.DH_NMP_SSN
UNION ALL
select x.NMP_PROV_NO, 'NMP_ENROL_STAT_CD_1' as FieldName,
x.NMP_ENROL_STAT_CD_1 as MMISValue ,
y.NMP_ENROL_STAT_CD_1 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ENROL_STAT_CD_1<>y.NMP_ENROL_STAT_CD_1
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_EFF_DT_1' as FieldName,
x.NMP_STAT_EFF_DT_1 as MMISValue ,
y.NMP_STAT_EFF_DT_1 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_EFF_DT_1,101)<>convert(varchar(10),y.NMP_STAT_EFF_DT_1,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_END_DT_1' as FieldName,
x.NMP_STAT_END_DT_1 as MMISValue ,
y.NMP_STAT_END_DT_1 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_END_DT_1,101)<>convert(varchar(10),y.NMP_STAT_END_DT_1,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ENROL_STAT_CD_2' as FieldName,
x.NMP_ENROL_STAT_CD_2 as MMISValue ,
y.NMP_ENROL_STAT_CD_2 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ENROL_STAT_CD_2<>y.NMP_ENROL_STAT_CD_2
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_EFF_DT_2' as FieldName,
x.NMP_STAT_EFF_DT_2 as MMISValue ,
y.NMP_STAT_EFF_DT_2 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_EFF_DT_2,101)<>convert(varchar(10),y.NMP_STAT_EFF_DT_2,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_END_DT_2' as FieldName,
x.NMP_STAT_END_DT_2 as MMISValue ,
y.NMP_STAT_END_DT_2 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_END_DT_2,101)<>convert(varchar(10),y.NMP_STAT_END_DT_2,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ENROL_STAT_CD_3' as FieldName,
x.NMP_ENROL_STAT_CD_3 as MMISValue ,
y.NMP_ENROL_STAT_CD_3 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ENROL_STAT_CD_3<>y.NMP_ENROL_STAT_CD_3
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_EFF_DT_3' as FieldName,
x.NMP_STAT_EFF_DT_3 as MMISValue ,
y.NMP_STAT_EFF_DT_3 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_EFF_DT_3,101)<>convert(varchar(10),y.NMP_STAT_EFF_DT_3,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_END_DT_3' as FieldName,
x.NMP_STAT_END_DT_3 as MMISValue ,
y.NMP_STAT_END_DT_3 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_END_DT_3,101)<>convert(varchar(10),y.NMP_STAT_END_DT_3,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ENROL_STAT_CD_4' as FieldName,
x.NMP_ENROL_STAT_CD_4 as MMISValue ,
y.NMP_ENROL_STAT_CD_4 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ENROL_STAT_CD_4<>y.NMP_ENROL_STAT_CD_4
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_EFF_DT_4' as FieldName,
x.NMP_STAT_EFF_DT_4 as MMISValue ,
y.NMP_STAT_EFF_DT_4 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_EFF_DT_4,101)<>convert(varchar(10),y.NMP_STAT_EFF_DT_4,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_END_DT_4' as FieldName,
x.NMP_STAT_END_DT_4 as MMISValue ,
y.NMP_STAT_END_DT_4 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_END_DT_4,101)<>convert(varchar(10),y.NMP_STAT_END_DT_4,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_ENROL_STAT_CD_5' as FieldName,
x.NMP_ENROL_STAT_CD_5 as MMISValue ,
y.NMP_ENROL_STAT_CD_5 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_ENROL_STAT_CD_5<>y.NMP_ENROL_STAT_CD_5
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_EFF_DT_5' as FieldName,
x.NMP_STAT_EFF_DT_5 as MMISValue ,
y.NMP_STAT_EFF_DT_5 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_EFF_DT_5,101)<>convert(varchar(10),y.NMP_STAT_EFF_DT_5,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_STAT_END_DT_5' as FieldName,
x.NMP_STAT_END_DT_5 as MMISValue ,
y.NMP_STAT_END_DT_5 as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_STAT_END_DT_5,101)<>convert(varchar(10),y.NMP_STAT_END_DT_5,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_RE_ENROMENT_IN' as FieldName,
x.NMP_RE_ENROMENT_IN as MMISValue ,
y.NMP_RE_ENROMENT_IN as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_RE_ENROMENT_IN<>y.NMP_RE_ENROMENT_IN
UNION ALL
select x.NMP_PROV_NO, 'NMP_RE_ENR_EFF_DATE' as FieldName,
x.NMP_RE_ENR_EFF_DATE as MMISValue ,
y.NMP_RE_ENR_EFF_DATE as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_RE_ENR_EFF_DATE,101)<>convert(varchar(10),y.NMP_RE_ENR_EFF_DATE,101)
UNION ALL
select x.NMP_PROV_NO, 'NMP_PROVIS_ENROLL_IND' as FieldName,
x.NMP_PROVIS_ENROLL_IND as MMISValue ,
y.NMP_PROVIS_ENROLL_IND as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.NMP_PROVIS_ENROLL_IND<>y.NMP_PROVIS_ENROLL_IND
UNION ALL
select x.NMP_PROV_NO, 'NMP_PROVIS_ENROLL_EFFEC_DT' as FieldName,
x.NMP_PROVIS_ENROLL_EFFEC_DT as MMISValue ,
y.NMP_PROVIS_ENROLL_EFFEC_DT as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where convert(varchar(10),x.NMP_PROVIS_ENROLL_EFFEC_DT,101)<>convert(varchar(10),y.NMP_PROVIS_ENROLL_EFFEC_DT,101)
UNION ALL
select x.NMP_PROV_NO, '[Column 36]' as FieldName,
x.[Column 36] as MMISValue ,
y.[Column 36] as PAVEValue
 from dbo.MMIS_NMPDetailFile x
 inner join dbo.PAVE_NMPDetailFile y
 on x.NMP_PROV_NO=y.NMP_PROV_NO
where x.[Column 36]<>y.[Column 36]

------------------------------------NMP Detail File Mismatch end---------------------------

------------------------------------NMP Relationship File Mismatch start-------------------------

insert into dbo.NMPRelationshipFileMismatch_Report
(ProvNumber,OwnerNum,ServLocNum,ProvType,NMPProvNumber,FieldName,MMISValue,PaveValueCompared)
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], '[PM-NMP-LICENSE]' as FieldName, x.[PM-NMP-LICENSE] as MMISValue , y.[PM-NMP-LICENSE] as PAVEValue
 from dbo.MMIS_NMPRelationshipFile x
 inner join dbo.PAVE_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
  and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where x.[PM-NMP-LICENSE]<>y.[PM-NMP-LICENSE]
union all 
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], '[PM-NMP-TYPE]' as FieldName, x.[PM-NMP-LICENSE] as MMISValue , y.[PM-NMP-LICENSE] as PAVEValue
 from dbo.MMIS_NMPRelationshipFile x
 inner join dbo.PAVE_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
  and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where x.[PM-NMP-TYPE]<>y.[PM-NMP-TYPE]
union all 
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], '[PM-NMP-EFF-DT]' as FieldName, x.[PM-NMP-LICENSE] as MMISValue , y.[PM-NMP-LICENSE] as PAVEValue
 from dbo.MMIS_NMPRelationshipFile x
 inner join dbo.PAVE_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
  and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where convert(varchar(10),x.[PM-NMP-EFF-DT],101)<>convert(varchar(10),y.[PM-NMP-EFF-DT],101)
union all 
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],x.[PM-NMP-PROV-NUMBER], '[PM-NMP-END-DT]' as FieldName, x.[PM-NMP-LICENSE] as MMISValue , y.[PM-NMP-LICENSE] as PAVEValue
 from dbo.MMIS_NMPRelationshipFile x
 inner join dbo.PAVE_NMPRelationshipFile y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
  and x.[PM-NMP-PROV-NUMBER]=y.[PM-NMP-PROV-NUMBER]
where convert(varchar(10),x.[PM-NMP-END-DT],101)<>convert(varchar(10),y.[PM-NMP-END-DT],101)
------------------------------------NMP Relationship File Mismatch end-------------------------


------------------------------------ dbo.MOCADetailFileMismatch_Report start -------------------------
insert into dbo.MOCADetailFileMismatch_Report
(MOCASSN,MOCATIN,FieldName,MMISValue,PaveValueCompared)
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'DH_MOCAL_NPI' as FieldName, x.DH_MOCAL_NPI as MMISValue , y.DH_MOCAL_NPI as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where x.DH_MOCAL_NPI<>y.DH_MOCAL_NPI
union all
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'DH_MOCA_LEGAL_NAME' as FieldName, x.DH_MOCA_LEGAL_NAME as MMISValue , y.DH_MOCA_LEGAL_NAME as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where SUBSTRING(x.DH_MOCA_LEGAL_NAME,1,28)<>SUBSTRING(y.DH_MOCA_LEGAL_NAME,1,28)
union all
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'DH_MOCA_EFF_DT' as FieldName, x.DH_MOCA_EFF_DT as MMISValue , y.DH_MOCA_EFF_DT as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where  convert(varchar(10),x.DH_MOCA_EFF_DT,101)<> convert(varchar(10),y.DH_MOCA_EFF_DT,101)
union all
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'DH_MOCA_END_DT' as FieldName, x.DH_MOCA_END_DT as MMISValue , y.DH_MOCA_END_DT as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where  convert(varchar(10),x.DH_MOCA_END_DT,101)<> convert(varchar(10),y.DH_MOCA_END_DT,101)
union all
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'DH_MOCA_DOB' as FieldName, x.DH_MOCA_DOB as MMISValue , y.DH_MOCA_DOB as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where convert(varchar(10),x.DH_MOCA_DOB,101)<>convert(varchar(10),y.DH_MOCA_DOB,101)
union all
select x.DH_MOCA_SSN,x.DH_MOCA_TIN,'Column 7' as FieldName, x.[Column 7] as MMISValue , y.[Column 7] as PAVEValue
 from dbo.MMIS_MOCADetailFile x
 inner join dbo.PAVE_MOCADetailFile y
 on x.DH_MOCA_SSN=y.DH_MOCA_SSN
 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where x.[Column 7]<>y.[Column 7]
------------------------------------ dbo.MOCADetailFileMismatch_Report start -------------------------

------------------------------------ dbo.MOCARelationshipsFileMismatch_Report start -------------------------
insert into dbo.MOCARelationshipsFileMismatch_Report
(ProvNumber,OwnerNum,ServLocNum,ProvType,MOCASSN,MOCATIN,FieldName,MMISValue,PaveValueCompared)
select x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE,
x.DH_MOCA_BILL_SSN,x.DH_MOCA_BILL_TIN, 'DH_MOCA_BILL_EFF_DT' as FieldName, x.DH_MOCA_BILL_EFF_DT as MMISValue , y.DH_MOCA_BILL_EFF_DT as PAVEValue
 from dbo.MMIS_MOCARelationShipFile x
 inner join dbo.PAVE_MOCARelationShipFile y
 on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
 and x.DH_MOCA_BILL_OWNER=y.DH_MOCA_BILL_OWNER
 and x.DH_MOCA_BILL_LOCATION=y.DH_MOCA_BILL_LOCATION
 and x.DH_MOCA_BILL_PROV_TYPE=y.DH_MOCA_BILL_PROV_TYPE
  and x.DH_MOCA_BILL_SSN=y.DH_MOCA_BILL_SSN
  and x.DH_MOCA_BILL_TIN = y.DH_MOCA_BILL_TIN
where convert(varchar(10),x.DH_MOCA_BILL_EFF_DT,101)<>convert(varchar(10),y.DH_MOCA_BILL_EFF_DT,101)
union all
select x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE,
x.DH_MOCA_BILL_SSN,x.DH_MOCA_BILL_TIN, 'DH_MOCA_BILL_END_DT' as FieldName, x.DH_MOCA_BILL_END_DT as MMISValue , y.DH_MOCA_BILL_END_DT as PAVEValue
 from dbo.MMIS_MOCARelationShipFile x
 inner join dbo.PAVE_MOCARelationShipFile y
 on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
 and x.DH_MOCA_BILL_OWNER=y.DH_MOCA_BILL_OWNER
 and x.DH_MOCA_BILL_LOCATION=y.DH_MOCA_BILL_LOCATION
 and x.DH_MOCA_BILL_PROV_TYPE=y.DH_MOCA_BILL_PROV_TYPE
  and x.DH_MOCA_BILL_SSN=y.DH_MOCA_BILL_SSN
  and x.DH_MOCA_BILL_TIN = y.DH_MOCA_BILL_TIN
where convert(varchar(10),x.DH_MOCA_BILL_END_DT,101)<>convert(varchar(10),y.DH_MOCA_BILL_END_DT,101)
union all
select x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE,
x.DH_MOCA_BILL_SSN,x.DH_MOCA_BILL_TIN, 'Column 8' as FieldName, x.[Column 8] as MMISValue , y.[Column 8] as PAVEValue
 from dbo.MMIS_MOCARelationShipFile x
 inner join dbo.PAVE_MOCARelationShipFile y
 on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
 and x.DH_MOCA_BILL_OWNER=y.DH_MOCA_BILL_OWNER
 and x.DH_MOCA_BILL_LOCATION=y.DH_MOCA_BILL_LOCATION
 and x.DH_MOCA_BILL_PROV_TYPE=y.DH_MOCA_BILL_PROV_TYPE
  and x.DH_MOCA_BILL_SSN=y.DH_MOCA_BILL_SSN
  and x.DH_MOCA_BILL_TIN = y.DH_MOCA_BILL_TIN
where x.[Column 8]<>y.[Column 8]
------------------------------------ dbo.MOCARelationshipsFileMismatch_Report end -------------------------

------------------------------------ dbo.GRRelationshipFileMismatch_Report start -------------------------

insert into dbo.GRRelationshipFileMismatch_Report
(ProvNumber,OwnerNum,ServLocNum,ProvType,RenderingProvNumber,FieldName,MISValue,PaveValueCompared)
select x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP],
x.[PM-PROV-NOS-IN-GRP], '[PM-PROV-NOS-IN-GRP]' as FieldName, x.[PM-PROV-NOS-IN-GRP] as MMISValue , y.[PM-PROV-NOS-IN-GRP] as PAVEValue
 from dbo.MMIS_GroupProvider x
 inner join dbo.PAVE_GroupProvider y
 on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
 and  x.[PM-PROV-NOS-IN-GRP]=y.[PM-PROV-NOS-IN-GRP]

END


GO

