/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMAppOwner]
(@PartyID int
 ,@ApplicationID int
 ,@FromDate smalldatetime = NULL
 ,@ThroughDate smalldatetime =NULL
 ,@Ownership int = NULL
 ,@Type int=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int =NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@UPIN varchar(6)=NULL
)
as begin 

INSERT INTO [KYP].[ADM_App_Owner]
           ([PartyID]
           ,[ApplicationID]
           ,[FromDate]
           ,[ThroughDate]
           ,[Ownership]
           ,[Type]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[UPIN])
     VALUES
           (@PartyID
           ,@ApplicationID
           ,@FromDate
           ,@ThroughDate
           ,@Ownership
           ,@Type
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@UPIN)

	return IDENT_CURRENT('[KYP].[ADM_App_Owner]')

end


GO

