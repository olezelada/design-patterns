


CREATE VIEW [KYP].[Alerts]
AS
SELECT 
	 A.AlertNo AS 'Alert Number'
	,A.Priority AS Relevance
	,A.WatchedPartyName AS 'Party Name'
	,A.NPI
	,A.TAXID AS 'Tax ID'
	,A.WatchlistName AS 'Watchlist/Category' 
	,A.AlertStatus AS 'Alert Status'
FROM KYP.MDM_Alert AS A


GO

