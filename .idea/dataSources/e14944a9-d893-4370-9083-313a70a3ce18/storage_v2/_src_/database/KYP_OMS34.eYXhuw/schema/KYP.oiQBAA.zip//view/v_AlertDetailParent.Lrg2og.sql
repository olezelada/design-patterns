


CREATE VIEW [KYP].[v_AlertDetailParent]
AS
SELECT     
	row_number() OVER (ORDER BY A.AlertID ASC) AS ID, 
	A.AlertID, 
	A.WatchedPartyType, 
	A.WatchlistName AS 'Parent_WLName', 
	A.AlertNo AS 'ParentAlertno', 
	A.MatchPercent AS 'ParentMatchPercentage', 
	A.IsMerged AS 'ParentMerged',
    A.MatchStatusIndicatorDesc AS 'ParentMatchStatus', 
    C.Name AS 'ProvParty_Name', 
    CASE 
		WHEN C.Type = 'Person' 
			THEN D .Alias1 
		WHEN C.Type = 'Organization' 
			THEN E.LegalName 
	END AS 'ProvParty_Alias',
	
    CASE 
		WHEN C.Type = 'Organization' 
			THEN 
				CASE 
					WHEN E.TIN IS NOT NULL 
						THEN E.TIN 
					WHEN E.TIN IS NULL 
						THEN
					/* GET TaxID from HMS if NULL*/ 
					(SELECT DISTINCT STUFF(
						(SELECT ',' + (Taxid) FROM
							(SELECT DISTINCT TaxID, PartyID FROM KYP.MDM_PartyDetail) A
							 WHERE PartyID = C.PartyID FOR XML PATH('')
						),1,1,'') AS Numbers
					FROM KYP.MDM_PartyDetail
					WHERE db_Flag = 'HMS'
					) 
					
					/* GET TaxID from HMS if NULL*/ 
				END 
	END AS 'ProvParty_TaxID', 
                      
    CASE 
		WHEN C.Type = 'Organization' 
			THEN 
				CASE 
					WHEN E.TIN IS NULL THEN 
						CASE 
							WHEN (SELECT COUNT(DISTINCT (TaxID)) FROM KYP.MDM_PartyDetail
								  WHERE PartyID = C.PartyID 
								  AND db_Flag = 'HMS') > 0 THEN 'HMS' 
							ELSE NULL 
						END 
				END 
	END AS 'ProvParty_TIN_Source', 
                      
    CASE 
		WHEN C.Type = 'Person' 
			THEN D .SSN 
	END AS 'ProvParty_SSN', 
	
	D.DoB AS 'ProvParty_DOB',
	
	/*START: Getting Multiple NPI */ 
	(SELECT DISTINCT STUFF(
		(SELECT ',' + CONVERT(VARCHAR(50), NPI) FROM 
		        (SELECT DISTINCT NPI, PartyID FROM KYP.MDM_PartyDetail) A
		         WHERE PartyID = C.PartyID 
		         FOR XML PATH('')), 1, 1, '') AS Numbers
         FROM KYP.MDM_PartyDetail) AS 'ProvParty_NPI', 
     /*END: Getting Multiple NPI */ 
     
     F.UPIN,
     
     /*START: Getting Multiple Speciality*/ 
     (SELECT DISTINCT STUFF(
		(SELECT ',' + Speciality FROM
			(SELECT 
				DISTINCT 
					Speciality, 
					PartyID
			 FROM KYP.MDM_PartyDetail WHERE Speciality NOT IN ('Unknown', 'unknown')) A
			 WHERE PartyID = C.PartyID 
			 FOR XML PATH('')), 1, 1, '') AS Numbers
      FROM KYP.MDM_PartyDetail) AS 'ProvParty_Speciality',
      
      /*START: Getting Multiple Licenses*/ 
      (SELECT DISTINCT STUFF(
		(SELECT ',' + License FROM
			(SELECT DISTINCT License, PartyID 
			 FROM KYP.MDM_PartyDetail) A
			 WHERE PartyID = C.PartyID 
			 FOR XML PATH('')), 1, 1, '') AS Numbers
			 FROM KYP.MDM_PartyDetail
			 ) AS 'ProvParty_Licenses', 
		/*END: Getting Multiple Licenses*/ 
		
		A.WatchlistName,                       
		
		/*ADDED FOR Matched Party from Watchlist*/ 
		
		/*START - Fix for http://jira/browse/KYP-3308 */
		COALESCE(G.LName + ' ' + G.FName + ' ' + ISNULL(G.MName,' '),G.OrganizationName) AS 'MatchParty_Name',
		--CASE         
		--	WHEN A.WatchedPartyType = 'Individual' 
		--		THEN G.LName + ' ' + G.FName + ' ' + G.MName 
		--	ELSE G.OrganizationName 
		--END AS 'MatchParty_Name',
		/*END - Fix for http://jira/browse/KYP-3308 */
		
        G.AliasName AS 'MatchParty_Alias', 
        G.TAXID AS 'MatchParty_TaxID', 
        G.SSN AS 'MatchParty_SSN', 
        G.DOB AS 'MatchParty_DOB', 
        G.NPI AS 'MatchParty_NPI', 
        G.UPIN AS 'MatchParty_UPIN', 
        G.Speciality AS 'MatchParty_Specialty', 
        G.LicenseNo AS 'MatchParty_License',
        A.Priority

FROM KYP.MDM_Alert A 
		INNER JOIN KYP.PDM_Party C ON C.PartyID = A.WatchedPartyID 
		LEFT OUTER JOIN KYP.PDM_Person D ON D .PartyID = C.PartyID 
		LEFT OUTER JOIN KYP.PDM_Organization E ON E.PartyID = C.PartyID 
		LEFT OUTER JOIN KYP.PDM_Provider F ON F.PartyID = C.PartyID 
		LEFT OUTER JOIN KYP.MDM_AlertDetail G ON G.AlertID = A.AlertID		
WHERE A.IsMerged = 'N' 
AND A.IsDeleted <> 1


GO

