


-- =============================================
-- Author:		Ashok Chelimilla
-- Create date: 07/11/2014
--Modified on:28/11/2104
-- Description: Added to create finding type level composite risk score details in  SDM_CompositeRiskScoreDet table
-- =============================================
CREATE PROCEDURE [KYP].[p_insertCompositeRiskDetails]
	-- Add the parameters for the stored procedure here
	(@ScreeningID int
	,@ApplicationID int=null
	,@Auto varchar(4)=null)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	delete from kyp.SDM_CompositeRiskScoreDet where ScreeningID = @ScreeningID;
	
select RiskFactor,RiskScore,ScreeningID,ApplicationID, Auto ,IsModified,0 as EDDScore, RiskScore as autoscore, RiskScore as compositescore
into #tmpAutoRiskScore
from kyp.SDM_RiskScore where Auto='Auto' and ScreeningID=@ScreeningID 

select distinct y.RiskFactor,y.RiskScore,y.ScreeningID,y.ApplicationID, y.Auto
into #tmpEDDRiskScore  
from kyp.SDM_RiskScore y
where y.ScreeningID=@ScreeningID and y.Auto='EDD' and coalesce(isdeleted,0)=0

insert into #tmpAutoRiskScore
select y.RiskFactor,null,y.ScreeningID,y.ApplicationID, y.Auto,null as modified ,y.RiskScore as EDDScore, 0 as autoscore, y.RiskScore as compositescore
from #tmpAutoRiskScore x
right join #tmpEDDRiskScore y
on x.RiskFactor = y.RiskFactor
where x.RiskFactor is null

update  x 
set x.EDDScore= (y.RiskScore - x.RiskScore)
   ,x.compositescore = (X.RiskScore+ (y.RiskScore - x.RiskScore))
 from #tmpAutoRiskScore x
right join #tmpEDDRiskScore y
on x.RiskFactor = y.RiskFactor
where x.ismodified=1

insert into kyp.SDM_CompositeRiskScoreDet
select applicationID,ScreeningID,riskFactor,autoscore,compositescore,EDDScore from #tmpAutoRiskScore

drop table #tmpAutoRiskScore
drop table #tmpEDDRiskScore

if(@Auto='EDD')
	begin
	declare @PartyAutoScoreSum int
	,@PartyEDDScoreSum int
	,@PartyComScoreSum int
	,@PartyNormScoreSum int
	,@AppAutoScoreSum int
	,@AppEDDScoreSum int
	,@AppComScoreSum int
	,@AppNormScoreSum int
	,@CaseID int

	select @PartyAutoScoreSum=SUM(AutoRiskScore),@PartyEDDScoreSum=SUM(EDDRiskScore),@PartyComScoreSum=SUM(CompositeRiskScore) from kyp.SDM_CompositeRiskScoreDet where applicationID= @ApplicationID and ScreeningID =@ScreeningID
	set @PartyNormScoreSum = round((1000*(1-exp(-0.0009*@PartyComScoreSum))),0)
	UPDATE KYP.SDM_ApplicationParty set AutoRisk=@PartyAutoScoreSum, EDDRisk=@PartyEDDScoreSum, CompositeRisk=@PartyComScoreSum, NormalizedRisk=@PartyNormScoreSum where applicationID= @ApplicationID and ScreeningID =@ScreeningID


	select @AppAutoScoreSum=SUM(AutoRisk),@AppEDDScoreSum=SUM(EDDRisk),@AppComScoreSum=SUM(CompositeRisk) from KYP.SDM_ApplicationParty where applicationID= @ApplicationID
	set @AppNormScoreSum = round((1000*(1-exp(-0.0009*@AppComScoreSum))),0)
	UPDATE kyp.ADM_Application set AutoRisk=@AppAutoScoreSum, EDDRisk=@AppEDDScoreSum, CompositeRisk=@AppComScoreSum, NormalizedRisk=@AppNormScoreSum where applicationID= @ApplicationID 
	SELECT @CaseID = CaseID FROM KYP.ADM_Application where ApplicationID = @ApplicationID;
	UPDATE KYP.ADM_Case SET CompositeRisk = @AppNormScoreSum where CaseID = @CaseID ;
	
	END
END


GO

