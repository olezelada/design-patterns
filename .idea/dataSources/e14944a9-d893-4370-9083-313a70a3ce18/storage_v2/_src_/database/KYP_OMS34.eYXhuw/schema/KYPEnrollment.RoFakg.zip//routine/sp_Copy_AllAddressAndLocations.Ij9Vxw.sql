
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <08/09/2017>
-- Description:	<Copy ALL the addresses and Locations from Portal to Enrollment from a PartyID on Enrollment>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_AllAddressAndLocations]
	@mod_party_id int,
	@last_Action_User_ID varchar(100)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @addresses table (pk int identity(1,1),AddressID int)
declare @tot int
declare @cont int
,@add int,@new_add int,@loc int


		--BEGIN TRANSACTION 
		--BEGIN TRY

IF EXISTS (SELECT DISTINCT AddressID from [KYPPORTAL].[PortalKYP].[pPDM_location] where PartyID=@mod_party_id)
BEGIN

		INSERT INTO @addresses (AddressID)
		SELECT DISTINCT AddressID from [KYPPORTAL].[PortalKYP].[pPDM_location] where PartyID=@mod_party_id --87 as example
		select @tot =MAX(pk) from @addresses 
		set @cont=1;



		WHILE @cont<=@tot
		begin
	
		select @add = AddressID from [KYPPORTAL].[PortalKYP].[pPDM_Address] where AddressID=(select AddressID from @addresses where pk=@cont);
		EXEC @new_add = [KYPEnrollment].[sp_Copy_Address] 	@mod_party_id,	@add,	null,	@last_Action_User_ID;
	
		select @loc = LocationID from [KYPPORTAL].[PortalKYP].[pPDM_Location] where PartyID=@mod_party_id and AddressID=(select AddressID from @addresses where pk=@cont);
		EXEC [KYPEnrollment].[p_Copy_Location]	@loc,	@new_add,	@mod_party_id,	null,	null,	@last_Action_User_ID;

		set @cont= @cont + 1
		end



END
		/*COMMIT TRANSACTION
		END TRY
		
		BEGIN CATCH
			IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION 
			DECLARE @error_message NVARCHAR (4000), @error_severity INT;
			SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY();
			RAISERROR (@error_message, @error_severity, 1);
		END CATCH*/

END


GO

