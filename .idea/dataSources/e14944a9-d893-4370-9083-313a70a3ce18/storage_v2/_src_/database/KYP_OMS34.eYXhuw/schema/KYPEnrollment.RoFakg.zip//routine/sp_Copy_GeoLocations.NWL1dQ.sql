-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <16/10/2017>
-- Description:	<Thsi procedure copy all the addres related to locations type ServAddrBusinesLic and ServAddrGeoLocationBl>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_GeoLocations]
	@new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT, 
	@last_Action_User_ID VARCHAR(100)
	
AS
BEGIN

	SET NOCOUNT ON;
declare @temp table (pk int identity(1,1),PartyID int,LocationID int,AddressID int)
declare @tot int
declare @cont int,@sub_party int
,@add_party int,@add_location int,@add_address int, @loc int,@new_sub_party int,@new_address int,@remarks varchar(250)


	
	IF exists (select * from KYPPORTAL.PortalKYP.pPDM_Party where ParentPartyID=@party_Id and (Type='ServAddrGeoLocation'))
	BEGIN
	
	
		
		INSERT INTO @temp (PartyID,LocationID,AddressID)
		SELECT  p.PartyID,l.LocationID,a.AddressID from [KYPPORTAL].[PortalKYP].[pPDM_party] p INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_location] l ON p.PartyID=l.PartyID INNER JOIN [KYPPORTAL].[PortalKYP].pPDM_Address a ON l.AddressID=a.AddressID  where p.ParentPartyID=@party_Id and (p.Type='ServAddrBusinesLic' or p.Type='ServAddrGeoLocation') and p.IsDeleted=0 and l.IsDeleted=0 and a.IsDeleted=0
		
		select @tot =MAX(pk) from @temp 
		set @cont=1;

		WHILE @cont<=@tot
		begin
			
			select @add_party=t.PartyID, @add_location=t.LocationID, @add_address = t.AddressID  from @temp t where t.pk=@cont
			EXEC @new_sub_party = [KYPEnrollment].[sp_Copy_Party] 	@add_party,	@new_Party_Id,	@new_Account_Id,	@last_action_user_id;
			EXEC @new_address = [KYPEnrollment].[sp_Copy_Address] 	@new_sub_party,	@add_party,	null,	@last_Action_User_ID;

			EXEC [KYPEnrollment].[sp_Copy_Number]	@new_sub_party,	@add_party,	@last_Action_User_ID,'';

			
		
			set @cont= @cont + 1
			
		end
	
	END	
		
END


GO

