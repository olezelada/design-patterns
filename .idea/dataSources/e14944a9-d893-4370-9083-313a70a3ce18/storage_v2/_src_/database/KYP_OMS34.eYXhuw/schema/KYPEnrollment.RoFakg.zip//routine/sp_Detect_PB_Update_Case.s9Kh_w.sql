-- =============================================
-- Author:		<Lacunza Giresse>
-- Create date: <12/19/2017>
-- Description:	<Create a new account when a new business place is added in an update of account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Detect_PB_Update_Case]
@account_id int,
@application_no varchar(10),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@composite_risk INT,
@case_id INT,
@risk VARCHAR(15),
@application_type VARCHAR(35),
@main_app_number varchar(10)

AS
BEGIN

DECLARE @app_party int,@npi varchar(10),@ptc varchar(10),@account_num varchar(20),@max_acc_num int,
@new_account int,@new_address int,@new_party_acc int,@dateCreated date,@new_person_id int,@npi_Type varchar(15),@applicationId int,
@accountType varchar(10),@package varchar(20)
,@acc_aux int,@account_internal_use_id int,@LastActionComments varchar(200)
,@application_partyId int
, @acc_package_Name VARCHAR(30);

DECLARE @new_pb table (pk int identity(1,1),address_id int,location_id int, providerTypeCode VARCHAR(50), acc_packageName VARCHAR (30), twoDigits varchar(3) )
declare @tot int,@cont int,@add int,@add_loc int,@name varchar(100)

select @applicationId = ApplicationID, @application_partyId=PartyID from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@application_no
select @app_party = PartyID,@npi = NPI,@ptc = ProviderTypeCode, @package = PackagesName from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@application_no and IsDeleted=0

SET @dateCreated = GETDATE()

print @npi
print @package

-----------------------------------------------------for coutinue sequence
declare @maxSLN int
select @maxSLN = MAX(ServiceLocationNo) from KYPEnrollment.pADM_Account acc where npi = 
(select NPI from KYPEnrollment.pADM_Account a where AccountID=@account_id)
-----------------------------------------------------

INSERT INTO @new_pb (address_id,location_id, providerTypeCode, acc_packageName, twoDigits)
select ad.AddressID,l.LocationID, l.ProviderTypeCode, l.Remarks, ProvCrossReferenceCode from KYPPORTAL.PortalKYP.pADM_Application ap inner join
				KYPPORTAL.PortalKYP.pPDM_Party p on ap.PartyID=p.ParentPartyID
				inner join KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pb on p.ParentPartyID =pb.PartyId
				inner join KYPPORTAL.PortalKYP.pPDM_Location l on l.PartyID=p.PartyID
				inner join KYPPORTAL.PortalKYP.pPDM_Address ad on l.AddressID=ad.AddressID	
-----------------------------------------------------KEN-19915
                inner join KYP.PDM_AdditionalParties B on B.LocationNo=l.locationid
				INNER JOIN KYPEnrollment.EDM_SupplementalInternalUse A on A.LocationNo= B.ID
-----------------------------------------------------
				where ap.NPI=@npi and ap.IsDeleted=0 and p.IsDeleted=0 and pb.IsDeleted=0 and l.IsDeleted=0 and ad.IsDeleted=0
				and l.Approved=1
				and p.Type in ('FacilityBusiness Address') and p.ParentPartyID =@application_partyId
				and NOT exists (select * from KYPEnrollment.pADM_Account ac inner join 
				KYPEnrollment.pAccount_PDM_Location l_ac on l_ac.PartyID=ac.PartyID inner join
				KYPEnrollment.pAccount_PDM_Address a_ac on l_ac.AddressID=a_ac.AddressID
				where a_ac.AddressType='Servicing' and a_ac.CurrentRecordFlag=1 and l_ac.IsDeleted=0 and ac.IsDeleted=0 and l_ac.Approved=1
				and a_ac.AddressLine1=ad.AddressLine1 and a_ac.AddressLine2=ad.AddressLine2 and a_ac.ZipPlus4=ad.ZipPlus4 and a_ac.State=ad.State and a_ac.City=ad.City and ac.NPI=@npi and ac.PackageName=@package)
-----------------------------------------------------
				ORDER BY ProvCrossReferenceCode
-----------------------------------------------------

select * from @new_pb


select @tot = MAX(pk) from @new_pb
print @tot

SET @cont =1

BEGIN TRY

WHILE @cont <= @tot
	begin

	print 'inside while FBP'

    select @add = address_id
        , @add_loc = location_id
        , @ptc = ProviderTypeCode
        , @acc_package_Name = acc_packageName
         from @new_pb where pk=@cont
    DECLARE @fbpIndex VARCHAR(3)

    select @fbpIndex = 
-----------------------------------------------------    
    case when cast(pk as INT)<10 then '0' + cast(cast(pk as INT) as varchar) else cast(cast(pk as INT) as varchar) end  
-----------------------------------------------------    
    from @new_pb where location_id = @add_loc

    IF (@fbpIndex IS NULL OR '' = @fbpIndex)
      BEGIN
        SET @fbpIndex = '0' + cast((@cont + 1) as VARCHAR)
      END

    /*IF (LEN(@fbpIndex) > 2)
    BEGIN
      SET @account_num = cast(('1' + @fbpIndex + '00000') AS INT) + @case_id
    END
    ELSE
    BEGIN*/
      SET @account_num = cast(('1' + @fbpIndex + '000000') AS BIGINT) + @case_id
    --END

    SELECT @fbpIndex =''

		print 'New Account: ' + @account_num

	    EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no,
													 @last_Action_User_ID, @priority, @risk,
													 @composite_risk,
													 @case_id,
													 @application_type,
													 @ptc,
													 @account_num
		
		SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @account_num
            , @applicationId
            , @application_no
            , @application_type)
            
	
    	SET @new_account = IDENT_CURRENT('KYPEnrollment.pADM_Account')
    	--SET @new_account = SCOPE_IDENTITY ();
    	select @new_party_acc = PartyID, @npi_Type = NPIType,@accountType = AccountType from KYPEnrollment.pADM_Account where AccountID=@new_account and IsDeleted=0
    	----------------------
    	and ProvLocTypeCd='F'
    	----------------------
    	
		EXEC [KYPEnrollment].[sp_delete_Service_Address] @new_account
		
	INSERT INTO KYPEnrollment.pAccount_PDM_Address 
	(AddressType,
	 AddressLine1,
	 AddressLine2,
	 County,
	 City,
	 Zip,
	 ZipPlus4,
	 State,
	 Country,
	 Latitude,
	 Longitude,
	 GeographicArea,
	 LastAction,
	 LastActionUserID,
	 CurrentRecordFlag,
	 AdaAccessible,
	 TtyCapacity,
	 TtyNumber,
	 Explanation
	)
	
	 select 
	 'Servicing',
	 AddressLine1,
	 AddressLine2,
	 County,
	 City,
	 Zip,
	 ZipPlus4,
	 State,
	 Country,
	 Latitude,
	 Longitude,
	 GeographicArea,
	 'C',
	 @last_action_user_id,
	 1,
	 AdaAccessible,
	 TtyCapacity,
	 TtyNumber,
	 Explanation
	 from KYPPORTAL.PortalKYP.pPDM_Address where AddressID=@add and IsDeleted=0
	 
	 SET	@new_address = SCOPE_IDENTITY ();	
	
	 INSERT INTO KYPEnrollment.pAccount_PDM_Location
	 (AddressID,
	  PartyID,
	  ProviderID,
	  PersonID,
	  Type,
	  WorkingDays,
	  WorkingHours,
	  Phone1,
	  Phone2,
	  Fax,
	  Remarks,
	  CreatedBy,
	  DateCreated,
	  ModifiedBy,
	  DateModified,
	  DeletedBy,
	  InActive,
	  IsDeleted,
	  Email,
	  IsLicensed,
	  IsRented,
	  Status,
	  Name,
	  LastAction,
	  LastActionDate,
	  LastActorUserID,
	  LastActionReason,
	  LastActionComments,
	  LastActionApprovedBy,
	  CurrentRecordFlag,
	  IsSchoolSide,
	  IsDonatedSpace,
	  EffectiveDate,
	  Approved,
	  ProviderType,
	  ProviderTypeCode
	  ) 
	  
	 select 
	  @new_address,
	  @new_party_acc,
	  null,
	  null,
	  'Servicing',
	  WorkingDays,
	  WorkingHours,
	  Phone1,
	  Phone2,
	  Fax,
	  Remarks,
	  CreatedBy,
	  @dateCreated,
	  null,
	  null,
	  null,
	  InActive,
	  0,
	  Email,
	  IsLicensed,
	  IsRented,
	  Status,
	  Name,
	  'C',
	  @dateCreated,
	  @last_action_user_id,
	  null,
	  null,
	  null,
	  1,
	  IsSchoolSide,
	  IsDonatedSpace,
	  EffectiveDate,
	  Approved,
	  ProviderType,
	  ProviderTypeCode
	  
	  from KYPPORTAL.PortalKYP.pPDM_Location where LocationID=@add_loc and IsDeleted=0 and Approved=1 and TYPE='FacilityBusiness Address'
	  
	  ---------------------------------------------------------------------------
	  IF (@npi_Type='Individual')
	  select  @new_person_id = PersonID from KYPEnrollment.pAccount_PDM_Person where PartyID=@new_party_acc  AND CurrentRecordFlag=1 and Deleted=0
	  ELSE
	  begin
	  IF (@npi_Type='Organization')
	  select  @new_person_id = OrgID from KYPEnrollment.pAccount_PDM_Organization where PartyID=@new_party_acc  AND CurrentRecordFlag=1 and IsDeleted=0	  	  
	  end
	  ---------------------------------------------------------------------------
	  
	  select @name = LegalName from KYPEnrollment.pADM_Account where AccountID=@account_id
	  
	  EXEC [KYPEnrollment].[FBP_Legal_Name_Address] @new_account, @new_person_id, @new_address, @npi_Type, @last_Action_User_ID,@npi, @new_party_acc, 
	  @app_party, 1, @ptc, @account_num, NULL,@accountType,@applicationId,1,@application_type,@name;
	  
	  EXEC [KYPEnrollment].sp_Update_LocationNumber @npi, @applicationId, @new_account
           
	  IF exists (select AccountID from KYPEnrollment.pADM_Account where loc_FBP is null and AccountID=@new_account)
	  BEGIN
	     update KYPEnrollment.pADM_Account set loc_FBP=@add_loc where AccountID=@new_account
	  END 
	  
	  IF exists(select AccountID from KYPEnrollment.pADM_Account a where AccountID=@account_id and a.FacilityName is null)
	  BEGIN
		declare @legal_name varchar(100)
		set @legal_name = (select top 1 LegalName from KYPEnrollment.pADM_Account a where AccountID = @account_id and a.FacilityName is null)
		update KYPEnrollment.pADM_Account set FacilityName = @legal_name where AccountID=@account_id and FacilityName is null
	  END
	  
  	UPDATE a
	  SET a.ServiceLocationNo = n.twoDigits
	      , a.PackageName =  n.acc_packageName
	  from KYPEnrollment.pADM_Account a inner join @new_pb n on a.loc_FBP=n.location_id
	  where a.AccountNumber=@account_num and IsDeleted=0	  
	  
   	  SET @cont = @cont +1
	end				

	
END TRY

BEGIN CATCH
    
	DECLARE    @error_message NVARCHAR(4000),@error_severity INT;
	SELECT     @error_message = ERROR_MESSAGE()
		      ,@error_severity = ERROR_SEVERITY();
	RAISERROR (@error_message
              ,@error_severity
              ,1);
              
	EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @applicationId 
    
END CATCH

END

GO

