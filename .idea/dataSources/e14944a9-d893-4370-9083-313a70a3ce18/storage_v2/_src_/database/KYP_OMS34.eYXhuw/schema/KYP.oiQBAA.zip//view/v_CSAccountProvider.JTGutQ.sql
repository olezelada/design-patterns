


CREATE VIEW [KYP].[v_CSAccountProvider] AS
Select CONVERT(VARCHAR,C.CaseID) As CaseID,
	CONVERT(VARCHAR,A.AccountID) As AccountID, 
	--CONVERT(VARCHAR,P.StatusAcc) AS EnrollmentStatus,
	CONVERT(VARCHAR,P.StatusAcc) AS EnrollmentStatus,
	CONVERT(VARCHAR,A.EnrolledOn,101) As EnrolledOn,
	CONVERT(VARCHAR,A.StatusDate,101) AS StatusDate,
	CONVERT(VARCHAR,A.RiskScore) As RiskScore,
	CONVERT(VARCHAR,A.AccountNumber) AS AccountNumber,
	A.AccountName,
	A.CategoryOfService ,
	CONVERT(VARCHAR,A.NPI) As NPI,
	A.ProviderType,
	P.AccountTypeDescriptor,
	
	LTRIM(RTRIM(
	STUFF (( SELECT ', ' + ISNULL(CONVERT(VARCHAR,ISNULL(J.License,'')),'-') AS [text()]
   FROM KYPEnrollment.PortalLicense J
   WHERE J.EnrolCaseID = C.CaseID
   FOR XML PATH('')),1,1,''))) AS License,
   
   LTRIM(RTRIM(
	STUFF (( SELECT ', ' + ISNULL(CONVERT(VARCHAR,ISNULL(S.SpecialtyCode,'') + ' - ' + ISNULL(S.SpecialtyDesc,'')),'-') AS [text()]
   FROM KYPEnrollment.PDMSpecialty S
   WHERE S.EnrolCaseID = C.CaseID
   FOR XML PATH('')),1,1,''))) AS Specialty,
   
   LTRIM(RTRIM(
	STUFF (( SELECT ', ' + ISNULL(CONVERT(VARCHAR,ISNULL(S.TaxonomyCode,'') + ' - ' + ISNULL(S.TaxonomyDesc,'')),'-') AS [text()]
   FROM KYPEnrollment.PDMTaxonomy S
   WHERE S.EnrolCaseID = C.CaseID
   FOR XML PATH('')),1,1,''))) AS Taxonomy,
   --Added for MD-65 Start
   CONVERT(VARCHAR,P.StateStatusAcc) As StateStatusAcc,
   CONVERT(VARCHAR,P.LegacyAccountNo) As LegacyAccountNo,
   --Added for MD-65 END
	
	--ISNULL(CONVERT(VARCHAR,A.License),'-') As License,
	--ISNULL(CONVERT(VARCHAR,S.Speciality_Code) + ' - ' + S.TaxonomyCode,'-') As Specialty,
	--CONVERT(VARCHAR,TX.Speciality_Code) + ' - ' + TX.TaxonomyCode As Taxonomy,
	CASE WHEN P.StatusAcc = '1 - Active'  THEN 'rgb(112,173,71)'
	WHEN P.StatusAcc = '2 - Inactive'  THEN 'red'
	WHEN P.StatusAcc = '9 - Temporary Suspended'  THEN 'orange'
	WHEN P.StatusAcc = '3 - Pending'  THEN 'gray'
	WHEN P.StatusAcc = '6 - Suspended'  THEN 'orange'
	WHEN P.StatusAcc = '7 - Active Rendering (indirect)'  THEN 'gray'
	WHEN P.StatusAcc = '8 - Non-Contract Hospital'  THEN 'gray'
	WHEN P.StatusAcc = '5 - Rejected'  THEN 'red'
	WHEN P.StatusAcc = '4 - Appected'  THEN 'green'
	
	ELSE '#FFFFFF' END AS RGB
from KYPEnrollment.AccountSearch A 
	INNER JOIN KYPEnrollment.pADM_Account P ON A.AccountID = P.AccountID 
	INNER JOIN KYP.ADM_Case C ON C.AccountNo = A.AccountNumber 
where A.AccountSearchEnabled=1
	--LEFT JOIN KYPEnrollment.PortalLicense L ON L.EnrolCaseID = C.CaseID
	--LEFT JOIN KYPEnrollment.PDMSpecialty  S ON S.EnrolCaseID = C.CaseID
	--LEFT JOIN KYPEnrollment.PDMTaxonomy  T ON T.EnrolCaseID = C.CaseID
	--LEFT JOIN (
	--	SELECT * FROM(
	--			SELECT Speciality_Code,TaxonomyCode,P.AccountID,ROW_NUMBER() OVER(PARTITION BY [AccountID] ORDER BY [Speciality_Code]) AS SPINC 
	--			FROM KYPEnrollment.pADM_Account P INNER JOIN KYPEnrollment.pAccount_PDM_Speciality S 
	--			ON S.PartyID = P.PartyID AND S.Type = 'Specialty Code'
	--	)X WHERE X.SPINC = 1
	--)S ON S.AccountID = A.AccountID 
	--LEFT JOIN (
	--	SELECT * FROM(
	--			SELECT Speciality_Code,TaxonomyCode,P.AccountID,ROW_NUMBER() OVER(PARTITION BY [AccountID] ORDER BY [Speciality_Code]) AS SPINC 
	--			FROM KYPEnrollment.pADM_Account P INNER JOIN KYPEnrollment.pAccount_PDM_Speciality S 
	--			ON S.PartyID = P.PartyID AND S.Type = 'Taxonomy Code'
	--	)X WHERE X.SPINC = 1
	--)TX ON TX.AccountID = A.AccountID 


GO

