
CREATE VIEW [KYP].[V_AllLicense]
AS

	SELECT PLID,EnrolCaseID,PortalCaseID,PortalAppID,PortalPartyID,License,State,IsDeleted FROM KYPEnrollment.PortalLicense WHERE IsDeleted = 0


GO

