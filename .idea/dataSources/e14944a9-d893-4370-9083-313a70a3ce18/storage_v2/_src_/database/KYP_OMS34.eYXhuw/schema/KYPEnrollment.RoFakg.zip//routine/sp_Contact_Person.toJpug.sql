
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Contact Person form.   
-- PARAMETERS: 
-- @party_id_portal : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @@account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Contact_Person]	
	@party_id_portal INT,
	@new_party_id INT,
	@last_action_user_id VARCHAR(100),
	@account_id INT

AS
BEGIN
	DECLARE
	@new_party_contact_id INT, @full_name_person VARCHAR(100),
	@party_contact_id_portal INT
	SELECT @party_contact_id_portal = PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE Type='Contact Person' AND ParentPartyID=@party_id_portal
	EXEC @new_party_contact_id = [KYPEnrollment].[sp_Copy_Party] @party_contact_id_portal, @new_party_id,@account_id,@last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Person] @new_party_contact_id, @party_contact_id_portal,@last_action_user_id, 'C';
	
	PRINT 'Contact Person'
	
END


GO

