


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_AccountInternalUseOldData] 
@AccountID int, @AccountInternalUseID int, @LastActionComments varchar(255)
	
AS
BEGIN

Declare

@AccInternalUseID int
   -- @CreatedBy varchar(100),
   -- @LastActionReason varchar(500)

	
	--Replaces Parameter setting and Update and combines it into one
	UPDATE  b
	SET
	 b.BillingStatus = a.billingStatus 
	,b.BillingBeginDate = a.BillingBeginDate 
	,b.BillingEndDate = a.BillingEndDate 
	,b.BillingFutureStatus = a.BillingFutureStatus
	,b.BillingFutureDate = a.BillingFutureDate
	,b.BillingComments = a.BillingComments
	,b.BillingFutureComments = a.BillingFutureComments
	,b.ProvisionalCode = a.ProvisionalCode
	,b.ProvisionalCodeDate = a.ProvisionalCodeDate
	,b.ProvisionalCodeDesc = a.ProvisionalCodeDesc
	,b.LabStatusCode = a.LabStatusCode
	,b.LabSpecCodeDesc = a.LabSpecCodeDesc
	,b.LabStatusCodeDate = a.LabStatusCodeDate
	,b.OutOfStateInd = a.OutOfStateInd
	,b.OutOfStateIndDesc = a.OutOfStateIndDesc
	,b.SpecProcTypeCode = a.SpecProcTypeCode
	,b.SpecProcTypeCodeDesc = a.SpecProcTypeCodeDesc
	,b.ProvCrossReferenceValue = a.ProvCrossReferenceValue
	,b.CHDPCode = a.CHDPCode
	,b.AtypicalProviderNo = a.AtypicalProviderNo
	--,PhyCertCode = a.PhyCertCode
	--,PhyCertCodeDesc = a.PhyCertCodeDesc
	--,PhyCertCodeEfDate = a.PhyCertCodeEfDate
	,b.ReEnrolInd = a.ReEnrolInd
	,b.ReEnrolDate = a.ReEnrolDate
	,b.PracTypeCode1 = a.PracTypeCode1
	,b.PracTypeCode1Desc = a.PracTypeCode1Desc
	,b.PracTypeCode2 = a.PracTypeCode2
	,b.PracTypeCode2Desc = a.PracTypeCode2Desc
	,b.TINUpdateType = a.TINUpdateType
	,b.TINUpdateTypeDesc = a.TINUpdateTypeDesc
	,b.TINUpdateDate = a.TINUpdateDate
	from [KYPEnrollment].[EDM_AccountInternalUse] a
	join
	[KYPEnrollment].[EDM_AccountInternalUseOldData] b
	on a.accountid = b.AccountID
	WHERE b.AccountID = @AccountID AND b.LastActionComments = @LastActionComments

	
	---------------------------------------------------------
	
----------------------------------

		--Replaces While loop with set based operation
	
	SELECT --AccountID,LastActionComments
	 @AccInternalUseID = 
	AccountInternalUseID--,* 
	FROM [KYPEnrollment].[EDM_AccountInternalUseOldData] WHERE AccountID=@AccountID AND LastActionComments = @LastActionComments

	
	--Declare @accManyUserID int;
 IF OBJECT_ID('tempdb..#AccInternalUseManyIDtemp') IS NOT NULL
     DROP TABLE #AccInternalUseManyIDtemp;

	Select AccInternalUseManyID --,AccountInternalUseID
	into #AccInternalUseManyIDtemp 
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID = @AccountInternalUseID

	Print 'INSERT INTO [KYPEnrollment].[EDM_AccountInternalManyOldData]'
		INSERT INTO [KYPEnrollment].[EDM_AccountInternalManyOldData]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate])

		SELECT @AccInternalUseID,[CodeIdentification],[CodeDescription],[CodeType],
		[CodeDateEffDate],[CodeDateExpDate]
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID in (Select AccInternalUseManyID from #AccInternalUseManyIDtemp) AND CurrentRecordFlag = 1 and isnull(isDeleted,0) = 0



	
	/*	
	@BillingStatus varchar(30),
	@BillingBeginDate smalldatetime,
	@BillingEndDate smalldatetime,
	@BillingFutureStatus varchar(30),
	@BillingFutureDate smalldatetime,
	@BillingComments varchar(500),
	@BillingFutureComments varchar(500),
	@ProvisionalCode varchar(2),
	@ProvisionalCodeDate smalldatetime,
	@ProvisionalCodeDesc varchar(200),
	@LabStatusCode varchar(30),
	@LabSpecCodeDesc varchar(200),
	@LabStatusCodeDate smalldatetime,
	@OutOfStateInd varchar(1),
	@OutOfStateIndDesc varchar(200),
	@SpecProcTypeCodeDesc varchar(200),
	@SpecProcTypeCode varchar(10),
	@ProvCrossReferenceValue varchar(20),
	@CHDPCode varchar(150),
	@AtypicalProviderNo varchar(11),
	--@PhyCertCode varchar(2),
	--@PhyCertCodeDesc varchar(200),
	--@PhyCertCodeEfDate smalldatetime,
	@ReEnrolInd varchar(10),
	@ReEnrolDate smalldatetime,
	@PracTypeCode1 varchar(1),
	@PracTypeCode1Desc varchar(250),
	@PracTypeCode2 varchar(1),
	@PracTypeCode2Desc varchar(250),
	@TINUpdateType varchar(5),
	@TINUpdateTypeDesc varchar(250),
	@TINUpdateDate smalldatetime,
	@AccInternalUseID int
	
Declare
	
    @CodeIdentification varchar(10),
    @CodeDescription varchar(250),
    @CodeType varchar(10),
    @CodeDateEffDate smalldatetime,
    @CodeDateExpDate smalldatetime


    
	SELECT @BillingStatus =[BillingStatus],@BillingBeginDate =[BillingBeginDate],@BillingEndDate =[BillingEndDate],
	@BillingFutureStatus =[BillingFutureStatus],@BillingFutureDate =[BillingFutureDate],@BillingComments =[BillingComments],
	@BillingFutureComments =[BillingFutureComments],@ProvisionalCode =[ProvisionalCode],@ProvisionalCodeDate =[ProvisionalCodeDate],
	@ProvisionalCodeDesc =[ProvisionalCodeDesc],@LabStatusCode =[LabStatusCode],@LabSpecCodeDesc =[LabSpecCodeDesc],@LabStatusCodeDate =[LabStatusCodeDate],
	@OutOfStateInd =[OutOfStateInd],@OutOfStateIndDesc =[OutOfStateIndDesc],@SpecProcTypeCode =[SpecProcTypeCode],@SpecProcTypeCodeDesc =[SpecProcTypeCodeDesc],
	@ProvCrossReferenceValue =[ProvCrossReferenceValue],@CHDPCode =[CHDPCode], @AtypicalProviderNo =[AtypicalProviderNo],@ReEnrolInd =[ReEnrolInd],@ReEnrolDate =[ReEnrolDate],
	--@PhyCertCode =[PhyCertCode],@PhyCertCodeDesc =[PhyCertCodeDesc],@PhyCertCodeEfDate =[PhyCertCodeEfDate],
	@PracTypeCode1 =[PracTypeCode1], @PracTypeCode1Desc=[PracTypeCode1Desc],
	@PracTypeCode2 =[PracTypeCode2],@PracTypeCode2Desc =[PracTypeCode2Desc],@TINUpdateType =[TINUpdateType], @TINUpdateTypeDesc=[TINUpdateTypeDesc],
	@TINUpdateDate =[TINUpdateDate] FROM [KYPEnrollment].[EDM_AccountInternalUse]
	WHERE AccountID =@AccountID
	
	PRINT @AccountID
	
	declare @AppCount int;
	
	SELECT @AppCount = COUNT(AccInternalUseManyID) FROM [KYPEnrollment].[EDM_AccountInternalMany]
	WHERE AccountInternalUseID =@AccountInternalUseID 		
	
	
	PRINT @AccountInternalUseID
	
	UPDATE [KYPEnrollment].[EDM_AccountInternalUseOldData]
	SET
	 BillingStatus = @BillingStatus 
	,BillingBeginDate = @BillingBeginDate 
	,BillingEndDate = @BillingEndDate 
	,BillingFutureStatus = @BillingFutureStatus
	,BillingFutureDate = @BillingFutureDate
	,BillingComments = @BillingComments
	,BillingFutureComments = @BillingFutureComments
	,ProvisionalCode = @ProvisionalCode
	,ProvisionalCodeDate = @ProvisionalCodeDate
	,ProvisionalCodeDesc = @ProvisionalCodeDesc
	,LabStatusCode = @LabStatusCode
	,LabSpecCodeDesc = @LabSpecCodeDesc
	,LabStatusCodeDate = @LabStatusCodeDate
	,OutOfStateInd = @OutOfStateInd
	,OutOfStateIndDesc = @OutOfStateIndDesc
	,SpecProcTypeCode = @SpecProcTypeCode
	,SpecProcTypeCodeDesc = @SpecProcTypeCodeDesc
	,ProvCrossReferenceValue = @ProvCrossReferenceValue
	,CHDPCode = @CHDPCode
	,AtypicalProviderNo = @AtypicalProviderNo
	--,PhyCertCode = @PhyCertCode
	--,PhyCertCodeDesc = @PhyCertCodeDesc
	--,PhyCertCodeEfDate = @PhyCertCodeEfDate
	,ReEnrolInd = @ReEnrolInd
	,ReEnrolDate = @ReEnrolDate
	,PracTypeCode1 = @PracTypeCode1
	,PracTypeCode1Desc = @PracTypeCode1Desc
	,PracTypeCode2 = @PracTypeCode2
	,PracTypeCode2Desc = @PracTypeCode2Desc
	,TINUpdateType = @TINUpdateType
	,TINUpdateTypeDesc = @TINUpdateTypeDesc
	,TINUpdateDate = @TINUpdateDate
	WHERE AccountID = @AccountID AND LastActionComments = @LastActionComments;
	
	
	SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_AccountInternalUseOldData] WHERE AccountID=@AccountID AND LastActionComments = @LastActionComments
	
	Declare @accManyUserID int;
	
	SELECT @AppCount = COUNT(1)
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID 
	
	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.AccInternalUseManyID FROM(
		SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
		FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID )X WHERE X.RowNumber = @AppCount
	
		SELECT @CodeIdentification =[CodeIdentification],@CodeDescription =[CodeDescription],@CodeType =[CodeType],
		@CodeDateEffDate =[CodeDateEffDate],@CodeDateExpDate =[CodeDateExpDate]
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID =@accManyUserID
		
		INSERT INTO [KYPEnrollment].[EDM_AccountInternalManyOldData]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		)
		VALUES(
		@AccInternalUseID
		,@CodeIdentification 
		,@CodeDescription 
		,@CodeType 
		,@CodeDateEffDate
		,@CodeDateExpDate
)
		
		SET @AppCount = @AppCount - 1
	
	END
	*/

	
	
	
	END


GO

