/*
generate [KYPEnrollment].[pAccount_RenderingAffiliation]
Author: Richard Jimenez
*/


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Affiliarion_Rendering_Group]
@account_id INT
AS
BEGIN
SET NOCOUNT ON;

DECLARE @acc_render VARCHAR(20),
		@AffiliationStartDate SmallDatetime

SET NOCOUNT ON;

Select @AffiliationStartDate = t3.DateCreated From kypenrollment.pADM_Account t1
Join (Select AccountNo,Max(CaseID) CaseID 
		From kyp.ADM_Case
		Group by AccountNo) t2 on t1.AccountNumber=t2.AccountNo
Join kyp.adm_Case t3 on t3.CaseID = T2.CaseID		
Where T1.AccountID = @account_id

  BEGIN TRY
  IF EXISTS(SELECT  distinct a.AccountID
  FROM  KYPEnrollment.pADM_Account a
  INNER JOIN KYPPortal.PortalKYP.pRenderingAffiliation p  on a.npi = p.rendering_npi and a.AccountType = 'R'
  and a.AccountID= @account_id)
  BEGIN
		

  	   SET @acc_render= @account_id
  	   
	   INSERT INTO  [KYPEnrollment].[pAccount_RenderingAffiliation]
	               ([AccountID]
	               ,[AffiliatedAccountID]
				   ,[TypeAffiliation]
				   ,[LastActionDate]
				   ,[LastActorUserID]
				   ,[LastActionComments]
				   ,[LastActionApprovedBy]
				   ,[CurrentRecordFlag]
				   ,[LastAction]
				   ,[AffiliationStartDate]
				   ,[LastUpdatedBy]
                   ,isDeleted)
				SELECT 
				acc.accountrel,
				@acc_render,
				'NEW_RENDERING_FROM_ACCOUNT', 
				getdate(),
				null,
				'',
				null,
				1,
				'C',
				--getdate(),
				@AffiliationStartDate,
				'P',
				0
				FROM 
				(
				SELECT distinct  f.accountid as accountrel
				  FROM  KYPEnrollment.pADM_Account a
				  INNER JOIN KYPPortal.PortalKYP.pRenderingAffiliation p  on a.npi = p.rendering_npi and a.AccountType = 'R' 
				  INNER JOIN [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress]  f ON  f.npi = p.group_npi
				   where a.accountID = @acc_render
				 EXCEPT 
				 SELECT  DISTINCT accountid FROM [KYPEnrollment].[pAccount_RenderingAffiliation]
				 WHERE  AffiliatedAccountID = @acc_render
				 ) acc
	   	 
  END
 END TRY
	BEGIN CATCH
		DECLARE @error_message NVARCHAR (4000), @error_severity INT;
		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY();
		RAISERROR (@error_message, @error_severity, 1);
	END CATCH
END


GO

