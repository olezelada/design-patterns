
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[p_InsertGKWatchList] 
(@LastName varchar(100)=NULL
,@FirstName varchar(100)=NULL
 ,@MiddleName varchar(100)= NULL
 ,@Name varchar(150) =NULL
 ,@AkaName varchar(150) = NULL
 ,@RequestBy varchar(50)=NULL
 ,@Notes text=NULL
 ,@ProviderType varchar(50)=NULL
 ,@Status varchar(7)=NULL
 ,@isApproved bit=0
 ,@ResolutionID bit=0
 ,@StatusStartDate datetime=NULL
 ,@StatusEndDate dateTime=NULL
)
AS BEGIN

Insert into [KYP].[GK_Watchlist]
			([LastName]
			,[FirstName]
			 ,[MiddleName]
			 ,[Name]
			 ,[AkaName]
			 ,[RequestBy]
			 ,[Notes]
			 ,[ProviderType]
			 ,[Status]
			 ,[isApproved]
			 ,[ResolutionID]
			 ,[StatusStartDate]
			 ,[StatusEndDate])
		values(@LastName
			,@FirstName
			 ,@MiddleName
			 ,@Name
			 ,@AkaName
			 ,'Monitoring Resolution from CA PED'
			 ,@Notes
			 ,@ProviderType
			 ,@Status
			 ,0
			 ,@ResolutionID
			 ,@StatusStartDate
			 ,@StatusEndDate)
print IDENT_CURRENT('[KYP].[GK_Watchlist]')
return IDENT_CURRENT('[KYP].[GK_Watchlist]');

END


GO

