
CREATE PROCEDURE [KYP].[p_InsertMT_Checklist]
	@caseId 	int,
    @template 	int	
AS
BEGIN	
	SET NOCOUNT ON
	
	Declare 	
		@dateCreated date
    SET @dateCreated = GETDATE()
	
	IF ISNULL(@caseId,0) = 0
	BEGIN
		/*PRINT 'No application found!!!'*/
		RETURN
	END

	INSERT INTO KYPEnrollment.MT_Checklist
			   ([TaskID]
			   ,[Entity]
			   ,[EntityID]
			   ,[DateCompletion]
			   ,[CheckValue]
			   ,[YesNoNAValue]
			   ,[AdvancedValue]
			   ,[IsCompleted]
			   ,[UserID]
               ,[IsVisible])
		 SELECT ti.TaskID
			  ,'ADM_CASE'
			  , @caseId
			  , CASE WHEN t.CheckedByDefault = 1 THEN GETDATE()
					 ELSE null END
			  ,isnull(t.CheckedByDefault,0)
			  ,null
			  ,null
			  ,isnull(t.CheckedByDefault,0)
			  ,null
              ,t.VisibleByDefault
		   FROM [KYPEnrollment].[MT_TaskItem] ti,
				[KYPEnrollment].MT_Task t ,
				[KYPEnrollment].MT_Template tp		
		  WHERE ti.ItemRule = 'Milestone'
			and (ti.IsDeleted is null or ti.IsDeleted = 0)
			and (tp.IsDeleted is null or tp.IsDeleted = 0)
			and tp.TemplateID 	= @template
			and ti.TaskID       = t.TaskID
			and t.TemplateID    = tp.TemplateID
 
	SET NOCOUNT OFF
	/*PRINT 'Insert in Checklist Done !!!'*/
END


GO

