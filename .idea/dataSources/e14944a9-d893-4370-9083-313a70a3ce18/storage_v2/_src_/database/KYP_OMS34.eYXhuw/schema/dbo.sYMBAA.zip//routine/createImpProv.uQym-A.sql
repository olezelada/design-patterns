-- =============================================  
-- Author:  Nitish  
-- Create date: 19-Dec-2012  
-- Description: Procedure to insert Impacted  
--    Providers with non-repeated values  
-- =============================================  
CREATE PROCEDURE [dbo].[createImpProv]   
 @ParentAlertID INT  
AS   
BEGIN  
 DECLARE   
  @ParentOrChildAlertID INT,  
    
  @auto VARCHAR(1),  
        @impacted BIT,  
        @medicaidID VARCHAR(50),  
        @providerID INT,  
        @providerName VARCHAR(50),  
        @providerSince DATETIME,  
        @remarks VARCHAR(500),  
        @searchPartyID INT,                  
        @createdBy INT,         
        @createdDate SMALLDATETIME,  
        @modifiedBy INT,  
        @modifiedDate SMALLDATETIME,  
        @searchID INT,  
        @matchType VARCHAR(50),  
  @hmsID VARCHAR(50),  
        @alertID INT,  
        @isDeleted BIT,      
        @AccGenNumber  VARCHAR(50),  
        @count INT,  
        @searchIDinCursor INT  
    
 DECLARE mycursor CURSOR FOR     
    SELECT A.SearchID,A.AlertID FROM KYP.MDM_SearchProviders A   
    INNER JOIN KYP.MDM_Alert B ON A.AlertID = B.AlertID  -- Just joined to order by IsMerged  
    WHERE A.AlertID IN  
  (SELECT AlertID FROM KYP.MDM_Alert WHERE AlertID=@ParentAlertID  
   UNION ALL  
   SELECT ChildAlertID FROM KYP.MDM_RelatedAlerts WHERE ParentAlertID=@ParentAlertID   
   AND RelationshipType='Merged')  
   AND A.Impacted = 1  
   AND A.IsDeleted = 0  
   ORDER BY B.IsMerged    -- This is done to get Parent Alert first in Cursor loop  
   
 OPEN mycursor  
 FETCH NEXT FROM mycursor INTO @searchIDinCursor, @ParentOrChildAlertID  
   
 WHILE @@FETCH_STATUS = 0  
 BEGIN  
  SELECT   
   @auto = A.Auto,  
   @impacted = A.Impacted,  
   @medicaidID = A.MedicaidID,  
   @providerID = A.ProviderID,  
   @providerName = A.ProviderName,  
   @providerSince = A.ProviderSince,  
   @remarks = A.Remarks,  
   @searchPartyID = A.SearchPartyID,  
   @createdBy = A.CreatedBy,  
   @createdDate = A.CreatedDate,  
   @modifiedBy = A.ModifiedBy,  
   @modifiedDate = A.ModifiedDate,  
   @searchID = A.SearchID,  
   @matchType = A.MatchType,  
   @hmsID = A.HMS_ID,  
   @alertID = A.AlertID,  
   @isDeleted = A.IsDeleted,   
   @AccGenNumber=A.AccGenNumber       
  FROM KYP.MDM_SearchProviders A     
  WHERE A.AlertID =  @ParentOrChildAlertID AND SearchID = @searchIDinCursor  
  AND A.Impacted = 1  
    
  SELECT @count = COUNT(ProviderID) FROM KYP.MDM_ImpProviders WHERE AlertID IN   
   (SELECT AlertID FROM KYP.MDM_Alert WHERE AlertID IN  
    (SELECT AlertID FROM KYP.MDM_Alert WHERE AlertID=@ParentAlertID  
     UNION ALL  
     SELECT ChildAlertID FROM KYP.MDM_RelatedAlerts WHERE ParentAlertID=@ParentAlertID   
     AND RelationshipType='Merged')  
   )  
   AND ProviderID = @providerID AND IsDeleted = 0  
     
   IF(@count = 0)  
   BEGIN  
    INSERT INTO KYP.MDM_ImpProviders(AlertID, SearchID, Auto, 
	Impacted, MedicaidID, ProviderID, ProviderName, 
	ProviderSince, Remarks, SearchPartyID, CreatedBy, CreatedDate, 
	ModifiedBy, ModifiedDate, MatchType, HMS_ID, IsDeleted, 
	AccGenNumber) VALUES (  
    @alertID,  
    @searchID,  
    @auto,  
    @impacted,  
    @medicaidID,  
    @providerID,   
    @providerName,  
    @providerSince,  
    @remarks,  
    @searchPartyID,  
    @createdBy,  
    @createdDate,  
    @modifiedBy,  
    @modifiedDate,  
    @matchType,  
    @hmsID,  
    @isDeleted,  
    @AccGenNumber)      
   END      
   FETCH NEXT FROM mycursor INTO @searchIDinCursor, @ParentOrChildAlertID   
 END  
 CLOSE mycursor   
 DEALLOCATE mycursor  
END  
PRINT 'db_objects/03_STORED_PROCEDURES/021_DDL_sp_p_JournalEntry.sql'
GO

