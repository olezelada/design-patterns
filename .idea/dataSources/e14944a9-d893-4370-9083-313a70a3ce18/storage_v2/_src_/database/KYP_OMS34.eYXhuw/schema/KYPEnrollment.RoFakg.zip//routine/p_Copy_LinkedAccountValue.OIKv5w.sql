
-- =============================================
-- Author:		<Author,,Lperez>
-- inserta el valor por el cual se tiene una relacion
-- recive 3  parametros 
-- @linkedAccountID id del account que tiene la relacion ,@value valor con el que se identifico que tiene una relacion ,@attribute tipo ejemplo (address, specialty .......)
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]
	@linkedAccountID INT,
	@value varchar(100),
	@attribute varchar(50)	
AS
BEGIN
	INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
	([Attribute]
	,[Value]
	,[LinkedAccountID])
	VALUES
	(@attribute
	,@value
	,@linkedAccountID);
END


GO

