



CREATE VIEW [KYPEnrollment].[v_OutEDI_MOCA_R_File_WeeklyReport_Reconciliation]
AS
SELECT distinct A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
replace(P.SSN,'-','') AS SSN,
' ' AS TIN,
PRT.MOCARelationshipStartDate,
PRT.MOCARelationshipEndDate
from KYPEnrollment.pAccount_PDM_Party PRT
Left Join KYPENROLLMENT.pADM_Account A On PRT.AccountID=A.AccountID
LEFT JOIN KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
where PRT.IsProvider=0
AND PRT.TYPE in ('Individual Ownership')
and Prt.IsDeleted=0
and A.IsDeleted=0
and A.ProviderTypeCode<>'100' --Added to eliminate Mixed Group records
UNION ALL
SELECT distinct A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
' ' AS SSN,
O.TIN as TIN,
PRT.MOCARelationshipStartDate,
PRT.MOCARelationshipEndDate
from KYPEnrollment.pAccount_PDM_Party PRT
Left Join KYPENROLLMENT.pADM_Account A On PRT.AccountID=A.AccountID
LEFT JOIN [KYPEnrollment].[pAccount_PDM_Organization] O on O.PartyID=PRT.PartyID
where PRT.IsProvider=0
AND PRT.TYPE in ('Entity Ownership')
and Prt.IsDeleted=0
and A.IsDeleted=0
and A.ProviderTypeCode<>'100' --Added to eliminate Mixed Group records
------------------------------------------- Close of MOCA Reference file ------------------------------------------------------------------------------


GO

