



CREATE View [KYPEnrollment].[Vw_Account_License] as
Select 
--Row_Number() over (order by PartyID) LicenseID,
*
From (
	select N.NumberID LicenseID,
	A.AccountId,
	N.Partyid,
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')) then N.SecondNumber  else N.Number end License1,
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')) then N.SecondEffectiveDate else N.EffectiveDate end LicenseEffDate1, 
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')) then N.SecondExpirationDate else N.ExpirationDate end LicenseExpDate1,
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC','MFCertificate')) then N.Number else N.SecondNumber end License2,
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC','MFCertificate')) then N.EffectiveDate else N.SecondEffectiveDate end LicenseEffDate2, 
	case when (A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC','MFCertificate')) then N.ExpirationDate else N.SecondExpirationDate end LicenseExpDate2,
	N.Type,
	N.DateCreated,
	N.IsDeleted,
	N.DateModified,
	N.Name, 
	N.State, 
	N.DocumentInstanceId,
	N.LicenseBoardCode,
	N.LastAction, 
	N.LastActionDate,
	N.LastActorUserId,
	N.CurrentRecordFlag,
	N.IsStateAddress,
	N.IsPrimary
	From kypenrollment.padm_Account A
	Join kypenrollment.paccount_pdm_number N on A.Partyid=N.PartyID
	Where A.IsDeleted=0
	and N.IsDeleted=0
	and N.CurrentRecordFlag=1
	and (
	(A.ProviderTypeCode='029' and N.Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC','MFCertificate')) 
	or
	(N.Type in ('Professional License','Certificate','Other','orthotistBOC','orthotistABCOP','prosthetistBOC','prosthetistABCOP','orthProsthABCOP','License','Certification','Permit'))
	)
	
	) T

GO

