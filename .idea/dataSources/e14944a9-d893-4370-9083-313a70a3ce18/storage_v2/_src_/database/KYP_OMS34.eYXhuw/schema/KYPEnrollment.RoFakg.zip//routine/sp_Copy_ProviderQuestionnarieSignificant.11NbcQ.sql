
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ProviderQuestionnarieSignificant]
   @party_account_id INT, @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @QuestionId     INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();

   -- For significant Transaction
   INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
                  [PartyID],
                  [Type],
                  [Name],
                  [Value],
                  [CurrentRecordFlag],
                  [IsDeleted],
                  [Description])
      SELECT @party_account_id,
             [Type],
             [Name],
             [Value],
             [CurrentRecordFlag],
             [IsDeleted],
             [Description]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_ProviderQuestionnarie]
       WHERE PartyID = @party_app_id


   SELECT @Questionid = SCOPE_IDENTITY ();
   RETURN @Questionid
END


GO

