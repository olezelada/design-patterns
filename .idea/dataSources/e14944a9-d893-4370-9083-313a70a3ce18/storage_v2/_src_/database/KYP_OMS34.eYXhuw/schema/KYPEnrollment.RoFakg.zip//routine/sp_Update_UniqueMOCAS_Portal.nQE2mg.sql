
CREATE PROCEDURE [KYPEnrollment].[sp_Update_UniqueMOCAS_Portal]
(
@account_id int,
@taxid varchar(10),
@applicationid int,
@last_Action_User_ID VARCHAR(100)
)
AS
BEGIN
 DECLARE @date_Create DATE,@profileid VARCHAR(40)
 declare @taxidbefore varchar(10)
 SET @date_Create = GETDATE()
 SELECT TOP 1 @profileid = ProfileID FROM KYPEnrollment.pAccount_BizProfile_Details WHERE AccountID = @account_id --AND CurrentRecordFlag=1;
 
--enabled mocas in account
SELECT	ProfileID,TaxID,MOCAType,SSNorTIN,FirstName,LastName,LegalName
into #tempmoca
FROM(SELECT *
 	FROM
 	
 	(SELECT	ACC.ACCOUNTID,BPM.ProfileID,ACC.EIN AS TaxID,[Type] AS MOCAType,ISNULL(PRS.SSN,ORG.EIN) AS SSNorTIN,PRS.FirstName,PRS.LastName,
	 ORG.LegalName, ROW_NUMBER() OVER (PARTITION BY p.type,PRS.SSN,ORG.EIN ,prs.firstname,prs.lastname,org.legalname order by p.type,PRS.SSN,ORG.EIN ,prs.firstname,prs.lastname,org.legalname ) RN
	 FROM KYPEnrollment.pADM_Account ACC inner JOIN KYPEnrollment.pAccount_BizProfile_Details BPD ON ACC.AccountID	= BPD.AccountID
	 inner join KYPEnrollment.pAccount_BizProfile_Master BPM ON BPD.ProfileId	= BPM.ProfileId
	 inner join KYPEnrollment.pAccount_PDM_Party P 	ON ACC.PartyID		= P.ParentPartyID
	 LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS ON P.PartyID		= PRS.PartyID
	 LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG 	ON P.PartyID		= ORG.PartyID
	 WHERE	ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP','GSP_MDH') AND
			P.Type				IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity','Individual Ownership','Entity Ownership') AND
			(IsPastOwner		= 0 AND LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND 
			BPM.ProfileID		=@profileid AND
			ACC.EIN				= @taxid	AND
			ACC.IsDeleted		= 0			AND
			P.CurrentRecordFlag	= 1) ILV
	WHERE ILV.RN = 1) ILV1
	
--modified mocas in the application 
select AppPartyID, max(legalnamebefore) as legalnamebefore,
max(legalnameafter) as legalnameafter,
max(ssnbefore) as ssnbefore,
max(ssnafter) as ssnafter,
max(tinbefore) as tinbefore,
max(tinafter) as tinafter,
max(firstnamebefore) as firstnamebefore,
max(firstnameafter) as firstnameafter,
max(lastnamebefore) as lastnamebefore,
max(lastnameafter) as lastnameafter,
 tablename,type 
into #tempchanged 
from
(
select tra.AppPartyID, case when tra.fieldcode IN ('SubcontractorEntityName','legalBusinessName') then isnull(tra.currentvaluetext,'') else '' end as legalnamebefore,'' as legalnameafter,
case when tra.fieldcode IN ('socialSecurityNumber') then isnull(tra.currentvaluetext,'') else '' end as ssnbefore,'' as ssnafter,
case when tra.fieldcode in ('taxIdEntity') then isnull(tra.currentvaluetext,'') else '' end as tinbefore,'' as tinafter,
case when tra.fieldcode IN ('firstName','SubcontractorFirstName') then isnull(tra.currentvaluetext,'') else '' end as firstnamebefore,'' as firstnameafter,
case when tra.fieldcode IN ('lastname','SubcontractorLastName') then  isnull(tra.currentvaluetext,'') else '' end as lastnamebefore,'' as lastnameafter,
tra.tablename,part.type 
from kypportal.PortalKYP.FieldValuesTracking tra inner join 
(select  min(trapri.fieldvalueid) as prim from kypportal.PortalKYP.FieldValuesTracking trapri
where 
(trapri.FieldCode = 'firstName' OR trapri.FieldCode = 'lastName' OR trapri.FieldCode = 'socialSecurityNumber' OR trapri.FieldCode = 'legalBusinessName' or trapri.fieldcode='taxIdEntity' or 
trapri.fieldcode='SubcontractorEntityName' or trapri.fieldcode='SubcontractorFirstName' or trapri.fieldcode='SubcontractorLastName' )
and trapri.ApplicationID  = @applicationid  and (trapri.TableName = 'Ownership/Control Interest Table' or trapri.tablename='Subcontractors Table' or trapri.tablename='Significant Transactions Table')  and trapri.actiontaken='Updated'
group by trapri.apppartyid, trapri.fieldcode,trapri.tablename) primero on tra.fieldvalueid=primero.prim
inner join kypportal.portalkyp.ppdm_party part on tra.apppartyid=part.partyid

union all

select tra.AppPartyID, '' as legalnamebefore,case when tra.fieldcode IN ('SubcontractorEntityName','legalBusinessName') then isnull(tra.newvaluetext,'') else '' end as legalnameafter,
'' as ssnbefore,case when tra.fieldcode IN ('socialSecurityNumber') then isnull(tra.newvaluetext,'') else '' end as ssnafter,
'' as tinbefore,case when tra.fieldcode in ('taxIdEntity') then isnull(tra.newvaluetext,'') else '' end as tinafter,
'' as firstnamebefore,case when tra.fieldcode IN ('firstName','SubcontractorFirstName') then isnull(tra.newvaluetext,'') else '' end as firstnameafter,
'' as lasnamebefore,case when tra.fieldcode IN ('lastname','SubcontractorLastName') then  isnull(tra.newvaluetext,'') else '' end as lastnameafter,
tra.tablename,part.type 
from kypportal.PortalKYP.FieldValuesTracking tra inner join 
(select  max(trapri.fieldvalueid) as fin from kypportal.PortalKYP.FieldValuesTracking trapri
where 
(trapri.FieldCode = 'firstName' OR trapri.FieldCode = 'lastName' OR trapri.FieldCode = 'socialSecurityNumber' OR trapri.FieldCode = 'legalBusinessName' or trapri.fieldcode='taxIdEntity' or 
trapri.fieldcode='SubcontractorEntityName' or trapri.fieldcode='SubcontractorFirstName' or trapri.fieldcode='SubcontractorLastName' )
and trapri.ApplicationID  = @applicationid and (trapri.TableName = 'Ownership/Control Interest Table' or trapri.tablename='Subcontractors Table' or trapri.tablename='Significant Transactions Table')  and trapri.actiontaken='Updated'
group by trapri.apppartyid, trapri.fieldcode,trapri.tablename) final on tra.fieldvalueid=final.fin
inner join kypportal.portalkyp.ppdm_party part on tra.apppartyid=part.partyid
) auxiliar
group by apppartyid,tablename,type
--seek original values in  person/organization tables

select detrac.AppPartyID ,legalnamebefore,legalnameafter,
case when ssnbefore='' then ISNULL(person.ssn,'') else ssnbefore end as ssnbefore,ssnafter,
tinbefore,tinafter,
case when FirstNamebefore='' then ISNULL(person.firstname,'') else firstnamebefore end as firstnamebefore,firstnameafter,
case when lastnamebefore='' then ISNULL(person.lastname,'') else lastnamebefore end as lastnamebefore,lastnameafter,tablename
into #tempchangedfin
from #tempchanged   detrac inner join kypportal.portalkyp.pPDM_Person person on detrac.AppPartyID=person.PartyID 

union all 

select detrac.AppPartyID ,
case when legalnamebefore='' then isnull(orga.legalname,'') else legalnamebefore end as  legalnamebefore,legalnameafter,
ssnbefore,ssnafter,
case when tinbefore='' then isnull(orga.ein,'') else tinbefore end as  tinbefore,tinafter,
FirstNamebefore,firstnameafter,lastnamebefore,lastnameafter,tablename
from  #tempchanged detrac inner join kypportal.portalkyp.pPDM_organization orga on detrac.AppPartyID=orga.PartyID 


--update uniquemocas
--select * 
update TIN set ssnortin=case when (case when chan.ssnafter='' then chan.tinafter else chan.ssnafter end)='' then (case when chan.ssnbefore='' then chan.tinbefore else chan.ssnbefore end) else (case when chan.ssnafter='' then chan.tinafter else chan.ssnafter end) end ,
       firstname=case when chan.firstnameafter='' then chan.firstnamebefore else chan.firstnameafter end,lastname=case when chan.lastnameafter='' then chan.lastnamebefore else chan.lastnameafter end,legalname=case when chan.legalnameafter='' then chan.legalnamebefore else chan.legalnameafter end,       
      lastaction='U',lastactoruserid=@last_action_user_id,lastactiondate=@date_create,Accountupdatedby='P' 

from 	KYPEnrollment.UniqueMOCAsProfileTINwise TIN inner join (select * from #tempchangedfin where (ISNULL(legalnameafter,'')<>'' or ISNULL(ssnafter,'')<>'' or ISNULL(tinafter,'')<>'' or ISNULL(firstnameafter,'')<>'' or ISNULL(lastnameafter,'')<>'')
) chan 
on  isnull(tin.SSNorTIN,'')=case when chan.ssnbefore='' then chan.tinbefore else chan.ssnbefore end
and ISNULL(tin.firstname,'')=chan.firstnamebefore   and ISNULL(tin.lastname,'')=chan.lastnamebefore and ISNULL(tin.legalname,'')=chan.legalnamebefore
WHERE tin.ProfileID=@profileid and tin.TaxID=@taxid 

--mocas that exist but not should be set isdeleted=1 lastaction= lastactoruserid,lastactiondate,accountupdatedby
merge KYPEnrollment.UniqueMOCAsProfileTINwise	  as targ
using
 (select * from #tempmoca ) as sour
 on  targ.profileid=sour.profileid  and targ.taxid=sour.taxid and targ.mocatype=sour.mocatype and isnull(targ.ssnortin,'')=isnull(sour.ssnortin,'') and isnull(targ.firstname,'')=isnull(sour.firstname,'') and
 isnull(targ.lastname,'')=isnull(sour.lastname,'') and isnull(targ.legalname,'')=isnull(sour.legalname,'')
 WHEN NOT MATCHED BY TARGET THEN
    INSERT (ProfileID,TaxID,MOCAType,SSNorTIN,FirstName,LastName,LegalName,CreatedBy,DateCreated,IsDeleted,currentrecordflag,LastAction,LastActorUserID,LastActionDate,AccountUpdatedBy)
    VALUES (sour.ProfileID,sour.TaxID,sour.MOCAType,sour.SSNorTIN,sour.FirstName,sour.LastName,sour.LegalName,@last_action_user_id,@date_create,0,1,'C',@last_action_user_id,@date_create,'P')
 WHEN NOT MATCHED BY SOURCE and targ.profileid=@profileid and targ.taxid=@taxid and isdeleted=0 THEN
    UPDATE SET Targ.isdeleted = 1,currentrecordflag=0,lastaction='D',lastactoruserid=@last_action_user_id,lastactiondate=@date_create,Accountupdatedby='P';
 
drop table #tempchanged
drop table #tempmoca
drop table #tempchangedfin 
--for change of taxid
--when not exist enabled mocas for old taxid, set isdeleted=1


select @taxidbefore=isnull(currentvaluetext,'') from kypportal.PortalKYP.FieldValuesTracking where ApplicationID=@applicationid   and FieldCode='taxId' and actiontaken='Updated' and SectionNanme ='EIN/Licenses'
if @taxidbefore <>'' 

begin
set @taxidbefore=REPLACE(@taxidbefore,'-','')
SELECT	ProfileID,TaxID,MOCAType,SSNorTIN,FirstName,LastName,LegalName
into #tempmoca1
FROM(SELECT *
 	FROM
 	
 	(SELECT	ACC.ACCOUNTID,BPM.ProfileID,ACC.EIN AS TaxID,[Type] AS MOCAType,ISNULL(PRS.SSN,ORG.EIN) AS SSNorTIN,PRS.FirstName,PRS.LastName,
	 ORG.LegalName, ROW_NUMBER() OVER (PARTITION BY p.type,PRS.SSN,ORG.EIN ,prs.firstname,prs.lastname,org.legalname order by p.type,PRS.SSN,ORG.EIN ,prs.firstname,prs.lastname,org.legalname ) RN
	 FROM KYPEnrollment.pADM_Account ACC inner JOIN KYPEnrollment.pAccount_BizProfile_Details BPD ON ACC.AccountID	= BPD.AccountID
	 inner join KYPEnrollment.pAccount_BizProfile_Master BPM ON BPD.ProfileId	= BPM.ProfileId
	 inner join KYPEnrollment.pAccount_PDM_Party P 	ON ACC.PartyID		= P.ParentPartyID
	 LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS ON P.PartyID		= PRS.PartyID
	 LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG 	ON P.PartyID		= ORG.PartyID
	 WHERE	ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP','GSP_MDH') AND
			P.Type				IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity','Individual Ownership','Entity Ownership') AND
			(IsPastOwner		= 0 AND LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND 
			BPM.ProfileID		=@profileid AND
			ACC.EIN				= @taxidbefore	AND
			ACC.IsDeleted		= 0			AND
			P.CurrentRecordFlag	= 1) ILV
	WHERE ILV.RN = 1) ILV1
   --if is empty not exist enabled mocas
if not exists(select * from #tempmoca1) 
begin
update	KYPEnrollment.UniqueMOCAsProfileTINwise  SET isdeleted = 1,currentrecordflag=0,lastaction='D',lastactoruserid=@last_action_user_id,lastactiondate=@date_create,Accountupdatedby='P' WHERE ProfileID=@profileid and TaxID=@taxidbefore 
end
drop table #tempmoca1	
	
end



END


GO

