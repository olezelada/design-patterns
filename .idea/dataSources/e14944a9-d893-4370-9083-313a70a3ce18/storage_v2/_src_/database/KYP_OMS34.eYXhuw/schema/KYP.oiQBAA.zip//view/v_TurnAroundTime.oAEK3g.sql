
--Select * from [KYP].[v_TurnAroundTime]
----------------------------------------------------------------

CREATE VIEW [KYP].[v_TurnAroundTime]
AS


SELECT     row_number() OVER (ORDER BY x.F_DateResolved DESC) AS ID,x.Week,x.CaseID,x.DateCreated,x.DateResolved,x.F_DateCreated,x.F_DateResolved,x.Number,x.weekFormattedDate,x.TAT_Days,x.WeekEndDate,x.WeekStartDate FROM (
 

SELECT     8 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 43) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 43) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')
UNION ALL   

SELECT     7 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 36) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 36) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')
UNION ALL

SELECT     6 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 29) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 29) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')
                     

UNION ALL


SELECT     5 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 22) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 22) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')
UNION ALL

SELECT     4 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 15) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 15) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')

UNION ALL

SELECT     3 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 8) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 8) AND StatusCodeNumber <> 12) 
                      AND IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')
UNION ALL   

SELECT     2 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 1) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 1) AND StatusCodeNumber <> 12) AND 
                      IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')

UNION ALL                
SELECT     1 AS Week, CaseID, Number, CONVERT(VARCHAR(5), DateCreated, 101) AS F_DateCreated, CONVERT(VARCHAR(5), DateResolved, 101) AS F_DateResolved, 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0) AS WeekStartDate, DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 6) AS WeekEndDate, CONVERT(VARCHAR(5), 
                      DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0), 101) AS weekFormattedDate, DATEDIFF(DAY, DateReceived, DateResolved) AS TAT_Days, DateCreated, 
                      DateResolved
FROM         KYP.ADM_Case
WHERE     (DateResolved BETWEEN DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0) AND DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 6) AND StatusCodeNumber <> 12) AND 
                      IsPPURequired = 0 and CurrentlyAssignedToID is not null AND (Userfullname!='System(Auto)' OR CurrentlyAssignedToName!='system') 
                      AND LOWER(CurrentlyAssignedToName) NOT IN ('userr','users','userc','usera','userref')

) x


GO

