
-- =============================================
-- Author:		Piyush
-- Create date: DEC 22 2014
-- Description:	Finds Next Number for OIS_Attachement 
-- =============================================
CREATE PROCEDURE [KYP].[p_GenerateAttachmentNumber]

	@Notenumber varchar(15) output

	-- Add the parameters for the stored procedure here
	

AS
BEGIN
	SET NOCOUNT ON;
	Declare
	@ParentID int,
	@Number varchar(15),
	@NumberingSchemaInfo varchar(20),
	@nextNumber varchar(10),
	@counter_aux int,
	@limit int,
	@len int,
	@zeros varchar(10),
	@updatenumber int
	
	Select @counter_aux  = 0
	Select @limit=6
	Select @zeros=''
	
	Select top(1) @nextNumber=NextNumberValue from KYP.OIS_LK_NextNumber where Name ='DOC'
	
	Select @len=LEN(@nextNumber)
	
	select @limit  = @limit  - @len
	
	if (@limit  > @counter_aux) 
	begin
		while(@limit >=	@counter_aux)
		begin
		 
		 select @zeros=@zeros+'0'
		 select @counter_aux=@counter_aux+1
		end

     end
    select @Number='DOC-'+@zeros+@nextNumber
    select @updatenumber=convert(int,@nextNumber) 
    select @updatenumber=@updatenumber+1
	update KYP.OIS_LK_NextNumber set NextNumberValue=convert(varchar,@updatenumber) where Name ='DOC'
	select @Notenumber=@Number

	
END


--------------------

/****** Object:  StoredProcedure [dbo].[createAssignToOther]    Script Date: 12/06/2012 17:42:21 ******/
SET ANSI_NULLS ON


GO

