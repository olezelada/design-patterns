
CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_Especial_Clia]
    @en_db_column        VARCHAR(100),
    @last_action_user_id VARCHAR(100),
    @account_party_id    INT,
    @new_value_text      VARCHAR(250),
    @section_name      VARCHAR(250)
AS
  BEGIN
    DECLARE @today_date DATE = GETDATE()
    DECLARE @current_record_flag BIT = 1
    DECLARE @last_action VARCHAR(1) = 'C'
    DECLARE @cliaId INT

    IF @section_name = 'Prof. Licenses, Certificates & Lab Services' OR @section_name = 'Lab/Hospital License'
      BEGIN
        PRINT 'sp_Create_Update_Especial_Clia'
        IF @en_db_column = 'RegistrationNumber' OR @en_db_column = 'CertificationNumber' OR @en_db_column = 'CliaNumber'
          BEGIN
            SELECT @cliaId = CliaID
            FROM KYPEnrollment.pAccount_PDM_Clia
            WHERE PartyID = @account_party_id

            IF @cliaId IS NULL OR @cliaId = 0
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_Clia ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedByUsedID])
                VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id,
                        @last_action_user_id);
                SET @cliaId = SCOPE_IDENTITY()
              END
            IF @en_db_column = 'RegistrationNumber'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Clia
                SET RegistrationNumber = @new_value_text
                WHERE CliaID = @cliaId
              END

            IF @en_db_column = 'CertificationNumber'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Clia
                SET CertificationNumber = @new_value_text
                WHERE CliaID = @cliaId
              END

            IF @en_db_column = 'CliaNumber'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Clia
                SET CliaNumber = @new_value_text
                WHERE CliaID = @cliaId
              END
          END
      END

  END


GO

