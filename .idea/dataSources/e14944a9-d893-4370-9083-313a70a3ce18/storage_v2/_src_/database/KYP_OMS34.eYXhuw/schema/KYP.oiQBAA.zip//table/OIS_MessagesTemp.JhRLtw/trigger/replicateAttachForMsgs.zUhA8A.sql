
-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 10-May-2014
-- Description:	Replicating Attachments for
--				forwarded messages home page
-- =============================================
CREATE TRIGGER [KYP].[replicateAttachForMsgs] 
   ON  [KYP].[OIS_MessagesTemp]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE
		@MessageID INT,	
		@AttachmentID INT,
		@NewAttachmentID INT,
		@NewMessageID INT,
			
		@FileName varchar(MAX),
		@Author varchar(100),
		@Title varchar(500),
		@Status varchar(100),
		@Description varchar(MAX),
		@DMSID varchar(150),
		@Version varchar(10),
		@SubType varchar(100),
		@FileType varchar(100),
		@Owner varchar(100),
		@Created smalldatetime,
		@Modified smalldatetime,
		@Received smalldatetime,
		@Due smalldatetime,
		@Requirement varchar(50),
		@CaseNumber varchar(50),
		@AlertNo varchar(15),
		@IncidentNumber varchar(50),
		@Type varchar(100),
		@DocumentTypeID int,
		@deleted bit,
		@SubmittedBy varchar(250),
		@SubmittedTo varchar(250),
		@ConferenceID int,
		@Number varchar(100),
		@OldDMSID varchar(500),
		@FolderPath varchar(MAX),
		@VerificationID int,
		@isWorkpaper bit,
		@Scope varchar(100),
		@DatePublished smalldatetime,
		@Source varchar(100),
		@Published smalldatetime,
		@AbsoluteFilePath varchar(MAX),
		@PrimaryKey int,
		@Entity varchar(MAX),
		@TotalViews int,
		@IconType varchar(50),
		@LastView smalldatetime,
		@TotalComments int,
		@LastCommentOn smalldatetime,
		@Expired bit,
		@AbsolutePath varchar(MAX),
		@IsFolder bit,
		@IsSystemFolder bit

		SET @MessageID = (SELECT MessageID FROM Inserted);
		SET @NewMessageID = (SELECT NewMessageID FROM Inserted);
		
		DECLARE curMsgAttachments CURSOR  
		FOR
		SELECT AttachmentID FROM [KYP].[OIS_JT_MessageAttachment] WHERE MessageID = @MessageID
		OPEN curMsgAttachments
		FETCH NEXT FROM curMsgAttachments INTO @AttachmentID
		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT
				@FileName = FileName,								
				@Author = Author,
				@Title = Title,
				@Status = Status,
				@Description = Description,
				@DMSID = DMSID,
				@Version = Version,
				@SubType = SubType,
				@FileType = FileType,
				@Owner = Owner,
				@Created = Created,
				@Modified = Modified,
				@Received = Received,
				@Due = Due,
				@Requirement = Requirement,
				@CaseNumber = CaseNumber,
				@AlertNo = AlertNo,
				@IncidentNumber = IncidentNumber,
				@Type = Type,
				@DocumentTypeID = DocumentTypeID,
				@deleted = deleted,
				@SubmittedBy = SubmittedBy,
				@SubmittedTo = SubmittedTo,
				@ConferenceID = ConferenceID,
				@Number = Number,
				@OldDMSID = OldDMSID,
				@FolderPath = FolderPath,
				@VerificationID = VerificationID,
				@isWorkpaper = isWorkpaper,
				@Scope = Scope,
				@DatePublished = DatePublished,
				@Source = Source,
				@Published = Published,
				@AbsoluteFilePath = AbsoluteFilePath,
				@PrimaryKey = PrimaryKey,
				@Entity = Entity,
				@TotalViews = TotalViews,
				@IconType = IconType,
				@LastView = LastView,
				@TotalComments = TotalComments,
				@LastCommentOn = LastCommentOn,
				@Expired = Expired,
				@AbsolutePath = AbsolutePath,
				@IsFolder = IsFolder,
				@IsSystemFolder = IsSystemFolder
				FROM [KYP].[OIS_Attachment] WHERE AttachmentID = @AttachmentID
	
		EXEC @NewAttachmentID = [KYP].[p_InsertFwdMsgAttachments]
				@FileName,
				@Author,
				@Title,
				@Status,
				@Description,
				@DMSID,
				@Version,
				@SubType,
				@FileType,
				@Owner,
				@Created,
				@Modified,
				@Received,
				@Due,
				@Requirement,
				@CaseNumber,
				@AlertNo,
				@IncidentNumber,
				@Type,
				@DocumentTypeID,
				@deleted,
				@SubmittedBy,
				@SubmittedTo,
				@ConferenceID,
				@Number,
				@OldDMSID,
				@FolderPath,
				@VerificationID,
				@isWorkpaper,
				@Scope,
				@DatePublished,
				@Source,
				@Published,
				@AbsoluteFilePath,
				@PrimaryKey,
				@Entity,
				@TotalViews,
				@IconType,
				@LastView,
				@TotalComments,
				@LastCommentOn,
				@Expired,
				@AbsolutePath,
				@IsFolder,
				@IsSystemFolder

		INSERT INTO [KYP].[OIS_JT_MessageAttachment] (MessageID, AttachmentID)
		VALUES (@NewMessageID, @NewAttachmentID)
		
		FETCH NEXT FROM curMsgAttachments INTO @AttachmentID
		END		
		-- Insert statements for trigger here
		CLOSE curMsgAttachments
		DEALLOCATE curMsgAttachments
END


GO

