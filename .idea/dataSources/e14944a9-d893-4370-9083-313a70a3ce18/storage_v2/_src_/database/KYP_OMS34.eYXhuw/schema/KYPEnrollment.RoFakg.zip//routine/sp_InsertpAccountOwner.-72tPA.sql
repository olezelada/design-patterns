
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_InsertpAccountOwner] 
	-- Add the parameters for the stored procedure here
	(@AccountID int)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    
    --To Insert Entry into pAccount_Owner for all portal created Accounts except NMP and ORP
INSERT INTO [KYPEnrollment].[pAccount_Owner]
           ([AccountID]
           ,[OwnerNo]
           ,[PracticeType]
           ,[LegalName]
           ,[BusinessName]
           ,[DBAName]
           ,[TIN]
           ,[EffectiveBeingDate]
           ,[EffectiveEndDate]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[SSN])
SELECT 
           A.AccountID
           ,A.OwnerNo
           ,E.PracTypeCode1 + E.PracTypeCode2 as [PracticeType]
           ,A.LegalName
           ,A.BusinessName
           ,A.DBAName
           ,A.EIN
           --,E.BillingBeginDate
		   ,C.DateCreated           
           ,Null
           ,A.LastAction
           ,A.LastActionDate
           ,A.LastActorUserID
           ,A.LastActionReason
           ,A.LastActionComments
           ,A.LastActionApprovedBy
           ,1
           ,A.SSN
from kypenrollment.pADM_Account A join KYPEnrollment.EDM_AccountInternalUse E on A.Accountid = E.AccountID
	Left Join KYP.ADM_Case C on A.ApplicationNumber = C.Number
where A.LegacyAccountNo is null and A.AccountType NOT IN ('NMP', 'ORP')
and Not Exists(select 1 from kypenrollment.pAccount_Owner where AccountID = A.AccountID and CurrentRecordFlag = 1)
AND A.AccountID = @AccountID 
	
END


GO

