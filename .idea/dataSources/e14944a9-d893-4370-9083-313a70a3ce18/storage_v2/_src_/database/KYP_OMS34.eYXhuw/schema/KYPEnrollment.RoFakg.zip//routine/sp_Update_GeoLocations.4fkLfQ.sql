
/* ==========================================================
-- Author:		<Lacunza, Giresse>
-- PROCEDURE: Update Party Counselor by Traking.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name : 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_GeoLocations]


@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1),
@acc_table_name varchar(100)


AS
BEGIN
SET NOCOUNT ON;
iF not exists (SELECT FiledID FROM #Control_Add_row WHERE NameTable='Geografic location Table')
BEGIN


DECLARE @delete_temp TABLE(pk INT IDENTITY (1, 1), party int,location int,address int);
DECLARE @insert_temp TABLE(pk INT IDENTITY (1, 1), party int,location int,address int);
declare @cont int,@party int,@location int,@address int,@tot int
declare @app int,@acc int,@new_sub_party int,@new_address int


INSERT INTO @delete_temp (party,location,address)
select p.PartyID,l.LocationID,ad.AddressID from KYPEnrollment.pAccount_PDM_Party p inner join KYPEnrollment.pAccount_PDM_Location l on p.PartyID=l.PartyID
inner join KYPEnrollment.pAccount_PDM_Address ad on l.AddressID=ad.AddressID
where p.ParentPartyID=@acc_party_id and p.Type='ServAddrGeoLocation' and l.Type='ServAddrGeoLocation'
and p.CurrentRecordFlag=1 and p.IsDeleted=0 and l.CurrentRecordFlag=1 and l.IsDeleted=0 and ad.CurrentRecordFlag=1

select @tot = MAX(pk) from @delete_temp
SET @cont=1
WHILE @cont<=@tot
BEGIN
	
	select @party = party, @location = location, @address = address from @delete_temp where pk=@cont
	
	EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Party','PartyID',@party
	EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Location','LocationID',@location
	EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Address','AddressID',@address
	
	SET @cont = @cont + 1
	
END

	select @app = ApplicationID from KYPPORTAL.PortalKYP.FieldValuesTracking where TargetPath=@target_path
	
	INSERT INTO @insert_temp (Party,Location,Address)
	SELECT p.PartyID,l.LocationID,a.AddressID from KYPPORTAL.PortalKYP.pADM_Application ap inner join [KYPPORTAL].[PortalKYP].[pPDM_party] p on ap.PartyID=p.ParentPartyID INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_location] l 
	ON p.PartyID=l.PartyID INNER JOIN [KYPPORTAL].[PortalKYP].pPDM_Address a ON l.AddressID=a.AddressID  where ap.ApplicationID=@app 
	and (p.Type='ServAddrBusinesLic' or p.Type='ServAddrGeoLocation') and p.IsDeleted=0 and l.IsDeleted=0 and a.IsDeleted=0
	
	select @tot =MAX(pk) from @insert_temp
	set @cont=1;
	
	select @acc = accountid from KYPEnrollment.pADM_Account where partyid=@acc_party_id
	
	WHILE @cont<=@tot
	begin
		
		select @party = party, @location = location, @address = address from @insert_temp where pk=@cont
		EXEC @new_sub_party = [KYPEnrollment].[sp_Copy_Party] 	@party,	@acc_party_id,	@acc,	@last_action_user_id;
		EXEC @new_address = [KYPEnrollment].[sp_Copy_Address] 	@new_sub_party,	@party,	null,	@last_action_user_id;
		
		EXEC [KYPEnrollment].[sp_Copy_Number]	@new_sub_party,	@party,	@last_action_user_id,'';
		
		set @cont= @cont + 1

	end
  
INSERT INTO #Control_Add_row(FiledID,NameTable)
VALUES(@acc_PK_value, 'Geografic location Table'); 

END

END


GO

