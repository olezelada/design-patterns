





-- =============================================
-- Author:		Vinoth Ramesh
-- Create date: 15 September, 2014
-- Description:	Logs Resolution delete history when deleted impacted providers and change alert status
-- =============================================
CREATE PROCEDURE [KYP].[sp_RemoveAlertResolutions] 
	@Username VARCHAR(100), 
	@NotesDescription VARCHAR(MAX),
	@ProviderNumber VARCHAR(200),
	@AlertID INT,
	@Type VARCHAR(1)
AS
BEGIN
	SET NOCOUNT ON;

    DECLARE @ResolutionID INT,
			@ResolutionType VARCHAR(100),
			@PersonID_UpdateBy INT,
			@FullName_UpdateBy VARCHAR(200),
			@ProvID INT,
			@ProvMedicaID varchar(100), --KYP-12224 
			@NPI VARCHAR(20);
			
	
	SELECT @PersonID_UpdateBy = PersonID FROM KYP.OIS_User with(nolock) WHERE UserID = @Username
	SELECT @FullName_UpdateBy = FullName FROM KYP.OIS_User with(nolock) WHERE UserID = @Username
	SELECT @ProvMedicaID = MedicaidID FROM KYP.MDM_Alert with(nolock) WHERE AlertID = @AlertID  --KYP-12224 
	declare @grpresolutions table( pk int identity(1,1),ResolutionID int, ResolutionType varchar(40),ProviderMedicaidID varchar(50))
	declare @pk int
	IF @Type = '1'
	BEGIN
		--DECLARE grpResolutions CURSOR FOR 
		insert into @grpresolutions (ResolutionID,ResolutionType )
		SELECT ResolutionID, ResolutionType FROM KYP.MDM_AlertResolution with(nolock) 
		WHERE ProviderMedicaidID = @ProviderNumber and AlertID = @AlertID AND ISNULL(IsDeleted, 0) = 0 OPTION(MAXDOP 1)
	 
		--OPEN grpResolutions 
		--FETCH NEXT FROM grpResolutions INTO @ResolutionID, @ResolutionType
	    
			--WHILE @@Fetch_Status = 0 
			while exists(select pk from @grpresolutions )
			BEGIN
			    select top 1 @pk=pk,@ResolutionID=ResolutionID , @ResolutionType=ResolutionType  from @grpresolutions 
				
				SELECT @ProvID = ProviderID FROM KYP.MDM_AlertResolution with(nolock) WHERE ResolutionID = @ResolutionID
				
				SELECT TOP 1 @NPI = NPI FROM KYP.PDM_Provider WHERE ProvID = @ProvID
				 
				INSERT INTO KYP.MDM_ResolutionHistory (EventDateTime, EventName, Notes, ProviderID, ResolutionType, UserID, UserName, AlertID, ProNumber) /*KYP-11070:added a column */ 
				VALUES (GETDATE(), 'Delete', @NotesDescription, @NPI, @ResolutionType, @Username, @FullName_UpdateBy, @AlertID, @ProviderNumber)--KYP-12224 
		
				UPDATE KYP.MDM_AlertPIUReferral SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertOIGReferral SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertPvdSuspension SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertNewResolutions SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID
				delete from @grpresolutions where pk=@pk								
				--FETCH NEXT FROM grpResolutions INTO @ResolutionID, @ResolutionType
			END
		
		--ALTER TABLE KYP.MDM_AlertResolution DISABLE TRIGGER trg_MDM_ResolutionOnInsert
		UPDATE KYP.MDM_AlertResolution SET IsDeleted = 1, DeletedDate = GETDATE(), DeletedBy = @PersonID_UpdateBy,
		row_updation_source='KYP.sp_RemoveAlertResolutions' 
		WHERE ProviderMedicaidID = @ProviderNumber AND ISNULL(IsDeleted, 0) = 0
		--ALTER TABLE KYP.MDM_AlertResolution ENABLE TRIGGER trg_MDM_ResolutionOnInsert
		
		--CLOSE grpResolutions
		--DEALLOCATE grpResolutions
	END
	ELSE IF @Type = '2'
	BEGIN
		--DECLARE grpResolutions CURSOR FOR 
		insert into @grpresolutions (ResolutionID,ResolutionType,ProviderMedicaidID )
		SELECT ResolutionID, ResolutionType, ProviderMedicaidID FROM KYP.MDM_AlertResolution with(nolock) 
		WHERE AlertID = @AlertID AND ISNULL(IsDeleted, 0) = 0 OPTION(MAXDOP 1)
	 
		--OPEN grpResolutions 
		--FETCH NEXT FROM grpResolutions INTO @ResolutionID, @ResolutionType, @ProviderNumber
	 
			--WHILE @@Fetch_Status = 0 
			while exists(select pk from @grpresolutions )
			BEGIN
				select top 1 @pk=pk,@ResolutionID=resolutionID, @ResolutionType=resolutiontype, @ProviderNumber=ProviderMedicaidID  from @grpresolutions 
				SELECT @ProvID = ProviderID FROM KYP.MDM_AlertResolution with(nolock) WHERE ResolutionID = @ResolutionID
				
				SELECT TOP 1 @NPI = NPI FROM KYP.PDM_Provider WHERE ProvID = @ProvID
				
				INSERT INTO KYP.MDM_ResolutionHistory (EventDateTime, EventName, Notes, ProviderID, ResolutionType, UserID, UserName, AlertID,ProNumber) 
				VALUES (GETDATE(), 'Delete', @NotesDescription, @NPI, @ResolutionType, @Username, @FullName_UpdateBy, @AlertID,@ProvMedicaID)--KYP-12224 
		
				UPDATE KYP.MDM_AlertPIUReferral SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertOIGReferral SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertPvdSuspension SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID

				UPDATE KYP.MDM_AlertNewResolutions SET IsDeleted = 1 WHERE ResolutionID = @ResolutionID
				delete from @grpresolutions where pk=@pk								
				--FETCH NEXT FROM grpResolutions INTO @ResolutionID, @ResolutionType, @ProviderNumber
			END
			
		--ALTER TABLE KYP.MDM_AlertResolution DISABLE TRIGGER trg_MDM_ResolutionOnInsert
		UPDATE KYP.MDM_AlertResolution SET IsDeleted = 1, DeletedDate = GETDATE(), DeletedBy = @PersonID_UpdateBy ,
		row_updation_source='KYP.sp_RemoveAlertResolutions' 
		WHERE ProviderMedicaidID = @ProviderNumber AND ISNULL(IsDeleted, 0) = 0
		--ALTER TABLE KYP.MDM_AlertResolution ENABLE TRIGGER trg_MDM_ResolutionOnInsert
		
		--CLOSE grpResolutions
		--DEALLOCATE grpResolutions
	END
END


GO

