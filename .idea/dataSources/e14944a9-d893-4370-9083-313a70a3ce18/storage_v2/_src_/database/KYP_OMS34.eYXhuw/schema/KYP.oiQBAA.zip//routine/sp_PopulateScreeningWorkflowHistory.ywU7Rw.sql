

CREATE PROCEDURE [KYP].[sp_PopulateScreeningWorkflowHistory] 
	-- Add the parameters for the stored procedure here
	@CaseID INT,
	@ProcessName VARCHAR(100),
	@ActivityStatus VARCHAR(50),
	@UserID	VARCHAR(100),
	@Notes VARCHAR(MAX),
	@ProcessType VARCHAR(1),
	@ActionName VARCHAR(500)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE 
		@D_MajorDispositionStatus VARCHAR(100),
		@D_MinorDispositionStatus VARCHAR(100),
		@D_DescriptionStatus VARCHAR(100),
		@D_FullName VARCHAR(100),
		@D_DateTime DATETIME,
		@D_SortDateTime DATETIME,
		@D_ExisingHistory INT,
		@D_StartDateTime DATETIME,
		@RoleName VARCHAR(100),
		@CurrentMinorDisposition VARCHAR(100),
		@Assignee VARCHAR(100),
		@AssignByUserName VARCHAR(100);
		
	SELECT @D_FullName = FullName FROM KYP.OIS_User	WHERE UserID = @UserID;
	IF @D_FullName IS NULL
	BEGIN
		SELECT @D_FullName = FullName FROM KYP.OIS_User	WHERE PersonID = @UserID;
	END;
	
		SELECT @AssignByUserName=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT AssignedFromID FROM kyp.ADM_Case WHERE CaseID=@CaseID);
	
		SELECT @Assignee=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT CurrentlyAssignedToID FROM kyp.ADM_Case WHERE CaseID=@CaseID);
		
	SET @D_DateTime = GETDATE();
	SET @D_SortDateTime = DATEADD(SS, 2, @D_DateTime);

	SELECT TOP 1 @RoleName = RoleName FROM KYP.OIS_ProcessNextStep WITH (NOLOCK) WHERE ProcessName = @ProcessName AND ActionName =@ActionName;
	SELECT @CurrentMinorDisposition = CurrentMinorDisposition FROM KYP.ADM_Case WHERE CaseID = @CaseID;

	IF @RoleName is null
	BEGIN
	SELECT TOP 1 @RoleName = RoleName FROM KYP.OIS_ProcessNextStep WITH (NOLOCK) WHERE ProcessName = @ProcessName AND ActionName ='HISTORY';
	END
	
	
	IF @ProcessType = 2
	BEGIN
	
		SELECT TOP 1 @D_MajorDispositionStatus = MajorDisposition, @D_MinorDispositionStatus = MinorDisposition, @D_DescriptionStatus = [Description] 
		FROM KYP.OIS_ProcessWorkFlow WITH (NOLOCK) WHERE ProcessName = @ProcessName;
		
		IF @ActivityStatus IN ('Suspended', 'Resumed')
		BEGIN
		
			IF @ActivityStatus = 'Suspended'
			BEGIN
				EXEC KYP.p_InsertADMWorkflowHistory 
					@CaseID, @WorkflowStatus = '2', @DateTime = @D_DateTime, @UserID = @UserID, 
					@UserFullName = @D_FullName,@Notes = @Notes, @RoleName = @RoleName,
					@MajorStatus = @D_MajorDispositionStatus, @MinorStatus = NULL, 
					@ActivityStatus = @ActivityStatus, @Description = NULL, @EndDateTime = NULL, 
					@NoOfDays = NULL, @SortDateTime = @D_DateTime ,@Assignee=@Assignee
			END
			ELSE IF @ActivityStatus = 'Resumed'
			BEGIN
			
				SELECT TOP 1 @D_ExisingHistory = ID, @D_StartDateTime = [DateTime] 
				FROM KYP.ADM_WorkflowHistory 
				WHERE CaseID = @CaseID AND ActivityStatus = 'Suspended'
				ORDER BY ID DESC
				
				EXEC KYP.p_InsertADMWorkflowHistory
					@CaseID, @WorkflowStatus = '2', @DateTime = @D_DateTime, @UserID = @UserID, @UserFullName = @D_FullName, 
					@Notes = @Notes, @RoleName = @RoleName, @MajorStatus = @D_MajorDispositionStatus, @MinorStatus = NULL, 
					@ActivityStatus = @ActivityStatus, @Description = NULL, @EndDateTime = @D_DateTime, 
					@NoOfDays = 0, @SortDateTime = @D_DateTime ,@Assignee=@Assignee
				
				UPDATE KYP.ADM_WorkflowHistory 
				SET EndDateTime = @D_DateTime, NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime) ,@Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
		END
		
		ELSE
		BEGIN
			EXEC KYP.p_InsertADMWorkflowHistory 
				@CaseID, @WorkflowStatus = '2', @DateTime = @D_DateTime, @UserID = @UserID, @UserFullName = @D_FullName, 
				@Notes = @Notes, @RoleName = @RoleName, @MajorStatus = @D_MajorDispositionStatus, @MinorStatus = NULL, 
				@ActivityStatus = @ActivityStatus, @Description = NULL, @EndDateTime = @D_DateTime, @NoOfDays = 0, @SortDateTime = @D_DateTime,@Assignee=@Assignee
		END
		
		SELECT TOP 1 @D_ExisingHistory = ID, @D_StartDateTime = [DateTime] FROM KYP.ADM_WorkflowHistory WITH (NOLOCK)
		WHERE CaseID = @CaseID AND ActivityStatus = 'In Progress' AND @CurrentMinorDisposition != 'Revert'
		ORDER BY ID DESC
		
		SELECT @D_MajorDispositionStatus = MajorDisposition, @D_MinorDispositionStatus = MinorDisposition, @D_DescriptionStatus = [Description] 
		FROM KYP.OIS_ProcessWorkFlow WITH (NOLOCK) WHERE ProcessName = @ProcessName		
			
		IF ISNULL(@D_ExisingHistory, 0) <> 0
		BEGIN
			UPDATE KYP.ADM_WorkflowHistory 
			SET ActivityStatus = 'In Progress', SortDateTime = @D_SortDateTime, NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
			,Assignee=@Assignee 
			WHERE ID = @D_ExisingHistory
		END
	END
	
	ELSE IF @ProcessType = 1
	BEGIN

		SELECT TOP 1 @D_ExisingHistory = ID, @D_StartDateTime = [DateTime] FROM KYP.ADM_WorkflowHistory WITH (NOLOCK)
		WHERE CaseID = @CaseID AND ActivityStatus = 'In Progress' AND @CurrentMinorDisposition != 'Consult'
		ORDER BY ID DESC
		
		SELECT @D_MajorDispositionStatus = MajorDisposition, @D_MinorDispositionStatus = MinorDisposition, @D_DescriptionStatus = [Description] 
		FROM KYP.OIS_ProcessWorkFlow WITH (NOLOCK) WHERE ProcessName = @ProcessName		
			
		IF ISNULL(@D_ExisingHistory, 0) <> 0
		BEGIN
			IF @Notes IS NULL OR @Notes = ''
			BEGIN
				UPDATE KYP.ADM_WorkflowHistory 
				SET ActivityStatus = 'Completed', UserFullName = @D_FullName, UserID = @UserID,EndDateTime = @D_DateTime, NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime),
					SortDateTime = @D_DateTime ,Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
			ELSE
			BEGIN
				UPDATE KYP.ADM_WorkflowHistory 
				SET ActivityStatus = 'Completed', UserFullName = @D_FullName,UserID = @UserID, Notes = @Notes, EndDateTime = @D_DateTime, NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime),
					SortDateTime = @D_DateTime ,Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
		END
		ELSE
		BEGIN
		EXEC KYP.p_InsertADMWorkflowHistory 
			@CaseID, @WorkflowStatus = '1', @DateTime = @D_DateTime, @UserID = @UserID, @UserFullName = @D_FullName, 
			@Notes = @Notes, @RoleName = @RoleName, @MajorStatus = @D_MajorDispositionStatus, @MinorStatus = @D_MinorDispositionStatus, 
			@ActivityStatus = 'In Progress', @Description = @D_DescriptionStatus, @EndDateTime = NULL, @NoOfDays = NULL, @SortDateTime = @D_SortDateTime,
			@Assignee=@Assignee
		END
	END
END


GO

