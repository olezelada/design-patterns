

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Signif]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   --@type VARCHAR (50),
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_adr           INT,
      @new_party_adr       INT,
      @count_association   INT,
      @main_party_id       INT,
      @is_prepopulated     BIT,
      @target_path         VARCHAR (200),
      @full_name_person    VARCHAR (100),
      @type                VARCHAR (50),
      @org_id              INT,
      @legal_name          VARCHAR (100),
      @person_id           INT;
   PRINT '[sp_Copy_Party_Loc_Addr_Signif]';

   --new account
   IF @app_party_row_id IS NULL
      BEGIN
         --Create  Associations

         INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] (
                        [PartyIDOwner],
                        [PartyIDOwned],
                        [DateCreated],
                        [IsDeleted],
                        [TypeAssociation],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [OtherAssociation],
                        [ParentPartyIdAssociation],
                        TransDescription)
            SELECT @new_party_id,
                   s.PartyID_Enroll,
                   getdate (),                                   --datecreated
                   0,                                              --isdeleted
                   o.TypeAssociation,
                   'C',                                           --lastaction
                   getdate (),                                --lastactiondate
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   o.OtherAssociation,
                   --isnull((select PartyID_Enroll from @signif   where PartyID_Portal = o.ParentPartyIDAssociation),null) as pp
                   isnull (
                      (SELECT TOP 1
                              PartyID_Enroll
                         FROM #subcontractors
                        WHERE PartyID_Portal = o.ParentPartyIDAssociation),
                      NULL)
                      AS pp,
                   TransDEscription
              --from @signif  s
              FROM #subcontractors s
                   LEFT JOIN KYPPORTAL.PortalKYP.pPDM_OwnershipRelationship o
                      ON s.PartyID_Portal = o.PartyIDOwned
            ORDER BY s.PartyID_Portal ASC
      END
--RETURN @new_party_adr

END


GO

