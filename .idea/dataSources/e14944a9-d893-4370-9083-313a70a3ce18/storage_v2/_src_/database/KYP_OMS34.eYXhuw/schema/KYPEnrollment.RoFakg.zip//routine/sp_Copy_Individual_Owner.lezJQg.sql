
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Individual Ownership forms.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @is_update : Flag if is update or create, default value is false.
-- @account_id : AccointID that will be create.
-- ============================================================*/
--Change History
---------------------------------------------------------------------------------------
-- Sl.No. JIRA No.  Author  Date   Description
---------------------------------------------------------------------------------------
-- 1  CAPAVE-1742  Sundar  17-Aug-2017  Commented the SP call (kyp.usp_MocaInputDoc) since, it is added in sp_Update_Account SP

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Individual_Owner]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @is_update              BIT,
   @account_id             INT,
   @is_prepopulated        BIT,
   @party_provider_id      INT,
   @is_group               BIT,
   @target_path            VARCHAR (200)
AS
BEGIN
   DECLARE
      @full_name_person   VARCHAR (100),
      @main_party_id      INT,
      @person_id          INT;
   /**IndividualInformation**/
   EXEC @person_id =
           [KYPEnrollment].[sp_Copy_Person] @party_account_id,
                                            @party_app_id,
                                            @last_action_user_id,
                                            'C';
   EXEC [KYPEnrollment].[sp_Copy_Address] @party_account_id,
                                          @party_app_id,
                                          NULL,
                                          @last_action_user_id;
   EXEC [KYPEnrollment].[sp_Copy_Document] @party_account_id,
                                           @party_app_id,
                                           @last_action_user_id;
   EXEC [KYPEnrollment].[sp_Copy_Provider] @party_account_id,
                                           @party_app_id,
                                           @last_action_user_id;
   EXEC [KYPEnrollment].[sp_Copy_Program_Participation] @party_account_id,
                                                        @party_app_id,
                                                        @last_action_user_id,
                                                        'Individual Identification',
                                                        NULL,
                                                        @account_id;

   UPDATE person
      SET person.NPI = provider.NPI
     FROM KYPEnrollment.pAccount_PDM_Person person
          INNER JOIN KYPEnrollment.pAccount_PDM_Provider provider
             ON person.PartyID = provider.PartyID
    WHERE person.PartyID = @party_account_id

   /*Owner Interest*/
   EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @party_account_id,
                                             @party_app_id,
                                             @last_action_user_id,
                                             NULL,
                                             NULL;
   /*Association*/
   /*other association*/
   EXEC [KYPEnrollment].[sp_Copy_Others_Associations] @party_account_id,
                                                      @party_app_id,
                                                      @account_id,
                                                      @last_action_user_id,
                                                      NULL;

   /* Entity Individual */
   IF @is_update = 0
      BEGIN
         EXEC [KYPEnrollment].[sp_Copy_Assocoation_Ind_Ent] @party_account_id,
                                                            @party_app_id,
                                                            @last_action_user_id,
                                                            'OwnershipIndividualAssociation',
                                                            'OwnershipEntityAssociation';
      END

   /*Adverse Action*/
   EXEC [KYPEnrollment].[sp_Copy_Program_Suspension] @party_account_id,
                                                     @party_app_id,
                                                     @last_action_user_id,
                                                     'InvActionQuestion',
                                                     NULL,
                                                     @account_id;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'IndQuestionnaireSuspendedRevoked',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'IndQuestionnaireDisciplinaryHearing',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'IndQuestionnaireOtherApproval',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'InvActionConviction',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'InvActionLiability',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'InvActionSettlement',
                                                 NULL;
   -- Added for new packages MD.
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'InvActionPending',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'InvActionSuspendedSurrendered',
                                                 NULL;

   --Commented the SP call for CAPAVE-1742
   --EXEC KYPEnrollment.usp_MocaInputDoc @account_id --Added for MOCA Color changes PI-754

   IF (@is_group = 1)
      BEGIN
         IF (@is_prepopulated IS NULL OR @is_prepopulated = 0)
            BEGIN
               SELECT @full_name_person = [FirstName] + ' ' + [LastName]
               FROM KYPEnrollment.pAccount_PDM_Person
               WHERE PersonID = @person_id;
               --EXEC [KYPEnrollment].[Create_Moca_TaxId] @party_account_id,'Individual',@full_name_person, @party_provider_id;
               EXEC [KYPEnrollment].[Create_Party_Associate] @party_account_id,
                                                             @party_account_id,
                                                             @account_id,
                                                             'Individual Ownership',
                                                             @party_app_id;
            END
         ELSE
            BEGIN
               SELECT TOP 1
                      @main_party_id = Item
                 FROM [KYPEnrollment].[SplitString] (@target_path, '|')
               ORDER BY item;
               SELECT TOP 1
                      @main_party_id = MainPartyID
               FROM [KYPEnrollment].[pAccount_Party_Associate]
               WHERE PartyID = @main_party_id;
               EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                             @party_account_id,
                                                             @account_id,
                                                             'Individual Ownership',
                                                             @party_app_id;
            END
      END
END


GO

