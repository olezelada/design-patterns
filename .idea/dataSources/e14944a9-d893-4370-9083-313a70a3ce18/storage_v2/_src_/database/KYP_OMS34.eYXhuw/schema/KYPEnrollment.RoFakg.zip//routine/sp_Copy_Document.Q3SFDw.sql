
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Document.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Document]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON 
DECLARE @date_created DATE;
SET @date_created =  GETDATE();
INSERT INTO [KYPEnrollment].[pAccount_PDM_Document]
	  ([PartyID]
      ,[TypeDoc]
      ,[NumberDoc]
      ,[StateIssued]
      ,[CreatedBy]
      ,[DateCreated]
      ,[IsDeleted]
      ,[LastAction]
      ,[LastActionDate]
      ,[LastActorUserID]
      ,[LastActionApprovedBy]
      ,[CurrentRecordFlag])
      
      SELECT @party_account_id,
      [TypeDoc],
      [NumberDoc],
      [StateIssued],
      [CreatedBy],
      @date_created,
      [IsDeleted],
      'C',
      @date_created,
      @last_action_user_id,
      @last_action_user_id,
      1
      FROM [KYPPORTAL].[PortalKYP].[pPDM_Document] 
      WHERE PartyID=@party_app_id;

END


GO

