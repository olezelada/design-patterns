
/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: update Mode of Transportation.
-- PARAMETERS:
-- @accountPartyId : partyID to new Account that will be create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_UpdateCreateModeTranAir] @accountPartyId INT,@last_Action_User_ID VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON
DECLARE @date_created DATE = GETDATE();

--Variables and tempTables
CREATE TABLE #typesRows (instanceId INT, instanceType varchar(100));

INSERT INTO #typesRows (instanceId,instanceType)
SELECT o.OperatorId, p.Type
FROM KYPEnrollment.pAccount_PDM_Party p INNER JOIN KYPEnrollment.pAccount_PDM_Operator o ON p.PartyID = o.PartyId
WHERE p.ParentPartyID=@accountPartyId AND p.CurrentRecordFlag=1 AND o.CurrentRecordFlag=1 AND o.IsDeleted <>1 AND p.Type IN ('Pilot');

INSERT INTO #typesRows (instanceId,instanceType)
SELECT v.VehicleId, p.Type
FROM KYPEnrollment.pAccount_PDM_Party p INNER JOIN KYPEnrollment.pAccount_PDM_Vehicle v ON p.PartyID = v.PartyId
WHERE p.ParentPartyID=@accountPartyId AND p.CurrentRecordFlag=1 AND v.CurrentRecordFlag=1 AND v.IsDeleted <>1  AND p.Type IN ('Aircraft')

IF EXISTS(SELECT * FROM #typesRows)
BEGIN

	DECLARE @nonmedical BIT=0, @ground BIT=0, @wheelchairVan BIT=0, @littlerVan BIT=0, @ambulance BIT=0;
	DECLARE @motId INT, @typeEmergency BIT, @nonemergency BIT, @air BIT, @Helicopter BIT, @Fixedwing BIT;

	SELECT @motId = mot.MotId, @typeEmergency=mot.TypeEmergency, @nonemergency =mot.Nonemergency, @air = mot.Air, @Helicopter=mot.Helicopter, @Fixedwing=mot.Fixedwing
  FROM KYPEnrollment.pAccount_PDM_ModeOfTransportation mot INNER JOIN KYPEnrollment.pAccount_PDM_Party party ON mot.PartyId=party.PartyID
  WHERE party.CurrentRecordFlag = 1 AND mot.CurrentRecordFlag=1 AND party.IsDeleted <> 1 AND party.PartyID = @accountPartyId

	--AIR
	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('Pilot', 'Aircraft')) > 0)
	BEGIN
    SET @air=1;
    IF(@Helicopter IS NULL AND @Fixedwing IS NULL)
	  BEGIN
	    SET @Helicopter=1;
	    SET @Fixedwing=1;
	  END
	END

	IF ((SELECT COUNT(instanceId )FROM #typesRows WHERE instanceType IN ('Pilot', 'Aircraft')) > 0 AND @typeEmergency IS NULL AND @nonemergency IS NULL)
	BEGIN
	    SET @typeEmergency=1;
	    SET @nonemergency=1;
	END
	--update ModeOfTransportation
  IF( @motId IS NOT null)
  BEGIN
    UPDATE KYPEnrollment.pAccount_PDM_ModeOfTransportation
    SET TypeEmergency = @typeEmergency, Nonemergency = @nonemergency, Nonmedical = @nonmedical,
    Ground = @ground, WheelchairVan = @wheelchairVan, LittlerVan = @littlerVan, Ambulance = @ambulance,
    Air = @air, Helicopter = @Helicopter , Fixedwing = @Fixedwing
    WHERE MotId=@motId
  END
  ELSE
    BEGIN
      INSERT INTO KYPEnrollment.pAccount_PDM_ModeOfTransportation(
              TypeEmergency,
              Nonemergency,
              Air,
              Helicopter,
              Fixedwing,
              Ground,
              WheelchairVan,
              LittlerVan,
              Ambulance,
              PartyId,
              LastAction,
              LastActionDate,
              LastActionUserID,
              DateCreated,
              CurrentRecordFlag,
              Nonmedical)
      VALUES (
              @typeEmergency,
              @nonemergency,
              @air,
              @Helicopter,
              @Fixedwing,
              @ground,
              @wheelchairVan,
              @littlerVan,
              @ambulance,
              @accountPartyId,
              'C',
              @date_created,
              @last_Action_User_ID,
              @date_created,
              1,
              @nonmedical)
    END
END

DROP TABLE #typesRows;

END
GO

