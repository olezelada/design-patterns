
CREATE VIEW [KYP].[v_AlertCurrAsgRoleinfo]
AS
SELECT row_number() OVER (
		ORDER BY AlertNo ASC
		) AS ID
	,*
FROM (
	(
		SELECT a.Alertno AS AlertNo
			,u.ROLE_NAME AS ROLE_NAME
			,A.IsMerged
			,A.WatchedPartyName
			,A.WFStatus
			,A.AlertID
		FROM dbo.USERROLETABLE u
			,kyp.MDM_Alert a
		WHERE USER_NAME = (
				SELECT UserID
				FROM kyp.OIS_User
				WHERE PersonID = a.AssignedToUserID
				)
		)
	
	UNION
	
	(
		SELECT a.Alertno AS AlertNo
			,'Supervisor' AS ROLE_NAME
			,A.IsMerged
			,A.WatchedPartyName
			,A.WFStatus
			,A.AlertID
		FROM kyp.MDM_Alert a
		WHERE a.AssignedToUserID IS NULL
		)
	) Z


GO

