











/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertAdditionalParties]
(
	@CaseID int = NULL,
	@ApplicationID int = NULL,
	@PartyID int = NULL,
	@ApplicationNo [varchar](10) = NULL,
	@PartyType [varchar](50) = NULL,
	@FirstName [varchar](100)= NULL,
	@LastName [varchar](100) = NULL,
	@MiddleName [varchar](100) = NULL,
	@LegalName [varchar](100) = NULL,
	@SSN [varchar](20) = NULL,
	@TIN [varchar](20) = NULL,
	@License [varchar](20) = NULL,
	@ProviderTypeCode [varchar](6) = NULL,
	@ProviderTypeDescription [varchar](100) = NULL,
	@AddressType [varchar](50) = NULL,
	@AddressLine1 [varchar](200) = NULL,
	@AddressLine2 [varchar](100) = NULL,
	@City [varchar](50) = NULL,
	@State [varchar](50) = NULL,
	@ZipCode [varchar](10) = NULL,
	@Zip5 [varchar](5) = NULL,
	@Zip4 [varchar](4) = NULL,
	@IsActive [bit] = NULL,
	@IsDeleted [bit] = NULL,
	@FullAddress [VARCHAR] (1000) = NULL,
	@IsApproved [bit] = NULL,
	@IsParent [bit] = NULL,
	@LocationNumber int
)
as begin 

print'test insaid PDM_AdditionalParties'
	INSERT INTO [KYP].[PDM_AdditionalParties]
           ([CaseID]
           ,[ApplicationID]
           ,[PartyID]
           ,[ApplicationNo]
           ,[PartyType]
           ,[FirstName]
           ,[LastName]
           ,[MiddleName]
           ,[LegalName]
           ,[SSN]
           ,[TIN]
           ,[License]
           ,[ProviderTypeCode]
           ,[ProviderTypeDescription]
           ,[AddressType]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[City]
           ,[State]
           ,[ZipCode]
           ,[Zip5]
           ,[Zip4]
           ,[IsActive]
           ,[IsDeleted]
           ,[FullAddress]
           ,[IsApproved]
           ,[IsParent]
           ,[LocationNo]
           ,[IsIUDCompleted])
     VALUES
           (@CaseID ,
			@ApplicationID ,
			@PartyID ,
			@ApplicationNo ,
			@PartyType ,
			@FirstName ,
			@LastName ,
			@MiddleName ,
			@LegalName ,
			@SSN ,
			@TIN ,
			@License ,
			@ProviderTypeCode ,
			@ProviderTypeDescription ,
			@AddressType,
			@AddressLine1,
			@AddressLine2,
			@City,
			@State,
			@ZipCode,
			@Zip5,
			@Zip4,
			@IsActive,
			@IsDeleted,
			@FullAddress,
			@IsApproved,
			@IsParent,
			@LocationNumber,
			'0%'
			)
print'return insaid PDM_AdditionalParties'
	return IDENT_CURRENT('[KYP].[PDM_AdditionalParties]')

end


GO

