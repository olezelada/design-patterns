


CREATE VIEW [KYP].[v_CaseSummaryRedFlagDetails] AS

SELECT DISTINCT CONVERT(VARCHAR,P.ScreeningID)As ScreeningID,CONVERT(VARCHAR,A.CaseID) As CaseID,B.Name
	,F.Attribute,F.Description,'This flag requires additional information' As Comments,
	convert(varchar(10),P.DateCreated,101) [ScreenedOn],P.tag
 FROM 
	KYP.SDM_ApplicationParty P INNER JOIN KYP.ADM_Application A ON A.ApplicationID = P.ApplicationID AND P.IsActive = 1
	INNER JOIN KYP.ADM_Case C ON C.CaseID = A.CaseID 
	INNER JOIN KYP.PDM_Party B ON B.PartyID = P.PartyID  
	INNER JOIN (
		Select DISTINCT L.FlagID,L.Attribute,L.FlagEnabled,L.Description,R.ScreeningID  
		from KYP.LK_RedFlagConfiguration L INNER JOIN KYP.SDM_RedFlag R ON L.FlagID = R.FlagID 
	) F ON F.ScreeningID = P.ScreeningID where P.Tag is null


GO

