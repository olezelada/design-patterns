
CREATE VIEW [KYPEnrollment].[v_EDM_AccountInternalManyOldData]
AS
SELECT *
	,CASE ISNULL(CodeIdentification, '')
		WHEN ''
			THEN CodeDescription
		ELSE isnull(CodeIdentification,'') + ' - ' + CodeDescription
		END AS 'CodeDescriptionFull'
FROM KYPEnrollment.EDM_AccountInternalManyOldData


GO

