
CREATE TRIGGER [KYP].[trg_JournalEntry] ON [KYP].[MDM_JournalBasicInfo]
AFTER INSERT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE
		/*--------Variable declaration for KYP-1182 and KYP-1184-----------*/
		@MultipleCaseID VARCHAR(500)
		,
		-- @ApplicationID int,
		/*--------End of Variable declaration for KYP-1182 and KYP-1184-----------*/
		@AlertNo VARCHAR(500)
		,@AlertID INT
		,@CurrentWFStatus VARCHAR(50)
		,@JournalEvent VARCHAR(50)
		,@Username VARCHAR(100)
		,@Description VARCHAR(100)
		,@PersonID INT
		,@AssignToUserID INT
		,@NotesDescription VARCHAR(MAX)
		,@NotesTitle VARCHAR(120)
		,@Number VARCHAR(20)
		,@FirstName VARCHAR(100)
		,@LastName VARCHAR(100)
		,@Name VARCHAR(8000)
		,@NoteID INT
		,@CurrentDate DATETIME
		,@Currenttag VARCHAR(5)
		,@Notenumber VARCHAR(15)
		,@Type VARCHAR(100)
		,@SubType VARCHAR(100)
		,@RelatedEntityType VARCHAR(200)
		,@JournalDescription VARCHAR(250)
		,@CaseID INT
		,@NoteEntityType VARCHAR(100)
		,@NoteEntityTypeID VARCHAR(100)
		,@NoteEntityDepID VARCHAR(100)
		,@NoteEntityDep VARCHAR(100)
		,@Level INT
		,@SmartletParameter VARCHAR(500)
		,@IsLastLevel BIT
		,@RelatedEntityID INT
		,@FullName VARCHAR(200)
		,@IsExistID INT
		,@NoteCount INT
		,@IsExistCaseID INT
		,@CaseNoteCNT INT
		,@InfoID INT		
		-- START : Changes for KYP-2880 (NM-Enhancement) - By : Nitish Gondkar - 26-June-2013
		,@body NVARCHAR(MAX)
		,@EmailAddTo VARCHAR(500)
		,@EmailAddCC VARCHAR(500)
		,@Sub VARCHAR(MAX)
		,@ALIASNAME VARCHAR(100)
		,@MultipleTrackingNo VARCHAR(800)		
		-- END : Changes for KYP-2880 (NM-Enhancement) - By : Nitish Gondkar - 26-June-2013
		-- START : Changes for http://jira/browse/KYP-9197--BY MUTIPLE DATASETS 
		,@DUPLICATEID INT
		,@MEDICAIDRESOLID VARCHAR(MAX)
		,@WATCHRESOLUTIONNAME VARCHAR(225)
		,@WATCHRESOLUTIONPROVIDERMEDICAIDID VARCHAR(225)
		,@WATCHDUMRESOLUTIONID VARCHAR(225)
		,@ResolutionID INT
		,@PersonID_UpdateBy INT
		,@FullName_UpdateBy VARCHAR(200)
		,@ProvID INT
		,@ProvMedicaID VARCHAR(100)
		,@NPI VARCHAR(20)
		,@FormattedContent VARCHAR(MAX);
		
	
	SELECT @CurrentDate = getdate()
-- CAPAVE -1122
-- Start
 declare @test varchar(max)
 select @test = NotesTitle 
 from inserted 
 
 set @test = Replace(REPLACE(@test,char(10),' '),CHAR(13),' ')

 while charindex('  ',@test  ) > 0
 begin
  set @test = replace(@test, '  ', ' ');
 end

 Set @NotesTitle=@test;
-- end
	SELECT @AlertNo = AlertNo
		,@JournalEvent = JournalEvent
		,@NotesDescription = NotesDescription
		,@Username = UserName
		,@AssignToUserID = AssignToUserID
		,@InfoID = InfoID
		,@Type = [Type]
		,@RelatedEntityType = RelatedEntityType
		,@CaseID = CaseID
		,@SmartletParameter = SmartletParameter
		,@SubType = SubType
		,@RelatedEntityID = RelatedEntityID
		,@CurrentWFStatus = CurrentWFStatus
		,@MultipleTrackingNo = MultipleTrackingNo
		,@MultipleCaseID = MultipleCaseID
		,@FormattedContent = FormattedContent
		--,@NotesTitle = NotesTitle
		,@MEDICAIDRESOLID = NotesDescription
	FROM inserted
	
	

	EXECUTE KYP.p_JournalEntry
		@MultipleCaseID = @MultipleCaseID,
		@AlertNo = @AlertNo,
		@AlertID = @AlertID,
		@CurrentWFStatus = @CurrentWFStatus,
		@JournalEvent = @JournalEvent,
		@Username = @Username,
		@Description = @Description,
		@PersonID = @PersonID,
		@AssignToUserID = @AssignToUserID,
		@NotesDescription = @NotesDescription,
		@NotesTitle = @NotesTitle,
		@Number = @Number,
		@FirstName = @FirstName,
		@LastName = @LastName,
		@Name = @Name,
		@NoteID = @NoteID,
		@CurrentDate = @CurrentDate,
		@Currenttag = @Currenttag,
		@Notenumber = @Notenumber,
		@Type = @Type,
		@SubType = @SubType,
		@RelatedEntityType = @RelatedEntityType,
		@JournalDescription = @JournalDescription,
		@CaseID = @CaseID,
		@NoteEntityType = @NoteEntityType,
		@NoteEntityTypeID = @NoteEntityTypeID,
		@NoteEntityDepID = @NoteEntityDepID,
		@NoteEntityDep = @NoteEntityDep,
		@Level = @Level,
		@SmartletParameter = @SmartletParameter,
		@IsLastLevel = @IsLastLevel,
		@RelatedEntityID = @RelatedEntityID,
		@FullName = @FullName,
		@IsExistID = @IsExistID,
		@NoteCount = @NoteCount,
		@IsExistCaseID = @IsExistCaseID,
		@CaseNoteCNT = @CaseNoteCNT,
		@InfoID = @InfoID,
		@body = @body,
		@EmailAddTo = @EmailAddTo,
		@EmailAddCC = @EmailAddCC,
		@Sub = @Sub,
		@ALIASNAME = @ALIASNAME,
		@MultipleTrackingNo = @MultipleTrackingNo,
		@DUPLICATEID = @DUPLICATEID,
		@MEDICAIDRESOLID = @MEDICAIDRESOLID,
		@WATCHRESOLUTIONNAME = @WATCHRESOLUTIONNAME,
		@WATCHRESOLUTIONPROVIDERMEDICAIDID = @WATCHRESOLUTIONPROVIDERMEDICAIDID,
		@WATCHDUMRESOLUTIONID = @WATCHDUMRESOLUTIONID,
		@ResolutionID = @ResolutionID,
		@PersonID_UpdateBy = @PersonID_UpdateBy,
		@FullName_UpdateBy = @FullName_UpdateBy,
		@ProvID = @ProvID,
		@ProvMedicaID = @ProvMedicaID,
		@NPI = @NPI,
		@FormattedContent = @FormattedContent

		
END


GO

