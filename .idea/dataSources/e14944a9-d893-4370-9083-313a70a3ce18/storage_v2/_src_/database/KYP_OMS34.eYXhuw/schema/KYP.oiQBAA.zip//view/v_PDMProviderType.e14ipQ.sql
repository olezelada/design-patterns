
CREATE VIEW [KYP].[v_PDMProviderType] As
Select row_number() OVER (ORDER BY ProviderTypeDescription ASC) AS ID,MAX(ProviderTypeCode) As ProviderTypeCode, ProviderTypeDescription FROM KYP.PDM_ProviderTypeCode 
GROUP BY ProviderTypeDescription


GO

