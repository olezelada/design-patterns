



CREATE VIEW [KYPEnrollment].[v_OutEDI_ORPFile_WeeklyReport]
AS
Select DISTINCT x.AccountID,AccountType,IsDeleted ,---,x.AccountUpdatedBy
NPI,SUBSTRING(LegalName,1,28) AS LegalName,SSN -- here 1 EMPTY field no data leave it blanck

,SUBSTRING(SAddressLine1,1,100) AS SAddressLine1,SUBSTRING(SAddressLine2,1,100) AS SAddressLine2,SUBSTRING(SCity,1,50) AS SCity
,SState,SZip,SZipPlus4
-- here 1 EMPTY field no data leave it blanck
,SUBSTRING(MAddressLine1,1,100) AS MAddressLine1,SUBSTRING(MAddressLine2,1,100) AS MAddressLine2,SUBSTRING(MCity,1,50) AS MCity
,MState as MStateO,MZip,MZipPlus4
,x.ProviderTypecode --This field check with Swati***
-- 5 occurence of "Provider DH-MCAL-ORP-ENROL-STAT-DATA Table 
,AccStatusValue1,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveBeginDate1),101) AS AccEffectiveBeginDate1 ,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveEndDate1),101) AS AccEffectiveEndDate1 
,AccStatusValue2,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveBeginDate2),101) AS AccEffectiveBeginDate2 ,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveEndDate2),101) AS AccEffectiveEndDate2
,AccStatusValue3,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveBeginDate3),101) AS AccEffectiveBeginDate3 ,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveEndDate3),101) AS AccEffectiveEndDate3
,AccStatusValue4,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveBeginDate4),101) AS AccEffectiveBeginDate4 ,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveEndDate4),101) AS AccEffectiveEndDate4
,AccStatusValue5,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveBeginDate5),101) AS AccEffectiveBeginDate5 ,convert(varchar(10),CONVERT(smalldatetime,AccEffectiveEndDate5),101) AS AccEffectiveEndDate5

,LicenseNumber,LicenseExpirationDate,ProvisionalCode,ProvisionalCodeDate,ReenrollmentIndicator,convert(varchar(10),convert(date,ReenrollmentDate),101)as ReenrollmentDate,AccountUpdateDate
from( 
Select A.AccountID,A.NPI,A.SSN,A.LegalName,A.StatusAcc,A.ReenrollmentIndicator,A.AccountUpdateDate,A.AccountType,A.IsDeleted,A.ProviderTypeCode --,A.AccountUpdatedBy
,g.AddressLine1 AS SAddressLine1,g.AddressLine2 AS SAddressLine2,g.City AS SCity,g.State AS SState,g.Zip as SZip, g.ZipPlus4 AS SZipPlus4
,F.AddressLine1 AS MAddressLine1,F.AddressLine2 AS MAddressLine2,F.City AS MCity,F.State AS MState,F.Zip as MZip,F.ZipPlus4 AS MZipPlus4 

,D.Number AS LicenseNumber,D.ExpirationDate AS LicenseExpirationDate
,E.ProvisionalCode,E.ProvisionalCodeDate,A.ReenrollmentDate
from KYPEnrollment.pADM_Account A
left outer join 
(select D.AddressLine1,D.AddressLine2,D.City,D.State,D.Zip,D.ZipPlus4,x.PartyID,x.Phone1,d.County  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)g
	 on g.PartyID = a.PartyID
--This is for Mailing Address Details
left outer join(select D.AddressLine1,D.AddressLine2,D.City,D.State,D.Zip,D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = a.PartyID
left outer join KYPEnrollment.pAccount_PDM_Number D on D.PartyID=A.PartyID AND D.Type='Professional License' AND D.CurrentRecordFlag=1
left outer join KYPEnrollment.EDM_AccountInternalUse E 
	on E.AccountID=A.AccountID 
	and E.CurrentRecordFlag = 1
	where A.IsDeleted=0  AND A.AccountType IN ('ORP'))
x
left outer join
( select AccountId, 
 AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
 ,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5

  from 
(   
	 
SELECT AccS.accountid,  CONVERT(varchar(20), StatusValue)as StatusValue
,'AccStatusValue'+CONVERT(varchar(10), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS

UNION ALL
SELECT AccS.accountid,  CONVERT(varchar(20), EffectiveBeginDate)as EffectiveBeginDate
,'AccEffectiveBeginDate'+CONVERT(varchar(15), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS
UNION ALL
SELECT AccS.accountid,  CONVERT(varchar(20), EffectiveEndDate)as EffectiveEndDate
,'AccEffectiveEndDate'+CONVERT(varchar(15), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS
   
)ML(AccountId,StatusValue,seq)
PIVOT (max(ml.StatusValue) 
FOR ml.seq IN (
AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5

)) pvt   )y
on x.AccountID= y.AccountId
  

--------------------------------------------- Close of ORP file---------------------------------------------------------------------------------------------------


GO

