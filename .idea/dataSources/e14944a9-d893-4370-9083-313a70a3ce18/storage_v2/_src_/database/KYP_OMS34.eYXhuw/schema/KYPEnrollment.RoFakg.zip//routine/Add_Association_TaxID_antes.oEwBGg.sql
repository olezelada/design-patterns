

CREATE PROCEDURE [KYPEnrollment].[Add_Association_TaxID_antes]
   @account_id             INT,
   @party_id_account       INT,
   @tax_id                 VARCHAR (10),
   @application_id         INT,
   @party_id_app           INT,
   @last_Action_User_ID    VARCHAR (100),
   @accepted               BIT,
   @application_type       VARCHAR (50) = NULL
AS
BEGIN
   SET  NOCOUNT ON

   IF @application_type = 'CHOW'
      BEGIN
         SET @accepted = 1;
      END

   DECLARE
      @date_Create   DATE,
      @profile_id    VARCHAR (40)
   --mvc--
   DECLARE
      @npi       VARCHAR (10),
      @ownerno   VARCHAR (3)

   SET @date_Create = GETDATE ()
   SELECT TOP 1
          @profile_id = ProfileID
   FROM KYPEnrollment.pAccount_BizProfile_Details
   WHERE AccountID = @account_id                    --AND CurrentRecordFlag=1;
   --mvc--
   SELECT @npi = npi,
          @ownerno = ownerno
   FROM kypenrollment.padm_account
   WHERE accountid = @account_id


   CREATE TABLE #PartyPortal
   (
      PartyID          INT,
      ParentPartyID    INT,
      Type             VARCHAR (50),
      IsPrepopulated   BIT,
      TargetPath       VARCHAR (200),
      UUID             VARCHAR (200),
      Partyenroll      VARCHAR (200)
   )

   INSERT INTO #PartyPortal
      SELECT PartyID,
             ParentPartyID,
             Type,
             IsPrepopulated,
             TargetPath,
             UUID,
             SUBSTRING (
                targetpath,
                CHARINDEX ('pAccount_PDM_Party|PartyID|', TargetPath, 1) + 27,
                LEN (targetpath))
                AS partyenroll
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
       WHERE     (   (       ParentPartyID = @party_id_app
                         AND (   Type = 'SubcontractorEntity'
                              OR Type = 'SubcontractorIndividual'
                              OR Type = 'TransactionEntity'
                              OR Type = 'TransactionIndividual'
                              OR Type = 'Entity Ownership'
                              OR Type = 'Individual Ownership')
                      OR (ParentPartyID IN
                             (SELECT PartyID
                                FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                               WHERE     ParentPartyID = @party_id_app
                                     AND (   Type = 'Entity Ownership'
                                          OR Type = 'Individual Ownership'))))
                  OR PartyID = @party_id_app)
             AND IsDeleted = 0;

   WITH PartyLevels (partyidlevel,
                     type,
                     IsPrepopulated,
                     partypadre,
                     partyabuelo,
                     partylevel,
                     partyenroll,
                     partyenrollmain,
                     UUID,
                     TargetPath,
                     Accepted,
                     IsPastOwner)
           AS (SELECT PartyID,
                      Type,
                      IsPrepopulated,
                      NULL,
                      NULL,
                      0 AS partylevel,
                      partyenroll,
                      NULL,
                      UUID,
                      TargetPath,
                      0,
                      0
                 FROM #PartyPortal
                WHERE ParentPartyID IS NULL
               UNION ALL
               SELECT p.PartyID,
                      p.Type,
                      p.IsPrepopulated,
                      pe.partyidlevel,
                      pe.partypadre,
                      partylevel + 1,
                      P.partyenroll,
                      NULL,
                      p.UUID,
                      p.TargetPath,
                      0,
                      0
                 FROM #PartyPortal AS p
                      INNER JOIN PartyLevels pe
                         ON p.ParentPartyID = pe.partyidlevel)
   SELECT *
     INTO #PartiesLevelTable
     FROM PartyLevels;

   UPDATE pl
      SET pl.partyenrollmain = partyAso.mainpartyid
     FROM #PartiesLevelTable pl
          INNER JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAso
             ON (ISNULL (pl.partyenroll, '') =
                    CONVERT (VARCHAR (10), partyAso.PartyID))
    WHERE IsPrepopulated = 1

   --mvc
   SELECT pl.*,
          partyaso.MainPartyID,
          partyAso.PartyID AS partyIDEnrollment,
          partyAso.AccountID,
          CONVERT (VARCHAR (40), ' ') AS ProfileID,
          CONVERT (VARCHAR (10), ' ') AS npi,
          CONVERT (VARCHAR (3), '') AS ownerno
     INTO #Associations
     FROM #PartiesLevelTable pl
          LEFT JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAso
             ON (ISNULL (pl.partyenrollmain, '') =
                    CONVERT (VARCHAR (10), partyAso.mainpartyID))

   UPDATE association
      SET association.ProfileID = details.ProfileID
     FROM KYPEnrollment.pAccount_BizProfile_Details details
          INNER JOIN #Associations association
             ON (association.AccountID = details.AccountID)

   UPDATE association
      SET association.Accepted = field.Accepted
     FROM #Associations association,
          [KYPPORTAL].[PortalKYP].[FieldValuesTracking] field
    WHERE     (   association.UUID = field.RowUUID
               OR association.TargetPath = field.TargetPath)
          AND field.ApplicationID = @application_id
          AND (IsPrepopulated IS NULL OR IsPrepopulated = 0)

   --mvc
   UPDATE association
      SET association.IsPastOwner = account.IsPastOwner,
          npi = account.npi,
          ownerno = account.ownerno
     FROM KYPEnrollment.pADM_Account account
          INNER JOIN #Associations association
             ON (association.AccountID = account.AccountID)

   --add new column for packagename
   ---update packagename of account
   --mvc
   DECLARE @TaxIDParty TABLE
                       (
                          parent_party_acc   INT,
                          account_id_asso    INT,
                          PackageName        VARCHAR (100)
                       )

   INSERT INTO @TaxIDParty
      SELECT ass.PartyID, ass.AccountID, acc.packagename
        FROM KYPEnrollment.pAccount_TaxID_Associate ass
             INNER JOIN kypenrollment.pADM_Account acc
                ON ass.accountid = acc.accountid
       WHERE     TaxID = @tax_id
             AND ass.PartyID != @party_id_account
             AND ass.CurrentRecordFlag = 1
             AND OwnerNo = @ownerno


   DELETE @TaxIDParty
    WHERE account_id_asso NOT IN
             (SELECT AccountID
                FROM KYPEnrollment.pAccount_BizProfile_Details
               WHERE ProfileID = @profile_id);

   DELETE #Associations
    WHERE (    ProfileID <> @profile_id
           AND ProfileID <> ''
           AND ProfileID IS NOT NULL);

   --validate duplicate moca

   CREATE TABLE #mocaexist
   (
      partyid     INT,
      type        VARCHAR (100),
      accountid   INT,
      ssn         VARCHAR (100),
      firstname   VARCHAR (200),
      lastname    VARCHAR (200),
      legalname   VARCHAR (200),
      Tin         VARCHAR (100),
      moca        VARCHAR (200)
   )

   INSERT INTO #mocaexist
      SELECT part.partyid,
             part.type,
             part.accountid,
             per.ssn,
             per.firstname,
             per.lastname,
             org.legalname,
             org.ein,
             ISNULL (
                CONVERT (VARCHAR (200), ssn),
                isnull (
                   CONVERT (VARCHAR (200), ein),
                   isnull (CONVERT (VARCHAR (200), legalname),
                           isnull (lastname, '') + isnull (firstname, ''))))
                AS aux
        FROM @TaxIDParty taxp
             INNER JOIN kypenrollment.paccount_pdm_party part
                ON taxp.parent_party_acc = part.parentpartyid
             LEFT JOIN kypenrollment.paccount_pdm_person per
                ON part.partyid = per.partyid
             LEFT JOIN kypenrollment.paccount_pdm_organization org
                ON part.partyid = org.partyid
       WHERE     part.CurrentRecordFlag = 1
             AND part.type IN ('Entity Ownership',
                               'Individual Ownership',
                               'SubcontractorIndividual',
                               'SubcontractorEntity',
                               'TransactionIndividual',
                               'TransactionEntity')

   INSERT INTO #mocaexist
      SELECT part.partyid,
             part.type,
             part.accountid,
             per.ssn,
             per.firstname,
             per.lastname,
             org.legalname,
             org.ein,
             ISNULL (
                CONVERT (VARCHAR (200), per.ssn),
                isnull (
                   CONVERT (VARCHAR (200), org.ein),
                   isnull (
                      CONVERT (VARCHAR (200), org.legalname),
                      isnull (per.lastname, '') + isnull (per.firstname, ''))))
                AS aux
        FROM #mocaexist taxp
             INNER JOIN kypenrollment.paccount_pdm_party part
                ON taxp.partyid = part.parentpartyid
             LEFT JOIN kypenrollment.paccount_pdm_person per
                ON part.partyid = per.partyid
             LEFT JOIN kypenrollment.paccount_pdm_organization org
                ON part.partyid = org.partyid
       WHERE     part.CurrentRecordFlag = 1
             AND part.type IN
                    ('OtherOwnershipIndividual', 'OtherOwnershipEntity')


   SELECT taxp.account_id_asso,
          taxp.parent_party_acc,
          taxp.PackageName,
          part.*,
          ISNULL (
             CONVERT (VARCHAR (200), per.ssn),
             isnull (
                CONVERT (VARCHAR (200), org.ein),
                isnull (
                   CONVERT (VARCHAR (200), org.legalname),
                   isnull (per.lastname, '') + isnull (per.firstname, ''))))
             AS moca
     INTO #associations1
     FROM #Associations part
          LEFT JOIN kypportal.portalkyp.ppdm_person per
             ON part.partyidlevel = per.partyid
          LEFT JOIN kypportal.portalkyp.ppdm_organization org
             ON part.partyidlevel = org.partyid
          CROSS JOIN @TaxIDParty taxp


   SELECT a.*
     INTO #associations2
     FROM #associations1 a
          LEFT JOIN #mocaexist b
             ON     a.type = b.type
                AND a.moca = b.moca
                AND a.account_id_asso = b.accountid
    WHERE b.PartyID IS NULL


   --  1 level
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate)
      SELECT #Associations2.Type,
             #Associations2.parent_party_acc,
             #Associations2.account_id_asso,
             #Associations2.Partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM #Associations2
       WHERE     #Associations2.type IN ('Individual Ownership',
                                         'SubcontractorIndividual',
                                         'SubcontractorEntity',
                                         'TransactionEntity',
                                         'TransactionIndividual')
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND #Associations2.account_id_asso NOT IN
                    (SELECT AccountID
                       FROM #Associations2
                      WHERE IsPastOwner = 1)

   --not add entity ownership in packagename in (IGSP_P_DM  para physicians,IGSP_NP_AP       para allied)
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate)
      SELECT #Associations2.Type,
             #Associations2.parent_party_acc,
             #Associations2.account_id_asso,
             #Associations2.Partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM #Associations2
       WHERE     #Associations2.PackageName NOT IN
                    ('IGSP_P_DM', 'IGSP_NP_AP')
             AND #Associations2.type IN ('Entity Ownership')
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND #Associations2.account_id_asso NOT IN
                    (SELECT AccountID
                       FROM #Associations2
                      WHERE IsPastOwner = 1)


   --2 level
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate)
      SELECT #Associations2.type,
             [KYPEnrollment].[pAccount_PDM_Party].PartyID,
             [KYPEnrollment].[pAccount_PDM_Party].AccountID,
             #Associations2.partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM #Associations2
             INNER JOIN [KYPEnrollment].[pAccount_PDM_Party]
                ON [KYPEnrollment].[pAccount_PDM_Party].TempPartyID =
                      #Associations2.partypadre
       WHERE     #Associations2.type NOT IN ('Entity Ownership',
                                             'Individual Ownership',
                                             'SubcontractorIndividual',
                                             'SubcontractorEntity',
                                             'TransactionEntity',
                                             'TransactionIndividual')
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND [KYPEnrollment].[pAccount_PDM_Party].AccountID !=
                    @account_id
             AND #Associations2.IsPastOwner = 0

   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] (Type,
                                                     ParentPartyID,
                                                     AccountID,
                                                     TempPartyID,
                                                     IsDeleted,
                                                     CurrentRecordFlag,
                                                     LastAction,
                                                     LastActorUserID,
                                                     LastActionApprovedBy,
                                                     LastActionDate)
      SELECT #Associations2.type,
             associacioAcco.partyIDEnrollment,
             associacioAcco.AccountID,
             #Associations2.partyidlevel,
             0,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM #Associations2
             INNER JOIN #Associations2 AS associacioAcco
                ON #Associations2.partypadre = associacioAcco.partyidlevel
       WHERE     associacioAcco.IsPrepopulated = 1
             AND associacioAcco.ProfileID = @profile_id
             AND (   #Associations2.IsPrepopulated IS NULL
                  OR #Associations2.IsPrepopulated = 0)
             AND #Associations2.Accepted = @accepted
             AND associacioAcco.AccountID IS NOT NULL
             AND associacioAcco.AccountID != @account_id
             AND #Associations2.IsPastOwner = 0
             AND associacioAcco.IsPastOwner = 0

   --1 level
   /*INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
   (Type,ParentPartyID,AccountID,TempPartyID,IsDeleted,CurrentRecordFlag,LastAction,LastActorUserID,LastActionApprovedBy,LastActionDate )
    SELECT  #Associations.Type,parent_party_acc,account_id_asso,#Associations.Partyidlevel,0,1,'C',@last_Action_User_ID,@last_Action_User_ID,@date_Create  FROM #Associations cross join @taxidparty
    WHERE #Associations.type IN('Individual Ownership','SubcontractorIndividual','SubcontractorEntity','TransactionEntity','TransactionIndividual')
    AND (#Associations.IsPrepopulated IS NULL OR #Associations.IsPrepopulated =0) AND #Associations.Accepted = @accepted AND account_id_asso NOT IN (SELECT AccountID  FROM #Associations WHERE IsPastOwner = 1 )

   --not add entity ownership in packagename in (IGSP_P_DM  para physicians,IGSP_NP_AP       para allied)
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
   (Type,ParentPartyID,AccountID,TempPartyID,IsDeleted,CurrentRecordFlag,LastAction,LastActorUserID,LastActionApprovedBy,LastActionDate )
    SELECT  #Associations.Type,parent_party_acc,account_id_asso,#Associations.Partyidlevel,0,1,'C',@last_Action_User_ID,@last_Action_User_ID,@date_Create  FROM #Associations cross join @taxidparty tax
    WHERE tax.PackageName not in ('IGSP_P_DM','IGSP_NP_AP' ) and #Associations.type IN('Entity Ownership')
    AND (#Associations.IsPrepopulated IS NULL OR #Associations.IsPrepopulated =0) AND #Associations.Accepted = @accepted AND account_id_asso NOT IN (SELECT AccountID  FROM #Associations WHERE IsPastOwner = 1 )


   --2 level
   INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
   (Type,ParentPartyID,AccountID,TempPartyID,IsDeleted,CurrentRecordFlag,LastAction,LastActorUserID,LastActionApprovedBy,LastActionDate )
    SELECT #Associations.type, [KYPEnrollment].[pAccount_PDM_Party].PartyID,[KYPEnrollment].[pAccount_PDM_Party].AccountID,#Associations.partyidlevel,0,1,'C',@last_Action_User_ID,@last_Action_User_ID,@date_Create FROM #Associations
    INNER JOIN  [KYPEnrollment].[pAccount_PDM_Party] ON [KYPEnrollment].[pAccount_PDM_Party].TempPartyID=#Associations.partypadre
    WHERE #Associations.type  NOT IN('Entity Ownership','Individual Ownership','SubcontractorIndividual','SubcontractorEntity','TransactionEntity','TransactionIndividual')
    AND (#Associations.IsPrepopulated IS NULL OR #Associations.IsPrepopulated =0) AND #Associations.Accepted = @accepted  AND [KYPEnrollment].[pAccount_PDM_Party].AccountID != @account_id
    AND #Associations.IsPastOwner = 0

    INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
   (Type,ParentPartyID,AccountID,TempPartyID,IsDeleted,CurrentRecordFlag,LastAction,LastActorUserID,LastActionApprovedBy,LastActionDate )
     SELECT #Associations.type, associacioAcco.partyIDEnrollment,associacioAcco.AccountID,#Associations.partyidlevel,0,1,'C',@last_Action_User_ID,@last_Action_User_ID,@date_Create FROM #Associations INNER JOIN #Associations AS associacioAcco ON  #Associations.partypadre = associacioAcco.partyidlevel
     WHERE associacioAcco.IsPrepopulated = 1 AND associacioAcco.ProfileID = @profile_id  AND (#Associations.IsPrepopulated IS NULL OR #Associations.IsPrepopulated =0) AND #Associations.Accepted = @accepted AND associacioAcco.AccountID IS NOT NULL AND associacioAcco.AccountID != @account_id
     AND #Associations.IsPastOwner = 0  AND associacioAcco.IsPastOwner = 0

    */
   /*PERSON*/
   DECLARE @Person_Table TABLE
                         (
                            ID                  INT IDENTITY (1, 1),
                            PersonID            INT,
                            PartyID             INT,
                            SSN                 VARCHAR (11),
                            FirstName           VARCHAR (25),
                            LastName            VARCHAR (25),
                            MiddleName          VARCHAR (25),
                            ProfessionalTitle   VARCHAR (50),
                            DoB                 DATETIME,
                            IsDeleted           BIT,
                            TargetPath          VARCHAR (200)
                         )

   INSERT INTO @Person_Table
      SELECT PersonID,
             PartyID,
             SSN,
             FirstName,
             LastName,
             MiddleName,
             ProfessionalTitle,
             DoB,
             Deleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Person]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ORGANIZATION*/
   DECLARE @Organization_Table TABLE
                               (
                                  ID              INT IDENTITY (1, 1),
                                  OrgID           INT,
                                  PartyID         INT,
                                  LegalName       VARCHAR (100),
                                  DBAName1        VARCHAR (MAX),
                                  Phone1          VARCHAR (15),
                                  Remarks         VARCHAR (25),
                                  NPI             VARCHAR (10),
                                  EIN             VARCHAR (30),
                                  IsCorporation   BIT,
                                  Extension       VARCHAR (12),
                                  BusinessName    VARCHAR (200),
                                  IsDeleted       BIT,
                                  TargetPath      VARCHAR (200)
                               )

   INSERT INTO @Organization_Table
      SELECT OrgID,
             PartyID,
             LegalName,
             DBAName1,
             Phone1,
             Remarks,
             NPI,
             EIN,
             IsCorporation,
             Extension,
             BusinessName,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ADDRESS LOCATION*/
   DECLARE @Address_Table TABLE
                          (
                             ID              INT IDENTITY (1, 1),
                             PartyID         INT,
                             AddressID       INT,
                             LocationID      INT,
                             AddressLine1    VARCHAR (250),
                             AddressLine2    VARCHAR (50),
                             County          VARCHAR (25),
                             City            VARCHAR (25),
                             ZipPlus4        VARCHAR (50),
                             State           VARCHAR (40),
                             IsDeleted       BIT,
                             TargetPathAdd   VARCHAR (200),
                             Type            VARCHAR (25),
                             IsDeletedLoc    BIT,
                             TargetPathLoc   VARCHAR (200)
                          )

   INSERT INTO @Address_Table
      SELECT location.PartyID,
             address.AddressID,
             location.LocationID,
             address.AddressLine1,
             address.AddressLine2,
             address.County,
             address.City,
             address.ZipPlus4,
             address.State,
             address.IsDeleted,
             address.TargetPath,
             location.Type,
             location.IsDeleted,
             location.TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] address,
             [KYPPORTAL].[PortalKYP].[pPDM_Location] location
       WHERE     address.AddressID = location.AddressID
             AND location.PartyID IN
                    (SELECT DISTINCT Partyidlevel
                       FROM #Associations2
                      WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*DOCUMENT*/
   DECLARE @Document_Table TABLE
                           (
                              ID           INT IDENTITY (1, 1),
                              DocumentID   INT,
                              PartyID      INT,
                              TypeDoc      VARCHAR (15),
                              NumberDoc    VARCHAR (16),
                              IsDeleted    BIT,
                              TargetPath   VARCHAR (200)
                           )

   INSERT INTO @Document_Table
      SELECT DocumentID,
             PartyID,
             TypeDoc,
             NumberDoc,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Document]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*TRANSACTION*/
   DECLARE @Trasaction_Table TABLE
                             (
                                ID              INT IDENTITY (1, 1),
                                TransactionID   INT,
                                PartyID         INT,
                                Description     VARCHAR (150),
                                Amount          VARCHAR (10),
                                IsDeleted       BIT,
                                TargetPath      VARCHAR (200)
                             )

   INSERT INTO @Trasaction_Table
      SELECT TransactionID,
             PartyID,
             Description,
             Amount,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnerhipTransaction]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*Owner Relation*/
   DECLARE @Ownership_Relationship_Table TABLE
                                         (
                                            ID                     INT IDENTITY (1, 1),
                                            OwnerRelationID        INT,
                                            PartyIdOwner           INT,
                                            PartyIdOwned           INT,
                                            TypeAssociation        VARCHAR (100),
                                            FamiliarRelationship   VARCHAR (50),
                                            IsDeleted              BIT,
                                            TargetPath             VARCHAR (200)
                                         )

   INSERT INTO @Ownership_Relationship_Table
      SELECT OwnerRelationID,
             PartyIdOwner,
             PartyIdOwned,
             TypeAssociation,
             FamiliarRelationship,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
       WHERE    PartyIdOwner IN
                   (SELECT DISTINCT Partyidlevel
                      FROM #Associations2
                     WHERE Type <> 'Provider' AND IsPastOwner = 0)
             OR PartyIdOwned IN
                   (SELECT DISTINCT Partyidlevel
                      FROM #Associations2
                     WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ROLE*/
   DECLARE @Role_Table TABLE
                       (
                          ID                INT IDENTITY (1, 1),
                          PdmOwnerID        INT,
                          PartyID           INT,
                          TypeForm          VARCHAR (100),
                          PercentCheck      BIT,
                          PercentValue      VARCHAR (150),
                          Partner           BIT,
                          PartnerValue      VARCHAR (150),
                          Managing          BIT,
                          Director          BIT,
                          DirectorValue     VARCHAR (150),
                          Other             BIT,
                          OtherValue        VARCHAR (150),
                          IsDeleted         BIT,
                          PercentDate       SMALLDATETIME,
                          PartnerDate       SMALLDATETIME,
                          ManagingDate      SMALLDATETIME,
                          OtherDate         SMALLDATETIME,
                          Agent             BIT,
                          OwnerRelationID   INT,
                          SoleOwner         BIT,
                          TargetPath        VARCHAR (200)
                       )

   INSERT INTO @Role_Table
      SELECT PdmOwnerID,
             PartyID,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             OwnerRelationID,
             SoleOwner,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role]
       WHERE    PartyID IN (SELECT DISTINCT Partyidlevel
                              FROM #Associations2
                             WHERE Type <> 'Provider' AND IsPastOwner = 0)
             OR OwnerRelationID IN
                   (SELECT DISTINCT OwnerRelationID
                      FROM @Ownership_Relationship_Table
                     WHERE    PartyIdOwner IN
                                 (SELECT DISTINCT Partyidlevel
                                    FROM #Associations2
                                   WHERE     Type <> 'Provider'
                                         AND IsPastOwner = 0)
                           OR PartyIdOwned IN
                                 (SELECT DISTINCT Partyidlevel
                                    FROM #Associations2
                                   WHERE     Type <> 'Provider'
                                         AND IsPastOwner = 0))

   /*PROVIDER*/
   DECLARE @Provider_Table TABLE
                           (
                              ID           INT IDENTITY (1, 1),
                              ProvID       INT,
                              PartyID      INT,
                              NPI          BIGINT,
                              IsDeleted    BIT,
                              TargetPath   VARCHAR (200)
                           )

   INSERT INTO @Provider_Table
      SELECT ProvID,
             PartyID,
             NPI,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Provider]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*ADVERSE ACTION*/
   DECLARE @Adverse_Action_Table TABLE
                                 (
                                    ID                INT IDENTITY (1, 1),
                                    AdverseActionID   INT,
                                    PartyID           INT,
                                    Type_x            VARCHAR (100),
                                    Date_x            DATETIME,
                                    EffectiveDate     DATETIME,
                                    ProgramType       VARCHAR (50),
                                    Where_x           VARCHAR (100),
                                    Action_x          VARCHAR (1000),
                                    IsDeleted         BIT,
                                    TargetPath        VARCHAR (200)
                                 )

   INSERT INTO @Adverse_Action_Table
      SELECT AdverseActionID,
             PartyID,
             Type_x,
             Date_x,
             EffectiveDate,
             ProgramType,
             Where_x,
             Action_x,
             IsDeleted,
             TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction]
       WHERE PartyID IN (SELECT DISTINCT Partyidlevel
                           FROM #Associations2
                          WHERE Type <> 'Provider' AND IsPastOwner = 0)

   /*INSERT*/
   INSERT INTO KYPEnrollment.pAccount_PDM_Person (PartyID,
                                                  SSN,
                                                  FirstName,
                                                  LastName,
                                                  MiddleName,
                                                  Salutation,
                                                  DoB,
                                                  Deleted,
                                                  CurrentRecordFlag,
                                                  LastAction,
                                                  LastActorUserID,
                                                  LastActionApprovedBy,
                                                  LastActionDate)
      SELECT party.PartyID,
             SSN,
             FirstName,
             LastName,
             MiddleName,
             person.ProfessionalTitle,
             DoB,
             person.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Person_Table person
                ON     (party.TempPartyID = person.PartyID)
                   AND person.IsDeleted = 0



   INSERT INTO KYPEnrollment.pAccount_PDM_Organization (PartyID,
                                                        LegalName,
                                                        DBAName1,
                                                        Phone1,
                                                        Remarks,
                                                        NPI,
                                                        EIN,
                                                        IsCorporation,
                                                        Extension,
                                                        BusinessName,
                                                        IsDeleted,
                                                        CurrentRecordFlag,
                                                        LastAction,
                                                        LastActionApprovedBy,
                                                        LastActorUserID,
                                                        LastActionDate)
      SELECT party.PartyID,
             LegalName,
             DBAName1,
             Phone1,
             Remarks,
             NPI,
             EIN,
             IsCorporation,
             Extension,
             BusinessName,
             org.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Organization_Table org
                ON (party.TempPartyID = org.PartyID) AND org.IsDeleted = 0


   INSERT INTO KYPEnrollment.pAccount_PDM_Address (
                  TempAddressID,
                  AddressLine1,
                  AddressLine2,
                  County,
                  City,
                  ZipPlus4,
                  State,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedByUsedID,
                  LastActionUserID,
                  LastActionDate)
      SELECT   CONVERT (VARCHAR (10), address.PartyID)
             + '-'
             + CONVERT (VARCHAR (10), party.PartyID),
             AddressLine1,
             AddressLine2,
             County,
             City,
             ZipPlus4,
             State,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Address_Table address
                ON     (party.TempPartyID = address.PartyID)
                   AND address.IsDeleted = 0


   INSERT INTO KYPEnrollment.pAccount_PDM_Location (PartyID,
                                                    AddressID,
                                                    Type,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate)
      SELECT DISTINCT
             CONVERT (
                INT,
                SUBSTRING (address.TempAddressID,
                           charindex ('-', address.TempAddressID, 1) + 1,
                           LEN (address.TempAddressID))),
             address.AddressID,
             location.Type,
             IsDeletedLoc,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Address_Table location
             INNER JOIN KYPEnrollment.pAccount_PDM_Address address
                ON     SUBSTRING (
                          ISNULL (address.TempAddressID, ''),
                          1,
                            charindex ('-',
                                       ISNULL (address.TempAddressID, '-'),
                                       1)
                          - 1) = CONVERT (VARCHAR (10), location.PartyID)
                   AND location.IsDeletedLoc = 0


   INSERT INTO KYPEnrollment.pAccount_PDM_Document (PartyID,
                                                    TypeDoc,
                                                    NumberDoc,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate)
      SELECT party.PartyID,
             TypeDoc,
             NumberDoc,
             document.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Document_Table document
                ON     (party.TempPartyID = document.PartyID)
                   AND document.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_OwnerhipTransaction (
                  PartyID,
                  Description,
                  Amount,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate)
      SELECT party.PartyID,
             Description,
             Amount,
             transactions.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Trasaction_Table transactions
                ON     (party.TempPartyID = transactions.PartyID)
                   AND transactions.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_Provider (PartyID,
                                                    NPI,
                                                    IsDeleted,
                                                    CurrentRecordFlag,
                                                    LastAction,
                                                    LastActionApprovedBy,
                                                    LastActorUserID,
                                                    LastActionDate)
      SELECT party.PartyID,
             NPI,
             provider.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Provider_Table provider
                ON     (party.TempPartyID = provider.PartyID)
                   AND provider.IsDeleted = 0

   /*OWNER RELATIONSHIP*/

   INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] (
                  TempRelationshipID,
                  DateCreated,
                  PartyIDOwner,
                  PartyIDOwned,
                  TypeAssociation,
                  FamiliarRelationship,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate)
      SELECT relation.OwnerRelationID,
             @date_Create,
             asso.partyIDEnrollment AS ownerEnroll,
             asso2.partyIDEnrollment,
             TypeAssociation,
             FamiliarRelationship,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations2 asso
                ON relation.PartyIDOwner = asso.partyidlevel
             INNER JOIN #Associations2 asso2
                ON relation.PartyIDOwned = asso2.partyidlevel
       WHERE     asso.AccountID = asso2.AccountID
             AND relation.IsDeleted = 0
             AND relation.TargetPath NOT LIKE
                    'pAccount_PDM_OwnershipRelationship%'
             AND asso.IsPrepopulated = 1
             AND asso2.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso2.ProfileID = @profile_id
             AND asso.AccountID != @account_id
             AND asso.IsPastOwner = 0
             AND asso2.IsPastOwner = 0
      UNION ALL
      /*owner prepo owned new*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             asso.partyIDEnrollment AS ownerEnroll,
             party.PartyID,
             TypeAssociation,
             FamiliarRelationship,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations2 asso
                ON relation.PartyIDOwner = asso.partyidlevel
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwned = party.TempPartyID
       WHERE     asso.AccountID = party.AccountID
             AND asso.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso.IsPastOwner = 0
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations2 assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND relation.IsDeleted = 0
             AND asso.AccountID != @account_id
      UNION ALL
      /*owner new owned prep*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             party.PartyID,
             asso.partyIDEnrollment AS ownerEnroll,
             TypeAssociation,
             FamiliarRelationship,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN #Associations2 asso
                ON relation.PartyIDOwned = asso.partyidlevel
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwner = party.TempPartyID
       WHERE     asso.AccountID = party.AccountID
             AND asso.IsPrepopulated = 1
             AND asso.ProfileID = @profile_id
             AND asso.IsPastOwner = 0
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations2 assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND relation.IsDeleted = 0
             AND party.AccountID != @account_id
      UNION ALL
      /*owner new and new owned*/
      SELECT relation.OwnerRelationID,
             @date_Create,
             party.PartyID,
             party2.PartyID AS Partyowned,
             TypeAssociation,
             FamiliarRelationship,
             relation.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM @Ownership_Relationship_Table AS relation
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party
                ON relation.PartyIDOwner = party.TempPartyID
             INNER JOIN KYPEnrollment.pAccount_PDM_Party party2
                ON relation.PartyIDOwned = party2.TempPartyID
       WHERE     party.AccountID = party2.AccountID
             AND NOT EXISTS
                    (SELECT assoFine.partyidlevel
                       FROM #Associations2 assoFine
                      WHERE     assoFine.partyidlevel = party.TempPartyID
                            AND assoFine.IsPrepopulated = 1
                            AND assoFine.IsPastOwner = 0)
             AND NOT EXISTS
                    (SELECT assoExists.partyidlevel
                       FROM #Associations2 assoExists
                      WHERE     assoExists.partyidlevel = party2.TempPartyID
                            AND assoExists.IsPrepopulated = 1
                            AND assoExists.IsPastOwner = 0)
             AND relation.IsDeleted = 0
             AND party.AccountID != @account_id

   /*OWNER ROLE*/

   INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role (OwnerRelationID,
                                                      DateCreated,
                                                      TypeForm,
                                                      PercentCheck,
                                                      PercentValue,
                                                      Partner,
                                                      PartnerValue,
                                                      Managing,
                                                      Director,
                                                      DirectorValue,
                                                      Other,
                                                      OtherValue,
                                                      IsDeleted,
                                                      PercentDate,
                                                      PartnerDate,
                                                      ManagingDate,
                                                      OtherDate,
                                                      Agent,
                                                      SoleOwner,
                                                      CurrentRecordFlag,
                                                      LastAction,
                                                      LastActionApprovedBy,
                                                      LastActorUserID,
                                                      LastActionDate)
      SELECT relation.OwnerRelationID,
             @date_Create,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             ownerRole.IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             SoleOwner,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] relation
             INNER JOIN @Role_Table ownerRole
                ON     (relation.TempRelationshipID =
                           ownerRole.OwnerRelationID)
                   AND ownerRole.IsDeleted = 0

   INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role (PartyID,
                                                      DateCreated,
                                                      TypeForm,
                                                      PercentCheck,
                                                      PercentValue,
                                                      Partner,
                                                      PartnerValue,
                                                      Managing,
                                                      Director,
                                                      DirectorValue,
                                                      Other,
                                                      OtherValue,
                                                      IsDeleted,
                                                      PercentDate,
                                                      PartnerDate,
                                                      ManagingDate,
                                                      OtherDate,
                                                      Agent,
                                                      SoleOwner,
                                                      CurrentRecordFlag,
                                                      LastAction,
                                                      LastActionApprovedBy,
                                                      LastActorUserID,
                                                      LastActionDate)
      SELECT party.PartyID,
             @date_Create,
             TypeForm,
             PercentCheck,
             PercentValue,
             Partner,
             PartnerValue,
             Managing,
             Director,
             DirectorValue,
             Other,
             OtherValue,
             ownerRole.IsDeleted,
             PercentDate,
             PartnerDate,
             ManagingDate,
             OtherDate,
             Agent,
             SoleOwner,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Role_Table ownerRole
                ON (party.TempPartyID = ownerRole.PartyID)
       WHERE ownerRole.IsDeleted = 0

   /*ADVERSE ACTION*/
   INSERT INTO KYPEnrollment.pAccount_PDM_AdverseAction (
                  PartyID,
                  Type_x,
                  Date_x,
                  EffectiveDate,
                  ProgramType,
                  Where_x,
                  Action_x,
                  IsDeleted,
                  CurrentRecordFlag,
                  LastAction,
                  LastActionApprovedBy,
                  LastActorUserID,
                  LastActionDate)
      SELECT party.PartyID,
             Type_x,
             Date_x,
             EffectiveDate,
             ProgramType,
             Where_x,
             Action_x,
             adverseAction.IsDeleted,
             1,
             'C',
             @last_Action_User_ID,
             @last_Action_User_ID,
             @date_Create
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN @Adverse_Action_Table adverseAction
                ON     (party.TempPartyID = adverseAction.PartyID)
                   AND adverseAction.IsDeleted = 0


   INSERT INTO KYPEnrollment.pAccount_Party_Associate (MainPartyID,
                                                       PartyID,
                                                       AccountID,
                                                       Type,
                                                       CurrentRecordFlag)
      SELECT partyAssociation.MainPartyID,
             party.PartyID,
             party.AccountID,
             party.Type,
             1
        FROM KYPEnrollment.pAccount_PDM_Party party
             INNER JOIN
             KYPEnrollment.pAccount_Party_Associate partyAssociation
                ON party.TempPartyID = partyAssociation.IdentityPartyID
       WHERE     party.Type IN ('Entity Ownership',
                                'Individual Ownership',
                                'SubcontractorIndividual',
                                'SubcontractorEntity',
                                'TransactionEntity',
                                'TransactionIndividual')
             AND party.AccountID != @account_id


   --UPDATE KYPEnrollment.pAccount_PDM_Party SET TempPartyID = NULL
   UPDATE KYPEnrollment.pAccount_PDM_Address
      SET TempAddressID = NULL
    WHERE TempAddressID IS NOT NULL

   UPDATE KYPEnrollment.pAccount_PDM_OwnershipRelationship
      SET TempRelationshipID = NULL
    WHERE TempRelationshipID IS NOT NULL

   DROP TABLE #PartiesLevelTable
   DROP TABLE #PartyPortal
   DROP TABLE #Associations
   DROP TABLE #Associations2
   DROP TABLE #Associations1
   DROP TABLE #mocaexist
END


GO

