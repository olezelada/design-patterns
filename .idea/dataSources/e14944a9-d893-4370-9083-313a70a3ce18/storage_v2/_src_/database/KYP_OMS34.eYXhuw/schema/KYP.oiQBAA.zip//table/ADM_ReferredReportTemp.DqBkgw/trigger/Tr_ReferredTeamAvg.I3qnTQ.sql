



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[Tr_ReferredTeamAvg]
   ON  [KYP].[ADM_ReferredReportTemp]
   AFTER insert
AS 
BEGIN

	SET NOCOUNT ON;

	Declare @pFromDate datetime,
	@pToDate Datetime,
	@pProviderType varchar(3000),
	@pReferralTeam varchar(3000),
	@pIDValue int,
	@pUserId varchar(100)

	Select @pFromDate = FromDate,
			@pToDate = ToDate,
			@pProviderType = ProviderType,
			@pReferralTeam = ReferralTeam,
			@pIDValue = ID,
			@pUserId  = UserId
	From Inserted;
	
	--SELECT*
	--FROM iNSERTED;
	
	If (@pProviderType like '%Physician/Surgeon,%' or @pProviderType like '%Physician/Surgeon')
	Begin
		Set @pProviderType = @pProviderType+',Physicians/Surgeons'
	End
	
	Exec [KYP].[GetReferralTeamAvg] @pFromDate = @pFromDate,  @pToDate = @pToDate, @pProviderType  =@pProviderType, @pReferralTeam = @pReferralTeam, @pID = @pIDValue,@pUserId = @pUserId;
	

END


GO

