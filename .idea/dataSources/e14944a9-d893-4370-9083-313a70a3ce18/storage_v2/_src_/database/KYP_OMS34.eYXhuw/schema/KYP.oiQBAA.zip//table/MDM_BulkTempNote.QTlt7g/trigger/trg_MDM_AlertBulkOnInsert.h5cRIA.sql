
-- =============================================
-- Author:		Manikanta Donthu
-- Create date: 3/12/2014
-- Description:	it will call the bulk stored procedure.
-- =============================================
CREATE TRIGGER [KYP].[trg_MDM_AlertBulkOnInsert] ON [KYP].[MDM_BulkTempNote]
AFTER INSERT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @ID INT
		,@AlertID NVARCHAR(500)
		,@AlertNo NVARCHAR(500)
		,@AlertStatus NVARCHAR(50)
		,@Description NVARCHAR(max)
		,@Reasoncode VARCHAR(100)
		,@Snozzedate VARCHAR(100)
		,@DateChanged NVARCHAR(50)
		,@PartyIDAttribute VARCHAR(100)
		,@WatchlistPartyID VARCHAR(100)
		,@NoteTitle VARCHAR(max)
		,@SubType VARCHAR(50)
		,@AssignedToUser INT
		,@FormattedContent VARCHAR(MAX)

	SELECT @ID = ID
		,@AlertID = AlertID
		,@AlertNo = AlertNo
		,@AlertStatus = AlertStatus
		,@Description = [Description]
		,@Reasoncode = Reasoncode
		,@Snozzedate = Snozzedate
		,@DateChanged = DateChanged
		,@PartyIDAttribute = PartyIDAttribute
		,@WatchlistPartyID = WatchlistPartyID
		,@AssignedToUser = AssignedToUserID
		,@SubType = SubType
		,@FormattedContent = FormattedContent
	FROM INSERTED

	BEGIN
		DECLARE @PARTYID INT
			,@WatchedPartyType VARCHAR(50)
			,@OrganizationName VARCHAR(175)
			,@WatchlistName VARCHAR(175)
			,@FName VARCHAR(50)
			,@MName VARCHAR(50)
			,@LName VARCHAR(50)
			,@Assignee VARCHAR(250)
			,@AssignedToUserID INT
			,@MatchStatusIndicatorDesc VARCHAR(25)
			,@RowsToProcess INT
			,@CurrentRow INT
			,@T_AlertNo INT;
		DECLARE @temptab TABLE (
			RowID INT NOT NULL PRIMARY KEY identity(1, 1)
			,T_AlertNo INT
			)

		INSERT INTO @temptab (T_AlertNo)
		SELECT Data
		FROM dbo.split(@AlertNo, ',')

		SET @RowsToProcess = @@ROWCOUNT
		SET @CurrentRow = 0

		WHILE @CurrentRow < @RowsToProcess
		BEGIN
			SET @CurrentRow = @CurrentRow + 1

			SELECT @T_AlertNo = T_AlertNo
			FROM @temptab
			WHERE RowID = @CurrentRow

			SET @AlertNo = @T_AlertNo

			/*--------------UPDATE THE REASONCODE IN MDM_ALERT-----------------*/
			SELECT @MatchStatusIndicatorDesc = (
					CASE 
						WHEN @alertStatus = 'C'
							THEN 'Confirmed'
						WHEN @alertStatus = 'F'
							THEN 'False Positive'
						WHEN @alertStatus = 'I'
							THEN 'Ignored'
						WHEN @alertStatus = 'U'
							THEN 'Unconfirmed'
						ELSE @MatchStatusIndicatorDesc
						END
					)

			UPDATE KYP.MDM_Alert
			SET reasoncode = @reasoncode
				,matchstatusindicator = @alertStatus
				,MatchStatusIndicatorDesc = @MatchStatusIndicatorDesc
			WHERE AlertNo = @AlertNo

			/*--------------GETTING THE WATCHED PARTY TYPE IT IS INDIVIDUAL OR ORGANISATION-----------------*/
			SELECT @WatchedPartyType = WatchedPartyType
				,@AlertID = AlertID
				,@AssignedToUserID = AssignedToUserID
				,@PARTYID = WatchedPartyID
				,@WatchlistName = WatchlistName
			FROM KYP.MDM_Alert
			WHERE AlertNo = @AlertNo

			SELECT @Assignee = UserID
			FROM KYP.OIS_User
			WHERE PersonID = @AssignedToUser --(SELECT TOP 1 AssignedToUserID FROM KYP.MDM_BulkTempNote WHERE AlertID =@AlertID)

			IF LTRIM(RTRIM(ISNULL(@Assignee, ' '))) = ''
			BEGIN
				SET @Assignee = 'system';
			END

			SELECT @WatchlistPartyID = NPIID
			FROM KYP.MDM_AlertDetail
			WHERE AlertID = @AlertID

			IF @WatchedPartyType = 'Individual'
			BEGIN
				SELECT @FName = [FName]
					,@LName = [LName]
					,@MName = [MName]
				FROM KYP.MDM_AlertDetail
				WHERE AlertID = @AlertID

				SET @OrganizationName = NULL;
			END
			ELSE
			BEGIN
				SET @FName = NULL;
				SET @LName = NULL;
				SET @MName = NULL;

				SELECT @OrganizationName = OrganizationName
				FROM KYP.MDM_AlertDetail
				WHERE AlertID = @AlertID
			END

			IF @SubType = 'Disposition'
			BEGIN
				INSERT INTO KYP.MDM_JournalBasicInfo (
					UserName
					,AlertNo
					,AssignToUserID
					,NotesDescription
					,NotesTitle
					,RelatedEntityType
					,RelatedEntityID
					,Type
					,SubType
					,FormattedContent
					)
				VALUES (
					@Assignee
					,@AlertNo
					,@AssignedToUserID
					,@description
					,@NoteTitle
					,'MDM_Alert'
					,@AlertID
					,'Disposition'
					,'Disposition'
					,@FormattedContent
					)
			END

			IF LTRIM(RTRIM(ISNULL(@snozzedate, ''))) = '5'
			BEGIN
				DELETE
				FROM KYP.MDM_FalsePositiveAlert
				WHERE AlertID = @AlertID

				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertID
					)
				VALUES (
					CONVERT(VARCHAR(10), @PARTYID)
					,CONVERT(VARCHAR(10), GETDATE() + 90, 126)
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
			ELSE IF LTRIM(RTRIM(ISNULL(@snozzedate, ''))) = '6'
			BEGIN
				DELETE
				FROM KYP.MDM_FalsePositiveAlert
				WHERE AlertID = @AlertID

				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertID
					)
				VALUES (
					CONVERT(VARCHAR(10), @PARTYID)
					,DATEADD(DAY, - 1, (DATEADD(MONTH, 6, GETDATE())))
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
			ELSE IF LTRIM(RTRIM(ISNULL(@snozzedate, ''))) = '7'
			BEGIN
				DELETE
				FROM KYP.MDM_FalsePositiveAlert
				WHERE AlertID = @AlertID

				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertID
					)
				VALUES (
					CONVERT(VARCHAR(10), @PARTYID)
					,DATEADD(DAY, - 1, (DATEADD(MONTH, 12, GETDATE())))
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);

				SET @snozzedate = '6'
			END
			ELSE
			BEGIN
				SET @snozzedate = NULL

				DELETE
				FROM KYP.MDM_FalsePositiveAlert
				WHERE AlertID = @AlertID

				INSERT INTO [KYP].MDM_FalsePositiveAlert (
					PartyID
					,SnoozeDate
					,WatchlistName
					,FName
					,MName
					,LName
					,OrganizationName
					,WatchedPartyType
					,AlertStatus
					,DataChanged
					,PartyIDAttribute
					,WatchlistPartyID
					,AlertID
					)
				VALUES (
					CONVERT(VARCHAR(10), @PARTYID)
					,@snozzedate
					,@WatchlistName
					,@FName
					,@MName
					,@LName
					,@OrganizationName
					,@WatchedPartyType
					,@alertStatus
					,@dateChanged
					,@PartyIDAttribute
					,@WatchlistPartyID
					,@AlertID
					);
			END
		END
	END

	DELETE
	FROM [KYP].[MDM_BulkTempNote]
	WHERE AlertID = @AlertID
		AND ID <> @ID
END


GO

