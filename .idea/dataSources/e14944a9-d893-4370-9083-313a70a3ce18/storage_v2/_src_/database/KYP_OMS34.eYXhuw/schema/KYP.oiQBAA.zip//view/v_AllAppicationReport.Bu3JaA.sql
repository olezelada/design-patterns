


CREATE VIEW [KYP].[v_AllAppicationReport] 
AS
	SELECT 
	ROW_NUMBER() over(order by A.DateReceived Desc) As RID,
	A.CaseID,
	A.ProviderName,A.Number,
	COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
	COALESCE(LTRIM(RTRIM(NULLIF(A.ApplnTypeAlias,''))),'NA') As ApplnType,
	COALESCE(LTRIM(RTRIM(NULLIF(A.TypeDescription	,''))),'NA') As TypeDescription,
	cast(A.DateReceived as datetime) As DateReceived,
	CASE WHEN A.RTPDateCreated is not null then convert(varchar(10),A.RTPDateCreated,101) else 'NA' END As RTPDateCreated,
	CASE WHEN  A.Resubmitted='-R' then convert(varchar(10),A.DateReceived,101) else 'NA' END As ResubmittedDate,
	CASE WHEN A.ReferralDate is not null then convert(varchar(10),A.ReferralDate,101) else 'NA' END As ReferralDate,
	CASE WHEN A.DateCreated is not null then convert(varchar(10),A.DateCreated,101) else 'NA' END As OriginalSubmissionDate,
	CASE WHEN A.ReferralDate > A.RevertDate Then 'NA'  else  COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.RevertDate as date), 101),''))),'NA')  END As RevertDate,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DateResolved as date), 101),''))),'NA') As DateResolvedVarChar,
	Cast(A.DateResolved as datetime)As DateResolved,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DueDate as date), 101),''))),'NA') As DueDate,
	COALESCE((NULLIF(A.UserFullName,'')),'NA') As UserFullName,
	CASE WHEN A.ResolutionStatus='Approved' then 'Approve' else COALESCE(LTRIM(RTRIM(NULLIF(A.ResolutionStatus,''))),'NA')  
	 END As ResolutionStatus,
	CASE WHEN A.ResolutionStatus='Denied' then A.ReviewStatus else 'NA' END As DenialReason,  
	A.WFStatus,A.IsPPURequired,A.MILESTONE,
	CASE WHEN D.Notes is not null then D.Notes else 'NA' END As Explanation
FROM KYP.ADM_Case A INNER JOIN KYP.ADM_Application B on A.CaseID = B.CaseID
Left join (Select ApplicationID,MAX(ResolutionID) ResolutionID
			From KYP.SDM_Resolution
			Group By ApplicationID) C ON B.ApplicationID = C.ApplicationID
Left Join KYP.SDM_Resolution D on C.ResolutionID = D.ResolutionID			
WHERE A.IsPPURequired = 0  AND A.WFProcessing = 0


GO

