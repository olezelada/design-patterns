CREATE PROCEDURE [dbo].[LoadProvidernameAddress] 
AS	
BEGIN
	
	--[dbo].[Monitoring_ProviderNameAddress]
	insert into [dbo].[Monitoring_ProviderNameAddress](
		P_ID,
		P_NPI_NUM,P_TY_CD,P_FED_TAX_ID,P_SSN_NUM,DH_ENROL_STAT_CD_1,
		DH_OWNER_NUM,DH_SERV_LOC_NUM,ProviderType,P_AccNo,STAT_EFF_DT,
		P_DEA_NUM,
		P_PRACT_TY_CD,
		P_DOB_DT,P_LAST_NAM,P_FST_NAM,P_MI_NAM,P_SFX_NAM,
		P_NAM
		,FileType,FileSource,
		P_LINE1_AD,
		P_LINE2_AD,
		P_CITY_NAM,
		P_ST_CD,
		P_ZIP5_CD,
		P_ZIP4_CD
		,P_LINE1_AD2,
		P_LINE2_AD2,
		P_CITY_NAM2,
		P_ST_CD2,
		P_ZIP5_CD2,
		P_ZIP4_CD2,
		P_LINE1_AD3,
		P_LINE2_AD3,
		P_CITY_NAM3,
		P_ST_CD3,
		P_ZIP5_CD3,
		P_ZIP4_CD3,
		DH_PROV_TELE_NO
		)
			
		select 
		--Mapping AccountNumber instead of AccountID to P_ID after DA team suggestion
		Cast(isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,'') as varchar(20)), 
		cast(A.NPI as varchar(10)),
		cast(A.ProviderTypeCode as varchar(20)),
		cast(A.EIN as varchar(9)),
		cast(A.SSN as varchar(9)),
		cast(left(A.StatusAcc,1)  as varchar(1))  StatusAcc,
		cast(A.OwnerNo  as varchar(2)),
		cast(A.ServiceLocationNo  as varchar(3)),
		cast(A.NPITYPE  as varchar(50)),
		cast(A.AccountID as varchar(50)),cast(A.StatusBeginDate as smalldatetime),
		cast(B.DEA as varchar(11)),
		cast(C.PracTypeCode as varchar(3)),
		convert(varchar(10),D.DOB,101) as DOB,
		cast(D.LastName  as varchar(50)),cast(D.FirstName  as varchar(50)),
		cast(left(D.MiddleName,1)  as varchar(1)),cast(D.Sufix  as varchar(10)),
		cast(NULL as varchar(200)) as LegalName
		,'M','M',
		---City size change from 20 to 25(Max account address table) on 31Aug2018
		cast(SA.AddressLine1 as varchar(50)) ,cast(SA.AddressLine2 as varchar(50)) SA2,cast(SA.City as varchar(25)) SACty,cast(SA.State as varchar(2)) SASt, cast(SA.Zip as varchar(5)) SAZp,cast(SA.Zip4 as varchar(4)) SAZ4
		,cast(PA.AddressLine1 as varchar(50)), cast(PA.AddressLine2 as varchar(50)) PA2,cast(PA.City as varchar(25)) PACty,cast(PA.State as varchar(2)) PASt,cast(PA.Zip as varchar(5)) PAZP,cast(PA.Zip4 as varchar(4)) PAZ4,
		cast(MA.AddressLine1 as varchar(50)), cast(MA.AddressLine2 as varchar(50)) MA2,cast(MA.City as varchar(25)) MACty,cast(MA.State as varchar(2)) MASt,cast(MA.Zip as varchar(5)) MAZp,cast(MA.Zip4  as varchar(4))MAZ4,
		cast(SA.phone1 as varchar(20))
		from KYPEnrollment.pADM_Account A 
		--taking top 1 DEA after discussion with DA team
		left join (select partyid,max(DEA) as DEA from KYPEnrollment.pAccount_PDM_DEA 
		where CurrentRecordFlag=1 
		and DEA<>'No data' --added check DEA<>'No data' on 31stAug2018
		group by partyid)B on A.partyid=B.partyid
		--taking null value for deleted 
		join KYPEnrollment.pAccount_PDM_Person D on A.partyid=D.partyid 
		and isnull(d.deleted,0)=0 and d.CurrentRecordFlag=1
		--join KYPEnrollment.pAccount_PDM_Organization E ON A.partyid=E.partyid
		Left join KYPEnrollment.EDM_AccountInternalUse C on A.AccountID=C.AccountID and C.CurrentRecordFlag=1
		Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
		   (case when charindex('-',F.ZipPlus4)>0
					then right(F.ZipPlus4,4) 
					else null end) as Zip4
		   , G.Phone1
						from KYPEnrollment.pADM_Account A 
						join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
						join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
						join KYP.Lk_Screening S on F.state=S.description
						--and F.AddressType = 'Servicing' --Commented on 30Aug2018
						and G.Type = 'Servicing')as SA ON A.AccountID = SA.AccountID
		Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
		   (case when charindex('-',F.ZipPlus4)>0
					then right(F.ZipPlus4,4) 
					else null end) as Zip4
	   					from KYPEnrollment.pADM_Account A 
						join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
						join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
						join KYP.Lk_Screening S on F.state=S.description
						--and F.AddressType = 'Pay-to' --Commented on 30Aug2018
						and G.Type = 'Pay-to')as PA on A.AccountID = PA.AccountID
		Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
		   (case when charindex('-',F.ZipPlus4)>0
					then right(F.ZipPlus4,4) 
					else null end) as Zip4
						from KYPEnrollment.pADM_Account A 
						join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
						join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
						join KYP.Lk_Screening S on F.state=S.description
						--and F.AddressType = 'Mailing' --Commented on 30Aug2018
						and G.Type = 'Mailing') as MA on A.AccountID = MA.AccountID
		Where Left(A.StatusAcc,1) in (1,7,9)
		and NPITYPE='Individual'
		and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0
	Union
	select 
	--Mapping AccountNumber instead of AccountID to P_ID after DA team suggestion
	Cast(isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,'') as varchar(20)), 
	cast(A.NPI as varchar(10)),
	cast(A.ProviderTypeCode as varchar(20)),
	cast(A.EIN as varchar(9)),
	cast(A.SSN as varchar(9)),
	cast(left(A.StatusAcc,1)  as varchar(1))  StatusAcc,
	cast(A.OwnerNo  as varchar(2)),
	cast(A.ServiceLocationNo  as varchar(3)),
	cast(A.NPITYPE  as varchar(50)),
	cast(A.AccountID as varchar(50)),cast(A.StatusBeginDate as smalldatetime),
	cast(B.DEA as varchar(11)),
	cast(C.PracTypeCode as varchar(3)),
	NULL as DOB,NULL as LastName,NULL as FirstName,NULL as MiddleName,NULL as Sufix,
	cast(E.LegalName as varchar(200)),
	'M' FileType,'M' FileSource,
	---City size change from 20 to 25(Max account address table) on 31Aug2018
	cast(SA.AddressLine1 as varchar(50)) ,cast(SA.AddressLine2 as varchar(50)) SA2,cast(SA.City as varchar(25)) SACty,cast(SA.State as varchar(2)) SASt, cast(SA.Zip as varchar(5)) SAZp,cast(SA.Zip4 as varchar(4)) SAZ4,
	cast(PA.AddressLine1 as varchar(50)), cast(PA.AddressLine2 as varchar(50)) PA2,cast(PA.City as varchar(25)) PACty,cast(PA.State as varchar(2)) PASt,cast(PA.Zip as varchar(5)) PAZP,cast(PA.Zip4 as varchar(4)) PAZ4,
	cast(MA.AddressLine1 as varchar(50)), cast(MA.AddressLine2 as varchar(50)) MA2,cast(MA.City as varchar(25)) MACty,cast(MA.State as varchar(2)) MASt,cast(MA.Zip as varchar(5)) MAZp,cast(MA.Zip4  as varchar(4))MAZ4,
	cast(SA.phone1 as varchar(20))
	from KYPEnrollment.pADM_Account A 
	--taking top 1 DEA after discussion with DA team
	left join (select partyid,max(DEA) as DEA from KYPEnrollment.pAccount_PDM_DEA 
	where CurrentRecordFlag=1 
	and DEA<>'No data' --added check DEA<>'No data' on 31stAug2018
	group by partyid)B on A.partyid=B.partyid
	--taking null value for isdeleted 
	join KYPEnrollment.pAccount_PDM_Organization E ON A.partyid=E.partyid 
	and isnull(e.isdeleted,0)=0  and e.CurrentRecordFlag=1
	Left join KYPEnrollment.EDM_AccountInternalUse C on A.AccountID=C.AccountID and C.CurrentRecordFlag=1
	Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
	   (case when charindex('-',F.ZipPlus4)>0
				then right(F.ZipPlus4,4) 
				else null end) as Zip4
	   , G.Phone1
					from KYPEnrollment.pADM_Account A 
					join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
					join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
					join KYP.Lk_Screening S on F.state=S.description
					--and F.AddressType = 'Servicing' --Commented on 30Aug2018
					and G.Type = 'Servicing')as SA ON A.AccountID = SA.AccountID
	Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
	   (case when charindex('-',F.ZipPlus4)>0
				then right(F.ZipPlus4,4) 
				else null end) as Zip4
	   				from KYPEnrollment.pADM_Account A 
					join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
					join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
					join KYP.Lk_Screening S on F.state=S.description
					--and F.AddressType = 'Pay-to' --Commented on 30Aug2018
					and G.Type = 'Pay-to')as PA on A.AccountID = PA.AccountID
	Left Join (select A.AccountID,F.AddressLine1, F.AddressLine2 ,F.City ,S.abreviation as State ,F.Zip,
	   (case when charindex('-',F.ZipPlus4)>0
				then right(F.ZipPlus4,4) 
				else null end) as Zip4
	                from KYPEnrollment.pADM_Account A 
					join KYPEnrollment.pAccount_PDM_Location G ON A.partyid=G.partyid
					join KYPEnrollment.pAccount_PDM_Address F ON F.ADDRESSID=G.ADDRESSID
					join KYP.Lk_Screening S on F.state=S.description
					--and F.AddressType = 'Mailing' --Commented on 30Aug2018
					and G.Type = 'Mailing') as MA on A.AccountID = MA.AccountID
	Where Left(A.StatusAcc,1) in (1,7,9)
	and A.NPITYPE='Organization'
	and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0

	--As discussed with DA team Atypical provider NPI(starting with 5) are updated to null for now
	update [dbo].[Monitoring_ProviderNameAddress] set P_NPI_NUM=null where P_NPI_NUM like '5%'
	
	----instead of adding new field in this table, we are considering "P_SupUpdate_Flag" this existing field as indicator of MixedGroup(MG),SubGroup(SG) etc
	----Mix group(MG) indicator
	update B set P_SupUpdate_Flag='MG' from KYPEnrollment.pADM_Account A join [dbo].[Monitoring_ProviderNameAddress] b on 
	B.P_AccNo=A.AccountID where  A.providertypecode = '100' and isnull(A.IsDeleted,'0') = 0 
	and LEFT(A.statusacc,1) in ('1','7','9') and B.P_SupUpdate_Flag is null
	
	--Sub group(SG) indicator
	update B set P_SupUpdate_Flag='SG' from KYPEnrollment.pADM_Account A join [dbo].[Monitoring_ProviderNameAddress] b on 
	B.P_AccNo=A.AccountID where isnull(A.IsDeleted,'0') = 0 and
	LEFT(A.statusacc,1) in ('1','7','9')
	and len(A.accountnumber) in(13,16) and A.ProviderTypeCode in 
	('003','005','006','010','012','013','018','019','021','022','023','025','027','029','031',
	'032','037','062','071','078') and B.P_SupUpdate_Flag is null
	
	--crossover Accounts(CO) indicator
	update D set P_SupUpdate_Flag='CO'
	From Kypenrollment.padm_account B
	join Kypenrollment.EDM_AccountInternalUse C on B.AccountId = C.AccountId 
	join [dbo].[Monitoring_ProviderNameAddress] D on D.P_AccNo=B.AccountID 
	where Left(isnull(B.Statusacc,''),1) in ('1','7','9') and B.Isdeleted=0 and B.AccountType not in ('NMP', 'ORP') 
	and C.ProvisionalCode = 'X' and isnull(B.IsDeleted,'0') = 0 
	and D.P_SupUpdate_Flag is null

--Added on 28Sep2018
----NMP ORP Main file indicator for billing purpose
update A set P_SupUpdate_Flag=(Case when B.ACcountType='NMP' then 'NMP'
								when B.ACcountType='ORP' then 'ORP' else 'Main' end)
 from [dbo].[Monitoring_ProviderNameAddress] A 
join kypenrollment.Padm_Account b on B.AccountID=A.P_AccNo
where P_SupUpdate_Flag is null



	--[dbo].[Monitoring_providerclia]
	insert into [dbo].[Monitoring_providerclia]
	(P_ID,P_CLIA_NUM,CertificationType)
	select distinct isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,''), nullif(C.CliaNumber,''),nullif(C.RegistrationNumber,'')
	from KYPEnrollment.pADM_Account A join KYPEnrollment.pAccount_PDM_CLIA C
	on A.partyid=C.partyID
	where Left(A.StatusAcc,1) in (1,7,9) 
	and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0 --Added check on 30Aug2018
	and nullif(C.CliaNumber,'') is not null
	and C.CliaNumber<>'No data'
	
	--[dbo].[Monitoring_providerlicense]
	insert into [dbo].[Monitoring_providerlicense]
	(P_ID,P_LIC_CERT_NUM,P_ST_CD,P_LIC_EXP_DT,P_LIC_EFF_DT)
	select distinct isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,''), N.Number,
	S.abreviation,convert(varchar(10),N.ExpirationDate,101) as ExpirationDate,convert(varchar(10),N.EffectiveDate,101) as EffectiveDate
	from KYPEnrollment.pADM_Account A 
	join KYPEnrollment.pAccount_PDM_Number N on A.partyid=N.partyID and N.CurrentrecordFlag=1
	left join KYP.Lk_Screening S on N.state=S.description
	where N.Type in(   -----------Changed on 1sep2018
	'Professional License',
	'BusinessEinLicenses',
	'orthABCOPprosthABCOP',
	'orthABCOPprosthBOC',
	'orthBOCprosthABCOP',
	'orthBOCprosthBOC',
	'orthotistABCOP',
	'orthotistBOC',
	'orthProsthABCOP',
	'prosthetistABCOP',
	'prosthetistBOC',
	'Certificate',
	'Other'
	)
	and S.TypeID = '4' and
	Left(A.StatusAcc,1) in (1,7,9) 
	and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0 --Added check on 30Aug2018
	and N.Number<>'No data'

	
	--[dbo].[Monitoring_providerspeciality]
	insert into [dbo].[Monitoring_providerspeciality]
	(P_ID,P_SPECL_CD,DH_SPE_CERT_DT)
	select distinct isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,''), S.Speciality_Code,convert(varchar(10),S.SpecCertDate,101) as SpecCertDate
	from KYPEnrollment.pADM_Account A join KYPEnrollment.pAccount_PDM_Speciality S
	on A.partyid=S.partyID and s.currentRecordFlag=1
	Where S.Type = 'Specialty Code' and
	Left(A.StatusAcc,1) in (1,7,9) 
	and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0 --Added check on 30Aug2018
	and S.Speciality_Code<>'No data'
	
	--[dbo].[providersfortheday]
	truncate table [dbo].Monitoring_ProvidersForTheDay
		
	insert into Monitoring_ProvidersForTheDay (filetype,p_id)
	select 'M' as filetype,x.* from 
	(select distinct p_id from [Monitoring_ProviderNameAddress] 
	where P_SupUpdate_Flag not in('CO','SG') ---added filter on 15Oct2018 to not include SG and CO providers in provider of the day table
	--union									---Commented on 15Oct2018 because nameaddress only table enough for provider counts
	--select p_id from [providerclia]
	--union
	--select p_id from [providerlicense]
	--union
	--select p_id from [providerspeciality]
	)x

	--KYP.PDM_MasterGroupProvider : GROUP - RENDERING DATA LOAD
	truncate table KYP.PDM_MasterGroupProvider 
	truncate table dbo.Monitoring_stage_GroupProvider 
	
	insert into Monitoring_stage_GroupProvider
	select distinct isnull(A.NPI,'')+isnull(A.OwnerNo,'')+isnull(A.ServiceLocationNo,'')+isnull(A.ProviderTypeCode,'') grpno,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode,
	isnull(C.NPI,'')+isnull(C.OwnerNo,'')+isnull(C.ServiceLocationNo,'')+isnull(C.ProviderTypeCode,'') RendNo
	from KYPenrollment.PADM_Account A 
	join KYPenrollment.pAccount_RenderingAffiliation B on A.ACcountID=B.ACcountID 
	and isnull(b.isdeleted,'0')=0 and B.CurrentRecordFlag=1
	join dbo.[Monitoring_ProviderNameAddress] D on A.ACcountID=D.P_AccNo  --Aded on 1stOct2018 to restrict SG or CO accounts group rend relationship
	and D.P_SupUpdate_Flag not in ('CO','SG')
	join KYPenrollment.PADM_Account c on B.AffiliatedAccountID=c.ACcountID
	join dbo.[Monitoring_ProviderNameAddress] E on C.ACcountID=E.P_AccNo --Aded on 1stOct2018 to restrict SG or CO accounts group rend relationship
	and E.P_SupUpdate_Flag not in ('CO','SG')
	where left(A.StatusAcc,1) in('1','7','9') and left(c.StatusAcc,1) in('1','7','9')
	 and isnull(A.isDeleted,'0') = 0 and isnull(A.AccProcessing,'0') =0 --Added check on 30Aug2018
	 and isnull(C.isDeleted,'0') = 0 and isnull(C.AccProcessing,'0') =0 --Added check on 30Aug2018

	Insert into kyp.PDM_MasterGroupProvider (Group_ProviderNO,Member_ProviderNO,FileSource)
	select distinct  [PM-PROV-NUMBER],[PM-PROV-NOS-IN-GRP], 'G' as Filesource from
	dbo.Monitoring_stage_GroupProvider
	

	delete y from (
	select * from KYP.PDM_MasterGroupProvider where Member_ProviderNO is not null)x
	inner join
	(
	select * from KYP.PDM_MasterGroupProvider where Member_ProviderNO is null)y
	on x.Group_ProviderNO = y.Group_ProviderNO

	--dbo.Monitoring_ProviderIndOwner
	truncate table dbo.Monitoring_ProviderIndOwner
	
	insert into dbo.Monitoring_ProviderIndOwner
	(P_ID,
	P_OWNER_LAST_NAM,
	P_OWNER_FST_NAM,
	P_OWNER_MI_NAM,
	P_OWNER_TITL_NAM,
	P_OWNER_DOB_DT,
	P_OWNER_SSN_NUM,
	P_LINE1_AD,
	P_LINE2_AD,
	P_CITY_NAM,
	P_ST_CD,
	P_ZIP5_CD,
	P_ZIP4_CD,
	Owner_NPI,
	Owner_FullName,
	MOCA_END_DT,
	DateCreated,
	DateModified,
	MOCA_EFF_DT,
	MOCAPartyStatus ---This existing field we are using to store MOCA partyid from enrollment for billing count 15Oct2018
	)

	select
	distinct isnull(B.NPI,'')+isnull(B.OwnerNo,'')+isnull(B.ServiceLocationNo,'')+isnull(B.ProviderTypeCode,'') LegacyAccountNo
	,C.LastName,C.FirstName
	,C.MiddleName,C.Sufix,C.DoB
	,replace(C.SSN,'-','') SSN
	,E.AddressLine1
	,E.AddressLine2,E.City ---changed on 31Aug2018 removed left of 20 char
	,S.abreviation as state
	,E.Zip
	, case when charindex('-',E.ZipPlus4)>0
					then right(E.ZipPlus4,4) 
					else null end as ZipPlus4
	,C.NPI
	,ISNULL(C.FirstName,'')+Case when nullif(C.MiddleName,'') IS null then ' '+ISNULL(C.LastName,'') 
	else ' '+ISNULL(C.MiddleName,'')+' '+isnull(C.LastName,'') end FullName,
	A.MOCARelationshipEndDate,
	A.DateCreated,
	A.LastLoadDate,
	A.MOCARelationshipStartDate,
	C.partyid   ----------------Added on 15Oct2018 for the purpose of billing count
	----Commented below code bcause it belongs to old Moca implementation before 3.0
	/*
	from kypenrollment.pAccount_PDM_Party A 
	join kypenrollment.Padm_Account B on A.ParentPartyID=B.PartyID and A.AccountID=B.AccountID
	*/
	
	----Code with new Moca design 3.0----
	from kypenrollment.padm_account B
	join kypenrollment.paccount_bizprofile_details bpd 
	on b.accountid = bpd.accountid
	join kypenrollment.taxidprofile tp
	on	b.ein = tp.taxid and
		bpd.profileid = tp.profileid
	join kypenrollment.paccount_pdm_party A
	on tp.taxidprofileid = a.taxidprofileid
	----------------------------------------
	join kypenrollment.pAccount_PDM_Person c 
	on A.PartyID=c.PartyID and isnull(c.deleted,'0')=0 and c.CurrentRecordFlag=1
	join dbo.[Monitoring_ProviderNameAddress] F on B.ACcountID=F.P_AccNo  ----Added on 1stOct2018 to restrict SG or CO accounts group rend relationship
	----and F.P_SupUpdate_Flag not in ('CO','SG')  ----now commented on 5Dec2018 because we need to capture Full MOCA count as well from enrollment
	left join kypenrollment.pAccount_PDM_Location D on A.PartyID=D.PartyID and D.CurrentRecordFlag='1'
	Left join kypenrollment.pAccount_PDM_Address E on D.AddressID=E.AddressID and E.AddressLine1<>'No Data'
	left join KYP.Lk_Screening S on E.state=S.description  ---Correction left join on 31Aug2018
	and E.CurrentRecordFlag='1'
	where a.type in(
	'Individual Ownership',
	'SubcontractorIndividual',
	--'TransactionIndividual',  --commented on 1Sep2018 no more supportred in 3.0
	'OtherOwnershipIndividual',
	'DelegatedOfficials',
	'SubcontractorOwnerIndividual',
	'WhollyOwnedSupplied'       ---Added on 1Sep2018 newly supported type
	) and a.CurrentRecordFlag='1' and left(b.StatusAcc,1) in('1','7','9') 
	and isnull(b.isDeleted,'0') = 0 and isnull(b.AccProcessing,'0') =0 --Added check on 30Aug2018
	and nullif(C.FirstName,'') is not null
	and ( --Added on 31Aug2018 for filtering MOCA's where no attribute available except name
	nullif(C.NPI,'') is not null or nullif(C.SSN,'') is not null or nullif(C.DOB,'') is not null or 
	nullif(E.AddressLine1,'') is not null
	)
	order by LegacyAccountNo,LastName,FirstName
	

	--cleansing firstname,middlename,lastname
	update dbo.Monitoring_ProviderIndOwner set P_OWNER_FST_NAM=null where P_OWNER_FST_NAM=''
	update dbo.Monitoring_ProviderIndOwner set P_OWNER_MI_NAM=null where P_OWNER_MI_NAM=''
	update dbo.Monitoring_ProviderIndOwner set P_OWNER_LAST_NAM=null where P_OWNER_LAST_NAM=''
	
	--dbo.Monitoring_ProviderOrgOwner
	truncate table dbo.Monitoring_ProviderOrgOwner

	insert into Monitoring_ProviderOrgOwner
	(P_ID,
	P_OWNER_BUSN_NAM,
	P_OWNER_DBA_NAM,
	P_OWNER_TAX_ID,
	P_BUSN_LINE1_AD,
	P_BUSN_LINE2_AD,
	P_BUSN_CITY_NAM,
	P_BUSN_ST_CD,
	P_BUSN_ZIP5_CD,
	P_BUSN_ZIP4_CD,
	Owner_NPI,
	MOCA_END_DT,
	DateCreated,
	DateModified,
	MOCA_EFF_DT,
	MOCAPartyStatus ---This existing field we are using to store MOCA partyid from enrollment for billing count 15Oct2018
	)
	select distinct 
	isnull(B.NPI,'')+isnull(B.OwnerNo,'')+isnull(B.ServiceLocationNo,'')+isnull(B.ProviderTypeCode,'') LegacyAccountNo
	,C.LegalName,C.DBAName1,C.TIN,
	E.AddressLine1,E.AddressLine2
	,E.City ---changed on 31Aug2018 removed left of 20 char
	,S.abreviation as state
	,E.Zip
	,case when charindex('-',E.ZipPlus4)>0
					then right(E.ZipPlus4,4) 
					else null end as ZipPlus4
	,C.NPI,
	A.MOCARelationshipEndDate,
	A.DateCreated,
	A.LastLoadDate,
	A.MOCARelationshipStartDate,	
	C.partyid   ----------------Added on 15Oct2018 for the purpose of billing count
	----Commented below code bcause it belongs to old Moca implementation before 3.0
	/*
	from kypenrollment.pAccount_PDM_Party A 
	join kypenrollment.Padm_Account B on A.ParentPartyID=B.PartyID and A.AccountID=B.AccountID
	*/
	
	----Code with new Moca design 3.0----
	from kypenrollment.padm_account B
	join kypenrollment.paccount_bizprofile_details bpd
	on b.accountid = bpd.accountid
	join kypenrollment.taxidprofile tp
	on	b.ein = tp.taxid and
		bpd.profileid = tp.profileid
	join kypenrollment.paccount_pdm_party A
	on tp.taxidprofileid = a.taxidprofileid
	----------------------------------------
	join kypenrollment.pAccount_PDM_Organization c
	on A.PartyID=c.PartyID and isnull(c.isdeleted,'0')=0 and c.CurrentRecordFlag=1
	join dbo.[Monitoring_ProviderNameAddress] F on B.ACcountID=F.P_AccNo  --Aded on 1stOct2018 to restrict SG or CO accounts group rend relationship
	----and F.P_SupUpdate_Flag not in ('CO','SG') ----now commented on 5Dec2018 because we need to capture Full MOCA count as well from enrollment
	left join kypenrollment.pAccount_PDM_Location D on A.PartyID=D.PartyID and D.CurrentRecordFlag='1'
	Left join kypenrollment.pAccount_PDM_Address E on D.AddressID=E.AddressID and E.AddressLine1<>'No Data'
	left join KYP.Lk_Screening S on E.state=S.description  ---Left join added on 31Aug2018
	and E.CurrentRecordFlag='1'
	where a.type in(
	'Entity Ownership',
	'SubcontractorEntity',
	--'TransactionEntity',  --commented on 1Sep2018 no more supportred in 3.0
	'OtherOwnershipEntity',
	'SubcontractorOwnerEntity',
	'WhollyOwnedSupplied'       ---Added on 1Sep2018 newly supported type
	) and a.CurrentRecordFlag='1' and left(b.StatusAcc,1) in('1','7','9') 
	and isnull(b.isDeleted,'0') = 0 and isnull(b.AccProcessing,'0') =0--Added check on 30Aug2018
	and nullif(C.LegalName,'') is not null
	and ( --Added on 31Aug2018 for filtering MOCA's where no attribute available except name
	nullif(C.NPI,'') is not null or nullif(C.TIN,'') is not null or 
	nullif(E.AddressLine1,'') is not null
	)
	order by LegacyAccountNo,C.LegalName

	--cleansing legalname,DBAName 
	update dbo.Monitoring_ProviderOrgOwner set P_OWNER_BUSN_NAM=null where P_OWNER_BUSN_NAM=''
	update dbo.Monitoring_ProviderOrgOwner set P_OWNER_DBA_NAM=null where P_OWNER_DBA_NAM=''

END


GO

