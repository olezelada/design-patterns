

CREATE VIEW [KYPEnrollment].[ViewToSimilarAccount]
AS
select (row_number() over ( order by r.AccountID))  AS ViewID, r.*
from ( 
	select pAcc.AccountID,pAcc.AccountNumber,pAcc.ProviderType,pAcc.PartyID,pAcc.LegalName,pAcc.StatusAcc,pAcc.NPI,pAcc.SSN,pAcc.SSNH,pAcc.EINH,pAcc.PracticeAddress
	,pAcc.DateCreated,pAcc.ActivationDate,pAcc.LastActionDate,pAcc.LastActorUserID,pAcc.LegacyAccountNo,pAcc.StateStatusAcc 
	,substring(pABiz.AccountAdrZip9,1,5) AS Zip1stFive 
	,accSpecilityCode1,accSpecilityCode2,accSpecilityCode3,accSpecilityCode4,accSpecilityCode5
	from KYPEnrollment.pADM_Account pAcc
	left outer join KYPEnrollment.pAccount_BizProfile_Details pABiz on pABiz.AccountID=pAcc.AccountID
	left Outer join 	
	(
		select PartyID,  accSpecilityCode1,accSpecilityCode2,accSpecilityCode3,accSpecilityCode4,accSpecilityCode5 
		from
		(   
 			SELECT accSplity.PartyID ,  CONVERT(varchar(20),Speciality_Code)as StatusValue
			,'accSpecilityCode'+CONVERT(varchar(10), ROW_NUMBER() over( partition by accSplity.PartyID order by  SpecialityID desc  ) ) seq
			from KYPEnrollment.pAccount_PDM_Speciality accSplity where Type='Specialty Code'
			)ML(PartyID,StatusValue,seq)
			PIVOT (max(ml.StatusValue) 
			FOR ml.seq IN (
				accSpecilityCode1,accSpecilityCode2,accSpecilityCode3,accSpecilityCode4,accSpecilityCode5)
		) pvt
	) AS pSplity on pSplity.PartyID=pAcc.PartyID 
) r


GO

