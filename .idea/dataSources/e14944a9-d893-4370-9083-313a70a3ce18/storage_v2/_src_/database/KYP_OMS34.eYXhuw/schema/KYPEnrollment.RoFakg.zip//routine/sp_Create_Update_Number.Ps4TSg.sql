-- =============================================
-- Author:		<ohuanca>
-- Create date: <08-03-18>
-- Description:	check if not exist records site account then insert one time
-- Params:
-- @party_id_provider: party id from application
-- @acc_party_id: party id of account
-- @last_action_user_id: identifier from tracking
-- @typeNumber: type of number
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_Number]
  @party_id_provider INT,
  @account_party_id INT,
  @last_action_user_id VARCHAR(100),
  @typeNumber VARCHAR(100)
AS
BEGIN
    IF NOT EXISTS(SELECT NumberID FROM KYPEnrollment.pAccount_PDM_Number WHERE Type = @typeNumber AND PartyID = @account_party_id AND IsDeleted = 'false')
    BEGIN

      EXEC [KYPEnrollment].[sp_Copy_Number] @account_party_id, @party_id_provider, @last_action_user_id, NULL;
      PRINT 'INSERT TABLE NUMBER'
    END
END


GO

