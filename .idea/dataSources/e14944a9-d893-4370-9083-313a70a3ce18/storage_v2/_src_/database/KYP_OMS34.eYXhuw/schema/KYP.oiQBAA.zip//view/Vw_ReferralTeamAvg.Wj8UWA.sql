


CREATE VIEW [KYP].[Vw_ReferralTeamAvg] as
SELECT ROW_NUMBER() over(order by C.ReferralTeamDesc) TeamAvgId,  C.ReferralTeamDesc,   
 Convert(numeric(12,2),SUM(isnull(C.DaysWithReferral,0)))/COUNT(Distinct C.CaseID) ReferralTeamAvg
	FROM KYP.Vw_TotalReferredApplication C
		WHERE C.ReferralDate is not null 
Group By C.ReferralTeamDesc


GO

