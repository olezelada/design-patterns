
/* ==========================================================
-- Author:		Richard Jimenez
-- PROCEDURE: Data patch  Redndering Affiliation.   
-- PARAMETERS: 
-- @account_id : AccountID 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_DataPatch_8674_All]

@atype varchar(2)
AS
BEGIN
SET NOCOUNT ON 

  DECLARE @acc_render VARCHAR(20), @isdel bit, @affcc varchar(40),@npi varchar(80),@modif int,@typeAff varchar(80)
  
  IF @atype ='G' SET @typeAff = 'NEW_RENDERING_FROM_GROUP' 
  IF @atype ='R' SET @typeAff = 'NEW_RENDERING_FROM_ACCOUNT'
  ELSE RETURN
  
  --SET @affcc=@account_id 
  
  DECLARE Cur_m CURSOR FOR
  
  SELECT group_npi,accountID from KYPEnrollment.pADM_Account a 
  INNER JOIN KYPPortal.PortalKYP.pRenderingAffiliation p  on a.npi = p.rendering_npi and a.AccountType = @atype
  --where accountID = @affcc
  
  return
  
  OPEN Cur_m
   
  FETCH Cur_add INTO @npi,@affcc
		  
	  WHILE (@@FETCH_STATUS = 0)
	  BEGIN	
		  print @affcc
		  
		  DECLARE Cur_add CURSOR FOR
		  
		  select  accountid, isdeleted,modifiedBy FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] 
		  WHERE npi = @npi
		  group by  accountid, isdeleted,modifiedBy 

		  OPEN Cur_add  
		  
		  FETCH Cur_add INTO @acc_render, @isdel,@modif
		  
		  WHILE (@@FETCH_STATUS = 0)
		  BEGIN	
		    
			IF NOT EXISTS( SELECT  1 FROM [KYPEnrollment].pAccount_RenderingAffiliation WHERE AffiliatedAccountId = @affcc and accountID = @acc_render)
			BEGIN
			  PRINT 'insert'
			  
			   INSERT INTO  [KYPEnrollment].[pAccount_RenderingAffiliation]
						   ([AccountID]
						   ,[AffiliatedAccountID]
						   ,[TypeAffiliation]
						   ,[LastActionDate]
						   ,[LastActorUserID]
						   ,[LastActionComments]
						   ,[LastActionApprovedBy]
						   ,[CurrentRecordFlag]
						   ,[LastAction]
						   ,[AffiliationStartDate]
						   ,[LastUpdatedBy]
						   ,isDeleted)
						VALUES( 
						@acc_render,
						@affcc,
						@atype, 
						getdate(),
						null,
						'Data Patch',
						null,
						1,
						'C',
						getdate(),
						'P',
						0)
			END
			ELSE
			BEGIN
			 -- Update
			
				if (@modif is not null)
				BEGIN	     
					UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET isdeleted=@isdel,LastActionDate=getdate()
					WHERE AffiliatedAccountId = @affcc and accountID = @acc_render 
				END 
			   
			END
		    
		  FETCH Cur_add INTO @acc_render, @isdel,@modif
		  END 
		  CLOSE Cur_add
		  DEALLOCATE Cur_add
		  
   FETCH Cur_m INTO @npi,@affcc
   END 
   CLOSE Cur_m
   DEALLOCATE Cur_m
END


GO

