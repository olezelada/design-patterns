

-- =============================================
-- Author:		Sundar
-- Create date: 25 Feb 2019
-- Description:	Updated LastActionDate with Current date for Elk Implementation
-- =============================================
CREATE TRIGGER [KYP].[OIS_Attachment_Insert_Update] 
   ON  [KYP].[OIS_Attachment] 
   AFTER INSERT,UPDATE
AS 
BEGIN
	SET NOCOUNT ON;

	Update KYP.OIS_ATTACHMENT
	Set LastActionDate = Getdate(),
		Row_Updation_Source = 'OIS_Attachment'
	Where AttachmentID in (Select AttachmentID from Inserted);

END


GO

