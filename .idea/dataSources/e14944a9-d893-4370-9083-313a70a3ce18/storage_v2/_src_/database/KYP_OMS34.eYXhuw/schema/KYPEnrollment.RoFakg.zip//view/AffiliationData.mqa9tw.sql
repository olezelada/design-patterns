


CREATE VIEW [KYPEnrollment].[AffiliationData] as
SELECT ROW_NUMBER() over(order by A.AccountID) AffiliateID,
A.AccountID,A.AccountNumber,B.AffiliatedAccountID,B.AffiliationStartDate,B.AffiliationEndDate,A.LegalName,A.ProviderType,A.NPI,A.SSN
from KYPEnrollment.pADM_Account A
JOIN KYPEnrollment.pAccount_RenderingAffiliation B ON B.AccountID = A.AccountID


GO

