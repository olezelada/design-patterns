

/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: create Insurance form.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Twin_Place_Business]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@account_id INT
AS
BEGIN
SET NOCOUNT ON

IF EXISTS (SELECT a.AccountID FROM KYPEnrollment.pADM_Account a where a.AccountID =@party_account_id AND a.PackageName='F_OOS_OE')
  BEGIN
     EXEC [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios] @party_account_id,@party_app_id,@last_action_user_id,@account_id;
  END
ELSE
  BEGIN
    EXEC [KYPEnrollment].[sp_Copy_Place_Business] @party_account_id,@party_app_id,@last_action_user_id,@account_id;
  END

PRINT 'twin Place of Business'
END


GO

