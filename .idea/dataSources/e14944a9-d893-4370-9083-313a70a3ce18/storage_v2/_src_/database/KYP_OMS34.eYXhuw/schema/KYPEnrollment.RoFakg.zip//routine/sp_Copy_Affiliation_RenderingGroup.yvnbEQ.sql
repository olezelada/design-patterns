

/*
generate [KYPEnrollment].[pAccount_RenderingAffiliation]
Author: Richard Jimenez
*/


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Affiliation_RenderingGroup]
@account_id INT,
@accountType varchar(2)
AS
BEGIN
--SET NOCOUNT ON;

 BEGIN TRY
    declare @tot int
    declare @cont int

    SELECT @accountType=AccountType from KYPEnrollment.pADM_Account where accountID = @account_id;
   
 IF @accountType='R'
 BEGIN
 
  IF EXISTS(SELECT  distinct a.AccountID
  FROM  KYPEnrollment.pADM_Account a
  INNER JOIN KYPPortal.PortalKYP.pRenderingAffiliation p  on a.npi = p.rendering_npi and a.AccountType = @accountType
  and a.AccountID= @account_id)
  BEGIN
	   
		 DECLARE @acc_render VARCHAR(20), @isdel bit, @affcc varchar(40),@npi varchar(80),@modif int
		 DECLARE @typerender VARCHAR(80)
				,@Date_Create datetime --Added for CAPAVE-2233 on 7 Nov 2017

		  
		  SET @affcc=@account_id
		
			-- Added the below statement for CAPAVE-2233 on 7 Nov 2017
			select @Date_Create = T2.DateCreated
			from kypenrollment.padm_Account T1
			Join kyp.ADM_Case T2 with (nolock) on T1.ApplicationNumber=T2.Number
			Where T1.AccountID = @affcc	
				  
		  SELECT @npi = group_npi,@typerender=p.type_affiliation from KYPEnrollment.pADM_Account a 
		  INNER JOIN KYPPortal.PortalKYP.pRenderingAffiliation p  on a.npi = p.rendering_npi and a.AccountType = @accountType 
		  where accountID = @affcc
		  	  
		 -- DECLARE Cur_add CURSOR FOR
		   DECLARE  @AfillAddres table (pk int identity(1,1),accountid int, isdeleted bit,modifiedBy int)

		  INSERT INTO @AfillAddres(accountid,isdeleted,modifiedBy)
		  select  accountid, isdeleted,modifiedBy FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] 
		  WHERE npi = @npi
		  group by  accountid, isdeleted,modifiedBy 

		  --OPEN Cur_add  
		  
		  --FETCH Cur_add INTO @acc_render, @isdel,@modif
		 SELECT @tot =MAX(pk) from @AfillAddres
		 SET @cont=1;

		 WHILE  @cont<=@tot
		  BEGIN	
		    
			SELECT  @acc_render=accountid,@isdel=isdeleted,@modif=modifiedBy FROM @AfillAddres WHERE pk = @cont

			IF NOT EXISTS( SELECT  1 FROM [KYPEnrollment].pAccount_RenderingAffiliation WHERE AffiliatedAccountId = @affcc and accountID = @acc_render)
			BEGIN
			  		  
			   INSERT INTO  [KYPEnrollment].[pAccount_RenderingAffiliation]
						   ([AccountID]
						   ,[AffiliatedAccountID]
						   ,[TypeAffiliation]
						   ,[LastActionDate]
						   ,[LastActorUserID]
						   ,[LastActionComments]
						   ,[LastActionApprovedBy]
						   ,[CurrentRecordFlag]
						   ,[LastAction]
						   ,[AffiliationStartDate]
						   ,[LastUpdatedBy]
						   ,isDeleted)
						VALUES( 
						@acc_render,
						@affcc,
						@typerender, 
						getdate(),
						null,
						'',
						null,
						0,
						'C',
						@Date_Create,--getdate(), --Changed for CAPAVE-2233 on 7 Nov 2017
						'P',
						1)
			END
			ELSE
			BEGIN
			 -- Update
			
				if (@modif is not null)
				BEGIN	     
					UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
					SET isdeleted=1
					WHERE AffiliatedAccountId = @affcc and accountID = @acc_render 
				END 
			   
			END
		    set @cont=@cont+1
		 -- FETCH Cur_add INTO @acc_render, @isdel,@modif
		  END 
		 -- CLOSE Cur_add
		  --DEALLOCATE Cur_add
		  	     	 
  END
 END
 END TRY
	BEGIN CATCH
		DECLARE @error_message NVARCHAR (4000), @error_severity INT;
		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY();
		RAISERROR (@error_message, @error_severity, 1);
	END CATCH
END


GO

