



CREATE VIEW [KYPEnrollment].[v_OutEDI_NMP_D_File_WeeklyReport]
AS

 Select DISTINCT x.AccountID,x.AccountType,x.IsDeleted,x.LastActionDate,DateCreated ,x.AccountUpdatedBy
 
 ,x.NPI,SUBSTRING(x.LegalName,1,28) AS LegalName -- Leave on empty column
,SUBSTRING(x.SAddressLine1,1,100) AS SAddressLine1,SUBSTRING(x.SAddressLine2,1,100) AS SAddressLine2,SUBSTRING(x.SCity,1,50) AS SCity
,SState,SZip, SZipPlus4
-- Leave on empty column
,SUBSTRING(x.MAddressLine1,1,100) AS MAddressLine1N,SUBSTRING(x.MAddressLine2,1,100) AS MAddressLine2,SUBSTRING(x.MCity,1,50) AS MCity
,MState,MZip,MZipPlus4

,x.SSN --Check with Swati 
,y.StatusValue1,convert(varchar(10),y.EffectiveBeginDate1,101) as EffectiveBeginDate1 ,convert(varchar(10),y.EffectiveEndDate1,101) as EffectiveEndDate1
,y.StatusValue2,convert(varchar(10),y.EffectiveBeginDate2,101) as EffectiveBeginDate2,convert(varchar(10),y.EffectiveEndDate2,101) as EffectiveEndDate2
,y.StatusValue3,convert(varchar(10),y.EffectiveBeginDate3,101) as EffectiveBeginDate3,convert(varchar(10),y.EffectiveEndDate3,101) as EffectiveEndDate3
,y.StatusValue4,convert(varchar(10),y.EffectiveBeginDate4,101) as EffectiveBeginDate4,convert(varchar(10),y.EffectiveEndDate4,101) as EffectiveEndDate4
,y.StatusValue5,convert(varchar(10),y.EffectiveBeginDate5,101) as EffectiveBeginDate5,convert(varchar(10),y.EffectiveEndDate5,101) as EffectiveEndDate5

,x.Reenrollment,convert(varchar(10),convert(date,x.ReenrollmentDate),101)as ReenrollmentDate,NULL as CN404R31,x.ProvisionalCode,x.ProvisionalCodeDate,x.AccountUpdateDate

from( 
select 
A.LastActionDate --LastActionDate for fetch the data based on specific date
,A.NPI,A.LegalName,A.SSN,A.StatusAcc,A.ReenrollmentIndicator,A.AccountUpdateDate,A.AccountID,A.AccountType,A.IsDeleted,A.DateCreated,A.AccountUpdatedBy
,B.AddressLine1 AS SAddressLine1,B.AddressLine2 AS SAddressLine2,B.City AS SCity,B.State AS SState,B.Zip as SZip, B.ZipPlus4 AS SZipPlus4
,C.AddressLine1 AS MAddressLine1,C.AddressLine2 AS MAddressLine2,C.City AS MCity,C.State AS MState,C.Zip as MZip,C.ZipPlus4 AS MZipPlus4
,D.ProvisionalCode,D.ProvisionalCodeDate,A.ReenrollmentIndicator as Reenrollment,A.ReenrollmentDate
-- 5 occurence of "Provider NMP-ENROL-STAT-DATA Table 

from KYPEnrollment.pADM_Account A
--This is for Service Address Details
left outer join 

(select D.AddressLine1,D.AddressLine2,D.City,D.State,d.Zip, D.ZipPlus4,x.PartyID,x.Phone1,d.County  from KYPEnrollment.pAccount_PDM_Address D 
left join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)B
	 on B.PartyID = a.PartyID
--This is for Mailing Address Details
left outer join(select D.AddressLine1,D.AddressLine2,D.City,D.State,d.Zip,D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
left outer join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)C
	 on C.PartyID = a.PartyID
left outer join KYPEnrollment.EDM_AccountInternalUse D on D.AccountInternalUseID=
(select AccountInternalUseID from KYPEnrollment.EDM_AccountInternalUse where  AccountID=A.AccountID AND CurrentRecordFlag=1)
where A.AccountType ='NMP' AND A.IsDeleted=0 

)  x 
left outer join
( select AccountId,StatusValue1,CONVERT(smalldatetime,AccEffectiveBeginDate1) AS EffectiveBeginDate1 ,CONVERT(smalldatetime,AccEffectiveEndDate1) AS EffectiveEndDate1 
,StatusValue2,CONVERT(smalldatetime,AccEffectiveBeginDate2) AS EffectiveBeginDate2 ,CONVERT(smalldatetime,AccEffectiveEndDate2) AS EffectiveEndDate2
,StatusValue3,CONVERT(smalldatetime,AccEffectiveBeginDate3) AS EffectiveBeginDate3 ,CONVERT(smalldatetime,AccEffectiveEndDate3) AS EffectiveEndDate3
,StatusValue4,CONVERT(smalldatetime,AccEffectiveBeginDate4) AS EffectiveBeginDate4 ,CONVERT(smalldatetime,AccEffectiveEndDate4) AS EffectiveEndDate4
,StatusValue5,CONVERT(smalldatetime,AccEffectiveBeginDate5) AS EffectiveBeginDate5 ,CONVERT(smalldatetime,AccEffectiveEndDate5) AS EffectiveEndDate5

  from 
(   
	 
SELECT AccS.accountid,  CONVERT(varchar(20), StatusValue)as StatusValue
,'StatusValue'+CONVERT(varchar(10), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS

UNION ALL
SELECT AccS.accountid,  CONVERT(varchar(20), EffectiveBeginDate)as EffectiveBeginDate
,'AccEffectiveBeginDate'+CONVERT(varchar(10), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS
UNION ALL
SELECT AccS.accountid,  CONVERT(varchar(20), EffectiveEndDate)as EffectiveEndDate
,'AccEffectiveEndDate'+CONVERT(varchar(10), ROW_NUMBER() over( partition by AccS.accountid order by  AccountStatusID desc  ) ) seq
from [KYPEnrollment].[pADM_AccountStatus] AccS
   
)ML(AccountId,StatusValue,seq)
PIVOT (max(ml.StatusValue) 
FOR ml.seq IN (
StatusValue1,StatusValue2,StatusValue3,StatusValue4,StatusValue5
,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5

)) pvt   )y
on x.AccountID= y.AccountId
------------------------------------------------------------- Close of NMP Detail file -------------------------------------------------------------------------------------------------------------------------------


GO

