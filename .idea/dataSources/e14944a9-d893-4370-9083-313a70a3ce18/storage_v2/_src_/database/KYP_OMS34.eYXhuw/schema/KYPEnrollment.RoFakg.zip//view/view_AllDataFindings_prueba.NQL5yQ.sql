


CREATE VIEW [KYPEnrollment].[view_AllDataFindings_prueba]
 AS
SELECT row_number() OVER (ORDER BY category ASC) AS ViewID, *
FROM         
(		
		select case when a.Type IN ('Related Accounts') then '' else fe.FormattedContent end as FormattedContent, 
		case when a.Type IN ('Related Accounts') then 0 else fe.InfoID end as infoid,
		case when a.Type IN ('Related Accounts') then '' else fe.JournalEvent end as JournalEvent, 
		case when a.Type IN ('Related Accounts') then '' else  fe.Type end as type,
		case when a.Type IN ('Related Accounts') then 0 else  fe.PSubFormID end as PSubFormID, 
		case when a.Type IN ('Related Accounts') then '' ELSE fe.PFieldID end as PFieldID, 
		case when a.Type IN ('Related Accounts') then 0 ELSE fe.PartyID end as PartyID,  
		case when  a.Type NOT IN ('Application Review','Related Accounts') then 'SCREENING' else case when a.Type  in ('Application Review') then 'APP REVIEW' else 'RELATED ACCOUNTS' end end  as category,
		a.ReasonCode as Reasoncode, 
		CASE 
				 WHEN a.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (a.ExternalYesNO = '1' or a.ExternalYesNO = 'Yes') THEN
						'EXTERNAL' 
						WHEN (a.ExternalYesNO = '0' or a.ExternalYesNO = 'NO')  THEN
						'INTERNAL' 
					 ELSE NULL END
			    END As isexternaldesc
			 ,CASE 
				 WHEN a.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (a.ExternalYesNO = '1' or a.ExternalYesNO = 'Yes') THEN
						'Yes' 
						WHEN (a.ExternalYesNO = '0' or a.ExternalYesNO = 'NO')  THEN
						'No' 
					 ELSE NULL END
			    END As isexternalYesNo   
	          ,(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u where p.PersonID = u.PersonID and u.UserID= a.UserID) as addedby
            , a.DateCreated addedon
		     , a.Name titleFinding
		     , CAST(a.Content AS varchar(MAX)) descFinding
		     , a.Score riskScoreFinding
		     , a.Type typeFinding
		     , a.UpdAction actionFinding
		     
		     ,case when  a.Type NOT IN ('Application Review','Related Accounts') then '' else Case when  a.Type  in ('Application Review') then
		     ISNULL( (select top 1 fl.fieldLabel from KYPEnrollment.FieldLabel fl where fe.PFieldID = fl.fieldID and fe.PAppID=fl.ApplicationID and fe.PSubFormID=fl.SubFormID),'')  else '' end end  as fieldFinding
		     ,case when  a.Type NOT IN ('Application Review','Related Accounts') then 0 else Case  when a.Type  in ('Application Review') then fe.IsIgnored else 0 end end as  ignoredFinding
		     , a.AutoFlag flagScore
		     , a.DiffScore diffScore
		     , a.Tags tagsFinding
		     , a.DocumentCount docCountFinding
		     ,case when  a.Type NOT IN ('Application Review','Related Accounts') then cast(a.CaseID+'' as int) else Case when  a.Type  in ('Application Review') then cast(fe.PCaseID+'' as int) else  cast(a.CaseID+'' as int) end end  caseIDFinding
			 , a.NoteID findingID
			 ,case when  a.Type NOT IN ('Application Review','Related Accounts') then 'SCREENING' else Case when a.Type in ('Application Review') then fe.PStatus else 'Related Accounts' end end as  PStatus
			 ,case when  a.Type NOT IN ('Application Review','Related Accounts') then   'Confirmed' else case when a.Type in ('Application Review') then
			  CASE 
				 WHEN fe.IsIgnored = '1' THEN 
					'Ignored'
				 ELSE 
				 CASE WHEN fe.IsIgnored = '0' THEN
					'Confirmed' 
				 ELSE 'NA' END
			    END
			    else 'Confirmed' end end AS isIgnoredMsg
			 , CAST(a.UnformattedContent AS varchar(5000)) findingDescription
			 , a.RiskScoreColor
			 ,a.PartyRole
		from kyp.OIS_Note a left join kyp.MDM_JournalBasicInfo fe on a.PInID=fe.infoid 
		where  a.NoteID IN (select DISTINCT c.CFId from  KYP.Eventdates c ) 
		and (
		(a.Type NOT IN ('Application Review','Related Accounts') and fe.InfoID is NOT null) 
		or (a.Type  IN ('Application Review') and fe.InfoID is NOT null and a.ReasonCode is NOT null) 
		or a.Type  IN ('Related Accounts')
		)
		
		
		
		
)G


GO

