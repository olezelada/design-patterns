


--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		CAPAVE-1284, 1285	Sundar		16-Feb-2017		Added the condition LastActorUserID<>'System' to ignore the changes made by Delta load
-- 2		CAPAVE-1485			Pullaiah	 6-Apr-2017		Added the condition fetch the NR Applications also to Post in SFTP.
-- 3		CAPAVE-1591			Pullaiah	16-June-2017	Removed the null condition as there is a chance for created account to be modified same day.
-- 4		MD-4				Sundar		20-Jul-2017		Added Input Doc functionality for MD
-- 5		CAPAVE-1955			Sundar		09-Aug-2017		Suppressed legacy IDs for Group Affiliation and Association Sections of Input Doc.
-- 6		KEN-12838			Sundar		28-Aug-2017		Implemented PAVE 3.0 changes for Input Document
-- 7		CAPAVE-1937			Sundar		08-Feb-2018		Added Accountnumer in AccountUpdatedYesterday table
-- 8		KEN-15462			Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- 9        CAPAVE-2954         Ramya       5-May-2018      --Replaced the select statement to View as the same view is used in the MMIS Schedular jar for comparison.
CREATE PROCEDURE [KYPEnrollment].[sp_update_AccountUpdatedYesterday]
AS


BEGIN

	Declare @AccountId int,
			@userName varchar(100),
			@UserDate DATETIME,
			@AccountType varchar(10),
			@StateCode Varchar(2) --Added for #4 MD-4
			,@AccountNumber varchar(20) --Added for #7 CAPAVE-1937
			
	--Added for #4 MD-4		
	Select @StateCode = StateCode
	From kyp.OIS_App_Version			
	
	If (@StateCode = 'CA' OR @StateCode is null) --Added for #4 MD-4	
	Begin --Added for #4 MD-4	
		
		TRUNCATE TABLE [KYPEnrollment].[AccountUpdatedYesterday]
		
		TRUNCATE TABLE  KYPENROLLMENT.GroupRenderingforAccount
		TRUNCATE TABLE  KYPENROLLMENT.NMPRenderingForAccount
		TRUNCATE TABLE  KYPENROLLMENT.MocaDetailforAccount
		
		TRUNCATE TABLE  KYPENROLLMENT.NMPBillingProvider
		TRUNCATE TABLE KYPENROLLMENT.AccountInputDocNMP
		TRUNCATE TABLE kypenrollment.[GroupAssociationforAccount] --Added by Sundar on 3Mar2017 for an Adhoc issue
		
		--TRUNCATE TABLE KYPEnrollment.AccountInputDoc
		TRUNCATE TABLE KYPEnrollment. AccountInputDocORP
		TRUNCATE TABLE KYPEnrollment.Idoc_Biller
		
		/*Start #6 KEN-12838*/
		TRUNCATE TABLE  KYPENROLLMENT.GroupRendforAccount	
		TRUNCATE TABLE kypenrollment.[GroupAssforAccount]			
		Truncate table KYPEnrollment.ID_Biller_COS;
		Truncate table KYPEnrollment.ID_Biller_LAB;
		Truncate table KYPEnrollment.ID_Biller_Specialty;
		Truncate table KYPEnrollment.ID_Biller_Taxonomy;						
		/*End #6 KEN-12838*/			
	
	
	 --Replaced the select statement to View as the same view is used in the MMIS Schedular jar for comparison.
		DECLARE myCursor CURSOR LOCAL FAST_FORWARD FOR
		 Select AccountId,userName,UserDate,AccountType,AccountNumber from KYPEnrollment.V_AccountUpdatedYesterday
		OPEN myCursor
		
		FETCH NEXT FROM myCursor INTO @AccountId,@userName,@UserDate,@AccountType,@AccountNumber;
		
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			INSERT INTO [KYPEnrollment].[AccountUpdatedYesterday]
			(AccountID,userName,UserDate,AccountType,AccountNumber)
    		 values(@AccountId,@userName,@UserDate,@AccountType,@AccountNumber);
    		 
			FETCH NEXT FROM myCursor INTO @AccountId,@userName,@UserDate,@AccountType,@AccountNumber;

		END
		CLOSE myCursor
		DEALLOCATE myCursor
	End; --Added for #4 MD-4

	--Added the If block for #4 MD-4		
	If @StateCode = 'MD'
	Begin
		TRUNCATE TABLE [KYPEnrollment].[AccountUpdatedYesterday]
		
		TRUNCATE TABLE  KYPENROLLMENT.ID_BillerInfo
		TRUNCATE TABLE  KYPENROLLMENT.ID_Category
		TRUNCATE TABLE  KYPENROLLMENT.ID_Speciality	
		TRUNCATE TABLE  KYPENROLLMENT.ID_GroupAffiliation
		TRUNCATE TABLE KYPENROLLMENT.ID_LabClassification
		
		DECLARE myCursor CURSOR LOCAL FAST_FORWARD FOR
			select Distinct (IH.AccountID), 
					'system' as userName,
					CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate
			from  KYPEnrollment.INPUTDOC_BILLER  IH
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= IH.AccountID
			where Cast(IH.DateModified as DATE)=Cast(GETDATE()-1 as DATE) AND PA.IsDeleted!=1
			UNION
			--Portal Records				
			Select distinct(AccountID),
					'system' as userName,
					CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate
			from KYPEnrollment.pADM_Account where Cast(DateCreated as DATE)=Cast(GETDATE()-1 as DATE) AND IsDeleted!=1 
			and LegacyAccountNo is null and DateModified is null
			UNION	
			--Changes in Rendering Affiliation	
			SELECT Distinct RA.AccountID, 
					'system' as userName,
					CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate
			FROM KYPEnrollment.pAccount_RenderingAffiliation  RA
			Inner Join KYPENROLLMENT.PADM_ACCOUNT PA on  PA.AccountID= RA.AccountID
			where Cast(RA.LASTACTIONDATE as DATE)=Cast(GETDATE()-1 as DATE) 
			AND PA.IsDeleted!=1 
			and RA.LastActorUserID<>'System' --#1 CAPAVE-1284,1285		
			and RA.affiliatedaccountid is not null /*Added to remove unwanted Data*/			
			UNION	
			--NR Application	
			SELECT AccountID , 
					'system' as userName,
					CAST(Cast(GETDATE()-1 as DATE) as DATETIME) as UserDate
			FROM KYPEnrollment.pADM_Account 
			where AccountNumber in (SELECT  DISTINCT AccountNo 
									FROM KYP.ADM_Case a 
									where a.SupUpdateFlag='5A'
										AND convert(date,DateReceived)=Convert(date,GETDATE()-1));											
			
		OPEN myCursor
		
		FETCH NEXT FROM myCursor INTO @AccountId,@userName,@UserDate;
		
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			INSERT INTO [KYPEnrollment].[AccountUpdatedYesterday](
				AccountID,
				userName,
				UserDate)
			 values(@AccountId,@userName,@UserDate);
    		 
			FETCH NEXT FROM myCursor INTO @AccountId,@userName,@UserDate

		END
		CLOSE myCursor
		DEALLOCATE myCursor		
	End;		
END


GO

