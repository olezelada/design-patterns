CREATE VIEW [KYP].[SDM_SummaryReport_Checks_View]
AS
SELECT     row_number() OVER (ORDER BY KYP.SDM_ApplicationParty.PartyID ASC) AS ID, KYP.ADM_Application.ApplicationID,KYP.ADM_Application.ApplicationNo, 
KYP.PDM_Party.PartyID, KYP.PDM_Party.Name, KYP.SDM_ApplicationParty.PartyRole, KYP.SDM_ApplicationParty.AutoRisk, 
KYP.SDM_ApplicationParty.EDDRisk, KYP.SDM_ApplicationParty.CompositeRisk, KYP.SDM_DBCheckResult.OIGLEIE, KYP.SDM_DBCheckResult.GSAEPLS, 
KYP.SDM_DBCheckResult.SOR, KYP.SDM_DBCheckResult.SSADMF, KYP.SDM_DBCheckResult.NPI, KYP.SDM_DBCheckResult.SSN, 
KYP.SDM_DBCheckResult.TIN, KYP.SDM_DBCheckResult.DEA, KYP.SDM_DBCheckResult.License, KYP.SDM_DBCheckResult.City
 ,KYP.SDM_ApplicationParty.AppPartyID,KYP.SDM_ApplicationParty.ScreeningID
FROM 

KYP.SDM_ApplicationParty left join KYP.ADM_Application on KYP.SDM_ApplicationParty.ApplicationID=KYP.ADM_Application.ApplicationID and IsActive=1 left join
KYP.PDM_Party on KYP.SDM_ApplicationParty.PartyID=KYP.PDM_Party.PartyID left join KYP.SDM_PartyScreening on KYP.SDM_ApplicationParty.ScreeningID=KYP.SDM_PartyScreening.ScreeningID left join
KYP.SDM_DBCheckResult on KYP.SDM_PartyScreening.ScreeningID = KYP.SDM_DBCheckResult.ScreeningID


GO

