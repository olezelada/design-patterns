 
 
CREATE VIEW [KYP].[v_CSNgChkDetailsAnnexure] AS
SELECT DISTINCT CONVERT(VARCHAR,P.ScreeningID)As ScreeningID,CONVERT(VARCHAR,A.CaseID) As CaseID,B.Name,
        CONVERT(VARCHAR,P.PartyID) As PartyID,N.Field,Case When N.field = 'TIN' Then STUFF(N.Value,3,0,'-') When N.Field = 'SSN' THEN Stuff(Stuff(N.VALUE,4,0,'-'),7,0,'-') Else N.Value End Value,
		N.Comments,
        convert(varchar(10),P.DateCreated,101) [ScreenedOn]
  FROM 
    KYP.SDM_ApplicationParty P INNER JOIN KYP.ADM_Application A ON A.ApplicationID = P.ApplicationID AND P.IsActive = 1
    INNER JOIN KYP.ADM_Case C ON C.CaseID = A.CaseID 
    INNER JOIN KYP.PDM_Party B ON B.PartyID = P.PartyID  
    INNER JOIN [KYP].[v_CSPartyNegChkResult] N ON N.PartyID = P.PartyID AND N.ApplicationID = A.ApplicationID
    --where P.Tag in ('New','Updated')
GO

