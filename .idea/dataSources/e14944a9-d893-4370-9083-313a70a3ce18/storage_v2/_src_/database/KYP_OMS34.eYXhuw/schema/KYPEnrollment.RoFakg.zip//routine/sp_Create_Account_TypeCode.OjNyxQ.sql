/* ==========================================================
-- Author:		<Lacunza Giresse>
-- PROCEDURE: create Account and Account Provider Mapping with provider type code of parammeter.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @application_id : applicationID that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @priority : ADM_Case.Priority to Enrollment data base.
-- @risk : ADM_Case.risk to Enrollment data base.
-- @composite_risk : ADM_Case.CompositeRisk to Enrollment data base.
-- @case_id : ADM_Case.CaseID to Enrollment data base, for Account Number.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Create_Account_TypeCode]
@party_account_id INT,
@application_id INT,
@last_action_user_id VARCHAR(100),
@priority VARCHAR(3),
@risk VARCHAR(15),
@composite_risk INT,
@case_id INT,
@is_group BIT,
--@account_type varchar(50),
@provider_type_code varchar(50),
@accountType varchar(3)
AS
BEGIN
SET NOCOUNT ON
DECLARE @account_id INT,@date_created DATE,@account_number INT,@party_application INT
SET @date_created =  GETDATE();
SET @account_number = 100000000+@case_id

INSERT INTO [KYPEnrollment].[pADM_Account]
	  ([portaluserid]
      ,[ProviderType]
      ,[NPI]
      ,[NPIType]
      ,[ApplicationNumber]
      --,[StatusAcc]
      ,[PartyID]
      ,[AccountNumber]
      ,[IsDeleted]
      ,[profile_id]
      ,[PackageName]
      ,[ProviderTypeCode]
    
      ,[RiskDescriptor]
      ,[OwnerNo]
      ,[Risk]
      ,[RiskScore]
      --,[StatusBeginDate]
      ,[IncorporatedDate]
      ,[ActivationDate]
      ,[DateCreated]
      --,[LastActionDate]
      ,[LastAction]
      --,[LastActorUserID]
      ,[LastActionApprovedBy]
      ,[AccountUpdatedBy]
      ,[ProvTypeUpdateDate]
      ,[CreatedBy]
      ,[AccProcessing]-- KEN-7045
      ,[IsProvOwnedData]
      ,[ApplicationDate]
      ,[DateModified]--KPP-6612
      ,[AccountType])
      
      
SELECT  [portaluserid]
		,[Type]
		,[NPI]
		,[NpiType]
		,[ApplicationNo]
		--,'3 - Pending'--change '1 - Active'
		,@party_account_id
		, @account_number
		,0
		,[profile_id]
		,[ApplicationCode]
		,@provider_type_code
		,@risk
		,'01'
		,@priority
		,@composite_risk
		--,@date_created
		,@date_created
		,@date_created
		,@date_created
		--,@date_created
		,'C'
		--,@last_action_user_id
		,@last_action_user_id
		,'P'
		,@date_created
		,@last_action_user_id
		,1
		,1
		,[DateCreated]
		,getdate()
		,@accountType
FROM [KYPPORTAL].[PortalKYP].[pADM_Application] 
WHERE ApplicationID = @application_id;
SELECT @account_id = SCOPE_IDENTITY();
PRINT 'Create New AccountID: '+ CONVERT(VARCHAR(10),@account_id);

INSERT INTO [KYPEnrollment].[pADM_AccProvMapping](
               [AccountNumber]
			  ,[CurrentRecordFlag]
			  ,[LastAction]
			  ,[LastActionApprovedBy]
			  ,[LastActionDate]
			  ,[LastActorUserID])
      
VALUES (@account_number
        ,1
        ,'C'
        ,@last_action_user_id
        ,@date_created
        ,@last_action_user_id)
          
 PRINT 'Create Account Provider Mapping';           
        
SELECT @party_application = PartyID FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationID = @application_id;
INSERT INTO [KYPEnrollment].[pAccount_PDM_PracticeLanguage](
			 [PartyID]
			,[Language]
			,[IsDeleted]
			,[CurrentRecordFlag]
			,[LastAction]
			,[LastActionApprovedBy]
			,[LastActionDate]
			,[LastActorUserID]
)
SELECT @party_account_id
	   ,[Language]
	   ,0
	   ,1
	   ,'C'
	   ,@last_action_user_id
       ,@date_created
       ,@last_action_user_id
 FROM [KYPPORTAL].[PortalKYP].[pPDM_PracticeLanguage] WHERE PartyID=@party_application;
 PRINT 'Create Account Practice Language';     
 --PRINT 'Create Account Practice Language';     
 
 DECLARE @package_name VARCHAR(30)
 SELECT @package_name=PackageName FROM [KYPEnrollment].[pADM_Account] WHERE AccountID=@account_id;
 
 IF @is_group=1
 BEGIN
  EXEC [KYPEnrollment].[Create_TaxID_Associate]@account_id,@party_account_id,@account_number,@date_created;
 END
 
 
 EXEC [KYPEnrollment].[sp_Copy_Provider] @party_account_id,@party_application,@last_action_user_id;
 
RETURN  @account_id;
END


GO

