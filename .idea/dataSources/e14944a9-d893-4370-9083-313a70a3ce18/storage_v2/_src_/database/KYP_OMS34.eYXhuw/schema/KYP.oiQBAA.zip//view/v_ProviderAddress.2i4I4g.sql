
CREATE VIEW [KYP].[v_ProviderAddress] AS
SELECT D.AddressID,P.ApplicationID,P.PartyID,D.AddressLine1,D.AddressLine2,D.City,D.Country,D.State,D.Zip,D.ZipPlus4,D.USPSFlag 
FROM KYP.SDM_ApplicationParty P 
	INNER JOIN KYP.ADM_Application A ON A.ApplicationID = P.ApplicationID AND P.IsActive = 1 
	AND P.PartyType IN ('Provider Organization','Provider Person')
	INNER JOIN KYP.PDM_Location L ON L.PartyID = P.PartyID 
	INNER JOIN KYP.PDM_Address D ON D.AddressID = L.AddressID 
WHERE LTRIM(RTRIM(ISNULL(D.AddressLine1,''))) <> ''
	AND LTRIM(RTRIM(ISNULL(D.City,''))) <> ''
	AND LTRIM(RTRIM(ISNULL(D.State,''))) <> ''
	AND LTRIM(RTRIM(ISNULL(D.Zip,''))) <> ''


GO

