





/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[UpdatedMoca_by_TaxId]
	 @party_id INT ,
	 @last_action VARCHAR(1) ,
	 @party_id_app INT,
	 @app_id INT,
	 @account_id INT,
	 @profId VARCHAR(100) 
AS

BEGIN
	DECLARE @mainParty INT, @TypeAssociation VARCHAR(50),@npi varchar(10),@ownerno varchar(3)

	SELECT @mainParty = MainPartyID, @TypeAssociation=Type,@npi=acc.NPI,@ownerno=acc.ownerno FROM [KYPEnrollment].[pAccount_Party_Associate] party inner join kypenrollment.padm_account acc
	on party.AccountID=acc.AccountID 
	 WHERE party.PartyID=@party_id


	-----V.1 Replaces the declared table with a Temp table to reference 
	 IF OBJECT_ID('tempdb..#party_Associate') IS NOT NULL
       DROP TABLE #party_Associate
	Create  Table #party_Associate  (ID INT IDENTITY(1,1),PartyID INT)
	Create Clustered Index IDX_Associate on #party_Associate(ID,PartyID)
	-- drop table #party_Associate
	--kpp-7977
	INSERT INTO #party_Associate 
	SELECT party.PartyID FROM [KYPEnrollment].[pAccount_Party_Associate] party inner join kypenrollment.padm_account acc
	on party.AccountID=acc.AccountID inner join KYPEnrollment.pAccount_BizProfile_Details prof	ON acc.AccountID = prof.AccountID
	WHERE MainPartyID=@mainParty and party.CurrentRecordFlag=1  and acc.OwnerNo=@ownerno AND prof.ProfileID=@profId
	and IsPastOwner=0
	



	DECLARE @Address_Table TABLE (ID INT IDENTITY(1,1),MainPartyID INT, PartyID INT,AddressID INT,LocationID INT,AddressLine1 VARCHAR(250),AddressLine2 VARCHAR(50),County VARCHAR(25),City VARCHAR(25),ZipPlus4 VARCHAR(50),State VARCHAR(40), CurrentRecordFlag BIT)
	INSERT INTO @Address_Table SELECT @mainParty, loc.PartyID,addres.AddressID, loc.LocationID, addres.AddressLine1, addres.AddressLine2, addres.County, addres.City, addres.ZipPlus4, addres.State, addres.CurrentRecordFlag
	FROM [KYPEnrollment].[pAccount_PDM_Address] addres, [KYPEnrollment].[pAccount_PDM_Location] loc, [KYPEnrollment].[pAccount_PDM_Party] party 
	WHERE addres.AddressID = loc.AddressID and loc.IsDeleted=0 and loc.PartyID = party.PartyID and party.PartyID=@party_id
	
	

	UPDATE addr SET 
	AddressLine1 = addtable.AddressLine1, AddressLine2 = addTable.AddressLine2, City = addTable.City, County = addTable.County,
	State = addTable.State, ZipPlus4 = addTable.ZipPlus4, CurrentRecordFlag = addTable.CurrentRecordFlag ,LastAction=@last_action
	FROM 
	[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
	INNER JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAss ON loc.PartyID = partyAss.PartyID 
	LEFT JOIN @Address_Table addTable ON partyAss.MainPartyID = addTable.MainPartyID
	WHERE loc.PartyID in (SELECT PartyID FROM #party_Associate) --V.1

	

	/*  
			Update Person
	*/
	DECLARE @Person_Table TABLE(ID INT IDENTITY(1,1),PersonID INT,MainPartyID INT,PartyID INT,SSN VARCHAR(11),FirstName VARCHAR(25),LastName VARCHAR(25),MiddleName VARCHAR(25),DoB DATETIME, CurrentRecordFlag BIT)
	INSERT INTO @Person_Table SELECT person.PersonID, @mainParty ,person.PartyID, person.SSN, person.FirstName, person.LastName, person.MiddleName, person.DoB, person.CurrentRecordFlag
	FROM [KYPEnrollment].[pAccount_PDM_Person] person, [KYPEnrollment].[pAccount_PDM_Party] party 
	WHERE person.PartyID = party.PartyID and party.IsDeleted=0 and party.PartyID=@party_id

	

	UPDATE person SET
	SSN = personTable.SSN, FirstName = personTable.FirstName, LastName = personTable.LastName, 
	MiddleName = personTable.MiddleName, DoB= personTable.DoB, CurrentRecordFlag = personTable.CurrentRecordFlag,LastAction=@last_action
	FROM [KYPEnrollment].[pAccount_PDM_Person] person 
	INNER JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAss ON person.PartyID = partyAss.PartyID 
	LEFT JOIN @Person_Table personTable ON partyAss.MainPartyID = personTable.MainPartyID 
	WHERE person.PartyID in (SELECT PartyID FROM #party_Associate) --V.1

	/*  
			Update Organization
	*/
	DECLARE @Organization_Table TABLE(ID INT IDENTITY(1,1),OrgID INT ,MainPartyID INT,PartyID INT,LegalName VARCHAR(100),DBAName1 VARCHAR(MAX),Phone1 VARCHAR(15),
	Remarks VARCHAR(25),NPI VARCHAR(10),EIN VARCHAR(30),IsCorporation BIT,Extension VARCHAR(12),BusinessName VARCHAR(200), CurrentRecordFlag BIT)
	INSERT INTO @Organization_Table SELECT org.OrgID, @mainParty, org.PartyID, org.LegalName, org.DBAName1, org.Phone1, 
	org.Remarks, org.NPI, org.EIN, org.IsCorporation, org.Extension, org.BusinessName, org.CurrentRecordFlag
	FROM [KYPEnrollment].[pAccount_PDM_Organization] org, [KYPEnrollment].[pAccount_PDM_Party] party 
	WHERE org.PartyID = party.PartyID and party.IsDeleted=0 and party.PartyID=@party_id



	UPDATE org SET
	LegalName = orgTable.LegalName, DBAName1 = orgTable.DBAName1, Phone1 = orgTable.Phone1, Remarks = orgTable.Remarks, NPI = orgTable.NPI,
	EIN = orgTable.EIN, IsCorporation = orgTable.IsCorporation, Extension = orgTable.Extension, BusinessName = orgTable.BusinessName, 
	CurrentRecordFlag = orgTable.CurrentRecordFlag, LastAction=@last_action
	FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
	INNER JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAss ON org.PartyID = partyAss.PartyID 
	LEFT JOIN @Organization_Table orgTable ON partyAss.MainPartyID = orgTable.MainPartyID
	WHERE org.PartyID in (SELECT PartyID FROM #party_Associate) --V.1

	/*  
			Update Owner Role
	*/	
	DECLARE @OwnerRole_Table TABLE(ID INT IDENTITY(1,1),PdmOwnerID INT,MainPartyID INT, PartyID INT ,TypeForm VARCHAR(100),PercentCheck BIT,PercentValue VARCHAR(150),
	Partner BIT,PartnerValue VARCHAR(150),Managing BIT,Director BIT,DirectorValue VARCHAR(150),Other BIT,OtherValue VARCHAR(150),
	PercentDate SMALLDATETIME,PartnerDate SMALLDATETIME,ManagingDate SMALLDATETIME,OtherDate SMALLDATETIME,Agent BIT,OwnerRelationID INT,SoleOwner BIT, CurrentRecordFlag BIT)
	INSERT INTO @OwnerRole_Table SELECT ownerRole.PdmOwnerID, @mainParty, ownerRole.PartyID, ownerRole.TypeForm, ownerRole.PercentCheck, ownerRole.PercentValue,
	ownerRole.Partner, ownerRole.PartnerValue, ownerRole.Managing, ownerRole.Director, ownerRole.DirectorValue, ownerRole.Other,ownerRole.OtherValue,
	ownerRole.PercentDate, ownerRole.PartnerDate, ownerRole.ManagingDate, ownerRole.OtherDate, ownerRole.Agent, ownerRole.OwnerRelationID,ownerRole.SoleOwner, ownerRole.CurrentRecordFlag
	FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole, [KYPEnrollment].[pAccount_PDM_Party] party 
	WHERE ownerRole.PartyID = party.PartyID and party.IsDeleted=0 and party.PartyID=@party_id

	--rollback done

	UPDATE ownerRole SET
	TypeForm = ownerTable.TypeForm, PercentCheck = ownerTable.PercentCheck, PercentValue = ownerTable.PercentValue, Partner = ownerTable.Partner,
	PartnerValue = ownerTable.PartnerValue, Managing = ownerTable.Managing, Director = ownerTable.Director, DirectorValue =ownerTable.DirectorValue,
	Other = ownerTable.Other, OtherValue = ownerTable.OtherValue,PercentDate = ownerTable.PercentDate, PartnerDate = ownerTable.PartnerDate, 
	ManagingDate = ownerTable.ManagingDate, OtherDate = ownerTable.OtherDate,Agent = ownerTable.Agent, OwnerRelationID = ownerTable.OwnerRelationID, 
	SoleOwner = ownerTable.SoleOwner,CurrentRecordFlag = ownerTable.CurrentRecordFlag , LastAction=@last_action
	FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole 
	INNER JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAss ON ownerRole.PartyID = partyAss.PartyID 
	LEFT JOIN @OwnerRole_Table ownerTable ON partyAss.MainPartyID = ownerTable.MainPartyID
	WHERE ownerRole.PartyID in (SELECT PartyID FROM #party_Associate) --V.1



	------------------------------------------------------------------------------------------------------
	 --V.1 5/3/2017 This section replaces Update Adverse Action. It replaces the loop and inserts all associate partyid's that are associated with the parentpartyId into [KYPEnrollment].[pAccount_PDM_AdverseAction].
	 	

	--------------------------------------------------------------
		/*  
			Update Association
	
	--PRINT 'Update Association'
	--EXECUTE [KYPEnrollment].[Update_Associations]@last_action, @party_id_app, @app_id, @account_id,@profId*/
	
	

END


GO

