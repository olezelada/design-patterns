


CREATE VIEW [KYPEnrollment].[v_LT_Modalities] 
As
Select ROW_NUMBER() OVER (
  ORDER BY M.PartyId DESC
  ) AS RID,
  Case M.ModlityCode 
  When 'HDP' Then 'Herion Detoxification Program'
  When 'RS' Then 'Residential'
  When 'IOT' Then 'Intensive Outpatient Treatment'
  When 'NA' Then 'Naltrexone'
  When 'NTP' Then 'Narcotic Treatment Program'
  When 'ODF' Then 'Outpatient DrugFree'
  Else ''
  End As ServiceModality,
  M.LicenseNumber AS LicenseNumber, 
  CASE WHEN M.ReqTreatmentComp = 'Perinatal'
   THEN 'Yes'
  WHEN M.ReqTreatmentComp = 'Both Non-Perinatal and Perinatal'
   THEN 'Yes'
  ELSE 'No'
  END AS Parential
 ,CASE 
  WHEN M.ReqTreatmentComp = 'Non-Perinatal'
   THEN 'Yes'
  WHEN M.ReqTreatmentComp = 'Both Non-Perinatal and Perinatal'
   THEN 'Yes'
  ELSE 'No'
  END AS Non_Parential,
  COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(M.EffectiveDate as date), 101),''))),'NA') As EffectiveDate
 ,M.ReqTreatmentComp AS ReqTreatmentComp
 ,P.ParentPartyID
 ,A.ApplicationNo ApplicationNumber
 ,M.PartyId AS ModalityPartyId
from KYPPORTAL.PortalKYP.pPDM_Party P 
INNER JOIN KYPPORTAL.PortalKYP.pADM_Application A ON A.PartyID = P.ParentPartyID 
INNER JOIN KYPPORTAL.PortalKYP.pPDM_Modalities M ON M.PartyId = P.PartyID 
 AND M.Approved = 1


GO

