


CREATE TRIGGER [dbo].[DeleteAppRoles] 
   ON  [dbo].[ROLETABLE]
   AFTER DELETE
AS 
BEGIN

	update KYP.OIS_Role set Deleted = 1 where RoleName in (select RoleName from DELETED)

END


GO

