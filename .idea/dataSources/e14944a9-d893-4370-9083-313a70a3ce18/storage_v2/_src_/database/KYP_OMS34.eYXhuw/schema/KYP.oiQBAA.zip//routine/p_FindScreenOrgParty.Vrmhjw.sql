


CREATE PROCEDURE [KYP].[p_FindScreenOrgParty]
	-- Add the parameters for the stored procedure here
	@TrackingNumber varchar(20)
	,@OrgName varchar(100) 
	,@TAXID varchar(9) = NULL
	,@NPI varchar(10) = NULL
	,@City varchar(25) = NULL
	,@ZIP varchar(5) = NULL
	,@Adr_Line1 varchar(30) = NULL
	,@CurrentModule smallint = 1
	,@Isprovider int=0
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare 
		@PartyID_SameTAX_SameTracking int
		,@PartyID_SameNPI_SameTracking int
		,@PartyID_SameLegalName_SameTracking int
		,@PartyID_GenericMatch int
		,@MatchedPartyID int
		
	select 
		@PartyID_SameTAX_SameTracking = null	
		,@PartyID_SameNPI_SameTracking = null
		,@PartyID_SameLegalName_SameTracking = null
		,@PartyID_GenericMatch = null
		,@MatchedPartyID = null
		
	if @Isprovider=0
	begin
			/*select @PartyID_SameTAX_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Organization E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.TIN = @TAXID and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')*/
				
				
			select @PartyID_SameNPI_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Organization E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.NPI = convert(int, @NPI) and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')



			select @PartyID_SameLegalName_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Organization E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.LegalName = @OrgName and E.TIN = @TAXID and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')
         end
		else
		begin
			   /*select @PartyID_SameTAX_SameTracking = D.PartyID
				from KYP.ADM_Case A
				inner join KYP.ADM_Application B
					on A.CaseID = B.CaseID
				inner join KYP.SDM_ApplicationParty C
					on B.ApplicationID = C.ApplicationID
				inner join KYP.PDM_Party D
					on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
				inner join KYP.PDM_Organization E
					on D.PartyID = E.PartyID
				where 
					A.Number = @TrackingNumber	
					and E.TIN = @TAXID */
					
					
				select @PartyID_SameNPI_SameTracking = D.PartyID
				from KYP.ADM_Case A
				inner join KYP.ADM_Application B
					on A.CaseID = B.CaseID
				inner join KYP.SDM_ApplicationParty C
					on B.ApplicationID = C.ApplicationID
				inner join KYP.PDM_Party D
					on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
				inner join KYP.PDM_Organization E
					on D.PartyID = E.PartyID
				where 
					A.Number = @TrackingNumber	
					and E.NPI = convert(int, @NPI) 




				select @PartyID_SameLegalName_SameTracking = D.PartyID
				from KYP.ADM_Case A
				inner join KYP.ADM_Application B
					on A.CaseID = B.CaseID
				inner join KYP.SDM_ApplicationParty C
					on B.ApplicationID = C.ApplicationID
				inner join KYP.PDM_Party D
					on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
				inner join KYP.PDM_Organization E
					on D.PartyID = E.PartyID
				where 
					A.Number = @TrackingNumber	
					and E.LegalName = @OrgName and E.TIN = @TAXID

		
		end
				
				
	if (@PartyID_SameLegalName_SameTracking is null and @PartyID_SameNPI_SameTracking is null 
	--and  @PartyID_SameTAX_SameTracking is null
	)
	begin 			
			select @PartyID_GenericMatch = A.PartyID
			from KYP.PDM_Party A
			inner join KYP.PDM_Organization B
				on A.PartyID = B.PartyID 
				and ISNULL(A.IsDeleted,0) = 0 
			where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
				and B.LegalName = @OrgName
				and B.TIN = @TAXID	
				and ISNULL(B.NPI, 0) = ISNULL(convert(int, @NPI),0)	
				
	end
		
	select @MatchedPartyID = coalesce(
								@PartyID_SameTAX_SameTracking
								,@PartyID_SameNPI_SameTracking
								,@PartyID_SameLegalName_SameTracking
								,@PartyID_GenericMatch								
								,-1)
								
	return @MatchedPartyID								
	
END


GO

