
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Especial_OrthotistProsthetist]
      @application_Code  VARCHAR(100)
    , @app_provider_Type VARCHAR(100)
    , @account_id        INT
    , @acc_party_id      INT
    , @party_id_provider INT
    ,	@last_action_user_id VARCHAR(100)
AS
  BEGIN

    DECLARE @account_app_package_name VARCHAR(30)
    DECLARE @packageList TABLE(packageName VARCHAR(30) PRIMARY KEY)
    INSERT INTO @packageList (packageName)
    VALUES ('ISP_PP_AP'), ('ISP_OAP_AP'), ('ISP_RP_P_RA'), ('ISP_RP_OAP_RA'), ('IGSP_PP_AP'), ('IGSP_OAP_AP');

    SELECT @account_app_package_name = PackageName
    FROM [KYPEnrollment].[pADM_Account]
    WHERE AccountID = @account_id

     /*update type in table pAccount_PDM_Number Only Type*/
     EXEC [KYPEnrollment].[sp_Update_OrthotistProsthetist]
                                                @party_id_provider
                                                ,@application_Code
                                                ,@acc_party_id
                                                ,@last_action_user_id

    /*update packageCode for specialCase*/
    IF EXISTS(SELECT * FROM @packageList WHERE packageName = @application_Code) AND (@account_app_package_name != @application_Code)
      BEGIN
        PRINT 'Change_Package_Update_Special_Supplemental Orthotist&Prosthetist'
        UPDATE KYPEnrollment.pADM_Account
        SET PackageName = @application_Code, ProviderType = @app_provider_Type
        WHERE AccountID = @account_id
      END

  END


GO

