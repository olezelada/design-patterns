


CREATE PROCEDURE [KYP].[p_UpdatePDMOrganization] (
	@PartyID INT
	,@OrgNumber VARCHAR(25) = NULL
	,@OrgCategory VARCHAR(15) = NULL
	,@TIN VARCHAR(11) = NULL
	,@PrimaryDUNS VARCHAR(11) = NULL
	,@LegalName VARCHAR(100) = NULL
	,@DBAName1 VARCHAR(100) = NULL
	,@DBAName2 VARCHAR(100) = NULL
	,@IncTyp VARCHAR(15) = NULL
	,@IncState VARCHAR(2) = NULL
	,@IncDate SMALLDATETIME = NULL
	,@ForeginOwned BIT = NULL
	,@Email1 VARCHAR(50) = NULL
	,@Phone1 VARCHAR(15) = NULL
	,@Email2 VARCHAR(50) = NULL
	,@Phone2 VARCHAR(15) = NULL
	,@Remarks VARCHAR(25) = NULL
	,@CurrentModule SMALLINT = NULL
	,@CreatedBy INT = NULL
	,@DateCreated SMALLDATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified SMALLDATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted SMALLDATETIME = NULL
	,@NPI INT = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF ISNULL(@IncDate, '') = ''
	BEGIN
		SET @IncDate = NULL;
	END

	IF ISNULL(@ForeginOwned, '') = ''
	BEGIN
		SET @ForeginOwned = NULL;
	END

	IF ISNULL(@NPI, '') = ''
	BEGIN
		SET @NPI = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@OrgNumber, '')))) = ''
	BEGIN
		SET @OrgNumber = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@OrgCategory, '')))) = ''
	BEGIN
		SET @OrgCategory = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@TIN, '')))) = ''
	BEGIN
		SET @TIN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@PrimaryDUNS, '')))) = ''
	BEGIN
		SET @PrimaryDUNS = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LegalName, '')))) = ''
	BEGIN
		SET @LegalName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@DBAName1, '')))) = ''
	BEGIN
		SET @DBAName1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@DBAName2, '')))) = ''
	BEGIN
		SET @DBAName2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@IncTyp, '')))) = ''
	BEGIN
		SET @IncTyp = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@IncState, '')))) = ''
	BEGIN
		SET @IncState = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Email1, '')))) = ''
	BEGIN
		SET @Email1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone1, '')))) = ''
	BEGIN
		SET @Phone1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Email2, '')))) = ''
	BEGIN
		SET @Email2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone2, '')))) = ''
	BEGIN
		SET @Phone2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remarks, '')))) = ''
	BEGIN
		SET @Remarks = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_Organization] Set '

	IF @OrgNumber IS NOT NULL
		SET @updatelist = '[OrgNumber] = ''' + @OrgNumber + ''''

	IF @OrgCategory IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[OrgCategory] = ''' + replace(@OrgCategory, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[OrgCategory] = ''' + replace(@OrgCategory, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @TIN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[TIN] = ''' + replace(@TIN, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[TIN] = ''' + replace(@TIN, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @PrimaryDUNS IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PrimaryDUNS] = ''' + replace(@PrimaryDUNS, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[PrimaryDUNS] = ''' + replace(@PrimaryDUNS, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @LegalName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LegalName] = ''' + replace(@LegalName, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LegalName] = ''' + replace(@LegalName, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DBAName1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DBAName1] = ''' + replace(ISNULL(@DBAName1,@LegalName), '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[DBAName1] = ''' + replace(ISNULL(@DBAName1,@LegalName), '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DBAName2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DBAName2] = ''' + replace(@DBAName2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[DBAName2] = ''' + replace(@DBAName2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @IncTyp IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IncTyp] = ''' + replace(@IncTyp, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[IncTyp] = ''' + replace(@IncTyp, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @IncState IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IncState] = ''' + replace(@IncState, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[IncState] = ''' + replace(@IncState, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @IncDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IncDate] = ''' + convert(VARCHAR(25), @IncDate, 121) + ''''
		ELSE
			SET @updatelist = '[IncDate] = ''' + convert(VARCHAR(25), @IncDate, 121) + ''''
	END

	IF @ForeginOwned IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ForeginOwned] = ' + CAST(@ForeginOwned AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[ForeginOwned] = ' + CAST(@ForeginOwned AS VARCHAR(1)) + ''
	END

	IF @Email1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Email1] = ''' + replace(@Email1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Email1] = ''' + replace(@Email1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Email2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Email2] = ''' + replace(@Email2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Email2] = ''' + replace(@Email2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone2] = ''' + replace(@Phone2, '''', CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone2] = ''' + replace(@Phone2, '''', CHAR(39)) + ''''
	END

	IF @Remarks IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	IF @NPI IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[NPI] = ' + Convert(VARCHAR(12), @NPI)
		ELSE
			SET @updatelist = '[NPI] = ' + Convert(VARCHAR(12), @NPI)
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

