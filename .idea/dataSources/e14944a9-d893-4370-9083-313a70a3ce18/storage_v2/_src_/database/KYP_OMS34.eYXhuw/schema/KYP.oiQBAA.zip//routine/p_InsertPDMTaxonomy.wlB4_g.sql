






/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMTaxonomy]
(
  @PartyID int
  ,@Taxonomy varchar(20)
  ,@TaxonomyDesc varchar(max)
 
)
as begin 

INSERT INTO [KYP].[PDM_Taxonomy]
           ([PartyID]
           ,[Taxonomy]         
           ,[DateCreated]
           ,[TaxonomyDesc]
           )
     VALUES
           (@PartyID
           ,@Taxonomy 
           ,CONVERT(DATETIME,GETDATE(),121)
           ,@TaxonomyDesc
           )

	return IDENT_CURRENT('[KYP].[PDM_Taxonomy]')

end


GO

