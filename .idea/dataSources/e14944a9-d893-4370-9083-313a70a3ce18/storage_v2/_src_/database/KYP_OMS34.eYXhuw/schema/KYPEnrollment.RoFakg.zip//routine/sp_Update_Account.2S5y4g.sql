



/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.		Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		PI-760			Pullaiah	6 Apr 2017		Calling the Stored Procedure for an NR Application.
-- 2		CAPAVE-1742		Sundar		4 Jul 2017		Called the SP KYPEnrollment.usp_MocaInputDoc to tracking MOCA changes for Input Document generation.
-- 3						Sundar		15 May 2018		Comment calling for Usp_MocaInputDoc SP due to switching off of MOCA in Input Document

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Account] 
@application_no VARCHAR(15),
@account_number VARCHAR(20),
@last_action_user_id VARCHAR(100)
AS

BEGIN
  --mvc
  CREATE TABLE #subcontractors (
    pk INT IDENTITY (1, 1)
   ,PartyID_Portal INT
   ,Type_sub VARCHAR(50)
   ,PartyID_Enroll INT
  )
  --
  CREATE TABLE #signif (acc_PK_value int,partyOwner int)
  --
  DECLARE @application_id INT
         ,@acc_party_id INT
         ,@account_id INT
         ,@application_type VARCHAR(30)
         ,@party_id_provider INT
         ,@application_Code VARCHAR(200)
         ,@is_group BIT
         ,@activityStatus VARCHAR(50)
         ,@provider_Type_Code VARCHAR(50)
         ,@type_application VARCHAR(50)
         ,@crossoverIndicator BIT
		 ,@isAccount BIT
  SELECT
    @application_id = ApplicationID
   ,@application_type = ApplicationType
   ,@party_id_provider = PartyID
   ,@application_Code = PackagesName
   ,@provider_Type_Code = ProviderTypeCode
   ,@type_application = Type
   ,@isAccount = IsAccount
  FROM [KYPPORTAL].[PortalKYP].[pADM_Application]
  WHERE ApplicationNo = @application_no;
  SET @is_group = 0;

  SELECT @activityStatus = ActivityStatus
  FROM [KYPPORTAL].[PortalKYP].[pADM_Case]
  WHERE Number = @application_no;

  /*list of allowed packages to update by taxId*/
  DECLARE @packageList_TaxId TABLE(packageName VARCHAR(30) PRIMARY KEY)
  INSERT INTO @packageList_TaxId (packageName)
  VALUES('GSP_P_DM'),('GSP_AL_BL'),('IGSP_P_DM'),('IGSP_NP_AP'),('GSP_MDH'),('IGSP_FSP_ASC_IN'),('F_THS_OE'),('F_PHA_OE'),
		('IGSP_OP_AP'),('IGSP_PP_AP'),('IGSP_OAP_AP'),('GSP_OAP_BL'),('F_OOS_OE'),('FSP_DMC_IN'),('FSP_MDT_IN'),('F_CAEL_OE'),
		('F_CNAEL_OE'),('IGSP_FSP_DME_IN'),('F_BB_OE'),('F_PI_OE'),('F_CAEL_SP'),('F_CNAEL_SP'),('GISP_P_DM'),('GISP_NP_AP'),
		('ISP_NP_AP'),('ISP_OP_AP'),('F_PI_SP'),('F_BB_SP'),('F_THS_SP'),('ISP_PP_AP'),('ISP_OAP_AP'),('ISP_FSP_DME_SP'),
		('ISP_FSP_ASC_SP'),('ISP_FSP_CLP_SP'),('GISP_OAP_AP'),('F_PHA_SP'), ('ISP_P_DM'), ('FSP_MDT_SP'),('FSP_DMC_SP'),
		('IGSP_FSP_CLP_IN'),('F_DPP_OE'),('F_DPP_SP');

  /*list of allowed packages to update Delegates form*/
  DECLARE @packageList_delegates TABLE(packageName VARCHAR(30) PRIMARY KEY)
  INSERT INTO @packageList_delegates (packageName)
  VALUES ('GSP_P_DM'), ('GSP_AL_BL'), ('IGSP_P_DM'), ('IGSP_NP_AP'), ('ISP_MDH'), ('GSP_MDH'), ('GISP_P_DM'), ('GISP_NP_AP'),
     ('GISP_OAP_AP'), ('GSP_OAP_BL');

  /*update by taxId*/
  IF EXISTS(SELECT * FROM @packageList_TaxId WHERE packageName = @application_Code)
  BEGIN
    SET @is_group = 1;
    INSERT INTO #TaxIDChange (PartyID, TYPE, IsPrepopulated, TargetPath)
      SELECT
        PartyID
       ,Type
       ,IsPrepopulated
       ,TargetPath
      FROM [KYPPORTAL].[PortalKYP].pPDM_Party
      WHERE (Type = 'SubcontractorEntity'
      OR Type = 'SubcontractorIndividual'
      OR Type = 'TransactionEntity'
      OR Type = 'TransactionIndividual'
      OR Type = 'Entity Ownership'
      OR Type = 'Individual Ownership')
      AND ParentPartyID = @party_id_provider
      AND (IsPrepopulated IS NULL
      OR IsPrepopulated = 0)
      AND IsDeleted = 0
  END

  IF @application_type = 'CHOA'
    OR @application_type = 'CHOW'
    OR @application_type = 'Revalidation'
    OR @application_type = 'Reenrollment'
  BEGIN
    EXEC [KYPEnrollment].[sp_Disaffiliation_Account] @party_id_provider;
  END
  
  CREATE TABLE #Control_add_row (
    FiledID INT
   ,NameTable VARCHAR(200)
   ,AppPartyId INT NULL
   ,AccPartyID INT NULL
   ,TargePath VARCHAR(200) NULL
  )
  CREATE TABLE #Control_FieldCode (
    Section_code VARCHAR(50)
   ,Field_code VARCHAR(50)
  )

  DECLARE @field_code VARCHAR(100)
		 ,@data_type VARCHAR(100)
         ,@new_value_text VARCHAR(MAX)
         ,@new_value_int INT
         ,@new_value_date DATE
         ,@new_value_bool BIT
         ,@new_value_long BIGINT
         ,@new_value_double FLOAT
         ,@is_table BIT
         ,@table_code VARCHAR(20)
         ,@is_deleted BIT
         ,@row_uuid VARCHAR(100)
         ,@acc_table_name VARCHAR(100)
         ,@acc_PK VARCHAR(100)
         ,@acc_PK_value INT
         ,@action_taken VARCHAR(50)
         ,@accepted BIT
         ,@en_db_column VARCHAR(100)
         ,@target_path VARCHAR(200)
         ,@entity_id INT
         ,@stored_value VARCHAR(MAX)
         ,@new_fields_values VARCHAR(MAX)
         ,@section_nanme VARCHAR(MAX)
         ,@current_value_text VARCHAR(MAX)
         ,@section_code VARCHAR(50)

  DECLARE @ParamDefinition AS NVARCHAR(2000)
         ,@accPKvalue VARCHAR(100)
  SET @ParamDefinition = '@accPKvalue INT'
  SET @accPKvalue = CONVERT(VARCHAR(100), @acc_PK_value);
  declare @taxid varchar(100)
  SELECT
    @acc_party_id = PartyID
   ,@account_id = AccountID
   --,@taxid=ein
  FROM [KYPEnrollment].[pADM_Account]
  WHERE AccountNumber = @account_number
  AND IsDeleted = 0;
  
   select @taxid=replace(ein,'-','') from kypportal.portalkyp.ppdm_organization where partyid=@party_id_provider
  
  BEGIN TRANSACTION
  BEGIN TRY


    DECLARE @tabtempo TABLE (
      pk INT IDENTITY (1, 1)
     ,FieldCode VARCHAR(100)
	 ,DataType VARCHAR(100)
     ,NewValueText TEXT
     ,NewValueInt INT
     ,NewValueDate DATETIME
     ,NewValueBool BIT
     ,NewValueLong BIGINT
     ,NewValueDouble FLOAT
     ,IsTable BIT
     ,TableCode VARCHAR(20)
     ,IsDeleted BIT
     ,RowUUID VARCHAR(100)
     ,AccTableName VARCHAR(100)
     ,AccPK VARCHAR(100)
     ,AccPKValue INT
     ,ActionTaken VARCHAR(50)
     ,Accepted BIT
     ,EnDbColumn VARCHAR(100)
     ,TargetPath VARCHAR(200)
     ,EntityID INT
     ,StoredValue VARCHAR(MAX)
     ,NewFieldsValues TEXT
     ,SectionNanme VARCHAR(500)
     ,CurrentValueText VARCHAR(MAX)
     ,SectionCode VARCHAR(50)
    )
    INSERT INTO @tabtempo
      SELECT
        FieldCode
	   ,DataType
       ,NewValueText
       ,NewValueInt
       ,NewValueDate
       ,NewValueBool
       ,NewValueLong
       ,NewValueDouble
       ,IsTable
       ,TableCode
       ,IsDeleted
       ,RowUUID
       ,AccTableName
       ,AccPK
       ,AccPKValue
       ,ActionTaken
       ,Accepted
       ,EnDbColumn
       ,TargetPath
       ,EntityID
       ,StoredValue
       ,NewFieldsValues
       ,SectionNanme
       ,CurrentValueText
       ,SectionCode
      FROM [KYPPORTAL].[PortalKYP].[FieldValuesTracking]
      WHERE ApplicationID = @application_id
      AND ((sectionnanme <> 'Disclosure Information'
      OR TableCode <> 'delegatedTable'
      OR TableCode = 'settlementDelgTable'
      OR TableCode <> 'liableDelgTable'
      OR TableCode <> 'convictedDelgTable'
      OR sectionnanme <> 'Fee Information'
      OR TableCode NOT IN ('businessActivity', 'isLineCredit', 'isManufacturer','isCapitalSource')
      OR FieldCode NOT IN ('questionCapitalSource', 'questionLineCredit', 'questionManufacturer')
      )
      AND isnull(EnDbColumn,'') not in ('Day', 'TimeFrom','TimeTo'))
      AND sectionnanme <> 'Licensure Exemption'
     --** excluded all records related to Mocas for @is_group=1
      and (
	  	isnull(tablecode,'') not IN ('subcontractorTable','ownerTable','sigTransTable','ownerSubAssocTable','individualSubTable','otherAssocTable','otherEntAssocTable','subOwnerTable','entitySubTable','assoSubIndTable','assoSubOwnerTable','whollySuppliersTable','significantSubTable') 
		or (tablecode  IN ('subcontractorTable','ownerTable','sigTransTable','ownerSubAssocTable','individualSubTable','otherAssocTable','otherEntAssocTable','subOwnerTable','entitySubTable','assoSubIndTable','assoSubOwnerTable','whollySuppliersTable','significantSubTable') and @is_group=0)
		  )
	  and (
		(tablecode  IN ('licenseActions','settlementTable','licenseActions','convictedTable','liableTable','suspendedTable','selfPartTable') and (sectionnanme='Contract/Program Actions' or sectionnanme='License Actions' or sectionnanme ='Medicaid/Medicare Participation' or @is_group=0))
		or isnull(tablecode,'')  not IN ('licenseActions','settlementTable','licenseActions','convictedTable','liableTable','suspendedTable','selfPartTable')
		   )
      ORDER BY FieldValueID

          UPDATE @tabtempo
          SET Accepted = 1

          DECLARE @UserDate DATE = GETDATE(); --PI-760 (#1)
        --exec [KYPEnrollment].[sp_Insert_AccountInputDoc] @account_id,'sysNRApp',@UserDate; --PI-760	(#1)

    DECLARE @totreg INT
           ,@cont INT
    SELECT
      @totreg = MAX(pk)
    FROM @tabtempo
    SET @cont = 1
    WHILE @cont <= @totreg

    BEGIN

    SELECT
      @field_code = FieldCode
	 ,@data_type = DataType
     ,@new_value_text = NewValueText
     ,@new_value_int = NewValueInt
     ,@new_value_date = NewValueDate
     ,@new_value_bool = NewValueBool
     ,@new_value_long = NewValueLong
     ,@new_value_double = NewValueDouble
     ,@is_table = IsTable
     ,@table_code = TableCode
     ,@is_deleted = IsDeleted
     ,@row_uuid = RowUUID
     ,@acc_table_name = AccTableName
     ,@acc_PK = AccPK
     ,@acc_PK_value = AccPKValue
     ,@action_taken = ActionTaken
     ,@accepted = Accepted
     ,@en_db_column = EnDbColumn
     ,@target_path = TargetPath
     ,@entity_id = EntityID
     ,@stored_value = StoredValue
     ,@new_fields_values = NewFieldsValues
     ,@section_nanme = SectionNanme
     ,@current_value_text = CurrentValueText
     ,@section_code = SectionCode
    FROM @tabtempo
    WHERE PK = @cont
    AND Accepted = 1

    DECLARE @update NVARCHAR(MAX)
           ,@data VARCHAR(MAX)
           ,@is_text_date CHAR(1)
           ,@data_real VARCHAR(100)
    SET @data = ISNULL(CONVERT(VARCHAR(MAX), @new_value_text), ISNULL(CASE
      WHEN CONVERT(VARCHAR(100), @new_value_date) = '1900-01-01' THEN ''
      ELSE CONVERT(VARCHAR(100), @new_value_date)
    END, ISNULL(CASE
      WHEN CONVERT(VARCHAR(100), @new_value_int) = '0' THEN ''
      ELSE CONVERT(VARCHAR(100), @new_value_int)
    END,
    ISNULL(CASE
      WHEN CONVERT(VARCHAR(100), @new_value_bool) = '0' THEN '0'
      ELSE CONVERT(VARCHAR(100), @new_value_bool)
    END, ISNULL(CASE
      WHEN CONVERT(VARCHAR(100), @new_value_long) = '0' THEN ''
      ELSE CONVERT(VARCHAR(100), @new_value_long)
    END, '')))))


    IF @section_nanme = 'EIN/Licenses'
      AND @field_code = 'taxId'
      AND NOT EXISTS (SELECT
          ID
        FROM #TaxIDChange
        WHERE IsChangeTaxID = 1)
      AND @is_group = 1
    BEGIN
      INSERT INTO #TaxIDChange (IsChangeTaxID)
        VALUES (1)
      
      SET @current_value_text = REPLACE(@current_value_text, '-', '')

    
    END

    IF (@new_value_text IS NOT NULL
      OR @new_value_date IS NOT NULL
      OR @new_value_double IS NOT NULL
      OR @new_value_long IS NOT NULL)
    BEGIN
      SET @data_real = LTRIM(STR(@new_value_double, 10, 7))
      IF (@data_real <> '')
        SET @data = @data_real;
      SET @is_text_date = '1'
    END

    ELSE
    BEGIN
      SET @is_text_date = '0'
    END

    IF @section_nanme = 'Individual Information'
      AND @field_code = 'npiNumber'
      AND @acc_PK_value IS NOT NULL
    BEGIN
      UPDATE person
      SET person.NPI = provider.NPI
      FROM KYPEnrollment.pAccount_PDM_Person person
      INNER JOIN KYPEnrollment.pAccount_PDM_Provider provider
        ON person.PartyID = provider.PartyID
      WHERE provider.ProvID = @acc_PK_value
    END
    --mvc
    --update radios in pAccount_PDM_ProviderQuestionnarie]
    IF @field_code IN ('subcontractorRadio', 'subcontractorRadio2')
      AND @en_db_column IS NULL
    BEGIN

    	if exists(select Questionid from  [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] where name=@field_code and PartyID=@acc_party_id)
			begin
				update [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] set value =case when @new_value_text is null or @new_value_text='' then 'No' else @new_value_text end where name=@field_code and PartyID=@acc_party_id
			end
			else
			begin
				  INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
				  [PartyID],
				  [Type],
				  [Name],
				  [Value],
				  [CurrentRecordFlag],
				  [IsDeleted]) 
				  values (
				  @acc_party_id,
				  'SubcontractorRadio',
				  @field_code,
				  case when @new_value_text is null or @new_value_text='' then 'No' else @new_value_text end,
				  1,
				  0)                  

			end
    END

	IF (@field_code = 'diabetesCode' AND ISNULL(@data_type,'') = 'string' AND @application_Code IN ('GISP_P_DM','ISP_P_DM','IGSP_P_DM','GSP_P_DM', 'F_THS_OE','F_THS_SP'))
    BEGIN
      EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_By_Type] 'FormProfessionalLicenseCert'
                                                                    , @acc_party_id
                                                                    , @new_value_text
                                                                    , @party_id_provider;
    END
	
  IF (@activityStatus != 'CrossoverToFull' OR @activityStatus != 'FullToCrossover')
  BEGIN

    EXEC [KYPEnrollment].[sp_Create_Update_CAMMIS_Acc_Field]
                                                @en_db_column
                                                ,@last_action_user_id
                                                ,@section_nanme
                                                ,@acc_party_id
                                                ,@new_value_text
                                                ,@target_path
                                                ,@is_deleted

  END

    --  no table 
    IF (@is_table IS NULL
      OR @is_table = 'false')
      AND @en_db_column IS NOT NULL
    BEGIN
      PRINT @en_db_column;

      IF @stored_value = 'radio'
        AND @section_nanme = 'Place of Business'
      BEGIN
        SET @data = @new_fields_values;
      END

      IF  (@field_code IN ('leaseOption','ownOption')
          AND @row_uuid IS NULL
          AND @target_path LIKE '%|%'
          AND @section_code='2.5.1'
          AND @application_Code IN ('F_PI_OE', 'F_PI_SP', 'F_CAEL_SP', 'F_CAEL_OE', 'F_CNAEL_SP', 'F_CNAEL_OE', 'F_OOS_OE', 'F_BB_SP', 'F_BB_OE', 'ISP_FSP_DME_SP', 'IGSP_FSP_DME_IN', 'F_DPP_SP','F_DPP_OE'))
      BEGIN
          DECLARE @newPartyPlace INT
          SELECT @newPartyPlace = COUNT (PartyID) FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
          WHERE Type = 'Lease Information' AND ParentPartyID = @party_id_provider AND IsDeleted = 0 AND  TargetPath NOT LIKE '%|%';
          IF (@newPartyPlace = 1)
          BEGIN
            EXEC [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios] @acc_party_id, @party_id_provider, @last_Action_User_ID,  @account_id, 1;
          END
      END

      ---
      -- get code for radio of location stock
      ------
      IF @field_code = 'radioBtnStockOne'
      BEGIN
        IF @data IN ('In stock on the premises')
        BEGIN
          SET @data = 'valueOneStock';
        END
        ELSE
        IF @data IN ('In a warehouse under the direct control of')
        BEGIN
          SET @data = 'valueTwoWarehouse';
        END
        ELSE
        IF @data IN ('Both in stock on premises and in a warehouse under the direct control of')
        BEGIN
          SET @data = 'valueThreeBoth';
        END

        --create or update radio
        
        IF @acc_table_name IS NULL
		BEGIN

    		if exists(select Questionid from  [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] where name='radioLocationStock' and PartyID=@acc_party_id)
				begin
					update [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] set value = @data  where name='radioLocationStock' and PartyID=@acc_party_id
				end
				else
				begin
					  INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
					  [PartyID],
					  [Type],
					  [Name],
					  [Value],
					  [CurrentRecordFlag],
					  [IsDeleted]) 
					  values (
					  @acc_party_id,
					  'phLocationOfStock',
					  'radioLocationStock',
					  @data,
					  1,
					  0)                  

				end
		END
		
		
		----------------------------

        PRINT 'LOCATION STOCK RADIO VALUE:';
        PRINT @data;
      END
      

      
      IF @field_code = 'stockAddress'  and @action_taken = 'Added' and @is_deleted = 0  
      BEGIN        
          EXEC [KYPEnrollment].[sp_Copy_Address_Location] @acc_party_id, @party_id_provider, 'locationOfStock', @last_Action_User_ID;      
      END
      
      
      
      IF @action_taken='Deleted' and @is_deleted = 1 AND @field_code like 'stock%'
		BEGIN
			PRINT @action_taken		
			 SET @accPKvalue = CONVERT(VARCHAR(100), @acc_PK_value);
			 SET @update = 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + ' = ' + '@accPKvalue'
			 
			 PRINT 'DELETE ADDRESS LOCATION STOCK';
			 PRINT @update;
			 
			  EXEC sp_executesql @update
							  ,@ParamDefinition
							  ,@accPKvalue
		END
		
		
		IF @field_code IN ('radioBtnStockAddress')   AND 	@acc_table_name IS NULL
		BEGIN

    		if exists(select Questionid from  [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] where name='radioLocStockAddress' and PartyID=@acc_party_id)
				begin
					update [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] set value =case when @new_value_text is null or @new_value_text='' then 'No' else @new_value_text end where name='radioLocStockAddress' and PartyID=@acc_party_id
				end
				else
				begin
					  INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
					  [PartyID],
					  [Type],
					  [Name],
					  [Value],
					  [CurrentRecordFlag],
					  [IsDeleted]) 
					  values (
					  @acc_party_id,
					  'phLocationOfStock',
					  'radioLocStockAddress',
					  case when @new_value_text is null or @new_value_text='' then 'No' else @new_value_text end,
					  1,
					  0)                  

				end
		END
		
		
		--Section code 3.6.2 for malpractice Pharmacy in charge
    IF @section_code = '3.6.2'  and	@acc_table_name IS NULL
    BEGIN
		DECLARE @malpractice_id INT,
			@dateCreated date;
	
			SET @dateCreated = GETDATE()	

            SELECT @malpractice_id = InsuranceID
                              FROM KYPEnrollment.pAccount_PDM_Insurance
                              WHERE PartyID = @acc_party_id AND Type IN ('malpracticeInsPharmacy')
            IF @malpractice_id is null OR @malpractice_id = 0
              BEGIN
              PRINT 'CREATE MALPRACTICE INFORMATION FOR PHARMACY';
              
              INSERT INTO [KYPEnrollment].[pAccount_PDM_Insurance]
                ([PartyID] ,
                [PolicyNumber] ,
                [Type] ,
                [IssuanceDate] ,
                [ExpirationDate] ,
                [MinimumOccurrence] ,
                [AnualAggregate] ,
                [LastAction],
                [LastActionDate],
                [LastActorUserID]	,
                [LastActionApprovedBy],
                [CurrentRecordFlag])
                SELECT @acc_party_id
                ,[PolicyNumber]
                ,[Type]
                ,[IssuanceDate]
                ,[ExpirationDate]
                ,[MinimumOccurrence]
                ,[AnualAggregate]
                ,'C'
                ,@dateCreated
                ,@last_action_user_id
                ,@last_action_user_id
                ,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
				FROM [KYPPORTAL].[PortalKYP].[pPDM_Insurance] WHERE PartyID = @party_id_provider and Type IN ('malpracticeInsPharmacy')				
	
               
                  SET @malpractice_id = SCOPE_IDENTITY()
              END

        IF @en_db_column = 'PolicyNumber'
          BEGIN
           PRINT 'UPDATE MALPRACTICE INFORMATION FOR PHARMACY';
            UPDATE KYPEnrollment.pAccount_PDM_Insurance set PolicyNumber = @new_value_text WHERE InsuranceID = @malpractice_id
          END
    END

    DECLARE @type_questionnarie VARCHAR(100);
		IF @field_code IN ('questionSuspensionRevoked', 'questionDisciplineHearing', 'questionLicense')   AND 	@acc_table_name IS NULL
		BEGIN
			SET @type_questionnarie = 'pharmacyAdverseActions';
			
			EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionSuspensionRevoked', 'questionSuspensionRevoked', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionDisciplineHearing', 'questionDisciplineAuthority', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionLicense', 'questionLicenseAuthority', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
		END
	--Activity forms pharmacy
			IF @field_code IN ('questionTradeSale', 'questionRehabilitation', 'questionStaff')   AND 	@acc_table_name IS NULL
		BEGIN
			  SET @type_questionnarie = 'activity';

			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionTradeSale', 'questionTradeSale', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionRehabilitation', 'questionRehabilitation', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'questionStaff', 'questionStaff', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;

		END
		-- Activity DME
		IF  @section_code = '2.8.1' AND @field_code IN ('radioOne', 'radioTwo', 'radioThree', 'radioFour', 'radioFive', 'radioSix')   AND 	@acc_table_name IS NULL
		BEGIN
			  SET @type_questionnarie = 'licenseDurable';

			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioOne', 'radioOne', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioTwo', 'radioTwo', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioThree', 'radioThree', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioFour', 'radioFour', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioFive', 'radioFive', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;
			  EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioSix', 'radioSix', @new_value_text, @acc_party_id, @type_questionnarie, @party_id_provider;

		END

    --Daily Operations
		IF @field_code like 'radioBtnQuestion%' AND  @acc_table_name IS NULL
		BEGIN
			DECLARE @type_questionnariedaily VARCHAR(100);
			SET @type_questionnariedaily = 'dailyOperation';

			IF @application_Code IN ('F_PHA_OE','F_PHA_SP' )
			  BEGIN
					--Pharmacy
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionOne', 'questionOneEquipment', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionTwo', 'questionTwoBusiness', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionThree', 'questionThreeServices', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionFour', 'questionFourInventory', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionFive', 'questionFiveSellRent', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
			  END
			  ELSE IF @application_Code IN ('ISP_FSP_DME_SP', 'IGSP_FSP_DME_IN')
			  BEGIN
					--DME
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionOne', 'firstDailyOperationsQuestion', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionTwo', 'secondDailyOperationsQuestion', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
					EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnQuestionThree', 'thirdDailyOperationsQuestion', @new_value_text, @acc_party_id, @type_questionnariedaily, @party_id_provider;
			  END
		END

		--Hours of Operations
		IF @field_code IN ('radioBtnHourOperation')   AND 	@acc_table_name IS NULL
		BEGIN
			DECLARE @type_questionnariehoursop VARCHAR(100);
			SET @type_questionnariehoursop = 'phHoursOfOperation';

			EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code, 'radioBtnHourOperation', 'questionBusinessHour', @new_value_text, @acc_party_id, @type_questionnariehoursop, @party_id_provider;
		END

  -- business profile pharmacy
     IF @section_code = '2.1.1' and @field_code IN ('specialty', 'locate', 'ownedOperate', 'prospectivePayment')   AND  @acc_table_name IS NULL
     BEGIN
       EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code,'specialty','specialty',@new_value_text, @acc_party_id, 'businessProfile', @party_id_provider;
       EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code,'locate','locate',@new_value_text, @acc_party_id, 'businessProfile', @party_id_provider;
       EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code,'ownedOperate','ownedOperate',@new_value_text, @acc_party_id, 'businessProfile', @party_id_provider;
       EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code,'prospectivePayment','prospectivePayment', @new_value_text, @acc_party_id, 'businessProfile', @party_id_provider;
     END

      -- business profile
      IF @section_code = '2.1.1'
      BEGIN
        EXEC [KYPEnrollment].[sp_Update_Entity_Type] @application_id,@field_code,'entityType',@party_id_provider
      END

     -- activity license service
      IF @section_code = '3.4.1' AND @acc_table_name IS NULL
      BEGIN

        EXEC [KYPEnrollment].[sp_Create_Update_DEA] @field_code,'deaLicenseNumber',@new_value_text,@party_id_provider,@acc_party_id,@last_action_user_id
        EXEC [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio] @field_code,'sellerPermit','sellerPermit', @new_value_text, @acc_party_id, 'Professional License', @party_id_provider;

        IF @field_code IN ('permitNumber', 'issueDate', 'ncpdpNumber')
        BEGIN
          EXEC [KYPEnrollment].[sp_Create_Update_Number] @party_id_provider,@acc_party_id,@last_action_user_id,'Professional License'
        END

      END

      -- Professional License Primary
      IF @section_code = '3.1.1'
          AND @acc_table_name IS NULL
          AND @field_code like 'primaryLicence%'
      BEGIN
        PRINT 'Verifying: Primary Licenses...';
        EXEC [KYPEnrollment].[sp_Create_Update_Primary_License] @party_id_provider,@acc_party_id,@last_action_user_id,'Professional License'
      END

      -- pharmacist in charge
      IF @section_code = '3.6.1' AND @acc_table_name IS NULL
      BEGIN
        EXEC [KYPEnrollment].[sp_Create_Update_Pharmacist_Information] @party_id_provider,@acc_party_id,@last_action_user_id,@account_id,'PharmacistInformation'
      END

      /* action take deleted DBAB-32 */
      IF @action_taken = 'Deleted'
      BEGIN
        SET @accPKvalue = CONVERT(VARCHAR(100), @acc_PK_value);
        SET @update = 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET ' + @en_db_column + ' = NULL WHERE ' + @acc_PK + ' = ' + '@accPKvalue'

        EXEC sp_executesql @update
                          ,@ParamDefinition
                          ,@accPKvalue
      --EXECUTE(@update)
      END
      EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name
                                            ,@en_db_column
                                            ,@data
                                            ,@acc_PK
                                            ,@acc_PK_value
                                            ,@is_text_date
                                            ,@stored_value
                                            ,@last_action_user_id
                                            ,@action_taken;
    END
    --end if no table
    ELSE
     begin
       EXEC [KYPEnrollment].[sp_Update_Account_Table] @acc_party_id
                                                    ,@table_code
                                                    ,@action_taken
                                                    ,@last_action_user_id
                                                    ,@target_path
                                                    ,@en_db_column
                                                    ,@data
                                                    ,@acc_PK
                                                    ,@acc_PK_value
                                                    ,@is_text_date
                                                    ,@acc_table_name
                                                    ,@entity_id
                                                    ,@stored_value
                                                    ,@account_id
                                                    ,@new_fields_values
                                                    ,@row_uuid
													,@application_id
                                                    ,@party_id_provider
													,@application_Code;
     end

     IF @activityStatus = 'CrossoverToFull'
     BEGIN

         EXEC [KYPEnrollment].[sp_Create_Update_New_Field]
                                                @en_db_column
                                                ,@last_action_user_id
                                                ,@action_taken
                                                ,@account_id
                                                ,@section_nanme
                                                ,@acc_party_id
                                                ,@new_value_text
                                                ,@target_path
                                                ,@new_fields_values
                                                ,@new_value_date
                                                ,@application_Code
                                                ,@field_code
                                                ,@party_id_provider
                                                ,@section_code
     END

     /*create field for Portable Imaging package*/
     EXEC [KYPEnrollment].[sp_Update_Not_Created_Field] @account_id
                                                       ,@acc_party_id
                                                       ,@application_Code
                                                       ,@party_id_provider
                                                       ,@section_code
                                                       ,@last_action_user_id

    IF (@application_Code IN ('F_PI_OE', 'F_PI_SP') AND
        @section_code = '3.2.1' AND
        (@target_path NOT LIKE  '%|%' OR @target_path IS NULL)AND
        @field_code IN ('rayCode', 'mammographyCode', 'ultrasoundCode', 'otherCode'))
    BEGIN
       EXEC [KYPEnrollment].[sp_UpdateNewDataServiceList] @section_code,
                                                          @field_code,
                                                          @party_id_provider,
                                                          @acc_party_id,
                                                          @last_Action_User_ID;
    END

     IF ( @application_Code ='GSP_OAP_BL' OR @application_Code ='GISP_OAP_AP')
         AND @provider_Type_Code='100'
     BEGIN
        EXEC [KYPEnrollment].[sp_Create_Update_Especial_Clia]
                                                @en_db_column
                                                ,@last_action_user_id
                                                ,@acc_party_id
                                                ,@new_value_text
                                                ,@section_nanme

        UPDATE KYPEnrollment.pADM_Account set ProviderType = @type_application, ProviderTypeCode = @provider_Type_Code
        WHERE AccountID = @account_id
     END

     EXEC [KYPEnrollment].[sp_Update_Organization_Ein]
                                                 @party_id_provider
                                                 ,@acc_party_id

      IF ( @application_Code ='F_OOS_OE')
      BEGIN
      EXEC [KYPEnrollment].[sp_Update_State_Hospital]
                                                 @party_id_provider
                                                 ,@acc_party_id
                                                 ,@last_action_user_id
                                                 ,@en_db_column
                                                 ,@new_value_text
                                                 ,@section_nanme
      END

      EXEC [KYPEnrollment].[UpdateBloodBankSections]@application_Code
                                                    ,@acc_party_id
                                                    ,@last_action_user_id
                                                    ,@party_id_provider

	  EXEC [KYPEnrollment].[sp_UpdateFieldNumberServiceAddress]
                                                @en_db_column
                                                ,@last_action_user_id
                                                ,@action_taken
                                                ,@acc_party_id
                                                ,@new_value_text
                                                ,@field_code
                                                ,@section_code
                                                ,@application_Code

    SET @cont = @cont + 1
    END
   --end while 
  --for new model large moca
   if @is_group=1
    begin
     exec [KYPEnrollment].[InsertUpdateMOCANewModel] @account_id,@acc_party_id,@taxid,@application_id,@party_id_provider,@last_action_user_id,1,@application_type
    end
   -- 
  IF(@activityStatus = 'CrossoverToFull')
    BEGIN
      EXEC [KYPEnrollment].[UpdateSpecialSectionsCrossover] @application_Code
                                                            ,@acc_party_id
                                                            ,@last_action_user_id
                                                            ,@party_id_provider
       SET @crossoverIndicator = 0;
              EXEC [KYPEnrollment].[Update_Crossover_Indicator] @account_id,
                                                          @crossoverIndicator
    END

    IF ( @application_Code ='FSP_DMC_IN' OR @application_Code ='FSP_DMC_SP')
     BEGIN
        EXEC [KYPEnrollment].[sp_Update_Address_Modalities] @acc_party_id,
                                                          @party_id_provider,
                                                          @last_action_user_id,
                                                          @provider_Type_Code
     END

     IF ( @application_Code ='F_CAEL_SP' OR @application_Code ='F_CAEL_OE')
     BEGIN
        EXEC [KYPEnrollment].[sp_Update_Exempt_Licensure] @acc_party_id,
                                                          @party_id_provider;
     END

    IF @application_Code = 'ISP_P_ORP'
      AND EXISTS (SELECT
          FieldValueID
        FROM KYPPORTAL.PortalKYP.FieldValuesTracking
        WHERE ApplicationID = @application_id
        AND SectionNanme = 'Business Profile')
    BEGIN
      EXEC [KYPEnrollment].[ORP_Service_Address] @account_id
                                                ,@acc_party_id
                                                ,1;
    END

   
    --UPDATE DELEGATED OFFICIALS
    IF EXISTS(SELECT * FROM @packageList_delegates WHERE packageName = @application_Code)
    BEGIN
      EXEC [KYPEnrollment].[sp_Copy_Delegated_Officials] @acc_party_id
                                                        ,@party_id_provider
                                                        ,@last_Action_User_ID
                                                        ,NULL
                                                        ,@account_id
                                                        ,1;
    END


    
    -- Update Logistics BusinessHours.
	IF @application_Code = 'ISP_MDH' OR @application_Code = 'GSP_MDH' OR @application_Code = 'RP_MDH'
	BEGIN
	
		-- Update Copy Address Rendering MD. 
		IF @application_Code = 'RP_MDH'
		BEGIN
			EXEC [KYPEnrollment].[sp_Update_Address_Rendering_MD] @acc_party_id,@last_Action_User_ID;
		END
		
		EXEC [KYPEnrollment].[sp_Update_Business_Hours] @acc_party_id, @application_id, @last_Action_User_ID;
	END
	
    -- Update Logistics BusinessHours, Incontinence Tables  for CA packages.
	IF @application_Code in ('FSP_MDT_IN','FSP_MDT_SP','F_PHA_OE','F_PHA_SP' , 'ISP_FSP_DME_SP', 'IGSP_FSP_DME_IN')
	BEGIN
		EXEC [KYPEnrollment].[sp_Update_Business_Hours_CA] @acc_party_id, @application_id, @last_Action_User_ID;

		--Update Business Activity,  Incontinence Tables
		EXEC [KYPEnrollment].[sp_Copy_BusinessActivity_IncontinenceTable] @party_id_provider, @acc_party_id, @last_Action_User_ID, null, @account_id, true;
		
		  -- Update Mode of transportation.
		IF @application_Code in ('FSP_MDT_IN','FSP_MDT_SP')
		BEGIN
			EXEC [KYPEnrollment].[sp_Update_Mode_of_Transportation] @acc_party_id, @application_id, @last_Action_User_ID;
			IF (ISNULL(@isAccount, 0) = 1)
			BEGIN
				-- Update Denied Selective approval for Operators and Vehicles (only for pre-populated Vehicles and Operators)
				EXEC [KYPEnrollment].[sp_update_denied_Transportation] @party_id_provider;
				-- Update Only EffectiveDate for Operators and Vehicles (pre-populated in the Supplemental app)
				EXEC [KYPEnrollment].[sp_update_Approved_Transportation_EffectiveDate] @party_id_provider;
			END
		END
		
	END



	-- Update application Fee
	EXEC [KYPEnrollment].[sp_Update_ApplicationFee] @acc_party_id, @party_id_provider, @last_Action_User_ID;

    --Commented for #3 Switching off MOCAs in Input Document
    --Added calling of SP for #2 CAPAVE-1742
    --EXEC KYPEnrollment.usp_MocaInputDoc @account_id


 IF (@activityStatus IS NOT NULL AND (@activityStatus = 'CrossoverToFull' OR @activityStatus = 'FullToCrossover'))
      BEGIN
        IF EXISTS (SELECT
                    FieldValueID
                    FROM KYPPORTAL.PortalKYP.FieldValuesTracking
                    WHERE ApplicationID = @application_id)
          BEGIN
            EXEC [KYPEnrollment].[Change_Package_Update_Special_Supplemental] @account_id
                                                                          ,@acc_party_id
                                                                          ,@application_id
                                                                          ,@activityStatus
          END

        IF(@activityStatus = 'FullToCrossover')
          BEGIN
             EXEC [KYPEnrollment].[FinishAffiliationAndMocaCrossover]  @account_id
                                                                      ,@acc_party_id
                                                                      ,@application_id
             SET @crossoverIndicator = 1;
             EXEC [KYPEnrollment].[Update_Crossover_Indicator] @account_id,
                                                          @crossoverIndicator
          END
      END

    /*to update PackageName for Orthotist & Prosthetist Especial Case*/
  EXEC [KYPEnrollment].[sp_Update_Especial_OrthotistProsthetist]
                                                           @application_Code
                                                          ,@type_application
                                                          ,@account_id
                                                          ,@acc_party_id
                                                          ,@party_id_provider
                                                          ,@last_Action_User_ID

  EXEC [KYPEnrollment].[sp_Update_Attachments_Plain_Forms_References]
                                                            @accountId = @account_id
                                                            , @applicationId = @application_id;

  EXEC [KYPEnrollment].[sp_Update_Attachments_References_AppPartyId]
                                                                @account_id
                                                                ,@application_id;

    COMMIT TRANSACTION
  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0
      ROLLBACK TRANSACTION
    DECLARE @error_message NVARCHAR(4000)
           ,@error_severity INT;
    SELECT
      @error_message = ERROR_MESSAGE()
     ,@error_severity = ERROR_SEVERITY();
    RAISERROR (@error_message, @error_severity, 1);
    
    EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @application_id
    
  END CATCH


  DROP TABLE #Control_add_row
  DROP TABLE #subcontractors
  DROP TABLE #signif
  DROP TABLE #Control_FieldCode
END


GO

