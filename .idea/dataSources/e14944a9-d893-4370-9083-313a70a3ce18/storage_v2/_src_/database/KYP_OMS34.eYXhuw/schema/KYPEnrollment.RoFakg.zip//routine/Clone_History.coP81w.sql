CREATE PROCEDURE  [KYPEnrollment].[Clone_History]
  @account_id INT,
  @clone_account_id INT
AS
BEGIN
SET NOCOUNT ON 
INSERT INTO [KYPEnrollment].[pAccount_History]
           ([AccountID]
           ,[RelatedID]
           ,[ActionID]
           ,[Remarks]
           ,[DateCreated]
           ,[CreatedBy]
           ,[DeletedBy]
           ,[IsDeleted]
           ,[LastActorUserID]
           ,[ModificationSemanticDescription]
           ,[ModifiyingEvent]
           ,[LastActionDate]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction])
     SELECT @clone_account_id
           ,[RelatedID]
           ,[ActionID]
           ,HistoryID--[Remarks]
           ,[DateCreated]
           ,[CreatedBy]
           ,[DeletedBy]
           ,[IsDeleted]
           ,[LastActorUserID]
           ,[ModificationSemanticDescription]
           ,[ModifiyingEvent]
           ,[LastActionDate]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction]
           FROM [KYPEnrollment].[pAccount_History] WHERE AccountID = @account_id;
           
DECLARE @history_id_table TABLE (OldHistoryID INT,NewHistoryID INT)
INSERT INTO @history_id_table (OldHistoryID,NewHistoryID)   
SELECT old.HistoryID,new.HistoryID FROM [KYPEnrollment].[pAccount_History] old, [KYPEnrollment].[pAccount_History] new 
WHERE old.HistoryID = new.[Remarks]AND old.AccountID = @account_id AND new.AccountID = @clone_account_id;         
           
/*ALERT*/
INSERT INTO [KYPEnrollment].[HIS_Alert]
           ([AccountID]
           ,[HistoryID]
           ,[AlertNumber]
           ,[MonStatus]
           ,[MonRelevance]
           ,[AlertPartyName]
           ,[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted]
           ,[WatchlistCategory]
           ,[MonResolution])
    SELECT  @clone_account_id
           ,history.NewHistoryID
           ,[AlertNumber]
           ,[MonStatus]
           ,[MonRelevance]
           ,alert.[AlertPartyName]
           ,alert.[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,alert.[DeletedBy]
           ,[DateDelete]
           ,alert.[IsDeleted]
           ,[WatchlistCategory]
           ,[MonResolution] 
           FROM @history_id_table history ,[KYPEnrollment].[HIS_Alert] alert
           WHERE history.OldHistoryID = alert.HistoryID AND alert.AccountID = @account_id; 
           
/*Application History*/           
INSERT INTO [KYPEnrollment].[HIS_ApplicationHistory]
           ([HistoryID]
           ,[AccountStatus]
           ,[ApplicationType]
           ,[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted]
           ,[Resolution]
           ,[AplicationNumber])  
     SELECT history.NewHistoryID
           ,[AccountStatus]
           ,[ApplicationType]
           ,appHistory.[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,appHistory.[DeletedBy]
           ,[DateDelete]
           ,appHistory.[IsDeleted]
           ,[Resolution]
           ,[AplicationNumber]          
           FROM @history_id_table history, [KYPEnrollment].[HIS_ApplicationHistory] appHistory
           WHERE history.OldHistoryID = appHistory.HistoryID;
/*DOCUMENT*/
INSERT INTO [KYPEnrollment].[HIS_Document]
           ([HistoryID]
           ,[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted]
           ,[DocNumber]
           ,[DocTitle])
     SELECT history.NewHistoryID
           ,document.[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,document.[DeletedBy]
           ,[DateDelete]
           ,document.[IsDeleted]
           ,[DocNumber]
           ,[DocTitle]
           FROM @history_id_table history , [KYPEnrollment].[HIS_Document] document
           WHERE history.OldHistoryID = document.HistoryID;  

/*Made Change*/
INSERT INTO [KYPEnrollment].[HIS_MadeChange]
           ([HistoryID]
           ,[Field]
           ,[TypeChange]
           ,[NewValue]
           ,[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted]
           ,[OldValue])
     SELECT history.NewHistoryID
           ,[Field]
           ,[TypeChange]
           ,[NewValue]
           ,madeChange.[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,madeChange.[DeletedBy]
           ,[DateDelete]
           ,madeChange.[IsDeleted]
           ,[OldValue]
            FROM @history_id_table history,[KYPEnrollment].[HIS_MadeChange] madeChange
            WHERE history.OldHistoryID = madeChange.HistoryID;  
           
/*Message*/
INSERT INTO [KYPEnrollment].[HIS_Message]
           ([MessageSubject]
           ,[HistoryID]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted])                       
     SELECT [MessageSubject]
           ,history.NewHistoryID
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,hMessage.[DeletedBy]
           ,[DateDelete]
           ,hMessage.[IsDeleted]  
           FROM @history_id_table history,[KYPEnrollment].[HIS_Message] hMessage
           WHERE history.OldHistoryID = hMessage.HistoryID;   
           
/*Note*/
INSERT INTO [KYPEnrollment].[HIS_Note]
           ([HistoryID]
           ,[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,[DeletedBy]
           ,[DateDelete]
           ,[IsDeleted]
           ,[NoteNumber]
           ,[NoteTitle])   
     SELECT history.NewHistoryID
           ,hNote.[CreatedBy]
           ,[DateCreate]
           ,[ModifiedBy]
           ,[DateModify]
           ,hNote.[DeletedBy]
           ,[DateDelete]
           ,hNote.[IsDeleted]
           ,[NoteNumber]
           ,[NoteTitle]   
           FROM @history_id_table history ,[KYPEnrollment].[HIS_Note] hNote
           WHERE history.OldHistoryID = hNote.HistoryID; 
            
UPDATE newHistory SET newHistory.[Remarks] = oldHistory.[Remarks]  FROM [KYPEnrollment].[pAccount_History] newHistory,[KYPEnrollment].[pAccount_History] oldHistory 
WHERE oldHistory.HistoryID = newHistory.[Remarks]AND oldHistory.AccountID = @account_id AND newHistory.AccountID = @clone_account_id;                         
END


GO

