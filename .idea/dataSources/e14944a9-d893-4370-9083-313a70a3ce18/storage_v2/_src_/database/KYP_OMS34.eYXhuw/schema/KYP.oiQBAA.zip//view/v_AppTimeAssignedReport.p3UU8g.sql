

CREATE VIEW [KYP].[v_AppTimeAssignedReport] 
AS
	SELECT 
 ROW_NUMBER() over(order by A.DateReceived Desc) As RID,
 A.CaseID As CaseID,
 A.Number As ApplicationNumber,
 A.ApplnTypeAlias As ApplicationType,
 A.ProviderName As ProviderName,
 COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
 A.TypeDescription As ProviderType,
 --convert(varchar(10), cast(A.DateReceived as date), 101) As DateReceived,
 A.DateReceived As DateReceived,
 
 CASE WHEN A.DateReceived IS NOT NULL THEN 
 (DATEDIFF(DAY,A.DateReceived,ISNULL(A.DateResolved,GETDATE()))+1 - ISNULL(A.RTPDAYS_REMAINING,0)) ELSE '0' END As NumberOfDays,
 
 COALESCE(LTRIM(RTRIM(NULLIF(A.ReviewerFullName,''))),'NA') As ReviewerName,
 CASE WHEN A.DateResolved is not null then convert(varchar(10),A.DateResolved,101) else 'NA' END As DateClosed,
 COALESCE(LTRIM(RTRIM(NULLIF(A.MILESTONE,''))),'NA') As Milestone,
 COALESCE(LTRIM(RTRIM(NULLIF(A.CurrentlyAssignedToName,''))),'NA') As CurrentUserName
 
FROM KYP.ADM_Case A   
 WHERE A.IsPPURequired = 0  AND A.WFProcessing = 0

GO

