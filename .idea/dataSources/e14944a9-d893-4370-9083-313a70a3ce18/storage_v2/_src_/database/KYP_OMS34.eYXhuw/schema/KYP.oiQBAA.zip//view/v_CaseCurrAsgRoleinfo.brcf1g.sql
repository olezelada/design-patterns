


CREATE VIEW [KYP].[v_CaseCurrAsgRoleinfo]
AS

SELECT row_number() OVER (ORDER BY CaseID ASC) AS ID, *
FROM (
SELECT 
CaseID, 
Number, 
PAN, 
CurrentlyAssignedToID AS 'PersonID', 
CurrentlyAssignedToName AS 'UserID',
A.StatusCodeNumber,
A.WFStatus,
A.WFMinorStep,
CASE WHEN CurrentlyAssignedToName = 'userr' AND StatusCodeNumber = 12 
	 THEN 'SupervisorS'
	 ELSE D.RoleName
END AS 'Actual_Role'
FROM KYP.ADM_Case A
INNER JOIN KYP.OIS_User B ON B.PersonID = A.CurrentlyAssignedToID
LEFT JOIN KYP.OIS_JT_UserRole C ON C.UserID = B.UserID
LEFT JOIN KYP.OIS_Role D ON D.RoleID = C.RoleID 
WHERE D.RoleName IS NOT NULL AND D.RoleName <> 'Clerk'
) X


GO

