
-- =============================================
-- Author:		<Author,,Lperez>
-- realiza el registro de todos los entities y individuals ownership que tienen relacion con algun otro apartir de una busqueda en account
-- @uniquePartyID identificador unico,	@mocaPartyID party del moca (Entity o individual ownership), @lastActionUserID nombre del usuario que realizo la aprobacion,
-- @effectiveBeingDate fecha de aprobacion, @currentFlag flag para saber si el nuevo registro cera activo o desactivo
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Create_UniquePartyMoca]
	@uniquePartyID int,
	@mocaPartyID int,	
	@lastActionUserID varchar(100),
	@effectiveBeingDate smalldatetime,
	@currentFlag bit
AS
BEGIN

    DECLARE @dateCreated date	
	SET @dateCreated = GETDATE()
				
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_MOCAMapping]
	([UniquePartyID]
	,[MOCAPartyID]
	,[EffectiveBeingDate]
	,[LastAction]
	,[LastActionDate]
	,[LastActoryUserID]
	,[LastActionApprovedByUsedID]
	,[CurrentRecordFlag])
	VALUES
	(@uniquePartyID
	,@mocaPartyID
	,@effectiveBeingDate
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,@currentFlag)				
END


GO

