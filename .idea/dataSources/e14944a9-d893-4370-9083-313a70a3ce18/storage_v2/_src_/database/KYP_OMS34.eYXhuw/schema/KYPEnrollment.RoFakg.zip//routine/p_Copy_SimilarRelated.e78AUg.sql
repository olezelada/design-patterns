
-- =============================================
-- Author:		<Author,,Lperez>
-- PROCEDURE que relaciona account con otros account apartir de una busqueda 
-- valores de busqueda 
-- SIMILAR (EIN,SSN,NPI) que sean parecidos
-- RELATED ( @address Zip, Specialty)
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_SimilarRelated]
	@accountID INT,
	@partyID INT,
	@npi varchar(10),
	@ein varchar(10),
	@ssn varchar(10),
	@addressZip varchar(5),
	@lastActorUserID varchar(100)
AS
BEGIN

    DECLARE @sql nvarchar(MAX),@accountIDTmp INT,@partyIDTmp INT,@idTmp INT,@IDTmpB INT,@npiTmp varchar(15),@einTmp varchar(15),@ssnTmp varchar(15),
			@message varchar(100),@dateCreated date,@lastAction varchar(1),@specialityCode varchar(100)
		
	SET @dateCreated = GETDATE();
	SET @lastAction = 'C';
	
	SELECT @message = 'SIMILAR RELATED: BEGIN'
	RAISERROR(@message, 0, 1) WITH NOWAIT	
	
	-- SIMILAR (EIN,SSN,NPI) que sean parecidos

	DECLARE Related_Cursor CURSOR FOR		
	select srd.AccountID,ISNULL(srd.SSN,''),ISNULL(srd.EIN,''), ISNULL(srd.NPI,'')  from [KYPEnrollment].[SearchSimilarRelated] srd WHERE srd.SSN=@ssn OR srd.EIN = @ein OR srd.NPI=@npi
		
	OPEN Related_Cursor;
	FETCH NEXT FROM Related_Cursor INTO @accountIDTmp,@npiTmp,@einTmp,@ssnTmp 
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		SELECT @message = 'SIMILAR RELATED: BEGIN FFS '+CONVERT(char(10), @accountIDTmp)+' '+CONVERT(char(10), @accountID)+' '+CONVERT(char(10), @lastActorUserID)
		RAISERROR(@message, 0, 1) WITH NOWAIT
		--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccount] @accountID INT,@linkedWithAccountID INT,@linkType varchar(10),@linkingRemarks varchar(100),@lastActorUserID varchar(100)	
		EXEC @idTmp = [KYPEnrollment].[p_Copy_LinkedAccount] @accountID,@accountIDTmp,'Related','',@lastActorUserID;  
		SELECT @message = 'SIMILAR RELATED: BEGIN FFG '--+CONVERT(char(10), @IDTmp)
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		EXEC @IDTmpB = [KYPEnrollment].[p_Copy_LinkedAccount] @accountIDTmp,@accountID,'Related','',@lastActorUserID;  
		SELECT @message = 'SIMILAR RELATED: BEGIN  aaa'
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		IF(@npiTmp=@npi AND @npiTmp<>'')
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]	@linkedAccountID INT,@value varchar(100),@attribute varchar(50)	
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmp,@npiTmp,'npi';
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmpB,@npiTmp,'npi';	
		END
		SELECT @message = 'SIMILAR RELATED: BEGIN  bbb'
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		IF(@einTmp=@ein  AND @einTmp<>'')
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]	@linkedAccountID INT,@value varchar(100),@attribute varchar(50)	
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmp,@einTmp,'ein';
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmpB,@einTmp,'ein';	
		END
		SELECT @message = 'SIMILAR RELATED: BEGIN  ccc'
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		IF(@ssnTmp=@ssn AND @ssnTmp<>'')
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]	@linkedAccountID INT,@value varchar(100),@attribute varchar(50)	
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmp,@ssnTmp,'ssn';
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmpB,@ssnTmp,'ssn';	
		END	

		FETCH NEXT FROM Related_Cursor INTO @accountIDTmp,@npiTmp,@einTmp,@ssnTmp 
	END;
	CLOSE Related_Cursor;
	DEALLOCATE Related_Cursor;	
	
	-- RELATED ( @address Zip, Specialty)
	DECLARE Similar_Cursor CURSOR FOR		
	select DISTINCT acc.AccountID, acc.PartyID 
	from [KYPEnrollment].[pADM_Account] acc 
	INNER JOIN [KYPEnrollment].pAccount_PDM_Party par ON par.AccountID = acc.AccountID
	INNER JOIN [KYPEnrollment].pAccount_PDM_Location lo ON lo.PartyID=par.PartyID AND lo.Type='Servicing'
	INNER JOIN [KYPEnrollment].pAccount_PDM_Address ad ON ad.AddressID = lo.AddressID 
	INNER JOIN [KYPEnrollment].pAccount_PDM_Speciality sp ON sp.PartyID = par.PartyID AND sp.Type = 'Specialty Code'
	WHERE ad.ZipPlus4 LIKE '%'+@addressZip+'%' 
	AND sp.Speciality_Code IN(select spa.Speciality_Code from [KYPPORTAL].[PortalKYP].[pPDM_Speciality] spa WHERE spa.PartyID = @partyID and spa.Type = 'Specialty Code')
			
	OPEN Similar_Cursor;
	FETCH NEXT FROM Similar_Cursor INTO @accountIDTmp,@partyIDTmp 
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccount] @accountID INT,@linkedWithAccountID INT,@linkType varchar(10),@linkingRemarks varchar(100),@lastActorUserID varchar(100)	
		EXEC @IDTmp = [KYPEnrollment].[p_Copy_LinkedAccount] @accountID,@accountIDTmp,'Similar','',@lastActorUserID;  
		EXEC @IDTmpB = [KYPEnrollment].[p_Copy_LinkedAccount] @accountIDTmp,@accountID,'Similar','',@lastActorUserID;  
		
		DECLARE Similar_Code_Cursor CURSOR FOR		
		select spa.Speciality_Code from [KYPPORTAL].[PortalKYP].[pPDM_Speciality] spa WHERE spa.PartyID = @partyID and spa.Type = 'Specialty Code'
				
		OPEN Similar_Code_Cursor;
		FETCH NEXT FROM Similar_Code_Cursor INTO @specialityCode
		WHILE @@FETCH_STATUS = 0
		BEGIN								
			IF((select COUNT(sp.Speciality_Code) from [KYPEnrollment].pAccount_PDM_Speciality sp where sp.PartyID = @partyIDTmp AND sp.Speciality_Code = @specialityCode AND sp.Type = 'Specialty Code')>0)
			BEGIN
				--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]	@linkedAccountID INT,@value varchar(100),@attribute varchar(50)	
				EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmp,@specialityCode,'Specialty Code';
				EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmpB,@specialityCode,'Specialty Code';	
			END	

			FETCH NEXT FROM Similar_Code_Cursor INTO @specialityCode
		END;
		CLOSE Similar_Code_Cursor;
		DEALLOCATE Similar_Code_Cursor;	
		
		IF((select COUNT(ad.ZipPlus4) from [KYPEnrollment].pAccount_PDM_Location lo 
		INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.AddressID = lo.AddressID 
		where lo.PartyID=@partyIDTmp AND lo.Type='Servicing' AND ad.ZipPlus4 LIKE '%'+@addressZip+'%' )>0)
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccountValue]	@linkedAccountID INT,@value varchar(100),@attribute varchar(50)	
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmp,@addressZip,'Address ZIP';
			EXEC [KYPEnrollment].[p_Copy_LinkedAccountValue] @IDTmpB,@addressZip,'Address ZIP';	
		END	

		FETCH NEXT FROM Similar_Cursor INTO @accountIDTmp,@partyIDTmp 
	END;
	CLOSE Similar_Cursor;
	DEALLOCATE Similar_Cursor;	
	
	SELECT @message = 'SIMILAR RELATED: END'
	RAISERROR(@message, 0, 1) WITH NOWAIT	
END


GO

