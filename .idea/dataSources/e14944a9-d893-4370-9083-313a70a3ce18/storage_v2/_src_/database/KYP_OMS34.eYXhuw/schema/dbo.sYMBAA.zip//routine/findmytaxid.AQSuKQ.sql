
CREATE FUNCTION findmytaxid
(@TaxIDProfileID int)

Returns @taxidprofile table
(TaxIDProfileID int) 
   AS 
  BEGIN 
  Insert into @taxidprofile 
        SELECT taxidprofileid from KYPEnrollment.pAccount_PDM_Party 
        WHERE taxidprofileid = @TaxIDProfileID 
      RETURN
  END


GO

