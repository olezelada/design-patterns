
/* ==========================================================
-- Author:  <JVera>
-- PROCEDURE: create BusinessHour form for CA
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- Note: the field isDeleted referred to swith of options Yes/No
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Hours_CA]
   @party_account_id INT, @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day],
                                                             [TimeFrom],
                                                             [TimeTo],
                                                             [PartyID],
                                                             [IsDeleted],
                                                             [CurrentRecordFlag])
      SELECT [Day],
             [TimeFrom],
             [TimeTo],
             @party_account_id,
             [IsDeleted],
             1
        FROM [KYPPORTAL].[PortalKYP].[pPDM_BusinessHours]
       WHERE PartyID = @party_app_id
	     

   PRINT 'New BusinessHour for CA'
END


GO

