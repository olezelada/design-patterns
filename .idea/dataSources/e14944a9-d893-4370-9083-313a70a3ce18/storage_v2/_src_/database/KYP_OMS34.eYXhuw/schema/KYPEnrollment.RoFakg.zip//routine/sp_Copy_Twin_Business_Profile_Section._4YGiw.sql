-- =============================================
-- Author:		<DH-BOL>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts copy al data related to the BUSINESS PROFILE SECTION of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Twin_Business_Profile_Section]
@new_Account_Id int,
@new_Party_Id int,
@party_Id int,
@last_action_user_id varchar(50),
@application_no varchar(100)

AS
BEGIN

IF EXISTS (SELECT a.AccountID FROM KYPEnrollment.pADM_Account a where a.AccountID =@new_Account_Id AND a.PackageName='F_OOS_OE')
    BEGIN
    /*this SP is to create "Place of Business section" for Two radios*/
      EXEC [KYPEnrollment].[sp_Copy_Business_Profile_SubForm] @new_Party_Id,@party_Id,@last_action_user_id;
    END
  ELSE
    BEGIN
Insert into Debug(fieldName,FieldValue,ProcedureName,OtherComments,logtime)
select 'ServicelocationNo:',ServiceLocationNo,'sp_Copy_Twin_Business_Profile_Section',AccountID,GETDATE()
From kypenrollment.padm_Account with (nolock)
where AccountID in (@new_Account_Id)
      EXEC [KYPEnrollment].[sp_Copy_Business_Profile_Section] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no;
  END

END


GO

