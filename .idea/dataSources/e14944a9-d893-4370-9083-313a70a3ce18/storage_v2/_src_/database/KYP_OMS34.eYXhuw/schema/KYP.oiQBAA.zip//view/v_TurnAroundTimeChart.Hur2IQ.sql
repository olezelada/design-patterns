



CREATE VIEW [KYP].[v_TurnAroundTimeChart]
AS

SELECT W.week As week,ISNULL(X.TAT_Days,0) AS TAT_Days,W.WeekStartDate As WeekStartDate,X.DateCreated As DateCreated,
X.DateResolved As DateResolved,W.weekFormattedDate As weekFormattedDate,ISNULL(X.CTAT,0) As CTAT FROM(
SELECT 1 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0) AS WeekStartDate ,   CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 0), 101) AS weekFormattedDate  UNION ALL
SELECT 2 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7), 101) AS weekFormattedDate UNION ALL
SELECT 3 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14), 101) AS weekFormattedDate UNION ALL
SELECT 4 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21), 101) AS weekFormattedDate UNION ALL
SELECT 5 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28), 101) AS weekFormattedDate UNION ALL
SELECT 6 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35), 101) AS weekFormattedDate UNION ALL
SELECT 7 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42), 101) AS weekFormattedDate UNION ALL
SELECT 8 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49), 101) AS weekFormattedDate) W 
Left join 
(
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(1)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 1

UNION ALL 

SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(2)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 2
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(3)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 3
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(4)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 4
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(5)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 5
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(6)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 6
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(7)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 7
UNION ALL
SELECT     Week AS week, TAT_Days, WeekStartDate, DateCreated, DateResolved, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTurnAroundTime(8)) AS CTAT
FROM         KYP.v_TurnAroundTime
WHERE     Week = 8
)X ON X.week = W.week


GO

