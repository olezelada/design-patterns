-- =============================================
-- Author:		<Sheetal>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[createCompleteWorkflow] @AlertNo VARCHAR(MAX)
	,@JournalEvent VARCHAR(50)
	,@Username VARCHAR(25)
	,@AssignToUserID INT
	,@RelatedEntityType VARCHAR(50)
	,@NotesDescription VARCHAR(max)
	,@NotesTitle VARCHAR(120)
	,@Number VARCHAR(20)
	,@Currenttag VARCHAR(5)
	,@Type VARCHAR(100)
	,@SubType VARCHAR(100)
	,@RelatedEntityID INT
	,@CurrentWFStatus VARCHAR(100)
	,@FormattedContent VARCHAR(MAX)
AS
BEGIN
	DECLARE 
		@PersonID INT
		,@FirstName VARCHAR(25)
		,@LastName VARCHAR(25)
		,@Name VARCHAR(100)
		,@FullName VARCHAR(200)
		,@Notenumber VARCHAR(15)
		,@IsExistID INT
		,@IsMerged VARCHAR(1)
		,@NoteCount INT
		,@NoteFWAlertID INT
		,@NoteFWAlertNo VARCHAR(50)
		,@NoteMergedAlertNo INT
		,@MatchStatusIndicator VARCHAR(1)
		,@NoteFWParentAlertNo VARCHAR(50)
		,@FirstNoteID INT
		,@LastNoteID INT
	DECLARE @AlertIDTable TABLE (AllParentChildAlerts INT PRIMARY KEY)
	DECLARE @Alert TABLE (
		AlertID INT PRIMARY KEY
		,IsMerged VARCHAR(1)
		,AlertNo VARCHAR(10)
		,MatchStatusIndicator VARCHAR(1)
		,JournalEntry VARCHAR(100)
		,NoteID INT
		,NoteNumber VARCHAR(100)
		)

	SELECT @NoteFWParentAlertNo = AlertNo
	FROM KYP.MDM_Alert WITH (NOLOCK)
	WHERE AlertID = @RelatedEntityID
	OPTION (MAXDOP 1)

	--END - Changes for http://jira/browse/KYP-2121 
	SELECT @PersonID = PersonID
		,@FullName = FullName
	FROM KYP.OIS_User WITH (NOLOCK)
	WHERE UserID = @Username

	SELECT @FirstName = FirstName
		,@LastName = LastName
	FROM KYP.OIS_Person WITH (NOLOCK)
	WHERE PersonID = @PersonID

	SELECT @Name = @LastName + COALESCE((', ' + @FirstName), '')

	IF (@FormattedContent IS NULL)
	BEGIN
		SET @FormattedContent = @NotesDescription
	END

	INSERT INTO @AlertIDTable
	SELECT AlertID
	FROM KYP.MDM_Alert WITH (NOLOCK)
	WHERE AlertID = @RelatedEntityID
	
	UNION
	
	SELECT ChildAlertID
	FROM KYP.MDM_RelatedAlerts WITH (NOLOCK)
	WHERE ParentAlertID = @RelatedEntityID
		AND RelationshipType = 'Merged'
		AND ISNULL(IsDeleted, 0) = 0

	INSERT INTO @Alert (
		AlertID
		,IsMerged
		,AlertNo
		,MatchStatusIndicator
		,JournalEntry
		)
	SELECT AlertID
		,IsMerged
		,AlertNo
		,MatchStatusIndicator
		,CASE 
			WHEN IsMerged = 'N'
				AND (
					@CurrentWFStatus = 'Provide Resolution'
					OR @CurrentWFStatus = 'Reviews and confirms action'
					)
				THEN 'All possible resolutions were provided and documented for Alert by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'N'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'C'
				THEN 'Alert match was accepted by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'N'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'F'
				THEN 'Alert match was determined to be a False Positive by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'N'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'I'
				THEN 'Alert match was ignored by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'Y'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'C'
				THEN 'Alert match was accepted for merged alert' + ' ' + AlertNo + ' ' + 'by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'Y'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'F'
				THEN 'Alert match was determined to be a False Positive for merged alert' + ' ' + AlertNo + ' ' + 'by' + ' ' + @FullName + '.'
			WHEN IsMerged = 'Y'
				AND @CurrentWFStatus = 'Reviews and specifies alert status'
				AND MatchStatusIndicator = 'I'
				THEN 'Alert match was ignored for merged alert' + ' ' + AlertNo + ' ' + 'by' + ' ' + @FullName + '.'
			ELSE ''
			END AS [JournalEntry]
	FROM KYP.MDM_Alert
	WHERE AlertID IN (
			SELECT AllParentChildAlerts
			FROM @AlertIDTable
			)

	SELECT @FirstNoteID = MIN(NoteID)
	FROM [KYP].[OIS_Note]

	INSERT INTO [KYP].[OIS_Note] (
		[UserID]
		,[Name]
		,[Type]
		,[SubType]
		,ParentID
		,[DateCreated]
		,[Author]
		,[RelatedEntityType]
		,[Content]
		,[UnformattedContent]
		,[Number]
		,[VersionNo]
		,[isWorkpaper]
		,[isAcknowledged]
		,[isAdverse]
		,[Deleted]
		,[IsImportant]
		,[IsLastVersion]
		,[IsSticky]
		,[IsReferenced]
		,[HasComments]
		,[HasDocuments]
		,[NumberSchemaInfo]
		,[LastVersion]
		,[AllowComments]
		,[RelatedEntityID]
		,[Importance]
		,[Score]
		)
	SELECT @Username AS UserID
		,@NotesTitle AS [Name]
		,@Type AS [Type]
		,CASE 
			WHEN IsMerged = 'N'
				THEN @SubType
			ELSE 'WF Step Completion'
			END AS [SubType]
		,0 AS ParentID
		,GETDATE() AS [DateCreated]
		,@Name AS [Author]
		,CASE 
			WHEN IsMerged = 'N'
				THEN @RelatedEntityType
			ELSE 'MDM_Alert'
			END AS [RelatedEntityType]
		,@FormattedContent AS [Content]
		,@NotesDescription AS [UnformattedContent]
		,@Number AS [Number]
		,1 AS VersionNo
		,0 AS isWorkpaper
		,0 AS isAcknowledged
		,0 AS isAdverse
		,0 AS Deleted
		,0 AS IsImportant
		,1 AS IsLastVersion
		,0 AS IsSticky
		,0 AS IsReferenced
		,0 AS HasComments
		,0 AS HasDocuments
		,@Number AS NumberSchemaInfo
		,1 AS LastVersion
		,0 AS AllowComments
		,AlertID AS RelatedEntityID
		,'Low' AS Importance
		,0 AS Score
	FROM @Alert

	SELECT @LastNoteID = SCOPE_IDENTITY()
	
	 exec [KYP].[p_GenerateNoteNumber] @LastNoteID,
				  @Notenumber=@Notenumber output
    
	 /******* Updating note number in OIS_Note***********/ 
	update KYP.OIS_Note set Number= @Notenumber where NoteID= @LastNoteID

	UPDATE A
	SET A.NoteID = B.NoteID
		,A.NoteNumber = B.Number
	FROM @Alert A
	JOIN [KYP].[OIS_Note] B WITH (NOLOCK) ON A.AlertID = B.RelatedEntityID

	INSERT INTO [KYP].[OIS_Journal] (
		[UserID]
		,[ACTIONID]
		,[Date_x]
		,[DESCRIPTION]
		,[EntityTable]
		,[Entity]
		,[EntityID]
		,[CaseID]
		,[ShortDescription]
		)
	SELECT @Username
		,1
		,GETDATE()
		,'Notes Added-' + ' ' + @Type + ' ' + @Notenumber + ' ' + 'was added to' + ' ' + @RelatedEntityType AS JournalDescription
		,'OIS_Note'
		,'Note'
		,NoteID
		,NULL
		,'Notes Added-' + ' ' + @Type + ' ' + @Notenumber + ' ' + 'was added to' + ' ' + @RelatedEntityType AS JournalDescription
	FROM @Alert
	WHERE IsMerged = 'N'
		OR (
			IsMerged = 'Y'
			AND (
				@CurrentWFStatus = 'Provide Resolution'
				OR @CurrentWFStatus = 'Reviews and confirms action'
				)
			)

	INSERT INTO [KYP].[NoteEntity] (
		[NoteNumber]
		,[NoteEntityType]
		,[NoteEntityDep]
		,[NoteEntityTypeID]
		,[NoteEntityDepID]
		,[Level]
		,[IsLastLevel]
		)
	SELECT @Notenumber
		,NoteEntityType
		,NoteEntityDep
		,NoteEntityTypeID
		,NoteEntityDepID
		,[LEVEL]
		,IsLastLevel
	FROM @Alert A
	CROSS APPLY simple_intlist_to_tbl('MDM_Alert-' + convert(VARCHAR(10), @AlertNo))
	WHERE IsMerged = 'N'
		OR (
			IsMerged = 'Y'
			AND (
				@CurrentWFStatus = 'Provide Resolution'
				OR @CurrentWFStatus = 'Reviews and confirms action'
				)
			)

	MERGE [KYP].[NoteCounts] AS NC
	USING (
		SELECT B.RelatedEntityID
			,RelatedEntityType
			,count(DISTINCT B.NoteID) AS cnt
		FROM @alert A
		JOIN KYP.OIS_Note B ON B.RelatedEntityID = @RelatedEntityID
			AND RelatedEntityType = @RelatedEntityType
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)
		WHERE IsMerged = 'N'
			OR (
				IsMerged = 'Y'
				AND (
					@CurrentWFStatus = 'Provide Resolution'
					OR @CurrentWFStatus = 'Reviews and confirms action'
					)
				)
		GROUP BY B.RelatedEntityID
			,RelatedEntityType
		) TS
		ON (
				NC.ParentID = TS.RelatedEntityID
				AND NC.ParentTable = TS.RelatedEntityType
				)
	WHEN MATCHED
		THEN
			UPDATE
			SET [ParentID] = @RelatedEntityID
				,[ParentTable] = @RelatedEntityType
				,[Counts] = cnt
	WHEN NOT MATCHED
		THEN
			INSERT (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@RelatedEntityID
				,@RelatedEntityType
				,cnt
				);

	UPDATE A
	SET [JournalEntry] = A.[JournalEntry] + B.JournalEntry
	FROM [KYP].[MDM_AlertJournal] A
	JOIN @Alert B ON A.AlertID = B.AlertID
	WHERE A.[AlertID] = @RelatedEntityID

	IF @CurrentWFStatus <> 'Identify Impacted Providers'
		INSERT INTO [KYP].[MDM_AlertJournal] (
			[AlertID]
			,[JournalEventType]
			,[JournalEntry]
			,[JournalEntryDate]
			,[CreatedDate]
			,[CreatedBy]
			,[IsDeleted]
			)
		SELECT AlertID
			,'Business Event' AS [JournalEventType]
			,[JournalEntry]
			,GETDATE()
			,GETDATE()
			,@PersonID
			,0
		FROM @Alert
END --Stored proc
GO

