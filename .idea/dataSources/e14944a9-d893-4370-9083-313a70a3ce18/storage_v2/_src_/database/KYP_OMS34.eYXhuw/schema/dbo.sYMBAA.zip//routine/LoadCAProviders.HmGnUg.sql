

CREATE PROCEDURE [dbo].[LoadCAProviders]  
AS	
BEGIN

begin try
begin tran ProcessProvider

declare @currentDate datetime
set @currentDate= GETDATE()

update [dbo].Monitoring_ProviderIndOwner set P_OWNER_DOB_DT=null where isdate(P_OWNER_DOB_DT)=0
update [dbo].Monitoring_ProviderIndOwner set P_OWNER_DOB_DT =null where cast(P_OWNER_DOB_DT as DATE)>'2079-06-06 23:59:00'
update [dbo].Monitoring_ProviderIndOwner set P_OWNER_DOB_DT =null where cast(P_OWNER_DOB_DT as DATE)<'1900-01-01 00:00:00'

delete x from (select PartyID,Speciality_Code, ROW_NUMBER()over(partition by PartyID,Speciality_Code order by SpecialityID)as row
 from kyp.PDM_Speciality)x
 where x.row>1

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndPartyExisting1]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndPartyExisting1]
END
create table [tmp_IndPartyExisting1] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndPartyExisting1]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+ coalesce(p.FirstName,'')+coalesce(p.MiddleName,'')
+coalesce(p.LastName,'')+coalesce(cast(p.SSN as varchar(10)),'')+coalesce(cast(p.DoB as varchar(10)),'')
+coalesce(cast(p.Phone1 as varchar(15)),'')+coalesce(cast(p.Phone2 as varchar(15)),'')+coalesce(cast(p.TaxId as varchar(10)),'')+ coalesce(cast(p.NPI as varchar(12)),'')
+coalesce(pr.DEA,'')+coalesce(pr.CLIA,'')+coalesce(pr.NABP_Num,'')+coalesce(pr.Type,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join (select partyid,max(Dea)Dea,Max(Clia)Clia,Max(NABP_Num)NABP_Num,
Max(Type)[Type] from kyp.PDM_Provider group by  PartyID)pr
on p.PartyID= pr.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndPartyExisting2]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndPartyExisting2]
END
create table [tmp_IndPartyExisting2] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndPartyExisting2]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(a.AddressLine1,'')+coalesce(a.AddressLine2,'')+coalesce(a.City,'')
+coalesce(a.State,'')+coalesce(a.Zip,'')+coalesce(a.ZipPlus4,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_Location lo
on p.PartyID=lo.PartyID
inner join kyp.PDM_Address a
on lo.AddressID=a.AddressID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndPartyExisting3]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndPartyExisting3]
END
create table [tmp_IndPartyExisting3] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndPartyExisting3]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(l.LicenseCode,'')+coalesce(l.LicenseState,'')+coalesce(l.LicenseType,'')
+coalesce(l.LicenseAuthority,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_License l
on p.PartyID= l.PartyID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndPartyExisting4]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndPartyExisting4]
END
create table [tmp_IndPartyExisting4] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndPartyExisting4]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(s.Speciality_Code,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_Speciality s
on p.PartyID = s.PartyID
where pa.CurrentModule=2



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndPartyExisting5]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndPartyExisting5]
END
create table [tmp_IndPartyExisting5] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndPartyExisting5]
select p.partyid,coalesce(cast(p.partyid as varchar(10)),'')+coalesce(t.Taxonomy,'') as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.pdm_taxonomy t
on p.PartyID= t.partyid
where pa.CurrentModule=2



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgPartyExisting1]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgPartyExisting1]
END

create table tmp_OrgPartyExisting1 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgPartyExisting1
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+ coalesce(p.legalname,'')+coalesce(p.dbaname1,'')
+coalesce(cast(p.SSN as varchar(10)),'')+coalesce(cast(p.Phone1 as varchar(15)),'')+coalesce(cast(p.Phone2 as varchar(15)),'')
+coalesce(cast(p.TIN as varchar(10)),'')+ coalesce(cast(p.NPI as varchar(12)),'')
+coalesce(pr.DEA,'')+coalesce(pr.CLIA,'')+coalesce(pr.NABP_Num,'')+coalesce(pr.Type,'')) as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join (select partyid,max(Dea)Dea,Max(Clia)Clia,Max(NABP_Num)NABP_Num,
Max(Type)[Type] from kyp.PDM_Provider group by  PartyID)pr
on p.PartyID= pr.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgPartyExisting2]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgPartyExisting2]
END
create table tmp_OrgPartyExisting2 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgPartyExisting2
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+
coalesce(a.AddressLine1,'')+coalesce(a.AddressLine2,'')+coalesce(a.City,'')+
coalesce(a.State,'')+coalesce(a.Zip,'')+coalesce(a.ZipPlus4,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_Location lo
on p.PartyID=lo.PartyID
inner hash join kyp.PDM_Address a
on lo.AddressID=a.AddressID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgPartyExisting3]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgPartyExisting3]
END
create table tmp_OrgPartyExisting3 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgPartyExisting3
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(l.LicenseCode,'')
+coalesce(l.LicenseState,'')+coalesce(l.LicenseType,'')+coalesce(l.LicenseAuthority,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_License l
on p.PartyID= l.PartyID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgPartyExisting4]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgPartyExisting4]
END
create table tmp_OrgPartyExisting4 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgPartyExisting4
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(s.Speciality_Code,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_Speciality s
on p.PartyID = s.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgPartyExisting5]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgPartyExisting5]
END
create table tmp_OrgPartyExisting5 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgPartyExisting5
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(t.Taxonomy,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.pdm_taxonomy t
on p.PartyID= t.partyid
where pa.CurrentModule=2


CREATE TABLE [dbo].[tmp_ProviderNameAddress](
	[FileType] [varchar](1) NULL,
	LoadType [varchar](20) NULL,
	LoadId  [varchar](50) NULL	,
	LastLoadDate datetime null,
	[P_APPL_NUM] [varchar](20) NULL,
	[P_ID] [varchar](20) NOT NULL,
	[P_NPI_NUM] [varchar](10) NULL,
	[P_DEA_NUM] [varchar](11) NULL,
	--changed from 3 to 6
	[P_TY_CD] [varchar](6) NULL,
	--changed from 1 to 2
	[P_PRACT_TY_CD] [varchar](2) NULL,
	[P_DOB_DT] [varchar](10) NULL,
	[P_FED_TAX_ID] [varchar](9) NULL,
	[P_SSN_NUM] [varchar](9) NULL,
	--INCREASING FROM 35 TO 50 
	[P_LAST_NAM] [varchar](50) NULL,
	--INCREASING FROM 35 TO 50 
	[P_FST_NAM] [varchar](50) NULL,
	[P_MI_NAM] [varchar](1) NULL,
	[P_SFX_NAM] [varchar](10) NULL,
	--INCREASING FROM 50 TO 200
	[P_NAM] [varchar](200) NULL,
	--INCREASING FROM 35 TO 50 
	[P_DBA_LAST_NAM] [varchar](50) NULL,
	--INCREASING FROM 35 TO 50 
	[P_DBA_FST_NAM] [varchar](50) NULL,
	[P_DBA_MI_NAM] [varchar](1) NULL,
	[P_DBA_SFX_NAM] [varchar](10) NULL,
	--INCREASING FROM 50 TO 200
	[P_DBA_NAM] [varchar](200) NULL,
	[P_LINE1_AD] [varchar](50) NULL,
	[P_LINE2_AD] [varchar](50) NULL,
	--INCREASING FROM 20 TO 30
	[P_CITY_NAM] [varchar](30) NULL,
	[P_ST_CD] [varchar](2) NULL,
	[P_ZIP5_CD] [varchar](5) NULL,
	[P_ZIP4_CD] [varchar](4) NULL,
	[P_NABP_NUM] [varchar](11) NULL,
	[DH_NAME_OF_FAC_ADMIN] [varchar](50) NULL,
	[P_LINE1_AD2] [varchar](50) NULL,
	[P_LINE2_AD2] [varchar](50) NULL,
	--INCREASING FROM 20 TO 30
	[P_CITY_NAM2] [varchar](30) NULL,
	[P_ST_CD2] [varchar](2) NULL,
	[P_ZIP5_CD2] [varchar](5) NULL,
	[P_ZIP4_CD2] [varchar](4) NULL,
	[P_LINE1_AD3] [varchar](50) NULL,
	[P_LINE2_AD3] [varchar](50) NULL,
	---Increased 20--30
	[P_CITY_NAM3] [varchar](30) NULL,
	[P_ST_CD3] [varchar](2) NULL,
	[P_ZIP5_CD3] [varchar](5) NULL,
	[P_ZIP4_CD3] [varchar](4) NULL,
	[DH_ENROL_STAT_CD_1] [varchar](1) NULL,
	[DH_OWNER_NUM] [varchar](2) NULL,
	[DH_SERV_LOC_NUM] [varchar](3) NULL,
	--number coming in () like (204)269-7401, increasing from 11 to 13
	[DH_PROV_TELE_NO] [varchar](13) NULL,
	[ProviderType] [varchar](20) NULL,
    CLIA varchar(15) NULL,  
    --changed from 50 to 250
    PrimarySpeciality varchar(250) NULL,
    --INCREASING FROM 50 TO 200
    FullName varchar(200) NULL,
    DBAFullName varchar(200)NULL,
    PartyId int  NULL,
    ProvId int NULL,
    FileSource varchar(50) null,
    STAT_EFF_DT smalldatetime null,
    NMP_END_DT smalldatetime null,
    --partyid owner update
    id varchar(20) null,
    AccountID int null,			 ------------Added on 5thSep2018 to store accountID from enrollment DB for history purpose
    AccountType Varchar(5) null, ------------Added on 5thSep2018 to store AccountType from enrollment DB for history purpose
    IndNPIDeactivatedOrgCase varchar(1) null ----Added on 25thSep2018 to identify case where existing parties sitting as Individual and NPI type came as org because of deactivation of NPI
    )
    
    
insert into [dbo].[tmp_ProviderNameAddress]
([FileType],LoadType,LoadId ,LastLoadDate,[P_APPL_NUM],[P_ID],[P_NPI_NUM],[P_DEA_NUM] ,
	[P_TY_CD],[P_PRACT_TY_CD],[P_DOB_DT],[P_FED_TAX_ID],[P_SSN_NUM],[P_LAST_NAM],[P_FST_NAM] ,
	[P_MI_NAM],[P_SFX_NAM],[P_NAM],[P_DBA_LAST_NAM],[P_DBA_FST_NAM],[P_DBA_MI_NAM],[P_DBA_SFX_NAM] ,
	[P_DBA_NAM],[P_LINE1_AD],[P_LINE2_AD],[P_CITY_NAM],[P_ST_CD],[P_ZIP5_CD],[P_ZIP4_CD],[P_NABP_NUM] ,
	[DH_NAME_OF_FAC_ADMIN],[P_LINE1_AD2],[P_LINE2_AD2],[P_CITY_NAM2],[P_ST_CD2],[P_ZIP5_CD2],[P_ZIP4_CD2] ,
	[P_LINE1_AD3],[P_LINE2_AD3],[P_CITY_NAM3],[P_ST_CD3],[P_ZIP5_CD3],[P_ZIP4_CD3],[DH_ENROL_STAT_CD_1] ,
	[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DH_PROV_TELE_NO],[ProviderType],FileSource,STAT_EFF_DT,NMP_END_DT
	--partyid owner update
	,id
	,AccountID
	,AccountType
	,IndNPIDeactivatedOrgCase
	)
	
	SELECT[FileType]
		,LoadType = case 
						when [FileType] = 'M' then 'MonthlyProvider'
						when [FileType] = 'D' then 'DailyEnroller'
					  end	
		,LoadId  = case 
						when [FileType] = 'M' then 'MLOAD_' + CONVERT(varchar(10),GETDATE(), 112)
						when [FileType] = 'D' then 'DLOAD_' + CONVERT(varchar(10),GETDATE(), 112)
					  end	
		,LastLoadDate = GETDATE()
		
      ,nullif([P_APPL_NUM],'')
      ,nullif([P_ID] ,'')
      ,nullif([P_NPI_NUM],'')
      ,nullif([P_DEA_NUM],'')
      ,nullif([P_TY_CD],'')
      ,nullif([P_PRACT_TY_CD],'')
      ,nullif([P_DOB_DT],'')
      ,nullif([P_FED_TAX_ID],'')
      ,nullif([P_SSN_NUM],'')
      ,nullif([P_LAST_NAM],'')
      ,nullif([P_FST_NAM],'')
      ,nullif([P_MI_NAM],'')
      ,nullif([P_SFX_NAM],'')
      ,nullif([P_NAM],'')
      ,nullif([P_DBA_LAST_NAM],'')
      ,nullif([P_DBA_FST_NAM],'')
      ,nullif([P_DBA_MI_NAM],'')
      ,nullif([P_DBA_SFX_NAM],'')
      ,nullif([P_DBA_NAM],'')
      ,nullif([P_LINE1_AD],'')
      ,nullif([P_LINE2_AD],'')
      ,nullif([P_CITY_NAM],'')
      ,nullif([P_ST_CD],'')
      ,nullif([P_ZIP5_CD],'')
      ,nullif([P_ZIP4_CD],'')
      ,nullif([P_NABP_NUM],'')
      ,nullif([DH_NAME_OF_FAC_ADMIN],'')
      ,nullif([P_LINE1_AD2],'')
      ,nullif([P_LINE2_AD2],'')
      ,nullif([P_CITY_NAM2],'')
      ,nullif([P_ST_CD2],'')
      ,nullif([P_ZIP5_CD2],'')
      ,nullif([P_ZIP4_CD2],'')
      ,nullif([P_LINE1_AD3],'')
      ,nullif([P_LINE2_AD3],'')
      ,nullif([P_CITY_NAM3],'')
      ,nullif([P_ST_CD3],'')
      ,nullif([P_ZIP5_CD3],'')
      ,nullif([P_ZIP4_CD3],'')
      ,nullif([DH_ENROL_STAT_CD_1] ,'')
      ,nullif([DH_OWNER_NUM],'')
      ,nullif([DH_SERV_LOC_NUM],'')
      ,nullif([DH_PROV_TELE_NO],'')
      ,nullif(A.[ProviderType],'')
      ,nullif([FileSource],'')
      ,nullif(STAT_EFF_DT,'')
      ,nullif(NMP_END_DT,'')
      --partyid owner update
      ,nullif(ID,'')
      ,nullif(P_AccNo,'')
      ,nullif(b.AccountType,'')
      ,null             ---Added for IndNPIDeactivatedOrgCase on 25thSep2018
FROM [dbo].Monitoring_ProviderNameAddress A 
join kypenrollment.Padm_Account b on B.AccountID=A.P_AccNo ---Added on 5thSep2018 for storing accounttype for billing purpose
where isnull(a.P_SupUpdate_Flag,'') not in ('CO','SG') ---Added on 27Sep2018 to filter out Crossover and Sub-Group providers in monitoring load

--where [P_ID] in(select p_id from dbo.uat_providers)---Hareesha Panoor: should be removed for production, added only for UAT
--------------------------------------------------------
  
  ----added on 25Sep2018 to fix deactivated NPI party type mismatch problem i.e. earlier ind party in monitoring but now because of deactivated NPI new org party creating
 ----we are fixing this by considering exsiting ind party and discarding org new party, i.e. we are identifying such case and mark individual in provtype and copy exsiting split name in stage table
--select B.PartyID,B.LastName,B.FirstName,B.MiddleName,A.P_Nam,c.*,A.* 
update A set ProviderType='Individual',
P_LAST_NAM=B.LastName,
P_FST_NAM=B.FirstName,
P_MI_NAM=B.MiddleName,
P_SFX_NAM=B.Salunation,
p_nam=null,
IndNPIDeactivatedOrgCase='Y'
from [dbo].[tmp_ProviderNameAddress] A 
join kyp.pdm_person B on A.P_NPI_NUM=B.NPI
join Hippaspace.dbo.HIPPA_NPI_Details c on b.npi=c.npi
where ProviderType<>'Individual' and P_NPI_NUM is not null and NPI_Deactivate_Dt<>''
and NPI_Reactivation_Dt='' 

 --------------------------------------------------------
 --------------------------------------------------------
 update [tmp_ProviderNameAddress] 
 set p_ssn_num = null 
where p_ssn_num =''

update [tmp_ProviderNameAddress] 
 set p_npi_num = null 
where p_npi_num =''

update [tmp_ProviderNameAddress] 
 set p_fed_tax_id = null 
where p_fed_tax_id =''

update [tmp_ProviderNameAddress] 
 set p_dba_nam = null 
where p_dba_nam =''

update [tmp_ProviderNameAddress] 
 set p_nam = null 
where p_nam =''

update [tmp_ProviderNameAddress] 
 set p_last_nam = null 
where p_last_nam =''

update [tmp_ProviderNameAddress] 
 set p_fst_nam = null 
where p_fst_nam =''

update [tmp_ProviderNameAddress] 
 set P_MI_NAM = null 
where P_MI_NAM =''


 update [tmp_ProviderNameAddress] 
 set P_LAST_NAM = case when P_LAST_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(P_LAST_NAM,', ',' '),',',' '))))) end
,P_FST_NAM=case when P_FST_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_FST_NAM))end
,P_MI_NAM=case when P_MI_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_MI_NAM))end
,P_DBA_LAST_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_LAST_NAM,', ',' '),',',' ')))
,P_DBA_FST_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_FST_NAM,', ',' '),',',' ')))
,P_DBA_MI_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_MI_NAM,', ',' '),',',' ')))
,P_LINE1_AD= case when P_LINE1_AD is not null and P_LINE1_AD<>'' then KYP.RemoveUnwantedCharacters(P_LINE1_AD)end
,P_LINE2_AD=case when P_LINE2_AD is not null and P_LINE2_AD<>'' then KYP.RemoveUnwantedCharacters(P_LINE2_AD)end
,P_LINE1_AD2= case when P_LINE1_AD2 is not null and P_LINE1_AD2<>'' then KYP.RemoveUnwantedCharacters(P_LINE1_AD2)end
,P_LINE2_AD2=case when P_LINE2_AD2 is not null and P_LINE2_AD2<>''then KYP.RemoveUnwantedCharacters(P_LINE2_AD2)end
,P_LINE1_AD3= case when P_LINE1_AD3 is not null and  P_LINE1_AD3<>''then KYP.RemoveUnwantedCharacters(P_LINE1_AD3)end
,P_LINE2_AD3=case when P_LINE2_AD3 is not null and P_LINE2_AD3<>'' then KYP.RemoveUnwantedCharacters(P_LINE2_AD3)end
,P_NAM=case when P_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_NAM))end
,P_DBA_NAM=case when P_DBA_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_DBA_NAM))end


update [tmp_ProviderNameAddress] 
 set P_NAM = COALESCE(P_NAM, P_DBA_NAM)
where ProviderType='Organizaton'


update [tmp_ProviderNameAddress] 
 set P_LAST_NAM = COALESCE(P_LAST_NAM, P_DBA_LAST_NAM)
,P_FST_NAM = COALESCE(P_FST_NAM, P_DBA_FST_NAM)
 where ProviderType='Individual'
 
update [tmp_ProviderNameAddress] 
 set FullName = case when P_LAST_NAM IS NULL
			then COALESCE(P_LAST_NAM,'') +  COALESCE(P_FST_NAM, '') +  COALESCE((' ' + P_MI_NAM), '')
			else COALESCE(P_LAST_NAM,'') +  COALESCE((', ' + P_FST_NAM), '') +  COALESCE((' ' + P_MI_NAM), '')
			end
 where ProviderType='Individual'
 
 
update [tmp_ProviderNameAddress] 
 set DBAFullName = case when P_DBA_LAST_NAM IS NULL
			then COALESCE(P_DBA_LAST_NAM,'') +  COALESCE(P_DBA_FST_NAM, '') +  COALESCE((' ' + P_DBA_MI_NAM), '')
			else COALESCE(P_DBA_LAST_NAM,'') +  COALESCE((', ' + P_DBA_FST_NAM), '') +  COALESCE((' ' + P_DBA_MI_NAM), '')
			end
 where ProviderType='Individual'
 
 
update [tmp_ProviderNameAddress] 
 set FullName = COALESCE(FullName, DBAFullName)
where ProviderType='Individual'



--------------getting CLIA no
update y
set y.CLIA= x.P_CLIA_NUM
from [tmp_ProviderNameAddress] y
  inner join    
(select x.P_ID,x.P_CLIA_NUM from(select 
	x.P_ID,x.P_CLIA_NUM, ROW_NUMBER()over(partition by x.P_ID order by x.id) as row
	FROM dbo.Monitoring_ProviderCLIA x where x.P_CLIA_NUM<>'' and x.P_CLIA_NUM is not null)x
where x.row=1)x
on x.P_ID= y.p_id	
----------------getting primary speciality
update y
set y.PrimarySpeciality= x.LongDescription
from [tmp_ProviderNameAddress] y
  inner join    
(select x.P_ID,x.LongDescription,x.row from(
select 
	x.P_ID,y.LongDescription, ROW_NUMBER()over(partition by x.P_ID order by x.id) as row
	FROM dbo.Monitoring_ProviderSpeciality x 
	inner join [KYP].[PDM_SpecialityCode] y
	on x.P_SPECL_CD=y.Value where x.P_SPECL_CD is not null and x.P_SPECL_CD<>'')x where x.row=1)x
on x.P_ID= y.p_id


---------------update pdm party for Individual records if already exists--
----------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--Strong condition added on 1sSep2018
---L+NPI+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_LAST_NAM= y.LastName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_LAST_NAM is not null and y.LastName is not null
and x.P_LAST_NAM= y.LastName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and nullif(x.P_SSN_NUM,'') = nullif(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+NPI+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_Fst_NAM= y.FirstName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.FirstName is not null
and x.P_Fst_NAM= y.FirstName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and nullif(x.P_SSN_NUM,'') = nullif(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---L+NPI+(SSN blank also)+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_LAST_NAM= y.LastName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Last_NAM is not null and y.LastName is not null
and x.P_Last_NAM= y.LastName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and isnull(x.P_SSN_NUM,'') = isnull(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+NPI+(SSN blank also)+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_Fst_NAM= y.FirstName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.FirstName is not null
and x.P_Fst_NAM= y.FirstName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and isnull(x.P_SSN_NUM,'') = isnull(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---L+(NPI blank also)+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_LAST_NAM= y.LastName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Last_NAM is not null and y.LastName is not null
and x.P_Last_NAM= y.LastName and isnull(x.P_NPI_NUM,'')  = isnull(y.NPI,'') and nullif(x.P_SSN_NUM,'') = nullif(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+(NPI blank also)+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_Fst_NAM= y.FirstName
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.FirstName is not null
and x.P_Fst_NAM= y.FirstName and isnull(x.P_NPI_NUM,'')  = isnull(y.NPI,'') and nullif(x.P_SSN_NUM,'') = nullif(y.SSN,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---------------------------------------
--change
update x
set x.partyid = y.partyid
 from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_LAST_NAM= y.LastName
where x.ProviderType='Individual' and x.partyid is null and x.P_LAST_NAM is not null and y.LastName is not null
and x.P_LAST_NAM= y.LastName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and (
isnull(x.P_SSN_NUM,'') = isnull(y.SSN,'') or isnull(y.SSN,'')='' or isnull(x.P_SSN_NUM,'')=''
) 
and z.CurrentModule=2 --change added on 23-02-2018

update x
set x.partyid = y.partyid
 from  kyp.pdm_party z  
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
 join  [tmp_ProviderNameAddress] x
on x.P_LAST_NAM= y.LastName
where x.ProviderType='Individual' and x.partyid is null and x.P_LAST_NAM is not null and y.LastName is not null
and x.P_LAST_NAM= y.LastName and nullif(x.P_SSN_NUM,'')  = nullif(y.SSN,'') and (
isnull(x.P_NPI_NUM,'') = isnull(y.NPI,'') or isnull(y.NPI,'')='' or isnull(x.P_NPI_NUM,'')=''
) 
and z.CurrentModule=2 --change added on 23-02-2018

--change 
update x
set x.partyid = y.partyid
 from kyp.pdm_party z   
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
   join [tmp_ProviderNameAddress] x
on x.P_FST_NAM= y.FirstName
where x.ProviderType='Individual' and x.partyid is null and x.P_FST_NAM is not null and y.FirstName is not null
and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and (
isnull(x.P_SSN_NUM,'') = isnull(y.SSN,'') or isnull(y.SSN,'')='' or isnull(x.P_SSN_NUM,'')=''
) 
and z.CurrentModule=2 --change added on 2Sep2018

update x
set x.partyid = y.partyid
 from kyp.pdm_party z   
   inner join  kyp.PDM_Person y
   on z.partyid=y.partyid
   join [tmp_ProviderNameAddress] x
on x.P_FST_NAM= y.FirstName
where x.ProviderType='Individual' and x.partyid is null and x.P_FST_NAM is not null and y.FirstName is not null
and nullif(x.P_SSN_NUM,'')  = nullif(y.SSN,'') and (
isnull(x.P_NPI_NUM,'') = isnull(y.NPI,'') or isnull(y.NPI,'')='' or isnull(x.P_NPI_NUM,'')=''
) 
and z.CurrentModule=2 --change added on 2Sep2018

--------------------------
 UPDATE A		 
		set A.[Name] = x.FullName
		 ,A.[LoadType] = x.LoadType
		 ,a.IsProvider=1
		 ,A.[LoadID] = x.LoadID
		 ,A.[LastLoadDate] = x.LastLoadDate
		 ,A.DateModified = getdate()
		 ,A.STAT_EFF_DT = x.STAT_EFF_DT
		 ,A.NMP_END_DT =x.NMP_END_DT
		 ,A.FileSource=x.FileSource
 from [tmp_ProviderNameAddress] x
 inner join kyp.PDM_Person y
 on x.partyid= y.PartyID
inner join KYP.PDM_Party A
		on A.PartyID = y.PartyID 
where x.ProviderType='Individual' and x.PartyId is not null  and a.IsDeleted=0 and a.CurrentModule=2
 
--------------------------


---update pdm person --
UPDATE y
set
		y.SSN =  case when coalesce(x.P_SSN_NUM,'')<>'' then x.P_SSN_NUM else y.SSN end
		,y.Salunation = x.P_SFX_NAM
		,y.FirstName = case when coalesce(x.P_FST_NAM,'')<>'' then x.P_FST_NAM else y.FirstName end
		,y.LastName = case when coalesce(x.P_LAST_NAM,'')<>'' then x.P_LAST_NAM else y.LastName end
		,y.MiddleName = case when coalesce(x.P_MI_NAM,'')<>'' then x.P_MI_NAM else y.MiddleName end 
		,y.DoB = case when coalesce(x.P_DOB_DT,'')<>'' then x.P_DOB_DT else y.DoB end
		,y.NPI = case when coalesce(x.P_NPI_NUM,'')<>'' then x.P_NPI_NUM else y.NPI end 
		,y.DateModified = GETDATE() 
		,y.Phone1= case when coalesce(x.[DH_PROV_TELE_NO],'')<>'' then x.[DH_PROV_TELE_NO] else y.Phone1 end 
		,y.taxid=case when coalesce(x.[P_FED_TAX_ID],'')<>'' then x.[P_FED_TAX_ID] else y.taxid end
 from [tmp_ProviderNameAddress] x
 inner join kyp.PDM_Person y
 on  x.partyid= y.PartyID
inner join KYP.PDM_Party A
		on A.PartyID = y.PartyID 
where x.ProviderType='Individual' and x.PartyId is not null  and a.IsDeleted=0 and a.CurrentModule=2

------------------------------------------



IF OBJECT_ID('tempdb..#tmpIndParties1','U') IS NOT NULL
begin 
drop table #tmpIndParties1
end

---Modified on 30Aug2018 added address in temp table
select x.* into #tmpIndParties1  from(select x.Partyid, x.STAT_EFF_DT,x.NMP_END_DT,x.FileSource, x.[DH_PROV_TELE_NO],x.[P_FED_TAX_ID],x.P_SSN_NUM,x.[P_SFX_NAM],x.[P_LAST_NAM],x.[P_FST_NAM],x.[P_MI_NAM],x.[P_DOB_DT],x.[P_NPI_NUM], x.p_id
   ,x.fullname,x.LoadType,x.LoadID,x.LastLoadDate,'Person' as [Type],1 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,2 as currentmodule
,ROW_NUMBER()over(partition by x.p_id order by x.stat_eff_dt desc, x.nmp_end_dt desc)as row,
P_LINE1_AD,	P_LINE2_AD,	P_CITY_NAM,	P_ST_CD,	P_ZIP5_CD,	P_ZIP4_CD
from  tmp_ProviderNameAddress x
where x.ProviderType='Individual' and x.PartyId is null
)x
where x.row=1

--Strong condition added on 1sSep2018
--L+NPI+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by [P_LAST_NAM],[P_NPI_NUM],P_SSN_NUM,[P_DOB_DT] order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is not null and [P_LAST_NAM] is not null and P_SSN_NUM is not null)x
where x.row1>1

--F+NPI+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_FST_NAM, [P_NPI_NUM],P_SSN_NUM,[P_DOB_DT] order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is not null and P_FST_NAM is not null and P_SSN_NUM is not null)x
where x.row1>1

--L+NPI+SSN blank+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by [P_Last_NAM], [P_NPI_NUM],[P_DOB_DT],P_SSN_NUM order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is not null and [P_Last_NAM] is not null and P_SSN_NUM is null)x
where x.row1>1

--L+NPI blank+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by [P_Last_NAM], [P_NPI_NUM],[P_DOB_DT],P_SSN_NUM order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is null and [P_Last_NAM] is not null and P_SSN_NUM is not null)x
where x.row1>1

--FN+NPI+SSN blank+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_FST_NAM, [P_NPI_NUM],[P_DOB_DT],P_SSN_NUM order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is not null and P_FST_NAM is not null and P_SSN_NUM is null)x
where x.row1>1

--FN+NPI blank+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_FST_NAM, [P_NPI_NUM],[P_DOB_DT],P_SSN_NUM order by stat_eff_dt desc, 
nmp_end_dt desc) as row1
from #tmpIndParties1
where [P_NPI_NUM] is null and P_FST_NAM is not null and P_SSN_NUM is not null)x
where x.row1>1

-------insert individual party and person for new records-------------

declare @personTemp table (partyid INT , P_SSN_NUM varchar(9), P_SFX_NAM varchar(10), 
P_LAST_NAM varchar(50), P_FST_NAM varchar(50),P_MI_NAM varchar(50), P_DOB_DT datetime, P_NPI_NUM varchar(10), p_id varchar(20), [DH_PROV_TELE_NO] varchar(15), [P_FED_TAX_ID] varchar(10),
P_LINE1_AD varchar(50),P_City_Nam varchar(30) --added address attributes on 30Aug2018
)


MERGE [KYP].[PDM_Party]  trgt
USING 
(  
select * from #tmpIndParties1
)src ON (trgt.partyid=src.partyid and trgt.currentmodule=2 and trgt.isdeleted=0)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],[CurrentModule],STAT_EFF_DT,NMP_END_DT,FileSource )
 VALUES (src.[Type],src.FullName,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,src.currentmodule,src.STAT_EFF_DT,src.NMP_END_DT,src.FileSource)
output inserted.partyid, src.P_SSN_NUM,src.[P_SFX_NAM],src.[P_LAST_NAM],src.[P_FST_NAM],src.[P_MI_NAM],src.[P_DOB_DT],src.[P_NPI_NUM], src.p_id,src.[DH_PROV_TELE_NO],src.[P_FED_TAX_ID],
src.P_LINE1_AD,src.P_City_Nam
 into @personTemp;


INSERT INTO [KYP].[PDM_person]
           (PartyID,SSN,Salunation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,Phone1,taxid)
select partyid, P_SSN_NUM,P_SFX_NAM,P_FST_NAM,P_MI_NAM,P_LAST_NAM,P_DOB_DT,P_NPI_NUM,GETDATE(),
[DH_PROV_TELE_NO],[P_FED_TAX_ID] from @personTemp 
---------------------------------------------------------

----------------------------------------------------------------------------------
---------------------------------------------------------------------------------------
--Strong condition added on 1sSep2018
---L+NPI+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_LAST_NAM= y.P_LAST_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_LAST_NAM is not null and y.P_LAST_NAM is not null
and x.P_LAST_NAM= y.P_LAST_NAM and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') 
and nullif(x.P_SSN_NUM,'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---F+NPI+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_Fst_NAM= y.P_Fst_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.P_Fst_NAM is not null
and x.P_Fst_NAM= y.P_Fst_NAM and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.P_SSN_NUM,'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')


---L+NPI+(SSN blank also)+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_LAST_NAM= y.P_LAST_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Last_NAM is not null and y.P_LAST_NAM is not null
and x.P_Last_NAM= y.P_LAST_NAM and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') and isnull(x.P_SSN_NUM,'') = isnull(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---F+NPI+(SSN blank also)+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_Fst_NAM= y.P_Fst_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.P_Fst_NAM is not null
and x.P_Fst_NAM= y.P_Fst_NAM and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') and isnull(x.P_SSN_NUM,'') = isnull(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---L+(NPI blank also)+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_LAST_NAM= y.P_LAST_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Last_NAM is not null and y.P_LAST_NAM is not null
and x.P_Last_NAM= y.P_LAST_NAM and isnull(x.P_NPI_NUM,'')  = isnull(y.P_NPI_NUM,'') and nullif(x.P_SSN_NUM,'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---F+(NPI blank also)+SSN+(DOB blank also)
update x
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.P_Fst_NAM= y.P_Fst_NAM
where x.ProviderType='Individual' and x.partyid is null 
and x.P_Fst_NAM is not null and y.P_Fst_NAM is not null
and x.P_Fst_NAM= y.P_Fst_NAM and isnull(x.P_NPI_NUM,'')  = isnull(y.P_NPI_NUM,'') and nullif(x.P_SSN_NUM,'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---------------------------------------

--changed on 29Aug2018
update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on --x.p_id=y.p_id -------------- change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_LAST_NAM],'')=nullif(Y.P_LAST_NAM,'') and nullif(X.[P_NPI_NUM],'')=nullif(Y.[P_NPI_NUM],'')
where x.ProviderType='Individual' and x.PartyId is null 
and (
isnull(x.P_SSN_NUM,'') = isnull(y.P_SSN_NUM,'') or isnull(y.P_SSN_NUM,'')='' or isnull(x.P_SSN_NUM,'')=''
) 

update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on --x.p_id=y.p_id -------------- change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_LAST_NAM],'')=nullif(Y.P_LAST_NAM,'') and nullif(X.P_SSN_NUM,'')=nullif(Y.P_SSN_NUM,'')
where x.ProviderType='Individual' and x.PartyId is null 
and (
isnull(x.P_NPI_NUM,'') = isnull(y.P_NPI_NUM,'') or isnull(y.P_NPI_NUM,'')='' or isnull(x.P_NPI_NUM,'')=''
) 


update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on --x.p_id=y.p_id -------------- change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_Fst_NAM],'')=nullif(Y.[P_Fst_NAM],'') and nullif(X.[P_NPI_NUM],'')=nullif(Y.[P_NPI_NUM],'')
where x.ProviderType='Individual' and x.PartyId is null and (
isnull(x.P_SSN_NUM,'') = isnull(y.P_SSN_NUM,'') or isnull(y.P_SSN_NUM,'')='' or isnull(x.P_SSN_NUM,'')=''
) 

update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on --x.p_id=y.p_id -------------- change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_Fst_NAM],'')=nullif(Y.[P_Fst_NAM],'') and nullif(X.[P_SSN_NUM],'')=nullif(Y.[P_SSN_NUM],'')
where x.ProviderType='Individual' and x.PartyId is null and (
isnull(x.P_NPI_NUM,'') = isnull(y.P_NPI_NUM,'') or isnull(y.P_NPI_NUM,'')='' or isnull(x.P_NPI_NUM,'')=''
) 


---Added on 30Aug2018
update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on nullif(x.[P_Fst_NAM],'')=nullif(y.[P_Fst_NAM],'') and nullif(x.P_LAST_NAM,'')=nullif(Y.P_LAST_NAM,'') ---Based on name and address
and nullif(x.P_LINE1_AD,'')=nullif(Y.P_LINE1_AD,'') and nullif(x.P_CITY_NAM,'')=nullif(Y.P_CITY_NAM,'')
where x.ProviderType='Individual' and x.PartyId is null 


update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @personTemp y
on x.p_id=y.p_id -------------- missing entry based on name/NPI/SSN should be insert based on ID
where x.ProviderType='Individual' and x.PartyId is null 



------------------------------------------------pdm_party for organization update------------

---------------------------------------------------------------------------------------
--Strong condition added on 1sSep2018
---LegalName+NPI+TIn
update x
set x.partyid = y.partyid
 from kyp.pdm_party z
   inner join  kyp.PDM_Organization y
   on y.partyid=z.partyid 
   join  [tmp_ProviderNameAddress] x
 on x.P_NAM= y.LegalName
 where x.P_NAM= y.LegalName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and nullif(x.P_FED_TAX_ID,'') = nullif(y.TIN,'') 
 and  x.ProviderType='Organization' and x.partyid is null and z.CurrentModule=2--change added on 1Sep2018


---LegalName10+NPI+TIn
update x
set x.partyid = y.partyid
 from kyp.pdm_party z
   inner join  kyp.PDM_Organization y
   on y.partyid=z.partyid 
   join  [tmp_ProviderNameAddress] x
 on left(x.P_NAM,10)= left(y.LegalName,10)
 where left(x.P_NAM,10)= left(y.LegalName,10) and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and nullif(x.P_FED_TAX_ID,'') = nullif(y.TIN,'') 
 and  x.ProviderType='Organization' and x.partyid is null and z.CurrentModule=2--change added on 7Sep2018
 
 ---LegalName10+NPI
update x
set x.partyid = y.partyid
 from kyp.pdm_party z
   inner join  kyp.PDM_Organization y
   on y.partyid=z.partyid 
   join  [tmp_ProviderNameAddress] x
 on left(x.P_NAM,10)= left(y.LegalName,10)
 where left(x.P_NAM,10)= left(y.LegalName,10) and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') 
 and (nullif(x.P_FED_TAX_ID,'') is null or nullif(y.TIN,'') is null)
 and  x.ProviderType='Organization' and x.partyid is null and z.CurrentModule=2--change added on 7Sep2018

---------------------------------------

--change
update x
set x.partyid = y.partyid
 from kyp.pdm_party z
   inner join  kyp.PDM_Organization y
   on y.partyid=z.partyid 
   join  [tmp_ProviderNameAddress] x
 on x.P_NAM= y.LegalName
 where x.P_NAM= y.LegalName and nullif(x.P_NPI_NUM,'')  = nullif(y.NPI,'') and  (
 isnull(x.P_FED_TAX_ID,'') = isnull(y.TIN,'') or isnull(x.P_FED_TAX_ID,'')='' or isnull(y.TIN,'')=''
 )
 and  x.ProviderType='Organization' and x.partyid is null and z.CurrentModule=2
 
 update x
set x.partyid = y.partyid
 from kyp.pdm_party z
   inner join  kyp.PDM_Organization y
   on y.partyid=z.partyid 
   join  [tmp_ProviderNameAddress] x
 on x.P_NAM= y.LegalName
 where x.P_NAM= y.LegalName and nullif(x.P_FED_TAX_ID,'')  = nullif(y.TIN,'') and  (
 isnull(x.P_NPI_NUM,'') = isnull(y.NPI,'') or isnull(x.P_NPI_NUM,'')='' or isnull(y.NPI,'')=''
 )
 and  x.ProviderType='Organization' and x.partyid is null and z.CurrentModule=2


update	z
 set z.Name = x.P_NAM
	 ,z.LoadType = x.LoadType
	 ,z.IsProvider=1
	 ,z.LoadID = x.LoadID
	 ,z.LastLoadDate = x.LastLoadDate
	 ,z.DateModified = getdate()
	  ,z.STAT_EFF_DT = x.STAT_EFF_DT
		 ,z.NMP_END_DT =x.NMP_END_DT
		 ,z.FileSource=x.FileSource
from [tmp_ProviderNameAddress] x
   inner join  kyp.PDM_Organization y
on y.PartyID=x.partyid	
inner join kyp.PDM_Party z
		on y.PartyID=z.PartyID
where x.ProviderType='Organization' and x.partyid is not null and z.IsDeleted=0 and z.CurrentModule=2


-------------pdm_organization update-------------
update	y
 set y.TIN = case when coalesce(x.P_FED_TAX_ID,'')<>'' then x.P_FED_TAX_ID else y.TIN end 
		,y.LegalName =case when coalesce(x.P_NAM,'')<>'' then x.P_NAM else y.LegalName end  
		,y.DBAName1 = case when coalesce(x.P_DBA_NAM,'')<>'' then x.P_DBA_NAM else y.DBAName1 end 
		,y.NPI =case when coalesce(x.p_npi_num,'')<>'' then x.p_npi_num else y.NPI end  
		,y.DateModified = GETDATE()
		,y.Phone1= case when coalesce(x.[DH_PROV_TELE_NO],'')<>'' then x.[DH_PROV_TELE_NO] else y.Phone1 end   
		,y.SSN= case when coalesce(x.P_SSN_NUM,'')<>'' then x.P_SSN_NUM else y.SSN end  
from [tmp_ProviderNameAddress] x
   inner join  kyp.PDM_Organization y
on y.PartyID=x.partyid		
inner join kyp.PDM_Party z
		on y.PartyID=z.PartyID
where x.ProviderType='Organization' and x.partyid is not null and z.IsDeleted=0 and z.CurrentModule=2
 
 

 ----------------------------------------------------
IF OBJECT_ID('tempdb..#OrgParties','U') IS NOT NULL
begin 
drop table #OrgParties
end

select x.STAT_EFF_DT,x.NMP_END_DT,x.FileSource,x.[DH_PROV_TELE_NO],x.[P_NAM],x.[P_DBA_NAM],x.[P_FED_TAX_ID],x.[P_NPI_NUM],
x.LoadType,x.LoadID,x.LastLoadDate,x.p_id,'Organization' as [Type],1 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,
0 as isdeleted, GETDATE()as datecreated,2 as currentmodule,x.partyid,x.P_SSN_NUM,
P_LINE1_AD,	P_LINE2_AD,	P_CITY_NAM,	P_ST_CD,	P_ZIP5_CD,	P_ZIP4_CD
into #OrgParties
from [tmp_ProviderNameAddress] x
where x.ProviderType='Organization' and x.partyid is null



--N+NPI+TIN
delete x from (select *, ROW_NUMBER()over(partition by [P_NAM], [P_NPI_NUM],[P_FED_TAX_ID] order by p_id) as row1
from #OrgParties
where [P_NPI_NUM] is not null and [P_NAM] is not null and [P_FED_TAX_ID] is not null)x
where x.row1>1

--N+NPI+Blank TIN
delete x from (select *, ROW_NUMBER()over(partition by [P_NAM], [P_NPI_NUM],[P_FED_TAX_ID] order by p_id) as row1
from #OrgParties
where [P_NPI_NUM] is not null and [P_NAM] is not null and nullif([P_FED_TAX_ID],'') is null)x
where x.row1>1

--N+Blank NPI+TIN
delete x from (select *, ROW_NUMBER()over(partition by [P_NAM], [P_NPI_NUM],[P_FED_TAX_ID] order by p_id) as row1
from #OrgParties
where [P_NPI_NUM] is null and [P_NAM] is not null and [P_FED_TAX_ID] is not null)x
where x.row1>1



/* --Commented on 2Sep2018

--delete x from (select *, ROW_NUMBER()over(partition by [P_NAM], [P_NPI_NUM] order by p_id) as row1
--from #OrgParties
--where [P_NPI_NUM] is not null)x
--where x.row1>1

--delete x from (select *, ROW_NUMBER()over(partition by [P_NAM], [P_FED_TAX_ID] order by p_id) as row1
--from #OrgParties
--where [P_FED_TAX_ID] is not null)x
--where x.row1>1

----delete x from (select *, ROW_NUMBER()over(partition by [P_DBA_NAM], [P_NPI_NUM] order by p_id) as row1
----from #OrgParties
----where [P_NPI_NUM]<>'' and [P_DBA_NAM]<>'')x
----where x.row1>1

----delete x from (select *, ROW_NUMBER()over(partition by [P_DBA_NAM], [P_FED_TAX_ID] order by p_id) as row1
----from #OrgParties
----where [P_FED_TAX_ID]<>''  and [P_DBA_NAM]<>'')x
----where x.row1>1

-----Added on 30Aug2018 for address and name where NPI and SSN not available
--delete x from (select *, ROW_NUMBER()over(partition by [P_NAM],P_LINE1_AD,P_City_Nam order by p_id) as row1
--from #OrgParties
--where [P_SSN_NUM] is null and [P_NPI_NUM] is null )x
--where x.row1>1

*/

 ---insert org party 
 declare @OrgTemp table (partyid INT , P_FED_TAX_ID varchar(10), P_NAM varchar(200), 
P_DBA_NAM varchar(200),P_NPI_NUM varchar(10), p_id varchar(20),[DH_PROV_TELE_NO] varchar(15),P_SSN_Num varchar(10),
P_LINE1_AD varchar(50),P_City_Nam varchar(30) --added address attributes on 30Aug2018
 )

MERGE [KYP].[PDM_Party]  trgt
USING 
(select distinct partyid, [Type],p_nam,IsProvider,IsEnrolled,IsTemp,IsActive,LoadType,LoadID,
LastLoadDate,isdeleted, datecreated,currentmodule,STAT_EFF_DT,NMP_END_DT,FileSource,P_FED_TAX_ID,P_DBA_NAM,[P_NPI_NUM],p_id,[DH_PROV_TELE_NO],P_SSN_NUM,P_LINE1_AD,P_City_Nam
from #OrgParties )src 
ON (trgt.partyid=src.partyid and trgt.currentmodule=2 and trgt.isdeleted=0)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],[CurrentModule],STAT_EFF_DT,NMP_END_DT,FileSource )
 VALUES (src.[Type],src.p_nam,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,src.currentmodule,src.STAT_EFF_DT,src.NMP_END_DT,src.FileSource)
output inserted.partyid, src.P_FED_TAX_ID,src.[P_NAM],src.P_DBA_NAM,src.[P_NPI_NUM],src.p_id,src.[DH_PROV_TELE_NO],src.P_SSN_NUM,
src.P_LINE1_AD,src.P_City_Nam
 into @OrgTemp;
 
INSERT INTO [KYP].[PDM_organization]
   (PartyID,LegalName,DBAName1,TIN,NPI,DateCreated,Phone1, ssn)
select partyid, P_NAM,P_DBA_NAM,P_FED_TAX_ID,P_NPI_NUM,GETDATE(),[DH_PROV_TELE_NO], P_SSN_NUM from @OrgTemp

--------------------------------------------------------------
---Strong Condition
---LegalName+NPI+TIn
update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on x.P_NAM= y.P_NAM
 where x.P_NAM= y.P_NAM and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.P_FED_TAX_ID,'') = nullif(y.P_FED_TAX_ID,'') 
 and  x.ProviderType='Organization' and x.partyid is null
 
  ---LegalName10+NPI+TIn
 --change added on 7Sep2018
 update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on left(x.P_NAM,10)= left(y.P_NAM,10)
 where left(x.P_NAM,10)= left(y.P_NAM,10) and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.P_FED_TAX_ID,'') = nullif(y.P_FED_TAX_ID,'') 
 and  x.ProviderType='Organization' and x.partyid is null
 
 ----change added on 7Sep2018
 ------LegalName10+NPI
update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on left(x.P_NAM,10)= left(y.P_NAM,10)
 where left(x.P_NAM,10)= left(y.P_NAM,10) and nullif(x.P_NPI_NUM,'')  = nullif(y.P_NPI_NUM,'') 
 and (nullif(x.P_FED_TAX_ID,'') is null or nullif(y.P_FED_TAX_ID,'') is null)
 and  x.ProviderType='Organization' and x.partyid is null
 ----------------------------------------------
 
---Changed on 29Aug2018
 update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on --x.p_id=y.p_id		-----------------change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_NAM],'')=nullif(Y.[P_NAM],'') and nullif(x.[P_NPI_NUM],'')=nullif(Y.[P_NPI_NUM],'')	
where x.ProviderType='Organization' and x.partyid is null and  (
 isnull(x.[P_FED_TAX_ID],'') = isnull(y.[P_FED_TAX_ID],'') or isnull(x.P_FED_TAX_ID,'')='' or isnull(y.[P_FED_TAX_ID],'')=''
 )

 update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on --x.p_id=y.p_id		-----------------change for provider missing entry it should be based on name and attribute and not based on ID
nullif(x.[P_NAM],'')=nullif(Y.[P_NAM],'') and nullif(x.[P_FED_TAX_ID],'')=nullif(Y.P_FED_TAX_ID,'')
where x.ProviderType='Organization' and x.partyid is null and  (
 isnull(x.[P_NPI_NUM],'') = isnull(y.[P_NPI_NUM],'') or isnull(x.[P_NPI_NUM],'')='' or isnull(y.[P_NPI_NUM],'')=''
 )
  
---Added on 30Aug2018

update x 
set x.partyid = y.partyid
from [tmp_ProviderNameAddress] x
inner join @OrgTemp y
on nullif(x.[P_NAM],'')=nullif(y.[P_NAM],'')  ---Based on name and address
and nullif(x.P_LINE1_AD,'')=nullif(Y.P_LINE1_AD,'') and nullif(x.P_CITY_NAM,'')=nullif(Y.P_CITY_NAM,'')
where x.ProviderType='Organization' and x.PartyId is null 

 update x
set x.partyid = y.partyid
 from [tmp_ProviderNameAddress] x
   inner join  @OrgTemp y
 on x.p_id=y.p_id-----------------missing entry based on name/TaxID/SSN should be insert based on ID
where x.ProviderType='Organization' and x.partyid is null
-----------------------------------------------------------

update x
set x.ProvId = y.ProvID
 from [tmp_ProviderNameAddress] x
 inner join kyp.PDM_Provider y
 on x.p_id= y.ProvNumber
 where  x.PartyId = y.PartyID and  x.ProvId is null


update x 
set  
		x.Category =case when y.ProviderType = 'Individual' then 'Physician' 
					when y.ProviderType = 'Organization' then 'Institutional' 
					end
		,x.Type = y.P_TY_CD
		,x.NPI = case when coalesce(y.P_NPI_Num,'')<>'' then y.P_NPI_Num else x.NPI end 
		,x.IsEnrolled = 1
		,x.ProvNumber = y.P_ID
		,x.Mon_MedicaidID = y.P_ID
		,x.DateModified = GETDATE()
		,x.DEA = y.P_DEA_NUM
		,x.NABP_Num = y.P_NABP_NUM
		,x.PrimarySpecialty = y.PrimarySpeciality
		,x.EnrolStatusCode =Y.DH_ENROL_STAT_CD_1
		,x.Clia=PC.P_CLIA_NUM       ---------Added on 3rdSep2018 to have top 1 CLIA entry 
		from [KYP].[PDM_Provider] x
inner join
[tmp_ProviderNameAddress] y
on x.ProvID = y.ProvID
left join 
(select P_ID,Max(P_CLIA_NUM) P_CLIA_NUM from dbo.Monitoring_ProviderClia ---Added on 3rdSep2018 to have top 1 CLIA entry in provider table as well
where P_CLIA_NUM is not null group by P_ID)
PC on Y.P_ID=PC.P_ID
where x.PartyId = y.PartyID and y.ProvID is not null
---------------------------------


MERGE [KYP].[PDM_Provider]  trgt
USING 
( 	select y.partyid,
		y.P_TY_CD,
		y.P_NPI_Num,
		 y.p_id,
		y.P_DEA_NUM,
		PC.P_CLIA_NUM, ---Added on 3rdSep2018 to have top 1 CLIA entry
		 y.P_NABP_NUM,
		y.PrimarySpeciality,
		category =case when y.ProviderType = 'Individual' then 'Physician' 
					when y.ProviderType = 'Organization' then 'Institutional' 
					end,
		'' as ProvNumber
		,Y.DH_ENROL_STAT_CD_1
		,Y.AccountID    -------Added on 8thNov2018
from [tmp_ProviderNameAddress] y left join 
(select P_ID,Max(P_CLIA_NUM) P_CLIA_NUM from dbo.Monitoring_ProviderClia ---Added on 3rdSep2018 to have top 1 CLIA entry in provider table as well
where P_CLIA_NUM is not null group by P_ID)PC on Y.P_ID=PC.P_ID
	where y.provid is null and y.partyid is not null)src
ON (trgt.provNumber=src.ProvNumber and trgt.PartyId = src.PartyID)
WHEN NOT MATCHED THEN 
	INSERT ( PartyID ,
		Category
		,Type 
		,NPI 
		,IsEnrolled
		,ProvNumber
		,Mon_MedicaidID
		,dateCreated
		,DateModified
		,DEA 
		,CLIA
		,NABP_Num 
		,PrimarySpecialty 
		,IsDeleted 
		,EnrolStatusCode
		,AccountID   -------Added on 8thNov2018
		)
 VALUES (src.partyid,
		 src.category,
		src.P_TY_CD,
		src.P_NPI_Num
		,1
		, src.p_id
		, src.p_id
		,getdate()
		,getdate()
		,src.P_DEA_NUM
		,src.P_CLIA_NUM
		, src.P_NABP_NUM
		,src.PrimarySpeciality
		,0
		,src.DH_ENROL_STAT_CD_1
		,src.AccountID	-------Added on 8thNov2018
		);
 
update x
set x.ProvId = y.ProvID
 from [tmp_ProviderNameAddress] x
 inner join kyp.PDM_Provider y
 on x.p_id= y.ProvNumber
 where x.ProvId is null and x.PartyId = y.PartyID
 
 
update x
 set x.NPI=y.P_NPI_NUM,x.PrimarySpeciality=y.PrimarySpeciality
from KYP.DSH_DashBoardTable x
inner join [tmp_ProviderNameAddress] y
 on x.PartyID=y.PartyID 


--------------------------------------------------

update y
set		 
	 y.LicenseState = x.P_ST_CD			 
	 ,y.LicenseCode = REPLACE(x.P_LIC_CERT_NUM,'.','')
	 ,y.LicenseAuthority = x.P_LIC_BRD_NUM
	 ,y.DateModified = GETDATE()
	 ,y.ExpiryDate=CONVERT(DATETIME,x.[P_LIC_EXP_DT],121)
	 ,y.EffectiveDate= CONVERT(DATETIME,x.P_LIC_EFF_DT,121) 
from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderLicense d
	on c.p_id = d.p_id)x
	inner join 
	(select  A.PartyID,B.LicenseState,B.LicenseCode,B.ExpiryDate,B.EffectiveDate, b.LicenseAuthority,B.DateModified
	from KYP.PDM_Party A
	inner join KYP.PDM_License B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0 
		and B.IsDeleted = 0) y
		on x.partyid= y.partyid
		and COALESCE(y.LicenseState,'') = COALESCE(x.[P_ST_CD],'')
		and COALESCE(y.LicenseCode,'') = REPLACE(COALESCE(x.P_LIC_CERT_NUM,''),'.','')
		and COALESCE(y.ExpiryDate,'') = COALESCE(CONVERT(DATETIME,x.P_LIC_EXP_DT,121),'')

Insert into kyp.PDM_License 
(PartyID,LicenseState,LicenseCode,LicenseAuthority,DateModified,ExpiryDate,IsDeleted,EffectiveDate )
select x.PartyId, x.P_ST_CD,REPLACE(x.P_LIC_CERT_NUM,'.',''),x.P_LIC_BRD_NUM,GETDATE(),CONVERT(DATETIME,x.P_LIC_EXP_DT,121),0,CONVERT(DATETIME,x.P_LIC_EFF_DT,121)
from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderLicense d
	on c.p_id = d.p_id )x
	left join 
	(select  A.PartyID,B.LicenseState,B.LicenseCode,B.ExpiryDate
	from KYP.PDM_Party A
	inner join KYP.PDM_License B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0 
		and B.IsDeleted = 0) y
on x.PartyId=y.PartyID
		and COALESCE(y.LicenseState,'') = COALESCE(x.[P_ST_CD],'')
		and COALESCE(y.LicenseCode,'') = REPLACE(COALESCE(x.P_LIC_CERT_NUM,''),'.','')
		and COALESCE(y.ExpiryDate,'') = COALESCE(CONVERT(DATETIME,x.P_LIC_EXP_DT,121),'')
where y.PartyId is null and x.PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0)



update y
set		 
	 y.Speciality_Code = x.P_SPECL_CD			 
	 ,y.DateModified = GETDATE()
from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderSpeciality d
	on c.p_id = d.p_id where c.PartyId is not null)x
	inner join 
	(select  A.PartyID,B.Speciality_Code,B.DateModified
	from KYP.PDM_Party A
	inner join KYP.PDM_Speciality B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0) y
		on x.partyid= y.partyid
		and COALESCE(y.Speciality_Code,'') = COALESCE(x.P_SPECL_CD,'')


insert into kyp.PDM_Speciality
(PartyID,Speciality_Code,DateCreated)		 
select x.PartyId,x.P_SPECL_CD,GETDATE() from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderSpeciality d
	on c.p_id = d.p_id)x
	left join 
	(select  A.PartyID,B.Speciality_Code,B.DateModified
	from KYP.PDM_Party A
	inner join KYP.PDM_Speciality B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0) y
		on x.partyid= y.partyid
		and COALESCE(y.Speciality_Code,'') = COALESCE(x.P_SPECL_CD,'')
	where y.partyid is null 
	--and x.PartyID not in(select PartyID from kyp.PDM_Speciality) --Commented on 3Sep2018 restricting entry of new speciality codes of existing party
	and x.PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0)


update y
set		 
	 y.CLIA_NBR = x.P_CLIA_NUM			 
	 ,y.DateModified = GETDATE()
from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderCLIA d
	on c.p_id = d.p_id)x
	inner join 
	(select  A.PartyID,B.CLIA_NBR,B.DateModified
	from KYP.PDM_Party A
	inner join KYP.PDM_CLIA B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0) y
		on x.partyid= y.partyid
		and COALESCE(y.CLIA_NBR,'') = COALESCE(x.P_CLIA_NUM,'')
		
insert into kyp.PDM_CLIA
(
PartyID, CLIA_NBR ,DateCreated
)			 
select x.PartyId ,x.P_CLIA_NUM,GETDATE() from (select c.PartyId,d.*
	from  [tmp_ProviderNameAddress] c
		inner join [dbo].Monitoring_ProviderCLIA d
	on c.p_id = d.p_id
	)x
	left join 
	(select  A.PartyID,B.CLIA_NBR,B.DateModified
	from KYP.PDM_Party A
	inner join KYP.PDM_CLIA B
		on A.PartyID = B.PartyID 	
	where A.CurrentModule = 2
		and A.IsDeleted = 0) y
		on x.partyid= y.partyid
		and COALESCE(y.CLIA_NBR,'') = COALESCE(x.P_CLIA_NUM,'')
where y.PartyID is null 
--and x.PartyID not in(select PartyID from kyp.PDM_CLIA) --Commented on 3Sep2018 restricting entry of new CLIA codes of existing party
and x.PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0) 


----Added on 3rdSep2018		
-----Update modified date of address   
Update C set DateModified=getdate(),
Inactive=1,
ISdeleted=0,
C.AddressLine2=(Case when nullif(ISNULL(x.P_LINE2_AD,''),'') is not null then x.P_LINE2_AD else C.AddressLine2 end)  --added on 6Sep2018 to consider AddressLine2 as well for update
from [tmp_ProviderNameAddress] x
join KYP.PDM_Location A 
	on X.PartyID = A.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0
	and (LTRIM(RTRIM(ISNULL(c.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(c.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD,''))))



declare @Address table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD,
		 x.P_LINE2_AD,
		x.P_CITY_NAM,
		x.P_ST_CD
		, x.P_ZIP5_CD
		, x.P_ZIP4_CD,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select D.PartyID,C.* --,A.LegalName,A.DBAName1
	from --KYP.PDM_Organization A inner join 
	KYP.PDM_Location A 
	--on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD,''))))
	--AND																----Commented on 3rdSep2018, we already found Party just need to be check address for party
	--((LTRIM(RTRIM(ISNULL(y.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_DBA_NAM,'')))) OR 
	--(LTRIM(RTRIM(ISNULL(y.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_NAM,'')))))
	where --x.ProviderType='Organization' and       ---Commented on 3rdSep2018 in order to accomodate both person and Org parties in single query
	y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId )
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
         ,[IsDeleted])
 VALUES (src.P_LINE1_AD,
		 src.P_LINE2_AD,
		src.P_CITY_NAM,
		src.P_ST_CD
		, src.P_ZIP5_CD
		, src.P_ZIP4_CD
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address;
 
  -----Monitoring we don't require this dashboard trigger 
EXEC('DISABLE TRIGGER all ON kyp.pdm_location');
 
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted])
 select A.AddressId,A.PartyId,A.providerId, GETDATE(),1,0 from @Address A left join kyp.PDM_Location b
 on A.AddressID=B.AddressID
 left join kyp.PDM_Party C on A.PartyID=C.PartyID and c.currentmodule=2 and isnull(c.isdeleted,'0')=0
 where b.addressID is null and c.partyid is not null
-- where addressId not in (select addressId from kyp.PDM_Location)
-- --and partyid not in (select partyid from kyp.PDM_Location)   ----Commented on 3rdSep2018 it will restrict existing party new address 
--and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
--		and IsDeleted = 0 
--		and IsDeleted = 0)

  -----Monitoring we don't require this dashboard trigger 
EXEC('Enable TRIGGER all ON kyp.pdm_location');

		
update x
set x.AddressLine1=y.AddressLine1,
x.State=y.State,
x.City=y.City,
x.Zip=y.Zip,
x.Country=y.Country,
x.AddressID=y.AddressID 
from KYP.DSH_DashBoardTable x
inner join kyp.PDM_Location z
on x.PartyID= z.PartyID
inner join kyp.PDM_Address y
on z.AddressID = y.AddressID



----Added on 3rdSep2018		
-----Update modified date of address   
Update C set DateModified=getdate(),
Inactive=1,
ISdeleted=0,
C.AddressLine2=(Case when nullif(ISNULL(x.P_LINE2_AD,''),'') is not null then x.P_LINE2_AD else C.AddressLine2 end)  --added on 6Sep2018 to consider AddressLine2 as well for update
from [tmp_ProviderNameAddress] x
join KYP.PDM_Location A 
	on X.PartyID = A.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0
	and (LTRIM(RTRIM(ISNULL(c.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD2,''))))AND 
	(LTRIM(RTRIM(ISNULL(c.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD2,''))))
	


declare @Address1 table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD2,
		 x.P_LINE2_AD2,
		x.P_CITY_NAM2,
		x.P_ST_CD2
		, x.P_ZIP5_CD2
		, x.P_ZIP4_CD2,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select D.PartyID,C.* --,A.LegalName,A.DBAName1
	from --KYP.PDM_Organization A inner join 
	KYP.PDM_Location A 
	--on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD2,''))))AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD2,''))))
	--AND																----Commented on 3rdSep2018, we already found Party just need to be check address for party
	--((LTRIM(RTRIM(ISNULL(y.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_DBA_NAM,'')))) OR 
	--(LTRIM(RTRIM(ISNULL(y.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_NAM,'')))))
	where --x.ProviderType='Organization' and       ---Commented on 3rdSep2018 in order to accomodate both person and Org parties in single query
	y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD2,
		 src.P_LINE2_AD2,
		src.P_CITY_NAM2,
		src.P_ST_CD2
		, src.P_ZIP5_CD2
		, src.P_ZIP4_CD2
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address1;
 
 -----Monitoring we don't require this dashboard trigger 
EXEC('DISABLE TRIGGER all ON kyp.pdm_location');
 
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive]
           ,[IsDeleted])
 select A.AddressId,A.PartyId,A.providerId, GETDATE(),1,0 from @Address1 A left join kyp.PDM_Location b
 on A.AddressID=B.AddressID
 left join kyp.PDM_Party C on A.PartyID=C.PartyID and c.currentmodule=2 and isnull(c.isdeleted,'0')=0
 where b.addressID is null and c.partyid is not null
--  where addressId not in (select addressId from kyp.PDM_Location)
-- --and partyid not in (select partyid from kyp.PDM_Location)    ---Commented on 3rdSep2018  
--and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
--		and IsDeleted = 0 
--		and IsDeleted = 0)

-----Monitoring we don't require this dashboard trigger 
EXEC('Enable TRIGGER all ON kyp.pdm_location');


----Added on 3rdSep2018		
-----Update modified date of address   
Update C set DateModified=getdate(),
Inactive=1,
ISdeleted=0,
C.AddressLine2=(Case when nullif(ISNULL(x.P_LINE2_AD,''),'') is not null then x.P_LINE2_AD else C.AddressLine2 end)  --added on 6Sep2018 to consider AddressLine2 as well for update
from [tmp_ProviderNameAddress] x
join KYP.PDM_Location A 
	on X.PartyID = A.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0
	and (LTRIM(RTRIM(ISNULL(c.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD3,''))))AND 
	(LTRIM(RTRIM(ISNULL(c.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD3,''))))
	
		
declare @Address2 table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD3,
		 x.P_LINE2_AD3,
		x.P_CITY_NAM3,
		x.P_ST_CD3
		, x.P_ZIP5_CD3
		, x.P_ZIP4_CD3,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select D.PartyID,C.* --,A.LegalName,A.DBAName1
	from --KYP.PDM_Organization A inner join 
	KYP.PDM_Location A 
	--on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD3,''))))AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD3,''))))
	--AND																----Commented on 3rdSep2018, we already found Party just need to be check address for party
	--((LTRIM(RTRIM(ISNULL(y.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_DBA_NAM,'')))) OR 
	--(LTRIM(RTRIM(ISNULL(y.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_NAM,'')))))
	where --x.ProviderType='Organization' and       ---Commented on 3rdSep2018 in order to accomodate both person and Org parties in single query
	y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD3,
		 src.P_LINE2_AD3,
		src.P_CITY_NAM3,
		src.P_ST_CD3
		, src.P_ZIP5_CD3
		, src.P_ZIP4_CD3
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address2;

-----Monitoring we don't require this dashboard trigger 
EXEC('DISABLE TRIGGER all ON kyp.pdm_location');

 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive]
           ,[IsDeleted])
 select distinct A.AddressId,A.PartyId,A.providerId, GETDATE(),1,0 from @Address2 A left join kyp.PDM_Location b
 on A.AddressID=B.AddressID
 left join kyp.PDM_Party C on A.PartyID=C.PartyID and c.currentmodule=2 and isnull(c.isdeleted,'0')=0
 where b.addressID is null and c.partyid is not null
-- addressId not in (select addressId from kyp.PDM_Location)
-- ---and partyid not in (select partyid from kyp.PDM_Location)   --commented on 3rdSep2018
--and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
--		and IsDeleted = 0 
--		and IsDeleted = 0)

-----Monitoring we don't require this dashboard trigger 
 EXEC('Enable TRIGGER all ON kyp.pdm_location');
		

	

/* ------------Commented on 3rdSep2018 because both Ind and Org address handling through same above block and now below duplicate logic block not required specific for individuals
declare @Address3 table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD,
		 x.P_LINE2_AD,
		x.P_CITY_NAM,
		x.P_ST_CD
		, x.P_ZIP5_CD
		, x.P_ZIP4_CD,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select C.*,A.LastName,A.FirstName,d.PartyID from KYP.PDM_Person A
	inner join 
	KYP.PDM_Location B 
	on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on B.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(B.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD,''))))
	AND
	((LTRIM(RTRIM(ISNULL(y.LastName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LAST_NAM,'')))) OR 
	(LTRIM(RTRIM(ISNULL(y.FirstName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_FST_NAM,'')))))
	where x.ProviderType='Individual' and y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD,
		 src.P_LINE2_AD,
		src.P_CITY_NAM,
		src.P_ST_CD
		, src.P_ZIP5_CD
		, src.P_ZIP4_CD
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address3;
 
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive]
           ,[IsDeleted])
 select AddressId,PartyId,providerId, GETDATE(),1,0 from @Address3
 where addressId not in (select addressId from kyp.PDM_Location)
 and partyid not in (select partyid from kyp.PDM_Location)
and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0)
update x
set x.AddressLine1=y.AddressLine1,
x.State=y.State,
x.City=y.City,
x.Zip=y.Zip,
x.Country=y.Country,
x.AddressID=y.AddressID 
from KYP.DSH_DashBoardTable x
inner join kyp.PDM_Location z
on x.PartyID= z.PartyID
inner join kyp.PDM_Address y
on z.AddressID = y.AddressID



declare @Address4 table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD2,
		 x.P_LINE2_AD2,
		x.P_CITY_NAM2,
		x.P_ST_CD2
		, x.P_ZIP5_CD2
		, x.P_ZIP4_CD2,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select C.*,A.LastName,A.FirstName,d.PartyID from KYP.PDM_Person A
	inner join 
	KYP.PDM_Location B 
	on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on B.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(B.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD2,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD2,''))))
	AND
	((LTRIM(RTRIM(ISNULL(y.LastName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LAST_NAM,'')))) OR 
	(LTRIM(RTRIM(ISNULL(y.FirstName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_FST_NAM,'')))))
	where x.ProviderType='Individual' and y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD2,
		 src.P_LINE2_AD2,
		src.P_CITY_NAM2,
		src.P_ST_CD2
		, src.P_ZIP5_CD2
		, src.P_ZIP4_CD2
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address4;
 
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive]
           ,[IsDeleted])
 select AddressId,PartyId,providerId, GETDATE(),1,0 from @Address4
 where addressId not in (select addressId from kyp.PDM_Location)
 and partyid not in (select partyid from kyp.PDM_Location)
and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0)

declare @Address5 table (addressId INT , providerId int, partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD3,
		 x.P_LINE2_AD3,
		x.P_CITY_NAM3,
		x.P_ST_CD3
		, x.P_ZIP5_CD3
		, x.P_ZIP4_CD3,Y.addressId from [tmp_ProviderNameAddress] x
	left join 
	(select C.*,A.LastName,A.FirstName,d.PartyID from KYP.PDM_Person A
	inner join 
	KYP.PDM_Location B 
	on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on B.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(B.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.partyid = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD3,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD3,''))))
	AND
	((LTRIM(RTRIM(ISNULL(y.LastName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LAST_NAM,'')))) OR 
	(LTRIM(RTRIM(ISNULL(y.FirstName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_FST_NAM,'')))))
	where x.ProviderType='Individual' and y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD3,
		 src.P_LINE2_AD3,
		src.P_CITY_NAM3,
		src.P_ST_CD3
		, src.P_ZIP5_CD3
		, src.P_ZIP4_CD3
		,getdate(),1,0)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address5;
 
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,ProviderID,DateCreated,[InActive]
           ,[IsDeleted])
 select AddressId,PartyId,providerId, GETDATE(),1,0 from @Address5		
 where addressId not in (select addressId from kyp.PDM_Location)
 and partyid not in (select partyid from kyp.PDM_Location)
 and PartyId in(select PartyID from kyp.PDM_Party where CurrentModule = 2
		and IsDeleted = 0 
		and IsDeleted = 0)
		

*/
-----------individual Owner---------------------

 SELECT distinct	   
       nullif(Case When x.[P_OWNER_LAST_NAM] = '' Then '' ELSE KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_LAST_NAM],', ',' '),',',' '))))) End,'') as [P_OWNER_LAST_NAM]
      ,nullif(Case When x.[P_OWNER_FST_NAM] = '' Then '' ELSE KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_FST_NAM],', ',' '),',',' '))))) End,'') as [P_OWNER_FST_NAM]
      ,nullif(Case When x.[P_OWNER_MI_NAM] = '' Then '' ELSE KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_MI_NAM],', ',' '),',',' '))))) End,'') as [P_OWNER_MI_NAM]
      ,nullif(x.[P_OWNER_TITL_NAM],'') [P_OWNER_TITL_NAM]
      ,nullif(x.[P_OWNER_DOB_DT],'') [P_OWNER_DOB_DT]
      ,nullif(x.[P_OWNER_SSN_NUM],'') [P_OWNER_SSN_NUM]
      ,nullif(x.[P_LINE1_AD],'') [P_LINE1_AD]
      ,nullif(x.[P_LINE2_AD],'') [P_LINE2_AD]
      ,nullif(x.[P_CITY_NAM],'') [P_CITY_NAM]
      ,nullif(x.[P_ST_CD],'') [P_ST_CD]
      ,nullif(x.[P_ZIP5_CD],'') [P_ZIP5_CD]
      ,nullif(x.[P_ZIP4_CD],'') [P_ZIP4_CD]
      ,nullif(x.Owner_FullName ,'') Owner_FullName
      ,nullif(x.Owner_NPI,'') Owner_NPI
      ,nullif(y.PartyId,'') PartyId
      ,nullif(y.ProvId,'') ProvId
      ,nullif(y.LoadId,'') LoadId
      ,nullif(y.LoadType,'') LoadType
      ,nullif(y.LastLoadDate,'') LastLoadDate
      ,cast(null as int) as OwnerId
      ,CAST(null as INT) as ownerpartyid
      ,nullif(x.MOCA_END_DT,'') MOCA_END_DT
      --partyid owner update
      ,nullif(x.id,'') id
      ,nullif(X.P_ID,'') P_ID
      ,nullif(MOCAPartyStatus,'') EnrollmentMOCAPartyID
into tmp_IndOwners
FROM [dbo].Monitoring_ProviderIndOwner x
inner join [dbo].[tmp_ProviderNameAddress] y
on x.P_ID=y.P_ID


update tmp_IndOwners set Owner_NPI = null where Owner_NPI=''
update tmp_IndOwners set [P_OWNER_SSN_NUM] = null where [P_OWNER_SSN_NUM]=''
update tmp_IndOwners set Owner_FullName = P_OWNER_LAST_NAM+COALESCE((', ' + P_OWNER_FST_NAM), '') +  COALESCE((' ' + P_OWNER_MI_NAM), '')


---L+NPI+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_Last_NAM= y.LastName
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.LastName is not null
and x.P_OWNER_Last_NAM= y.LastName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+NPI+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_FST_NAM= y.FirstName
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.FirstName is not null
and x.P_OWNER_FST_NAM= y.FirstName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---L+NPI+(SSN blank also)+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_Last_NAM= y.LastName
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.LastName is not null
and x.P_OWNER_Last_NAM= y.LastName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and isnull(x.[P_owner_SSN_NUM],'') = isnull(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+NPI+(SSN blank also)+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_FST_NAM= y.FirstName
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.FirstName is not null
and x.P_OWNER_FST_NAM= y.FirstName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and isnull(x.[P_owner_SSN_NUM],'') = isnull(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---L+(NPI blank also)+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_Last_NAM= y.LastName
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.LastName is not null
and x.P_OWNER_Last_NAM= y.LastName and isnull(x.Owner_NPI,'')  = isnull(y.NPI,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---F+(NPI blank also)+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.P_OWNER_FST_NAM= y.FirstName
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.FirstName is not null
and x.P_OWNER_FST_NAM= y.FirstName and isnull(x.Owner_NPI,'')  = isnull(y.NPI,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.SSN,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.DOB,'')
and z.CurrentModule=2 --change added on 1Sep2018

---------------------------------------


--check currentmodule=2 for ind owner
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.p_owner_last_Nam= y.LastName
where x.ownerpartyid is null and x.p_owner_last_Nam is not null and y.LastName is not null and z.CurrentModule=2
and (
x.p_owner_last_Nam= y.LastName and 
nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and  (
isnull(x.[P_owner_SSN_NUM],'') = isnull(y.SSN,'')
or isnull(y.SSN,'')='' or isnull(x.[P_owner_SSN_NUM],'')=''
) 
)

update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
on x.p_owner_last_Nam= y.LastName
where x.ownerpartyid is null and x.p_owner_last_Nam is not null and y.LastName is not null and z.CurrentModule=2
and (
x.p_owner_last_Nam= y.LastName and 
nullif(x.[P_owner_SSN_NUM],'')  = nullif(y.SSN,'') and  (
isnull(x.Owner_NPI,'') = isnull(y.NPI,'')
or isnull(y.NPI,'')='' or isnull(x.Owner_NPI,'')=''
) 
)

--check currentmodule=2 for ind owner

update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
 on x.P_OWNER_FST_NAM= y.FirstName  ---corrected 30Aug2018 late night
where x.ownerpartyid is null and x.P_OWNER_FST_NAM is not null and y.FirstName is not null and z.CurrentModule=2 --changed on 29Aug2018 checking first name instead of Last name
and (x.P_OWNER_FST_NAM= y.FirstName and 
nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and  (
isnull(x.[P_owner_SSN_NUM],'') = isnull(y.SSN,'')
or isnull(y.SSN,'')='' or isnull(x.[P_owner_SSN_NUM],'')=''
) 
)


update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 inner join  tmp_IndOwners x
 on x.P_OWNER_FST_NAM= y.FirstName  ---corrected 30Aug2018 late night
where x.ownerpartyid is null and x.P_OWNER_FST_NAM is not null and y.FirstName is not null and z.CurrentModule=2 --changed on 29Aug2018 checking first name instead of Last name
and (x.P_OWNER_FST_NAM= y.FirstName and 
nullif(x.[P_owner_SSN_NUM],'')  = nullif(y.SSN,'') and  (
isnull(x.Owner_NPI,'') = isnull(y.NPI,'')
or isnull(y.NPI,'')='' or isnull(x.Owner_NPI,'')=''
) 
)

--------------Added on 30Aug2018-----------------
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_Party z
 join kyp.PDM_Person y
 on z.PartyID=y.partyid
 join kyp.PDM_Location L on z.PartyID=L.PartyID
 join kyp.PDM_Address AD on L.AddressID=AD.AddressID
 join  tmp_IndOwners x 
 on x.p_owner_last_Nam= y.LastName and x.P_OWNER_FST_NAM=Y.FirstName --checking first/last and address
 and x.P_LINE1_AD=Ad.AddressLine1 and x.P_CITY_NAM=Ad.City
where x.ownerpartyid is null and x.Owner_NPI is null and x.[P_owner_SSN_NUM] is null 
and z.CurrentModule=2 --changed on 29Aug2018 

--------------------------------------------------------

update x
set  x.OwnerId = y.OwnerID
from tmp_IndOwners x
inner join kyp.PDM_Owner y
on x.ownerpartyid = y.PartyID
where x.OwnerId is null

UPDATE trgt		 
		set trgt.[Name] = src.Owner_FullName
		 ,trgt.[LoadType] = src.LoadType
		 ,trgt.[LoadID] = src.LoadID
		 ,trgt.[LastLoadDate] = src.LastLoadDate
		 ,trgt.DateModified = getdate()
		 ,trgt.MOCA_END_DT = src.MOCA_END_DT
		 ,trgt.filesource='P'
 from [KYP].[PDM_Party]  trgt
inner join
(  
  select distinct x.MOCA_END_DT,x.ownerpartyid, x.Owner_FullName,x.loadtype,x.loadid,x.lastloaddate, 0 as IsProvider
from tmp_IndOwners x where x.ownerpartyid is not null

)src 
ON trgt.partyid=src.ownerpartyid


--------------------------------------------
---update pdm person -- 
UPDATE x
set
		x.SSN = case when z.partyid is not null and nullif(X.SSN,'') is null then nullif(y.P_owner_SSN_NUM,'') 
						when z.partyid is null and nullif(y.P_owner_SSN_NUM,'') is not null then nullif(y.P_owner_SSN_NUM,'') else nullif(X.SSN,'') end  
		,x.Salunation =case when z.partyid is not null and nullif(X.Salunation,'') is null  then nullif(y.P_OWNER_TITL_NAM,'') 
						when z.partyid is null and nullif(y.P_OWNER_TITL_NAM,'') is not null then nullif(y.P_OWNER_TITL_NAM,'') else nullif(X.Salunation,'') end  
		,x.FirstName =case when z.partyid is not null and nullif(X.FirstName,'') is null then nullif(y.P_owner_FST_NAM,'') 
						when z.partyid is null and nullif(y.P_owner_FST_NAM,'') is not null then nullif(y.P_owner_FST_NAM,'') else  nullif(X.FirstName,'') end   
		,x.LastName =case when z.partyid is not null and nullif(X.LastName,'') is null then nullif(y.P_owner_LAST_NAM,'') 
						when z.partyid is null and nullif(y.P_owner_LAST_NAM,'') is not null then nullif(y.P_owner_LAST_NAM,'') else  nullif(X.LastName,'') end    
		,x.MiddleName =case when z.partyid is not null and nullif(X.MiddleName,'') is null then nullif(y.P_owner_MI_NAM,'') 
						when z.partyid is null and nullif(y.P_owner_MI_NAM,'') is not null then nullif(y.P_owner_MI_NAM,'') else  nullif(X.MiddleName,'') end  
		,x.DoB =case when z.partyid is not null and nullif(X.DoB,'') is null then nullif(y.P_owner_DOB_DT,'') 
					when z.partyid is null and nullif(y.P_owner_DOB_DT,'') is not null then nullif(y.P_owner_DOB_DT,'') else  nullif(X.DoB,'') end   
		,x.NPI =case when z.partyid is not null and nullif(X.NPI,'') is null then nullif(y.[owner_NPI],'') 
					when z.partyid is null and nullif(y.[owner_NPI],'') is not null then nullif(y.[owner_NPI],'') else  nullif(X.NPI,'') end  
		,x.DateModified = GETDATE() 
from kyp.PDM_Person x
inner join 
(
select distinct x.ownerpartyid,x.P_owner_SSN_NUM,x.P_OWNER_TITL_NAM,x.P_owner_FST_NAM,x.P_owner_MI_NAM,x.P_owner_LAST_NAM,x.P_owner_DOB_DT,x.[owner_NPI]
from tmp_IndOwners x where x.ownerpartyid is not null
)y
on x.PartyID=y.ownerpartyid
left join tmp_providerNameAddress z on y.ownerpartyid=z.partyid  ----added on 4thSep2018 to restrict owner details owerwrites provider details for common parties 



-----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..#tmpIndParties2','U') IS NOT NULL
begin 
drop table #tmpIndParties2
end

select x.* into #tmpIndParties2  from(select * from tmp_IndOwners where ownerpartyid is null)x


--Strong condition added on 1sSep2018
--L+NPI+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_Last_NAM,Owner_NPI,P_Owner_SSN_Num,P_owner_DOB_DT order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is not null and P_owner_Last_NAM is not null and P_Owner_SSN_Num is not null)x
where x.row1>1

--F+NPI+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, Owner_NPI,P_Owner_SSN_Num,P_owner_DOB_DT order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is not null and P_owner_FST_NAM is not null and P_Owner_SSN_Num is not null)x
where x.row1>1

--L+NPI+SSN blank+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, Owner_NPI,P_owner_DOB_DT,P_Owner_SSN_Num order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is not null and P_owner_FST_NAM is not null and P_Owner_SSN_Num is null)x
where x.row1>1

--L+NPI blank+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, Owner_NPI,P_owner_DOB_DT,P_Owner_SSN_Num order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is null and P_owner_FST_NAM is not null and P_Owner_SSN_Num is not null)x
where x.row1>1

--FN+NPI+SSN blank+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, Owner_NPI,P_owner_DOB_DT,P_Owner_SSN_Num order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is not null and P_owner_FST_NAM is not null and P_Owner_SSN_Num is null)x
where x.row1>1

--FN+NPI blank+SSN+(DOB blank also)
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, Owner_NPI,P_owner_DOB_DT,P_owner_SSN_NUM order by ownerpartyid) as row1
from #tmpIndParties2
where Owner_NPI is null and P_owner_FST_NAM is not null and P_owner_SSN_NUM is not null)x
where x.row1>1


------Added on 8Sep2018
delete x from (select *, ROW_NUMBER()over(partition by P_owner_FST_NAM, P_owner_LAST_NAM,P_LINE1_AD,P_CITY_NAM order by ownerpartyid) as row1
from #tmpIndParties2
where P_owner_SSN_NUM is null and Owner_NPI is null)x
where x.row1>1

-------insert individual party and person for new records-------------

declare @personTemp1 table (partyid INT ,provid int, P_SSN_NUM varchar(9), P_SFX_NAM varchar(10), 
P_LAST_NAM varchar(50), P_FST_NAM varchar(50),P_MI_NAM varchar(50), P_DOB_DT datetime, P_NPI_NUM varchar(10)
--additional attribute: ID for updating partyid in @persontemp1
,id varchar(20),
P_LINE1_AD varchar(50), ----Added new columns for address and name match
P_CITY_NAM varchar(30),
P_ID varchar(20)
)

MERGE [KYP].[PDM_Party]  trgt
USING 
(  
  select distinct x.ownerpartyid, x.[P_OWNER_LAST_NAM]
      ,x.[P_OWNER_FST_NAM]
      ,x.[P_OWNER_MI_NAM]
      ,x.[P_OWNER_TITL_NAM]
      ,x.[P_OWNER_DOB_DT]
      ,x.[P_OWNER_SSN_NUM]
      ,x.[P_LINE1_AD]
      ,x.[P_LINE2_AD]
      ,x.[P_CITY_NAM]
      ,x.[P_ST_CD]
      ,x.[P_ZIP5_CD]
      ,x.[P_ZIP4_CD]
      ,x.Owner_FullName 
      ,x.Owner_NPI
      ,x.LoadId
      ,x.LoadType
      ,x.LastLoadDate
      ,x.MOCA_END_DT
      ,'Person' as [Type],0 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,2 as currentmodule,id,
      x.P_ID
from #tmpIndParties2 x where x.ownerpartyid is null
)src ON (trgt.partyid=src.ownerpartyid)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],[CurrentModule],MOCA_END_DT, filesource )
 VALUES (src.[Type],src.Owner_FullName,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,src.currentmodule,src.MOCA_END_DT,'P')
output inserted.partyid,null as provid, src.P_owner_SSN_NUM,src.[P_OWNER_TITL_NAM],src.[P_owner_LAST_NAM],src.[P_owner_FST_NAM],src.[P_owner_MI_NAM],src.[P_owner_DOB_DT],src.Owner_NPI,src.id,
src.P_LINE1_AD,src.P_CITY_NAM,src.P_ID
 into @personTemp1;

INSERT INTO [KYP].[PDM_person]
           (PartyID,SSN,Salunation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated)
select partyid, P_SSN_NUM,P_SFX_NAM,P_FST_NAM,P_MI_NAM,P_LAST_NAM,P_DOB_DT,P_NPI_NUM,GETDATE() from @personTemp1 
 
 --------------------------------------------------------------------
 
 ---L+NPI+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_Last_NAM= y.P_LAST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.P_LAST_NAM is not null
and x.P_OWNER_Last_NAM= y.P_LAST_NAM and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---F+NPI+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_FST_NAM= y.P_FST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.P_FST_NAM is not null
and x.P_OWNER_FST_NAM= y.P_FST_NAM and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---L+NPI+(SSN blank also)+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_Last_NAM= y.P_LAST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.P_LAST_NAM is not null
and x.P_OWNER_Last_NAM= y.P_LAST_NAM and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') and isnull(x.[P_owner_SSN_NUM],'') = isnull(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---F+NPI+(SSN blank also)+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_FST_NAM= y.P_FST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.P_FST_NAM is not null
and x.P_OWNER_FST_NAM= y.P_FST_NAM and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') and isnull(x.[P_owner_SSN_NUM],'') = isnull(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')

---L+(NPI blank also)+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_Last_NAM= y.P_LAST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_Last_NAM is not null and y.P_LAST_NAM is not null
and x.P_OWNER_Last_NAM= y.P_LAST_NAM and isnull(x.Owner_NPI,'')  = isnull(y.P_NPI_NUM,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')


---F+(NPI blank also)+SSN+(DOB blank also)
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.P_OWNER_FST_NAM= y.P_FST_NAM
where x.ownerpartyid is null 
and x.P_OWNER_FST_NAM is not null and y.P_FST_NAM is not null
and x.P_OWNER_FST_NAM= y.P_FST_NAM and isnull(x.Owner_NPI,'')  = isnull(y.P_NPI_NUM,'') and nullif(x.[P_owner_SSN_NUM],'') = nullif(y.P_SSN_NUM,'') and 
isnull(x.P_owner_DOB_DT,'')=isnull(Y.P_DOB_DT,'')
 
---Changed on 29Aug2018
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on --x.id= y.ID---------------Commented on 29Aug2018
nullif(x.P_owner_LAST_NAM,'')=nullif(Y.P_LAST_NAM,'') and  nullif(x.[owner_NPI],'')=nullif(y.P_NPI_NUM,'')
where x.ownerpartyid is null and (
ISNULL(x.P_owner_SSN_NUM,'')=ISNULL(Y.P_SSN_NUM,'') or ISNULL(x.P_owner_SSN_NUM,'')='' or ISNULL(Y.P_SSN_NUM,'')=''
)

update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on --x.id= y.ID---------------Commented on 29Aug2018
nullif(x.P_owner_LAST_NAM,'')=nullif(Y.P_LAST_NAM,'') and  nullif(x.P_owner_SSN_NUM,'')=nullif(y.P_SSN_NUM,'')
where x.ownerpartyid is null and (
ISNULL(x.[owner_NPI],'')=ISNULL(Y.P_NPI_NUM,'') or ISNULL(x.[owner_NPI],'')='' or ISNULL(Y.P_NPI_NUM,'')=''
)


update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on --x.id= y.ID---------------Commented on 29Aug2018
nullif(x.P_owner_Fst_NAM,'')=nullif(Y.P_FST_NAM,'') and  nullif(x.[owner_NPI],'')=nullif(y.P_NPI_NUM,'')
where x.ownerpartyid is null and (
ISNULL(x.P_owner_SSN_NUM,'')=ISNULL(Y.P_SSN_NUM,'') or ISNULL(x.P_owner_SSN_NUM,'')='' or ISNULL(Y.P_SSN_NUM,'')=''
)

update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on --x.id= y.ID---------------Commented on 29Aug2018
nullif(x.P_owner_Fst_NAM,'')=nullif(Y.P_FST_NAM,'') and  nullif(x.P_owner_SSN_NUM,'')=nullif(y.P_SSN_NUM,'')
where x.ownerpartyid is null and (
ISNULL(x.[owner_NPI],'')=ISNULL(Y.P_NPI_NUM,'') or ISNULL(x.[owner_NPI],'')='' or ISNULL(Y.P_NPI_NUM,'')=''
)


----Added on 30Aug2018
update x 
set x.ownerpartyid = y.partyid   ----Corrected 30Aug2018 late night
from tmp_IndOwners x
inner join @personTemp1 y
on nullif(x.P_owner_Fst_NAM,'')=nullif(y.[P_Fst_NAM],'') and nullif(x.P_owner_LAST_NAM,'')=nullif(Y.P_LAST_NAM,'') ---Based on name and address
and nullif(x.P_LINE1_AD,'')=nullif(Y.P_LINE1_AD,'') and nullif(x.P_CITY_NAM,'')=nullif(Y.P_CITY_NAM,'')
where x.ownerpartyid is null

-------Added on 31stAug2017 in order add moca without ssn/npi/address
update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on --x.id= y.ID---------------Commented on 29Aug2018
nullif(x.P_owner_Fst_NAM,'')=nullif(Y.P_FST_NAM,'') and  nullif(x.P_owner_LAST_NAM,'')=nullif(y.P_LAST_NAM,'')
and nullif(x.P_OWNER_DOB_DT,'')=nullif(Y.P_DOB_DT,'')
where x.ownerpartyid is null and nullif(x.P_OWNER_DOB_DT,'') is not null
--------------------------------------------------------

update x
set x.ownerpartyid = y.partyid
 from tmp_IndOwners x
   inner join  @personTemp1 y
on x.id= y.ID---------------Added for party where NPI/SSN/Name missing
where x.ownerpartyid is null 


Insert INTO [Kyp].[PDM_Owner](PartyID,ProviderID,Designation,DateCreated,IsDeleted)
select distinct ownerpartyid, provId,P_OWNER_TITL_NAM,GETDATE(),0 as deleted from tmp_IndOwners where OwnerId is null



update x
set  x.OwnerId = y.OwnerID
from tmp_IndOwners x
inner join kyp.PDM_Owner y
on x.ownerpartyid = y.PartyID
where x.OwnerId is null


----Change-------------Added on 23-02-2018
Insert INTO [Kyp].[PDM_Owner](PartyID,ProviderID,Designation,DateCreated,IsDeleted)
select A.ownerpartyid, A.provId,P_OWNER_TITL_NAM,GETDATE(),0 as deleted from tmp_IndOwners A join(
select ownerpartyid, provId from tmp_IndOwners
except
select partyid, providerID from kyp.pdm_Owner
)B on A.ownerpartyid=B.ownerpartyid and A.provId=B.provId


update x
set  x.OwnerId = y.OwnerID
from tmp_IndOwners x
inner join kyp.PDM_Owner y
on x.ownerpartyid = y.PartyID and x.provId=y.providerID
where x.OwnerId is null													   


--**************************************************************************
-------------------------Ind Owners Address---------------------------
----------------Added on 3rdSep2018 ---missing address load part for owners

----Added on 3rdSep2018		
-----Update modified date of address   
Update C set DateModified=getdate(),
Inactive=1,
ISdeleted=0,
C.AddressLine2=(Case when nullif(ISNULL(x.P_LINE2_AD,''),'') is not null then x.P_LINE2_AD else C.AddressLine2 end)  --added on 6Sep2018 to consider AddressLine2 as well for update
from tmp_indowners x
join KYP.PDM_Location A 
	on X.OwnerPartyID = A.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0
	and nullif(x.P_LINE1_AD,'') is not null
	and (LTRIM(RTRIM(ISNULL(c.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(c.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD,''))))


declare @IndOnwerAddress table (addressId INT , partyid int)


MERGE [KYP].[PDM_Address]  trgt
USING 
( 	
select distinct x.*,y.AddressID from (
select OwnerPartyID,P_LINE1_AD,	
P_LINE2_AD,	
P_CITY_NAM, 
P_ST_CD, 
P_ZIP5_CD,
P_ZIP4_CD
from dbo.tmp_indowners where P_LINE1_AD is not null 
group by OwnerPartyID,P_LINE1_AD,P_LINE2_AD,P_CITY_NAM,P_ST_CD,P_ZIP5_CD,P_ZIP4_CD)  x
	left join 
	(select D.PartyID,C.* --,A.LegalName,A.DBAName1
	from --KYP.PDM_Organization A inner join 
	KYP.PDM_Location A 
	--on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.OwnerPartyID = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP5_CD,'')))) and
	(LTRIM(RTRIM(ISNULL(y.ZipPlus4,'')))) = (LTRIM(RTRIM(ISNULL(x.P_ZIP4_CD,''))))
	--AND																----Commented on 3rdSep2018, we already found Party just need to be check address for party
	--((LTRIM(RTRIM(ISNULL(y.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_DBA_NAM,'')))) OR 
	--(LTRIM(RTRIM(ISNULL(y.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_NAM,'')))))
	where --x.ProviderType='Organization' and       ---Commented on 3rdSep2018 in order to accomodate both person and Org parties in single query
	y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_LINE1_AD,
		 src.P_LINE2_AD,
		src.P_CITY_NAM,
		src.P_ST_CD
		, src.P_ZIP5_CD
		, src.P_ZIP4_CD
		,getdate(),1,0)
output inserted.AddressId,src.OwnerPartyID
 into @IndOnwerAddress;


-----Monitoring we don't require this dashboard trigger 
 EXEC('DISABLE TRIGGER all ON kyp.pdm_location');
 

--select distinct A.* from testVBS A join kyp.pdm_Party b on A.PartyID=B.PartyID
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,DateCreated,[InActive]
           ,[IsDeleted])
 select distinct A.AddressId,A.PartyId, GETDATE(),1,0 from @IndOnwerAddress A 
 left join kyp.PDM_Location B
 on A.AddressID=B.AddressID
 left join kyp.PDM_Party C
 on A.PartyID=C.PartyID and c.CurrentModule = 2 and isnull(c.IsDeleted,'0')=0
 where B.AddressId is null and C.PartyID is not null

 EXEC('enable TRIGGER all ON kyp.pdm_location');

		
	
--*****************************************************************************************************************
 ------------------------------Organization owners

SELECT distinct
       KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(COALESCE(x.P_OWNER_BUSN_NAM,x.P_OWNER_DBA_NAM))) as P_OWNER_BUSN_NAM
      ,nullif(KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(x.P_OWNER_DBA_NAM)),'')  as P_OWNER_DBA_NAM
      , nullif(x.[P_OWNER_TAX_ID],'') [P_OWNER_TAX_ID]
      , nullif(x.[P_BUSN_LINE1_AD],'') [P_BUSN_LINE1_AD]
      , nullif(x.[P_BUSN_LINE2_AD],'') [P_BUSN_LINE2_AD]
      , nullif(x.[P_BUSN_CITY_NAM],'') [P_BUSN_CITY_NAM]
      , nullif(x.[P_BUSN_ST_CD],'') [P_BUSN_ST_CD]
      , nullif(x.[P_BUSN_ZIP5_CD],'') [P_BUSN_ZIP5_CD]
      , nullif(x.[P_BUSN_ZIP4_CD],'') [P_BUSN_ZIP4_CD]
       ,nullif(x.Owner_NPI,'') Owner_NPI
       ,nullif(x.MOCA_END_DT,'') MOCA_END_DT
      ,nullif(y.PartyId,'') PartyId
      ,nullif(y.ProvId,'') ProvId
      ,nullif(y.LoadId,'') LoadId
      ,nullif(y.LoadType,'') LoadType
      ,nullif(y.LastLoadDate,'') LastLoadDate
      ,CAST(null as INT) as ownerid
      ,CAST(null as INT) as ownerpartyid
      --partyid owner update
      ,nullif(x.ID,'') ID
      ,nullif(x.P_ID,'') P_ID
      ,nullif(MOCAPartyStatus,'') EnrollmentMOCAPartyID
      into tmp_orgOwner
 FROM [dbo].Monitoring_ProviderOrgOwner x
  inner join [tmp_ProviderNameAddress] y
  on  x.[P_ID] =y.P_ID
  
  
  
update tmp_orgOwner set Owner_NPI = null where Owner_NPI=''
update tmp_orgOwner set [P_OWNER_TAX_ID] = null where [P_OWNER_TAX_ID]=''
update tmp_orgOwner set P_OWNER_BUSN_NAM = null where P_OWNER_BUSN_NAM=''
update tmp_orgOwner set P_OWNER_DBA_NAM = null where P_OWNER_DBA_NAM=''


---Strong Condition --Added on 1Sep2018
--check currentmodule=2 for org owner
--Name+Npi+Tax
update x
set x.ownerpartyid = y.partyid
	from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on x.P_OWNER_BUSN_NAM= y.LegalName 
 where x.P_OWNER_BUSN_NAM= y.LegalName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.TIN,'')
 and x.ownerpartyid is null and z.CurrentModule=2
 
  ---LegalName10+NPI+TIn(blank also)
 --change added on 7Sep2018
update x
set x.ownerpartyid = y.partyid
	from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on left(x.P_OWNER_BUSN_NAM,10)= left(y.LegalName,10) 
 where left(x.P_OWNER_BUSN_NAM,10)= left(y.LegalName,10) and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') 
 and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.TIN,'')
 and x.ownerpartyid is null and z.CurrentModule=2
 
   ---LegalName10+NPI
 --change added on 7Sep2018
update x
set x.ownerpartyid = y.partyid
	from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on left(x.P_OWNER_BUSN_NAM,10)= left(y.LegalName,10) 
 where left(x.P_OWNER_BUSN_NAM,10)= left(y.LegalName,10) and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') 
 and (nullif(x.[P_OWNER_TAX_ID],'') is null  or  nullif(y.TIN,'') is null)
 and x.ownerpartyid is null and z.CurrentModule=2
 
 
   ----change added on 7Sep2018
 ------LegalName15+TIN only for individuals
update x
set x.ownerpartyid = y.partyid
	from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on left(x.P_OWNER_BUSN_NAM,15)= left(y.LegalName,15) 
 where left(x.P_OWNER_BUSN_NAM,15)= left(y.LegalName,15) and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.TIN,'') 
 and (nullif(x.Owner_NPI,'') is null or nullif(y.NPI,'') is null)
 and x.ownerpartyid is null and z.CurrentModule=2
 
 
 
--check currentmodule=2 for org owner
update x
set x.ownerpartyid = y.partyid
from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on x.P_OWNER_BUSN_NAM= y.LegalName 
 where x.P_OWNER_BUSN_NAM= y.LegalName and nullif(x.Owner_NPI,'')  = nullif(y.NPI,'') and (
 isnull(x.[P_OWNER_TAX_ID],'')  = isnull(y.TIN,'') or  isnull(y.TIN,'')='' or isnull(x.[P_OWNER_TAX_ID],'')=''
 )
 and x.ownerpartyid is null and z.CurrentModule=2
 
 
update x
set x.ownerpartyid = y.partyid
from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join tmp_orgOwner x
 on x.P_OWNER_BUSN_NAM= y.LegalName 
 where x.P_OWNER_BUSN_NAM= y.LegalName and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.TIN,'') and (
 isnull(x.Owner_NPI,'')  = isnull(y.NPI,'') or  isnull(y.NPI,'')='' or isnull(x.Owner_NPI,'')=''
 )
 and x.ownerpartyid is null and z.CurrentModule=2
 
---Added on 30Aug2018
---required for only owners and not for providers
update x
set x.ownerpartyid = y.partyid
 from kyp.PDM_party z
   inner join  kyp.PDM_Organization y
   on z.PartyID=y.partyid
   join kyp.PDM_Location L on z.partyid=L.PartyID
   join kyp.PDM_Address Ad on L.AddressID=Ad.AddressID
   join tmp_orgOwner x
 on x.P_OWNER_BUSN_NAM= y.LegalName and x.P_BUSN_LINE1_AD=Ad.AddressLine1 and
 x.P_BUSN_CITY_NAM=AD.City
 where (x.Owner_NPI is null and x.[P_OWNER_TAX_ID] is null)
 and x.ownerpartyid is null and z.CurrentModule=2
 
 
update x
set  x.OwnerId = y.OwnerID
from tmp_orgOwner x
inner join kyp.PDM_Owner y
on x.ownerpartyid = y.PartyID
where x.OwnerId is null


update	trgt
 set trgt.Name = src.P_OWNER_BUSN_NAM
	 ,trgt.LoadType = src.LoadType
	 ,trgt.LoadID = src.LoadID
	 ,trgt.LastLoadDate = src.LastLoadDate
	 ,trgt.DateModified = getdate()
	  ,trgt.MOCA_END_DT = src.MOCA_END_DT
		,trgt.filesource='P'
from [KYP].[PDM_Party]  trgt
inner join tmp_orgOwner src
 on trgt.partyid=src.ownerpartyid

-------------pdm_organization update-------------
update	trgt
 set trgt.TIN =case when z.partyid is not null and nullif(trgt.TIN,'') is null  then nullif(src.[P_OWNER_TAX_ID],'') 
				when z.partyid is null and nullif(src.[P_OWNER_TAX_ID],'') is not null then nullif(src.[P_OWNER_TAX_ID],'') else nullif(trgt.TIN,'') end 
		,trgt.LegalName = case when z.partyid is not null and nullif(trgt.LegalName,'') is null  then nullif(src.P_OWNER_BUSN_NAM,'') 
							when z.partyid is null and nullif(src.P_OWNER_BUSN_NAM,'') is not null then nullif(src.P_OWNER_BUSN_NAM,'') else nullif(trgt.LegalName,'') end
		,trgt.DBAName1 = case when z.partyid is not null and nullif(trgt.DBAName1,'') is null  then nullif(src.P_OWNER_DBA_NAM,'')
							when z.partyid is null and nullif(src.P_OWNER_DBA_NAM,'') is not null then nullif(src.P_OWNER_DBA_NAM,'')  else nullif(trgt.DBAName1,'') end
		,trgt.NPI = case when z.partyid is not null and nullif(trgt.NPI,'') is null  then nullif(src.Owner_NPI,'') 
							when z.partyid is null and nullif(src.Owner_NPI,'') is not null then nullif(src.Owner_NPI,'')  else nullif(trgt.NPI,'') end
		,trgt.DateModified = GETDATE()
from [KYP].[PDM_organization]  trgt
inner join tmp_orgOwner src
 on trgt.partyid=src.ownerpartyid
left join dbo.tmp_providernameAddress z on --------Added on 4th Sep2018 to restrict common party update between owner and providers
z.PartyID=src.ownerpartyid

 --------------------------------------------------------------------------------------------
 IF OBJECT_ID('tempdb..#OrgParties1','U') IS NOT NULL
begin 
drop table #OrgParties1
end

select x.*
into #OrgParties1
from tmp_orgOwner x
where  x.ownerpartyid is null


--N+NPI+TIN
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, Owner_NPI,P_OWNER_TAX_ID order by p_id) as row1
from #OrgParties1
where Owner_NPI is not null and P_OWNER_BUSN_NAM is not null and P_OWNER_TAX_ID is not null)x
where x.row1>1

--N+NPI+Blank TIN
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, Owner_NPI,P_OWNER_TAX_ID order by p_id) as row1
from #OrgParties1
where Owner_NPI is not null and P_OWNER_BUSN_NAM is not null and nullif(P_OWNER_TAX_ID,'') is null)x
where x.row1>1

--N+Blank NPI+TIN
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, Owner_NPI,P_OWNER_TAX_ID order by p_id) as row1
from #OrgParties1
where Owner_NPI is null and P_OWNER_BUSN_NAM is not null and P_OWNER_TAX_ID is not null)x
where x.row1>1

---Added on 8Sep2018
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, P_BUSN_LINE1_AD,P_BUSN_CITY_NAM order by OwnerPartyID) as row1
from #OrgParties1
where [P_OWNER_TAX_ID] is null and Owner_NPI is null)x
where x.row1>1

/* --Commented on 2sep2018
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, Owner_NPI order by partyid) as row1
from #OrgParties1
where Owner_NPI is not null)x
where x.row1>1

delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, [P_OWNER_TAX_ID] order by partyid) as row1
from #OrgParties1
where [P_OWNER_TAX_ID] is not null)x
where x.row1>1

--delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_DBA_NAM, Owner_NPI order by partyid) as row1
--from #OrgParties1
--where Owner_NPI<>'' and P_OWNER_DBA_NAM<>'')x
--where x.row1>1

--delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_DBA_NAM, [P_OWNER_TAX_ID] order by partyid) as row1
--from #OrgParties1
--where [P_OWNER_TAX_ID]<>''  and P_OWNER_DBA_NAM<>'')x
--where x.row1>1

---Added on 30Aug2018
delete x from (select *, ROW_NUMBER()over(partition by P_OWNER_BUSN_NAM, P_BUSN_LINE1_AD,P_BUSN_CITY_NAM order by OwnerPartyID) as row1
from #OrgParties1
where [P_OWNER_TAX_ID] is null and Owner_NPI is null)x
where x.row1>1
*/
 ----------------------------------------------------
 
 ---insert org party 
 declare @OrgTemp1 table (partyid INT,provid int, P_FED_TAX_ID varchar(10), 
 --updated length from 50 to 200
P_NAM varchar(200), P_DBA_NAM varchar(200)
,P_NPI_NUM varchar(10)
--partyid owner update
,id varchar(20)
,P_BUSN_LINE1_AD varchar(50)
,P_BUSN_CITY_NAM varchar(30)
)

MERGE [KYP].[PDM_Party]  trgt
USING 
( select x.*,'Organization' as [Type],0 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,2 as currentmodule
from #OrgParties1 x where x.ownerpartyid is null
 )src 
ON (trgt.partyid=src.ownerpartyid)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],[CurrentModule],MOCA_END_DT,filesource )
 VALUES (src.[Type],src.P_OWNER_BUSN_NAM,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,src.currentmodule,src.MOCA_END_DT,'P')
output inserted.partyid,src.ProvId, src.[P_OWNER_TAX_ID],src.P_OWNER_BUSN_NAM,src.P_OWNER_DBA_NAM,src.Owner_NPI,src.ID,
src.P_BUSN_LINE1_AD,src.P_BUSN_CITY_NAM
 into @OrgTemp1;

	----insert new organizations	 
INSERT INTO [KYP].[PDM_organization]
           (PartyID,LegalName,DBAName1,TIN,NPI,DateCreated)
select partyid, P_NAM,P_DBA_NAM,P_FED_TAX_ID,P_NPI_NUM,GETDATE() from @OrgTemp1

----------------------------------------------------

--Name+Npi+Tax
update x
set x.ownerpartyid = y.partyid
from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on x.P_OWNER_BUSN_NAM= y.P_NAM 
 where x.P_OWNER_BUSN_NAM= y.P_NAM and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.P_FED_TAX_ID,'')
 and x.ownerpartyid is null

 ---LegalName10+NPI+TIN(blank also)
 --change added on 7Sep2018
update x
set x.ownerpartyid = y.partyid
from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on left(x.P_OWNER_BUSN_NAM,10)= left(y.P_NAM,10) 
 where left(x.P_OWNER_BUSN_NAM,10)= left(y.P_NAM,10) and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') 
 and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.P_FED_TAX_ID,'')
 and x.ownerpartyid is null
 
   ---LegalName10+NPI (Only for Org Owner)
 --change added on 7Sep2018
update x
set x.ownerpartyid = y.partyid
from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on left(x.P_OWNER_BUSN_NAM,10)= left(y.P_NAM,10) 
 where left(x.P_OWNER_BUSN_NAM,10)= left(y.P_NAM,10) and nullif(x.Owner_NPI,'')  = nullif(y.P_NPI_NUM,'') 
 and (nullif(x.[P_OWNER_TAX_ID],'') is null or nullif(y.P_FED_TAX_ID,'') is null)
 and x.ownerpartyid is null
 
  ---LegalName15+Tin (Only for Org Owner)
 --change added on 7Sep2018
update x
set x.ownerpartyid = y.partyid
from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on left(x.P_OWNER_BUSN_NAM,15)= left(y.P_NAM,15) 
 where left(x.P_OWNER_BUSN_NAM,15)= left(y.P_NAM,15) and nullif(x.[P_OWNER_TAX_ID],'')  = nullif(y.P_FED_TAX_ID,'') 
 and (nullif(x.Owner_NPI,'') is null or nullif(y.P_NPI_NUM,'') is null)
 and x.ownerpartyid is null
 

--Changed on 29Aug2018
update x
set x.ownerpartyid = y.partyid
 from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on -----x.id= y.id 
 nullif(x.P_OWNER_BUSN_NAM,'')=nullif(y.P_NAM,'') and nullif(x.Owner_NPI,'')=nullif(Y.P_NPI_NUM,'')
 where x.ownerpartyid is null and (
 isnull(x.[P_OWNER_TAX_ID],'')  = isnull(y.P_FED_TAX_ID,'') or  isnull(y.P_FED_TAX_ID,'')='' or isnull(x.[P_OWNER_TAX_ID],'')=''
 )

update x
set x.ownerpartyid = y.partyid
 from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on -----x.id= y.id
 nullif(x.P_OWNER_BUSN_NAM,'')=nullif(y.P_NAM,'') and nullif(x.[P_OWNER_TAX_ID],'')=nullif(Y.P_FED_TAX_ID,'')
where x.ownerpartyid is null and (
 isnull(x.Owner_NPI,'')  = isnull(y.P_NPI_NUM,'') or  isnull(y.P_NPI_NUM,'')='' or isnull(x.Owner_NPI,'')=''
 )

----Added on 30Aug2018
update x
set x.ownerpartyid = y.partyid
 from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on nullif(x.P_OWNER_BUSN_NAM,'')=nullif(y.P_NAM,'') 
 and nullif(x.P_BUSN_LINE1_AD,'')=nullif(Y.P_BUSN_LINE1_AD,'')
 and nullif(x.P_BUSN_CITY_NAM,'')=nullif(Y.P_BUSN_CITY_NAM,'')
where x.ownerpartyid is null

update x
set x.ownerpartyid = y.partyid
 from tmp_orgOwner x
   inner join  @OrgTemp1 y
 on x.id= y.id
where x.ownerpartyid is null

 ---------------------------------------------
 --dba name is being loaded into designation for org owner, which is wrong.loading null
Insert INto [Kyp].[PDM_Owner](PartyID,ProviderID,Designation,DateCreated,IsDeleted)
select ownerpartyid, provId,null,GETDATE(),0 as deleted from tmp_orgOwner where ownerid is null


----Change-------------made for org owner on 18/5/18--need to test
Insert INTO [Kyp].[PDM_Owner](PartyID,ProviderID,Designation,DateCreated,IsDeleted)
select A.ownerpartyid, A.provId,null,GETDATE(),0 as deleted from tmp_orgOwner A join(
select ownerpartyid, provId from tmp_orgOwner
except
select partyid, providerID from kyp.pdm_Owner
)B on A.ownerpartyid=B.ownerpartyid and A.provId=B.provId
----Change-------------made for org owner on 18/5/18--need to test

update x
set  x.OwnerId = y.OwnerID
from tmp_orgOwner x
inner join kyp.PDM_Owner y
on x.ownerpartyid = y.PartyID
where x.OwnerId is null


--**************************************************************************
-------------------------ORG Owners Address---------------------------
----------------Added on 4thSep2018 ---missing address load part for owners

----Added on 3thSep2018		
-----Update modified date of address   
Update C set DateModified=getdate(),
Inactive=1,
ISdeleted=0,
C.AddressLine2=(Case when nullif(ISNULL(x.P_BUSN_LINE2_AD,''),'') is not null then x.P_BUSN_LINE2_AD else C.AddressLine2 end)  --added on 6Sep2018 to consider AddressLine2 as well for update
from tmp_Orgowner x
join KYP.PDM_Location A 
	on X.OwnerPartyID = A.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0
	and nullif(x.P_BUSN_LINE1_AD,'') is not null
	and (LTRIM(RTRIM(ISNULL(c.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(c.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(c.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ZIP5_CD,'')))) and
	(LTRIM(RTRIM(ISNULL(c.ZipPlus4,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ZIP4_CD,''))))


declare @IndOrgAddress table (addressId INT , partyid int)

MERGE [KYP].[PDM_Address]  trgt
USING 
( 	
select distinct x.*,y.AddressID from (
select OwnerPartyID,P_BUSN_LINE1_AD,	
P_BUSN_LINE2_AD,	
P_BUSN_CITY_NAM, 
P_BUSN_ST_CD, 
P_BUSN_ZIP5_CD,
P_BUSN_ZIP4_CD
from dbo.tmp_Orgowner where P_BUSN_LINE1_AD is not null 
group by OwnerPartyID,P_BUSN_LINE1_AD,P_BUSN_LINE2_AD,P_BUSN_CITY_NAM,P_BUSN_ST_CD,P_BUSN_ZIP5_CD,P_BUSN_ZIP4_CD)  x
	left join 
	(select D.PartyID,C.* --,A.LegalName,A.DBAName1
	from --KYP.PDM_Organization A inner join 
	KYP.PDM_Location A 
	--on A.PartyID = B.PartyID 
	inner join KYP.PDM_Address C  
	on A.AddressID = C.AddressID 
	inner join kyp.PDM_Party d
	on d.PartyID=A.PartyID 
	where ISNULL(D.CurrentModule,0) = 2 AND ISNULL(A.IsDeleted,0) = 0 	and ISNULL(C.IsDeleted,0) = 0)y
	on x.OwnerPartyID = y.PartyID
	and (LTRIM(RTRIM(ISNULL(y.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_LINE1_AD,''))))AND 
	(LTRIM(RTRIM(ISNULL(y.City,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_CITY_NAM,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.State,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ST_CD,'')))) AND 
	(LTRIM(RTRIM(ISNULL(y.Zip,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ZIP5_CD,'')))) and
	(LTRIM(RTRIM(ISNULL(y.ZipPlus4,'')))) = (LTRIM(RTRIM(ISNULL(x.P_BUSN_ZIP4_CD,''))))
	--AND																----Commented on 3rdSep2018, we already found Party just need to be check address for party
	--((LTRIM(RTRIM(ISNULL(y.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(x.P_DBA_NAM,'')))) OR 
	--(LTRIM(RTRIM(ISNULL(y.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(x.P_NAM,'')))))
	where --x.ProviderType='Organization' and       ---Commented on 3rdSep2018 in order to accomodate both person and Org parties in single query
	y.PartyID is null and Y.addressId is null)src
ON (trgt.addressid=src.addressId)
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,DateCreated
		,[InActive]
           ,[IsDeleted]
		)
 VALUES (src.P_BUSN_LINE1_AD,
		 src.P_BUSN_LINE2_AD,
		src.P_BUSN_CITY_NAM,
		src.P_BUSN_ST_CD
		, src.P_BUSN_ZIP5_CD
		, src.P_BUSN_ZIP4_CD
		,getdate(),1,0)
output inserted.AddressId,src.OwnerPartyID
 into @IndOrgAddress;


-----Monitoring we don't require this dashboard trigger 
 EXEC('DISABLE TRIGGER all ON kyp.pdm_location');
 

--select distinct A.* from testVBS A join kyp.pdm_Party b on A.PartyID=B.PartyID
 INSERT INTO KYp.PDM_Location(AddressID,PartyID,DateCreated,[InActive]
           ,[IsDeleted])
 select distinct A.AddressId,A.PartyId, GETDATE(),1,0 from @IndOrgAddress A 
 left join kyp.PDM_Location B
 on A.AddressID=B.AddressID
 left join kyp.PDM_Party C
 on A.PartyID=C.PartyID and c.CurrentModule = 2 and isnull(c.IsDeleted,'0')=0
 where B.AddressId is null and C.PartyID is not null

 EXEC('enable TRIGGER all ON kyp.pdm_location');

		
	
--*****************************************************************************************************************





-------------------------------------------------
---Optimized delete statement on 30Aug2018
-------------------------------------------------
--delete from kyp.PDM_Person where 
--PartyID in 
--(select distinct PartyID from kyp.PDM_Owner where ProviderID is null and partyid in
--(select partyid from kyp.pdm_party where currentmodule=2))

delete B from kyp.pdm_party A 
join kyp.PDM_person B on A.PartyID=B.PartyID
join kyp.PDM_Owner C on A.PartyID=C.PartyID
where A.CurrentModule=2 and C.ProviderID is null


--delete from kyp.PDM_Organization where 
--PartyID  in (select distinct PartyID 
--from kyp.PDM_Owner where ProviderID is null 
--and partyid in(select partyid from kyp.pdm_party where currentmodule=2))

delete B from kyp.pdm_party A 
join kyp.PDM_Organization B on A.PartyID=B.PartyID
join kyp.PDM_Owner C on A.PartyID=C.PartyID
where A.CurrentModule=2 and C.ProviderID is null

--delete from kyp.PDM_Owner where ProviderID is null and partyid 
--in(select partyid from kyp.pdm_party where currentmodule=2)

delete C from kyp.pdm_party A 
join kyp.PDM_Owner C on A.PartyID=C.PartyID
where A.CurrentModule=2 and C.ProviderID is null

----Not working properly------ 
--delete  from  kyp.PDM_Person where PartyID not in 
--(select distinct PartyID from KYP.PDM_Owner)
--and PartyID not in(select distinct PartyID from KYP.PDM_Provider) 
--and partyid in(select partyid from kyp.pdm_party where currentmodule=2)

delete B from kyp.pdm_party A 
join kyp.PDM_Person B on A.PartyID=B.PartyID
left join kyp.PDM_Owner C on A.PartyID=C.PartyID
left join kyp.PDM_Provider D on A.PartyID=D.PartyID
where A.CurrentModule=2 and C.PartyID is null and D.PartyID is null

----Not working properly------ 
--delete  from  kyp.PDM_Organization where PartyID not in (select distinct PartyID from KYP.PDM_Owner)
--and PartyID not in(select distinct PartyID from KYP.PDM_Provider) and partyid in(select partyid from kyp.pdm_party where currentmodule=2)

delete B from kyp.pdm_party A 
join kyp.PDM_Organization B on A.PartyID=B.PartyID
left join kyp.PDM_Owner C on A.PartyID=C.PartyID
left join kyp.PDM_Provider D on A.PartyID=D.PartyID
where A.CurrentModule=2 and C.PartyID is null and D.PartyID is null

----Not working properly------ 
--delete from kyp.PDM_Party where PartyID not in (select distinct PartyID from KYP.PDM_Owner)
--and PartyID not in(select distinct PartyID from KYP.PDM_Provider) and CurrentModule=2

delete A from kyp.pdm_party A  
left join kyp.PDM_Owner C on A.PartyID=C.PartyID
left join kyp.PDM_Provider D on A.PartyID=D.PartyID
left join kyp.mdm_alert E on A.PartyID=E.WatchedPartyid
where A.CurrentModule=2 and C.PartyID is null and D.PartyID is null and e.WatchedPartyid is null


----Added on 30Aug2018 late night
--2799 records deleted
delete C from kyp.PDM_Owner C
where C.ProviderID is null or c.partyID is null

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

Update KYP.Pdm_Person set ssn=null where ssn in('0','')
Update KYP.Pdm_Person set  taxid= null where taxid in('0','')
Update KYP.Pdm_Person set  NPI= null where NPI in('0','')
Update KYP.Pdm_Person set  LastName= null where LastName in('')
Update KYP.Pdm_Person set  FirstName= null where FirstName in('')

Update KYP.Pdm_Organization set tin=null where tin in('0','')
Update KYP.Pdm_Organization set SSN=null where SSN in('0','')
Update KYP.Pdm_Organization set NPI=null where NPI in('0','')
Update KYP.Pdm_Organization set DBAName1=null where DBAName1 in('')
Update KYP.Pdm_Organization set LegalName=null where LegalName in('')

update kyp.PDM_License 
set LicenseCode = NULL
where SUBSTRING(LicenseCode, PATINDEX('%[^0]%', LicenseCode+'.'), LEN(LicenseCode))=''

update kyp.PDM_License 
set LicenseCode = NULL
where LicenseCode like '%999999999%'

update x
set x.npi= y.npi
from kyp.PDM_Person x
inner join kyp.PDM_Provider y
on x.PartyID = y.PartyID
inner join kyp.pdm_party p
on x.partyid = p.partyid
where y.NPI is not null and  y.Category='Physician' and x.NPI is null and p.currentmodule=2

update x
set x.npi= y.npi
from kyp.PDM_Organization x
inner join kyp.PDM_Provider y
on x.PartyID = y.PartyID
inner join kyp.pdm_party p
on x.partyid = p.partyid
where y.NPI is not null and  y.Category='Institutional' and x.NPI is null and p.currentmodule=2


delete from KYP.PDM_Location where AddressID 
in
(select addressid from KYP.PDM_Address where coalesce(AddressLine1,'') = '' and coalesce(AddressLine2,'')='' and coalesce(City,'') ='' and coalesce([State],'')=''  and coalesce(Zip,'')='' and coalesce(ZipPlus4,'')='')

delete from  KYP.PDM_Address where coalesce(AddressLine1,'') = '' and coalesce(AddressLine2,'')='' and coalesce(City,'') ='' and coalesce([State],'')=''  and coalesce(Zip,'')='' and coalesce(ZipPlus4,'')=''


delete x from (select PartyID,Speciality_Code, ROW_NUMBER()over(partition by PartyID,Speciality_Code order by SpecialityID)as row
 from kyp.PDM_Speciality)x
 where x.row>1


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndParty1]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndParty1]
END
create table [tmp_IndParty1] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndParty1]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+ coalesce(p.FirstName,'')+coalesce(p.MiddleName,'')
+coalesce(p.LastName,'')+coalesce(cast(p.SSN as varchar(10)),'')+coalesce(cast(p.DoB as varchar(10)),'')
+coalesce(cast(p.Phone1 as varchar(15)),'')+coalesce(cast(p.Phone2 as varchar(15)),'')+coalesce(cast(p.TaxId as varchar(10)),'')+ coalesce(cast(p.NPI as varchar(12)),'')
+coalesce(pr.DEA,'')+coalesce(pr.CLIA,'')+coalesce(pr.NABP_Num,'')+coalesce(pr.Type,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join (select partyid,max(Dea)Dea,Max(Clia)Clia,Max(NABP_Num)NABP_Num,
Max(Type)[Type] from kyp.PDM_Provider group by  PartyID)pr
on p.PartyID= pr.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndParty2]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndParty2]
END
create table [tmp_IndParty2] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndParty2]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(a.AddressLine1,'')+coalesce(a.AddressLine2,'')+coalesce(a.City,'')
+coalesce(a.State,'')+coalesce(a.Zip,'')+coalesce(a.ZipPlus4,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_Location lo
on p.PartyID=lo.PartyID
inner join kyp.PDM_Address a
on lo.AddressID=a.AddressID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndParty3]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndParty3]
END
create table [tmp_IndParty3] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndParty3]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(l.LicenseCode,'')+coalesce(l.LicenseState,'')+coalesce(l.LicenseType,'')
+coalesce(l.LicenseAuthority,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_License l
on p.PartyID= l.PartyID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndParty4]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndParty4]
END
create table [tmp_IndParty4] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndParty4]
select p.partyid,(coalesce(cast(p.partyid as varchar(10)),'')+coalesce(s.Speciality_Code,'')) as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.PDM_Speciality s
on p.PartyID = s.PartyID
where pa.CurrentModule=2



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_IndParty5]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_IndParty5]
END
create table [tmp_IndParty5] (partyid int, uniqueKey varchar(max))

insert into [tmp_IndParty5]
select p.partyid,coalesce(cast(p.partyid as varchar(10)),'')+coalesce(t.Taxonomy,'') as uniqueKey
from kyp.PDM_Person p
inner join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left join kyp.pdm_taxonomy t
on p.PartyID= t.partyid
where pa.CurrentModule=2



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgParty1]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgParty1]
END

create table tmp_OrgParty1 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgParty1
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+ coalesce(p.legalname,'')+coalesce(p.dbaname1,'')
+coalesce(cast(p.SSN as varchar(10)),'')+coalesce(cast(p.Phone1 as varchar(15)),'')+coalesce(cast(p.Phone2 as varchar(15)),'')
+coalesce(cast(p.TIN as varchar(10)),'')+ coalesce(cast(p.NPI as varchar(12)),'')
+coalesce(pr.DEA,'')+coalesce(pr.CLIA,'')+coalesce(pr.NABP_Num,'')+coalesce(pr.Type,'')) as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join (select partyid,max(Dea)Dea,Max(Clia)Clia,Max(NABP_Num)NABP_Num,
Max(Type)[Type] from kyp.PDM_Provider group by  PartyID)pr
on p.PartyID= pr.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgParty2]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgParty2]
END
create table tmp_OrgParty2 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgParty2
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+
coalesce(a.AddressLine1,'')+coalesce(a.AddressLine2,'')+coalesce(a.City,'')+
coalesce(a.State,'')+coalesce(a.Zip,'')+coalesce(a.ZipPlus4,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_Location lo
on p.PartyID=lo.PartyID
inner hash join kyp.PDM_Address a
on lo.AddressID=a.AddressID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgParty3]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgParty3]
END
create table tmp_OrgParty3 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgParty3
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(l.LicenseCode,'')
+coalesce(l.LicenseState,'')+coalesce(l.LicenseType,'')+coalesce(l.LicenseAuthority,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_License l
on p.PartyID= l.PartyID
where pa.CurrentModule=2


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgParty4]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgParty4]
END
create table tmp_OrgParty4 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgParty4
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(s.Speciality_Code,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.PDM_Speciality s
on p.PartyID = s.PartyID
where pa.CurrentModule=2

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[tmp_OrgParty5]') AND type in (N'U'))
BEGIN
DROP TABLE [dbo].[tmp_OrgParty5]
END
create table tmp_OrgParty5 (partyid int, uniqueKey varchar(max))

insert into tmp_OrgParty5
select p.partyid, (coalesce(cast(p.partyid as varchar(10)),'')+coalesce(t.Taxonomy,''))as uniqueKey
from kyp.PDM_Organization p
inner hash join kyp.PDM_Party pa
on p.PartyID= pa.PartyID
left hash join kyp.pdm_taxonomy t
on p.PartyID= t.partyid
where pa.CurrentModule=2


select x.partyid  into #partiestoUpdate from 
tmp_IndPartyExisting1 x
left join tmp_IndParty1 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_IndPartyExisting2 x
left join tmp_IndParty2 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_IndPartyExisting3 x
left join tmp_IndParty3 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_IndPartyExisting4 x
left join tmp_IndParty4 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_IndPartyExisting5 x
left join tmp_IndParty5 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_OrgPartyExisting1 x
left join tmp_OrgParty1 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_OrgPartyExisting2 x
left join tmp_OrgParty2 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_OrgPartyExisting3 x
left join tmp_OrgParty3 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_OrgPartyExisting4 x
left join tmp_OrgParty4 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null
union
select x.partyid from 
tmp_OrgPartyExisting5 x
left join tmp_OrgParty5 y
on x.uniqueKey= y.uniqueKey
where y.uniqueKey is null

DECLARE @YearNo INT
		,@MonthNo INT
		,@ProvidersReceived INT

	SELECT @YearNo = datepart(year, GETDATE())
		,@MonthNo = datepart(month, getdate())

	SELECT @ProvidersReceived = count(DISTINCT Pvd.Mon_MedicaidID)
	FROM KYP.PDM_Party Prty
	INNER JOIN KYP.PDM_Provider Pvd ON Prty.PartyID = Pvd.PartyID
		AND ISNULL(Prty.IsDeleted, 0) = 0
		AND ISNULL(Pvd.IsDeleted, 0) = 0
		AND Prty.IsProvider = 1
		AND Prty.CurrentModule = 2

	IF NOT EXISTS (
			SELECT 1
			FROM KYP.MDM_MonthlyActiveProvider
			WHERE Year = @YearNo
				AND Month = @MonthNo
			)
	BEGIN
		INSERT INTO KYP.MDM_MonthlyActiveProvider
		VALUES (
			@MonthNo
			,@YearNo
			,@ProvidersReceived
			,@currentDate
			)
	END
	ELSE
	BEGIN
		DELETE
		FROM KYP.MDM_MonthlyActiveProvider
		WHERE Year = @YearNo
			AND Month = @MonthNo

		INSERT INTO KYP.MDM_MonthlyActiveProvider
		VALUES (
			@MonthNo
			,@YearNo
			,@ProvidersReceived
			,@currentDate
			)
	END
	
update kyp.PDM_Party set PartyDataModifiedDate=GETDATE() where PartyID in(select partyid from #partiestoUpdate)


-----Added on 28Sep2018 for additional column
IF EXISTS(SELECT 1 FROM sys.objects
          WHERE Name = N'ProviderNameAddress_History'
          )
BEGIN

IF not EXISTS(SELECT 1 FROM sys.columns A join sys.objects B on A.Object_ID=B.Object_ID
          WHERE A.Name = N'IndNPIDeactivatedOrgCase' and B.Name='ProviderNameAddress_History'
          )
    exec('Alter table dbo.ProviderNameAddress_History add IndNPIDeactivatedOrgCase varchar(1) null')

END

-------History table creation and management
--We are always ceating History table with select into to increase performance and retaining earlier historical data as well with latest load
IF OBJECT_ID(N'dbo.ProviderNameAddress_History', N'U') IS not NULL
BEGIN
select * into ProviderNameAddress_History_Temp
from ProviderNameAddress_History

drop table ProviderNameAddress_History

select  FileType,	LoadType,	LoadId,	LastLoadDate,	P_APPL_NUM,	P_ID,	P_NPI_NUM,	P_DEA_NUM,	P_TY_CD,	
P_PRACT_TY_CD,	P_DOB_DT,	P_FED_TAX_ID,	P_SSN_NUM,	P_LAST_NAM,	P_FST_NAM,	P_MI_NAM,	P_SFX_NAM,	P_NAM,	
P_DBA_LAST_NAM,	P_DBA_FST_NAM,	P_DBA_MI_NAM,	P_DBA_SFX_NAM,	P_DBA_NAM,	P_LINE1_AD,	P_LINE2_AD,	P_CITY_NAM,	
P_ST_CD,	P_ZIP5_CD,	P_ZIP4_CD,	P_NABP_NUM,	DH_NAME_OF_FAC_ADMIN,	P_LINE1_AD2,	P_LINE2_AD2,	
P_CITY_NAM2,	P_ST_CD2,	P_ZIP5_CD2,	P_ZIP4_CD2,	P_LINE1_AD3,	P_LINE2_AD3,	P_CITY_NAM3,	
P_ST_CD3,	P_ZIP5_CD3,	P_ZIP4_CD3,	DH_ENROL_STAT_CD_1,	DH_OWNER_NUM,	DH_SERV_LOC_NUM,	
DH_PROV_TELE_NO,	ProviderType,	CLIA,	PrimarySpeciality,	FullName,	DBAFullName,	
PartyId,	ProvId,	FileSource,	STAT_EFF_DT,	NMP_END_DT,	id,	AccountID,	AccountType 
,IndNPIDeactivatedOrgCase,cast(getdate() as date) LoadDate into [ProviderNameAddress_History]
from tmp_ProviderNameAddress where FileType='M'
union all
select FileType,	LoadType,	LoadId,	LastLoadDate,	P_APPL_NUM,	P_ID,	P_NPI_NUM,	P_DEA_NUM,	P_TY_CD,	
P_PRACT_TY_CD,	P_DOB_DT,	P_FED_TAX_ID,	P_SSN_NUM,	P_LAST_NAM,	P_FST_NAM,	P_MI_NAM,	P_SFX_NAM,	P_NAM,	
P_DBA_LAST_NAM,	P_DBA_FST_NAM,	P_DBA_MI_NAM,	P_DBA_SFX_NAM,	P_DBA_NAM,	P_LINE1_AD,	P_LINE2_AD,	P_CITY_NAM,	
P_ST_CD,	P_ZIP5_CD,	P_ZIP4_CD,	P_NABP_NUM,	DH_NAME_OF_FAC_ADMIN,	P_LINE1_AD2,	P_LINE2_AD2,	
P_CITY_NAM2,	P_ST_CD2,	P_ZIP5_CD2,	P_ZIP4_CD2,	P_LINE1_AD3,	P_LINE2_AD3,	P_CITY_NAM3,	
P_ST_CD3,	P_ZIP5_CD3,	P_ZIP4_CD3,	DH_ENROL_STAT_CD_1,	DH_OWNER_NUM,	DH_SERV_LOC_NUM,	
DH_PROV_TELE_NO,	ProviderType,	CLIA,	PrimarySpeciality,	FullName,	DBAFullName,	
PartyId,	ProvId,	FileSource,	STAT_EFF_DT,	NMP_END_DT,	id,	AccountID,	AccountType 
,IndNPIDeactivatedOrgCase,LoadDate from ProviderNameAddress_History_Temp

drop table ProviderNameAddress_History_Temp
end

---storing only monitoring providers so check file type 'M'
IF OBJECT_ID(N'dbo.ProviderNameAddress_History', N'U') IS NULL
BEGIN
select *,cast(getdate() as date) LoadDate into [ProviderNameAddress_History] 
from tmp_ProviderNameAddress where FileType='M'
end

---If history table exists then store data in temp tbl,drop history table and then create history tabl with old and new data both
IF OBJECT_ID(N'dbo.ProviderOwner_history', N'U') IS not NULL
BEGIN
select * into ProviderOwner_history_Temp 
from ProviderOwner_history

drop table ProviderOwner_history

select distinct 'IND' OwnerType,OwnerPartyID,A.partyID,cast(Getdate() as date) LoadDate into ProviderOwner_history 
from tmp_indOwners A left join tmp_Providernameaddress B on 
A.P_ID=B.P_ID where B.FileType='M'
union all
select distinct 'ORG',OwnerPartyID,A.partyID,cast(Getdate() as date) from tmp_ORGOwner A left join tmp_Providernameaddress B on 
A.P_ID=B.P_ID where B.FileType='M'
union all
select * from ProviderOwner_history_Temp

drop table ProviderOwner_history_Temp
end

---storing only monitoring providers so check file type 'M'
IF OBJECT_ID(N'dbo.ProviderOwner_history', N'U') IS NULL
BEGIN
select distinct 'IND' OwnerType,OwnerPartyID,A.partyID,cast(Getdate() as date) LoadDate into ProviderOwner_history 
from tmp_indOwners A left join tmp_Providernameaddress B on 
A.P_ID=B.P_ID where B.FileType='M'
union all
select distinct 'ORG',OwnerPartyID,A.partyID,cast(Getdate() as date) from tmp_ORGOwner A left join tmp_Providernameaddress B on 
A.P_ID=B.P_ID where B.FileType='M'
end


---Added on 28Sep2018 for capturing billing counts
IF OBJECT_ID(N'dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract', N'U') IS not NULL
BEGIN
	select * into dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract_temp from dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract

	drop table dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract

	Declare @IndOwnerF int
	Declare @ORGOwnerF int
	Declare @IndOwnerM int
	Declare @ORGOwnerM int
	--Declare @ProvParty int
	--Declare @TotalParty int

	select @IndOwnerF=count(distinct MOCAPartyStatus) from dbo.Monitoring_ProviderIndOwner  
	select @ORGOwnerF=count(distinct MOCAPartyStatus) from dbo.Monitoring_ProviderOrgOwner  
	select @IndOwnerM=count(distinct EnrollmentMOCAPartyID) from dbo.tmp_indOwners  
	select @ORGOwnerM=count(distinct EnrollmentMOCAPartyID) from dbo.tmp_ORGOwner  
	--select @ProvParty=count(distinct PartyID) from tmp_Providernameaddress

	--set @TotalParty=@ProvParty+@ORGOwner+@IndOwner


	select 'FULL' TotalEnrolledCounts,
	Count(case when P_SupUpdate_Flag not in('NMP','ORP') then 1 end)Main_Inc_MAIN_CO_SG_MG,
	Count(case when P_SupUpdate_Flag='NMP' then 1 end)NMP_F,
	Count(case when P_SupUpdate_Flag='ORP' then 1 end)ORP_F,
	Count(case when P_SupUpdate_Flag='CO' then 1 end)CrossOver_Excluded_F,
	Count(case when P_SupUpdate_Flag='SG' then 1 end)SubGroup_Excluded_F,
	Count(case when P_SupUpdate_Flag='MG' then 1 end)MixedGroup_F,
	@IndOwnerF IndEnrolledOwner,
	@ORGOwnerF OrgEnrolledOwner,
	@IndOwnerF+@ORGOwnerF TotalEnrolledMOCA,
	'MON' TotalMonitoredCounts,
	Count(case when P_SupUpdate_Flag in('Main','MG') then 1 end)Main_Inc_MG,
	Count(case when P_SupUpdate_Flag='NMP' then 1 end)NMP,
	Count(case when P_SupUpdate_Flag='ORP' then 1 end)ORP,
	'0' CrossOver_Excluded,
	'0' SubGroup_Excluded,
	Count(case when P_SupUpdate_Flag='MG' then 1 end)MixedGroup,
	@IndOwnerM IndMonitoredOwner,
	@ORGOwnerM OrgMonitoredOwner,
	@IndOwnerM+@ORGOwnerM TotalMonitoredMOCA,
	Getdate() LoadDate 
	into dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract
	from dbo.Monitoring_ProviderNameAddress
	union
	select TotalEnrolledCounts,Main_Inc_MAIN_CO_SG_MG,NMP_F,ORP_F,CrossOver_Excluded_F,SubGroup_Excluded_F,
	MixedGroup_F,IndEnrolledOwner,OrgEnrolledOwner,TotalEnrolledMOCA,TotalMonitoredCounts,Main_Inc_MG,
	NMP,ORP,CrossOver_Excluded,SubGroup_Excluded,MixedGroup,IndMonitoredOwner,OrgMonitoredOwner,
	TotalMonitoredMOCA,LoadDate from CA_MON_Billing_Variable_Counts_EnrollmentExtract_temp
	order by LoadDate

	drop table CA_MON_Billing_Variable_Counts_EnrollmentExtract_temp
end


IF OBJECT_ID(N'dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract', N'U') IS NULL
BEGIN

	Declare @IOF int
	Declare @OOF int
	Declare @IOM int
	Declare @OOM int
	--Declare @ProvParty int
	--Declare @TotalParty int

	select @IOF=count(distinct MOCAPartyStatus) from dbo.Monitoring_ProviderIndOwner  
	select @OOF=count(distinct MOCAPartyStatus) from dbo.Monitoring_ProviderOrgOwner  
	select @IOM=count(distinct EnrollmentMOCAPartyID) from dbo.tmp_indOwners  
	select @OOM=count(distinct EnrollmentMOCAPartyID) from dbo.tmp_ORGOwner  

	select 'FULL' TotalEnrolledCounts,
	Count(case when P_SupUpdate_Flag not in('NMP','ORP') then 1 end)Main_Inc_MAIN_CO_SG_MG,
	Count(case when P_SupUpdate_Flag='NMP' then 1 end)NMP_F,
	Count(case when P_SupUpdate_Flag='ORP' then 1 end)ORP_F,
	Count(case when P_SupUpdate_Flag='CO' then 1 end)CrossOver_Excluded_F,
	Count(case when P_SupUpdate_Flag='SG' then 1 end)SubGroup_Excluded_F,
	Count(case when P_SupUpdate_Flag='MG' then 1 end)MixedGroup_F,
	@IOF IndEnrolledOwner,
	@OOF OrgEnrolledOwner,
	@IOF+@OOF TotalEnrolledMOCA,
	'MON' TotalMonitoredCounts,
	Count(case when P_SupUpdate_Flag in('Main','MG') then 1 end)Main_Inc_MG,
	Count(case when P_SupUpdate_Flag='NMP' then 1 end)NMP,
	Count(case when P_SupUpdate_Flag='ORP' then 1 end)ORP,
	'0' CrossOver_Excluded,
	'0' SubGroup_Excluded,
	Count(case when P_SupUpdate_Flag='MG' then 1 end)MixedGroup,
	@IOM IndMonitoredOwner,
	@OOM OrgMonitoredOwner,
	@IOM+@OOM TotalMonitoredMOCA,
	Getdate() LoadDate
	into dbo.CA_MON_Billing_Variable_Counts_EnrollmentExtract
	from dbo.Monitoring_ProviderNameAddress
	
End		


commit tran ProcessProvider
end try	
begin catch
	if @@TRANCOUNT > 0
	begin	
	rollback tran ProcessProvider			
	INSERT INTO [dbo].[Monitoring_ErroredProvidersForTheDay]
           ([ERNumber]
           ,[Error_Severity]
           ,[Error_State]
           ,[Error_Procedure]
           ,[Error_Line]
           ,[Error_Message])
	
	select 
	
	B.ERNumber
	,B.Error_Severity
	,B.Error_State
	,B.Error_Procedure
	,B.Error_Line
	,B.Error_Message
	from	 
	(
	SELECT
	ERROR_NUMBER() ERNumber
    ,ERROR_SEVERITY() Error_Severity
    ,ERROR_STATE() Error_State
    ,ERROR_PROCEDURE() Error_Procedure
    ,ERROR_LINE() Error_Line
    ,ERROR_MESSAGE() Error_Message
	) B
	

	end
end catch
END


GO

