

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Subcon]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   --@type VARCHAR (50),
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_adr           INT,
      @new_party_adr       INT,
      @count_association   INT,
      @main_party_id       INT,
      @is_prepopulated     BIT,
      @target_path         VARCHAR (200),
      @full_name_person    VARCHAR (100),
      @type                VARCHAR (50),
      @org_id              INT,
      @legal_name          VARCHAR (100),
      @person_id           INT;
   PRINT '[sp_Copy_Party_Loc_Addr]';

   --new account
   IF @app_party_row_id IS NULL
      BEGIN
         --Call to procedure [KYPEnrollment].[sp_Copy_ProviderQuestionnarie] por store the values of radio button
         EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarie] @new_party_id,
                                                              @party_id

         DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200),
                           Type             VARCHAR (50)
                        )

         CREATE TABLE #childsub
         (
            pk               INT IDENTITY (1, 1),
            PartyID          INT,
            Type             VARCHAR (50),
            targetpath       VARCHAR (200),
            isprepopulated   BIT
         )

         INSERT INTO @party
            SELECT PartyID,
                   IsPrepopulated,
                   TargetPath,
                   type
             FROM [KYPPORTAL].[PortalKYP].pPDM_Party
             WHERE     type LIKE 'Subcontractor%'
                   AND (IsDeleted = 0 OR IsDeleted = NULL)
                   AND ParentPartyID = @party_id
            ORDER BY partyid DESC

         DECLARE
            @cont   INT,
            @tot    INT
         SELECT @tot = MAX (pk) FROM @party
         SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
            SELECT @party_adr = PartyID,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath,
                   @type = type
            FROM @party
            WHERE pk = @cont

            --1
            IF (@type = 'SubcontractorIndividual')
               BEGIN
                  /*SELECT @count_association = COUNT(OwnerRelationID)
                  FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                  WHERE PartyIDOwned = @party_adr AND (TypeAssociation = 'SubcontractorEntityAssociation' OR TypeAssociation = 'SubcontractorIndividualAssociation')
                  and isdeleted=0 ;*/

                  --IF @count_association = 0
                  --BEGIN
                  EXEC @new_party_adr =
                          [KYPEnrollment].[sp_Copy_Party] @party_adr,
                                                          @new_party_id,
                                                          @account_id,
                                                          @last_action_user_id;
                  EXEC @person_id =
                          [KYPEnrollment].[sp_Copy_Person] @new_party_adr,
                                                           @party_adr,
                                                           @last_action_user_id,
                                                           'C';
                  EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
                                                         @party_adr,
                                                         NULL,
                                                         @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr,
                                                                     @new_party_adr,
                                                                     @last_action_user_id;

                  --mvc--
                  print 'a1'
                  print @party_adr
                  print @type
                  print @new_party_adr
                  --IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME like '#subcontractors%')
				  IF OBJECT_ID('tempdb..#subcontractors') IS NOT NULL
                  BEGIN
                  print 'a11'
                  INSERT
                    INTO #subcontractors (PartyID_Portal,
                                          Type_sub,
                                          PartyID_Enroll)
                  VALUES (@party_adr, @type, @new_party_adr)
                  print 'a111'
				  END
                  --

                  IF (@type = 'SubcontractorIndividual')
                     BEGIN
                        EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_adr,
                                                                  @party_adr,
                                                                  @last_action_user_id,
                                                                  NULL,
                                                                  NULL;
                     END

                  IF (@type = 'SubcontractorIndividual' AND @is_group = 1)
                     BEGIN
                        IF (@is_prepopulated IS NULL OR @is_prepopulated = 0)
                           BEGIN
                              SELECT @full_name_person =
                                        [FirstName] + ' ' + [LastName]
                                FROM KYPEnrollment.pAccount_PDM_Person
                               WHERE PersonID = @person_id;
                              --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Individual',@full_name_person, @new_party_id;
                              EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_adr,
                                                                            @new_party_adr,
                                                                            @account_id,
                                                                            @type,
                                                                            @party_adr;
                           END
                        ELSE
                           BEGIN
                              SELECT TOP 1
                                     @main_party_id = Item
                                FROM [KYPEnrollment].[SplitString] (
                                        @target_path,
                                        '|')
                              ORDER BY item;
                              SELECT TOP 1
                                     @main_party_id = MainPartyID
                              FROM [KYPEnrollment].[pAccount_Party_Associate]
                              WHERE PartyID = @main_party_id;
                              EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                            @new_party_adr,
                                                                            @account_id,
                                                                            @type,
                                                                            @party_adr;
                           END
                     END
               --END
               END
            --1
            ELSE
               BEGIN
                  IF (@type = 'SubcontractorEntity')
                     BEGIN
                        /*if NOT EXISTS(SELECT OwnerRelationID
                       FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                       WHERE PartyIDOwned = @party_adr AND (TypeAssociation = 'SubcontractorEntityAssociation' OR TypeAssociation = 'SubcontractorIndividualAssociation'))*/

                        --BEGIN
                        EXEC @new_party_adr =
                                [KYPEnrollment].[sp_Copy_Party] @party_adr,
                                                                @new_party_id,
                                                                @account_id,
                                                                @last_action_user_id;
                        EXEC
                            @org_id =
                               [KYPEnrollment].[sp_Copy_Organization] @new_party_adr,
                                                                      @party_adr,
                                                                      @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
                                                               @party_adr,
                                                               NULL,
                                                               @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr,
                                                                           @new_party_adr,
                                                                           @last_action_user_id;

                        --mvc--
                        print 'a2'
                        --IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME like '#subcontractors%')
                        IF OBJECT_ID('tempdb..#subcontractors') IS NOT NULL
                        BEGIN
                        INSERT
                          INTO #subcontractors (PartyID_Portal,
                                                Type_sub,
                                                PartyID_Enroll)
                        VALUES (@party_adr, @type, @new_party_adr)
						END
                        --

                        IF (@type = 'SubcontractorEntity')
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_adr,
                                                                        @party_adr,
                                                                        @last_action_user_id,
                                                                        NULL,
                                                                        NULL;
                           END


                        IF (@type = 'SubcontractorEntity' AND @is_group = 1)
                           BEGIN
                              IF (   @is_prepopulated IS NULL
                                  OR @is_prepopulated = 0)
                                 BEGIN
                                    SELECT @legal_name = LegalName
                                      FROM KYPEnrollment.pAccount_PDM_Organization
                                     WHERE OrgID = @org_id
                                    --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Entity',@legal_name, @new_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_adr,
                                                                                  @new_party_adr,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_adr;
                                 END
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @main_party_id = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @target_path,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @main_party_id = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @main_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                                  @new_party_adr,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_adr;
                                 END
                           END
                     --END

                     END
               END

            --**
            --subcontractor father was created
            --if it has children
            --party.type
            --SubcontractorOwnerEntity
            --subcontractorOwnerIndividual


            IF EXISTS
                  (SELECT PartyID
                     FROM [KYPPORTAL].[PortalKYP].pPDM_Party
                    WHERE     type LIKE 'SubcontractorOwner%'
                          AND (IsDeleted = 0 OR IsDeleted = NULL)
                          AND ParentPartyID = @party_adr)
               BEGIN
                  --declare @childsub table (pk int identity(1,1),PartyID int, Type varchar(50))

                  INSERT INTO #childsub
                     SELECT PartyID,
                            Type,
                            TargetPath,
                            IsPrepopulated
                       FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                      WHERE     ParentPartyID = @party_adr
                            AND (   Type = 'SubcontractorOwnerEntity'
                                 OR Type = 'subcontractorOwnerIndividual')
                            AND (IsDeleted = 0 OR IsDeleted = NULL);

                  DECLARE
                     @cont1   INT,
                     @tot1    INT
                  SELECT @tot1 = MAX (pk) FROM #childsub
                  SET @cont1 = 1
                  DECLARE @partychildsub_port   INT
                  DECLARE @partychildsub_enr   INT
                  DECLARE @partychildtype_port   VARCHAR (50)
                  DECLARE @mainparty_child   INT
                  DECLARE @targetpath_child   VARCHAR (200)
                  DECLARE @isprepopulated_child   BIT

                  WHILE @cont1 <= @tot1
                  BEGIN
                     SELECT @partychildsub_port = partyid,
                            @partychildtype_port = TYPE,
                            @targetpath_child = targetpath,
                            @isprepopulated_child = isprepopulated
                     FROM #childsub
                     WHERE pk = @cont1
                     EXEC @partychildsub_enr =
                             [KYPEnrollment].[sp_Copy_Party] @partychildsub_port,
                                                             @new_party_adr,
                                                             @account_id,
                                                             @last_action_user_id;

                     --mvc--
                     print 'a3'
                     --IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME like '#subcontractors%')
                     IF OBJECT_ID('tempdb..#subcontractors') IS NOT NULL
                     BEGIN
                     INSERT
                       INTO #subcontractors (PartyID_Portal,
                                             Type_sub,
                                             PartyID_Enroll)
                        VALUES (
                                  @partychildsub_port,
                                  @partychildtype_port,
                                  @partychildsub_enr)
					 END
                     --
                     IF @partychildtype_port = 'SubcontractorOwnerEntity'
                        BEGIN
                           EXEC [KYPEnrollment].[sp_Copy_Organization] @partychildsub_enr,
                                                                       @partychildsub_port,
                                                                       @last_action_user_id;
                        END
                     ELSE
                        BEGIN
                           EXEC [KYPEnrollment].[sp_Copy_Person] @partychildsub_enr,
                                                                 @partychildsub_port,
                                                                 @last_action_user_id,
                                                                 'C';
                        END

                     EXEC [KYPEnrollment].[sp_Copy_Address] @partychildsub_enr,
                                                            @partychildsub_port,
                                                            NULL,
                                                            @last_action_user_id;
                     EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @partychildsub_enr,
                                                               @partychildsub_port,
                                                               @last_action_user_id,
                                                               NULL,
                                                               NULL;

                     --create new party_associate for new child subcontractors

                     IF (@is_group = 1)
                        BEGIN
                           IF (   @isprepopulated_child IS NULL
                               OR @isprepopulated_child = 0)
                              EXEC [KYPEnrollment].[Create_Party_Associate] @partychildsub_enr,
                                                                            @partychildsub_enr,
                                                                            @account_id,
                                                                            @partychildtype_port,
                                                                            @partychildsub_port;
                           ELSE
                              BEGIN
                                 SELECT TOP 1
                                        @mainparty_child = Item
                                   FROM [KYPEnrollment].[SplitString] (
                                           @targetpath_child,
                                           '|')
                                 ORDER BY item;
                                 SELECT TOP 1
                                        @mainparty_child = MainPartyID
                                   FROM [KYPEnrollment].[pAccount_Party_Associate]
                                  WHERE PartyID = @mainparty_child;
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @mainparty_child,
                                                                               @partychildsub_enr,
                                                                               @account_id,
                                                                               @partychildtype_port,
                                                                               @partychildsub_port;
                              END
                        END

                     --
                     SET @cont1 = @cont1 + 1
                  END

                  TRUNCATE TABLE #childsub
               --delete from #childsub
               --DBCC CHECKIDENT (#childsub , RESEED, 0)
               END

            --**
            SET @cont = @cont + 1
         END
      --end while
      END

   DROP TABLE #childsub
   RETURN @new_party_adr
END


GO

