-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <08/11/2017>
-- Description:	<This procedure turns row into deleted mode on the currentrecordflag and isdeleted,deleted fields, the respective table and primary key>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[turn_delete_tables]
@table varchar(100),
@accPK varchar (50),
@pk	int
	
AS
BEGIN

DECLARE @tables_to_erase table (pk int identity(1,1),name varchar(100),type varchar(50) )
declare @tot_erase int,@cont_erase int,@add_erase int, @table_erase varchar (50), @type varchar (50), @temp varchar (200)

insert into @tables_to_erase (name,type)
select distinct t.name,c.name from sys.tables t INNER JOIN sys.columns c ON t.object_id=c.object_id INNER JOIN sys.schemas s ON t.schema_id=s.schema_id where (c.name = 'IsDeleted' or c.name = 'CurrentRecordFlag' or c.name = 'Deleted') and s.name='KYPEnrollment' and t.name in (@table)
order by t.name

select @tot_erase = MAX(pk) from  @tables_to_erase 
set @cont_erase = 1;

	WHILE @cont_erase<=@tot_erase
	BEGIN

		select @table_erase = name,@type = type from @tables_to_erase where pk = @cont_erase;
		IF @type ='CurrentRecordFlag'
		BEGIN
			--SET @temp = 'select CurrentRecordFlag from KYPEnrollment.' + @table_erase;
			SET @temp = 'update KYPEnrollment.' + @table_erase +' SET CurrentRecordFlag=0 where ' + @accPK + ' = ' + cast(@pk as varchar);
			--PRINT @temp
			EXEC (@temp)
		END			
		IF @type ='isDeleted'
		BEGIN
			--SET @temp = 'select isDeleted from KYPEnrollment.' + @table_erase;
			SET @temp = 'update KYPEnrollment.' + @table_erase +' SET IsDeleted=1 where ' + @accPK + ' = ' + cast(@pk as varchar);
			--PRINT @temp
			EXEC (@temp)
		END			

		IF @type ='Deleted'
		BEGIN
			--SET @temp = 'select isDeleted from KYPEnrollment.' + @table_erase;
			SET @temp = 'update KYPEnrollment.' + @table_erase +' SET Deleted=1 where ' + @accPK + ' = ' + cast(@pk as varchar);
			--PRINT @temp
			EXEC (@temp)
		END
		
		SET @cont_erase = @cont_erase +1;
		
	END
END


GO

