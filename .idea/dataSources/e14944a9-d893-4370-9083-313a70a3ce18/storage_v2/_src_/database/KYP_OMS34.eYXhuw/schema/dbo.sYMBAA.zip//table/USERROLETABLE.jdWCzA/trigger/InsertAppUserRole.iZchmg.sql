
CREATE TRIGGER [dbo].[InsertAppUserRole]
   ON  [dbo].[USERROLETABLE]
   AFTER INSERT
AS 
BEGIN

    declare @userName varchar(50)

	select @userName = user_name from INSERTED;
	--Insert only when username exists in OIS_User table and role not assigned
	insert into KYP.OIS_JT_UserRole 
		select @userName, roleId from KYP.OIS_Role r where --r.RoleName = @roleName
		RoleId in (select roleId from KYP.OIS_Role where RoleName in (select role_name from INSERTED) )
		and exists (select userid from KYP.OIS_User where UserID = @userName)

END


GO

