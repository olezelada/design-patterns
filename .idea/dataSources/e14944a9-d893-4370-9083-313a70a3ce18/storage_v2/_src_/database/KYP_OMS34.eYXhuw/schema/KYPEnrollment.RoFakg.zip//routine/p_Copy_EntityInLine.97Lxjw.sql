-- =============================================

-- Author:   <Lperez>
-- realiza la copia del portal hacia account recive 4 parametros
-- @partyIdPortal party id del portal, @partyIdOMS nuevo party id de account ,@newAccountId account id , @lastActionUserID nombre del usuario que realizo la aprobacion.
-- NOTA en este PROCEDURE se realiza la copia de todas las tablas que tienen relacion directa con party id del portal
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_EntityInLine]
	@partyIdPortal INT, @partyIdOMS INT,@newAccountId INT,
	@lastActionUserID varchar(100)
AS
BEGIN
	Declare
		@newCliaId int,
		@applicationId int,
		@dateCreated DATE,
		@case INT,
		@numberApplication VARCHAR,
		@newPartyID int,
		@partyAdverseAction INT,
		@partyInsuranceId INT,
		@newPartyIdInsurance INT,
		@newPartyIdInsuranceThree INT,
		@partyInsuranceIdThree INT,
		@isRendering nvarchar(20)

	Declare
		@intErrorCode int,
		@message varchar(100)

	SET @dateCreated = GETDATE()

	SELECT @applicationId = [ApplicationID], @isRendering = ISNULL([ApplicationCode],'') FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE [PartyID] = @partyIdPortal

	-- Clia
	--PROCEDURE [KYPEnrollment].[p_Copy_Clia] @partyIdPortal INT,@partyIdOMS INT,@lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_Clia] @partyIdPortal,@partyIdOMS,@lastActionUserID;
		
	-- number	
	--PROCEDURE [KYPEnrollment].[p_Copy_Number]	@partyIdPortal INT,	@partyIdOMS INT, @lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_Number]	@partyIdPortal,@partyIdOMS,@lastActionUserID;
	
	-- Fine and Debt	
	--PROCEDURE [KYPEnrollment].[p_Copy_FineDebt] @partyIdPortal INT, @partyIdOMS INT,@lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_FineDebt] @partyIdPortal,@partyIdOMS,@lastActionUserID;
	
	--ALTER PROCEDURE [KYPEnrollment].[p_Copy_AdverseAction] @AdverseActionPartyID INT,@newPartyID INT,@typeSQL varchar(15)(party or AdverseAction)
	EXEC [KYPEnrollment].[p_Copy_AdverseAction] @partyIdPortal ,@partyIdOMS ,'party',@lastActionUserID
	  
	--Insurance  
	--PROCEDURE [KYPEnrollment].[p_Copy_Insurance]@partyIdPortal INT,@partyIdOMS INT,@lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_Insurance]@partyIdPortal,@partyIdOMS,@lastActionUserID;
	
	--License --------------------------------------------------------------------------------------------------------
	--PROCEDURE [KYPEnrollment].[p_Copy_License]@partyIdPortal INT,	@partyIdOMS INT,@lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_License] @partyIdPortal,@partyIdOMS,@lastActionUserID;
	print('holaaaaaaaaaaaSS')
	-- Payment 
	--PROCEDURE [KYPEnrollment].[p_Copy_PaymentDetail]@partyIdPortal INT,@partyIdOMS INT,@lastActionUserID varchar(100)
	EXECUTE [KYPEnrollment].[p_Copy_PaymentDetail] @partyIdPortal,@partyIdOMS,@lastActionUserID;
	print('holaaaaaaaaaaa')
	------ New Party AdverseAction ------------ aparty del provider party id, relacionando el nuevo party id de account	
	------------------------  Program participation table program participation----------------------------	
	DECLARE @partyProgSusp_Id INT, @adverseProgSusp_Id INT, @providerProgSusp INT, @newPartyProgSusp_Id INT,@orgsId int,@personsID int
	
	DECLARE ProgSus_Cursor CURSOR FOR 	
	SELECT party.PartyID, adverseAction.AdverseActionID, provider.ProvID
	FROM   [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] AS adverseaction INNER JOIN
		   [KYPPORTAL].[PortalKYP].[pPDM_Party] AS  party ON adverseAction.PartyID = party.PartyID INNER JOIN
		   [KYPPORTAL].[PortalKYP].[pPDM_Provider] AS provider ON party.PartyID = provider.PartyID
	WHERE party.ParentPartyID = @partyIdPortal AND party.Type= 'LiabilitiesActionProgramSuspension'
	
	OPEN ProgSus_Cursor;
	FETCH NEXT FROM ProgSus_Cursor INTO @partyProgSusp_Id, @adverseProgSusp_Id, @providerProgSusp
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		PRINT 'ingresoA'
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyProgSusp_Id = [KYPEnrollment].[p_Copy_Party] @partyProgSusp_Id,@partyIdOMS,@newAccountId,@lastActionUserID,'';
		
		--ALTER PROCEDURE [KYPEnrollment].[p_Copy_AdverseAction] @AdverseActionPartyID INT,@newPartyID INT,@typeSQL varchar(15)(party or AdverseAction)
		EXEC [KYPEnrollment].[p_Copy_AdverseAction] @adverseProgSusp_Id ,@newPartyProgSusp_Id ,'AdverseAction',@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Provider] @providerProgSusp,@newPartyProgSusp_Id,@lastActionUserID;
		
		FETCH NEXT FROM ProgSus_Cursor INTO @partyProgSusp_Id, @adverseProgSusp_Id, @providerProgSusp
	END;
	CLOSE ProgSus_Cursor;
	DEALLOCATE ProgSus_Cursor;	
	PRINT 'ingresoB'
 	IF ((SELECT COUNT([PartyID]) FROM[KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE Type = 'Insurance' AND ParentPartyID = @partyIdPortal)>0)
	BEGIN
		-- /////////////New Party Insurance Page One//////////////
		SELECT @partyInsuranceId = ppp.[PartyID],@personsID=ppps.PersonID,@orgsId=ppo.OrgID  FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] ppp 
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Person] ppps ON ppps.PartyID =ppp.PartyID
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Organization] ppo ON ppo.PartyID =ppp.PartyID
		WHERE Type = 'Insurance' AND ParentPartyID = @partyIdPortal
		PRINT 'llegoA'
		--PROCEDURE [KYPEnrollment].[p_Copy_Party]@partyId INT,	@newPartyIdProv INT,@accountId INT,@lastActionUserID varchar(100),@type varchar(50)
		EXECUTE @newPartyIdInsurance = [KYPEnrollment].[p_Copy_Party] @partyIdPortal,@partyIdOMS,@newAccountId,@lastActionUserID,'Insurance';
				
		--PROCEDURE [KYPEnrollment].[p_Copy_Person]@personId INT,@newPartyId INT,@lastActionUserID varchar(100)
		EXECUTE  [KYPEnrollment].[p_Copy_Person] @personsID,@newPartyIdInsurance,@lastActionUserID;
			
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization]@orgID INT,@newPartyId INT,@lastActionUserID varchar(100)
		EXECUTE [KYPEnrollment].[p_Copy_Organization] @orgsID,@newPartyIdInsurance,@lastActionUserID;		
	END
	PRINT 'ingresoC'
	----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	-- copia Insurance aprtir del provider party id relacionando el nuevo party id de account	
	-- /////////////New Party Insurance Page Three //////////////
	IF ((SELECT COUNT([PartyID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE Type = 'InsurancePage3' AND ParentPartyID = @partyIdPortal)>0)
	BEGIN
	PRINT 'ingresoC11'
		SELECT @partyInsuranceIdThree = ppp.[PartyID],@personsID=ppps.PersonID,@orgsId=ppo.OrgID  FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] ppp 
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Person] ppps ON ppps.PartyID =ppp.PartyID
		INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Organization] ppo ON ppo.PartyID =ppp.PartyID
		WHERE Type = 'InsurancePage3' AND ParentPartyID = @partyIdPortal
		PRINT 'ingresoC22'
		--PROCEDURE [KYPEnrollment].[p_Copy_Party]@partyId INT,	@newPartyIdProv INT,@accountId INT,@lastActionUserID varchar(100),@type varchar(50)
		EXECUTE @newPartyIdInsuranceThree = [KYPEnrollment].[p_Copy_Party] @partyIdPortal,@partyIdOMS,@newAccountId,@lastActionUserID,'InsurancePage3';
		PRINT 'ingresoC33'		
		--PROCEDURE [KYPEnrollment].[p_Copy_Person]@personId INT,@newPartyId INT,@lastActionUserID varchar(100)
		EXECUTE  [KYPEnrollment].[p_Copy_Person] @personsID,@newPartyIdInsuranceThree,@lastActionUserID;
		PRINT 'ingresoC44'
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization]@orgID INT,@newPartyId INT,@lastActionUserID varchar(100)
		EXECUTE [KYPEnrollment].[p_Copy_Organization] @orgsID,@newPartyIdInsuranceThree,@lastActionUserID;		
		PRINT 'ingresoC55'
	END
	PRINT 'ingresoD'
	-- copia Significant Transaction  Entity apartir del party id del proveedor, relacionando el nuevo party id de account	
	----------/////////////// Significant Transaction  Entity ///////////////-------------
	DECLARE @partyTrans_Id INT, @transaction_Id INT, @addressTrans_Id INT, @locationTrans_Id INT,
			@orgTrans_id INT, @newPartyTransaction_Id INT, @newAddressTrans_Id INT
	
	DECLARE Transaction_Cursor CURSOR FOR 	
	SELECT party.PartyID, address.AddressID, location.LocationID, trans.TransactionID, org.OrgID
	FROM [KYPPORTAL].[PortalKYP].pPDM_Address as address INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Location as location ON address.AddressID = location.AddressID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Organization as org ON party.PartyID = org.PartyID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_OwnerhipTransaction as trans ON party.PartyID = trans.PartyID
	WHERE party.ParentPartyID = @partyIdPortal  AND  party.Type = 'TransactionEntity' 
	
	OPEN Transaction_Cursor;
	FETCH NEXT FROM Transaction_Cursor INTO @partyTrans_Id, @addressTrans_Id, @locationTrans_Id, @transaction_Id, @orgTrans_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		PRINT 'ingresoF'
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyTransaction_Id = [KYPEnrollment].[p_Copy_Party] @partyTrans_Id,@partyIdOMS,@newAccountId,@lastActionUserID,'';
		PRINT 'ingresoF11'
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressTrans_Id = [KYPEnrollment].[p_Copy_Address] @addressTrans_Id,@lastActionUserID;
		PRINT 'ingresoF22'
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationTrans_Id,@newAddressTrans_Id,@newPartyTransaction_Id,NULL,NULL,@lastActionUserID;			
		PRINT 'ingresoF33'
		--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction]@partyId INT,@newPartyId INT,@lastActionUserID varchar(100),@type varchar(50)
		EXECUTE  [KYPEnrollment].[p_Copy_OwnerhipTransaction] @transaction_Id,@newPartyTransaction_Id,@lastActionUserID,'transaction';		
		PRINT 'ingresoF44'	
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Organization] @orgTrans_id,@newPartyTransaction_Id,@lastActionUserID;
		PRINT 'ingresoF55'
		FETCH NEXT FROM Transaction_Cursor INTO @partyTrans_Id, @addressTrans_Id, @locationTrans_Id, @transaction_Id, @orgTrans_id
	END;
	CLOSE Transaction_Cursor;
	DEALLOCATE Transaction_Cursor;	
	PRINT 'ingresoG'
	-- copia Significant Transaction  Individual apartir del provider party id relacionando el nuevo party id de account	
	----------/////////////// Significant Transaction  Individual ///////////////-------------
	DECLARE @partyTransInd_Id INT, @transactionInd_Id INT, @addressTransInd_Id INT, @locationTransInd_Id INT,
			@personTransInd_id INT, @newPartyTransactionInd_Id INT, @newAddressTransInd_Id INT
	
	DECLARE TransactionInd_Cursor CURSOR FOR 
	SELECT party.PartyID, address.AddressID, location.LocationID, trans.TransactionID, person.PersonID 
	FROM [KYPPORTAL].[PortalKYP].pPDM_Address as address INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Location as location ON address.AddressID = location.AddressID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_OwnerhipTransaction as trans ON party.PartyID = trans.PartyID INNER JOIN
		 [KYPPORTAL].[PortalKYP].pPDM_Person as person ON party.PartyID = person.PartyID
	WHERE party.ParentPartyID = @partyIdPortal  AND  party.Type = 'TransactionIndividual' 
	
	OPEN TransactionInd_Cursor
	FETCH NEXT FROM TransactionInd_Cursor INTO @partyTransInd_Id, @addressTransInd_Id, @locationTransInd_Id, @transactionInd_Id, @personTransInd_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN			
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyTransactionInd_Id = [KYPEnrollment].[p_Copy_Party] @partyTransInd_Id,@partyIdOMS,@newAccountId,@lastActionUserID,'';
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressTransInd_Id = [KYPEnrollment].[p_Copy_Address] @addressTransInd_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationTransInd_Id,@newAddressTransInd_Id,@newPartyTransactionInd_Id,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction]@partyId INT,@newPartyId INT,@lastActionUserID varchar(100),@type varchar(50)
		EXECUTE  [KYPEnrollment].[p_Copy_OwnerhipTransaction] @transactionInd_Id,@newPartyTransactionInd_Id,@lastActionUserID,'transaction';	
						
		--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Person] @personTransInd_id,@newPartyTransactionInd_Id,@lastActionUserID;
			
		FETCH NEXT FROM TransactionInd_Cursor INTO @partyTrans_Id, @addressTrans_Id, @locationTrans_Id, @transaction_Id, @personTransInd_id
	END;
	CLOSE TransactionInd_Cursor;
	DEALLOCATE TransactionInd_Cursor;	
	PRINT 'ingresoH'
	------------------------  Program participation table program participation----------------------------
	-- realiza la copia apartir del provider party id relacionando el nuevo party id de account	
	DECLARE @partyProgPart_Id INT, @addressProgPart_Id INT, @locationProgPart_Id INT,
			@orgProgPart_id INT, @providerProgPart INT, @newPartyProgPart_Id INT, @newAddressProgPart_Id INT
	
	DECLARE ProgPart_Cursor CURSOR FOR 	
	SELECT  party.PartyID, address.AddressID, location.LocationID, organization.OrgID, provider.ProvID
	FROM    [KYPPORTAL].[PortalKYP].[pPDM_Address] AS address INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Location] AS location ON address.AddressID = location.AddressID INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Party] AS party ON location.PartyID = party.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Organization] AS organization ON party.PartyID = organization.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Provider] AS provider ON party.PartyID = provider.PartyID
	WHERE  party.ParentPartyID = @partyIdPortal  AND  party.Type = 'ProgramParticipation'
	
	OPEN ProgPart_Cursor;
	FETCH NEXT FROM ProgPart_Cursor INTO @partyProgPart_Id, @addressProgPart_Id, @locationProgPart_Id, @orgProgPart_id, @providerProgPart
	
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyProgPart_Id = [KYPEnrollment].[p_Copy_Party] @partyProgPart_Id,@partyIdOMS,@newAccountId,@lastActionUserID,'';
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressProgPart_Id = [KYPEnrollment].[p_Copy_Address] @addressProgPart_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationProgPart_Id,@newAddressProgPart_Id,@newPartyProgPart_Id,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Organization] @orgProgPart_id,@newPartyProgPart_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Provider] @providerProgPart,@newPartyProgPart_Id,@lastActionUserID;
			
		FETCH NEXT FROM ProgPart_Cursor INTO @partyProgPart_Id, @addressProgPart_Id, @locationProgPart_Id, @orgProgPart_id, @providerProgPart
	END;
	CLOSE ProgPart_Cursor;
	DEALLOCATE ProgPart_Cursor;
	
	------------------------  Program participation table program participation Health Care Provider ----------------------------
	--- realiza la copia apartir del provider party id relacionando el nuevo party id de account	
	DECLARE @partyProgPartHealt_Id INT, @addressProgPartHealt_Id INT, @locationProgPartHealt_Id INT,
			@orgProgPartHealt_id INT, @providerProgPartHealt INT, @newPartyProgPartHealt_Id INT, @newAddressProgPartHealt_Id INT
	
	DECLARE ProgPartHealt_Cursor CURSOR FOR 
	
	SELECT party.PartyID, address.AddressID, location.LocationID, organization.OrgID
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] AS address INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Location] AS location ON address.AddressID = location.AddressID INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Party] AS party ON location.PartyID = party.PartyID INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Organization] AS organization ON party.PartyID = organization.PartyID
	WHERE  party.ParentPartyID = @partyIdPortal  AND  party.Type = 'Provider Q1'
	
	OPEN ProgPartHealt_Cursor;
	FETCH NEXT FROM ProgPartHealt_Cursor INTO @partyProgPartHealt_Id, @addressProgPartHealt_Id, @locationProgPartHealt_Id, @orgProgPartHealt_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyProgPartHealt_Id = [KYPEnrollment].[p_Copy_Party] @partyProgPartHealt_Id,@partyIdOMS,@newAccountId,@lastActionUserID,'';
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressProgPartHealt_Id = [KYPEnrollment].[p_Copy_Address] @addressProgPartHealt_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationProgPartHealt_Id,@newAddressProgPartHealt_Id,@newPartyProgPartHealt_Id,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Organization] @orgProgPartHealt_id,@newPartyProgPartHealt_Id,@lastActionUserID;
			
		FETCH NEXT FROM ProgPartHealt_Cursor INTO @partyProgPartHealt_Id, @addressProgPartHealt_Id, @locationProgPartHealt_Id, @orgProgPartHealt_id
	END;
	CLOSE ProgPartHealt_Cursor;
	DEALLOCATE ProgPartHealt_Cursor;
END


GO

