
CREATE VIEW [KYP].[v_LicenseExpiry_Reminder]
AS
SELECT  TOP (100) PERCENT   
    row_number() OVER (ORDER BY Lic.ProviderMedicaid ASC) AS ID,* from
( select
    distinct B.Name as ProviderName,
     C.provNumber as ProviderMedicaid,
     A.LicenseCode as ProviderLicenseNo, 
     A.ExpiryDate as ProviderLicenseExpiryDate
     --,A.PartyID   
FROM 
KYP.PDM_License A 
INNER JOIN KYP.PDM_Party B 
 ON A.PartyID = B.PartyID AND ISNULL(B.IsProvider,0) = 1 
    AND B.CurrentModule = 2 AND A.ExpiryDate IS NOT NULL
INNER JOIN KYP.PDM_Provider C
ON C.PartyID= B.PartyID
WHERE ExpiryDate between KYP.F_LicenseExpiryFirst() and KYP.F_LicenseExpiryLast()														
) Lic ORDER BY lic.ProviderLicenseExpiryDate ASC


GO

