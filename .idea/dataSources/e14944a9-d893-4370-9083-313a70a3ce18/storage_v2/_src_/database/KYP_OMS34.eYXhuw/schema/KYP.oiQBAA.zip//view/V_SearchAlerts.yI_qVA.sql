CREATE VIEW [KYP].[V_SearchAlerts]
AS
SELECT       KYP.MDM_Alert.AlertID AS ID,
			 KYP.MDM_Alert.AlertID, 
			 KYP.MDM_Alert.AlertNo, 
			 KYP.MDM_Alert.MatchPercent, 
			 KYP.MDM_Alert.WatchedPartyName, 
			 KYP.MDM_Alert.MatchStatusIndicator,
             KYP.MDM_Alert.WatchlistName,
             KYP.MDM_Alert.DateInitiated, 
             KYP.MDM_Alert.WatchedPartyID, 
             KYP.MDM_Alert.CurrentWFMinorStatus, 
             KYP.MDM_Alert.WatchedPartyType, 
             KYP.OIS_Person.FullName, 
             KYP.MDM_AlertDetail.FName, 
             KYP.MDM_Alert.NoOfMergedAlerts, 
             KYP.MDM_AlertDetail.MName, 
             KYP.MDM_AlertDetail.LName, 
             KYP.MDM_AlertDetail.OrganizationName, 
             KYP.PDM_Person.SSN, 
             KYP.PDM_Organization.TIN As TAXID ,
             KYP.MDM_AlertDetail.LegalName, 
             KYP.MDM_AlertDetail.DBAName, 
             KYP.MDM_AlertDetail.OwnerName

FROM         KYP.MDM_Alert LEFT OUTER JOIN KYP.OIS_Person 
             ON 
             KYP.MDM_Alert.AssignedToUserID = KYP.OIS_Person.PersonID
             LEFT OUTER JOIN KYP.MDM_AlertDetail   
             ON 
             KYP.MDM_AlertDetail.AlertID = KYP.MDM_Alert.AlertID
             left outer join
             KYP.PDM_Organization
             On  
             KYP.PDM_Organization.PartyID= KYP.MDM_Alert.WatchedPartyID
             left outer join KYP.PDM_Person
             ON
             KYP.PDM_Person.PartyID= KYP.MDM_Alert.WatchedPartyID

WHERE     (ISNULL(KYP.MDM_Alert.IsDeleted, 0) = 0)


GO

