

/* ==========================================================
-- Author:		<DH-Bolivia>
-- PROCEDURE: update affiliations DMC
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_affiliationsDMC]
  @application_no VARCHAR(20)
 ,@application_Code VARCHAR(50)

AS
  BEGIN
    IF (@application_Code IN ('FSP_DMC_IN','FSP_DMC_SP'))
    BEGIN
      DECLARE @group_npi VARCHAR(15), @groupId INT;
      CREATE TABLE #rendApplicationNo (id INT IDENTITY (1, 1),rendering_providerNumber VARCHAR(20))
      CREATE TABLE #rendAccountId (id INT IDENTITY (1, 1), rendAccountId INT )
      CREATE TABLE #clinics ( id INT IDENTITY (1, 1), accountId INT, providerTypeCode VARCHAR(6) )

      SELECT @group_npi = group_npi
      FROM KYPPORTAL.PortalKYP.pRenderingAffiliation
      WHERE group_providerNumber = @application_no


      INSERT INTO #clinics(accountId, providerTypeCode)
        SELECT acc.AccountID, acc.ProviderTypeCode FROM KYPEnrollment.pADM_Account acc
          INNER JOIN KYPEnrollment.pAccount_PDM_Party party on party.PartyID = acc.PartyID
          INNER JOIN KYPEnrollment.pAccount_PDM_Location loc on loc.PartyID = party.PartyID
          INNER JOIN KYPEnrollment.pAccount_PDM_Address addr on addr.AddressID = loc.AddressID
          INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address appAddr on appAddr.AddressLine1 = addr.AddressLine1
                                                                 AND appAddr.City = addr.City
                                                                 AND appAddr.State = addr.State
                                                                 AND appAddr.County = addr.County
                                                                 AND appAddr.ZipPlus4 = addr.ZipPlus4
          INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location appLoc on appLoc.AddressID = appAddr.AddressID
          INNER JOIN KYPPORTAL.PortalKYP.pADM_Application app on app.PartyID = appLoc.PartyID
        WHERE acc.NPI = @group_npi
              AND app.ApplicationCode = acc.PackageName
              AND app.ApplicationNo = @application_no
              AND acc.IsPastOwner = 0
              AND loc.Type = 'Servicing' AND appLoc.Type = 'Servicing'
              AND loc.IsDeleted = 0 AND appLoc.IsDeleted = 0


      DECLARE @totalClinics INT
      SELECT @totalClinics = COUNT(id) FROM #clinics

      IF(1 < @totalClinics)
        BEGIN
          SELECT @groupId = accountId FROM #clinics WHERE providerTypeCode = '076'
        END
      ELSE
        BEGIN
          SELECT @groupId = accountId FROM #clinics
        END

      INSERT INTO #rendApplicationNo (rendering_providerNumber)
        SELECT rendering_providerNumber
        FROM KYPPORTAL.PortalKYP.pRenderingAffiliation
        WHERE group_providerNumber = @application_no AND isDeleted = 0


      INSERT INTO #rendAccountId (rendAccountId)
        SELECT AccountID
        FROM [KYPEnrollment].[pADM_Account]
        WHERE IsPastOwner=0 AND ApplicationNumber IN (SELECT rendering_providerNumber FROM #rendApplicationNo)


      IF NOT EXISTS (SELECT * FROM #rendAccountId)
      BEGIN
        UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
        SET AccountID = @groupId
        WHERE AccountID IS NULL AND CurrentRecordFlag = 1 AND AffiliatedAccountID IN (
            SELECT acc.ACCOUNTID
            FROM KYP.ADM_Case ac
              INNER JOIN KYPENROLLMENT.PADM_ACCOUNT acc ON ac.ACCOUNTNO = acc.ACCOUNTNUMBER
            WHERE ac.Number IN (SELECT rendering_providerNumber FROM #rendApplicationNo)
        )
      END
      ELSE
      BEGIN
        UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
        SET AccountID = @groupId
        WHERE AccountID IS NULL AND CurrentRecordFlag = 1 AND AffiliatedAccountID IN (SELECT rendAccountId FROM #rendAccountId)
      END
    END
  END


GO

