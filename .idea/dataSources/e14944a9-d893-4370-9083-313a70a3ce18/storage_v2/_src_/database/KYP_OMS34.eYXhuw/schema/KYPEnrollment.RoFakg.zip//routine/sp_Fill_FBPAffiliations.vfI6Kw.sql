-- =============================================  
-- Author:  <GLacunza>  
-- Create date: <02/02/2018>  
-- Description: <Fills table pPDM_FBPAffiliations in FBP cases>  
-- =============================================  
--Change History  
---------------------------------------------------------------------------------------  
-- Sl.No. JIRA No.   Author		Date			Description  
---------------------------------------------------------------------------------------  
--	1	KEN-20824	Sundar		19-May-2019		Added statement to avoid duplicate rendering in pAccount_renderingAffiliation table

CREATE PROCEDURE [KYPEnrollment].[sp_Fill_FBPAffiliations]  
    @application_no      VARCHAR(10),  
    @group_app           VARCHAR(20),  
    @Account_Id          INT,  
    @application_Id      INT,  
    @last_action_user_id VARCHAR(100)  
  
AS  
BEGIN  

	DECLARE @date_create DATE, 
			@rendering_app_affiliation_id INT, 
			@group_email VARCHAR(100), 
			@type_affiliation VARCHAR(100), 
			@app_group_id INT, 
			@rendering_email VARCHAR(100), 
			@group_npi VARCHAR(10), 
			@group_pt_code VARCHAR(10),  
			@tot INT, 
			@cont INT, 
			@add INT, 
			@ap INT, 
			@loc INT, 
			@id INT  

	DECLARE @temp_data TABLE(pk INT IDENTITY (1, 1), id INT, loc_FBP INT)  
	DECLARE @temp_account TABLE(pk INT IDENTITY (1, 1), account INT,id int,loc int)  

	--SET @date_create = GETDATE();  
	SET NOCOUNT ON;  

	SELECT @date_create = DateCreated  
	FROM KYP.ADM_CASE with (nolock)  
	WHERE Number = @application_no --Changed from @Group_app to @application_No by Sundar on 22 Nov 2018 for CAPAVE-4227  

	SELECT  
	@app_group_id = ap.ApplicationID,  
	@group_npi = ap.NPI,  
	@group_pt_code = ap.ProviderTypeCode  
	FROM  
	KYPPORTAL.PortalKYP.pADM_Application ap  
	WHERE  
	ApplicationNo = @group_app AND ap.IsDeleted = 0  
	AND ap.FBPApp = 1  

	INSERT INTO @temp_data (id, loc_FBP)  
	SELECT  
	id, LocationID  
	FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations  
	WHERE ApplicationID = @application_Id AND IsDeleted = 0  

	INSERT INTO @temp_account (account,loc)  
	SELECT acc.AccountID,lfbp.LocationID  
	FROM KYPEnrollment.pADM_Account acc  
	inner join KYPEnrollment.pAccount_PDM_Location l on acc.PartyID=l.PartyID inner join KYPEnrollment.pAccount_PDM_Address ad on ad.AddressID=l.AddressID  
	inner join KYPPORTAL.PortalKYP.pPDM_Location lfbp on l.Name=lfbp.Name   
	inner join KYPPORTAL.PortalKYP.pPDM_Address adfbp on lfbp.AddressID=adfbp.AddressID  
	inner join KYPPORTAL.PortalKYP.pPDM_FBPAffiliations afil on afil.LocationID=lfbp.LocationID  
	WHERE l.IsDeleted=0 and 
			ad.CurrentRecordFlag=1 and 
			l.CurrentRecordFlag=1 and 
			lfbp.IsDeleted=0 and 
			adfbp.IsDeleted=0 and 
			lfbp.Approved=1 and 
			acc.IsDeleted=0 and 
			acc.IsPastOwner=0 and 
			l.Type='Servicing' and 
			afil.ApplicationID = @application_Id and 
			afil.IsDeleted=0 and 
			ad.AddressLine1=adfbp.AddressLine1 and  
			ad.AddressLine2=adfbp.AddressLine2 and 
			ad.City=adfbp.City and  
			ad.State=adfbp.State and  
			ad.ZipPlus4=adfbp.ZipPlus4 AND 
			acc.ProvLocTypeCd = 'F' AND 
			acc.NPI = @group_npi AND 
			(acc.ProviderTypeCode = @group_pt_code  
				OR acc.ProviderTypeCode IN (  
									SELECT ProviderTypeCode  
									FROM KYPPORTAL.PortalKYP.pPDM_Location loc  
									INNER JOIN @temp_data temp ON temp.loc_FBP = loc.LocationID  
									)  
				)  

	UPDATE f  
	SET FBPAccountID = ta.account  
	from KYPPORTAL.PortalKYP.pPDM_FBPAffiliations f inner join @temp_account ta on ta.loc=f.LocationID  
	WHERE ApplicationID=@application_Id and IsDeleted=0       

	IF EXISTS (SELECT * FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations WHERE ApplicationID = @application_Id and FBPAccountID is null and IsDeleted=0)   
	begin  
		--declare @acc_aux int  
		--select @acc_aux = AccountID from KYPEnrollment.pADM_Account a inner join KYPPORTAL.PortalKYP.pPDM_FBPAffiliations f on a.loc_FBP=f.LocationID   
		--where f.IsDeleted=0 and a.IsDeleted=0 and IsPastOwner=0 and (StatusAcc like '1%' or StatusAcc like '7%') and  f.ApplicationID = @application_Id and FBPAccountID is null  

		--update KYPPORTAL.PortalKYP.pPDM_FBPAffiliations set FBPAccountID=@acc_aux where  ApplicationID = @application_Id and IsDeleted=0 and FBPAccountID is null  

		--Changed the Update state. for CAPAVE-3668 on 18 Jul 2018  
		Update f  
		Set f.FBPAccountID = A.AccountID   
		from KYPEnrollment.pADM_Account a   
		inner join KYPPORTAL.PortalKYP.pPDM_FBPAffiliations f on a.loc_FBP=f.LocationID   
		where f.IsDeleted=0 and a.IsDeleted=0 and IsPastOwner=0   
		and (a.StatusAcc like '1%' or a.StatusAcc like '7%')   
		and  f.ApplicationID = @application_Id   
		and FBPAccountID is null   
	end  

	select @type_affiliation = type_affiliation,@group_email=groupEmail,@rendering_email=rendering_email, @rendering_app_affiliation_id = rendering_affiliation_id  
	FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  
	where rendering_providerNumber = @application_no and isDeleted=0  

	if exists (select FAf.FBPAccountID  
				FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations FAf  
				Left Join kypenrollment.Paccount_RenderingAffiliation Af on FAf.FBPAccountID = Af.AccountID and Af.[AffiliatedAccountID] = @Account_Id  
				WHERE FAf.ApplicationID = @application_Id AND FAf.IsDeleted = 0  
				and FAf.FBPAccountID is not null  
				and Af.AccountID is null)   
				OR  
			exists(select A.applicationNumber  
					FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] A  
					INNER JOIN kyp.adm_case B ON A.applicationNumber = B.Number  
					WHERE rendering_affiliation_id = @rendering_app_affiliation_id  
					AND A.accountId NOT IN (  
					SELECT FBPAccountID  
					FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations fbpAff  
					WHERE fbpAff.ApplicationID = @application_Id  
					  AND fbpAff.IsDeleted = 0  
					  AND fbpAff.FBPAccountID IS NOT NULL )  
					) 
	BEGIN  
		--Added Left Join and where clause for CAPAVE-3668 on 18 Jul 2018  
		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AccountID]  
		, [AffiliatedAccountID]  
		, [TypeAffiliation]  
		, [LastActionDate]  
		, [LastActorUserID]  
		, [LastActionApprovedBy]  
		, [CurrentRecordFlag]  
		, [LastAction]  
		, [AffiliationStartDate]  
		, [LastUpdatedBy]  
		, [groupEmail]  
		, [rendering_email]  
		, isDeleted)  
		SELECT  
		FBPAccountID,  
		@Account_Id,  
		@type_affiliation,  
		GetdaTE(),  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		@date_create,  
		'P',  
		@group_email,  
		@rendering_email,  
		0  
		FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations FAf  
		Left Join kypenrollment.Paccount_RenderingAffiliation Af on FAf.FBPAccountID = Af.AccountID and Af.[AffiliatedAccountID] = @Account_Id  
		WHERE FAf.ApplicationID = @application_Id AND FAf.IsDeleted = 0  
		and FAf.FBPAccountID is not null  
		and Af.AccountID is null;  

		If Not Exists(Select t1.RenderingAffiliationID FROM [KYPEnrollment].[pAccount_RenderingAffiliation] t1
							Join [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] T2 on T1.AccountId = T2.[accountId]
							Where t1.AffiliatedAccountID = @Account_Id
								and T2.rendering_affiliation_id = @rendering_app_affiliation_id
								and T1.isDeleted = 0) --Added for 1 KEN-20824
		Begin
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
			([AccountID]  
			, [AffiliatedAccountID]  
			, [TypeAffiliation]  
			, [LastActionDate]  
			, [LastActorUserID]  
			, [LastActionApprovedBy]  
			, [CurrentRecordFlag]  
			, [LastAction]  
			, [AffiliationStartDate]  
			, [LastUpdatedBy]  
			, [groupEmail]  
			, [rendering_email]  
			, [isDeleted])  
			SELECT  
			A.[accountId],  
			@Account_Id,  
			@type_affiliation,  
			-- @date_create,  
			Getdate(), -- Changed by Sundar on 12-Sep-2018 for CAPAVE-3992  
			@last_action_user_id,  
			@last_action_user_id,  
			1,  
			'C',  
			B.DateCreated,  
			'P',  
			[groupEmail],  
			[renderingEmail],  
			0  
			FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] A  
			INNER JOIN kyp.adm_case B ON A.applicationNumber = B.Number  
			WHERE A.rendering_affiliation_id = @rendering_app_affiliation_id  
				AND A.accountId NOT IN (  
				SELECT FBPAccountID  
				FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations fbpAff  
				WHERE fbpAff.ApplicationID = @application_Id  
					AND fbpAff.IsDeleted = 0  
					AND fbpAff.FBPAccountID IS NOT NULL  
				);  

			RETURN @@IDENTITY  
		End
	END  
	ELSE RETURN 0   
END

GO

