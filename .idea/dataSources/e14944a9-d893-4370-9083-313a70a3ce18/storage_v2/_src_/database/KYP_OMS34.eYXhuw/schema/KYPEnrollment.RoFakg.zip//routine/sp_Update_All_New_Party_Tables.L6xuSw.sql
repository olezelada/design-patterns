


/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update tables that have new PartyId for each row.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User. 
-- @target_path : target path to Traking. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name : Table Name to contain field that will be update.  
-- @table_code : Type of Table.  
-- @stored_value : input Type that be Update.
-- @account_id : AccountID that will be update.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_All_New_Party_Tables]
   @acc_party_id           INT,
   @action_taken           VARCHAR (50),
   @last_action_user_id    VARCHAR (100),
   @target_path            VARCHAR (200),
   @en_db_column           VARCHAR (100),
   @data                   VARCHAR (MAX),
   @acc_PK                 VARCHAR (100),
   @acc_PK_value           INT,
   @is_text_date           CHAR (1),
   @acc_table_name         VARCHAR (100),
   @table_code             VARCHAR (20),
   @stored_value           VARCHAR (MAX),
   @account_id             INT,
   @new_fields_values      VARCHAR (MAX) = NULL,
   @row_uuid               VARCHAR (100) = NULL
AS
BEGIN
   SET  NOCOUNT ON;
   DECLARE
      @app_party_row_id      INT,
      @type                  VARCHAR (50),
      @parent_party_id       INT,
      @inset                 BIT,
      @new_party_row_id      INT,
      @count                 INT,
      @acc_party_id_enroll   INT;
   DECLARE
      @partyOwner   INT,
      @part         INT

   SET @inset = 0;

   IF @action_taken = 'Added'
      BEGIN
         IF    @target_path NOT LIKE '%|%'
            OR @new_fields_values = 'TaxIDPrepopulate'
            BEGIN
               PRINT @action_taken + ': ' + 'NEW ROW'

               IF @new_fields_values = 'TaxIDPrepopulate'
                  BEGIN
                     SELECT @app_party_row_id = PartyID,
                            @type = Type,
                            @parent_party_id = ParentPartyID
                     FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                     WHERE UUID = @row_uuid;
                  END
               ELSE
                  BEGIN
                     SELECT @app_party_row_id = PartyID,
                            @type = Type,
                            @parent_party_id = ParentPartyID
                     FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                     WHERE TargetPath = @target_path;
                  END


               IF NOT EXISTS
                     (SELECT FiledID
                        FROM #Control_Add_row
                       WHERE     FiledID = @app_party_row_id
                             AND NameTable = 'pAccount_PDM_Party')
                  BEGIN
                     IF    @table_code = 'hospitalPrivileges'
                        OR @table_code = 'privilegesRevoked'
                        OR @table_code = 'privilegesResigned'
                        OR @table_code = 'mediCalPartTable'
                        OR @table_code = 'businessOrpTable'
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org] NULL,
                                                                             @acc_party_id,
                                                                             @last_action_user_id,
                                                                             @type,
                                                                             @app_party_row_id,
                                                                             @account_id;
                        END

                     IF     @table_code = 'selfPartTable'
                        AND NOT EXISTS
                               (SELECT FiledId
                                  FROM #Control_Add_row
                                 WHERE     FiledID = @parent_party_id
                                       AND NameTable = 'pAccount_PDM_Party')
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC [KYPEnrollment].[sp_Copy_Program_Participation] @acc_party_id,
                                                                                NULL,
                                                                                @last_action_user_id,
                                                                                @type,
                                                                                @app_party_row_id,
                                                                                @account_id;
                        END

                     IF     @table_code = 'suspendedTable'
                        AND NOT EXISTS
                               (SELECT FiledID
                                  FROM #Control_Add_row
                                 WHERE     FiledID = @parent_party_id
                                       AND NameTable = 'pAccount_PDM_Party')
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC [KYPEnrollment].[sp_Copy_Program_Suspension] @acc_party_id,
                                                                             NULL,
                                                                             @last_action_user_id,
                                                                             @type,
                                                                             @app_party_row_id,
                                                                             @account_id;
                        END

                     IF    @table_code = 'subcontractorTable'
                        OR @table_code = 'sigTransTable'
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;

                           IF    @type = 'SubcontractorEntity'
                              OR @type = 'TransactionEntity'
                              BEGIN
                                 EXEC @new_party_row_id =
                                         [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org] NULL,
                                                                                      @acc_party_id,
                                                                                      @last_action_user_id,
                                                                                      @type,
                                                                                      @app_party_row_id,
                                                                                      @account_id,
                                                                                      1;
                              --insert into #subcontractors (PartyID_Portal,Type_sub,PartyID_Enroll)
                              --VALUES (@app_party_row_id,@type,@new_party_row_id  )
                              END
                           ELSE
                              BEGIN
                                 EXEC @new_party_row_id =
                                         [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Ind] NULL,
                                                                                      @acc_party_id,
                                                                                      @last_action_user_id,
                                                                                      @type,
                                                                                      @app_party_row_id,
                                                                                      @account_id,
                                                                                      1;
                              --insert into #subcontractors (PartyID_Portal,Type_sub,PartyID_Enroll)
                              --VALUES (@app_party_row_id,@type,@new_party_row_id  )
                              END

                           IF (   @type = 'SubcontractorEntity'
                               OR @type = 'SubcontractorIndividual')
                              BEGIN
                                 EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_row_id,
                                                                           @app_party_row_id,
                                                                           @last_action_user_id,
                                                                           NULL,
                                                                           NULL;
                              END


                           INSERT
                             INTO #Control_Add_row (AppPartyId, AccPartyId)
                           VALUES (@app_party_row_id, @new_party_row_id)
                        END

                     --mvc

                     IF @table_code = 'subOwnerTable'
                        BEGIN
                           --if the child subcontractors created has a father that already exist
                           IF NOT EXISTS
                                 (SELECT *
                                    FROM #subcontractors
                                   WHERE partyid_portal = @app_party_row_id)
                              BEGIN
                                 DECLARE @partyfather   VARCHAR (50)
                                 SET @partyfather = ''
                                 SELECT @partyfather =
                                           substring (targetpath,
                                                      28,
                                                      LEN (targetpath) - 27)
                                   FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                                  WHERE     partyid = @parent_party_id
                                        AND targetpath LIKE
                                               'pAccount_PDM_Party|PartyID|%'

                                 IF @partyfather <> ''
                                    --create subcontr child
                                    BEGIN
                                       DECLARE @partychildsub_enr   INT

                                       EXEC @partychildsub_enr =
                                               [KYPEnrollment].[sp_Copy_Party] @app_party_row_id,
                                                                               @partyfather,
                                                                               @account_id,
                                                                               @last_action_user_id;

                                       INSERT
                                         INTO #subcontractors (
                                                 PartyID_Portal,
                                                 Type_sub,
                                                 PartyID_Enroll)
                                          VALUES (
                                                    @app_party_row_id,
                                                    @type,
                                                    @partychildsub_enr)

                                       --insert into [dbo].[subcontractors] (PartyID_Portal,Type_sub,PartyID_Enroll)
                                       --VALUES (@app_party_row_id,@type,@partychildsub_enr )
                                       --
                                       IF @type = 'SubcontractorOwnerEntity'
                                          BEGIN
                                             EXEC [KYPEnrollment].[sp_Copy_Organization] @partychildsub_enr,
                                                                                         @app_party_row_id,
                                                                                         @last_action_user_id;
                                          END
                                       ELSE
                                          BEGIN
                                             EXEC [KYPEnrollment].[sp_Copy_Person] @partychildsub_enr,
                                                                                   @app_party_row_id,
                                                                                   @last_action_user_id,
                                                                                   'C';
                                          END

                                       EXEC [KYPEnrollment].[sp_Copy_Address] @partychildsub_enr,
                                                                              @app_party_row_id,
                                                                              NULL,
                                                                              @last_action_user_id;
                                       EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @partychildsub_enr,
                                                                                 @app_party_row_id,
                                                                                 @last_action_user_id,
                                                                                 NULL,
                                                                                 NULL;
                                       --** insert association for owner subcontractor
                                       EXEC [KYPEnrollment].[Create_Party_Associate] @partychildsub_enr,
                                                                                     @partychildsub_enr,
                                                                                     @account_id,
                                                                                     @type,
                                                                                     @app_party_row_id;
                                    END
                              END
                        END

                     /*OTHER ASSOCIATION*/
                     IF     (   @table_code = 'otherEntAssocTable'
                             OR @table_code = 'otherAssocTable')
                        AND NOT EXISTS
                               (SELECT FiledID
                                  FROM #Control_Add_row
                                 WHERE     FiledID = @parent_party_id
                                       AND NameTable = 'pAccount_PDM_Party')
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC [KYPEnrollment].[sp_Copy_Others_Associations] @acc_party_id,
                                                                              NULL,
                                                                              @account_id,
                                                                              @last_action_user_id,
                                                                              @target_path;
                        END

                     --new ownership
                     IF @table_code = 'ownerTable'
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC @new_party_row_id =
                                   [KYPEnrollment].[sp_Copy_Owner_Interest] @acc_party_id,
                                                                            @parent_party_id,
                                                                            @last_action_user_id,
                                                                            @app_party_row_id,
                                                                            @account_id,
                                                                            1;


                           INSERT
                             INTO #Control_Add_row (AppPartyId, AccPartyId)
                           VALUES (@app_party_row_id, @new_party_row_id)
                        END

                     /*
                     IF @table_code='whollySuppliersTable'  AND  not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@acc_party_id AND NameTable='whollySuppliersTable')
                     BEGIN
                      SET @inset=1;
                      PRINT @action_taken+': '+@table_code+ ' whollySuppliersTable';
                       EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_SignifSecondAdd @parent_party_id,@acc_party_id,@last_action_user_id,NULL,@account_id;

                       INSERT INTO #Control_Add_row (FiledID,NameTable)
             VALUES(@acc_party_id,'whollySuppliersTable');
                     END
                         */

                     IF @table_code = 'whollySuppliersTable'
                        BEGIN
                           IF @target_path LIKE '%|%'
                              BEGIN
                                 IF     @target_path LIKE
                                           'pAccount_PDM_Organization%'
                                    AND @new_fields_values =
                                           'TaxIDPrepopulate'
                                    BEGIN
                                       SELECT @part = PartyID
                                         FROM KYPENROLLMENT.pAccount_PDM_Organization
                                        WHERE OrgID = @acc_PK_value

                                       UPDATE KYPEnrollment.pAccount_PDM_Party
                                          SET ParentPartyID = @acc_party_id
                                        WHERE     partyID = @part
                                              AND Type =
                                                     'WhollyOwnedSupplied'
                                    END

                                 IF     @target_path LIKE
                                           'pAccount_PDM_OwnerhipTransaction%'
                                    AND @new_fields_values =
                                           'TaxIDPrepopulate'
                                    BEGIN
                                       SELECT @part = PartyID
                                         FROM KYPENROLLMENT.pAccount_PDM_OwnerhipTransaction
                                        WHERE TransactionID = @acc_PK_value

                                       UPDATE KYPEnrollment.pAccount_PDM_Party
                                          SET ParentPartyID = @acc_party_id
                                        WHERE     partyID = @part
                                              AND Type =
                                                     'WhollyOwnedSupplied'
                                    END
                              END
                           ELSE
                              BEGIN
                                 IF NOT EXISTS
                                       (SELECT FiledID
                                          FROM #Control_Add_row
                                         WHERE     FiledID = @acc_party_id
                                               AND NameTable =
                                                      'whollySuppliersTable')
                                    BEGIN
                                       SET @inset = 1;
                                       PRINT   @action_taken
                                             + ': '
                                             + @table_code
                                             + ' whollySuppliersTable';
                                       EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_SignifSecondAdd @parent_party_id,
                                                                                                   @acc_party_id,
                                                                                                   @last_action_user_id,
                                                                                                   NULL,
                                                                                                   @account_id;

                                       INSERT
                                         INTO #Control_Add_row (FiledID,
                                                                NameTable)
                                          VALUES (
                                                    @acc_party_id,
                                                    'whollySuppliersTable');
                                    END
                              END
                        END

                     IF @table_code = 'significantSubTable'
                        BEGIN
                           IF     left (@target_path, 50) =
                                     'pAccount_PDM_OwnershipRelationship|OwnerRelationID'
                              AND @app_party_row_id = NULL
                              AND NOT EXISTS
                                     (SELECT partyOwner
                                        FROM #signif
                                       WHERE acc_PK_value = @acc_PK_value)
                              BEGIN
                                 SELECT @partyOwner = PartyIDOwner
                                   FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
                                  WHERE OwnerRelationID = @acc_PK_value

                                 INSERT
                                   INTO #signif (acc_PK_value, partyOwner)
                                 VALUES (@acc_PK_value, @partyOwner)
                              -- EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_Signif @new_app_party_row_id,@partyOwner ,@last_action_user_id,NULL,@account_id;
                              END

                        /*
                         PRINT @action_taken+': '+@table_code+ ' significantSubTable 0' + convert(varchar(20),@acc_party_id)
                           IF NOT EXISTS (SELECT 1 FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] WHERE  PartyIDOwned
                            in (SELECT PartyID_Enroll from #subcontractors))
                            BEGIN
                SET @inset=1;
                PRINT @action_taken+': '+@table_code+ ' significantSubTable 1' + convert(varchar(20),@acc_party_id)
                          EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_Signif @app_party_row_id,@acc_party_id ,@last_action_user_id,NULL,@account_id;
                END
                */
                        END

                     IF    @table_code = 'leaseInformation'
                        OR @table_code = 'facilities'
                        BEGIN
                           PRINT @action_taken + ': ' + @table_code;
                           SET @inset = 1;
                           EXEC [KYPEnrollment].[sp_Copy_Place_Business] @acc_party_id,
                                                                         @app_party_row_id,
                                                                         @last_action_user_id,
                                                                         @account_id,
                                                                         1,
                                                                         @table_code;
                        END

                     IF @inset = 1
                        BEGIN
                           INSERT INTO #Control_Add_row (FiledID, NameTable)
                           VALUES (@app_party_row_id, 'pAccount_PDM_Party');
                        END
                  END
            END
         ELSE
            BEGIN
               PRINT @action_taken + ': ' + 'FIELD'
               EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,
                                                      @en_db_column,
                                                      @data,
                                                      @acc_PK,
                                                      @acc_PK_value,
                                                      @is_text_date,
                                                      @stored_value,
                                                      @last_action_user_id,
                                                      @action_taken;
            END
      END
   ELSE
      BEGIN
         IF @action_taken = 'Updated'
            BEGIN
               PRINT @action_taken + ': ' + @table_code;

               EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,
                                                      @en_db_column,
                                                      @data,
                                                      @acc_PK,
                                                      @acc_PK_value,
                                                      @is_text_date,
                                                      @stored_value,
                                                      @last_action_user_id,
                                                      @action_taken;

               IF @table_code = 'ownerTable' AND @acc_party_id IS NOT NULL
                  BEGIN
                     UPDATE [KYPEnrollment].[pAccount_PDM_Party]
                        SET LastMOCARelationshipUpdateBy = 'P'
                      WHERE PartyID = @acc_party_id;

                     UPDATE [KYPEnrollment].[pAccount_PDM_Party]
                        SET LastMOCAUpdateBy = 'P'
                      WHERE PartyID = @acc_party_id;
                  END
            END
         ELSE
            BEGIN
               IF     @action_taken = 'Deleted'
                  AND @acc_table_name IS NOT NULL
                  AND @data = 'Row Deleted'
                  BEGIN
                     PRINT   @action_taken
                           + ': '
                           + @table_code
                           + ' '
                           + @acc_table_name
                           + ' '
                           + @acc_PK;

                     EXECUTE
                        (  'UPDATE KYPEnrollment.'
                         + @acc_table_name
                         + ' SET CurrentRecordFlag = 0 WHERE '
                         + @acc_PK
                         + ' = '
                         + @acc_PK_value);

                     IF @table_code = 'ownerTable'
                        BEGIN
                           UPDATE [KYPEnrollment].[pAccount_PDM_Party]
                              SET MOCARelationshipEndDate = GETDATE ()
                            WHERE PartyID = @acc_party_id;

                           UPDATE [KYPEnrollment].[pAccount_PDM_Party]
                              SET LastMOCARelationshipUpdateBy = 'P'
                            WHERE PartyID = @acc_party_id;

                           UPDATE [KYPEnrollment].[pAccount_PDM_Party]
                              SET LastMOCAUpdateBy = 'P'
                            WHERE PartyID = @acc_party_id;
                        END

                     IF @table_code = 'significantSubTable'
                        BEGIN
                           PRINT 'delete Significant table rad 1'

                           UPDATE [KYPEnrollment].pAccount_PDM_OwnershipRelationship
                              SET isDeleted = 1, CurrentRecordFlag = 0
                            WHERE OwnerRelationID = @acc_PK_value
                        END
                  END
               ELSE
                  BEGIN
                     EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,
                                                            @en_db_column,
                                                            NULL,
                                                            @acc_PK,
                                                            @acc_PK_value,
                                                            @is_text_date,
                                                            @stored_value,
                                                            @last_action_user_id,
                                                            @action_taken;
                  END
            END
      END
END
GO

