
/* ==========================================================
-- Author:		<Digital Harbor>
-- PROCEDURE: create Sole Proprietor Crossover Only Provider Packages.   
-- PARAMETERS: 
-- @new_Party_Id : partyID to new Account that will be create. 
-- @party_Id : partyID Application that will be Account. 
-- @last_Action_User_ID : this is the user Enrollment.
-- @application_no : Application Number that will be Account. 
-- @application_Id : ApplicationID that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ISP_ISP_COP_AP]	(
    @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT, 
	@last_Action_User_ID VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@account_type VARCHAR(10),
	@application_type VARCHAR(40))

AS
BEGIN
	DECLARE @new_Address_Id INT,
	@new_person_id INT,
	@party_contact_id INT,
	@party_contact_id_portal INT,
	@npi_Type VARCHAR(25),
	@npi VARCHAR (10),
	@provider_type_code VARCHAR(5),
	@account_number VARCHAR(20),
	@isGroup BIT ;

	SELECT @npi_Type = [NPIType], @npi =NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id

	 select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id
	
	/*Individual Profile*/
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Personal_Inf_Crossover_Identification] @new_Party_Id, @party_Id,@last_Action_User_ID;
	--EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Individual Profile', @last_Action_User_ID;
	
	/*Business Profile*/
	EXEC [KYPEnrollment].[sp_Copy_Business_Profile]@new_Party_Id, @party_Id,@last_Action_User_ID;
	
	/*Contact Person*/
	EXEC [KYPEnrollment].[sp_Contact_Person] @party_Id, @new_Party_Id,@last_Action_User_ID,@new_Account_Id;
	
	/*Address*/
	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Mailing', @last_Action_User_ID;
	 
	/* Taxonomy Speciality */
	EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id, @party_Id, @last_Action_User_ID, NULL;
	
	/* PaymentDetail */
	EXEC [KYPEnrollment].[sp_Copy_PaymentDetail] @party_Id, @new_Party_Id, @last_Action_User_ID;
	
	/*BizProfile Details*/
	-- DISABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,@new_Account_Id,@new_Party_Id,@last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';
	-- ENABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	
	/*Unique Party*/
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account]@new_Party_Id, @new_account_id, @npi_Type, @last_Action_User_ID,0;
	
	/*Update data Account and Linked*/
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id,	@party_Id, 0, @provider_type_code, @account_number, NULL,@account_type,@application_Id, @isGroup, @application_type;
		
END


GO

