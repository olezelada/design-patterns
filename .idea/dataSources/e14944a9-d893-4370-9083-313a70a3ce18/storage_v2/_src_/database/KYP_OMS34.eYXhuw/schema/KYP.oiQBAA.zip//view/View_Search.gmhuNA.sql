CREATE VIEW [KYP].[View_Search]
AS
SELECT     TOP (100) PERCENT row_number() OVER (ORDER BY KYP.ADM_Case.CaseID ASC) AS ID, KYP.ADM_Case.CaseID, 
KYP.ADM_Application.CaseID AS Expr1, KYP.ADM_Application.ApplicationID, KYP.SDM_ApplicationParty.ApplicationID AS Expr2, 
KYP.SDM_ApplicationParty.PartyID, KYP.PDM_Party.PartyID AS Expr3, KYP.PDM_Person.SSN
FROM         KYP.ADM_Case INNER JOIN
                      KYP.ADM_Application ON KYP.ADM_Case.CaseID = KYP.ADM_Application.CaseID INNER JOIN
                      KYP.SDM_ApplicationParty ON KYP.ADM_Application.ApplicationID = KYP.SDM_ApplicationParty.ApplicationID INNER JOIN
                      KYP.PDM_Party ON KYP.SDM_ApplicationParty.PartyID = KYP.PDM_Party.PartyID INNER JOIN
                      KYP.PDM_Person ON KYP.PDM_Party.PartyID = KYP.PDM_Person.PartyID


GO

