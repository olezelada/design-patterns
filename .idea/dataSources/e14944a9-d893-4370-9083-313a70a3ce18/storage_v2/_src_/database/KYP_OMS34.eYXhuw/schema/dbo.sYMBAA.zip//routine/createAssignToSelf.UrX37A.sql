-- =============================================
-- Author:		<Sheetal>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[createAssignToSelf] 
	@AlertNo varchar(MAX),
	@JournalEvent varchar(50),
	@Username varchar(25),
	@AssignToUserID int
	
	,@RelatedEntityType varchar(50),
	@NotesDescription varchar(max),
	@NotesTitle varchar(120),
	@Number varchar(20),
	@Currenttag varchar(5),
	@Type varchar(100),
	
	@SubType varchar(100)
	
	,@FormattedContent varchar(max) /* KYP 3.4 - SCREEN 16 */
	
AS
BEGIN
	Declare 
    @AlertID int,
    @CurrentWFStatus varchar(50),
    @Description varchar(500),
    @PersonID int,
    @FirstName varchar(25),
    @LastName varchar(25),
    @Name varchar(100),
    @CurrentDate datetime,
    @JournalDescription varchar(250),
    @FullName varchar(200),
    @index int,
    @sliceOfStringValue varchar(2000),
    @StringValue varchar(max), 
    @Delimiter char(1),
   
	
	@NoteID int,
    @Notenumber varchar(15),
    @NoteEntityType varchar(100),
    @NoteEntityTypeID varchar(100),
    @NoteEntityDepID varchar(100),
    @NoteEntityDep varchar(100),
    @Level int,
    @SmartletParameter varchar(500),
    @IsLastLevel bit,
    @RelatedEntityID int,
    @CaseID int,
    @IsExistID int,
    @NoteCount int
       
    Select @PersonID=PersonID from KYP.OIS_User where UserID=@Username
    Select @FullName=Fullname from KYP.OIS_User where PersonID =@AssignToUserID 
    --Select @FullName=FullName from KYP.OIS_Person where PersonID=@PersonID
    Select @FirstName=FirstName from KYP.OIS_Person where PersonID=@PersonID
    Select @LastName=LastName from KYP.OIS_Person where PersonID=@PersonID
    Select @Name= @LastName +  COALESCE((', ' + @FirstName), '') 
    	
    Select @CurrentDate=getdate()
    
    
    Select @Description='Alert acknowledged by'+' '+ @Name 
    --Set @Description ='Test'
 
    select @StringValue=@AlertNo
    select @Delimiter=','
   
      Select @index = 1    
            --if len(@StringValue)<1 or @StringValue is null  return    
    
      while @index!= 0    
      begin    
            Select @index = charindex(@Delimiter,@StringValue)    
            
            if @index!=0 
            begin   
                  Select @sliceOfStringValue = left(@StringValue,@index - 1) 
                  --select left(@StringValue,@index - 1)   
            end      
            else    
                  Select @sliceOfStringValue = @StringValue    
           
            if(len(@sliceOfStringValue)>0)
              --select @sliceOfStringValue    
       
            Select @StringValue = right(@StringValue,len(@StringValue) - @index)    
            if len(@StringValue) = 0 break    
            
      
            Select @AlertID=AlertID from KYP.MDM_Alert where AlertNo=@sliceOfStringValue
            Select @CurrentWFStatus=CurrentWFStatus from KYP.MDM_Alert where AlertID=@AlertID
            
      ------Insert into journal---------
      insert into KYP.MDM_AlertJournal 
     
          Select AlertID,'Business Event',@Description,getdate(),NULL,getdate(),@PersonID,NULL
         ,NULL,NULL,NULL,0 from kyp.MDM_Alert where AlertID=@AlertID
         
         union all
         
          Select ChildAlertID,'Business Event',@Description,getdate(),NULL,getdate(),@PersonID,NULL
         ,NULL,NULL,NULL,0 from KYP.MDM_RelatedAlerts where ParentAlertID=@AlertID and 
         RelationshipType='Merged' and ISNULL(IsDeleted,0)=0
         
      --------Update MDM_Alert table -----------------------------------------------
      
       if (@CurrentWFStatus='AssignAlert' or @CurrentWFStatus='AcceptAssignment')
       begin
        update KYP.MDM_Alert set StatusCodeNumber=10,AssignedByUserID=@PersonID,AssignedToUserID=@AssignToUserID,
          AssignedDate=getdate(), CurrentWFMinorStatus ='Confirm Match',CurrentMinorDisposition='In Progress',
          CurrentMajorDisposition='Alert Resolution',CurrentWFStatus='ConfirmMatch',ActivityStatus='Open',Assignee=@FullName
          where AlertID in
        (
         Select AlertID from KYP.MDM_Alert where AlertID=@AlertID
         union all
         Select ChildAlertID from KYP.MDM_RelatedAlerts where 
         ParentAlertID=@AlertID and RelationshipType='Merged' and ISNULL(IsDeleted,0)=0
        )
       end
       else
       begin
            update KYP.MDM_Alert set StatusCodeNumber=10,AssignedByUserID=@AssignToUserID,AssignedToUserID=@AssignToUserID,
            AssignedDate=getdate(), ActivityStatus='Open',Assignee=@FullName
            where AlertID in
             (
                Select AlertID from KYP.MDM_Alert where AlertID=@AlertID
                union all
                Select ChildAlertID from KYP.MDM_RelatedAlerts where 
                ParentAlertID=@AlertID and RelationshipType='Merged' and ISNULL(IsDeleted,0)=0
             )
       end
       
       
       
       ----Notes creation
       select @RelatedEntityID= @AlertID
       
 IF (@FormattedContent IS NULL)		/* KYP 3.4 - SCREEN 16 */
 BEGIN
		SET @FormattedContent = @NotesDescription
 END
   
 exec @NoteID = [KYP].[p_InsertOISNote]	
 @UserID=@Username,@Name=@NotesTitle,@Type=@Type,@SubType=@SubType,
 @ParentID=0, @DateCreated = @CurrentDate, @Author=@Name,@RelatedEntityType =@RelatedEntityType,
 @Content= @FormattedContent, @UnformattedContent=@NotesDescription , @Number=@Number , 
 @VersionNo =1, @isWorkpaper=0, @isAcknowledged=0 , @WorkflowName=NULL, @isAdverse=0,
 @Deleted=0, @DeletedOn=NULL, @DeletedBy=NULL , @DeletedByUserID=NULL , @UpdatedOn=NULL,
 @UpdatedBy =NULL, @UpdatedByUserID=NULL , @IsImportant=0 , @IsLastVersion=1 , @IsSticky=0 ,
 @IsReferenced=0 , @HasComments=0 , @HasDocuments=0 , @NumberSchemaInfo=@Number , @LastVersion =1,
 @AllowComments =0, @RestoredBy=NULL , @RestoredByUserID=NULL , @CaseID=NULL , @AlertID =NULL,
 @IncidentID =NULL, @Tags =NULL, @FullDateCreated=NULL , @RelatedEntityID=@RelatedEntityID , @Importance='Low',
 @Score =0, @DMSID =NULL, @DocumentCount=NULL ,@MultipleCaseID=NULL,@MultipleTrackingNo=NULL,@PInID=NULL 
   
   
           
      if @Currenttag is null
      begin
          INSERT INTO [KYP].[OIS_Tag]
           ([Tag])
          VALUES
           (',')
      end
      
           INSERT INTO [KYP].[OIS_JT_NoteTag]
           ([NoteID]
           ,[Tag])
      VALUES
           (@NoteID
           ,',')
           
           
    --Get the notenumber------
    
    exec [KYP].[p_GenerateNoteNumber] @NoteID,
    @Notenumber=@Notenumber output
    
    /******* Updating note number in OIS_Note***********/ 
    update KYP.OIS_Note set Number= @Notenumber where NoteID= @NoteID
    
    /********Creating Journal entry********************/
    
   Select  @JournalDescription='Notes Added-'+' '+@Type+' '+@Notenumber+' '+'was added to'+' '+@RelatedEntityType
    
    INSERT INTO [KYP].[OIS_Journal]
           ([UserID],[ACTIONID],[Date_x],[DESCRIPTION],[EntityTable],[Entity],[EntityID],[CaseID]
           ,[ShortDescription])
     VALUES
           (@Username,1,@CurrentDate,@JournalDescription,'OIS_Note','Note',@NoteID,@CaseID
           ,@JournalDescription)
           
  /**********Segregate the smartlet parameter for noteentity entry************/  
    
    Select @SmartletParameter='MDM_Alert-'+convert(varchar(10),@AlertNo)
    
 
    select 
    @NoteEntityType =NoteEntityType,
    @NoteEntityTypeID =NoteEntityTypeID,
    @NoteEntityDepID =NoteEntityDepID,
    @NoteEntityDep= NoteEntityDep,
    @Level =Level,
    @IsLastLevel=IsLastLevel
    from  simple_intlist_to_tbl(@SmartletParameter)       
     
     
     /********Insert into Noteentity*************/
     INSERT INTO [KYP].[NoteEntity]
           ([NoteNumber]
           ,[NoteEntityType]
           ,[NoteEntityDep]
           ,[NoteEntityTypeID]
           ,[NoteEntityDepID]
           ,[Level]
           ,[IsLastLevel])
    
           select @Notenumber
           ,NoteEntityType
           ,NoteEntityDep
           ,NoteEntityTypeID
           ,NoteEntityDepID
           ,Level
           ,IsLastLevel from  simple_intlist_to_tbl(@SmartletParameter)  
       
     
           
      select @IsExistID= ParentID from  KYP.NoteCounts where ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
      
     
      
      
      Select @NoteCount=count(RelatedEntityID) from KYP.OIS_Note where RelatedEntityID=@RelatedEntityID 
      and RelatedEntityType=@RelatedEntityType and (Deleted is null or Deleted=0)
      
      if @IsExistID =0
      begin
     
      
       INSERT INTO [KYP].[NoteCounts]
           ([ParentID]
           ,[ParentTable]
           ,[Counts])
        VALUES
           (@RelatedEntityID,
           @RelatedEntityType,
           @NoteCount)
      end
      else
      begin
       UPDATE [KYP].[NoteCounts]
        SET [ParentID] = @RelatedEntityID
      ,[ParentTable] = @RelatedEntityType
      ,[Counts] = @NoteCount
       WHERE ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
       
      end --if @IsExistID
      
      
     Select @IsExistID=0
     select @NoteCount=0
       
       
      END -- End WHILE
	
	END
GO

