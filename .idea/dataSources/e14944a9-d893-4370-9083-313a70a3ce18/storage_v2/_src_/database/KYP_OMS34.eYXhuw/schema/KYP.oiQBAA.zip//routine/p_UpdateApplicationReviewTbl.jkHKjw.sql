
CREATE PROCEDURE KYP.p_UpdateApplicationReviewTbl 

AS    
      
BEGIN
BEGIN TRANSACTION 
-----------step-1-delete-table-------------
DELETE FROM [KYP].[SDM_Application_Review]
-----------step-1-delete-table-------------
SET DATEFIRST 1;
-----------step-2-insert-table-------------
INSERT INTO [KYP].[SDM_Application_Review]
(
WEEK_NUMBER,
WEEK_START_DATE,
WEEK_END_DATE,
Applications_Processed,
IndProv_Applications,
IndProv_Negative_NPI,
IndProv_Unknown_NPI,
OrgProv_Applications,
OrgProv_Negative_NPI,
OrgProv_Unknown_NPI,
Total_Negative_NPI_ALL,
OrgProv_AllMatch_Unknown   --added to fix KYP-7204,7202
)
SELECT
DATEPART(week,  DateCreated),
MIN(DateCreated),
MIN(DateCreated),
COUNT(*) AS Applications_Processed,
SUM(INDIVIDUAL_PROVIDER) AS IndProv_Applications,
SUM(IND_PROV_NEGATIVE) AS IndProv_Negative_NPI,
SUM(IND_PROV_UNKNOWN) AS IndProv_Unknown_NPI,
SUM(ORGANISATION_PROVIDER) AS OrgProv_Applications,
SUM(ORG_PROV_NEGATIVE) AS OrgProv_Negative_NPI,
SUM(ORG_PROV_UNKNOWN) AS OrgProv_Unknown_NPI,
(SUM(IND_PROV_NEGATIVE)+SUM(ORG_PROV_NEGATIVE)) AS Total_Negative_NPI_ORG_AND_IND,
SUM(ORG_PROV_ALLUNKNOWN) AS ORG_PROV_ALLUNKNOWN --added to fix KYP-7204,7202
FROM
(
      SELECT 
      META_TABLE.Number,
      MAX(DateCreated)AS DateCreated,
      MAX(INDIVIDUAL_PROVIDER)AS INDIVIDUAL_PROVIDER,
      MAX(ORGANISATION_PROVIDER)AS ORGANISATION_PROVIDER,
      MAX(IND_PROV_NEGATIVE)AS IND_PROV_NEGATIVE,
      MAX(ORG_PROV_NEGATIVE)AS ORG_PROV_NEGATIVE,
      MAX(IND_PROV_UNKNOWN)AS IND_PROV_UNKNOWN,
      MAX(ORG_PROV_UNKNOWN)AS ORG_PROV_UNKNOWN,
      MAX(ORG_PROV_ALLUNKNOWN) AS ORG_PROV_ALLUNKNOWN --added to fix KYP-7204,7202
      FROM 
      (
            SELECT 
            KYP.ADM_Case.Number ,
            KYP.ADM_Case.DateCreated,
            KYP.ADM_Application.ApplicationID ,
            KYP.SDM_ApplicationParty.ScreeningID ,
                  KYP.SDM_ApplicationParty.PartyType, 
            KYP.SDM_DBCheckResult.DBChkResultID ,
            KYP.SDM_DBCheckResult.NPI ,
            KYP.SDM_DBCheckDetail.HMS_RefID ,
            KYP.SDM_HMSData.HMSID,
            CASE
            WHEN KYP.ADM_Case.SubType='Physician'  THEN 1
            ELSE 0
            END AS INDIVIDUAL_PROVIDER,
            CASE
            WHEN KYP.ADM_Case.SubType='Physician'  AND KYP.SDM_DBCheckResult.NPI ='F'  THEN 1
            ELSE 0
            END AS IND_PROV_NEGATIVE,
            CASE
            WHEN KYP.ADM_Case.SubType='Physician' AND (KYP.SDM_DBCheckResult.NPI IN ('U','X','Y') OR KYP.SDM_DBCheckResult.NPI IS NULL)THEN 1
            ELSE 0
            END AS IND_PROV_UNKNOWN,
            CASE
            WHEN KYP.ADM_Case.SubType='Institutional'  THEN 1
            ELSE 0
            END AS ORGANISATION_PROVIDER,
            CASE
            WHEN KYP.ADM_Case.SubType='Institutional'  AND KYP.SDM_DBCheckResult.NPI ='F'  THEN 1
            ELSE 0
            END AS ORG_PROV_NEGATIVE,
            CASE
            WHEN KYP.ADM_Case.SubType='Institutional'  AND (KYP.SDM_DBCheckResult.NPI IN ('U','X','Y') OR KYP.SDM_DBCheckResult.NPI IS NULL)THEN 1
            ELSE 0
            END AS ORG_PROV_UNKNOWN,
            -----------------------------------
            CASE --added to fix KYP-7204,7202
            WHEN KYP.ADM_Case.SubType='Institutional'  
            AND KYP.SDM_ApplicationParty.ScreeningID IS NOT NULL
            AND 
            (
            (KYP.SDM_DBCheckResult.NPI IN ('U','X','Y') OR KYP.SDM_DBCheckResult.NPI IS NULL)
            AND (KYP.SDM_DBCheckResult.DEA IN ('U','X','Y') OR KYP.SDM_DBCheckResult.DEA IS NULL)
            AND (KYP.SDM_DBCheckResult.CLIA IN ('U','X','Y') OR KYP.SDM_DBCheckResult.CLIA IS NULL)
            AND (KYP.SDM_DBCheckResult.TIN IN ('U','X','Y') OR KYP.SDM_DBCheckResult.TIN IS NULL)
            AND (KYP.SDM_DBCheckResult.City IN ('U','X','Y') OR KYP.SDM_DBCheckResult.City IS NULL)
            )THEN 1
            ELSE 0
            END AS ORG_PROV_ALLUNKNOWN --added to fix KYP-7204,7202
            -----------------------------------
            FROM KYP.ADM_Case
            LEFT JOIN  KYP.ADM_Application ON  KYP.ADM_Case.CaseID = KYP.ADM_Application.CaseID 
            LEFT JOIN  KYP.SDM_ApplicationParty ON  KYP.ADM_Application.ApplicationID = KYP.SDM_ApplicationParty.ApplicationID    AND KYP.SDM_ApplicationParty.IsActive =1  AND KYP.SDM_ApplicationParty.PartyType = 'Provider'
            LEFT JOIN  KYP.SDM_DBCheckResult ON KYP.SDM_DBCheckResult.ScreeningID = KYP.SDM_ApplicationParty.ScreeningID 
            LEFT JOIN  KYP.SDM_DBCheckDetail ON KYP.SDM_DBCheckDetail.DBChkResultID = KYP.SDM_DBCheckResult.DBChkResultID
            LEFT JOIN  KYP.SDM_HMSData ON KYP.SDM_HMSData.ID = KYP.SDM_DBCheckDetail.HMS_RefID
            WHERE KYP.ADM_Case.Number IS NOT NULL 
            AND KYP.ADM_Case.DateCreated IS NOT NULL
            --AND DATEPART(week,  GETDATE()) > DATEPART(week,  KYP.ADM_Case.DateCreated)
            --Getting data for the 90 days periods
            AND KYP.ADM_Case.DateCreated > (GETDATE()-90)


      )META_TABLE
      group by Number
)REVIEW_TABLE 
GROUP BY DATEPART(week,  DateCreated)
-----------step-2-insert-table-------------
SET DATEFIRST 7; --added to fix KYP-7204,7202
UPDATE [KYP].[SDM_Application_Review] set WEEK_START_DATE = CASE when DATEPART(WEEKDAY, WEEK_START_DATE) = 1 THEN DATEADD(DAY, -6, WEEK_START_DATE)
ELSE DATEADD(DAY, (2-DATEPART(WEEKDAY, WEEK_START_DATE)), WEEK_START_DATE)END;
UPDATE [KYP].[SDM_Application_Review] set WEEK_END_DATE =CASE when DATEPART(WEEKDAY, WEEK_END_DATE) = 1 THEN WEEK_END_DATE 
ELSE DATEADD(DAY, (8-DATEPART(WEEKDAY, WEEK_END_DATE)), WEEK_END_DATE)END;
--added to fix KYP-7204,7202
-----------step-3-update-Review_Period-column-------------
UPDATE [KYP].[SDM_Application_Review]
--fix for KEN-17660
SET [Review_Period] = CONVERT(varchar(10),WEEK_START_DATE,101)+' - '+CONVERT(varchar(10),WEEK_END_DATE,101)
--SET [Review_Period] = CONVERT(VARCHAR(6),  CONVERT(VARCHAR(12), WEEK_START_DATE, 106), 1) 
--+' - '+CONVERT(VARCHAR(6), CONVERT(VARCHAR(12), WEEK_END_DATE, 106) , 1) ;
-----------step-3-update-Review_Period-column-------------
COMMIT TRANSACTION
END


GO

