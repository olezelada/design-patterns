-- =============================================
-- Author:		Sheetal
-- Create date: Aug 10 2012
-- Description:	Finds if CaseID already exists
-- =============================================
CREATE PROCEDURE [KYP].[p_FindADMApplicationRecord]
	-- Add the parameters for the stored procedure here
	@CaseID int 
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @ApplicationID int
	/********Check if CaseID already exists**********/
	if exists (	
	select 1
	from KYP.ADM_Application where CaseID = @CaseID 
	)
	begin	
	select @ApplicationID = ApplicationID
	from KYP.ADM_Application 
	where CaseID  = @CaseID 
	return @ApplicationID	
	end	
	else 
	return -1    	
END


GO

