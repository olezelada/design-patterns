
CREATE VIEW [KYPEnrollment].[v_ProfessionalData] As
select 
ROW_NUMBER() over(order by A.AccountID Desc) As RID,
REPLACE(LTRIM(RTRIM(ISNULL(A.LegalName,'NA'))),'','NA') As ProfessionalName,
REPLACE(LTRIM(RTRIM(ISNULL(A.ProviderType,'NA'))),'','NA') As ProviderType,
REPLACE(LTRIM(RTRIM(ISNULL(A.NPI,'NA'))),'','NA') As NPI,
REPLACE(LTRIM(RTRIM(ISNULL(A.StatusAcc,'NA'))),'','NA') As Status,
A2.AccountID,A2.PartyID,A2.ApplicationNumber,A.ProviderTypeCode
from KYPEnrollment.pAccount_RenderingAffiliation R
Join KYPEnrollment.pADM_Account A2 On R.AccountID = A2.AccountId --Group
Join kypenrollment.padm_Account A on R.AffiliatedAccountId= A.accountID --Affiliation


GO

