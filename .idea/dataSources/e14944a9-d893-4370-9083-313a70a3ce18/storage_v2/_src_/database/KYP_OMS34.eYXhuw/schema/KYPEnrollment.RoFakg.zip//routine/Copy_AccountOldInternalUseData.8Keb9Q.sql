











-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_AccountOldInternalUseData] 

@AccountID int, @AccountInternalUseID int, @LastActionComments varchar(255)
	
AS
BEGIN

Declare
	
		
	@BillingStatus varchar(30),
	@BillingBeginDate smalldatetime,
	@BillingEndDate smalldatetime,
	@BillingFutureStatus varchar(30),
	@BillingFutureDate smalldatetime,
	@BillingComments varchar(500),
	@BillingFutureComments varchar(500),
	@ProvisionalCode varchar(2),
	@ProvisionalCodeDate smalldatetime,
	@ProvisionalCodeDesc varchar(200),
	@LabStatusCode varchar(30),
	@LabSpecCodeDesc varchar(200),
	@LabStatusCodeDate smalldatetime,
	@OutOfStateInd varchar(1),
	@OutOfStateIndDesc varchar(200),
	@SpecProcTypeCodeDesc varchar(200),
	@SpecProcTypeCode varchar(10),
	@ProvCrossReferenceValue varchar(20),
	@CHDPCode varchar(150),
	@AtypicalProviderNo varchar(11),
	--@PhyCertCode varchar(2),
	--@PhyCertCodeDesc varchar(200),
	--@PhyCertCodeEfDate smalldatetime,
	@ReEnrolInd varchar(10),
	@ReEnrolDate smalldatetime,
	@PracTypeCode1 varchar(1),
	@PracTypeCode1Desc varchar(250),
	@PracTypeCode2 varchar(1),
	@PracTypeCode2Desc varchar(250),
	@TINUpdateType varchar(5),
	@TINUpdateTypeDesc varchar(250),
	@TINUpdateDate smalldatetime,
	@AccInternalUseID int,
	@County varchar(2),
	@CountyDesc varchar(25),
	@PrevProviderNo varchar(20),
	@AuditIndicator varchar(1),
	@AuditDate datetime,
	@PracTypeCode varchar(3),
	@EPSDT varchar(5),
	@StatusAcc varchar(200),
	@StatusBeginDate smalldatetime,
	@StatusReasonCode varchar(6000),
	@EnrollStatusComments varchar(500),
	@MDLToMDC bit,
	@MDCToMDL bit,
	@ApplnType varchar(200),
	@CrossOverApp varchar(10),
	@ProviderTypeCode varchar(20),
	@ProviderTypeCodeNumber varchar(20),
	@ResolutionStatus varchar(200),
	@OwnerNumber varchar(5),
	@SreviceLocationNumber varchar(5),
	@ownerEffectiveDate smalldatetime

	
Declare
	
    @CodeIdentification varchar(10),
    @CodeDescription varchar(250),
    @CodeType varchar(10),
    @CreatedBy varchar(100),
    @CodeDateEffDate smalldatetime,
    @CodeDateExpDate smalldatetime,
    @state varchar(10),
    @SppReasonCode varchar(100);

	select @state=StateCode from KYP.OIS_App_Version

    
	SELECT @BillingStatus =[BillingStatus],@BillingBeginDate =[BillingBeginDate],@BillingEndDate =[BillingEndDate],
	@BillingFutureStatus =[BillingFutureStatus],@BillingFutureDate =[BillingFutureDate],@BillingComments =[BillingComments],
	@BillingFutureComments =[BillingFutureComments],@ProvisionalCode =[ProvisionalCode],@ProvisionalCodeDate =[ProvisionalCodeDate],
	@ProvisionalCodeDesc =[ProvisionalCodeDesc],@LabStatusCode =[LabStatusCode],@LabSpecCodeDesc =[LabSpecCodeDesc],@LabStatusCodeDate =[LabStatusCodeDate],
	@OutOfStateInd =[OutOfStateInd],@OutOfStateIndDesc =[OutOfStateIndDesc],@SpecProcTypeCode =[SpecProcTypeCode],@SpecProcTypeCodeDesc =[SpecProcTypeCodeDesc],
	@ProvCrossReferenceValue =[ProvCrossReferenceValue],@CHDPCode =[CHDPCode], @AtypicalProviderNo =[AtypicalProviderNo],@ReEnrolInd =[ReEnrolInd],@ReEnrolDate =[ReEnrolDate],
	--@PhyCertCode =[PhyCertCode],@PhyCertCodeDesc =[PhyCertCodeDesc],@PhyCertCodeEfDate =[PhyCertCodeEfDate],
	@PracTypeCode1 =[PracTypeCode1], @PracTypeCode1Desc=[PracTypeCode1Desc],
	@PracTypeCode2 =[PracTypeCode2],@PracTypeCode2Desc =[PracTypeCode2Desc],@TINUpdateType =[TINUpdateType], @TINUpdateTypeDesc=[TINUpdateTypeDesc],
	@TINUpdateDate =[TINUpdateDate],@County=County, @CountyDesc=CountyDesc, @PrevProviderNo=PrevProviderNo, @AuditIndicator=AuditIndicator,
	@AuditDate=AuditDate,  @PracTypeCode=PracTypeCode, @EPSDT=EPSDT,@ProviderTypeCode=ProviderTypeCode FROM [KYPEnrollment].[EDM_AccountInternalUse]
	WHERE AccountID =@AccountID
	
	select @StatusAcc=StatusAcc,@StatusBeginDate=StatusBeginDate,@StatusReasonCode=StatusReasonCode,@EnrollStatusComments=EnrollStatusComments,
	@OwnerNumber=ownerno,@SreviceLocationNumber=ServiceLocationNo,@SppReasonCode=StateStatusAcc
	from KYPEnrollment.pADM_Account where AccountID =@AccountID
	
	select @ownerEffectiveDate=EffectiveBeingDate from 
	kypenrollment.pAccount_Owner where AccountID=@AccountID
	
	select @ResolutionStatus=ResolutionStatus from KYP.ADM_Case where Number=@LastActionComments
	

	declare @AppCount int;
	
	SELECT @AppCount = COUNT(AccInternalUseManyID) FROM [KYPEnrollment].[EDM_AccountInternalMany]
	WHERE AccountInternalUseID =@AccountInternalUseID 		
	
	select @MDLToMDC=MDLToMDC,@MDCToMDL=MDCToMDL,@ApplnType=ApplnType,@CrossOverApp=CrossOverApp from KYP.ADM_Case where Number=@LastActionComments
	
	if(@ApplnType = 'Supplemental'and(@MDLToMDC=1 or @MDCToMDL=1))
	 begin
		set @StatusAcc=null
		set @StatusBeginDate=null
		set @StatusReasonCode=null
		set @EnrollStatusComments=null
		set @BillingStatus=null
		set @BillingBeginDate=null
		set @ProvisionalCode= null --case when((@MDLToMDC=1)and (@ResolutionStatus!='Close without account update')) then NULL --else null end 
		set @ProvisionalCodeDate= null--case when((@MDLToMDC=1)and (@ResolutionStatus!='Close without account update'))then  NULL --else null end 
		set @ProvisionalCodeDesc=null --case when((@MDLToMDC=1)and (@ResolutionStatus!='Close without account update'))then NULL --else null end
	 end
	

	UPDATE [KYPEnrollment].[EDM_SupplementalInternalUse]
	SET
	 BillingStatus = @BillingStatus 
	,BillingBeginDate = @BillingBeginDate 
	,BillingEndDate = @BillingEndDate 
	--,BillingFutureStatus = @BillingFutureStatus
	,BillingFutureDate = @BillingFutureDate
	,BillingComments = @BillingComments
	,BillingFutureComments = @BillingFutureComments
	,ProvisionalCode = @ProvisionalCode
	,ProvisionalCodeDate = @ProvisionalCodeDate
	,ProvisionalCodeDesc = @ProvisionalCodeDesc
	,LabStatusCode = @LabStatusCode
	,LabSpecCodeDesc = @LabSpecCodeDesc
	,LabStatusCodeDate = @LabStatusCodeDate
	,OutOfStateInd = @OutOfStateInd
	,OutOfStateIndDesc = @OutOfStateIndDesc
	,SpecProcTypeCode = @SpecProcTypeCode
	,SpecProcTypeCodeDesc = @SpecProcTypeCodeDesc
	,ProvCrossReferenceValue = @ProvCrossReferenceValue
	,CHDPCode = @CHDPCode
	,AtypicalProviderNo = @AtypicalProviderNo
	--,PhyCertCode = @PhyCertCode
	--,PhyCertCodeDesc = @PhyCertCodeDesc
	--,PhyCertCodeEfDate = @PhyCertCodeEfDate
	,ReEnrolInd = @ReEnrolInd
	,ReEnrolDate = @ReEnrolDate
	,PracTypeCode1 = @PracTypeCode1
	,PracTypeCode1Desc = @PracTypeCode1Desc
	,PracTypeCode2 = @PracTypeCode2
	,PracTypeCode2Desc = @PracTypeCode2Desc
	,TINUpdateType = @TINUpdateType
	,TINUpdateTypeDesc = @TINUpdateTypeDesc
	,TINUpdateDate = @TINUpdateDate
	,County=@County
	,CountyDesc=@CountyDesc
	,PrevProviderNo=@PrevProviderNo
	,AuditIndicator=@AuditIndicator
	,AuditDate=@AuditDate
	,PracTypeCode=@PracTypeCode
	,EPSDT=@EPSDT
	,StatusAcc=@StatusAcc
	,StatusBeginDate=@StatusBeginDate
	,StatusReasonCode=@StatusReasonCode
	,EnrollStatusComments=@EnrollStatusComments
	,ProvCrossReferenceCode=@SreviceLocationNumber
	,BillingFutureStatus=@OwnerNumber
	,ownerEffectiveDate=@ownerEffectiveDate
	--,ProviderTypeCode=@ProviderTypeCode
	WHERE AccountID = @AccountID AND LastActionComments = @LastActionComments;
	SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_SupplementalInternalUse] WHERE AccountID=@AccountID AND LastActionComments = @LastActionComments
	
	

	Declare @accManyUserID int;
	
	SELECT @AppCount = COUNT(1)
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID 
	AND CurrentRecordFlag = 1 and isnull(isDeleted,0) = 0 

	if(@state='MD')
		BEGIN 
			update  kypenrollment.padm_account Set SuppStatusAcc=@StatusAcc, SuppReasonCode=@SppReasonCode, SuppBeginDate=@StatusBeginDate 
			where AccountID=@AccountID
		END
	
	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.AccInternalUseManyID FROM(
		SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
		FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID 
		AND CurrentRecordFlag = 1 and isnull(isDeleted,0) = 0)X WHERE X.RowNumber = @AppCount
	
		SELECT @CodeIdentification =[CodeIdentification],@CodeDescription =[CodeDescription],@CodeType =[CodeType],
		@CodeDateEffDate =[CodeDateEffDate],@CodeDateExpDate =[CodeDateExpDate],@CreatedBy =[CreatedBy]
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID =@accManyUserID
		
		INSERT INTO [KYPEnrollment].[EDM_SupplementalInteranlMany]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[AccountInternalManyID]
		)
		VALUES(
		@AccInternalUseID,
		@CodeIdentification 
		,@CodeDescription 
		,@CodeType 
		,@CodeDateEffDate
		,@CodeDateExpDate
		,@CreatedBy
		,@accManyUserID)
		
		SET @AppCount = @AppCount - 1
	
	END
	
END


GO

