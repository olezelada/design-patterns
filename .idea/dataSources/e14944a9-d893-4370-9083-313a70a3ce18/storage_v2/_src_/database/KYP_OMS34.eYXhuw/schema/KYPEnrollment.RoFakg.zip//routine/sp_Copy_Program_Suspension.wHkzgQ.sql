

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Program Suspention Table.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @type : Party type. 
-- @app_party_row_id : this is the PartyID Row to Application that will be Create in Update Account, it is Null when account is create.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Program_Suspension]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@type VARCHAR(200),
@app_party_row_id INT,
@account_id INT
AS
BEGIN 
DECLARE @party_app_prog_id INT,@party_acc_prog_id INT
IF @app_party_row_id IS NULL
	BEGIN
	    declare @progsus table (pk int identity(1,1),PartyID int)
		--DECLARE progSus_cursor CURSOR FAST_FORWARD READ_ONLY FOR
		--SELECT identity(int,1,1)as pk,PartyID 
		--into #progsus
		insert into @progsus
		select PartyID
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] 
		WHERE Type=@type AND ParentPartyID=@party_app_id AND IsDeleted = 0
		declare @cont int, @tot int
		select @tot=MAX(pk) from @progsus 
		set @cont=1
		
		while @cont<=@tot
		--OPEN progSus_cursor;
		--FETCH NEXT FROM progSus_cursor INTO @party_app_prog_id 
		--WHILE @@FETCH_STATUS = 0
		BEGIN
		    select @party_app_prog_id =partyid from @progsus where pk=@cont
			EXEC @party_acc_prog_id = [KYPEnrollment].[sp_Copy_Party] @party_app_prog_id, @party_account_id,@account_id,@last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_Adverse_Action]@party_acc_prog_id,@party_app_prog_id,@last_action_user_id,@type,NULL;
			EXEC [KYPEnrollment].[sp_Copy_Provider] @party_acc_prog_id,@party_app_prog_id,@last_action_user_id
			set @cont=@cont+1
			--FETCH NEXT FROM progSus_cursor INTO @party_app_prog_id 
		END
		--drop table #progsus
		--CLOSE progSus_cursor;
		--DEALLOCATE progSus_cursor;
	END
ELSE
	BEGIN
		EXEC @party_acc_prog_id = [KYPEnrollment].[sp_Copy_Party] @app_party_row_id, @party_account_id,@account_id,@last_action_user_id;
		EXEC [KYPEnrollment].[sp_Copy_Adverse_Action]@party_acc_prog_id,@app_party_row_id,@last_action_user_id,@type,NULL;
		EXEC [KYPEnrollment].[sp_Copy_Provider] @party_acc_prog_id,@app_party_row_id,@last_action_user_id
	END	
END


GO

