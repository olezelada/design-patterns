-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <04/10/2017>
-- Description:	<Copy all the transportation modes include vehicles and operators>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_All_transport]

    @new_Account_Id      INT,
    @new_Party_Id        INT,
    @party_Id            INT,
    @application_Id      INT,
    @application_type    VARCHAR(30),

    @last_Action_User_ID VARCHAR(100),
    @provider_type_code  VARCHAR(50)


AS
  BEGIN

    DECLARE @party_type VARCHAR(50), @party_aux INT, @new_party_son INT, @address_aux INT
    DECLARE @vehicles_aux TABLE(pk_vehicle INT IDENTITY (1, 1), Vehicleid_aux INT, party_id_aux INT);
    DECLARE @operators_aux TABLE(pk_operator INT IDENTITY (1, 1), Operatorid_aux INT, party_id_aux INT);
    DECLARE @tot_vehicles INT, @cont_vehicles INT, @add_vehicles INT, @new_add_vehicles INT, @loc_vehicles INT;
    DECLARE @tot_operators INT, @cont_operators INT, @add_operators INT, @new_add_operators INT, @loc_operators INT;


    SET NOCOUNT ON;


    IF '038' = @provider_type_code
      BEGIN


        EXEC [KYPEnrollment].[sp_copy_ModeOfTransportation]  @new_Party_Id, @party_Id, @last_Action_User_ID, 1, 0;

        --Vehicles:
        INSERT INTO @vehicles_aux  (Vehicleid_aux, party_id_aux)
          SELECT
            VehicleId,
            v.PartyId
          FROM KYPPORTAL.PortalKYP.pPDM_Vehicle v
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON v.PartyId = p.PartyID
          WHERE p.ParentPartyID = @party_Id AND Approved = 1 AND v.IsDeleted = 0 AND VehicleType = 'Aircraft' and v.IsDeleted=0 and p.IsDeleted=0

        SELECT @tot_vehicles = MAX(pk_vehicle)
        FROM @vehicles_aux;
        SET @cont_vehicles = 1;

        WHILE @cont_vehicles <= @tot_vehicles
          BEGIN

            SELECT
              @add_vehicles = Vehicleid_aux,
              @party_aux = party_id_aux
            FROM @vehicles_aux
            WHERE pk_vehicle = @cont_vehicles
            EXEC @new_party_son = [KYPEnrollment].[sp_Copy_Party]    @party_aux, @new_Party_Id, @new_Account_Id,
                                                                     @last_action_user_id
            EXEC [KYPEnrollment].[sp_Copy_Vehicle]  @new_party_son, @add_vehicles, @last_Action_User_ID;

            EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @new_Account_Id, @party_aux, @new_party_son

            EXEC [KYPEnrollment].[sp_Copy_Address]  @new_party_son, @party_aux, NULL, @last_Action_User_ID;

            SET @cont_vehicles = @cont_vehicles + 1


          END

        --Operators:
        INSERT INTO @operators_aux  (Operatorid_aux, party_id_aux)
          SELECT
            OperatorId,
            o.PartyId
          FROM KYPPORTAL.PortalKYP.pPDM_Operators o
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON o.PartyId = p.PartyID
          WHERE p.ParentPartyID = @party_Id AND Approved = 1 AND o.OperatorType = 'Pilot' and o.IsDeleted=0 and p.IsDeleted=0

        SELECT @tot_operators = MAX(pk_operator)
        FROM @operators_aux;
        SET @cont_operators = 1;

        WHILE @cont_operators <= @tot_operators
          BEGIN

            SELECT
              @add_operators = Operatorid_aux,
              @party_aux = party_id_aux
            FROM @operators_aux
            WHERE pk_operator = @cont_operators
            EXEC @new_party_son = [KYPEnrollment].[sp_Copy_Party]    @party_aux, @new_Party_Id, @new_Account_Id, @last_action_user_id

            EXEC [KYPEnrollment].[sp_Copy_Operator]  @new_party_son, @add_operators, @last_Action_User_ID;
            EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @new_Account_Id, @party_aux, @new_party_son

            SET @cont_operators = @cont_operators + 1

          END
        PRINT 'FOUND AIR'
      END

    IF '030' = @provider_type_code
      BEGIN


        EXEC [KYPEnrollment].[sp_copy_ModeOfTransportation]  @new_Party_Id, @party_Id, @last_Action_User_ID, 0, 1;

        --Vehicles:
        INSERT INTO @vehicles_aux  (Vehicleid_aux, party_id_aux)
          SELECT
            VehicleId,
            v.PartyId
          FROM KYPPORTAL.PortalKYP.pPDM_Vehicle v INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON v.PartyId = p.PartyID
          WHERE p.ParentPartyID = @party_Id AND Approved = 1 AND VehicleType IN ('Ambulance', 'Van', 'Non-Medical Vehicle') and v.IsDeleted=0 and p.IsDeleted=0

        SELECT @tot_vehicles = MAX(pk_vehicle)
        FROM @vehicles_aux;
        SET @cont_vehicles = 1;

        WHILE @cont_vehicles <= @tot_vehicles
          BEGIN

            SELECT
              @add_vehicles = Vehicleid_aux,
              @party_aux = party_id_aux
            FROM @vehicles_aux
            WHERE pk_vehicle = @cont_vehicles
            EXEC @new_party_son = [KYPEnrollment].[sp_Copy_Party]    @party_aux, @new_Party_Id, @new_Account_Id,
                                                                     @last_action_user_id
            EXEC [KYPEnrollment].[sp_Copy_Vehicle]  @new_party_son, @add_vehicles, @last_Action_User_ID;
            EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @new_Account_Id, @party_aux, @new_party_son

            SELECT @address_aux = a.AddressID
            FROM KYPPORTAL.PortalKYP.pPDM_Address a INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location l
                ON a.AddressID = l.AddressID
            WHERE l.PartyID = @party_aux
            EXEC [KYPEnrollment].[sp_Copy_Address]  @new_party_son, @party_aux, NULL, @last_Action_User_ID;

            SET @cont_vehicles = @cont_vehicles + 1

          END

        --Operators:
        INSERT INTO @operators_aux  (Operatorid_aux, party_id_aux)
          SELECT
            OperatorId,
            o.PartyId
          FROM KYPPORTAL.PortalKYP.pPDM_Operators o INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON o.PartyId = p.PartyID
          WHERE p.ParentPartyID = @party_Id AND Approved = 1 AND OperatorType IN ('AmbulanceDriver', 'LitterWheelchairVanDriver', 'Non-Medical Operator') and o.IsDeleted=0 and p.IsDeleted=0

        SELECT @tot_operators = MAX(pk_operator)
        FROM @operators_aux;
        SET @cont_operators = 1;

        WHILE @cont_operators <= @tot_operators
          BEGIN

            SELECT
              @add_operators = Operatorid_aux,
              @party_aux = party_id_aux
            FROM @operators_aux
            WHERE pk_operator = @cont_operators
            EXEC @new_party_son = [KYPEnrollment].[sp_Copy_Party]    @party_aux, @new_Party_Id, @new_Account_Id,
                                                                     @last_action_user_id

            EXEC [KYPEnrollment].[sp_Copy_Operator]  @new_party_son, @add_operators, @last_Action_User_ID;
            EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @new_Account_Id, @party_aux, @new_party_son
            SET @cont_operators = @cont_operators + 1
          END

        PRINT 'FOUND GROUND'
      END


  END
GO

