




CREATE VIEW [KYPEnrollment].[Vw_MD_InputDoc_FullLoad] as
		SELECT 
			A.AccountID As AccountID	
			,A.LegacyAccountNo MAID						
			,A.NPI	
			,Case When A.NPIType = 'Individual' Then P.FirstName+' '+Isnull(LEft(P.MiddleName,1),'')+' '+P.LastName
				  When A.NPIType = 'Organization' Then Q.LegalName 
				  Else NULL End LegalName
			,Convert(varchar(10),E.DoB,101) DOB
			,H.AddressLine1 AS SAddressLine1
			,H.AddressLine2 AS SAddressLine2
			,H.City AS SCity
			,H.Abreviation AS SState
			,H.ZipPlus4 AS SZipPlus4
			,C.County --Changed for mapping table from Pdm_Address to Edm_AccountInternalUse
			,C.OutOfStateInd
			,(
			Case when (A.NPIType = 'Individual') 
					then S.Phone1 
			Else Q.Phone1
			end   
			) Phone1
			,A.ProviderType
			,Case When A.NPIType = 'Individual' Then P.LastName+' '+P.FirstName+' '+Isnull(LEft(P.MiddleName,1),'')
				  When A.NPIType = 'Organization' Then Q.LegalName 
				  Else NULL End as Sort
			,A.EIN as TaxID							
			,A.SSN
			,J.Number LicNo
			,Convert(varchar(10),J.EffectiveDate,101) LicBeginDate
			,Convert(varchar(10),J.ExpirationDate,101) LicEndDate
			,K.CliaNumber
			,K.RegistrationNumber LabPermitNumber			
			,I.DEA
			,C.PracTypeCode									
			,Convert(varchar(10),A.ReenrollmentDate,101) RevalidationDate --Changed for mapping table from Edm_AccountInternalUse to Padm_Account.ReenrollmentDate
			,Convert(varchar(10),(Case when A.LegacyAccountNo is NOT null then A.ApplicationDate
					else AC.DateCreated
					End),101) ApplicationDate			
			--,Convert(varchar(10),A.ApplicationDate,101) ApplicationDate
			,A.StateStatusAcc
			,Convert(varchar(10),A.StatusBeginDate,101) StatusBeginDate
			,C.PrevProviderNo
			,C.AuditIndicator
			,Convert(varchar(10),C.AuditDate,101) AuditDate
			,C.EPSDT
			,F.AddressLine1
			,F.AddressLine2
			,F.City
			,F.Abreviation as Acc_State
			,F.ZipPlus4 AS ZipPlus4	
			,G.AddressLine1 AS MAddressLine1
			,G.AddressLine2 AS MAddressLine2
			,G.City AS MCity
			,G.Abreviation AS MState
			,G.ZipPlus4 AS MZipPlus4
			--,[NCPDP]
			,'System' UserName			
		From KYPEnrollment.pADM_Account A 
		LEFT JOIN KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
		LEFT JOIN KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID
		LEFT JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
		LEFT JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
		--This is for Pay-to Address Details
		left join (select F.AddressLine1,F.AddressLine2,F.City,LS.Abreviation,F.Zip, F.ZipPlus4,x.PartyID  
							from KYPEnrollment.pAccount_PDM_Address F 
							inner join KYPEnrollment.pAccount_PDM_Location X
								 on F.AddressID = X.AddressID 
								 and X.Type='Pay-to'
								 and X.CurrentRecordFlag=1
							Left join kyp.LK_Screening LS on F.State=LS.Description
							 )F on F.PartyID = a.PartyID 
		--This is for Service Address Details	 
		left join (select H.AddressLine1,H.AddressLine2,H.City,LS.Abreviation,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County  
							from KYPEnrollment.pAccount_PDM_Address H 
							inner join KYPEnrollment.pAccount_PDM_Location X
								 on H.AddressID = X.AddressID 
								 and X.Type='Servicing'
								 and X.CurrentRecordFlag=1
								 Left join kyp.LK_Screening LS on H.State=LS.Description
								 )H on H.PartyID = a.PartyID 
		--This is for Mailing Address Details
		left join(select G.AddressLine1,G.AddressLine2,G.City,LS.Abreviation,G.Zip,G.ZipPlus4,x.PartyID  
							from KYPEnrollment.pAccount_PDM_Address G
							inner join KYPEnrollment.pAccount_PDM_Location X
								 on G.AddressID = X.AddressID 
								 and X.Type='Mailing'
								 and X.CurrentRecordFlag=1
								 Left join kyp.LK_Screening LS on G.State=LS.Description
								 )G on G.PartyID = a.PartyID
		LEFT JOIN (select T1.PartyID,T1.Number,T1.EffectiveDate,T1.ExpirationDate
							FROM KYPEnrollment.pAccount_PDM_Number T1
							Join (select MAX(NumberID) NumberID
								from KYPEnrollment.pAccount_PDM_Number
								where Type='Professional License' AND CurrentRecordFlag=1
								group by PartyID) T2 on T1.NumberID=T2.NumberID
								) J ON J.PartyID=A.PartyID 
		Left Join KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
		Left Join KYPEnrollment.PAccount_PDM_DEA I on I.PartyID=A.PartyID
		Left Join KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
		Left Join KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
		Left Join KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID and Q.Remarks <> 'BusinessProfile'
		Left Join KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID
		Left Join KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID			
		Left Join KYPEnrollment.pAccount_PDM_Party T ON A.PartyID=T.ParentPartyID 
																AND T.Type = 'Contact Person' 
		Left Join KYPEnrollment.pAccount_PDM_Person S ON S.PartyID=T.PartyID 
		Left Join kyp.ADM_Case AC on A.ApplicationNumber=AC.Number
		Where A.IsDeleted = 0


GO

