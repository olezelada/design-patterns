-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Provider recive 3 parametros 
-- @providerId id del proveedor ,@newPartyId nuevo party id,@lastActionUserID nombre del usuario que  realiza la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Provider]
	@providerId INT,
	@newPartyId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	
	-- 	Provider 
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
	([PartyID]
	,[Category]
	,[Type]
	,[PrimarySpecialty]
	,[SecondSpecialty]
	,[UPIN]
	,[CCN]
	,[HIN]
	,[Remarks]
	,[IsEnrolled]
	,[ProvNumber]
	,[Mon_MedicaidID]
	,[EnrolledSince]
	,[LastAction] 
	,[LastActionDate] 
	,[LastActorUserID] 
	,[LastActionApprovedBy] 
	,[CurrentRecordFlag] 
	,[DEA]
	,[NPI]
	,[Medicare]
	,[Medicaid]
	,[ServiceProvEntity]
	,[ProfLicense]
	,[ProfLicEffDate]
	,[ProfLicExpDate]
	,[OtherPriSpecialty]
	--,[TIN]
	,[EIN])
	SELECT @newPartyId
	,[Category]
	,[Type]
	,[PrimarySpecialty]
	,[SecondSpecialty]
	,[UPIN]
	,[CCN]
	,[HIN]
	,[Remarks]
	,[IsEnrolled]
	,[ProvNumber]
	,[Mon_MedicaidID]
	,[EnrolledSince]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[DEA]
	,[NPI]
	,[Medicare]
	,[Medicaid]
	,[ServiceProvEntity]
	,[ProfLicense]
	,[ProfLicEffDate]
	,[ProfLicExpDate]
	,[OtherPriSpecialty]
	--,[TIN]
	,[EIN]
	FROM [PortalKYP].[pPDM_Provider] WHERE [ProvID] = @providerId

	SELECT @message = '[pAccount_PDM_Provider] @newProviderId  ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT				
END


GO

