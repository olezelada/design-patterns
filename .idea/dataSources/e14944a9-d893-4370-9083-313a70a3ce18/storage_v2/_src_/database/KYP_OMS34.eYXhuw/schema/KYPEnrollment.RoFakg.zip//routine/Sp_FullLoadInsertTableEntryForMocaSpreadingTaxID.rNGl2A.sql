

CREATE PROC [KYPEnrollment].Sp_FullLoadInsertTableEntryForMocaSpreadingTaxID     
     
AS    
BEGIN   
INSERT INTO [KYPEnrollment].[pAccount_TaxID_Associate](AccountID,PartyID,TaxID,EntityID,CreatedOn,CurrentRecordFlag)
 SELECT ACC.AccountID,ACC.PartyID AS AccountPartyID,ACC.EIN,BPM.ProfileID,GETDATE(),1
  FROM KYPEnrollment.pADM_Account ACC
  JOIN KYPEnrollment.pAccount_Owner OWN
  ON ACC.AccountID = OWN.AccountID
  JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
  ON ACC.AccountID = BPD.AccountID
  JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
  ON BPD.ProfileId = BPM.ProfileID
  LEFT JOIN [KYPEnrollment].[pAccount_TaxID_Associate] ATA
  ON ATA.AccountID = ACC.AccountID
  WHERE ACC.PackageName IN('GSP_MDH') AND
   (ACC.EIN   IS NOT NULL AND ACC.EIN != '') AND
   ACC.NPI   NOT LIKE '%[a-z]%' AND
   LEFT(StatusAcc,1) IN ('1','7','9') AND
   ACC.IsDeleted  = 0 AND
   IsTempProfile  = 0 AND
   ACC.IsPastOwner = 0 AND
   ATA.AccountID IS NULL
End


GO

