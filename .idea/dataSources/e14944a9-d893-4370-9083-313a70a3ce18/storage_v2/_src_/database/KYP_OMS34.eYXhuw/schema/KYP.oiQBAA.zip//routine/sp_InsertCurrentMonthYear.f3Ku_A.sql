
-- =============================================
-- Author:		Vinoth Ramesh
-- Create date: 03 November 2014
-- Description:	Inserts the date and month into the corresponding master table
-- =============================================
CREATE PROCEDURE [KYP].[sp_InsertCurrentMonthYear] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE 
		@CurrentDateTime DATETIME,
		@CurrentMonth VARCHAR(3),
		@CurrentMonthNo INT,
		@CurrentYear VARCHAR(4),
		@ID INT;
		
	SET @CurrentDateTime = GETDATE();
	
	SET @CurrentMonth = CONVERT(VARCHAR(3), @CurrentDateTime, 0);
	SET @CurrentMonthNo = DATEPART(M, @CurrentDateTime);
	SET @CurrentYear = DATEPART(YEAR, @CurrentDateTime);
    PRINT @CurrentMonth
    PRINT @CurrentMonthNo
    PRINT @CurrentYear
	SELECT TOP 1 @ID = ID FROM KYP.LK_Screening WHERE [Description] = @CurrentMonth AND Abreviation = @CurrentYear
	
	IF @ID IS NULL OR @ID = ''
	BEGIN
		INSERT INTO KYP.LK_Screening (TypeID, [Description], SortOder, Abreviation)
		VALUES (9, @CurrentMonth, @CurrentMonthNo, @CurrentYear)
	END
END


GO

