

/* Modified Author: Sundar
   Defect:CAPAVE - 3901
   Date: 20 Sep 18
   Description: Added query to consider Moca as its Subcontractor Owner
				Removed unwanted functions like LTrim, RTrim and Coalesce
*/


CREATE VIEW [KYPEnrollment].[v_SubContractorsOwners]
AS
SELECT CASE 
		WHEN D.Type = 'SubcontractorOwnerIndividual'
			THEN ISNULL(P.LastName, '') + ', ' + ISNULL(P.FirstName, '') + ' ' + ISNULL(P.MiddleName, '')
		WHEN D.Type = 'SubcontractorOwnerEntity'
			THEN ISNULL(O.LegalName, '')
		ELSE NULL
		END AS NAME
	,CASE 
		WHEN   ISNULL(D.Type,'') = 'SubcontractorOwnerIndividual' 
			THEN 'Individual'
		WHEN ISNULL(D.Type,'') = 'SubcontractorOwnerEntity'  
			THEN 'Entity' 
		ELSE 'NA'
		END AS Type
	,CASE 
		WHEN ISNULL(D.Type,'') = 'SubcontractorOwnerIndividual'  
			THEN  ISNULL(NULLIF(P.Phone1,''),'NA')   
		WHEN ISNULL(D.Type,'') = 'SubcontractorOwnerEntity' 
			THEN ISNULL(NULLIF(O.Phone1,''),'NA')
		END AS 'PhoneNumber'
	,ISNULL(NULLIF(T.Description,''),'NA') as 'Description'
	,D.PartyID
	,D.AccountID
	,ISNULL(NULLIF(A.AddressLine1,''),'NA') as 'AddressLine1'  
	,ISNULL(NULLIF(A.AddressLine2,''),'NA')  as 'AddressLine2' 
	,ISNULL(NULLIF(A.City,''),'NA') as 'City'    
	,ISNULL(NULLIF(A.STATE,''),'NA')  as 'STATE'
	,ISNULL(NULLIF(A.County,''),'NA') as 'County'
	,ISNULL(NULLIF(A.ZipPlus4,''),'NA') as 'ZipPlus4'
	,ISNULL(NULLIF(R.OtherValue,''),'NA')    AS 'Title'
	,ISNULL(NULLIF(O.EIN,''),'NA')   AS 'TIN'
FROM KYPEnrollment.pAccount_PDM_Party D
LEFT JOIN KYPEnrollment.pAccount_PDM_Person P ON D.PartyID = P.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Organization O ON D.PartyID = O.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role R ON D.PartyID = R.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction T ON D.PartyID = T.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Location L ON D.PartyID = L.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Address A ON L.AddressID = A.AddressID
WHERE D.Type IN (
		'SubcontractorOwnerIndividual',
		'SubcontractorOwnerEntity'
		)
		AND D.ParentPartyID in (select partyid from  KYPEnrollment.pAccount_PDM_Party WHERE Type IN (
				'SubcontractorIndividual'
				,'SubcontractorEntity'
				))
Union all
SELECT Distinct ISNULL(P.LastName, '') + ', ' + ISNULL(P.FirstName, '') + ' ' + ISNULL(P.MiddleName, '')
		 AS NAME
	,'Individual' AS Type
	,ISNULL(NULLIF(P.Phone1,''),'NA') AS 'PhoneNumber'
	,ISNULL(NULLIF(T.Description,''),'NA') as 'Description'
	,D.PartyID
	,D.AccountID
	,ISNULL(NULLIF(A.AddressLine1,''),'NA') as 'AddressLine1'  
	,ISNULL(NULLIF(A.AddressLine2,''),'NA')  as 'AddressLine2' 
	,ISNULL(NULLIF(A.City,''),'NA') as 'City'    
	,ISNULL(NULLIF(A.STATE,''),'NA')  as 'STATE'
	,ISNULL(NULLIF(A.County,''),'NA') as 'County'
	,ISNULL(NULLIF(A.ZipPlus4,''),'NA') as 'ZipPlus4'
	,ISNULL(NULLIF(R.OtherValue,''),'NA')    AS 'Title'
	,Null AS 'TIN'		
FROM KYPEnrollment.pAccount_PDM_Party D
Join kypenrollment.pAccount_PDM_OwnershipRelationship PO ON PO.PartyIDOwner = D.PartyID
Join kypenrollment.paccount_pdm_party PA ON PO.PartyIDOwned = PA.PartyID
JOIN KYPEnrollment.pAccount_PDM_Person P ON D.PartyID = P.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role R ON D.PartyID = R.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction T ON D.PartyID = T.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Location L ON D.PartyID = L.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Address A ON L.AddressID = A.AddressID
WHERE D.Type IN ('Individual Ownership')
and PA.Type IN ('SubcontractorEntity','SubcontractorIndividual')
and PO.TypeAssociation in ('SubcontractorIndividualAssociation','SubcontractorEntityAssociation')
Union all
SELECT ISNULL(O.LegalName, '') AS NAME
	,'Entity' AS Type
	,ISNULL(NULLIF(O.Phone1,''),'NA') AS 'PhoneNumber'
	,ISNULL(NULLIF(T.Description,''),'NA') as 'Description'
	,D.PartyID
	,D.AccountID
	,ISNULL(NULLIF(A.AddressLine1,''),'NA') as 'AddressLine1'  
	,ISNULL(NULLIF(A.AddressLine2,''),'NA')  as 'AddressLine2' 
	,ISNULL(NULLIF(A.City,''),'NA') as 'City'    
	,ISNULL(NULLIF(A.STATE,''),'NA')  as 'STATE'
	,ISNULL(NULLIF(A.County,''),'NA') as 'County'
	,ISNULL(NULLIF(A.ZipPlus4,''),'NA') as 'ZipPlus4'
	,ISNULL(NULLIF(R.OtherValue,''),'NA')    AS 'Title'
	,ISNULL(NULLIF(O.EIN,''),'NA')   AS 'TIN'		
FROM KYPEnrollment.pAccount_PDM_Party D
Join kypenrollment.pAccount_PDM_OwnershipRelationship PO ON PO.PartyIDOwner = D.PartyID
Join kypenrollment.paccount_pdm_party PA ON PO.PartyIDOwned = PA.PartyID
JOIN KYPEnrollment.pAccount_PDM_Organization O ON D.PartyID = O.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role R ON D.PartyID = R.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction T ON D.PartyID = T.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Location L ON D.PartyID = L.PartyID
LEFT JOIN KYPEnrollment.pAccount_PDM_Address A ON L.AddressID = A.AddressID
WHERE D.Type IN ('Entity Ownership')
and PA.Type IN ('SubcontractorEntity','SubcontractorIndividual')
and PO.TypeAssociation in ('SubcontractorIndividualAssociation','SubcontractorEntityAssociation')


GO

