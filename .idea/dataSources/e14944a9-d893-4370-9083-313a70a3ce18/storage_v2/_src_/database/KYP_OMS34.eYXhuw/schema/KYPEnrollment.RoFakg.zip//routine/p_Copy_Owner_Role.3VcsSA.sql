

-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Owner role: recive 5 para metros 
-- Owner role ID, new party id, new Owner Relation ID,
-- Is type: tipo de operacion que va realizar(party,owner_role,OwnerRelation), nombre del usuario que aprovo
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]
	@pdmOwnerID INT,
	@newPartyID INT,
	@newOwnerRelationID INT,
	@isType varchar(15),
	@lastActionUserID varchar(100)
	
AS
BEGIN

    DECLARE @newPdmOwnerID int,@sql nvarchar(MAX),@ParmDefinition nvarchar(500),@name varchar(18),@isTrue INT,
			@message varchar(100),@dateCreated date,@lastAction varchar(1)
	
	SET @name ='';
	SET @isTrue = 0;
	SET @dateCreated = GETDATE();
	SET @lastAction = 'C';
		
	IF @isType='party'
	BEGIN
		SET @name ='[PartyID]';
		SET @isTrue = 1;
	END
	ELSE
	BEGIN
		IF @isType='owner_Role'
		BEGIN
			SET @name ='[PdmOwnerID]';
			SET @isTrue = 1;
		END
		ELSE
		BEGIN
			IF @isType='OwnerRelation'
			BEGIN
				SET @name ='[OwnerRelationID]';
				SET @isTrue = 1;
			END
		END
	END
	
	IF(@isTrue=1)
	BEGIN
	-- sql en formato string que sera evaluado	
		SET @sql =N'INSERT INTO [KYPEnrollment].[pAccount_PDM_Owner_Role]
				([TypeForm],[OwnerRelationID],[PercentCheck],[PercentValue],[Partner],[PartnerValue],[Managing],[ManagingValue],[Director],[DirectorValue],[Other],[OtherValue],
				[LastAction] ,
				[LastActionDate] ,
				[LastActorUserID] ,
				[LastActionApprovedBy] ,
				[CurrentRecordFlag] ,
				[PercentDate],[PartnerDate]
				,[ManagingDate]	,[DirectorDate]	,[OtherDate],[Agent],[AgentValue],[AgentDate],[PartyID],SoleOwner)
				SELECT [TypeForm],@newOwnerRelationID,[PercentCheck],[PercentValue],[Partner],[PartnerValue],[Managing],[ManagingValue]	,[Director]	,[DirectorValue],[Other],[OtherValue],
				@lastAction,
				@dateCreated,
				@lastActionUserID,
				@lastActionUserID,
				(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end),
				[PercentDate],[PartnerDate],[ManagingDate],[DirectorDate],[OtherDate]
				,[Agent],[AgentValue],[AgentDate],@newPartyID,SoleOwner
				FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role] WHERE '+@name+'=@pdmOwnerID';
			-- Definimos los para metros que se van a enviar al sql, que se definio anteriormente
			-- En la consulta existe @lastAction,lastActionUserID ....... estos son los para metros que esperan un valor
			-- para enviar un valor a un para metro se debe de finir que tipo es: de salida o ingreso los valores de salida son OUTPUT y los valores de ingreso son INTPUT o no lo defines.
		SET @ParmDefinition = N'@newOwnerRelationID INT OUTPUT, @newPartyID INT OUTPUT,@lastAction VARCHAR(1) OUTPUT,@dateCreated DATE OUTPUT,@lastActionUserID VARCHAR(100) OUTPUT, @pdmOwnerID INT';
		-- funcion que ejecuta el sql con los para metros NOTA: se debe enviar en el orden definido
		EXECUTE  sp_executesql @sql,@ParmDefinition,@newOwnerRelationID=@newOwnerRelationID,@newPartyID=@newPartyID,@lastAction=@lastAction,@dateCreated=@dateCreated,@lastActionUserID=@lastActionUserID,@pdmOwnerID=@pdmOwnerID;
		
		SELECT @message = '[pAccount_PDM_Owner_Role] @newPdmOwnerID : ' + CONVERT(char(10), 'OK')
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		
	END			
END


GO

