





CREATE VIEW [KYPEnrollment].[v_OutEDIMainFile_WeeklyReport]
AS
Select x.AccountID,AccountType,IsDeleted ,AccountUpdatedBy,
NPI,OwnerNo,ServiceLocationNo,OwnerEffectiveBeingDate,OwnerEffectiveEndDate,SUBSTRING(DBAName,1,28) AS LegalName,EIN,SSN,PIN
,TINUpdateType,TINUpdateDate
,SUBSTRING(AddressLine1,1,100) AS AddressLine1,SUBSTRING(AddressLine2,1,100) AS AddressLine2,SUBSTRING(City,1,50) AS City
,State, Zip,ZipPlus4
,AccountDateCreated,AccountUpdateDate --here 1 field no data leave it blanck

,SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4
,SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8
,ProvLocTypeCd,DBAName --here 1 field no data leave it blanck
,SUBSTRING(SAddressLine1,1,100) AS SAddressLine1,SUBSTRING(SAddressLine2,1,100) AS SAddressLine2,SUBSTRING(SCity,1,50) AS SCity
,SState,SZip,SZipPlus4,County as SCountyCode   
,Phone1,NameOfFacAdmin --here 1 field no data leave it blanck
,SUBSTRING(MAddressLine1,1,100) AS MAddressLine1,SUBSTRING(MAddressLine2,1,100) AS MAddressLine2,SUBSTRING(MCity,1,50) AS MCity
,MState,MZip,MZipPlus4  
,OutOfStateInd,ProviderTypeCode

,AccStatusValue1,convert(varchar(10),CONVERT(datetime,AccEffectiveBeginDate1),101) AS AccEffectiveBeginDate1 ,convert(varchar(10),CONVERT(datetime,AccEffectiveEndDate1),101) AS AccEffectiveEndDate1 
,AccStatusValue2,convert(varchar(10),CONVERT(datetime,AccEffectiveBeginDate2),101) AS AccEffectiveBeginDate2 ,convert(varchar(10),CONVERT(datetime,AccEffectiveEndDate2),101) AS AccEffectiveEndDate2
,AccStatusValue3,convert(varchar(10),CONVERT(datetime,AccEffectiveBeginDate3),101) AS AccEffectiveBeginDate3 ,convert(varchar(10),CONVERT(datetime,AccEffectiveEndDate3),101) AS AccEffectiveEndDate3
,AccStatusValue4,convert(varchar(10),CONVERT(datetime,AccEffectiveBeginDate4),101) AS AccEffectiveBeginDate4 ,convert(varchar(10),CONVERT(datetime,AccEffectiveEndDate4),101) AS AccEffectiveEndDate4
,AccStatusValue5,convert(varchar(10),CONVERT(datetime,AccEffectiveBeginDate5),101) AS AccEffectiveBeginDate5 ,convert(varchar(10),CONVERT(datetime,AccEffectiveEndDate5),101) AS AccEffectiveEndDate5

,CCodeIdentification1,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate1),101) AS CCodeDateEffDate1 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate1),101) AS CCodeDateExpDate1
,CCodeIdentification2,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate2),101) AS CCodeDateEffDate2 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate2),101) AS CCodeDateExpDate2
,CCodeIdentification3,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate3),101) AS CCodeDateEffDate3 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate3),101) AS CCodeDateExpDate3
,CCodeIdentification4,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate4),101) AS CCodeDateEffDate4 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate4),101) AS CCodeDateExpDate4
,CCodeIdentification5,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate5),101) AS CCodeDateEffDate5 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate5),101) AS CCodeDateExpDate5
,CCodeIdentification6,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate6),101) AS CCodeDateEffDate6 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate6),101) AS CCodeDateExpDate6
,CCodeIdentification7,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate7),101) AS CCodeDateEffDate7 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate7),101) AS CCodeDateExpDate7
,CCodeIdentification8,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate8),101) AS CCodeDateEffDate8 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate8),101) AS CCodeDateExpDate8
,CCodeIdentification9,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate9),101) AS CCodeDateEffDate9 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate9),101) AS CCodeDateExpDate9
,CCodeIdentification10,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate10),101) AS CCodeDateEffDate10 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate10),101) AS CCodeDateExpDate10
 
,CCodeIdentification11,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate11),101) AS CCodeDateEffDate11 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate11),101) AS CCodeDateExpDate11
,CCodeIdentification12,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate12),101) AS CCodeDateEffDate12 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate12),101) AS CCodeDateExpDate12
,CCodeIdentification13,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate13),101) AS CCodeDateEffDate13 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate13),101) AS CCodeDateExpDate13
,CCodeIdentification14,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate14),101) AS CCodeDateEffDate14 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate14),101) AS CCodeDateExpDate14
,CCodeIdentification15,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate15),101) AS CCodeDateEffDate15 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate15),101) AS CCodeDateExpDate15
,CCodeIdentification16,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate16),101) AS CCodeDateEffDate16 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate16),101) AS CCodeDateExpDate16
,CCodeIdentification17,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate17),101) AS CCodeDateEffDate17 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate17),101) AS CCodeDateExpDate17
,CCodeIdentification18,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate18),101) AS CCodeDateEffDate18 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate18),101) AS CCodeDateExpDate18
,CCodeIdentification19,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate19),101) AS CCodeDateEffDate19 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate19),101) AS CCodeDateExpDate19
,CCodeIdentification20,convert(varchar(10),CONVERT(datetime,CCodeDateEffDate20),101) AS CCodeDateEffDate20 ,convert(varchar(10),CONVERT(datetime,CCodeDateExpDate20),101) AS CCodeDateExpDate20
 
,Speciality_Code1,convert(varchar(10),CONVERT(datetime,SpecCertDate1),101) AS SpecCertDate1
,Speciality_Code2,convert(varchar(10),CONVERT(datetime,SpecCertDate2),101) AS SpecCertDate2
,Speciality_Code3,convert(varchar(10),CONVERT(datetime,SpecCertDate3),101) AS SpecCertDate3 
 
,SpecProcTypeCode,IMDFacilType
,PracTypeCode,ApplicationDate,RejectReasonCode,ExceptionIndicator,ProvisionalCode,ProvisionalCodeDate,ReenrollmentIndicator,ReenrollmentDate 
,LicenseNumber,LicenseBoardCode,License_EffectiveDate,CliaNumber,CliaCertificateType,ProvTypeUpdatedDate 
 
from( 
select A.NPI,A.OwnerNo,A.ServiceLocationNo,A.LegalName,A.PIN,A.AccountID,A.DateCreated AS AccountDateCreated,A.AccountUpdateDate,A.IsDeleted ,A.AccountUpdatedBy--,A.LastUpdatedBy
 ,A.DBAName,A.StatusAcc,A.ApplicationDate,A.ReenrollmentIndicator,A.EIN,A.SSN,A.ProviderTypeCode,A.AccountType,convert(varchar(10),CONVERT(datetime,A.ReenrollmentDate),101) AS ReenrollmentDate,convert(varchar(10),CONVERT(datetime,A.ProvTypeUpdateDate),101) as ProvTypeUpdatedDate
 ,A.ProvLocTypeCd 
  -- Field of pAccount_Owner
 ,B.EffectiveBeingDate  AS OwnerEffectiveBeingDate 
 ,B.EffectiveEndDate AS OwnerEffectiveEndDate --OR Case when(B.EffectiveEndDate is NULL) then (Case When(A.LegacyAccountNo is NULL) then NULL Else '2069-12-31 00:00:00' END) Else B.EffectiveEndDate END  AS OwnerEffectiveEndDate
 -- Field of EDM_AccountInternalUse
 ,C.TINUpdateType,C.TINUpdateDate,C.OutOfStateInd,C.SpecProcTypeCode,C.ProvisionalCode,C.ProvisionalCodeDate,C.RejectReasonCode,C.ExceptionIndicator ,C.NameOfFacAdmin,C.IMDFacilType
 -- Field of pAccount_PDM_Address 
 ,D.AddressLine1,D.AddressLine2,D.City,d.Zip,D.State,D.ZipPlus4  
 ,E.AddressLine1 AS SAddressLine1,E.AddressLine2 AS SAddressLine2,E.City AS SCity,E.State AS SState,E.Zip as SZip,E.ZipPlus4 AS SZipPlus4,E.County
 ,F.AddressLine1 AS MAddressLine1,F.AddressLine2 AS MAddressLine2,F.City AS MCity,F.State AS MState,F.Zip as MZip,F.ZipPlus4 AS MZipPlus4
 ,E.Phone1
 
 -- Field of pAccount_PDM_Speciality
 ,H.Speciality_Code,H.SpecCertDate
  -- Field of pAccount_PDM_EntityType
 ,c.PracTypeCode1+c.PracTypeCode2 as PracTypeCode
  -- Field of pAccount_PDM_Number
 ,J.LicenseBoardCode,J.Number AS LicenseNumber,J.EffectiveDate AS License_EffectiveDate
  -- Field of pAccount_PDM_Clia
 ,K.CliaNumber,K.CertificateType as CliaCertificateType
 
from KYPEnrollment.pADM_Account A 
left outer join KYPEnrollment.pAccount_Owner B 
	on A.AccountID=B.AccountID 
	AND A.OwnerNo=B.OwnerNo 
	AND B.CurrentRecordFlag=1
left outer join KYPEnrollment.EDM_AccountInternalUse C 
	on C.AccountID=A.AccountID 
	and C.CurrentRecordFlag = 1
left outer join KYPEnrollment.pAccount_PDM_Speciality H on H.PartyID=A.PartyID AND H.IsPrimary=NULL AND H.CurrentRecordFlag=1
left outer join KYPEnrollment.pAccount_PDM_EntityType I on I.PartyID=A.PartyID AND I.CurrentRecordFlag=1
left outer join KYPEnrollment.pAccount_PDM_Number J on J.PartyID=A.PartyID AND J.Type='Professional License' AND J.CurrentRecordFlag=1
left outer join KYPEnrollment.pAccount_PDM_Clia K on K.PartyID=A.PartyID AND K.CurrentRecordFlag=1
--This is for Pay-to Address Details
left outer join 
(select D.AddressLine1,D.AddressLine2,D.City,D.State,d.Zip, D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Pay-to'
	 and X.CurrentRecordFlag=1)D
	 on d.PartyID = a.PartyID
--This is for Service Address Details
left outer join 
(select D.AddressLine1,D.AddressLine2,D.City,D.State,d.Zip,D.ZipPlus4,x.PartyID,x.Phone1,d.County  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)E
	 on E.PartyID = a.PartyID
--This is for Mailing Address Details
left outer join(select D.AddressLine1,D.AddressLine2,D.City,D.State,d.Zip,D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = a.PartyID

       

	where A.IsDeleted=0  AND A.AccountType NOT IN ('NMP','ORP') --AND A.AccountUpdatedBy != 'M' 
	--	AND CONVERT(VARCHAR,A.LastActionDate, 101) >=  CONVERT(VARCHAR, GETDATE()-7, 101) and CONVERT(VARCHAR,A.LastActionDate, 101) <=  CONVERT(VARCHAR, GETDATE(), 101)
	--	AND A.DateCreated != A.DeActivationDate
	--AND CONVERT(VARCHAR, a.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-1, 101) 

) x  
left join 	 
  ( select AccountId, 
 SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
 SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,
 AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
 ,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
 from 
(   
	SELECT C.AccountId, CONVERT(varchar(20),CodeIdentification) as CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
    inner join KYPEnrollment.EDM_AccountInternalUse C 
    on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
    
    UNION ALL
    SELECT AccS.AccountId,CONVERT(varchar(20), AccS.StatusValue)as StatusValue
    ,'AccStatusValue'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by AccS.AccountStatusId desc  ) ) seq
    from KYPEnrollment.pADM_AccountStatus AccS  
    
    UNION ALL	
    SELECT AccS.AccountId,CONVERT(varchar(20), AccS.EffectiveBeginDate)
    ,'AccEffectiveBeginDate'+CONVERT(varchar(15), ROW_NUMBER() over(partition by AccS.AccountId order by  AccS.AccountStatusId desc )) seq
    from KYPEnrollment.pADM_AccountStatus AccS 

    UNION ALL	
    SELECT AccS.AccountId,CONVERT(varchar(20), AccS.EffectiveEndDate)
    ,'AccEffectiveEndDate'+CONVERT(varchar(15), ROW_NUMBER() over(partition by AccS.AccountId order by AccS.AccountStatusId desc )) seq
    from KYPEnrollment.pADM_AccountStatus AccS 

	UNION ALL 
	SELECT A.Accountid,CONVERT(varchar(20), P.Speciality_Code)
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc  ) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID   

	UNION ALL 
	SELECT A.Accountid,CONVERT(varchar(20), P.SpecCertDate)
	,'SpecCertDate'+CONVERT(varchar(15), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID  

	UNION ALL
	SELECT C.AccountId,CONVERT(varchar(20),CodeIdentification)
	,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'

	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateEffDate)
	,'CCodeDateEffDate'+CONVERT(varchar(15), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'

	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateExpDate)
	,'CCodeDateExpDate'+CONVERT(varchar(15), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
    
)ML(AccountId,StatusValue,seq)
PIVOT (max(ml.StatusValue) 
FOR ml.seq IN (
SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8, 
AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
)) pvt   )y
on x.AccountID= y.AccountId
     

-------------------------------------------------------- Close of Main PMF Record -----------------------------------------------------------------------------------------------------------------------


GO

