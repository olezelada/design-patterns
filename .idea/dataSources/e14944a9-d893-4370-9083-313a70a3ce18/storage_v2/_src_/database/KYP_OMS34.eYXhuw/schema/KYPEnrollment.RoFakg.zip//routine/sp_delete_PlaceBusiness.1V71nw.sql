-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <13/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_PlaceBusiness]
@new_Account_Id int


AS
BEGIN
Declare @place int,@person int,@party int,@location int,@address int
	SET NOCOUNT ON;

select @place = place.PlaceBusinessID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID
INNER JOIN KYPEnrollment.pAccount_PDM_PlaceBusiness place ON place.PartyId=p.PartyID
where a.AccountID=@new_Account_Id and place.CurrentRecordFlag=1 and place.IsDeleted=0

select @party = p2.PartyID from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Party p2 ON p.PartyID=p2.ParentPartyID
where p2.Type in ('Lease Information','FacilityBusiness Address','HospitalBusiness Address') and a.AccountID=@new_Account_Id
and p2.CurrentRecordFlag=1 and p2.IsDeleted=0

select @location = l.LocationID ,@address = a.AddressID from KYPEnrollment.pAccount_PDM_Location l INNER JOIN KYPEnrollment.pAccount_PDM_Address a ON l.AddressID=a.AddressID
where l.PartyID=@party and l.CurrentRecordFlag=1 and l.IsDeleted=0 and a.CurrentRecordFlag=1

select @person = PersonID from KYPEnrollment.pAccount_PDM_Person where PartyID=@party and CurrentRecordFlag=1

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_PlaceBusiness','PlaceBusinessID',@place

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Party','PartyID',@party

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Location','LocationID',@location

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Address','AddressID',@address

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Person','PersonID',@person

END


GO

