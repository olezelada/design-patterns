

CREATE PROCEDURE  [KYPEnrollment].[Main_Procedure_Clone_Account]
  @account_id INT,
  @account_no VARCHAR(20),
  @last_Action_User_ID VARCHAR(100),
  @priority VARCHAR(3),
  @risk VARCHAR(15),
  @composite_risk INT,
  @case_id INT,
  @application_no VARCHAR(15),
  @application_type VARCHAR(30),
  @party_id_app INT,
  @provider_type_code varchar(50)
  
  
  
AS
BEGIN

 CREATE TABLE #tempProviderType (id INT IDENTITY (1, 1),[tempProviderType] [nvarchar](50) NULL,[appName] [nvarchar](50) NULL,
[AccountNumber] [varchar](20) NULL,[partyAddressId] [int] NULL,	[IsFBP] [bit] NULL,	[locationID] [int] NULL )

 DECLARE @clone_account_number VARCHAR(20),@account_prefix VARCHAR(20),@clone_account_id INT,@new_account_id INT,@new_account_party_id INT
 
 SELECT @account_prefix = OwnerNo FROM KYPEnrollment.pADM_Account WHERE AccountID=@account_id
			 
  IF @account_prefix <> @account_no AND @account_prefix IS NOT NULL
  BEGIN
	SET @clone_account_number = @account_no+'-'+@account_prefix
  END
  ELSE 
  BEGIN
	SET @clone_account_number = @account_no+'-'+@account_prefix
  END
			 
  UPDATE KYPEnrollment.pADM_Account 
		SET IsPastOwner = 1,AccountNumber=@clone_account_number,
		DateModified=getdate() --KPP-6437
   WHERE AccountID=@account_id;

  UPDATE KYPEnrollment.pAccount_BizProfile_Details SET AccountNumber=@clone_account_number WHERE AccountID=@account_id; 
         
  EXEC [KYPEnrollment].[sp_Create_New_Account]@application_no, @last_Action_User_ID,@priority, @risk, @composite_risk, @case_id,@application_type,@provider_type_code, @account_no;
          
  SELECT @new_account_id = AccountID,@new_account_party_id=PartyID FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @account_no
           
  UPDATE KYPEnrollment.pADM_Account SET AccountNumber=@account_no,OwnerNo=RIGHT('0'+CONVERT(VARCHAR(10),CONVERT(INT,@account_prefix)+1),2) WHERE AccountID=@new_account_id
 		
  INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			   ([AccountID]
			   ,[AffiliatedAccountID]
			   ,[TypeAffiliation]
			   ,[AffiliationStartDate]
			   ,[AffiliationEndDate]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionComments]
			   ,[LastActionReason]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag]
			   ,[TempAffiliation]
			   ,[LastAction]
			   ,[LastUpdatedBy]
			   ,[groupEmail]
			   ,[rendering_email])
				 SELECT @new_account_id
					   ,renderingAffiliation.[AffiliatedAccountID]
					   ,renderingAffiliation.[TypeAffiliation]
					   ,renderingAffiliation.[AffiliationStartDate]
					   ,renderingAffiliation.[AffiliationEndDate]
					   ,renderingAffiliation.[LastActionDate]
					   ,renderingAffiliation.[LastActorUserID]
					   ,renderingAffiliation.[LastActionComments]
					   ,renderingAffiliation.[LastActionReason]
					   ,renderingAffiliation.[LastActionApprovedBy]
					   ,currentAffiliation.[IsAffilied]
					   ,renderingAffiliation.[TempAffiliation]
					   ,renderingAffiliation.[LastAction]
					   ,renderingAffiliation.[LastUpdatedBy]
					   ,renderingAffiliation.[groupEmail]
					   ,renderingAffiliation.[rendering_email]
			  FROM [KYPPORTAL].[PortalKYP].[pPDM_CurrentAffiliation] currentAffiliation INNER JOIN  [KYPEnrollment].[pAccount_RenderingAffiliation] renderingAffiliation
			  ON SUBSTRING(currentAffiliation.TargetPath,CHARINDEX('pAccount_RenderingAffiliation|RenderingAffiliationID|',currentAffiliation.TargetPath,1)+53,LEN(currentAffiliation.TargetPath)) = renderingAffiliation.RenderingAffiliationID 
			  WHERE currentAffiliation.PartyID = @party_id_app;
			  
    DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_trd] ON [KYPEnrollment].[EDM_AccountInternalMany];
	DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tri] ON [KYPEnrollment].[EDM_AccountInternalMany];
	DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tru] ON [KYPEnrollment].[EDM_AccountInternalMany];
	
	  EXEC [KYPEnrollment].[CloneAccountSearch]@account_id,@new_account_id;
      EXEC [KYPEnrollment].[Clone_AccountInternalUse]@account_id,@new_account_id;
      EXEC [KYPEnrollment].[Clone_History]@account_id,@new_account_id;
 

	
	ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_trd] ON [KYPEnrollment].[EDM_AccountInternalMany];
	ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tri] ON [KYPEnrollment].[EDM_AccountInternalMany];
	ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tru] ON [KYPEnrollment].[EDM_AccountInternalMany];		  

  
  UPDATE newAccount SET --newAccount.[LegacyAccountNo] = oldAccount.[LegacyAccountNo]
      newAccount.[P_SYS_ID] = oldAccount.[P_SYS_ID]
      ,newAccount.[ServiceLocationNo] = oldAccount.[ServiceLocationNo]
      ,newAccount.[ProvLocTypeCd] = oldAccount.[ProvLocTypeCd]
      ,newAccount.[EnrollmentRiskLevel] = oldAccount.[EnrollmentRiskLevel]
      ,newAccount.[PIN] = oldAccount.[PIN]
      ,newAccount.[StatusBeginDate] = oldAccount.[StatusBeginDate]
      ,newAccount.[DateDied] = oldAccount.[DateDied]
      ,newAccount.[OOBDate] = oldAccount.[OOBDate]
      ,newAccount.[ApplicationDate] = oldAccount.[ApplicationDate]
      ,newAccount.[DeActivationDate] = oldAccount.[DeActivationDate]
      ,newAccount.[DateCreated] = oldAccount.[DateCreated] -- KPP-6510
      ,newAccount.[DateModified] = getdate()--oldAccount.[DateModified] KPP-6510
      ,newAccount.[LastActionReason] = oldAccount.[LastActionReason]
      ,newAccount.[LastActionComments] = oldAccount.[LastActionComments]
      ,newAccount.[AccountUpdateDate] = oldAccount.[AccountUpdateDate]
      ,newAccount.[AccountUpdateUserID] = oldAccount.[AccountUpdateUserID]
      ,newAccount.[AccountUpdateReason] = oldAccount.[AccountUpdateReason]
      ,newAccount.[AccountUpdateComments] = oldAccount.[AccountUpdateComments]
      ,newAccount.[LastRevalidationDate] = oldAccount.[LastRevalidationDate]
      ,newAccount.[LastRevalidationReason] = oldAccount.[LastRevalidationReason]
      --,newAccount.[RevalidationDueDate] = oldAccount.[RevalidationDueDate]
      ,newAccount.[LastApplicationType] = oldAccount.[LastApplicationType]
      ,newAccount.[LastAlertedDate] = oldAccount.[LastAlertedDate]
      ,newAccount.[LastScreenedDate] = oldAccount.[LastScreenedDate]
      ,newAccount.[LastBilledDate] = oldAccount.[LastBilledDate]
      ,newAccount.[LastRenderedDate] = oldAccount.[LastRenderedDate]
      ,newAccount.[LastDeltaLoadDate] = oldAccount.[LastDeltaLoadDate]
      ,newAccount.[ReenrollmentDate] = oldAccount.[ReenrollmentDate]
      ,newAccount.[StatusAcc] = oldAccount.[StatusAcc]
      ,newAccount.[ReenrollmentIndicator] = oldAccount.[ReenrollmentIndicator]
      ,newAccount.[IsDeleted] = oldAccount.[IsDeleted]
      ,newAccount.[FutureStatus] = oldAccount.[FutureStatus]
      ,newAccount.[FutureDate] = oldAccount.[FutureDate]
      ,newAccount.[StatusReasonCode] = oldAccount.[StatusReasonCode]
      ,newAccount.[EnrollStatusComments] = oldAccount.[EnrollStatusComments]
      ,newAccount.[FutureStatusReasonCode] = oldAccount.[FutureStatusReasonCode]
      ,newAccount.[FutureEnrollComments] = oldAccount.[FutureEnrollComments]
      ,newAccount.[ApplicationStatusAcc] = oldAccount.[ApplicationStatusAcc]
      ,newAccount.[ApplicationBeginDate] = oldAccount.[ApplicationBeginDate]
      ,newAccount.[ApplicationReasonCode] = oldAccount.[ApplicationReasonCode]
      ,newAccount.[ApplicationComments] = oldAccount.[ApplicationComments]
      ,newAccount.[SuppStatusAcc] = oldAccount.[SuppStatusAcc]
      ,newAccount.[SuppBeginDate] = oldAccount.[SuppBeginDate]
      ,newAccount.[SuppReasonCode] = oldAccount.[SuppReasonCode]
      ,newAccount.[SuppComments] = oldAccount.[SuppComments]
      ,newAccount.[SuppFutureStatusAcc] = oldAccount.[SuppFutureStatusAcc]
      ,newAccount.[SuppFutureDate] = oldAccount.[SuppFutureDate]
      ,newAccount.[SuppFutureReason] = oldAccount.[SuppFutureReason]
      ,newAccount.[SuppFutureComments] = oldAccount.[SuppFutureComments]
      ,newAccount.[SuppDeActivationDate] = oldAccount.[SuppDeActivationDate]
     -- ,newAccount.[ScheduleType] = oldAccount.[ScheduleType]
  FROM KYPEnrollment.pADM_Account newAccount,KYPEnrollment.pADM_Account oldAccount
  WHERE newAccount.AccountID=@new_account_id AND oldAccount.AccountID=@account_id
  
  UPDATE newDetails SET newDetails.AccountNumber =@account_no,newDetails.ProfileID = oldDetails.ProfileID,newDetails.AccountBillingStatus=oldDetails.AccountBillingStatus,
  newDetails.AccountEnrollmentStatus= oldDetails.AccountEnrollmentStatus,newDetails.CurrentRecordFlag = oldDetails.CurrentRecordFlag,
  newDetails.UserRemark = oldDetails.UserRemark,newDetails.EffectiveBeginDate = oldDetails.EffectiveBeginDate,newDetails.LastAction = oldDetails.LastAction    
  FROM KYPEnrollment.pAccount_BizProfile_Details newDetails,KYPEnrollment.pAccount_BizProfile_Details oldDetails
  WHERE newDetails.AccountID=@new_account_id AND oldDetails.AccountID=@account_id AND oldDetails.CurrentRecordFlag=1			  
  
  UPDATE [KYPPORTAL].[PortalKYP].[AccountSectionChange] SET  AccountID=@new_account_id	WHERE AccountID=@account_id 
  UPDATE [KYPPORTAL].[PortalKYP].[AccountRevalidationTime] SET AccountID=@new_account_id	WHERE AccountID=@account_id 
  UPDATE [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] SET group_instance_id = @new_account_id WHERE group_providerNumber=@account_no;
  UPDATE [KYPPORTAL].[PortalKYP].[pPDM_TaxIdAssociation] SET AccountID = @new_account_id,AccountPartyID =@new_account_party_id  WHERE AccountID=@account_id
--**KPP-8042--
DECLARE @oldpartyaccount int
declare @LastActorUserID varchar(100)
set @LastActorUserID =''
select @oldpartyaccount=partyid from kypenrollment.pADM_Account where AccountID=@account_id
SELECT @LastActorUserID=isnull(LastActorUserID,'')  FROM  KYPEnrollment.pAccount_PDM_PaymentDetail	 WHERE PartyID = @oldpartyaccount
if  @LastActorUserID ='system'
	begin
		update KYPEnrollment.pAccount_PDM_PaymentDetail set LastActorUserID ='UserR' where PartyID=@new_account_party_id
		
    end
---**
END


GO

