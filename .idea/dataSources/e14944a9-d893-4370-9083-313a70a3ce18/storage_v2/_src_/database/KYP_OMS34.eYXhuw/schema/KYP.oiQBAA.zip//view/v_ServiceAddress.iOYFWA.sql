



CREATE VIEW [KYP].[v_ServiceAddress] AS
SELECT DISTINCT P.ApplicationID,A.AddressLine1,A.City,A.State,SUBSTRING(ISNULL(CONVERT(VARCHAR,A.ZipPlus4),''),0,CHARINDEX('-',ISNULL(CONVERT(VARCHAR,A.ZipPlus4),''))) As Zip,
ISNULL(CONVERT(VARCHAR,A.AddressLine1),'') + ',' + ISNULL(A.City,'') + ',' + ISNULL(A.State,'') + ' ' + SUBSTRING(ISNULL(CONVERT(VARCHAR,A.ZipPlus4),''),0,CHARINDEX('-',ISNULL(CONVERT(VARCHAR,A.ZipPlus4),''))) As ServiceAddress 
 from KYPEnrollment.pAccount_PDM_Location L INNER JOIN KYPEnrollment.pAccount_PDM_Address A ON L.AddressID = A.AddressID 
			INNER JOIN KYP.SDM_ApplicationParty P ON P.PartyID = L.PartyID AND P.IsActive = 1 AND (P.PartyType='Provider')
		WHERE L.Type = 'Servicing' AND ISNULL(A.AddressLine1,'') <> '' AND ISNULL(A.City,'') <> '' AND ISNULL(A.State,'') <> '' AND ISNULL(A.ZipPlus4,'') <> ''


GO

