
/* ==========================================================
-- Author:  <JVera>
-- PROCEDURE: create Delegated Officials forms.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @is_update : Flag if is update or create, default value is false.
-- @account_id : AccointID that will be create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Individual_Delegate]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @is_update              BIT,
   @account_id             INT,
   @is_prepopulated        BIT,
   @party_provider_id      INT,
   @is_group               BIT,
   @target_path            VARCHAR (200)
AS
BEGIN
   DECLARE
      @full_name_person       VARCHAR (100),
      @main_party_id          INT,
      @person_id              INT,
      @delegate_date_modify   SMALLDATETIME;
   /*IndividualInformation*/
   EXEC @person_id =
           [KYPEnrollment].[sp_Copy_Person] @party_account_id,
                                            @party_app_id,
                                            @last_action_user_id,
                                            'C';

   SELECT @delegate_date_modify = person.DateModified
   FROM [KYPPORTAL].[PortalKYP].pPDM_Person person
   WHERE person.PartyID = @party_app_id;

   UPDATE [KYPEnrollment].[pAccount_PDM_Person]
      SET DateModified = @delegate_date_modify
    WHERE PartyID = @party_account_id


   EXEC [KYPEnrollment].[sp_Copy_Address] @party_account_id,
                                          @party_app_id,
                                          NULL,
                                          @last_action_user_id;
   EXEC [KYPEnrollment].[sp_Copy_Document] @party_account_id,
                                           @party_app_id,
                                           @last_action_user_id;

   /*Adverse Action*/
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'DelegatedConviction',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'DelegatedLiability',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'DelegatedSettlement',
                                                 NULL;

   /*Adverse Action for new packages MD*/
   EXEC [KYPEnrollment].[sp_Copy_Program_Suspension] @party_account_id,
                                                     @party_app_id,
                                                     @last_action_user_id,
                                                     'DelegatedProgramSuspension',
                                                     NULL,
                                                     @account_id;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'DelegatedSuspendedSurrendered',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'DelegatedActionPending',
                                                 NULL;
END


GO

