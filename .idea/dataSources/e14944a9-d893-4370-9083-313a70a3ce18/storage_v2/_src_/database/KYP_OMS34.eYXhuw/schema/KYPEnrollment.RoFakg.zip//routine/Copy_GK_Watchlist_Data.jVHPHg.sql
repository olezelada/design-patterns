












-- =============================================
-- Author:		<Rahul, Raghavendra>
-- Create date: <06th november 2018>
-- Description:	< Copy data to Watchlist>
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.		Author		Date			Description
---------------------------------------------------------------------------------------

CREATE PROCEDURE [KYPEnrollment].[Copy_GK_Watchlist_Data] 

@AlertID int
	
AS
BEGIN
Declare 
@ProvType varchar(100),
@GKWLID INT,
@WatchListCount INT,
@IDResolution int,
@ProviderPartyID int,
@MedicaidID varchar(20), 
@I Int = 1;

Declare @Tab_GK_Watchlist Table(ID Int Identity(1,1), ProvType varchar(100),ResolutionID int,AlertID int, MedicaidID varchar(20),PrvPartyID int);
	

-- Inert All Provider to temp Table
				
	Insert into @Tab_GK_Watchlist( ProvType, ResolutionID, AlertID,MedicaidID,PrvPartyID)
	SELECT B.category, A.ResolutionID, A.AlertID, A.ProviderMedicaidID, B.PartyID	
	FROM KYP.MDM_AlertResolution A
	inner join KYP.PDM_provider B on A.ProviderMedicaidID=B.Mon_MedicaidID
	WHERE A.ResolutionType = 'Add to Internal Watchlist' and A.AlertID=@AlertID and A.IsDeleted=0
	

-- Get Count of Records 
	SELECT @WatchListCount= @@RowCount;	
	print @WatchListCount

	while(@I <= @WatchListCount)
	BEGIN
	
		SELECT @ProvType = ProvType,@IDResolution=ResolutionID,@ProviderPartyID=PrvPartyID,@MedicaidID=MedicaidID
		FROM @Tab_GK_Watchlist
		WHERE ID = @I
	print @WatchListCount
					

									-- Insert into GK Watchlist

								INSERT INTO [KYP].[GK_Watchlist] (
														[RequestBy]
														,[isApproved]
														,ResolutionID 
														,AkaName  
														,NAME 
														,FirstName 
														,LastName 
														,MiddleName 
														,Status
														,StatusStartDate 
														,StatusEndDate 
														,createdBy 
														,CreatedOn 
														,Notes 
														,isDeleted 
														,LastModifiedBy 
														,lastModifiedOn 
														,ProviderType 
														)
										select 'Monitoring Resolution from CA PED',0,A.ResolutionID,C.AKAName,A.ProviderName,C.FirstName,C.LastName,C.MiddleName,
										A.ResolutionStatus,A.StatusStartDate,A.StatusEndDate,D.FullName,A.CreatedDate,F.UnformattedContent,0,NULL,NULL,'Individual'	
										from KYP.MDM_AlertResolution A
										inner join KYP.PDM_provider B on B.Mon_MedicaidID = A.ProviderMedicaidID
										inner join (select P.PARtyID,P.FirstName,P.LastName,P.MiddleName,NULL LegalName,NULL AKAName
														from KYP.PDM_Person P
														Join kyp.PDM_Provider Pv on P.PartyID=Pv.PartyID and Pv.Mon_MedicaidID=@MedicaidID
														Where Pv.Category = 'Physician'
														Union all
														select O.PartyID,NULL,NULL,NULL,O.LegalName,ISNULL(nullif(O.DBAName1,''),O.DBAName2) AKAName 
														from KYP.PDM_Organization O
														Join kyp.PDM_Provider Pv on O.PartyID=Pv.PartyID and Pv.Mon_MedicaidID=@MedicaidID
														Where Pv.Category <> 'Physician') C on B.PartyID=C.PartyID
										inner join KYP.OIS_User D on D.PersonID=A.CreatedBy 
										inner join KYP.MDM_AlertNewResolutions E on E.ResolutionID=A.ResolutionID
										inner join KYP.OIS_Note F on F.NoteID=E.ResolutionNoteID
										where 	A.ResolutionID=@IDResolution
										
										--Get Primary Key of GK Watchlist
										SET @GKWLID = SCOPE_IDENTITY()--IDENT_CURRENT('[KYP].[GK_Watchlist]');
										print @GKWLID
										
										-- Insert INTO Phone Number Watchlist
										
										INSERT INTO KYP.GK_PhoneNoWatchlist (
												PhoneNo
												,GateKeeperID
												,isDeleted
										)
										select 
										Phone,
										@GKWLID,
										0																	
										from 	KYP.PDM_provider B 
										inner join (select P.PARtyID,ISNULL(nullif(Phone1,''),Phone2) Phone
														from KYP.PDM_Person P
														Join kyp.PDM_Provider Pv on P.PartyID=Pv.PartyID and Pv.Mon_MedicaidID=@MedicaidID
														Where Pv.Category = 'Physician'
														Union all
														select O.PartyID,ISNULL(nullif(O.Phone1,''),O.Phone2) Phone
														from KYP.PDM_Organization O
														Join kyp.PDM_Provider Pv on O.PartyID=Pv.PartyID and Pv.Mon_MedicaidID=@MedicaidID
														Where Pv.Category <> 'Physician') C on B.PartyID=C.PartyID
										where 	B.PartyID =@ProviderPartyID and B.Mon_MedicaidID=@MedicaidID
										
										-- Insert INTO NPI  Watchlist
												
										INSERT INTO KYP.GK_NPIWatchlist (
												NPI
												,GateKeeperID
												,isDeleted
												)
										select B.NPI,@GKWLID,0 										
										from 	KYP.PDM_provider B 
										where 	B.PartyID=@ProviderPartyID and B.Mon_MedicaidID=@MedicaidID
										
										-- Insert INTO Provider Number  Watchlist
										
										INSERT INTO KYP.GK_ProviderNoWatchlist (
												ProviderNo
												,GateKeeperID
												,isDeleted
										)
										select A.ProviderMedicaidID ,@GKWLID,0 from KYP.MDM_AlertResolution A
										where 	A.ResolutionID=@IDResolution 
										
										-- Insert INTO License Watchlist
										
										INSERT INTO [KYP].[GK_LicenseWatchlist] (
											License
											,GateKeeperID
											,isDeleted
											)
										select C.LicenseCode ,@GKWLID,0 										
										from 	KYP.PDM_provider B 
										inner join KYP.PDM_LICENSE C on C.PartyID=B.PartyID 
										where 	B.PartyID=@ProviderPartyID and B.Mon_MedicaidID=@MedicaidID
										
										--Inert Into Address WatchList
										
											INSERT INTO [KYP].[GK_AddressWatchlist] (
												 GateKeeperID
												,AddressLine1
												,AddressLine2
												,City
												,[STATE]
												,StateAbbrevation
												,ZipCode
												,Zip4code
												,isDeleted
											)
											select @GKWLID,D.AddressLine1,D.AddressLine2,D.City,E.[Description],D.[STATE],D.Zip,D.ZipPlus4,0	
											from KYP.PDM_provider B 
											inner join KYP.PDM_location C on B.PartyID=C.PartyID
											inner join KYP.PDM_Address D on C.addressID = D.addressID
											inner join KYP.LK_screening E on E.Abreviation=D.[STATE] and Typeid = 4
											where 	B.PartyID=@ProviderPartyID and B.Mon_MedicaidID=@MedicaidID
			
			update [KYP].[GK_Watchlist] set LastActionDate=getdate() where GateKeeperID=@GKWLID
			SET @I = @I + 1	
		END


END


GO

