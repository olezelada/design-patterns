


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[GetReferralTeamAvg]
	@pFromDate datetime,
	@pToDate Datetime,
	@pProviderType varchar(3000),
	@pReferralTeam varchar(3000),
	@pID int,
	@pUserId varchar(100)
AS
BEGIN
	SET NOCOUNT ON;

	Truncate table KYP.ReferralTeamAvgChart;

	Insert into KYP.ReferralTeamAvgChart(ReferralTeam, ReferralTeamAvgValue, IDValue ,UserID)
	Select T1.ReferralTeamDesc, T1.ReferralTeamAvg, @pID, @pUserId
	From (Select C.ReferralTeamDesc,
						Convert(numeric(12,2),SUM(isnull(C.DaysWithReferral,0)))/COUNT(Distinct C.CaseID) ReferralTeamAvg
				from KYP.ADM_Case C
				--Join KYP.ADM_ReferredReportHistory AR on C.CaseID = AR.CaseID
				WHERE C.ReferralDate between @pFromDate and @pToDate
				AND C.TypeDescription in (select Item
											from dbo.fnSplitString(@pProviderType,','))
				AND C.ReferralTeamDesc in (select Item
											from dbo.fnSplitString(@pReferralTeam,','))
				Group By C.ReferralTeamDesc) T1;
	
	--Insert into KYP.ReferralTeamAvgChart(ReferralTeam, ReferralTeamAvgValue, IDValue)
	--select Description as ReferralTeam, 0 as ReferralTeamAvgValue, @pID
	--from kyp.LK_Screening
	--where TYPEID=117
	--order by SortOder;
	
	--Update T2
	--Set T2.ReferralTeamAvgValue = T1.ReferralTeamAvg,
	--	--T2.IDValue = @pID,
	--	T2.UserID = @pUserId
	--From (Select C.ReferralTeamDesc,
	--					Convert(numeric(12,2),SUM(isnull(C.DaysWithReferral,0)))/COUNT(Distinct C.CaseID) ReferralTeamAvg
	--			from KYP.ADM_Case C
	--			--Join KYP.ADM_ReferredReportHistory AR on C.CaseID = AR.CaseID
	--			WHERE C.ReferralDate between @pFromDate and @pToDate
	--			AND C.TypeDescription in (select Item
	--										from dbo.fnSplitString(@pProviderType,','))
	--			AND C.ReferralTeamDesc in (select Item
	--										from dbo.fnSplitString(@pReferralTeam,','))
	--			Group By C.ReferralTeamDesc) T1
	--Join KYP.ReferralTeamAvgChart T2 on T1.ReferralTeamDesc = T2.ReferralTeam;
				

END


GO

