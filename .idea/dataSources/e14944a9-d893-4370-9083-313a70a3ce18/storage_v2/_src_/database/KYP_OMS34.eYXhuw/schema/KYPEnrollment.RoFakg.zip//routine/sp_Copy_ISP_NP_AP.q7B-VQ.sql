

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Packages Sole Proprietor Allied.   
-- PARAMETERS: 
-- @new_account_id : AccountID to new Account that will be create. 
-- @new_party_id_account : partyID to new Account that will be create. 
-- @party_id_portal : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ISP_NP_AP] (
	@new_account_id INT,
	@new_party_id_account INT,
	@party_id_portal INT, 
	@last_action_user_id VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@account_type VARCHAR(10),
	@application_type VARCHAR(40))
AS
BEGIN
	DECLARE @new_address_id INT,
			@new_person_id INT,
			@party_contact_id INT,
			@party_contact_id_portal INT,
			@npi_type VARCHAR(25),
			@npi VARCHAR (10),
			@provider_type_code VARCHAR(5),
	        @account_number VARCHAR(20),
			@isGroup BIT ;
	        
	        print 'sp_Copy_ISP_NP_AP'
	
	SELECT @npi_type = [NPIType], @npi =NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_account_id
	
	select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id
	/*BizProfile Details*/
	-- DISABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_id_portal,@new_account_id,@new_party_id_account,@last_action_user_id, 'KYPEnrollment.sp_Copy_BizProfile_Details';
	-- ENABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]

	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id

	/*Individual Profile*/
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Personal_Inf_Identification] @new_party_id_account, @party_id_portal,@last_action_user_id;
	EXEC @new_address_id = [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Individual Profile', @last_action_user_id;
		
	/*Business Profile*/
	EXEC [KYPEnrollment].[sp_Copy_Business_Profile]@new_party_id_account, @party_id_portal,@last_action_user_id;
	
	/*Contact Person*/
	EXEC [KYPEnrollment].[sp_Contact_Person] @party_id_portal, @new_party_id_account,@last_action_user_id,@new_account_id;
	
	/*Address*/
	EXEC @new_address_id = [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Servicing', @last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Pay-to', @last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Mailing', @last_action_user_id;

	/*Place Business*/
	EXEC [KYPEnrollment].[sp_Copy_Place_Business] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id;	 
	
	/*Insurance*/
	EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_party_id_account, @party_id_portal,@last_action_user_id;
	
	/* Prof. Licenses Certificates*/
	EXEC [KYPEnrollment].[sp_Copy_Clia] @new_party_id_account, @party_id_portal, @last_action_user_id, NULL;
	
	/* Taxonomy Speciality */
	EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_party_id_account, @party_id_portal, @last_action_user_id, NULL; 
	
	/*Program Participation*/
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id;

	/*Adverse Action*/
	EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id;
		
	/* Fines and debts */
	EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_id_portal, @new_party_id_account, @last_action_user_id,NULL; 
	
	/* Large Moca */
	--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
	IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
	BEGIN
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_party_id_account, null,@application_Id,@party_id_portal, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
	END
	
	/* PaymentDetail */
	EXEC [KYPEnrollment].[sp_Copy_PaymentDetail] @party_id_portal, @new_party_id_account, @last_action_user_id;
			
	/*Unique Party*/
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account]@new_party_id_account, @new_account_id, @npi_Type, @last_Action_User_ID,0;
	
	/*Update data Account and Linked*/
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_party_id_account, @party_id_portal, 0, @provider_type_code, @account_number, NULL,@account_type, @application_Id, @isGroup, @application_type;
END


GO

