



CREATE VIEW [KYP].[v_SumofPartyTrueChkResult] AS

SELECT SUM(X.cPositive) As cPositive,ApplicationID,PartyID FROM (

SELECT 
    COUNT(GSAEPLS) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1   where GSAEPLS = 'T' 
GROUP BY ApplicationID,PartyID, GSAEPLS 

UNION ALL

SELECT 
    COUNT(OIGLEIE) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where OIGLEIE = 'T' 
GROUP BY ApplicationID,PartyID, OIGLEIE 

UNION ALL

SELECT 
    COUNT(SOR) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SOR = 'T' 
GROUP BY ApplicationID,PartyID, SOR 

UNION ALL

SELECT 
    COUNT(SSADMF) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SSADMF = 'T' 
GROUP BY ApplicationID,PartyID, SSADMF 

UNION ALL

SELECT 
    COUNT(DMF) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where DMF = 'T' 
GROUP BY ApplicationID,PartyID, DMF 

UNION ALL

SELECT 
    COUNT(CourtCheck) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where CourtCheck = 'T' 
GROUP BY ApplicationID,PartyID, CourtCheck 

UNION ALL


SELECT 
    COUNT(HMSSanction) AS cPositive, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where HMSSanction = 'T' 
GROUP BY ApplicationID,PartyID, HMSSanction 

UNION ALL


SELECT COUNT(KYP_Watchlist) As cPositive,ApplicationID,PartyID FROM(

SELECT  IW_NPI_STATUS As KYP_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_NPI_STATUS = 'T'  
	UNION ALL
SELECT  IW_LICENSE_STATUS As KYP_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_LICENSE_STATUS = 'T'  
 UNION ALL
 SELECT  IW_NAME_ADDRESS_STATUS As KYP_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1
 where IW_NAME_ADDRESS_STATUS = 'T'  
 )X GROUP BY ApplicationID,PartyID,KYP_Watchlist 

UNION ALL



SELECT COUNT(MCSIS_Watchlist) As cPositive,ApplicationID,PartyID FROM(
SELECT 
    MCSIS_MR_NPI_STATUS AS MCSIS_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NPI_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, MCSIS_MR_NPI_STATUS 

UNION ALL

SELECT 
    MCSIS_MR_NAME_ADDR_STATUS AS MCSIS_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NAME_ADDR_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, MCSIS_MR_NAME_ADDR_STATUS 

UNION ALL

SELECT 
    MCSIS_MD_NPI_STATUS AS MCSIS_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NPI_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, MCSIS_MD_NPI_STATUS 

UNION ALL

SELECT 
    MCSIS_MD_NAME_ADDR_STATUS AS MCSIS_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NAME_ADDR_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, MCSIS_MD_NAME_ADDR_STATUS 
)X GROUP BY ApplicationID,PartyID,MCSIS_Watchlist 


UNION ALL
SELECT COUNT(SANDI_Watchlist) As cPositive,ApplicationID,PartyID FROM(
SELECT 
    SANDI_NPI_STATUS AS SANDI_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_NPI_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, SANDI_NPI_STATUS 

UNION ALL

SELECT 
    SANDI_LICENSE_STATUS AS SANDI_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_LICENSE_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, SANDI_LICENSE_STATUS 

UNION ALL

SELECT 
    SANDI_ADDRESS_STATUS AS SANDI_Watchlist, ApplicationID,PartyID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_ADDRESS_STATUS = 'T' 
GROUP BY ApplicationID,PartyID, SANDI_ADDRESS_STATUS 
)X GROUP BY ApplicationID,PartyID,SANDI_Watchlist




)X 
GROUP BY X.ApplicationID,PartyID


GO

