-- =============================================
-- Author:		<Lacunza Giresse>
-- Create date: <20/11/2017>
-- Description:	<This procedure fill the section_sp table with the procedures and sections required, if you add a new procedure/section that has to be in the update twins flow, please add it here>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].FBPpackageBufferAddress
    @applicatioNo VARCHAR(50),
    @caseId       INT
AS
  BEGIN
	
    DECLARE @provtypecode VARCHAR(20), @party INT, @count_acc_number INT
    SET NOCOUNT ON;
    
    DECLARE @tot INT, @count INT, @load INT
    DECLARE @InsertedRows TABLE(pk INT IDENTITY (1, 1), id INT, locationID INT)
	
    SELECT
      @provtypecode = a.ProviderTypeCode,
      @party = PartyID
    FROM KYPPORTAL.PortalKYP.pADM_Application a
    WHERE ApplicationNo = @applicatioNo AND IsDeleted = 0
	
    IF EXISTS(SELECT ad.AddressID
              FROM
                KYPPORTAL.PortalKYP.pPDM_Party p
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pb ON p.ParentPartyID = pb.PartyId
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location l ON l.PartyID = p.PartyID
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address ad ON l.AddressID = ad.AddressID
              WHERE p.ParentPartyID = @party AND p.IsDeleted = 0 AND pb.IsDeleted = 0 AND l.IsDeleted = 0 AND
                    ad.IsDeleted = 0 AND l.Approved = 1
                    AND p.TYPE IN ('FacilityBusiness Address'))
	  
      BEGIN
	  
        INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber, partyAddressId, IsFBP,locationID)
        OUTPUT inserted.id, inserted.locationID INTO @InsertedRows
          SELECT
            l.ProviderTypeCode,
            @applicatioNo,
            CONVERT(VARCHAR(20), CONVERT(INT, 100000000 + @caseId)),
            l.PartyID,
            1,
            l.LocationID
          FROM KYPPORTAL.PortalKYP.pADM_Application a
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON a.PartyID = p.ParentPartyID
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pb ON a.PartyID = pb.PartyId
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location l ON l.PartyID = p.PartyID
            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address ad ON l.AddressID = ad.AddressID
          WHERE a.ApplicationNo = @applicatioNo AND a.IsDeleted = 0 AND p.IsDeleted = 0 AND pb.IsDeleted = 0 AND
                l.IsDeleted = 0 AND ad.IsDeleted = 0 AND l.Approved = 1
                AND p.TYPE IN ('FacilityBusiness Address')
			    		    

---------------------------------------------------------------KEN-19915:
DECLARE @seq_aux table (id int identity,locationid bigint,twoDigits varchar(20))
INSERT INTO @seq_aux (locationid)
select locationno from
            KYPEnrollment.EDM_ApplicationInternalUse A  
              INNER JOIN KYP.PDM_AdditionalParties B ON A.LocationNumber = B.ID
              inner join @InsertedRows i on i.locationID=LocationNo where ProvCrossReferenceCode is not null order by ProvCrossReferenceCode
			  
INSERT INTO @seq_aux (locationid)
select locationno from
            KYPEnrollment.EDM_ApplicationInternalUse A  
              INNER JOIN KYP.PDM_AdditionalParties B ON A.LocationNumber = B.ID
              inner join @InsertedRows i on i.locationID=LocationNo where ProvCrossReferenceCode is null


update @seq_aux set twoDigits= case when id<10 then '0' + CAST(id AS varchar) else CAST(id AS varchar) end

update t
set t.AccountNumber= cast(cast('1' + a.twoDigits + '000000' as bigint) + @caseId as varchar)
from #tempProviderType t inner join @seq_aux a on t.locationID=a.locationid

      
      END
  END

GO

