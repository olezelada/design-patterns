-- drop function KYPEnrollment.getSpecialtyDesc   CREATE
CREATE FUNCTION [KYPEnrollment].[getSpecialtyDesc](@PartyID int)
RETURNS varchar(500)
AS
BEGIN
  Declare @vResult varchar(500)
  Declare @vPartial varchar(500)
  Declare @vCounter integer=0

  DECLARE Cur_ESFS CURSOR FOR
  
  select LongDescription  from KYP.PDM_Speciality spe inner join KYP.PDM_SpecialityCode cod on  spe.Speciality_Code=cod.Value where spe.PartyID=@PartyID
  
  OPEN Cur_ESFS  
  
  SET @vResult='';
  SET @vPartial='';
  FETCH Cur_ESFS INTO @vPartial
  WHILE (@@FETCH_STATUS = 0)
  BEGIN	
	
	if len(@vPartial) >0
	begin
	  SET @vCounter = @vCounter + 1
	  
	  IF @vCounter = 1 
		BEGIN
			SET @vResult = @vPartial
		END
	  ELSE 
		BEGIN
			SET @vResult = @vResult + ', ' +  @vPartial
	    END
	end
	FETCH Cur_ESFS INTO @vPartial

  END 
  CLOSE Cur_ESFS
  DEALLOCATE Cur_ESFS
  SET @vResult = @vResult 
  return @vResult
END


GO

