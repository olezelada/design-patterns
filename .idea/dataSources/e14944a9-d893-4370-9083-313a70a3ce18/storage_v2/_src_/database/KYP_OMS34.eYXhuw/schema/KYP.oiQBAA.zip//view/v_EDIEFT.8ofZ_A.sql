





CREATE VIEW [KYP].[v_EDIEFT]
AS
SELECT row_number() OVER (
		ORDER BY NPI ASC
		) AS ID
	,*
FROM (
	SELECT CASE 
			WHEN LEN(ACC.LegalName) > 150
				THEN SUBSTRING(ACC.LegalName, 1, 150)
			ELSE LTRIM(RTRIM(ACC.LegalName))
			END AS 'Provider_Name'
		,CASE 
			WHEN LEN(ACC.NPI) > 10
				THEN SUBSTRING(ACC.NPI, 1, 10)
			ELSE LTRIM(RTRIM(ACC.NPI))
			END AS 'NPI'
		,CASE 
			WHEN LEN(ACC.OwnerNo) > 2
				THEN SUBSTRING(ACC.OwnerNo, 1, 2)
			ELSE LTRIM(RTRIM(ACC.OwnerNo))
			END AS 'OwnerNum'
		,CASE 
			WHEN LEN(PAY.ProviderContact) > 100
				THEN SUBSTRING(PAY.ProviderContact, 1, 100)
			ELSE LTRIM(RTRIM(PAY.ProviderContact))
			END AS 'Contact_Name'
		,CASE 
			WHEN LEN(REPLACE(REPLACE(REPLACE(PER.Phone1,'(',''),') ',''),'-','')) > 10
				THEN SUBSTRING(REPLACE(REPLACE(REPLACE(PER.Phone1,'(',''),') ',''),'-',''), 1, 10)
			ELSE LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(PER.Phone1,'(',''),') ',''),'-',''))) 
			END AS 'Telephone_Num'
		,CASE 
			WHEN LEN(PER.Extension) > 5
				THEN SUBSTRING(CONVERT(VARCHAR(5),PER.Extension), 1, 5)
			ELSE LTRIM(RTRIM(PER.Extension))
			END AS 'Ext'
		,CASE 
			WHEN LEN(ADDR.AddressLine1) > 100
				THEN SUBSTRING(ADDR.AddressLine1, 1, 100)
			ELSE LTRIM(RTRIM(ADDR.AddressLine1))
			END AS 'AdL1'
		,CASE 
			WHEN LEN(ADDR.AddressLine2) > 50
				THEN SUBSTRING(ADDR.AddressLine2, 1, 50)
			ELSE LTRIM(RTRIM(ADDR.AddressLine2))
			END AS 'AdL2'
		,CASE 
			WHEN LEN(ADDR.City) > 25
				THEN SUBSTRING(ADDR.City, 1, 25)
			ELSE LTRIM(RTRIM(ADDR.City))
			END AS 'Cty'
		,CASE 
			WHEN LEN(ADDR.STATE) > 40
				THEN SUBSTRING(ADDR.STATE, 1, 40)
			ELSE LTRIM(RTRIM(ADDR.STATE))
			END AS 'St'
		,CASE
			WHEN LEN(REPLACE(ADDR.ZipPlus4, '-', '')) > 9
				THEN SUBSTRING(REPLACE(ADDR.ZipPlus4, '-', ''), 1, 9)		
			ELSE LTRIM(RTRIM(REPLACE(ADDR.ZipPlus4, '-', '')))
			END AS 'ZIP'
		,CASE
			WHEN LEN(SUBSTRING(ACC.SSNH, 8, 4)) > 4
				THEN SUBSTRING(SUBSTRING(ACC.SSNH, 8, 4), 1, 4)		
			ELSE LTRIM(RTRIM(SUBSTRING(ACC.SSNH, 8, 4)))
			END AS 'SSN_LAST4'
		,CASE
			WHEN LEN(ACC.EIN) > 9
				THEN SUBSTRING(ACC.EIN, 1, 9)		
			ELSE LTRIM(RTRIM(ACC.EIN))
			END AS 'FEIN'		
		,CASE
			WHEN LEN(PAY.RoutingNumber) > 9
				THEN SUBSTRING(PAY.RoutingNumber, 1, 9)		
			ELSE LTRIM(RTRIM(PAY.RoutingNumber))
			END AS 'ROUTING_NUM'
		,CASE
			WHEN LEN(PAY.BankpAccountNumber) > 17
				THEN SUBSTRING(PAY.BankpAccountNumber, 1, 17)		
			ELSE LTRIM(RTRIM(PAY.BankpAccountNumber))
			END AS 'ACCNT_NUM'		
		,CASE
			WHEN LEN(PAY.TypeOfPayment) > 40
				THEN SUBSTRING(PAY.TypeOfPayment, 1, 40)		
			ELSE LTRIM(RTRIM(PAY.TypeOfPayment))
			END AS 'TYPE_OF_ACCNT'
		,CASE
			WHEN LEN(PAY.BankName) > 100
				THEN SUBSTRING(PAY.BankName, 1, 100)		
			ELSE LTRIM(RTRIM(PAY.BankName))
			END AS 'BANK_NAME'
		,CASE
			WHEN LEN(PAY.StreetName) > 100
				THEN SUBSTRING(PAY.StreetName, 1, 100)		
			ELSE LTRIM(RTRIM(PAY.StreetName))
			END AS 'BA'
		,CASE
			WHEN LEN(PAY.City) > 25
				THEN SUBSTRING(PAY.City, 1, 25)		
			ELSE LTRIM(RTRIM(PAY.City))
			END AS 'Ct'
		,CASE
			WHEN LEN(PAY.StateTrans) > 40
				THEN SUBSTRING(PAY.StateTrans, 1, 40)		
			ELSE LTRIM(RTRIM(PAY.StateTrans))
			END AS 'BS'		
		,CASE
			WHEN LEN(REPLACE(PAY.ZipPlus4, '-', '')) > 9
				THEN SUBSTRING(REPLACE(PAY.ZipPlus4, '-', ''), 1, 9)		
			ELSE LTRIM(RTRIM(REPLACE(PAY.ZipPlus4, '-', '')))
			END AS 'BZ'		
		,CASE 
			WHEN PAY.TypeOfPayment = 'Savings' OR PAY.TypeOfPayment = 'Checking'
				THEN 'N'
			ELSE 'Y'
			END AS 'OPTOUT'
		,CASE
			WHEN ACC.SSNH IS NOT NULL AND ACC.SSNH <> ''
				THEN SUBSTRING(ACC.SSNH, 8, 4)
			ELSE ACC.EIN
			END AS 'SSN_OR_EIN'
		,CONVERT(VARCHAR(10), GETDATE(), 101) + ' ' 
		 + LTRIM(RIGHT(CONVERT(CHAR(20), GETDATE(), 22), 11))
		 AS 'GEN_DATE'
		,ACC.AccountID
		,ACC.PartyID
		,PAY.LastActionDate AS PAY_LastActionDate
		,ADDR.LastActionDate AS ADDR_LastActionDate
	FROM --KYPEnrollment.pADM_Account ACC 
	(SELECT * FROM 
		(SELECT ROW_NUMBER() OVER (Partition by NPI order by LastActionDate DESC) as row , * 
		 FROM kypenrollment.pADM_Account WHERE AccProcessing = 0 AND IsDeleted = 0
		)  x where row = 1
	) ACC
	INNER JOIN KYPEnrollment.pAccount_PDM_Party PARTY ON PARTY.AccountID = ACC.AccountID AND PARTY.Type = 'Contact Person'
	INNER JOIN KYPEnrollment.pAccount_PDM_Person PER ON PER.PartyID = PARTY.PartyID
	INNER JOIN KYPEnrollment.pAccount_PDM_PaymentDetail PAY ON PAY.PartyID = ACC.PartyID AND PAY.LastActorUserID <> 'system'
	INNER JOIN KYPEnrollment.pAccount_PDM_Location LOC ON LOC.PartyID = ACC.PartyID AND LOC.Type = 'Pay-to'
	INNER JOIN KYPEnrollment.pAccount_PDM_Address ADDR ON ADDR.AddressID = LOC.AddressID
	WHERE (PAY.TypeOfPayment IS NOT NULL AND PAY.LastAction IN ('C','U'))
	OR (PAY.TypeOfPayment IS NULL AND PAY.LastAction = 'U')	
	) z
	WHERE 
       (
              PAY_LastActionDate > --DATEADD(HOUR, 18, CAST(CAST(GETDATE()-1 AS DATE) AS DATETIME))
				CASE WHEN  DATENAME(dw,GETDATE()) = 'Monday'
					 THEN 
					 
						DATEADD(HOUR, 18, CAST(CAST(GETDATE()-2 AS DATE) AS DATETIME))
					 ELSE
						DATEADD(HOUR, 18, CAST(CAST(GETDATE()-1 AS DATE) AS DATETIME))
					 END
              AND           
			  PAY_LastActionDate <= DATEADD(HOUR, 18, CAST(CAST(GETDATE() AS DATE) AS DATETIME))
       )
       OR
       (
              ADDR_LastActionDate > --DATEADD(HOUR, 18, CAST(CAST(GETDATE()-1 AS DATE) AS DATETIME))
				CASE WHEN  DATENAME(dw,GETDATE()) = 'Monday'
					 THEN 
						DATEADD(HOUR, 18, CAST(CAST(GETDATE()-2 AS DATE) AS DATETIME))
					 ELSE
						DATEADD(HOUR, 18, CAST(CAST(GETDATE()-1 AS DATE) AS DATETIME))
					 END
              AND           
              ADDR_LastActionDate <= DATEADD(HOUR, 18, CAST(CAST(GETDATE() AS DATE) AS DATETIME))
       )


GO

