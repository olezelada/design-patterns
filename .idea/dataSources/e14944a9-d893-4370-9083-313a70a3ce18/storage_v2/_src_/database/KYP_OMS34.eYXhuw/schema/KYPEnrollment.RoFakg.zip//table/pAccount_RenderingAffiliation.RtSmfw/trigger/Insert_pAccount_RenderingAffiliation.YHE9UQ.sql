
CREATE TRIGGER [KYPEnrollment].[Insert_pAccount_RenderingAffiliation]
ON [KYPEnrollment].[pAccount_RenderingAffiliation]
INSTEAD OF INSERT
AS
BEGIN
	IF EXISTS (SELECT * FROM inserted WHERE TypeAffiliation NOT LIKE 'RENDERING_S%')
	BEGIN
		INSERT KYPEnrollment.pAccount_RenderingAffiliation (AccountID, AffiliatedAccountID, TypeAffiliation, AffiliationStartDate, AffiliationEndDate, LastActionDate, LastActorUserID, LastActionComments, LastActionReason, LastActionApprovedBy, CurrentRecordFlag, TempAffiliation, LastAction, LastUpdatedBy, groupEmail, rendering_email, AffiliatedAccountProvTypeCode, AcHistoryID, isDeleted)
		SELECT AccountID, AffiliatedAccountID, TypeAffiliation, AffiliationStartDate, AffiliationEndDate, LastActionDate, LastActorUserID, LastActionComments, LastActionReason, LastActionApprovedBy, CurrentRecordFlag, TempAffiliation, LastAction, LastUpdatedBy, groupEmail, rendering_email, AffiliatedAccountProvTypeCode, AcHistoryID, isDeleted
		FROM inserted
		WHERE TypeAffiliation NOT LIKE 'RENDERING_S%'
	END

	-- CAPAVE-2508: in this ticket mentions the control of duplicates for rendering-s
	IF EXISTS (SELECT * FROM inserted WHERE TypeAffiliation LIKE 'RENDERING_S%')
	BEGIN
		-- Verifying if in the data to be inserted, in this there is no duplicated information
		DECLARE @auxInserted TABLE (row_num int, RenderingAffiliationID int, AccountID int, AffiliatedAccountID int, TypeAffiliation varchar(50), AffiliationStartDate smalldatetime, AffiliationEndDate smalldatetime, LastActionDate smalldatetime, LastActorUserID varchar(100), LastActionComments varchar(255), LastActionReason varchar(100), LastActionApprovedBy varchar(100), CurrentRecordFlag bit, TempAffiliation int, LastAction varchar(1), LastUpdatedBy varchar(1), groupEmail varchar(100), rendering_email varchar(100), AffiliatedAccountProvTypeCode varchar(3), AcHistoryID int, isDeleted bit)
		INSERT INTO @auxInserted (row_num, RenderingAffiliationID, AccountID, AffiliatedAccountID, TypeAffiliation, AffiliationStartDate, AffiliationEndDate, LastActionDate, LastActorUserID, LastActionComments, LastActionReason, LastActionApprovedBy, CurrentRecordFlag, TempAffiliation, LastAction, LastUpdatedBy, groupEmail, rendering_email, AffiliatedAccountProvTypeCode, AcHistoryID, isDeleted)
		SELECT row_number() OVER ( PARTITION BY RenderingAffiliationID, AccountID ORDER BY RenderingAffiliationID DESC) AS row_num, RenderingAffiliationID, AccountID, AffiliatedAccountID, TypeAffiliation, AffiliationStartDate, AffiliationEndDate, LastActionDate, LastActorUserID, LastActionComments, LastActionReason, LastActionApprovedBy, CurrentRecordFlag, TempAffiliation, LastAction, LastUpdatedBy, groupEmail, rendering_email, AffiliatedAccountProvTypeCode, AcHistoryID, isDeleted
		FROM inserted
		WHERE TypeAffiliation LIKE 'RENDERING_S%'

		-- Inserting the new records in the table pAccount_RenderingAffiliation, but verifying that there is no duplicate data information, with the existing data
		INSERT KYPEnrollment.pAccount_RenderingAffiliation (AccountID, AffiliatedAccountID, TypeAffiliation, AffiliationStartDate, AffiliationEndDate, LastActionDate, LastActorUserID, LastActionComments, LastActionReason, LastActionApprovedBy, CurrentRecordFlag, TempAffiliation, LastAction, LastUpdatedBy, groupEmail, rendering_email, AffiliatedAccountProvTypeCode, AcHistoryID, isDeleted)
		SELECT newDt.AccountID, newDt.AffiliatedAccountID, newDt.TypeAffiliation, newDt.AffiliationStartDate, newDt.AffiliationEndDate, newDt.LastActionDate, newDt.LastActorUserID, newDt.LastActionComments, newDt.LastActionReason, newDt.LastActionApprovedBy, newDt.CurrentRecordFlag, newDt.TempAffiliation, newDt.LastAction, newDt.LastUpdatedBy, newDt.groupEmail, newDt.rendering_email, newDt.AffiliatedAccountProvTypeCode, newDt.AcHistoryID, newDt.isDeleted
		FROM (SELECT * FROM @auxInserted WHERE row_num=1) newDt
		LEFT JOIN (	SELECT *
					FROM KYPEnrollment.pAccount_RenderingAffiliation
					WHERE isDeleted = 0 AND CurrentRecordFlag = 1) affDt
		ON (newDt.AccountID=affDt.AccountID AND newDt.AffiliatedAccountID=affDt.AffiliatedAccountID)
		WHERE affDt.AccountID IS NULL
	END
END;
GO

