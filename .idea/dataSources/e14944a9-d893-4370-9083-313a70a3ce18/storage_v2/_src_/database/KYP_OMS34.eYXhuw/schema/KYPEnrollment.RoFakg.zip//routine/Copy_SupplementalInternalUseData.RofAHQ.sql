








-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_SupplementalInternalUseData] 
   @LastActionComments varchar(200)  
AS
BEGIN

	SET NOCount ON;

	Declare @BillingStatus varchar(30),
		@BillingBeginDate smalldatetime,
		@BillingEndDate smalldatetime,
		@BillingFutureStatus varchar(30),
		@BillingFutureDate smalldatetime,
		@BillingComments varchar(500),
		@BillingFutureComments varchar(500),
		@ProvisionalCode varchar(2),
		@ProvisionalCodeDate smalldatetime,
		@ProvisionalCodeDesc varchar(200),
		@LabStatusCode varchar(30),
		@LabSpecCodeDesc varchar(200),
		@LabStatusCodeDate smalldatetime,
		@OutOfStateInd varchar(1),
		@OutOfStateIndDesc varchar(200),
		@SpecProcTypeCodeDesc varchar(200),
		@SpecProcTypeCode varchar(10),
		@ProvCrossReferenceValue varchar(20),
		@CHDPCode varchar(150),
		@AtypicalProviderNo varchar(11),
		--@PhyCertCode varchar(2),
		--@PhyCertCodeDesc varchar(200),
		--@PhyCertCodeEfDate smalldatetime,
		@ReEnrolInd varchar(10),
		@ReEnrolDate smalldatetime,
		@PracTypeCode1 varchar(1),
		@PracTypeCode1Desc varchar(250),
		@PracTypeCode2 varchar(1),
		@PracTypeCode2Desc varchar(250),
		@TINUpdateType varchar(5),
		@TINUpdateTypeDesc varchar(250),
		@TINUpdateDate smalldatetime,
		@AccInternalUseID int,
		@StatusAcc varchar(200),
		@StatusBeginDate smalldatetime,
		@StatusReasonCode varchar(6000),
		@EnrollStatusComments varchar(500),
		@StatusDate date,
		@suppStatusAcc varchar(200),
		@suppStatusBeginDate smalldatetime,
		@suppStatusReasonCode varchar(6000),
		@suppEnrollStatusComments varchar(500),
		@suppStatusDate date,
		@getDate date= convert (date,getdate()),
		@datediff int,
		@CurrentlyAssignedToName varchar(500),
		@MDCToMDL bit,
		@MDLToMDC bit,
		@ResolutionStatus varchar(200),
		@ProviderTypeCode varchar(20),
		@CountSupplemental int,
		@oldAccountID int,
		@NewAccountID int,
		@AccountID int,
		@AccountInternalUseID int,
		@isFBP bit,
		@IsTribalAppln bit,
		@OwnerEffectiveDate smalldatetime,
		@ProvCrossReferenceCode varchar(20),
		@CountSuperUser int,
		@reslotionName varchar(150),
		@AccountProviderTypeCode varchar(5)
	 	
	Declare @CodeIdentification varchar(10),
		@CodeDescription varchar(250),
		@CodeType varchar(10),
		@CodeDateEffDate smalldatetime,
		@CodeDateExpDate smalldatetime,
		@CreatedBy varchar(100),
		@Partyid int;

	Declare @Tab_StatusAcc Table(AccountID int, StatusAcc varchar(200), StatusBeginDate smalldatetime);
	
	Declare @Tab_IUD_Fields Table(AccountID int, ProvisionalCode varchar(2), ProvisionalCodeDate smalldatetime,
		LabStatusCode varchar(30),
		LabStatusCodeDate smalldatetime,
		OutOfStateInd varchar(1),
		CHDPCode varchar(150),
		ReEnrolInd varchar(10),
		ReEnrolDate smalldatetime,
		PracTypeCode1 varchar(1),
		PracTypeCode2 varchar(1),
		TINUpdateType varchar(5),
		TINUpdateDate smalldatetime,
		SpecProcTypeCode varchar(10));
		
	Declare @Tab_OwnerEffDate Table(AccountID int, OwnerEffDate smalldatetime);
	
	Declare @Tab_IUD_Many Table(AccountID int, [CodeIdentification] varchar(10)
					,CodeType varchar(10)
					,[CodeDateEffDate] smalldatetime
					,[CodeDateExpDate] smalldatetime);		

	Begin Try
		select @isFBP=IsFacilityBasedProvider from KYP.ADM_CaseExtended where Number=@LastActionComments
		
		select @reslotionName=serviceLocNo from Kypenrollment.EDM_SupplementalInternalUse where LastActionComments=@LastActionComments
		
		--if(@reslotionName='Change in Ownership - Approved')
		--BEGIN
		--		--update KYPEnrollment.EDM_SupplementalInternalUse set AccountID=Null  Where LastActionComments=@LastActionComments
		--END
		
		IF Exists (Select A.AccountID From kypenrollment.Padm_Account A
						Join Kypenrollment.EDM_SupplementalInternalUse SI on A.ApplicationNumber=SI.LastActionComments and A.ProviderTypeCode = SI.ProviderTypeCode 
						Where A.ApplicationNumber=@LastActionComments
						and SI.serviceLocNo='Change in Ownership - Approved' and @isFBP <>1 )
		BEGIN
			
			Insert into [KYPEnrollment].[EDM_AccountInternalUse](AccountID,LastActionComments,ApplicationNumber,IsApproved,ProviderTypeCode)
			Select A.AccountID,A.ApplicationNumber,A.ApplicationNumber,1,A.ProviderTypeCode
				From kypenrollment.Padm_Account A
				Join Kypenrollment.EDM_SupplementalInternalUse SI on A.ApplicationNumber=SI.LastActionComments and A.ProviderTypeCode = SI.ProviderTypeCode 
				--Left Join [KYPEnrollment].[EDM_AccountInternalUse] AI on A.AccountID=AI.AccountID
				Where A.ApplicationNumber=@LastActionComments
				and SI.serviceLocNo='Change in Ownership - Approved'
				--and AI.AccountID is null;
							
		
		END
	
		select @IsTribalAppln=IsTribalAppln from KYP.ADM_Case where Number=@LastActionComments
		select  @CountSuperUser=count(InfoID)
		from KYP.MDM_JournalBasicInfo journal
		inner join kyp.OIS_Note note on  note.PInID=journal.infoid 
		inner join KYP.ADM_case A on journal.CaseID=A.CaseID
		where A.Number = @LastActionComments and note.Tags='Application Update'
		
		update KYP.ADM_case set isRequiresUpdate= case when (@CountSuperUser>0)then 1 else 0 END where Number=@LastActionComments


		exec Kypenrollment.Usp_DeActivate_Account @LastActionComments

		--Update kypenrollment.EDM_SupplementalInternalUse
		--Set AccountID = (Select AccountID from kypenrollment.pADM_Account where ApplicationNumber = @LastActionComments)
		--Where LastActionComments=@LastActionComments
		--and AccountID is null;

		
		if(@isFBP=1)
		begin
		
		update Kypenrollment.EDM_SupplementalInternalUse set AccountID=Null  Where LastActionComments=@LastActionComments
			exec [KYPEnrollment].[sp_CopySupplementalInternalUseDate_FBP]  @LastActionComments
		end
		else
		begin
		
			select @CountSupplemental=count(AccountInternalUseID) from KYPEnrollment.EDM_SupplementalInternalUse where LastActionComments=@LastActionComments


			while(@CountSupplemental>0)
			BEGIN
				SELECT @providertypecode=Y.ProviderTypeCode,@AccountID = Y.AccountID,@AccInternalUseID= Y.AccountInternalUseID FROM(
				SELECT row_number() OVER(order by ProviderTypeCode) As RowNumber,ProviderTypeCode,AccountID,AccountInternalUseID
				FROM KYPEnrollment.EDM_SupplementalInternalUse WHERE LastActionComments =@LastActionComments )Y WHERE Y.RowNumber = @CountSupplemental 

				if(ISNULL(@IsTribalAppln,0) = 1)
				begin
					select @AccountID=AccountID 
					from KYPEnrollment.pADM_Account where ApplicationNumber=@LastActionComments
					update KYPEnrollment.EDM_SupplementalInternalUse set AccountID=@AccountID where AccountInternalUseID=@AccInternalUseID
					--Added the IF statement for KEN-19013 by Sundar on 4 Oct 2018
					IF Not Exists (Select AccountInternalUseID From [KYPEnrollment].[EDM_AccountInternalUse] where AccountID = @AccountID)
					Begin
						insert into KYPEnrollment.EDM_AccountInternalUse (ApplicationNumber,ProviderTypeCode,LastActionComments,AccountID)values(@LastActionComments,'075',@LastActionComments,@AccountID)
					End
					--select @AccountID=AccountID from KYPEnrollment.pADM_Account where ApplicationNumber=@LastActionComments
				END

				if(@AccountID is null and @reslotionName='Change in Ownership - Approved')
				begin
					select @AccountID=AccountID,@AccountProviderTypeCode=ProviderTypeCode from KYPEnrollment.pADM_Account where ApplicationNumber=@LastActionComments and ProviderTypecode=@providertypecode
					update KYPEnrollment.EDM_SupplementalInternalUse set AccountID=@AccountID where LastActionComments=@LastActionComments and ProviderTypeCode=@AccountProviderTypeCode
					--update KYPEnrollment.EDM_AccountInternalUse set AccountID=@AccountID where ApplicationNumber=@LastActionComments and ProviderTypeCode=@AccountProviderTypeCode
				end
				else 
				Begin
					
					select @AccountID=AccountID from KYPEnrollment.pADM_Account where ApplicationNumber=@LastActionComments AND ProviderTypeCode = @providertypecode
					print 'AccountID: ' +  CAST(@AccountID AS VARCHAR(20))
					update KYPEnrollment.EDM_SupplementalInternalUse set AccountID=@AccountID where AccountInternalUseID=@AccInternalUseID
					update KYPEnrollment.EDM_AccountInternalUse set AccountID=@AccountID where ApplicationNumber=@LastActionComments and ProviderTypeCode=@providertypecode
				end 
				if(@AccountID is not null)
				Begin
																
					SELECT @suppStatusDate=(convert(date,StatusBeginDate)),@suppStatusAcc=StatusAcc,@suppStatusBeginDate=StatusBeginDate,
					@suppStatusReasonCode=StatusReasonCode,@suppEnrollStatusComments=EnrollStatusComments
					,@AccountInternalUseID=AccountInternalUseID,@LastActionComments=LastActionComments,@BillingStatus =[BillingStatus],@BillingBeginDate =[BillingBeginDate],@BillingEndDate =[BillingEndDate],
					@BillingFutureStatus =[BillingFutureStatus],@BillingFutureDate =[BillingFutureDate],@BillingComments =[BillingComments],
					@BillingFutureComments =[BillingFutureComments],@ProvisionalCode =[ProvisionalCode],@ProvisionalCodeDate =[ProvisionalCodeDate],
					@ProvisionalCodeDesc =[ProvisionalCodeDesc],@LabStatusCode =[LabStatusCode],@LabSpecCodeDesc =[LabSpecCodeDesc],@LabStatusCodeDate =[LabStatusCodeDate],
					@OutOfStateInd =[OutOfStateInd],@OutOfStateIndDesc =[OutOfStateIndDesc],@SpecProcTypeCode =[SpecProcTypeCode],@SpecProcTypeCodeDesc =[SpecProcTypeCodeDesc],
					@ProvCrossReferenceValue =[ProvCrossReferenceValue],@CHDPCode =[CHDPCode], @AtypicalProviderNo =[AtypicalProviderNo],@ReEnrolInd =[ReEnrolInd],@ReEnrolDate =[ReEnrolDate],
					--@PhyCertCode =[PhyCertCode],@PhyCertCodeDesc =[PhyCertCodeDesc],@PhyCertCodeEfDate =[PhyCertCodeEfDate],
					@PracTypeCode1 =[PracTypeCode1], @PracTypeCode1Desc=[PracTypeCode1Desc],
					@PracTypeCode2 =[PracTypeCode2],@PracTypeCode2Desc =[PracTypeCode2Desc],@TINUpdateType =[TINUpdateType], @TINUpdateTypeDesc=[TINUpdateTypeDesc],
					@TINUpdateDate =[TINUpdateDate],@ProviderTypeCode=[ProviderTypeCode],@OwnerEffectiveDate=OwnerEffectiveDate,@ProvCrossReferenceCode=ProvCrossReferenceCode  
					FROM [KYPEnrollment].[EDM_SupplementalInternalUse] 
					WHERE AccountID = @AccountID and 
					LastActionComments=@LastActionComments;
					
					--select @StatusDate=(convert(date,StatusBeginDate)),@StatusAcc=StatusAcc,@StatusBeginDate=StatusBeginDate,@StatusReasonCode=StatusReasonCode,
					--@EnrollStatusComments=EnrollStatusComments
					--from KYPEnrollment.pADM_Account where AccountID =@AccountID 

					select @CurrentlyAssignedToName=B.FullName,@MDCToMDL=isnull(A.MDCToMDL,0),@MDLToMDC=isnull(MDLToMDC,0),@ResolutionStatus=ResolutionStatus 
					from KYP.ADM_Case A
					inner join KYP.OIS_User B on A.CurrentlyAssignedToID=B.PersonID
					where Number=@LastActionComments

					if(@suppStatusDate>@getDate)
						begin
						
							update KYPEnrollment.pADM_Account	
							set
								FutureDate=@suppStatusBeginDate,
								FutureEnrollComments=@suppEnrollStatusComments,
								FutureStatus=@suppStatusAcc,
								FutureStatusReasonCode=@suppStatusReasonCode,
								DeActivationDate=@suppStatusBeginDate-1,
								LastActionDate=GETDATE(),
								LastActorUserID=@CurrentlyAssignedToName,
								-- KEN-17103, Commented the below command, as we are maintaining if enrollmentStatusDate is greater than currentDate we are displaying 3-Pending
								--StatusAcc=case when(@MDCToMDL=1 or @MDLToMDC=1) then '3 - Pending' else StatusAcc end,
								StatusAcc='3 - Pending',
								OwnerNo=@BillingFutureStatus,
								ServiceLocationNo=@ProvCrossReferenceCode,	
								StatusBeginDate=case when(@MDCToMDL=1 or @MDLToMDC=1) then GETDATE() else StatusBeginDate end,
								StatusReasonCode=case when(@MDCToMDL=1 or @MDLToMDC=1) then '' else StatusReasonCode end,
								EnrollStatusComments=case when(@MDCToMDL=1 or @MDLToMDC=1) then ''else EnrollStatusComments end,
								UpdateRequired= case when (@CountSuperUser>0)then 1 else 0 END
							Output Deleted.AccountID,Deleted.StatusAcc, Deleted.StatusBeginDate Into @Tab_StatusAcc(AccountID, StatusAcc, StatusBeginDate)
							where AccountID =@AccountID;	
								
						end
					else if (@suppStatusDate is not null)
						begin

							update KYPEnrollment.pADM_Account	
							set
								StatusAcc=@suppStatusAcc,
								StatusBeginDate=@suppStatusBeginDate,
								StatusReasonCode=@suppStatusReasonCode,
								EnrollStatusComments=@suppEnrollStatusComments,
								OwnerNo=@BillingFutureStatus,
								ServiceLocationNo=@ProvCrossReferenceCode,
								ActivationDate=case when(@suppStatusAcc='1 - Active') then @suppStatusBeginDate else ActivationDate end,
								LastActionDate=GETDATE(),
								LastActorUserID=@CurrentlyAssignedToName,
								UpdateRequired= case when (@CountSuperUser>0)then 1 else 0 END,
								AccHistory=case when(@suppStatusAcc not in('6 - Suspended','2 - Inactive','9 - Temporary Suspended')) then 'true' else AccHistory end
							Output Deleted.AccountID,Deleted.StatusAcc, Deleted.StatusBeginDate Into @Tab_StatusAcc(AccountID, StatusAcc, StatusBeginDate)
							where AccountID =@AccountID;

							
						end
						else if(@suppStatusDate is null)
						begin
						
							update KYPEnrollment.pADM_Account	
								set
									StatusAcc='3 - Pending',
									StatusBeginDate=@suppStatusBeginDate,
									StatusReasonCode=@suppStatusReasonCode,
									EnrollStatusComments=@suppEnrollStatusComments,
									OwnerNo=@BillingFutureStatus,
									ServiceLocationNo=@ProvCrossReferenceCode,
									ActivationDate=case when(@suppStatusAcc='1 - Active') then @suppStatusBeginDate else ActivationDate end,
									LastActionDate=GETDATE(),
									LastActorUserID=@CurrentlyAssignedToName,
									UpdateRequired= case when (@CountSuperUser>0)then 1 else 0 END,
									AccHistory=case when(@suppStatusAcc not in('6 - Suspended','2 - Inactive','9 - Temporary Suspended')) then 'true' else AccHistory end
							Output Deleted.AccountID,Deleted.StatusAcc, Deleted.StatusBeginDate Into @Tab_StatusAcc(AccountID, StatusAcc, StatusBeginDate)
							where AccountID =@AccountID;
														
						end 

					declare @AppCount int;

					SELECT @AppCount = COUNT(AccInternalUseManyID) FROM [KYPEnrollment].[EDM_SupplementalInteranlMany]
					WHERE AccountInternalUseID =@AccountInternalUseID 		
					DECLARE @ACC INT;
					SELECT @ACC= COUNT(AccountID) FROM [KYPEnrollment].[EDM_SupplementalInternalUse]
					WHERE AccountID =@AccountID


					IF @ACC >= 1
					BEGIN
						IF Exists (Select AccountInternalUseID From [KYPEnrollment].[EDM_AccountInternalUse] where AccountID = @AccountID)
						Begin
							UPDATE [KYPEnrollment].[EDM_AccountInternalUse]
							SET BillingStatus =  @BillingStatus 
							,BillingBeginDate = @BillingBeginDate  
							,BillingEndDate = @BillingEndDate 
							,BillingFutureStatus = @BillingFutureStatus
							,BillingFutureDate = @BillingFutureDate
							,BillingComments = @BillingComments
							,BillingFutureComments = @BillingFutureComments
							,ProvisionalCode = @ProvisionalCode
							,ProvisionalCodeDate = @ProvisionalCodeDate
							,ProvisionalCodeDesc = @ProvisionalCodeDesc
							,LabStatusCode = @LabStatusCode
							,LabSpecCodeDesc = @LabSpecCodeDesc
							,LabStatusCodeDate = @LabStatusCodeDate
							,OutOfStateInd = @OutOfStateInd
							,OutOfStateIndDesc = @OutOfStateIndDesc
							,SpecProcTypeCode = @SpecProcTypeCode
							,SpecProcTypeCodeDesc = @SpecProcTypeCodeDesc
							,ProvCrossReferenceValue = @ProvCrossReferenceValue
							,CHDPCode = @CHDPCode
							,AtypicalProviderNo = @AtypicalProviderNo
							--,PhyCertCode = @PhyCertCode
							--,PhyCertCodeDesc = @PhyCertCodeDesc
							--,PhyCertCodeEfDate = @PhyCertCodeEfDate
							,ReEnrolInd = @ReEnrolInd
							,ReEnrolDate = @ReEnrolDate
							,PracTypeCode1 = @PracTypeCode1
							,PracTypeCode1Desc = @PracTypeCode1Desc
							,PracTypeCode2 = @PracTypeCode2
							,PracTypeCode2Desc = @PracTypeCode2Desc
							,TINUpdateType = @TINUpdateType
							,TINUpdateTypeDesc = @TINUpdateTypeDesc
							,TINUpdateDate = @TINUpdateDate
							,IsApproved=1
							,LastActionDate = GETDATE()
							OutPut Deleted.AccountID,
									Deleted.ProvisionalCode, 
									Deleted.ProvisionalCodeDate,
									Deleted.LabStatusCode,
									Deleted.LabStatusCodeDate,
									Deleted.OutOfStateInd,
									Deleted.CHDPCode,
									Deleted.ReEnrolInd,
									Deleted.ReEnrolDate,
									Deleted.PracTypeCode1,
									Deleted.PracTypeCode2,
									Deleted.TINUpdateType,
									Deleted.TINUpdateDate,
									Deleted.SpecProcTypeCode
							 Into @Tab_IUD_Fields(AccountID, 
													ProvisionalCode, 
													ProvisionalCodeDate,
													LabStatusCode,
													LabStatusCodeDate,
													OutOfStateInd,
													CHDPCode,
													ReEnrolInd,
													ReEnrolDate,
													PracTypeCode1,
													PracTypeCode2,
													TINUpdateType,
													TINUpdateDate,
													SpecProcTypeCode)
							WHERE AccountID = @AccountID;
						End
						Else
						Begin
							Insert into [KYPEnrollment].[EDM_AccountInternalUse](AccountID
							,BillingStatus
							,BillingBeginDate  
							,BillingEndDate
							,BillingFutureStatus
							,BillingFutureDate
							,BillingComments
							,BillingFutureComments
							,ProvisionalCode
							,ProvisionalCodeDate
							,ProvisionalCodeDesc
							,LabStatusCode
							,LabSpecCodeDesc
							,LabStatusCodeDate
							,OutOfStateInd
							,OutOfStateIndDesc
							,SpecProcTypeCode 
							,SpecProcTypeCodeDesc
							,ProvCrossReferenceValue
							,CHDPCode
							,AtypicalProviderNo
							,ReEnrolInd
							,ReEnrolDate
							,PracTypeCode1
							,PracTypeCode1Desc
							,PracTypeCode2
							,PracTypeCode2Desc
							,TINUpdateType
							,TINUpdateTypeDesc
							,TINUpdateDate
							,IsApproved
							,LastActionDate)
							Values (@AccountID
							,@BillingStatus 
							,@BillingBeginDate  
							,@BillingEndDate 
							,@BillingFutureStatus
							,@BillingFutureDate
							,@BillingComments
							,@BillingFutureComments
							,@ProvisionalCode
							,@ProvisionalCodeDate
							,@ProvisionalCodeDesc
							,@LabStatusCode
							,@LabSpecCodeDesc
							,@LabStatusCodeDate
							,@OutOfStateInd
							,@OutOfStateIndDesc
							,@SpecProcTypeCode
							,@SpecProcTypeCodeDesc
							,@ProvCrossReferenceValue
							,@CHDPCode
							,@AtypicalProviderNo
							,@ReEnrolInd
							,@ReEnrolDate
							,@PracTypeCode1
							,@PracTypeCode1Desc
							,@PracTypeCode2
							,@PracTypeCode2Desc
							,@TINUpdateType
							,@TINUpdateTypeDesc
							,@TINUpdateDate
							,1
							,GETDATE())
						End
						
						Select @Partyid= Partyid from [KYPEnrollment].pADM_Account where AccountID=@AccountID

						update [KYPEnrollment].[pAccount_PDM_Speciality] set ISUpdate=1 where PartyID=@Partyid

						update  KYPEnrollment.PaDM_Account set StateStatusAcc=SuppReasonCode  where AccountID=@AccountID
						
					END
					
					/*Added for CAPAVE-2629 by Khalid on 22 Feb 2018 STart*/
					If Not Exists(Select AccountID from Kypenrollment.pAccount_Owner Where AccountID = @AccountID)
					Begin
						Insert into KYPEnrollment.pAccount_Owner(AccountID, OwnerNo, EffectiveBeingDate, EffectiveEndDate, LastAction, LastActionDate, LastActorUserID, CurrentRecordFlag)
						Output Inserted.AccountID INTO @Tab_OwnerEffDate(AccountID)
						Select T1.AccountID, T1.OwnerNo, T2.OwnerEffectiveDate, '2069-12-31', 'c',GETDATE(), 'System', 1
						From Kypenrollment.pADM_Account T1
						Join KYPEnrollment.EDM_SupplementalInternalUse T2 on T1.AccountID = T2.AccountID
						Where IsDeleted = 0
						and T1.AccountID = @AccountID
					End
					--Else
					--Begin
					--	Update T1
					--	Set T1.EffectiveBeingDate = T2.OwnerEffectiveDate
					--	Output Deleted.AccountID, Deleted.EffectiveBeingDate INTO @Tab_OwnerEffDate(AccountID, OwnerEffDate)						
					--	From kypenrollment.pAccount_Owner T1
					--	Join KYPEnrollment.EDM_SupplementalInternalUse T2 on T1.AccountID = T2.AccountID and T2.LastActionComments=@LastActionComments
					--	Where T1.AccountID = @AccountID
					--End
					/*Added for CAPAVE-2629 by Khalid on 22 Feb 2018 End*/	

					SET @AccInternalUseID = NULL;
					SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_AccountInternalUse] WHERE AccountID=@AccountID;


					IF EXISTS(SELECT 1 FROM [KYPEnrollment].[EDM_SupplementalInteranlMany] WHERE AccountInternalUseID =@AccountInternalUseID )
					BEGIN
						--DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_trd] ON [KYPEnrollment].[EDM_AccountInternalMany];
						--DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tri] ON [KYPEnrollment].[EDM_AccountInternalMany];
						--DISABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tru] ON [KYPEnrollment].[EDM_AccountInternalMany];
						Update [KYPEnrollment].[EDM_AccountInternalMany] 
						Set Row_Updation_Source = 'Trigger_return'
						WHERE AccountInternalUseID =@AccInternalUseID;
						
						--Added Output clause for CAPAVE-5356 by Sundar on 26Mar2019
						DELETE FROM [KYPEnrollment].[EDM_AccountInternalMany] 
						Output @AccountID,
									Deleted.[CodeIdentification],
									Deleted.[CodeDateEffDate],
									Deleted.[CodeDateExpDate],
									Deleted.CodeType
						 INTO @Tab_IUD_Many(AccountID
											,[CodeIdentification]
											,[CodeDateEffDate]
											,[CodeDateExpDate]
											,CodeType)						
						WHERE AccountInternalUseID =@AccInternalUseID	;
						--ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_trd] ON [KYPEnrollment].[EDM_AccountInternalMany];
						--ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tri] ON [KYPEnrollment].[EDM_AccountInternalMany];
						--ENABLE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tru] ON [KYPEnrollment].[EDM_AccountInternalMany];
					END

					;With Cte(RowNumber,AccInternalUseManyID)
					As
					(
					SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
					FROM [KYPEnrollment].[EDM_SupplementalInteranlMany] WHERE AccountInternalUseID =@AccountInternalUseID and isnull(isDeleted,0)=0
					and CodeIdentification is not null
					),
					cte2 (AccInternalUseID,[CodeIdentification],[CodeDescription],[CodeType],
					[CodeDateEffDate],[CodeDateExpDate],[CreatedBy],[CurrentRecordFlag],AccInternalUseManyID)
					as
					(SELECT @AccInternalUseID as AccInternalUseID,[CodeIdentification],[CodeDescription],[CodeType],
					[CodeDateEffDate],[CodeDateExpDate],[CreatedBy],1 as [CurrentRecordFlag] ,cte.AccInternalUseManyID
					FROM [KYPEnrollment].[EDM_SupplementalInteranlMany] supp
					join cte on cte.AccInternalUseManyID = supp.AccInternalUseManyID
					)
					
					INSERT INTO [KYPEnrollment].[EDM_AccountInternalMany]
					([AccountInternalUseID]
					,[CodeIdentification]
					,[CodeDescription]
					,[CodeType]
					,[CodeDateEffDate]
					,[CodeDateExpDate]
					,[CreatedBy]
					,[CurrentRecordFlag]
					,isDeleted
					,LastActionDate
					)
					--Output @AccountID, --Commented Output clause for CAPAVE-5356 by Sundar on 26Mar2019
					--			Inserted.[CodeIdentification],
					--			Inserted.[CodeDateEffDate],
					--			Inserted.[CodeDateExpDate],
					--			Inserted.CodeType
					-- INTO @Tab_IUD_Many(AccountID
					--					,[CodeIdentification]
					--					,[CodeDateEffDate]
					--					,[CodeDateExpDate]
					--					,CodeType)
					Select AccInternalUseID,[CodeIdentification],[CodeDescription],[CodeType],
					[CodeDateEffDate],[CodeDateExpDate],[CreatedBy],1,0,Getdate() from cte2
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'StatusAcc',T1.StatusAcc,T2.StatusAcc,GetdatE()
					From @Tab_StatusAcc t1
					Join kypenrollment.Padm_Account T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.StatusAcc,'') <> isnull(T2.StatusAcc,'')
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'StatusBgnDt',Convert(varchar(10),T1.StatusBeginDate,101),Convert(varchar(10),T2.StatusBeginDate,101),GetdatE()
					From @Tab_StatusAcc t1
					Join kypenrollment.Padm_Account T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.StatusBeginDate,'1900-01-01') <> isnull(T2.StatusBeginDate,'1900-01-01')
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'ProvCode',T1.ProvisionalCode,T2.ProvisionalCode,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.ProvisionalCode,'') <> isnull(T2.ProvisionalCode,'')
				
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'ProvCodeDT',Convert(varchar(10),T1.ProvisionalCodeDate,101),Convert(varchar(10),T2.ProvisionalCodeDate,101),GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.ProvisionalCodeDate,'1900-01-01') <> isnull(T2.ProvisionalCodeDate,'1900-01-01')	
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'LABStat',T1.LabStatusCode,T2.LabStatusCode,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.LabStatusCode,'') <> isnull(T2.LabStatusCode,'')

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'LABEFFDT',Convert(varchar(10),T1.LabStatusCodeDate,101),Convert(varchar(10),T2.LabStatusCodeDate,101),GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.LabStatusCodeDate,'1900-01-01') <> isnull(T2.LabStatusCodeDate,'1900-01-01')

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'OutOfStateInd',T1.OutOfStateInd,T2.OutOfStateInd,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.OutOfStateInd,'') <> isnull(T2.OutOfStateInd,'')
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'CHDPCode',T1.CHDPCode,T2.CHDPCode,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.CHDPCode,'') <> isnull(T2.CHDPCode,'')					

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'ReEnrollIn',T1.ReEnrolInd,T2.ReEnrolInd,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.ReEnrolInd,'') <> isnull(T2.ReEnrolInd,'')	

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'ReEnrollDate',Convert(varchar(10),T1.ReEnrolDate,101),Convert(varchar(10),T2.ReEnrolDate,101),GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.ReEnrolDate,'1900-01-01') <> isnull(T2.ReEnrolDate,'1900-01-01')

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'PracticeCode',T1.PracTypeCode1+T1.PracTypeCode2,T2.PracTypeCode1+T2.PracTypeCode2,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.PracTypeCode1,'') <> isnull(T2.PracTypeCode1,'')	
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'PracticeCode',T1.PracTypeCode1+T1.PracTypeCode2,T2.PracTypeCode1+T2.PracTypeCode2,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.PracTypeCode2,'') <> isnull(T2.PracTypeCode2,'')
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'TINUpdateType',T1.TINUpdateType,T2.TINUpdateType,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.TINUpdateType,'') <> isnull(T2.TINUpdateType,'')

					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'TINUpdateDate',Convert(varchar(10),T1.TINUpdateDate,101),Convert(varchar(10),T2.TINUpdateDate,101),GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.TINUpdateDate,'1900-01-01') <> isnull(T2.TINUpdateDate,'1900-01-01')
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'SpecProcTypeCode',T1.SpecProcTypeCode,T2.SpecProcTypeCode,GetdatE()
					From @Tab_IUD_Fields t1
					Join kypenrollment.Edm_AccountInternalUse T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.SpecProcTypeCode,'') <> isnull(T2.SpecProcTypeCode,'')																															
										
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					Select T1.AccountID,'EffectiveBeingDate',Convert(varchar(10),T1.OwnerEffDate,101),Convert(varchar(10),T2.EffectiveBeingDate,101),GetdatE()
					From @Tab_OwnerEffDate t1
					Join kypenrollment.pAccount_Owner T2 on t1.AccountID=T2.AccountID
					Where isnull(T1.OwnerEffDate,'1900-01-01') <> isnull(T2.EffectiveBeingDate,'1900-01-01')		
		
					--Changed the Insert statement for CAPAVE-5356 by Sundar on 26Mar2019
					--Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					--Select Top 1 AccountID,'CI',null,T1.[CodeIdentification],GetdatE()
					--From (Select AccountID,[CodeIdentification],[CodeDateEffDate],[CodeDateExpDate] 
					--		From @Tab_IUD_Many
					--		Where CodeType='Category'
					--		Except
					--		Select a.AccountID, b.CodeIdentification,B.CodeDateEffDate,b.CodeDateExpDate
					--		From kypenrollment.edm_AccountInternalUse a
					--		Join kypenrollment.edm_accountinternalMany b on A.accountinternaluseid=b.AccountinternaluseID
					--		Where B.CodeType='Category'
					--		and A.AccountID = @AccountID
					--		and b.CurrentRecordFlag=1) t1
					
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)					
					Select AccountID,'CI',null,T1.[CodeIdentification],GetdatE()
					From (Select a.AccountID, b.CodeIdentification,B.CodeDateEffDate,b.CodeDateExpDate
							From kypenrollment.edm_AccountInternalUse a
							Join kypenrollment.edm_accountinternalMany b on A.accountinternaluseid=b.AccountinternaluseID
							Where B.CodeType='Category'
							and A.AccountID = @AccountID
							and b.CurrentRecordFlag=1
							Except
							Select AccountID,[CodeIdentification],[CodeDateEffDate],[CodeDateExpDate] 
							From @Tab_IUD_Many
							Where CodeType='Category') t1						
					
					--Changed the Insert statement for CAPAVE-5356 by Sundar on 26Mar2019
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					--Select Top 1 @AccountID,'LI',null,T1.[CodeIdentification],GetdatE()
					--From @Tab_IUD_Many t1
					--Where CodeType='Specialty'	
					Select AccountId,'LI',Null,CodeIdentification,GETDATE()
					From (Select a.AccountID, b.CodeIdentification,B.CodeDateEffDate,b.CodeDateExpDate
							From kypenrollment.edm_AccountInternalUse a
							Join kypenrollment.edm_accountinternalMany b on A.accountinternaluseid=b.AccountinternaluseID
							Where B.CodeType='Specialty'
							and A.AccountID = @AccountID
							and b.CurrentRecordFlag=1
							Except
							Select Top 1 @AccountID,T1.[CodeIdentification],CodeDateEffDate,CodeDateExpDate
							From @Tab_IUD_Many t1
							Where CodeType='Specialty') T										
					
					--Changed the Insert statement for CAPAVE-5356 by Sundar on 26Mar2019
					Insert into KypEnrollment.InputDoc_Biller(AccountID, FieldName, FromValue, ToValue, DateModified)
					--Select Top 1 @AccountID,'SI',null,T1.[CodeIdentification],GetdatE()
					--From @Tab_IUD_Many t1
					--Where CodeType='Sanction'	
					Select AccountId,'SI',Null,CodeIdentification,GETDATE()
					From (Select a.AccountID, b.CodeIdentification,B.CodeDateEffDate,b.CodeDateExpDate
							From kypenrollment.edm_AccountInternalUse a
							Join kypenrollment.edm_accountinternalMany b on A.accountinternaluseid=b.AccountinternaluseID
							Where B.CodeType='Sanction'
							and A.AccountID = @AccountID
							and b.CurrentRecordFlag=1
							Except
							Select Top 1 @AccountID,T1.[CodeIdentification],CodeDateEffDate,CodeDateExpDate
							From @Tab_IUD_Many t1
							Where CodeType='Sanction') T										
	
					Delete From @Tab_StatusAcc;
					Delete From @Tab_IUD_Fields;		
					Delete From @Tab_OwnerEffDate;
					Delete From @Tab_IUD_Many;

				END

				SET @CountSupplemental = @CountSupplemental - 1

				/*Added the below Update statements by Sundar for Elk Implementation on 25 Feb 2019*/				
				Update kypenrollment.pAccount_PDM_Number
				Set LastActionDate = GETDATE()
				Where PartyID = (Select PartyID from Kypenrollment.pADM_Account where AccountID = @AccountID);	

			END	
			
		END
	End Try
	Begin Catch
		 IF @@TRANCOUNT > 0
		 ROLLBACK TRANSACTION 
		  
		 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'ApplicationNumber',@KeyValue = @LastActionComments; 
		 
	End Catch	
END


GO

