
CREATE PROCEDURE [KYP].[p_InsertResolutionHistory] 
	@AlertNo VARCHAR(500),
	@CaseID INT,
	@RelatedEntityID INT,
	@CurrentWFStatus VARCHAR(50),
	@Username VARCHAR(25),
	@NotesDescription VARCHAR(MAX),
	@MultipleTrackingNo VARCHAR(100)
AS
BEGIN

	SET NOCOUNT ON;
	IF @AlertNo IS NULL
	BEGIN
		EXEC [KYP].[sp_PopulateAlertWorkflowHistory] @CaseID
			,@RelatedEntityID
			,@CurrentWFStatus
			,@Username
			,@NotesDescription
			,@MultipleTrackingNo
	END
	ELSE
	BEGIN
		DECLARE @CaseID_M INT;

		IF OBJECT_ID(N'tempdb..#tmp_1') IS NOT NULL
		BEGIN
			DROP TABLE #tmp_1
		END

		CREATE TABLE #tmp_1 (
			[ID] INT
			,AlertID INT
			)

		INSERT INTO #tmp_1
		SELECT *
		FROM dbo.Split(@AlertNo, ',')

		DECLARE multipleAlert CURSOR
		FOR
		SELECT AlertID
		FROM #tmp_1

		OPEN multipleAlert

		FETCH NEXT
		FROM multipleAlert
		INTO @CaseID_M

		WHILE @@Fetch_Status = 0
		BEGIN
			--PRINT 'IN LOOP'
			PRINT @NotesDescription

			EXEC [KYP].[sp_PopulateAlertWorkflowHistory] @CaseID_M
				,@RelatedEntityID
				,@CurrentWFStatus
				,@Username
				,@NotesDescription
				,@MultipleTrackingNo

			FETCH NEXT
			FROM multipleAlert
			INTO @CaseID_M
		END
		
		CLOSE multipleAlert
		DEALLOCATE multipleAlert
	END

END


GO

