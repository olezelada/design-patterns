
/* ==========================================================
-- Author:		<D-Harbor>
-- PROCEDURE: Update ProviderName Account.
-- PARAMETERS:
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_id : AccountID that will be update.
-- @last_action_user_id : Enrollment User.
-- @package_name : application package code
--this SP is only for group application
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_ProviderName_Account]
    @application_no      VARCHAR(15),
    @account_id          INT,
    @last_action_user_id VARCHAR(100),
    @package_name        VARCHAR(100)
AS
  BEGIN
    IF (@package_name = 'F_OOS_OE')
      BEGIN
        PRINT 'Update Provider Name TWIN ACCOUNT'
        DECLARE @application_id INT, @party_app_id INT, @application_type VARCHAR(50)

        SELECT @application_id = ApplicationID, @party_app_id = PartyID, @application_type = ApplicationType
        FROM [KYPPORTAL].[PortalKYP].[pADM_Application]
        WHERE ApplicationNo = @application_no;

        DECLARE @acc_party_id INT,
        @npi_Type VARCHAR(25),
        @account_number INT,
        @npi VARCHAR(10),
        @legal_name_id INT,
        @address_id INT,
        @provider_type_code VARCHAR(5),
        @service_location_no VARCHAR(3)

        SELECT @acc_party_id = PartyID, @account_number = AccountNumber, @npi_Type = NPIType, @npi = NPI,
          @provider_type_code = ProviderTypeCode, @service_location_no = ServiceLocationNo
        FROM [KYPEnrollment].[pADM_Account]
        WHERE AccountID = @account_Id;

        BEGIN TRANSACTION
        BEGIN TRY

        SELECT @legal_name_id = OrgID
        FROM [KYPEnrollment].[pAccount_PDM_Organization]
        WHERE PartyID = @acc_party_id;

        SELECT @address_id = AddressID
        FROM KYPEnrollment.pAccount_PDM_Location
        WHERE PartyID = @acc_party_id AND Type = 'Servicing';
        
        EXEC [KYPEnrollment].[FBP_Legal_Name_Address] @account_id, @legal_name_id, @address_id, @npi_Type, @last_Action_User_ID, @npi,@acc_party_id, @party_app_id,1, @provider_type_code, @account_number,@service_location_no,'',@application_id,0,@application_type,null;

Insert into Debug(fieldName,FieldValue,ProcedureName,OtherComments,logtime)
select 'ServicelocationNo',ServiceLocationNo,'sp_Update_ProviderName_Account',AccountID,GETDATE()
From kypenrollment.padm_Account with (nolock)
where AccountID in (@account_id)
                                                             
        COMMIT TRANSACTION
        END TRY
        BEGIN CATCH
        IF @@TRANCOUNT > 0
          ROLLBACK TRANSACTION
        DECLARE @error_message NVARCHAR(4000), @error_severity INT;
        SELECT
          @error_message = ERROR_MESSAGE(),
          @error_severity = ERROR_SEVERITY();
        RAISERROR (@error_message, @error_severity, 1);
        END CATCH
      END
  END


GO

