
/* ==========================================================
-- Author:		<Digital Harbor>
-- PROCEDURE: create Personal Information and Identification Sections from Individual Profile form for Crossover Only Provider.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Personal_Inf_Crossover_Identification]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)

AS
BEGIN
DECLARE @person_id INT,@person_id_appliction INT,@full_name_person VARCHAR(100),
@date_created DATE;
SET @date_created =  GETDATE();
EXEC @person_id = [KYPEnrollment].[sp_Copy_Person] @party_account_id,@party_app_id,@last_action_user_id,'C';

PRINT 'New Person '+ CONVERT(VARCHAR(10),@person_id)+' Personal Information And Identification';
RETURN @person_id;
END


GO

