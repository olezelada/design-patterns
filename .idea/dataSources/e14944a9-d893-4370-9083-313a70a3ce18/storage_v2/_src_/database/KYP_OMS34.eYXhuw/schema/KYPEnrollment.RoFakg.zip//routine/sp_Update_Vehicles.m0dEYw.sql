
/* ==========================================================
-- Author:		<Lacunza, Giresse>
-- PROCEDURE: Update Party Counselor by Traking.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name : 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Vehicles]


@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1),
@acc_table_name varchar(100),
@applicationId INT


AS
BEGIN
SET NOCOUNT ON;
DECLARE @app_party_id INT,@acc_id int, @delete VARCHAR(MAX), @app_counselor_id int,@new_party_son int,@address_aux int, 
@person_id int,@app_person_id int,@app_alias_id int, @new_address_acc int,@location_aux int,@type varchar(100);

  select top 1 @acc_id = AccountID from KYPEnrollment.pADM_Account ac where ac.PartyID = @acc_party_id and ac.IsDeleted=0


IF @action_taken='Added' 
---------  
  BEGIN
---------  
	SELECT @app_counselor_id = PartyID FROM [KYPPORTAL].[PortalKYP].pPDM_Party WHERE TargetPath=@target_path;
	
    if @target_path NOT LIKE '%|%' and NOT EXISTS(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_counselor_id AND NameTable='pAccount_PDM_Vehicle')
	begin
		PRINT @action_taken 
		

		SELECT @app_party_id = p.PartyID, @acc_PK_value = VehicleId,@type = VehicleType FROM [KYPPORTAL].[PortalKYP].[pPDM_Vehicle] p WHERE TargetPath =@target_path



IF (@type in ('Aircraft','Pilot') and exists(select * from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p 
on a.PartyID=p.ParentPartyID where p.PartyID=@app_party_id and a.ProviderTypeCode='038'))
OR
(@type in ('Ambulance','Van','AmbulanceDriver','LitterWheelchairVanDriver', 'Non-Medical Operator', 'Non-Medical Vehicle') and exists(select * from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p
on a.PartyID=p.ParentPartyID where p.PartyID=@app_party_id and a.ProviderTypeCode='030'))

begin



	
		EXEC @new_party_son =  [KYPEnrollment].[sp_Copy_Party] 		@app_party_id,	@acc_party_id,	@acc_id,	@last_action_user_id
		
		EXEC [KYPEnrollment].[sp_Copy_Vehicle] 	@new_party_son,	@acc_PK_value,	@last_Action_User_ID;
		select @address_aux = a.AddressID, @location_aux = l.LocationID from KYPPORTAL.PortalKYP.pPDM_Address a INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location l ON a.AddressID=l.AddressID where l.PartyID=@app_party_id
		EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @acc_id, @app_party_id, @new_party_son
			
		exec  @new_address_acc = [KYPEnrollment].[p_Copy_Address]	@address_aux,@last_action_user_id
		EXEC [KYPEnrollment].[sp_Copy_Location]	@location_aux,	@new_address_acc,	null,	@new_party_son,	@last_action_user_id
		
		
		
		

		select @app_person_id = PersonID from KYPPORTAL.PortalKYP.pPDM_Person where PartyID=@app_party_id and Deleted=0
		IF @app_person_id is not null
		begin
			
			EXEC @person_id = [KYPEnrollment].[sp_Copy_Person] @new_party_son, @app_party_id,@last_action_user_id
			
			select @app_alias_id = PesonONID from KYPPORTAL.PortalKYP.pPDM_Person_OtherName where PersonID=@app_person_id and IsDeleted=0
			
			IF @app_alias_id is not null
			begin
				EXEC [KYPEnrollment].[sp_Copy_Person_OtherName] @person_id,@app_person_id,@last_action_user_id,@app_alias_id,@new_party_son 
			end
			
		end
		
		INSERT INTO #Control_Add_row(FiledID,NameTable)
		VALUES(@app_party_id,'pAccount_PDM_Vehicle'); 
end  
	end
  
  ELSE
  
  begin  
	PRINT @action_taken 
	EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
  end

----------
  END
----------   

IF @action_taken='Updated'
		BEGIN
			PRINT @action_taken
			
			EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;

      DECLARE @vehicleAppPartyID INT, @vehicleAccPartyID INT

      SELECT @vehicleAppPartyID = vehicle.PartyID
      FROM KYPPORTAL.PortalKYP.pPDM_Vehicle vehicle
        INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party party on party.PartyID =  vehicle.PartyId
        INNER JOIN KYPPORTAL.PortalKYP.pADM_Application app on app.PartyID = party.ParentPartyID
      WHERE vehicle.TargetPath = @target_path AND app.ApplicationID = @applicationId

      SELECT @vehicleAccPartyID = vehicleAcc.PartyID
      FROM KYPEnrollment.pAccount_PDM_Vehicle vehicleAcc
      WHERE vehicleAcc.VehicleId = @acc_PK_value

      PRINT '----------------- ATTACH UPDATE VEHICLES ----------------'
      PRINT @vehicleAccPartyID
      PRINT @vehicleAppPartyID
      PRINT @target_path
      PRINT @acc_PK_value
      PRINT '----------------------------------------------------------'

      EXEC KYPEnrollment.sp_Update_Attachments_References_Parties @acc_id, @vehicleAppPartyID, @vehicleAccPartyID
			
		END   
   
IF NOT EXISTS (SELECT TargePath FROM #Control_Add_row WHERE TargePath = @target_path)
		BEGIN
  			IF @action_taken='Deleted'
			BEGIN
				PRINT @action_taken
				if @acc_PK_value is not null
				begin
					print 'acc_PK_value'
					print @acc_PK_value
					EXEC [KYPEnrollment].[turn_delete_tables] @acc_table_name,@acc_PK,@acc_PK_value
				end
				ELSE
				begin
					
					print '@target_path'
					print @target_path
					update KYPEnrollment.pAccount_PDM_Vehicle SET IsDeleted=1,CurrentRecordFlag=0 where TargetPath=@target_path
				end
				
				INSERT INTO #Control_Add_row(TargePath) VALUES(@target_path);
			END
		END  
   
END
GO

