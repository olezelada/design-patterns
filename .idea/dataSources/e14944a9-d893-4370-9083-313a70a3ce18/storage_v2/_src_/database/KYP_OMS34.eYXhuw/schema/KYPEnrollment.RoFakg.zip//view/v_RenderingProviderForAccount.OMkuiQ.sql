








CREATE VIEW [KYPEnrollment].[v_RenderingProviderForAccount]
AS
SELECT     row_number() OVER (ORDER BY AccountID ASC) AS ID, *
         
FROM         
(

select DISTINCT 
A.AccountID,
Case When(CONVERT(VARCHAR, RAff.AffiliationStartDate , 101) =  
CONVERT(VARCHAR, GETDATE()-1, 101)) then 'A' 
When (CONVERT(VARCHAR, RAff.AffiliationEndDate , 101) =  
CONVERT(VARCHAR, GETDATE()-1, 101)) then 'D' 
else
 'E' END AS ReqType

-- Field of pAccount_PDM_Number (For Rendring)
,AR.NPI AS Provider,
AR.OwnerNo AS OWNERNO,
Ar.ServiceLocationNo AS SLocNo,
AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType ,
Raff.LastActionDate,Raff.LastUpdatedBy


from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID

-- This is for  Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
where  CONVERT(VARCHAR, RAff.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101) and RAff.LastUpdatedBy != 'M' and
 RAff.AffiliatedAccountID is not null  and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')
 
  
UNION 


select DISTINCT 
A.AccountID,
Case When(CONVERT(VARCHAR, RAff.AffiliationStartDate , 101) =  
CONVERT(VARCHAR, GETDATE()-1, 101)) then 'A' 
When (CONVERT(VARCHAR, RAff.AffiliationEndDate , 101) =  
CONVERT(VARCHAR, GETDATE()-1, 101)) then 'D' 
else
 'E' END AS ReqType
-- Field of pAccount_PDM_Number (For Rendring)
,AR.NPI AS Provider,
AR.OwnerNo AS OWNERNO,
Ar.ServiceLocationNo AS SLocNo,
AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType ,

Raff.LastActionDate,Raff.LastUpdatedBy

from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID

-- This is for  Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
where  CONVERT(VARCHAR, RAff.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101) and RAff.LastUpdatedBy != 'M' and
   RAff.AccountID is not null and  RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')

) z
------------------------------------------------------------------- Close of NMP Relationship file ----------------------------------------------------------------------


GO

