--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket				Description
--------------------------------------------------------------------------------------------------------
-- 1		08-jan-2019	    Mvillarroel DBAB-990				Commented the sentence disable/enabled triggers for MDM.Alert table for prevent the deadlocks


CREATE PROCEDURE [dbo].[p_UpdateAlertage]
AS
BEGIN
	ALTER TABLE KYP.ADM_Case DISABLE TRIGGER DashboardTable_Insert

	--------Updating Alert age in MDM_Dashboardtable------------------
	UPDATE A
	SET [AgeByDays] = ABS(Datediff(d, B.DateInitiated, getdate()))
		,[Range] = KYP.AuditDays(B.DateInitiated)
	FROM [KYP].[MDM_DashBoardTable] A
	JOIN KYP.MDM_Alert B ON A.AlertID = B.AlertID

	UPDATE A
	SET [AgeByDays] = ABS(Datediff(d, B.DateInitiated, getdate()))
		,[Range] = KYP.AuditDays(B.DateInitiated)
		,[DaysCurrentStatus] = ABS(Datediff(d, B.DateResolved, getdate()))
	FROM [KYP].[DSH_DashBoardTable] A
	JOIN KYP.ADM_Case B ON A.CaseID = B.CaseID

	UPDATE KYP.ADM_Case
	SET [CaseAge] = ABS(Datediff(d, DateInitiated, getdate()));

    --mvc
	--DISABLE TRIGGER trg_MDM_AlertOnInsert ON KYP.MDM_Alert;

	--DISABLE TRIGGER trg_MDM_AlertOnUpdate ON KYP.MDM_Alert;

	--DISABLE TRIGGER trg_OwnerEmployeeCountPopulation ON KYP.MDM_Alert;

	/************KYP 3.4 (MON-68) - Added the below logic for calculating the age for open alerts *********/
	UPDATE KYP.MDM_Alert
	SET 
	Row_Updation_Source='p_UpdateAlertage',
	[AlertOpen] = CASE 
						WHEN WFStatus = 'Completed' THEN ABS(DATEDIFF(DD, DateInitiated, DateClosed))
						WHEN WFStatus <> 'Completed' THEN ABS(DATEDIFF(DD, DateInitiated, GETDATE()))
						END;
	/************KYP 3.4 (MON-68) - END *********/

	UPDATE KYP.MDM_Alert
	SET Row_Updation_Source='p_UpdateAlertage',[AlertClose] = ABS(DATEDIFF(DD, DateInitiated, DateClosed));

	--ENABLE TRIGGER trg_MDM_AlertOnInsert ON KYP.MDM_Alert;

	--ENABLE TRIGGER trg_MDM_AlertOnUpdate ON KYP.MDM_Alert;

	--ENABLE TRIGGER trg_OwnerEmployeeCountPopulation ON KYP.MDM_Alert;

	ALTER TABLE KYP.ADM_Case ENABLE TRIGGER [DashboardTable_Insert]
END


GO

