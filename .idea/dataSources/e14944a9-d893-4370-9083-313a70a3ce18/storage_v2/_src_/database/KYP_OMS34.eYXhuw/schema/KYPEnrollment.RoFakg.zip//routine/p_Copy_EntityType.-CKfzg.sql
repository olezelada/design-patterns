
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Type Entity recive 3  para metros
-- @partyId old aprty id ,@newPartyIdProv nuevo party id ,	@lastActionUserID nombre del usuario que realiza la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_EntityType]
	@partyId INT,
	@newPartyIdProv INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_EntityType]
	([PartyID] ,
	[NameEntityType] ,
	[TypeProfit] ,
	[CorporateNumber] ,
	[StateIncorporated] ,
	[LlcNumber] ,
	[StateRegistered] ,
	[TypeNonProfit] ,
	[Other] ,
	[LastAction] ,
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy], 
	[CurrentRecordFlag] )
	SELECT @newPartyIdProv
	,[NameEntityType]
	,[TypeProfit]
	,[CorporateNumber]
	,[StateIncorporated]
	,[LlcNumber]
	,[StateRegistered]
	,[TypeNonProfit]
	,[Other]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	FROM [KYPPORTAL].[PortalKYP].[pADM_App_EntityType] WHERE PartyID = @partyId

	SELECT @message = '[pAccount_PDM_EntityType] @newEntityTypeId : ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT					
END


GO

