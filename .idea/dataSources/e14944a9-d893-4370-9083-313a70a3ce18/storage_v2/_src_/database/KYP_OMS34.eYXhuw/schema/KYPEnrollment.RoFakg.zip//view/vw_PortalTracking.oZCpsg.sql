


CREATE VIEW [KYPEnrollment].[vw_PortalTracking] (
	ApplicationID, FieldValueID, Field, OldValue, NewValue, ValueType, 
    ActionTaken, Section, TableX,changePath, RowUUID, Accepted, FieldCode, SectionID, FormID, SubFormID, IsMandatory, Type,FieldID,DataType
    ,AppPartyID,CreatedDate
)
AS

--For Boolean changes
  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  (Case when ft.CurrentValueBool=1 then 'True' else 'False' end), (Case when ft.NewValueBool=1 then 'True' else 'False' end), 'Boolean', ft.ActionTaken  
  	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
    , ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null 
  and (ft.CurrentValueBool is not null or ft.NewValueBool is not null)
--Date  
UNION

  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  left(convert(varchar(1000),ft.CurrentValueDate,101),10), left(convert(varchar(1000),ft.NewValueDate,101),10), 'Date', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
 from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null
  and (ft.CurrentValueDate is not null or ft.NewValueDate is not null)
--Double  
UNION


  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  convert(varchar(1000),ft.CurrentValueDouble), convert(varchar(1000),ft.NewValueDouble), 'Double', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
  		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null
  and (ft.CurrentValueDouble is not null or ft.NewValueDouble is not null)
--Int  
UNION

  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  convert(varchar(1000),ft.CurrentValueInt), convert(varchar(1000),ft.NewValueInt), 'Int', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
  		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null
  and (ft.CurrentValueInt is not null or ft.NewValueInt is not null)
--Long
UNION

  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  convert(varchar(1000),ft.CurrentValueLong), convert(varchar(1000),ft.NewValueLong), 'Long', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
  		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null
  and (ft.CurrentValueLong is not null or ft.NewValueLong is not null)
--Text
UNION

  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  convert(varchar(1000),ft.CurrentValueText), convert(varchar(1000),ft.NewValueText), 'Text', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+' - ' end)+isnull(ft.FieldLabel,''), ft.RowUUID
  		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE (ft.IsDeleted = 0 or ft.IsDeleted is null) and ft.ActionTaken is not null
  	and (ft.CurrentValueBool 	is null and ft.NewValueBool is null)
	and (ft.CurrentValueDate 	is null and ft.NewValueDate is null)
	and (ft.CurrentValueDouble 	is null and ft.NewValueDouble is null)
	and (ft.CurrentValueLong 	is null and ft.NewValueLong is null)
	and (ft.CurrentValueInt 	is null and ft.NewValueInt is null)
--Delete
UNION

  SELECT ft.ApplicationID, ft.FieldValueID, ft.FieldLabel,  convert(varchar(1000),ft.CurrentValueLong), convert(varchar(1000),ft.NewValueLong), 'Text', ft.ActionTaken  
    	, ft.SectionNanme, ft.TableName, (case when ft.SectionNanme is null then '' else ft.SectionNanme+' - ' end)+(case when ft.TableName is null then '' else ft.TableName+'' end), ft.RowUUID
  		, ft.Accepted,ft.FieldCode,ft.SectionID,ft.FormID,ft.SubFormID, ft.MandatoryReview ,'',0,ft.DataType,FT.AppPartyID,FT.CreatedDate
  from [KYPPORTAL].[PORTALKYP].[FieldValuesTracking] ft 
  WHERE ft.ActionTaken = 'Deleted'


GO

