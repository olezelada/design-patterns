
CREATE VIEW [KYPEnrollment].[pViewReFindingDocument] AS
	select ROW_NUMBER() OVER( ORDER BY ReviewDocumentID ) as ViewID, er.*,ef.DescriptionPlain,ef.FieldName,ef.Type,ef.Since from KYPEnrollment.pEDM_ReviewDocument er INNER JOIN KYPEnrollment.pEDM_Findings ef on ef.FindingID=er.FindingID


GO

