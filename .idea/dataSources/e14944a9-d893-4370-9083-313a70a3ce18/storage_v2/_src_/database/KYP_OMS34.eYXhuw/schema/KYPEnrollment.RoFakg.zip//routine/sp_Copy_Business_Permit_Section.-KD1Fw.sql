-- =============================================
-- Author:		<DH-BOL>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts copy al data related to the BUSINESS PROFILE SECTION of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Permit_Section]
@new_Party_Id int,
@party_Id int,
@last_action_user_id varchar(50)

AS
BEGIN

EXEC [KYPEnrollment].[sp_Copy_Twin_NumberFromLicense] @new_Party_Id, @party_Id, @last_action_user_id,'BusinessPermits';
EXEC [KYPEnrollment].[Copy_Twin_Number] @new_Party_Id, @party_Id, @last_action_user_id, 'Permit Local Number';

END


GO

