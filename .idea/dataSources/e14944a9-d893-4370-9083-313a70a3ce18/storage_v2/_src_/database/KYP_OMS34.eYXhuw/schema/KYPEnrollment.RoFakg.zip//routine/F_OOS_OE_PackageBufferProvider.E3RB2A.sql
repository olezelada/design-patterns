CREATE PROCEDURE [KYPEnrollment].[F_OOS_OE_PackageBufferProvider]

		@applicatioNo VARCHAR(50),
		@caseId INT

AS
	BEGIN
		DECLARE @total INT, @count INT,@provtypecode varchar(50)
		SET NOCOUNT ON;
				
				
				SELECT @provtypecode = a.ProviderTypeCode FROM KYPPORTAL.PortalKYP.pADM_Application a
				WHERE a.ApplicationNo = @applicatioNo and a.IsDeleted=0
				
				
		IF (@provtypecode IN ('015','016'))
			BEGIN
				INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber)
				VALUES ('015', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 150000000+@caseId))),
				('016', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 160000000+@caseId)))

			END

	END


GO

