-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[trg_OnPhysicalDeletion_SDM_Communication]
   ON  [KYP].[SDM_Communication]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (
			SELECT 1 
			FROM DELETED A 
				INNER JOIN KYP.CommunicationEntity B 
					ON A.CommID = B.CommID						
				INNER JOIN KYP.FrameworkCount C
					ON B.CommEntityType = C.FrameworkEntityType
						AND B.CommEntityTypeID = C.FrameworkEntityTypeID
		)
	UPDATE A 
		SET A.CommunicationCount = case 
									when A.CommunicationCount>1 then A.CommunicationCount -1 
									else 0  
								end ,
			A.ModifiedDate = getdate(),
			A.ModifiedBy = 'Communication Decreased'	
	FROM KYP.FrameworkCount A	
	INNER JOIN KYP.CommunicationEntity B 
		ON A.FrameworkEntityType = B.CommEntityType
			AND A.FrameworkEntityTypeID = B.CommEntityTypeID
	INNER JOIN DELETED C
		ON B.CommID = C.CommID		


    -- Insert statements for trigger here

END


GO

