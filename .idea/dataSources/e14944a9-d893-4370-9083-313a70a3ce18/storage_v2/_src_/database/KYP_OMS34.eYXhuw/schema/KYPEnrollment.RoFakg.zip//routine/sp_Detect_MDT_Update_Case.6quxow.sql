-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <20/11/2017>
-- Description:	<This sp look for a change on the mode of transportation to create a clone account with the respective transportation mode>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Detect_MDT_Update_Case]
@account_id int,
@application_no varchar(10),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@composite_risk INT,
@case_id INT,
@risk VARCHAR(15),
@application_type VARCHAR(35),
@main_app_number varchar(10)

AS
BEGIN
declare @code_acc varchar(10),@accountNumber VARCHAR(20),@npi varchar(20),@case int
,@acc_aux int, @app_id int,@account_internal_use_id int,@LastActionComments varchar(200)

DECLARE @exist_air_vehicles bit,@exist_air_operators bit,@exist_ground_vehicles bit,@exist_ground_operators bit,@tot int, @cont int,@add int,@buf varchar(100);
declare @types table (pk int identity(1,1),type varchar(100))
declare @NonMedicalVehicle bit,@NonMedicalOperator bit


	SET NOCOUNT ON;
	
	select @app_id = ApplicationID from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@application_no
	
	INSERT INTO @types (type)
    select o.OperatorType from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p on a.PartyID=p.ParentPartyID inner join 
    KYPPORTAL.PortalKYP.pPDM_Operators o on p.PartyID=o.PartyId and a.ApplicationNo=@application_no and a.IsDeleted=0 and p.IsDeleted=0 and o.Approved=1 and o.IsDeleted=0
	    
	INSERT INTO @types (type)
    select o.VehicleType from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p on a.PartyID=p.ParentPartyID inner join 
    KYPPORTAL.PortalKYP.pPDM_Vehicle o on p.PartyID=o.PartyId and a.ApplicationNo=@application_no and a.IsDeleted=0 and p.IsDeleted=0 and o.Approved=1 and o.IsDeleted=0
	
	select @tot =MAX(pk) from @types;
	SET @cont=1;
	
	BEGIN TRY
	
	WHILE @cont<=@tot
	BEGIN
		
		SELECT @buf = type from @types where pk=@cont
		IF @buf in ('Aircraft')
		begin
			set @exist_air_vehicles = 1	
		end
		
		IF @buf in ('Pilot')
		begin
			set @exist_air_operators = 1
		end			
		
		IF @buf in ('Ambulance','Van')
		begin
			set @exist_ground_vehicles = 1
		end
		
		IF @buf in ('AmbulanceDriver','LitterWheelchairVanDriver')
		begin
			set @exist_ground_operators = 1
		end					

		
		IF @buf in ('Non-Medical Operator')
		begin
			set @NonMedicalOperator = 1
		end		

		IF @buf in ('Non-Medical Vehicle')
		begin
			set @NonMedicalVehicle = 1
		end		

		
		SET @cont = @cont +1
		
	END
	
	SELECT @code_acc = a.ProviderTypeCode, @accountNumber = a.AccountNumber,@npi = a.npi  from KYPEnrollment.pADM_Account a where a.AccountID=@account_id and IsDeleted=0

	IF @application_type NOT IN ('CHOW')
	BEGIN
		
		IF @exist_air_vehicles = 1 and @exist_air_operators = 1 	AND NOT EXISTS (select AccountID from KYPEnrollment.pADM_Account where NPI=@npi and ProviderTypeCode='038' and IsDeleted=0 and IsPastOwner=0 and StatusAcc like '1%')
		begin
			
			print 'CREATING 038'
		
			SET @case = 110000000+@case_id
			print @case
			EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no, 
														 @last_Action_User_ID, 
														 @priority, 
														 @risk,
							                             @composite_risk, 
								                         @case, 
									                     @application_type,
										                 '038', 
											             @case
											             

	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @case
            , @app_id
            , @application_no
            , @application_type)									             


		end	
			
		IF ((@exist_ground_vehicles=1 and @exist_ground_operators=1) OR (@NonMedicalVehicle = 1 and @NonMedicalOperator = 1))	
		AND NOT EXISTS (select AccountID from KYPEnrollment.pADM_Account where NPI=@npi and ProviderTypeCode='030' and IsDeleted=0 and IsPastOwner=0 and StatusAcc like '1%')
		begin			
			
			print 'CREATING 030'
		
			SET @case = 120000000+@case_id
			print @case
			EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no, 
														 @last_Action_User_ID, @priority, @risk,
														 @composite_risk,
														 @case, 
														 @application_type,
														 '030', 
														 @case;
														 
	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @case
            , @app_id
            , @application_no
            , @application_type)



		end                                                     

	END



	IF @application_type IN ('CHOW')
	BEGIN

		IF @exist_air_vehicles = 1 and @exist_air_operators = 1	AND NOT EXISTS (select AccountID from KYPEnrollment.pADM_Account where NPI=@npi and ProviderTypeCode='038' and IsDeleted=0 and IsPastOwner=0 and StatusAcc like '1%')
							AND NOT EXISTS (SELECT AccountID from KYPEnrollment.pADM_Account a where a.NPI=@npi and a.ProviderTypeCode='038' and a.IsDeleted=0 and @application_type='CHOW')
		begin
			
			print 'CREATING 038 (IN CHOW)'
		
			SET @case = 110000000+@case_id
			print @case
			EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no, 
														 @last_Action_User_ID, 
														 @priority, 
														 @risk,
							                             @composite_risk, 
								                         @case, 
									                     @application_type,
										                 '038', 
											             @case
											             

	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @case
            , @app_id
            , @application_no
            , @application_type)
										             


											             
		end	
	
		IF ((@exist_ground_vehicles=1 and @exist_ground_operators=1) OR (@NonMedicalVehicle = 1 and @NonMedicalOperator = 1))	AND NOT EXISTS (select AccountID from KYPEnrollment.pADM_Account where NPI=@npi and ProviderTypeCode='030' and IsDeleted=0 and IsPastOwner=0 and StatusAcc like '1%')
							AND NOT EXISTS (SELECT AccountID from KYPEnrollment.pADM_Account a where a.NPI=@npi and a.ProviderTypeCode='030' and a.IsDeleted=0 and @application_type='CHOW')
		begin			
			
			print 'CREATING 030 (IN CHOW)'
		
			SET @case = 120000000+@case_id
			print @case
			EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no, 
														 @last_Action_User_ID, @priority, @risk,
														 @composite_risk,
														 @case, 
														 @application_type,
														 '030', 
														 @case;


	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @case
            , @app_id
            , @application_no
            , @application_type)
									             


														 
		end         
	
	END

END TRY

BEGIN CATCH
    
	DECLARE    @error_message NVARCHAR(4000),@error_severity INT;
	SELECT     @error_message = ERROR_MESSAGE()
		      ,@error_severity = ERROR_SEVERITY();
	RAISERROR (@error_message
              ,@error_severity
              ,1);
              
	EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @app_id                
	
END CATCH	

END
GO

