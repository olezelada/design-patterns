
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Linked Account Values.   
-- PARAMETERS: 
-- @linked_account_id : AccountID wich it is similar. 
-- @value : Value of Attribute. 
-- @attribute : Attribute with similarity.
-- ============================================================*/


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_LinkedAccountValue]
	@linked_account_id INT,
	@value VARCHAR(100),
	@attribute VARCHAR(50)	
AS
BEGIN
    SET NOCOUNT ON
	INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
	([Attribute]
	,[Value]
	,[LinkedAccountID])
	VALUES
	(@attribute
	,@value
	,@linked_account_id);
END


GO

