




CREATE VIEW [KYPEnrollment].[v_OutEDI_ORPFile_WeeklyReport_Reconciliation] as
With Q1 as (select *
	from KYPENROLLMEnt.pADM_Account
	where AccountType='orp'
	and isdeleted=0
	and ProviderTypeCode<>'100') --Added to eliminate Mixed Group records
,S_Add as (select L.PartyId,AD.AddressLine1 AS SAddressLine1,AD.AddressLine2 AS SAddressLine2,AD.City AS SCity,S.Abreviation AS SState,AD.Zip as SZip,RIGHT(AD.ZipPlus4,4) AS SZipPlus4
	From Q1 
	Join KYPEnrollment.pAccount_PDM_Location L ON Q1.PartyId=L.PartyID
	Join KYPEnrollment.pAccount_PDM_Address AD ON L.AddressID = AD.AddressID
	JOIN KYP.LK_Screening S ON AD.State=S.Description
	Where L.[Type]='Servicing'
		and AD.CurrentRecordFlag=1)	
,M_Add as (select L.PartyId,AD.AddressLine1 AS MAddressLine1,AD.AddressLine2 AS MAddressLine2,AD.City AS MCity,S.Abreviation AS MState,AD.Zip as MZip, RIGHT(AD.ZipPlus4,4) AS MZipPlus4
	From Q1 
	Join KYPEnrollment.pAccount_PDM_Location L ON Q1.PartyId=L.PartyID
	Join KYPEnrollment.pAccount_PDM_Address AD ON L.AddressID = AD.AddressID
	JOIN KYP.LK_Screening S ON AD.State=S.Description	
	Where L.[Type]='Mailing'
		and AD.CurrentRecordFlag=1)	
,ACS as (select Q1.AccountId,accs.statusValue,convert(varchar(10),accs.EffectiveBeginDate,101) EffectiveBeginDate,convert(varchar(10),accs.EffectiveEndDate,101) EffectiveEndDate,Row_number() over(partition by accs.AccountId order by accs.AccountStatusId desc) R
	from Q1
	Join kypenrollment.padm_accountstatus ACCS ON ACCS.accountid=Q1.accountid
	where ACCS.statustype='Enrollment')
,ACSV as (select T1.AccountId,LEFT(T1.statusValue,1) as statusValue1,T1.EffectiveBeginDate as EffectiveBeginDate1,T1.EffectiveEndDate as EffectiveEndDate1,
	LEFT(T2.statusValue,1) as statusValue2,T2.EffectiveBeginDate as EffectiveBeginDate2,T2.EffectiveEndDate as EffectiveEndDate2,
	LEFT(T3.statusValue,1) as statusValue3,T3.EffectiveBeginDate as EffectiveBeginDate3,T3.EffectiveEndDate as EffectiveEndDate3,
	LEFT(T4.statusValue,1) as statusValue4,T4.EffectiveBeginDate as EffectiveBeginDate4,T4.EffectiveEndDate as EffectiveEndDate4,
	LEFT(T5.statusValue,1) as statusValue5,T5.EffectiveBeginDate as EffectiveBeginDate5,T5.EffectiveEndDate as EffectiveEndDate5
	from (select AccountId,statusValue,EffectiveBeginDate,EffectiveEndDate
			from ACS 
			where R=1) T1
			LEft JOIN (select AccountId,statusValue,EffectiveBeginDate,EffectiveEndDate
			from ACS
			where R=2) T2 on T1.AccountId=T2.AccountId
			LEft JOIN (select AccountId,statusValue,EffectiveBeginDate,EffectiveEndDate
			from ACS
			where R=3) T3 on T1.AccountId=T3.AccountId
			LEft JOIN (select AccountId,statusValue,EffectiveBeginDate,EffectiveEndDate
			from ACS
			where R=4) T4 on T1.AccountId=T4.AccountId	
			LEft JOIN (select AccountId,statusValue,EffectiveBeginDate,EffectiveEndDate
			from ACS
			where R=5) T5 on T1.AccountId=T5.AccountId)		
SELECT distinct Q1.NPI,Q1.LegalName,Q1.SSN,NULL as [MCAL-ORP-ADDR-ATTEN-LN],S_Add.SAddressLine1,S_Add.SAddressLine2,S_Add.SCity,S_Add.SState,S_Add.SZip, S_Add.SZipPlus4
,NULL as [MCAL-ORP-MAIL-TO-ATTEN-LN],M_Add.MAddressLine1,M_Add.MAddressLine2,M_Add.MCity,M_Add.MState,M_Add.MZip,M_Add.MZipPlus4
,Q1.ProviderTypeCode
,ACSV.statusValue1,ACSV.EffectiveBeginDate1,ACSV.EffectiveEndDate1
,ACSV.statusValue2,ACSV.EffectiveBeginDate2,ACSV.EffectiveEndDate2
,ACSV.statusValue3,ACSV.EffectiveBeginDate3,ACSV.EffectiveEndDate3
,ACSV.statusValue4,ACSV.EffectiveBeginDate4,ACSV.EffectiveEndDate4
,ACSV.statusValue5,ACSV.EffectiveBeginDate5,ACSV.EffectiveEndDate5
,LC.Number AS LicenseNumber,LC.EffectiveDate AS LicenseEffectiveDate
,E.ProvisionalCode,E.ProvisionalCodeDate
,Q1.ReenrollmentIndicator,Q1.ReenrollmentDate,Q1.AccountUpdateDate,
Q1.AccountUpdatedBy
FROM Q1
Left Join S_Add ON Q1.PartyID = S_Add.PartyID
Left Join M_Add ON Q1.PartyID = M_Add.PartyID
Left Join ACSV ON Q1.AccountID = ACSV.AccountID
Left Join KYPEnrollment.pAccount_PDM_Number LC on Q1.PartyID=LC.PartyID AND LC.Type='Professional License' AND LC.CurrentRecordFlag=1
Left Join KYPEnrollment.EDM_AccountInternalUse E on E.AccountID=Q1.AccountID and E.CurrentRecordFlag = 1


GO

