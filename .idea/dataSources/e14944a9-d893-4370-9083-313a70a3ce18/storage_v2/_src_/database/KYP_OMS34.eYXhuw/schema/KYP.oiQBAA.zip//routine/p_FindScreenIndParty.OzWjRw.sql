

CREATE PROCEDURE [KYP].[p_FindScreenIndParty]
	-- Add the parameters for the stored procedure here
	@TrackingNumber varchar(20)
	,@LastName varchar(50) 
	,@FirstName varchar(50)
	,@SSN varchar(9) = NULL
	,@NPI varchar(10) = NULL
	,@LIC_CERT_NUM varchar(15) = NULL
	,@LIC_STATE varchar(20)=NULL
	,@CurrentModule smallint = 1,
	 @Isprovider int=1
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare 
		@PartyID_SameSSN_SameTracking int	
		,@PartyID_SameLicense_SameTracking int
		,@PartyID_SameNPI_SameTracking int
		,@PartyID_SameFirstLastName_SameTracking int
		,@PartyID_GenericMatch int 	
		,@MatchedPartyID int
	
	select 
		@PartyID_SameSSN_SameTracking = null
		,@PartyID_SameLicense_SameTracking = null
		,@PartyID_SameNPI_SameTracking = null
		,@PartyID_SameFirstLastName_SameTracking = null
		,@PartyID_GenericMatch = null
		,@MatchedPartyID = null
	
	if @Isprovider=0
	begin
			select @PartyID_SameSSN_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Person E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.SSN = @SSN and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')
				


			select @PartyID_SameLicense_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Person E
				on D.PartyID = E.PartyID
			inner join KYP.PDM_License F
				on D.PartyID = F.PartyID
			inner join dbo.ProviderLicense G
				on F.LicenseCode = G.P_LIC_CERT_NUM 
				and F.LicenseState = G.P_ST_CD 
				and G.P_ID = @TrackingNumber		
			where 
				A.Number = @TrackingNumber	and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')


			
				
			select @PartyID_SameNPI_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Person E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.NPI = convert(int, @NPI)	and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')
				


			select @PartyID_SameFirstLastName_SameTracking = D.PartyID
			from KYP.ADM_Case A
			inner join KYP.ADM_Application B
				on A.CaseID = B.CaseID
			inner join KYP.SDM_ApplicationParty C
				on B.ApplicationID = C.ApplicationID
			inner join KYP.PDM_Party D
				on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
			inner join KYP.PDM_Person E
				on D.PartyID = E.PartyID
			where 
				A.Number = @TrackingNumber	
				and E.FirstName = @FirstName
				and E.LastName = @LastName and D.PartyID not in (select PDM_PartyID from KYP.PDM_MasterParty 
				where ProviderNumber=  @TrackingNumber and Type <> 'ProviderParty')
			
	end
	else 
	begin
	
	
			   select @PartyID_SameSSN_SameTracking = D.PartyID
					from KYP.ADM_Case A
					inner join KYP.ADM_Application B
						on A.CaseID = B.CaseID
					inner join KYP.SDM_ApplicationParty C
						on B.ApplicationID = C.ApplicationID
					inner join KYP.PDM_Party D
						on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
					inner join KYP.PDM_Person E
						on D.PartyID = E.PartyID
					where 
						A.Number = @TrackingNumber	
						and E.SSN = @SSN 
						

               
					select @PartyID_SameLicense_SameTracking = D.PartyID
					from KYP.ADM_Case A
					inner join KYP.ADM_Application B
						on A.CaseID = B.CaseID
					inner join KYP.SDM_ApplicationParty C
						on B.ApplicationID = C.ApplicationID
					inner join KYP.PDM_Party D
						on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
					inner join KYP.PDM_Person E
						on D.PartyID = E.PartyID
					inner join KYP.PDM_License F
						on D.PartyID = F.PartyID
					inner join dbo.ProviderLicense G
						on F.LicenseCode = G.P_LIC_CERT_NUM 
						and F.LicenseState = G.P_ST_CD 
						and G.P_ID = @TrackingNumber		
					where 
						A.Number = @TrackingNumber	


					
						
					select @PartyID_SameNPI_SameTracking = D.PartyID
					from KYP.ADM_Case A
					inner join KYP.ADM_Application B
						on A.CaseID = B.CaseID
					inner join KYP.SDM_ApplicationParty C
						on B.ApplicationID = C.ApplicationID
					inner join KYP.PDM_Party D
						on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
					inner join KYP.PDM_Person E
						on D.PartyID = E.PartyID
					where 
						A.Number = @TrackingNumber	
						and E.NPI = convert(int, @NPI)	
						


					select @PartyID_SameFirstLastName_SameTracking = D.PartyID
					from KYP.ADM_Case A
					inner join KYP.ADM_Application B
						on A.CaseID = B.CaseID
					inner join KYP.SDM_ApplicationParty C
						on B.ApplicationID = C.ApplicationID
					inner join KYP.PDM_Party D
						on C.PartyID = D.PartyID and D.CurrentModule = 1 and D.IsDeleted <> 1
					inner join KYP.PDM_Person E
						on D.PartyID = E.PartyID
					where 
						A.Number = @TrackingNumber	
						and E.FirstName = @FirstName
						and E.LastName = @LastName 
					
			
	end
	
	if (@PartyID_SameSSN_SameTracking is null and @PartyID_SameLicense_SameTracking is null and
	   @PartyID_SameNPI_SameTracking is null and @PartyID_SameFirstLastName_SameTracking is null)
	begin   
	 
		select @PartyID_GenericMatch = A.PartyID
		from KYP.PDM_Party A
		inner join KYP.PDM_Person B
			on A.PartyID = B.PartyID 
			and ISNULL(A.IsDeleted,0) = 0 
		where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
			and B.LastName = @LastName
			and B.SSN = @SSN
			and ISNULL(B.NPI, 0) = ISNULL(convert(int, @NPI),0)		
	end
	
	select @MatchedPartyID = coalesce(
								@PartyID_SameSSN_SameTracking
								,@PartyID_SameLicense_SameTracking
								,@PartyID_SameNPI_SameTracking
								,@PartyID_SameFirstLastName_SameTracking
								,@PartyID_GenericMatch
								,-1)
								
	return @MatchedPartyID						
		
		
	END


GO

