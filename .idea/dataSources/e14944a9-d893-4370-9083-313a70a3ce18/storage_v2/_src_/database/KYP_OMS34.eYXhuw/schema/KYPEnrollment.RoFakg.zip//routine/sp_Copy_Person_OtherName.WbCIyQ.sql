
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Person other name.   
-- PARAMETERS: 
-- @acc_person_id : personID to new Account that will be create. 
-- @app_person_id : personID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @person_other_id : this is the perdonOtherID Application that will be Create in Update Account, it is Null when account is create. 
-- @acc_party_id : partyID Account it is null when account create, when account is Update it have value to find PersonId.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Person_OtherName]
@acc_person_id INT,
@app_person_id INT,
@last_action_user_id VARCHAR(100),
@person_other_id INT,
@acc_party_id INT
AS
BEGIN
SET NOCOUNT ON
DECLARE @date_created DATE; 
SET @date_created =  GETDATE();
IF @person_other_id IS NULL
BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Person_OtherName]
			   ([PersonID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleName]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag])
	           
	SELECT	@acc_person_id,
			[FirstName],
			[LastName],
			[MiddleName],
			[CreatedBy],
			@date_created,
			[IsDeleted],
			'C',
			@date_created,
			@last_action_user_id,
			@last_action_user_id,
			1
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] 
	WHERE PersonID = @app_person_id AND IsDeleted=0
END 
ELSE
BEGIN
    DECLARE @personId INT;
    SELECT @personId = PersonID FROM [KYPEnrollment].[pAccount_PDM_Person] WHERE PartyID=@acc_party_id;
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Person_OtherName]
			   ([PersonID]
			   ,[FirstName]
			   ,[LastName]
			   ,[MiddleName]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag])
	           
	SELECT	@personId,
			[FirstName],
			[LastName],
			[MiddleName],
			[CreatedBy],
			@date_created,
			[IsDeleted],
			'C',
			@date_created,
			@last_action_user_id,
			@last_action_user_id,
			1
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] 
	WHERE PesonONID = @person_other_id 
END
END


GO

