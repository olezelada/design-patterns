

-- =============================================
-- Author:		Sundar
-- Create date: 2018-Dec-14
-- Description:	To fetch data to display in AccountHistory for NPI Spreading CAPAVE-3812
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Usp_GetDisclosedData]
	@pApplicationNo varchar(20),
	@pAccountID int
AS
BEGIN
	SET NOCOUNT ON;

	DEclare @UpdateLegalName bit,
			@UpdateBusinessName bit,
			@UpdateMailAddress bit,
			@ApplicationID int,
			@LegaName varchar(200),
			@PartyID int,
			@BusinessName varchar(200),
			@MailAddress varchar(2000),
			@OwnerNo varchar(5),
			@ServiceLocationNo varchar(5),
			@SupUpdateFlag varchar(20)

	Declare @Tab_Name table (AccountID int,
									FieldName varchar(200),
									OldValue varchar(2000),
									NewValue varchar(2000))
			
	Declare @Tab_MailAddress Table(Accountid Int,
									AddressLine1 varchar(250), 
									AddressLine2 varchar(50),
									City varchar(25),
									State varchar(40),
									County  varchar(25),
									Zip varchar(20))		
		
	--Declare @Tab_AccountID_1 Table(AccountID int)	
	
	--Declare @Tab_AccountID_2 Table(AccountID int)		

	Begin Try		
		--Insert into @Tab_AccountID_1(AccountID)
		--select T2.AccountID
		--From kypenrollment.pADM_Account T1
		--Join kypenrollment.pADM_Account T2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo
		--Where T1.AccountID = @pAccountID
		--and T2.IsDeleted=0
		--and T1.AccountID <> T2.AccountID
		
		--Insert into @Tab_AccountID_2(AccountID)
		--select T2.AccountID
		--From kypenrollment.pADM_Account T1
		--Join kypenrollment.pADM_Account T2 on T1.NPI = T2.NPI and T1.OwnerNo=T2.OwnerNo and T1.ServiceLocationNo=T2.ServiceLocationNo
		--Where T1.AccountID = @pAccountID
		--and T2.IsDeleted=0
		--and T1.AccountID <> T2.AccountID	
				
		Select @SupUpdateFlag = SupUpdateFlag
		From kyp.ADM_Case
		Where Number = @pApplicationNo

		Select @OwnerNo = BillingFutureStatus,
				@ServiceLocationNo = ProvCrossReferenceCode
			from kypenrollment.edm_applicationinternaluse where ApplicationNumber=@pApplicationNo;
		
		IF (@OwnerNo is null or @ServiceLocationNo is null)
		Begin
			Select @OwnerNo = BillingFutureStatus,
					@ServiceLocationNo = ProvCrossReferenceCode
				from kypenrollment.edm_Supplementalinternaluse where LastActionComments=@pApplicationNo;	
		End
		
		IF (@OwnerNo is null or @ServiceLocationNo is null) and @SupUpdateFlag = '5A'
		Begin
			Select @OwnerNo = OwnerNo,
					@ServiceLocationNo = ServiceLocationNo
				from kypenrollment.pADM_Account where AccountID=@pAccountID;	
		End		
		
		Select @ApplicationID = ApplicationID,
				@PartyID = PartyID,
				@UpdateLegalName = UpdateLegalName,
				@UpdateBusinessName = UpdateBusinessName,
				@UpdateMailAddress = UpdateMailToAddress
			from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo = @pApplicationNo;
		
		Select @LegaName = ISNULL(LastName+', ','')+ISNULL(FirstName+' ','')+Isnull(LEFT(MiddleName,1)+' ','')+isnull(ProfessionalTitle,Salutation)
		from KYPPORTAL.PortalKYP.pPDM_Person
		Where PartyID = @PartyID
		and @UpdateLegalName=1
		
		Select @LegaName = LegalName
		from KYPPORTAL.PortalKYP.pPDM_Organization
		Where PartyID = @PartyID
		and @UpdateLegalName=1	
		and @LegaName is null
		
		Select @BusinessName = BusinessName
		from KYPPORTAL.PortalKYP.pPDM_Organization
		Where PartyID = @PartyID
		and @UpdateBusinessName=1
		and BusinessName is not null
		
		Select @MailAddress = isnull(T2.AddressLine1,'')+ISNULL(t2.AddressLine2,'')+ISNULL(t2.city,'')+ISNULL(t2.state,'')+ISNULL(t2.ZipPlus4,'')
		From KYPPORTAL.PortalKYP.pPDM_Location t1
		Join KYPPORTAL.PortalKYP.pPDM_Address t2 on t1.AddressID=t2.AddressID
		Where t1.Type = 'Mailing'
		and T1.PartyID=@PartyID
		and @UpdateMailAddress = 1

		--Changed the Select Statement for KEN-20823
		select T2.AccountID,'LegalName' FieldName,@LegaName Value
			From kypenrollment.pADM_Account T1
			Join kypenrollment.pADM_Account T2 on T1.NPI = T2.NPI 
			Where @LegaName is not null
			and T1.AccountID = @pAccountID
			and T2.OwnerNo = @OwnerNo
			and T2.IsDeleted=0
			and T1.AccountID <> T2.AccountID
			and T2.LegalName <> @LegaName
		Union all
		select T2.AccountID,'BusinessName' FieldName,@BusinessName Value
			From kypenrollment.pADM_Account T1
			Join kypenrollment.pADM_Account T2 on T1.NPI = T2.NPI 
			Where @BusinessName is not null
			and T1.AccountID = @pAccountID
			and T2.OwnerNo = @OwnerNo
			and T2.ServiceLocationNo = @ServiceLocationNo
			and T2.IsDeleted=0
			and T1.AccountID <> T2.AccountID
			and T2.BusinessName <> @BusinessName		
		Union All
		select T2.AccountID,'MailToAddress' FieldName,@MailAddress Value
			From kypenrollment.pADM_Account T1
			Join kypenrollment.pADM_Account T2 on T1.NPI = T2.NPI 
			Join kypenrollment.pAccount_PDM_Location T3 on T2.PartyID=T3.PartyID
			Join kypenrollment.pAccount_PDM_Address T4 on T3.AddressID=T4.AddressID
			Where T1.AccountID = @pAccountID
			and T2.OwnerNo = @OwnerNo
			and T2.ServiceLocationNo = @ServiceLocationNo
			and T2.IsDeleted=0
			and T1.AccountID <> T2.AccountID
			and T3.Type = 'Mailing'
			and isnull(t4.AddressLine1,'')+isnull(t4.AddressLine2,'')+isnull(t4.City,'')+isnull(t4.State,'')+isnull(t4.ZipPlus4,'') <> @MailAddress
				
	End Try
	Begin Catch
		 IF @@TRANCOUNT > 0
		 ROLLBACK TRANSACTION 
		  
		 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'ApplicationNumber',@KeyValue = @pApplicationNo; 
		 
	End Catch	
	
END


GO

