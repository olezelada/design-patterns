








CREATE VIEW [KYPEnrollment].[v_NMP_detail]
AS
SELECT row_number() OVER (ORDER BY AccountID ASC) AS ID, *
FROM         
(

select Distinct
RAff.AccountID
,RAff.TypeAffiliation,
 RAff.RenderingAffiliationID
, CONVERT( varchar(10), RAff.AffiliationStartDate, 101)  AS RenAffStDT,
CONVERT( varchar(10), RAff.AffiliationEndDate, 101) AS RenAffEndDT,
A.ProviderTypeCode as ProvTC


-- Field of pAccount_PDM_Number (For Rendring)
,A.NPI AS NMPRendNPI

,LIC.Number AS NMPRendLic,
AR.LegalName,AR.SSN,

D.ProvisionalCode as ProvC,

CASE CONVERT(varchar(10),D.ProvisionalCodeDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),D.ProvisionalCodeDate,101) END 
AS ProvCDate,
AR.ReenrollmentIndicator AS ReEnrollInd,

CASE CONVERT(varchar(10),AR.ReenrollmentDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),AR.ReenrollmentDate,101) END AS ReEnrollDT,
 AR.StatusAcc,
 
 CASE CONVERT(varchar(10),ACS.EffectiveBeginDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),ACS.EffectiveBeginDate,101) END AS StsEffBnDT,

CASE CONVERT(varchar(10),ACS.EffectiveEndDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),ACS.EffectiveEndDate,101) END AS StsEffEdDT,

  
--servicing Address
srADD1,srADD2,srcity,srstate,srZip4,
--Mailing Address
MADD1,MADD2,MCity,MState,MZip4,
Raff.LastActionDate,Raff.LastUpdatedBy

from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
-- This is for NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
left outer join KYPEnrollment.EDM_AccountInternalUse D on  D.AccountID=RAff.AffiliatedAccountID and D.CurrentRecordFlag=1
--License of NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Number LIC on LIC.PartyID=AR.PartyID AND LIC.Type='Professional License' AND LIC.CurrentRecordFlag=1
 left outer join KYPEnrollment.pADM_AccountStatus ACS on Acs.AccountID=AR.AccountID and ACS.CurrentRecordFlag=1
left outer join 
(select SR.AddressLine1 as srADD1,SR.AddressLine2 AS srADD2,SR.City as srcity,SR.State AS srstate ,SR.ZipPlus4 AS srZip4,x.PartyID,SR.County AS srcountry from KYPEnrollment.pAccount_PDM_Address SR
inner join KYPEnrollment.pAccount_PDM_Location X
	 on SR.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)E
	 on E.PartyID = AR.PartyID

--This is for Mailing Address Details
left outer join(select D.AddressLine1 as MADD1,D.AddressLine2 as MADD2,D.City as MCity,D.State as MState,D.ZipPlus4 as MZip4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = AR.PartyID
where  CONVERT(VARCHAR, RAff.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)  and  RAff.AffiliatedAccountID is not null and RAff.TypeAffiliation in ('NMP','NEW_RENDERING_MIDLEVEL_FROM_ACCOUNT','NEW_RENDERING_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_ACCOUNT')
 
and RAff.LastUpdatedBy != 'M'
 

) z
------------------------------------------------------------------- Close of NMP Relationship file ----------------------------------------------------------------------


GO

