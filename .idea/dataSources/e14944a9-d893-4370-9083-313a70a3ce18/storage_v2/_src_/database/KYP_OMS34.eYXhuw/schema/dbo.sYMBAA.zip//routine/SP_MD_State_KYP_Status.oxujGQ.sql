

CREATE PROCEDURE SP_MD_State_KYP_Status as begin

IF OBJECT_ID('dbo.[Stage_MD_State_KYP_Status]', 'U') IS not NULL
drop table Stage_MD_State_KYP_Status

select A.[PROVIDER_MA_NUMBER],left([Provider_Enr_Status1],2) StateEnrolmentStatus,
Case when left(A.[Provider_Enr_Status1],2) is null then '5' --Null means reject status
when left([Provider_Enr_Status1],2) in('36','37','38','39','41','42','43') then '1'
when left([Provider_Enr_Status1],2) in('66','67','68','69','70','72','73') then '2'
when left([Provider_Enr_Status1],2) between 01 and 16 then '3'
when left([Provider_Enr_Status1],2)='71' then '4'
when left([Provider_Enr_Status1],2) between 26 and 29 then '5'
when left([Provider_Enr_Status1],2)in('40','44') then '7'
when left([Provider_Enr_Status1],2) between 51 and 58  then '9' end KYPEnrolmentStatus
into dbo.Stage_MD_State_KYP_Status --table created
from dbo.Stage_MD_PEF_Full A join (
select  distinct [PROVIDER_MA_NUMBER]
from dbo.Stage_MD_PEF_Full A 
where A.[PROVIDER_TYPE] not in('29', '44', '45', '63', '75', '93', '96', '97', '99', 'AT', 
 'MA', 'T2', '02', '52', '98') and
[PROVIDER_MA_NUMBER] in(
select  [PROVIDER_MA_NUMBER]
from dbo.Stage_MD_PEF_Full where [PROVIDER_TYPE]<>'76' and 
(
left([Provider_Enr_Status1],2)  between 36 and 44 
or
(left([Provider_Enr_Status1],2) between 51 and 58)
) and A.Provider_Name not like '%dummy%' and A.Provider_Name is not null and (left(A.Provider_NPI,1) not in('2','4') or A.Provider_NPI is null)
)
union
select  [PROVIDER_MA_NUMBER]
from dbo.Stage_MD_PEF_Full where [PROVIDER_TYPE]='76'
and(
left([Provider_Enr_Status1],2)  between 36 and 44 
or
(left([Provider_Enr_Status1],2) between 51 and 58)
) 
and 
(
isnull(nullif(PROVIDER_SPEC_CODE1,'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE2],'000'),'270') not in('270','284') or 
isnull(nullif([PROVIDER_SPEC_CODE3],'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE4],'000'),'270') not in('270','284') or 
isnull(nullif([PROVIDER_SPEC_CODE5],'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE6],'000'),'270') not in('270','284') or
(
right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE1])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE2])),''),'000'),4),3)='000'
and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE3])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE4])),''),'000'),4),3)='000'
and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE5])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE6])),''),'000'),4),3)='000'
)
)
)B on A.[PROVIDER_MA_NUMBER]=B.[PROVIDER_MA_NUMBER]
where A.Provider_Name not like '%dummy%' and A.Provider_Name is not null 
and (left(A.Provider_NPI,1) not in('2','4') or A.Provider_NPI is null)
 
 
 
 --Insert valid 76 PT type case with Inactive and Other Status
 Insert into dbo.Stage_MD_State_KYP_Status 
select  A.[PROVIDER_MA_NUMBER],left(A.[Provider_Enr_Status1],2),
Case when left(A.[Provider_Enr_Status1],2) is null then '5' --Null means reject status
when left(A.[Provider_Enr_Status1],2) in('36','37','38','39','41','42','43') then '1'
when left(A.[Provider_Enr_Status1],2) in('66','67','68','69','70','72','73') then '2'
when left(A.[Provider_Enr_Status1],2) between 01 and 16 then '3'
when left(A.[Provider_Enr_Status1],2)='71' then '4'
when left(A.[Provider_Enr_Status1],2) between 26 and 29 then '5'
when left(A.[Provider_Enr_Status1],2)in('40','44') then '7'
when left(A.[Provider_Enr_Status1],2) between 51 and 58  then '9' end KYPEnrolmentStatus
from dbo.Stage_MD_PEF_Full A left join dbo.Stage_MD_State_KYP_Status B
on A.[PROVIDER_MA_NUMBER]=B.[PROVIDER_MA_NUMBER] where [PROVIDER_TYPE]='76'
and 
(
isnull(nullif(PROVIDER_SPEC_CODE1,'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE2],'000'),'270') not in('270','284') or 
isnull(nullif([PROVIDER_SPEC_CODE3],'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE4],'000'),'270') not in('270','284') or 
isnull(nullif([PROVIDER_SPEC_CODE5],'000'),'270') not in('270','284') or
isnull(nullif([PROVIDER_SPEC_CODE6],'000'),'270') not in('270','284') or
(
right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE1])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE2])),''),'000'),4),3)='000'
and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE3])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE4])),''),'000'),4),3)='000'
and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE5])),''),'000'),4),3)='000' and right(left(isnull(nullif(ltrim(rtrim([PROVIDER_SPEC_CODE6])),''),'000'),4),3)='000'
)
)
and B.[PROVIDER_MA_NUMBER] is null
and A.Provider_Name not like '%dummy%' and A.Provider_Name is not null 
and (left(A.Provider_NPI,1) not in('2','4') or A.Provider_NPI is null)


--Inactive excluded provider type and PT 76 with only speciality 270/284
Insert into dbo.Stage_MD_State_KYP_Status 
select  A.[PROVIDER_MA_NUMBER],left(A.[Provider_Enr_Status1],2),
'2' KYPEnrolmentStatus
from dbo.Stage_MD_PEF_Full A left join dbo.Stage_MD_State_KYP_Status B
on A.[PROVIDER_MA_NUMBER]=B.[PROVIDER_MA_NUMBER]
where B.[PROVIDER_MA_NUMBER] is null and 
A.[PROVIDER_TYPE] in('29', '44', '45', '63', '75', '93', '96', '97', '99', 'AT', 
 'MA', 'T2', '02', '52', '98','76')
 and A.Provider_Name not like '%dummy%' and A.Provider_Name is not null 
and (left(A.Provider_NPI,1) not in('2','4') or A.Provider_NPI is null)
 

---Rest all enrollment status wise mapping
Insert into dbo.Stage_MD_State_KYP_Status 
select  A.[PROVIDER_MA_NUMBER],left(A.[Provider_Enr_Status1],2),
Case when left(A.[Provider_Enr_Status1],2) is null then '5' --Null means reject status
when left(A.[Provider_Enr_Status1],2) in('36','37','38','39','41','42','43') then '1'
when left(A.[Provider_Enr_Status1],2) in('66','67','68','69','70','72','73') then '2'
when left(A.[Provider_Enr_Status1],2) between 01 and 16 then '3'
when left(A.[Provider_Enr_Status1],2)='71' then '4'
when left(A.[Provider_Enr_Status1],2) between 26 and 29 then '5'
when left(A.[Provider_Enr_Status1],2)in('40','44') then '7'
when left(A.[Provider_Enr_Status1],2) between 51 and 58  then '9' end KYPEnrolmentStatus
from dbo.Stage_MD_PEF_Full A left join dbo.Stage_MD_State_KYP_Status B
on A.[PROVIDER_MA_NUMBER]=B.[PROVIDER_MA_NUMBER]
where B.[PROVIDER_MA_NUMBER] is null
and A.Provider_Name not like '%dummy%' and A.Provider_Name is not null 
and (left(A.Provider_NPI,1) not in('2','4') or A.Provider_NPI is null)

End


GO

