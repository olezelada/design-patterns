


CREATE FUNCTION [dbo].[CaseIndicator](@MILESTONE varchar(100),@StatusCodeNumber INT,@CurrentMinorDisposition varchar(100),@Status varchar(25),@SupUpdateFlag varchar(25),@EnrollmentType varchar(50),@PracticeType varchar(50),@IsMoratoria BIT,@RevertStatus varchar(30))
RETURNS varchar(30)
AS
   BEGIN
   
   DECLARE @CaseIndicator varchar(30),
			@numOfIndicator int;
	SET @numOfIndicator =0;
	
	 if(@CurrentMinorDisposition='Revert' AND @MILESTONE='Reverted') 
	begin
		SET @CaseIndicator = 'Revert';
	end
    
    if(@PracticeType='ConsultReverted') 
	begin
		SET @numOfIndicator = @numOfIndicator + 1;
		SET @CaseIndicator = 'ConsultReverted';
	end
	
	if(@PracticeType='EscalateReverted') 
	begin
		SET @numOfIndicator = @numOfIndicator + 1;
		SET @CaseIndicator = 'EscalateReverted';
	end
    
    if(@StatusCodeNumber=9) 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'P';
			
	end
	
	if((@MILESTONE='Return to provider'))
	begin
			SET @numOfIndicator =@numOfIndicator + 1;
			SET @CaseIndicator = 'RTP';
	end
	
	if((@MILESTONE='Re-Submitted' OR @MILESTONE='Resubmitted Application Review'))
	begin
			SET @numOfIndicator =@numOfIndicator + 1;
			SET @CaseIndicator = 'Re-Submitted';
	end
	
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	--if(@CurrentMinorDisposition='Consult' AND @RevertStatus='Moratoria Exempt') 
	if((@CurrentMinorDisposition='Consult' and (@IsMoratoria = 0 OR @IsMoratoria is null)) OR (@IsMoratoria = 1 AND @RevertStatus='Moratoria Exempt' AND @CurrentMinorDisposition='Consult'))
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Consult';
	end
	
	/*CurrentMinorDisposition is Pending Account Update check for other values are there */
	if(@CurrentMinorDisposition='Pending Account Update') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Pending Account Update';
	end
	/*CurrentMinorDisposition is Pending Account Creation check for other values are there */
	if(@CurrentMinorDisposition='Pending Account Creation') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Pending Account Creation';
	end
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	--if(@CurrentMinorDisposition='Escalate' AND @RevertStatus='Moratoria Exempt') 
	if((@CurrentMinorDisposition='Escalate' and (@IsMoratoria = 0 OR @IsMoratoria is null)) OR (@IsMoratoria = 1 AND @RevertStatus='Moratoria Exempt' AND @CurrentMinorDisposition='Escalate'))
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Escalate';
	end
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	if(@CurrentMinorDisposition='Suspended') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Suspended';
	end
	
	/*CurrentMinorDisposition is Return check for other values are there */
	if(@CurrentMinorDisposition='Returned' OR @EnrollmentType='Returned') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Returned';
	end
	
	/*CurrentMinorDisposition is Reassigned check for other values are there */
	
	if(@CurrentMinorDisposition='Reassigned' AND @MILESTONE ='Reverted') 
	begin
		
		SET @CaseIndicator = 'M';
		
	end
	
	/* Status is decline check for other values are there */
	--if(@Status='Decline' AND @RevertStatus='Moratoria Exempt') 
	if((@Status='Decline' and (@IsMoratoria = 0 OR @IsMoratoria is null)) OR (@IsMoratoria = 1 AND @RevertStatus='Moratoria Exempt' AND @Status='Decline'))
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicator = 'Decline';
	end
	
	if(@numOfIndicator > 1) 
	begin
		SET @CaseIndicator = 'M';
	end
	
	--Added this If block for Ken-13338 By Subhash on 16 Feb 2018
	if(@IsMoratoria=1 AND (@RevertStatus<>'Moratoria Exempt' OR @RevertStatus is null)) 
	begin
		SET @CaseIndicator = 'MO';
	end
	
	if(@Status='Withdrawal' AND @StatusCodeNumber=9) 
	begin
		
		SET @CaseIndicator = 'M';
	end
	
	if(@Status='Withdrawal' AND @StatusCodeNumber<>9) 
	begin
		
		SET @CaseIndicator = 'W';
	end
	
	
	
	
	
RETURN(@CaseIndicator)
END


GO

