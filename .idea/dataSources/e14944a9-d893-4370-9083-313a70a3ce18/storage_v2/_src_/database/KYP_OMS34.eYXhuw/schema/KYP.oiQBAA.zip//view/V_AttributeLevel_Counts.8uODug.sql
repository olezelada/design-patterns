CREATE VIEW [KYP].[V_AttributeLevel_Counts] as
 select row_number() OVER (ORDER BY T1.CaseID ASC,T1.CategoryID,T1.Partyid) AS ID ,T1.CaseID,T1.PartyID,T1.CategoryID,T2.CategoryName,T2.HeaderName,T2.ModuleName,COUNT(t1.CommentID) CategoryCount
from kyp.ADM_Comments T1
Join  kyp.ADM_Comment_Category T2 on T1.CategoryID = T2.CategoryID
where T1.IsActive = 1
and T2.IsActive = 1
Group by T1.CaseID,T1.PartyID,T1.CategoryID,T2.CategoryName,T2.HeaderName,T2.ModuleName


GO

