
/* ==========================================================
-- Author:		<Lacunza,Sanabria, Giresse>
-- PROCEDURE: copy Party with a parameter for type.
-- PARAMETERS: 
-- @party_Id : partyID Applicacion that will be Account. 
-- @parent_party_Id : this is PartyID Account that will be create, it can be null, is null when create the firts party to Account.
-- @account_id : AccountID that will be create, it is null when create the firts party to Account.
-- @last_action_user_id : this is the user Enrollment.
-- @type: this is the type of the new party
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Type] 	
	@party_Id INT,
	@parent_party_Id INT,
	@account_id INT,
	@last_action_user_id VARCHAR(100),
	@type varchar(50)
	
AS
BEGIN
SET NOCOUNT ON 
	DECLARE 
		@new_Party_Id INT,
		@date_Create DATE
		
		SET @date_Create = GETDATE()
  IF @account_id IS NULL
  BEGIN		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
		([Type] ,
		[Name] ,
		[IsProvider] ,
		[IsEnrolled] ,
		[IsTemp] ,
		[IsActive] ,
		[LoadType] ,
		[LoadID] ,
		[LastLoadDate] ,
		[DateModified] ,
		[CurrentRecordFlag] ,
		[Source] ,
		[LastAction] ,
		[LastActionDate] ,
		[profile_id],
		[IsDeleted],
		[LastActorUserID],
		[LastActionApprovedBy])
		SELECT @type
		,[Name]
		,[IsProvider]
		,[IsEnrolled]
		,[IsTemp]
		,[IsActive]
		,[LoadType]
		,[LoadID]
		,[LastLoadDate]
		,[DateModified]
		,1
		,[Source]
		,'C'
		,@date_Create
		,[profile_id]
		,0
		,@last_action_user_id
		,@last_action_user_id
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID = @party_Id AND IsDeleted = 0
		SELECT @new_Party_Id = SCOPE_IDENTITY()
 END
 ELSE
 BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
		([Type] ,
		[Name] ,
		[IsProvider] ,
		[IsEnrolled] ,
		[IsTemp] ,
		[IsActive] ,
		[LoadType] ,
		[LoadID] ,
		[LastLoadDate] ,
		[IsDeleted],
		[DateModified] ,
		[CurrentRecordFlag] ,
		[Source] ,
		[LastAction] ,
		[LastActionDate] ,
		[profile_id],
		[ParentPartyID],
		[AccountID],
		[LastActorUserID],
		[LastActionApprovedBy])
		SELECT @type
		,[Name]
		,[IsProvider]
		,[IsEnrolled]
		,[IsTemp]
		,[IsActive]
		,[LoadType]
		,[LoadID]
		,[LastLoadDate]
		,[IsDeleted]
		,[DateModified]
		,1
		,[Source]
		,'C'
		,@date_Create
		,[profile_id]
		,@parent_party_Id
		,@account_id
		,@last_action_user_id
		,@last_action_user_id
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID = @party_Id AND IsDeleted = 0
		SELECT @new_Party_Id = SCOPE_IDENTITY()
	
 END
  PRINT 'New Account Party is : ' + CONVERT(VARCHAR(10), @new_Party_Id);
  RETURN @new_Party_Id
END


GO

