
/* =============================================*/
/* Author:		<Author,,JZapata>*/
/* =============================================*/
CREATE PROCEDURE [KYPEnrollment].[p_Affecting_Portal2]
	@applicationNo VARCHAR(50),
	@resolutionStatus varchar(100)
AS
BEGIN
	DECLARE @dateCreated date
    
	SET @dateCreated = GETDATE()	
    --Due to the application is being closed (WFStatus = Completed) 
    --then we will disable the app to be reviewed in application review
	UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application] SET [IsReviewStatus] = 0, [CaseIndicator] = 'Closed' WHERE [ApplicationNo] = @applicationNo;

    
	IF @resolutionStatus='Approved'
	BEGIN	
		/* actualiza los valores en el portal*/
		SET XACT_ABORT ON
		BEGIN DISTRIBUTED TRANSACTION			
			UPDATE [KYPPORTAL].[PortalKYP].[pADM_Case] SET [Status] = 'Approved' WHERE [Number] = @applicationNo;
			/*INSERT INTO [KYPPORTAL].[PortalKYP].[pApplicationHistoryTracking] ([ApplicationNumber],[ApplicationMilestone],[DateTracking],[UserTrackingName],[IsDeleted],[DateCreated],[DateModified],[DateDeleted],[CreatedBy],[ModifiedBy],[DeletedBy])
			VALUES (@applicationNo,'Approved',@dateCreated,'Medi-Cal Reviewer',0,@dateCreated,null,null,0,0,0)*/
		COMMIT TRANSACTION
		SET XACT_ABORT OFF			
	END
	ELSE
	BEGIN
		IF @resolutionStatus='Deficiency Notice Sent'
		BEGIN		
			SET XACT_ABORT ON
			BEGIN DISTRIBUTED TRANSACTION		
				UPDATE [KYPPORTAL].[PortalKYP].[pADM_Case] SET [Status] = 'Return to Provider', Submitted='false' WHERE [Number] = @applicationNo;
				UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application] SET [IsRTP] = 'true' WHERE [ApplicationNo] = @applicationNo;
				/*INSERT INTO [KYPPORTAL].[PortalKYP].[pApplicationHistoryTracking] ([ApplicationNumber],[ApplicationMilestone],[DateTracking],[UserTrackingName],[IsDeleted],[DateCreated],[DateModified],[DateDeleted],[CreatedBy],[ModifiedBy],[DeletedBy])
				VALUES (@applicationNo,'Return to Provider',@dateCreated,'Medi-Cal Reviewer',0,@dateCreated,null,null,0,0,0)*/
			COMMIT TRANSACTION
			SET XACT_ABORT OFF	
		END
		ELSE
		BEGIN
			IF @resolutionStatus='Denied'
			BEGIN
				SET XACT_ABORT ON
				BEGIN DISTRIBUTED TRANSACTION
					UPDATE [KYPPORTAL].[PortalKYP].[pADM_Case] SET [Status] = 'Denied' WHERE [Number] = @applicationNo;
					/*INSERT INTO [KYPPORTAL].[PortalKYP].[pApplicationHistoryTracking] ([ApplicationNumber],[ApplicationMilestone],[DateTracking],[UserTrackingName],[IsDeleted],[DateCreated],[DateModified],[DateDeleted],[CreatedBy],[ModifiedBy],[DeletedBy])
					VALUES (@applicationNo,'Denied',@dateCreated,'Medi-Cal Reviewer',0,@dateCreated,null,null,0,0,0)*/
				COMMIT TRANSACTION
				SET XACT_ABORT OFF	
			END

		END
	END
END


GO

