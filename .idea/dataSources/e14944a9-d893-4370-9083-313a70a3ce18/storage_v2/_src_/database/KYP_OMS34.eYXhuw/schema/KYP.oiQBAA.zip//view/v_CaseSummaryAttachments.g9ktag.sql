


CREATE VIEW [KYP].[v_CaseSummaryAttachments] AS
Select CONVERT(VARCHAR,C.CaseID) AS CaseID,
		A.Number As Doucment,A.DMSID,
		A.Title AS DocumentName,
		COALESCE(Author,'') + COALESCE(('/'+CONVERT(VARCHAR,Created,101) + ' ' + RIGHT(CONVERT(CHAR(20), Created, 22), 11)),'') AS AddedBy_On	
 from KYP.OIS_Attachment A INNER JOIN KYP.AttachmentEntity E ON A.AttachmentID = E.AttachmentID
 INNER JOIN KYP.ADM_Case C ON C.CaseID = E.AttachmentEntityTypeID
 WHERE  (A.deleted = 'false' OR A.deleted IS NULL) AND E.AttachmentEntityType = 'ADM_Case' AND E.Temp IS NULL


GO

