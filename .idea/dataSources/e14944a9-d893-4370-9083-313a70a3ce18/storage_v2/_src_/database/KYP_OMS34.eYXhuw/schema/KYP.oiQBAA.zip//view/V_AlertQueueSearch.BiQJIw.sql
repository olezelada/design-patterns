

CREATE VIEW [KYP].[V_AlertQueueSearch]
AS
SELECT     TOP (100) PERCENT row_number() OVER (ORDER BY AlertID ASC) AS ID, *
FROM         (SELECT DISTINCT 
                                              A.AlertID, A.AlertNo, A.WatchlistName, A.DateInitiated, A.MatchPercent, A.NoOfMergedAlerts, A.AssignedToUserID, A.IsMerged, A.WFStatus AS 'CurrentWFStatus',
                                              A.StatusCodeNumber, A.WatchedPartyName, EProvParty.Name AS [ProviderName], D .Mon_MedicaidID AS [MedicaidID], W.NPI, W.SSN AS [SSN], 
                                              W.TaxID AS TaxID
                       FROM          KYP.MDM_Alert A LEFT OUTER JOIN
                                              KYP.MDM_PartyDetail W ON A.WatchedPartyID = W.PartyID INNER JOIN
                                              KYP.PDM_Party B ON A.WatchedPartyID = B.PartyID INNER JOIN
                                              KYP.PDM_Owner C ON B.PartyID = C.PartyID INNER JOIN
                                              KYP.PDM_Provider D ON C.ProviderID = D .ProvID INNER JOIN
                                              KYP.PDM_Party EProvParty ON EProvParty.PartyId = D .PartyID LEFT JOIN
                                              KYP.PDM_Person F ON B.PartyID = F.PartyID LEFT JOIN
                                              KYP.PDM_Organization G ON B.PartyID = G.PartyID
                                              
                       UNION
                       SELECT DISTINCT 
                                             A.AlertID, A.AlertNo, A.WatchlistName, A.DateInitiated, A.MatchPercent, A.NoOfMergedAlerts, A.AssignedToUserID, A.IsMerged, A.WFStatus AS 'CurrentWFStatus',
                                             A.StatusCodeNumber, A.WatchedPartyName, EProvParty.Name AS [ProviderName], D .Mon_MedicaidID AS [MedicaidID], W.NPI, W.SSN[SSN], 
                                             W.TaxID AS TaxID
                       FROM         KYP.MDM_Alert A LEFT OUTER JOIN
                                             KYP.MDM_PartyDetail W ON A.WatchedPartyID = W.PartyID INNER JOIN
                                             KYP.PDM_Party B ON A.WatchedPartyID = B.PartyID INNER JOIN
                                             KYP.PDM_Employee C ON B.PartyID = C.PartyID INNER JOIN
                                             KYP.PDM_Provider D ON C.ProviderID = D .ProvID INNER JOIN
                                             KYP.PDM_Party EProvParty ON EProvParty.PartyId = D .PartyID LEFT JOIN
                                             KYP.PDM_Person F ON B.PartyID = F.PartyID LEFT JOIN
                                             KYP.PDM_Organization G ON B.PartyID = G.PartyID
                                            
                       UNION
                       SELECT DISTINCT 
                                             A.AlertID, A.AlertNo, A.WatchlistName, A.DateInitiated, A.MatchPercent, A.NoOfMergedAlerts, A.AssignedToUserID, A.IsMerged, A.WFStatus AS 'CurrentWFStatus',
                                             A.StatusCodeNumber, A.WatchedPartyName, B.Name AS [ProviderName], C.Mon_MedicaidID AS [MedicaidID], W.NPI, W.SSN[SSN],
                                             W.TaxID AS TaxID
                       FROM         KYP.MDM_Alert A LEFT OUTER JOIN
                                             KYP.MDM_PartyDetail W ON A.WatchedPartyID = W.PartyID INNER JOIN
                                             KYP.PDM_Party B ON A.WatchedPartyID = B.PartyID INNER JOIN
                                             KYP.PDM_Provider C ON B.PartyID = C.PartyID LEFT JOIN
                                             KYP.PDM_Person D ON B.PartyID = D .PartyID LEFT JOIN
                                             KYP.PDM_Organization E ON B.PartyID = E.PartyID
                                             ) AllProvidersEmpOwners
                                             

ORDER BY AlertID


GO

