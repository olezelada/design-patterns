
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Modules Account.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Modules_Account]
	@application_no VARCHAR(15),
	@account_number VARCHAR(20),
	@last_action_user_id VARCHAR(100)
AS

BEGIN

print 'in [sp_Update_Modules_Account]'
DECLARE @application_id INT,@party_app_id INT,@application_type VARCHAR(50)
SELECT @application_id = ApplicationID,@party_app_id=PartyID,@application_type = ApplicationType FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationNo = @application_no;

	DECLARE @acc_party_id INT,
			@npi_Type VARCHAR(25),
			@account_id INT,
			@npi VARCHAR(10),
			@legal_name_id INT,
			@address_id INT,
			@provider_type_code VARCHAR(5),
	        @service_location_no VARCHAR(3)
			
   SELECT @acc_party_id = PartyID, @account_id = AccountID, @npi_Type = NPIType, @npi=NPI, @provider_type_code = ProviderTypeCode, @service_location_no = ServiceLocationNo FROM [KYPEnrollment].[pADM_Account] WHERE AccountNumber = @account_number;
   BEGIN TRANSACTION 
   BEGIN TRY
	
	IF(@npi_Type='Individual')

	BEGIN
		print 'in if@npi_TypeIndividual'
		SELECT @legal_name_id = PersonID FROM [KYPEnrollment].[pAccount_PDM_Person] WHERE PartyID=@acc_party_id
	END
	ELSE
	BEGIN
		print 'in else @npi_TypeIndividual'
		SELECT @legal_name_id=OrgID FROM [KYPEnrollment].[pAccount_PDM_Organization] WHERE PartyID=@acc_party_id;
	END
	SELECT @address_id = AddressID FROM KYPEnrollment.pAccount_PDM_Location WHERE PartyID=@acc_party_id AND Type='Servicing';
	
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account]@acc_party_id, @account_id, @npi_Type, @last_action_user_id,1;
	EXEC [KYPEnrollment].[sp_Update_Unique_Party_Moca] @acc_party_id,@last_action_user_id;
	EXEC [KYPEnrollment].[sp_Legal_Name_Address]@account_id,@legal_name_id,@address_id,@npi_Type,@last_action_user_id,@npi,@acc_party_id,@party_app_id,1,@provider_type_code,@account_number,@service_location_no,'',@application_id,0,@application_type;
	COMMIT TRANSACTION
	END TRY
	BEGIN CATCH
	  IF @@TRANCOUNT > 0
	  ROLLBACK TRANSACTION 
	  DECLARE @error_message NVARCHAR (4000), @error_severity INT;
	  SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY();
	  RAISERROR (@error_message, @error_severity, 1);
	END CATCH	
END


GO

