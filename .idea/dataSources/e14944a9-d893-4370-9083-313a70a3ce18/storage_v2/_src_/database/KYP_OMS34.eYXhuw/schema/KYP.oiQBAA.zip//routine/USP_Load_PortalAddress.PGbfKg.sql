
-- =============================================
-- Author:		Sundar
-- Create date: 18-Jun-2019
-- Description:	To Populate Address Info to KypEnrollment.PortalAddress table for Elastic Search implementation on Quick Search
-- =============================================
CREATE PROCEDURE [KYP].[USP_Load_PortalAddress] 
	@p_ApplicationNumber varchar(15) = 0  
AS  
BEGIN  
	SET NOCOUNT ON;  

	Declare @EnrollCaseID int;  

	Select @EnrollCaseID = CaseID From Kyp.ADM_Case Where Number = @p_ApplicationNumber  

	Delete from Kypenrollment.PortalAddress Where EnrollCaseID = @EnrollCaseID;  

	Insert Into Kypenrollment.PortalAddress(EnrollCaseID, PortalCaseID, PortalAppID, PortalPartyID, Type, AddressLine1, AddressLine2, County, City, ZipPlus4, State, IsDeleted)  
	Select @EnrollCaseID, B.CaseID, B.ApplicationID, B.PartyID, A.Type, A.AddressLine1, A.AddressLine2, A.County, A.City, A.ZipPlus4, A.statecode, 0  
	From KYP.View_AllAddresses A  
	Join KYPPORTAL.PortalKYP.pADM_Application B on A.ApplicationNo = B.ApplicationNo  
	Where A.ApplicationNo = @p_ApplicationNumber;  

END


GO

