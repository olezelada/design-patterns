-- =============================================
-- Authors:   <Lokesh vishwakarma>
-- Script Date: 05/09/2018
-- =============================================
CREATE TRIGGER [KYP].[ResolveFindings] ON [KYP].[ois_note]
	WITH EXECUTE AS CALLER
FOR
UPDATE AS
BEGIN
	DECLARE @CaseID int
		,@Count int = 0;

	DECLARE @Row_Updation_Source VARCHAR(100)

	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF isnull(@Row_Updation_Source,'') in ( 'KYP.p_InsertOISNote') AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END

	SELECT @CaseID = CaseID
	FROM inserted

	Select @Count = CNotes from KYPEnrollment.view_ResolvedFindings where CaseID= @CaseID
	
	if (@Count=0)
	Begin
		update kyp.adm_case set isrequiresupdate=0 where caseid=@CaseID;
		
		update kypenrollment.padm_account 
		set UpdateRequired=0,
			Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
		where applicationNumber = (select Number from kyp.adm_case where caseid=@CaseID)
    End
END
GO

