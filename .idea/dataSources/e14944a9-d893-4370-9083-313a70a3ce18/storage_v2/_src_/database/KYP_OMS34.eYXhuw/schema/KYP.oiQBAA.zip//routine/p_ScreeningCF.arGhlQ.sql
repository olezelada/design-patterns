




CREATE PROCedure [KYP].[p_ScreeningCF]
(
	@InfoID INT,
	@Number VARCHAR(10)
)
as begin 

	
DECLARE @CaseID VARCHAR(25),
		@AppNo VARCHAR(25),
		@PartyID VARCHAR(25),
		@MultipleValue VARCHAR(800),
		@matchValue INT,
		@strNoteDepth VARCHAR (200),
		@RelatedEntityID VARCHAR(100),
		@RelatedEntityType VARCHAR(200),
		@webPartyID VARCHAR(10),
		@currentScreen VARCHAR(20),
		@Username VARCHAR(20),
		@NoteID VARCHAR(10),
		@NotesTitle VARCHAR(20),
		@Type VARCHAR(50),
		@SubType VARCHAR(20),
		@CurrentDate VARCHAR(20),
		@Name VARCHAR(20),
		@NotesDescription VARCHAR(20),
		@AlertID VARCHAR(20),
		@DMSID VARCHAR(200),
		@fileName VARCHAR(100),
		@findingScreen VARCHAR(50),
		@AttachTo VARCHAR(200),
		@AttachToDep VARCHAR(200),
		@absolutePath VARCHAR(100),
		@category VARCHAR(100),
		@AttachmentEntityType VARCHAR(100),
		@AttachmentEntityTypeID INT,
		@AttachmentEntityDep VARCHAR(100),
		@AttachmentEntityDepID INT,
		@IsLastLevel INT,
		@Level VARCHAR(100),
		@Notenumber VARCHAR(15),
		@AttachmentID INT,
		@NoteEntityType VARCHAR(20) ,
		@NoteEntityTypeID VARCHAR(20) ,
		@NoteEntityDepID VARCHAR(20) ,
		@AttachmentNumber VARCHAR(20) ,
		@MultipleCaseID varchar(500),
		@NoteEntityDep VARCHAR(20),
		@PCaseID VARCHAR(25),
        @PAppID VARCHAR(25),
        @FullName varchar(150),
        @PSubFormID VARCHAR(25);
		

SELECT @CurrentDate = getdate();
SELECT @CaseID=(SELECT CaseID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @AppNo= (SELECT ApplicationID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @PartyID =(SELECT RelatedEntityID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @webPartyID = @PartyID;
SELECT @currentScreen = (SELECT SmartletParameter FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @Username = (SELECT UserName FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @FullName = (SELECT FullName FROM KYP.OIS_User where UserID =@Username);
SELECT @Type = (SELECT Type FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @SubType = (SELECT SubType FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
SELECT @DMSID = (SELECT RelatedEntityType FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
print @dmsid
SELECT @MultipleValue = (SELECT MultipleTrackingNo FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
Select @MultipleCaseID= (SELECT MultipleCaseID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);

IF ISNULL(@Username,'') = ''
BEGIN
	SET @FullName = 'System'
END

 /********when is Application Review*************/
IF(@currentScreen = 'Application Review')
  BEGIN
		SELECT @PCaseID   =(SELECT PCaseID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
        SELECT @PAppID    =(SELECT PAppID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
        SELECT @PSubFormID=(SELECT PSubFormID FROM KYP.MDM_JournalBasicInfo WHERE InfoID = @InfoID);
END 

CREATE TABLE #tblFindings(	
	isRedFlagClicked VARCHAR(50),
	findingsScreen VARCHAR(50),
	AttachTo VARCHAR(200),
	AttachToDep VARCHAR(300),
	fileName VARCHAR(100),
	absolutePath VARCHAR(100),
	category VARCHAR(100)	
);

insert into #tblFindings 
SELECT * FROM(
Select 'TIN'+CAST(Id as VARCHAR(10)) AS TIN ,Data from [dbo].[Split](@MultipleValue,';') WHERE LTRIM(RTRIM(ISNULL(Data,''))) != '' 
)X PIVOT(max(Data) for TIN IN (TIN1,TIN2,TIN3,TIN4,TIN5,TIN6,TIN7))P

SELECT @fileName = (SELECT fileName from #tblFindings)
SELECT @findingScreen = (SELECT findingsScreen from #tblFindings)
SELECT @AttachTo = (SELECT AttachTo from #tblFindings)
SELECT @AttachToDep = (SELECT AttachToDep from #tblFindings)
SELECT @absolutePath = (SELECT absolutePath from #tblFindings)
SELECT @category = (SELECT category from #tblFindings)


IF(@currentScreen = 'Application List')
	BEGIN
 		SET @RelatedEntityType = 'ADM_Case';
		SET @RelatedEntityID = @CaseID;
		set @strNoteDepth = 'ADM_Case-'+@CaseID;
	END
	
IF(@currentScreen = 'DB Check')
  BEGIN
		SET @RelatedEntityType = 'SDM_ApplicationParty';
		SET @RelatedEntityID = @PartyID;
		set @strNoteDepth = 'ADM_Case-'+@CaseID+'|ADM_Application-'+@AppNo+'|SDM_ApplicationParty-'+@PartyID;	
  END 

IF(@currentScreen = 'Web Research')
  BEGIN
		SET @RelatedEntityType = 'ADM_App_Provider';
		SET @RelatedEntityID = @webPartyID;
		set @strNoteDepth = 'ADM_Case-'+@CaseID+'|ADM_App_Provider-'+@PartyID;	
  END 
/********when is Application Review*************/
IF(@currentScreen = 'Application Review')
  BEGIN
		SET @RelatedEntityType = 'SDM_ApplicationParty';
		SET @RelatedEntityID = @PartyID;
        set @strNoteDepth = 'ADM_Case-'+@CaseID+'|ADM_Application-'+@AppNo+'|pADM_Case-'+@PCaseID+'|pADM_Application-'+@PAppID+'|PSubFormID-'+@PSubFormID;
  END


exec @NoteID = [KYP].[p_InsertOISNote]	
 @UserID=@Username,@Name='TempNoteForDocFW',@Type=@Type,@SubType=@SubType,
 @ParentID=0, @DateCreated = @CurrentDate, @Author=@FullName,@RelatedEntityType =@RelatedEntityType,
 @Content= 'TempNoteForDocFW', @UnformattedContent='TempNoteForDocFW' , @Number=@Notenumber , 
 @VersionNo =1, @isWorkpaper=0, @isAcknowledged=0 , @WorkflowName=NULL, @isAdverse=0,
 @Deleted=0, @DeletedOn=NULL, @DeletedBy=NULL , @DeletedByUserID=NULL , @UpdatedOn=NULL,
 @UpdatedBy =NULL, @UpdatedByUserID=NULL , @IsImportant=0 , @IsLastVersion=1 , @IsSticky=0 ,
 @IsReferenced=0 , @HasComments=0 , @HasDocuments=0 , @NumberSchemaInfo=@Number , @LastVersion =1,
 @AllowComments =0, @RestoredBy=NULL , @RestoredByUserID=NULL , @CaseID=@CaseID , @AlertID =@AlertID,
 @IncidentID =NULL, @Tags =NULL, @FullDateCreated=NULL , @RelatedEntityID=@RelatedEntityID , @Importance='Low',
 @Score =0, @DMSID =@DMSID, @DocumentCount=NULL,@MultipleCaseID=null,@MultipleTrackingNo=null, @PInID = @InfoID /*App Review added @PInID*/

  exec [KYP].[p_GenerateNoteNumber] @NoteID,
    @Notenumber=@Notenumber output
    
        /******* Updating note number in OIS_Note***********/ 
    update KYP.OIS_Note set Number= @Notenumber where NoteID= @NoteID
    
 SELECT 
    @NoteEntityType =NoteEntityType,
    @NoteEntityTypeID =NoteEntityTypeID,
    @NoteEntityDepID =NoteEntityDepID,
    @NoteEntityDep= NoteEntityDep,
    @Level =Level,
    @IsLastLevel=IsLastLevel
    from  simple_intlist_to_tbl(@strNoteDepth)       
     
     
     /********Insert into Noteentity*************/
     INSERT INTO [KYP].[NoteEntity]
           ([NoteNumber]
           ,[NoteEntityType]
           ,[NoteEntityDep]
           ,[NoteEntityTypeID]
           ,[NoteEntityDepID]
           ,[Level]
           ,[IsLastLevel])
    
           SELECT @Notenumber
           ,NoteEntityType
           ,NoteEntityDep
           ,NoteEntityTypeID
           ,NoteEntityDepID
           ,Level
           ,IsLastLevel from  simple_intlist_to_tbl(@strNoteDepth)  

 exec [KYP].[p_GenerateAttachmentNumber] 
    @NoteNumber=@Attachmentnumber output

INSERT INTO KYP.OIS_Attachment
	(Number,DMSID,FileName,Status,Type,Title,FileType,SubType,Author,FolderPath,Created,Version,Entity,PrimaryKey,IconType,TotalViews,IsFolder,AbsolutePath,Category,deleted)
	 VALUES
	(@AttachmentNumber,@DMSID,@fileName,'Draft','Findings',@fileName,NULL,@findingScreen,'System',@absolutePath,GETDATE(),1,@AttachTo,NULL,'pdf',0,0,@absolutePath,@category,0)
 
SELECT @AttachmentID = IDENT_CURRENT('[KYP].[OIS_Attachment]')
IF(@AttachTo = 'Reference Library') 
 BEGIN
	SELECT @AttachmentEntityType = 'Reference Library';
	SELECT @AttachmentEntityTypeID = 0;
	SELECT @AttachmentEntityDep = 'Reference Library';
	SELECT @AttachmentEntityDepID = 0;
	SELECT @IsLastLevel = 1;
	SELECT @Level = 0;
		
	INSERT INTO KYP.AttachmentEntity 
		(AttachmentEntityDep,AttachmentEntityDepID,AttachmentEntityType,AttachmentEntityTypeID,IsLastLevel,Level,AttachmentID)
		 VALUES
		(@AttachmentEntityDep,@AttachmentEntityDepID,@AttachmentEntityType,@AttachmentEntityTypeID,@IsLastLevel,@Level,@AttachmentID)
 END
ELSE
 BEGIN
		
		IF(@currentScreen = 'Application List')
		BEGIN
 			 INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_Case',@CaseID,'ADM_Case',@CaseID,0,0);
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'OIS_Note',@NoteID,'ADM_Case',@CaseID,1,1);			
		END
	
	
		IF(@currentScreen = 'DB Check')
	    BEGIN
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_Case',@CaseID,'ADM_Case',@CaseID,0,0);	
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_Application',@AppNo,'ADM_Case',@CaseID,1,0);
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'SDM_ApplicationParty',@PartyID,'ADM_Application',@AppNo,2,0);
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'OIS_Note',@NoteID,'SDM_ApplicationParty',@PartyID,3,1);									
		END 

		IF(@currentScreen = 'Web Research')
		BEGIN
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_Case',@CaseID,'ADM_Case',@CaseID,0,0);	
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_App_Provider',@PartyID,'ADM_Case',@CaseID,1,0);	
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'OIS_Note',@NoteID,'ADM_App_Provider',@webPartyID,2,0);							
	    END
		
		IF(@currentScreen = 'Application Review')
		BEGIN
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'ADM_Case',@CaseID,'ADM_Case',@CaseID,0,0);	
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'pADM_Case',@PCaseID,'ADM_Case',@CaseID,1,0);	
			INSERT INTO KYP.AttachmentEntity 
					(AttachmentID,AttachmentEntityType,AttachmentEntityTypeID,AttachmentEntityDep,AttachmentEntityDepID,Level,IsLastLevel)
					 VALUES
					(@AttachmentID,'OIS_Note',@NoteID,'pADM_Case',@PCaseID,2,1);							
	    END	
			
 END
 
drop table #tblFindings


end


GO

