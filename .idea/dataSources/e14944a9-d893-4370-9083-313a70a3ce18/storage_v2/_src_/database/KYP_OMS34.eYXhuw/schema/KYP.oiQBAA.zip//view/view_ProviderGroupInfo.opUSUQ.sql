


CREATE VIEW [KYP].[view_ProviderGroupInfo]
AS
SELECT KYP.PDM_GroupProvider.ID
	,KYP.PDM_GroupProvider.Group_ProviderNO AS GroupProviderNo
	,KYP.ADM_Case.Number AS ProviderNo
	,KYP.ADM_Case.PAN AS ApplicationNo
	,KYP.ADM_Case.ProviderName AS Name
	,KYP.ADM_Case.WFMinorStep AS Status
	,KYP.ADM_Application.NormalizedRisk AS RiskScore
	,KYP.ADM_Case.ApplnType AS Type
	,KYP.ADM_Case.DateReceived
	,KYP.PDM_GroupProvider.Type AS ProviderType
	,KYP.ADM_Case.Provider_NPI AS NPI
	,KYP.ADM_Case.DateCreated AS DateCreated
	,KYP.ADM_Case.CurrentlyAssignedToName As AssignedToName
	,KYP.ADM_Case.Status As WFStatus 
FROM KYP.ADM_Application
INNER JOIN KYP.ADM_Case ON KYP.ADM_Application.CaseID = KYP.ADM_Case.CaseID
INNER JOIN KYP.PDM_GroupProvider ON KYP.ADM_Case.Number = KYP.PDM_GroupProvider.Member_ProviderNO


GO

