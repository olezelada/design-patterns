

-- =============================================
-- Author:		Vinoth
-- Create date: 12/2/2013
-- Description:	For related Owners and Employees count population
-- =============================================
CREATE TRIGGER [KYP].[trg_OwnerEmployeeCountPopulation] 
   ON [KYP].[MDM_Alert]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    --**
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF (isnull( @Row_Updation_Source,'') in ( 'KYP.MDM_Alert','p_UpdateAlertage' ) AND Update(Row_Updation_Source)) or not exists (select * from inserted)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	--**
	SET NOCOUNT ON;			
    -- Insert statements for trigger here
	DECLARE @ownersCount INT,
			@employesCount INT,
			@alertID INT,
			@watchedPartyID INT,
			@isMerged VARCHAR(2);
	
	SET @alertID = (SELECT Top 1 AlertID FROM inserted);
	SET @watchedPartyID = (SELECT Top 1 WatchedPartyID FROM inserted);
	SET @isMerged = (SELECT Top 1 IsMerged FROM inserted);
	
	EXEC calOwnersEmployeesCount @alertID, @watchedPartyID;
	EXEC calImpactedProviderCount @alertID, @isMerged;
END


GO

