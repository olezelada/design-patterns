-- =============================================
-- Author:		<jvera>
-- Create date: <01/24/2018>
-- Description:	<This procedure update Incontinence Tables>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_IncontinenceTable]
@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1),
@account_id INT,
 @acc_table_name VARCHAR(200)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @app_address_id INT;
	DECLARE @party_incontinence_id INT;
	 DECLARE @party_adr           INT;
	DECLARE @new_party_adr       INT;
	DECLARE @org_id	int;

	IF @action_taken='Added'
	  BEGIN
	  
	  SELECT @party_incontinence_id = PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] WHERE TargetPath=@target_path;
	  --IF (SELECT COUNT(FiledID) FROM [KYPEnrollment].[Control_Add_row] WHERE FiledID=@app_address_id AND NameTable='pAccount_PDM_Address')= 0
	  IF not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@party_incontinence_id AND NameTable='pAccount_PDM_Party')

	  BEGIN
	  PRINT @action_taken 
	  
	  
	  EXEC @new_party_adr = [KYPEnrollment].[sp_Copy_Party] @party_incontinence_id,
															  @acc_party_id,
															  @account_id,
															  @last_action_user_id;
					  EXEC @org_id = [KYPEnrollment].[sp_Copy_Organization] @new_party_adr,
																	@party_incontinence_id,
																	@last_action_user_id;
					  EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
															 @party_incontinence_id,
															 NULL,
															 @last_action_user_id;   
	                                                         
	  
	   INSERT INTO #Control_Add_row(FiledID,NameTable)
	   VALUES(@party_incontinence_id,'pAccount_PDM_Party'); 
	  END 
	END
	  
	
	IF @action_taken='Deleted' AND @target_path LIKE '%'+@acc_table_name+'%'
	  BEGIN
			PRINT 'DELETED FROM SECTION INCONTINENCE :'
			PRINT @acc_table_name;
	  
			DECLARE @update NVARCHAR(MAX)
			DECLARE @ParamDefinition AS NVARCHAR(2000),@accPKvalue VARCHAR(100)
			SET @ParamDefinition = '@accPKvalue INT'

			SET @accPKvalue = CONVERT(VARCHAR(100), @acc_PK_value);
			SET @update = 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + ' = ' + '@accPKvalue'

			
			EXEC sp_executesql @update
							  ,@ParamDefinition
							  ,@accPKvalue
  
	END
END


GO

