

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Organization_Ein]
  @party_id_provider INT,
  @account_party_id INT
AS
BEGIN

	DECLARE @data_ein VARCHAR(100)
	DECLARE @orgId INT
	DECLARE @remark VARCHAR(200) = 'BusinessProfile'

	SELECT @data_ein = EIN FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization]  where PartyID=@party_id_provider AND Remarks=@remark         
	SELECT @orgId = OrgID FROM KYPEnrollment.pAccount_PDM_Organization WHERE PartyID=@account_party_id AND Remarks=@remark
                        
    IF (@orgId IS NOT NULL AND @data_ein IS NOT NULL)
	BEGIN
	  UPDATE KYPEnrollment.pAccount_PDM_Organization set EIN = @data_ein WHERE OrgID=@orgId
	END

END


GO

