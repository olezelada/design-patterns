





CREATE PROCEDURE [dbo].[LoadCAProvidersEnrollment] 
AS	
BEGIN
begin try
begin tran ProcessProvider

CREATE TABLE [dbo].[tmp_ProviderNameAddress](
	[FileType] [varchar](1) NULL,
	LoadType [varchar](20) NULL,
	LoadId  [varchar](50) NULL	,
	LastLoadDate datetime null,
	[P_APPL_NUM] [varchar](20) NULL,
	[P_ID] [varchar](20) NOT NULL,
	[P_NPI_NUM] [varchar](10) NULL,
	[P_DEA_NUM] [varchar](11) NULL,
	[P_TY_CD] [varchar](3) NULL,
	[P_PRACT_TY_CD] [varchar](1) NULL,
	[P_DOB_DT] [varchar](10) NULL,
	[P_FED_TAX_ID] [varchar](9) NULL,
	[P_SSN_NUM] [varchar](9) NULL,
	[P_LAST_NAM] [varchar](35) NULL,
	[P_FST_NAM] [varchar](35) NULL,
	[P_MI_NAM] [varchar](1) NULL,
	[P_SFX_NAM] [varchar](10) NULL,
	[P_NAM] [varchar](50) NULL,
	[P_DBA_LAST_NAM] [varchar](35) NULL,
	[P_DBA_FST_NAM] [varchar](35) NULL,
	[P_DBA_MI_NAM] [varchar](1) NULL,
	[P_DBA_SFX_NAM] [varchar](10) NULL,
	[P_DBA_NAM] [varchar](50) NULL,
	[P_LINE1_AD] [varchar](50) NULL,
	[P_LINE2_AD] [varchar](50) NULL,
	[P_CITY_NAM] [varchar](20) NULL,
	[P_ST_CD] [varchar](2) NULL,
	[P_ZIP5_CD] [varchar](5) NULL,
	[P_ZIP4_CD] [varchar](4) NULL,
	[P_NABP_NUM] [varchar](11) NULL,
	[DH_NAME_OF_FAC_ADMIN] [varchar](50) NULL,
	[P_LINE1_AD2] [varchar](50) NULL,
	[P_LINE2_AD2] [varchar](50) NULL,
	[P_CITY_NAM2] [varchar](20) NULL,
	[P_ST_CD2] [varchar](2) NULL,
	[P_ZIP5_CD2] [varchar](5) NULL,
	[P_ZIP4_CD2] [varchar](4) NULL,
	[P_LINE1_AD3] [varchar](50) NULL,
	[P_LINE2_AD3] [varchar](50) NULL,
	[P_CITY_NAM3] [varchar](20) NULL,
	[P_ST_CD3] [varchar](2) NULL,
	[P_ZIP5_CD3] [varchar](5) NULL,
	[P_ZIP4_CD3] [varchar](4) NULL,
	[DH_ENROL_STAT_CD_1] [varchar](1) NULL,
	[DH_OWNER_NUM] [varchar](2) NULL,
	[DH_SERV_LOC_NUM] [varchar](3) NULL,
	[DH_PROV_TELE_NO] [varchar](11) NULL,
	[ProviderType] [varchar](20) NULL,
    CLIA varchar(15) NULL,  
    PrimarySpeciality varchar(50) NULL,
    FullName varchar(50) NULL,
    DBAFullName varchar(50)NULL,
    PartyId int  NULL,
    ProvId int NULL,
    FileSource varchar(50) null,
    STAT_EFF_DT smalldatetime null,
    NMP_END_DT smalldatetime null
    ,[RE_ENROMENT_IN] [varchar](1) NULL
	,[RE_ENR_EFF_DATE] [varchar](10) NULL
	,[PROVIS_ENROLL_IND] [varchar](2) NULL
	,[PROVIS_ENROLL_EFFEC_DT] [varchar](10) NULL
	,[LAST_ACTVT_DT] [varchar](10) NULL
	,[NMP_USER_ID] [varchar](8) NULL
	,[DH_PROV_LOC_TYPE] [varchar](1) NULL
	,[DH_PROV_CNTY] [varchar](2) NULL
	,[DH_OUT_OF_STATE_IND] [varchar](1) NULL
	,[DH_IMD_FACIL_TYPE] [varchar](1) NULL
	,[DH_TYP_OF_PRAC_ORG] [varchar](2) NULL
	,[DH_APP_DT] [varchar](10) NULL
	,[DH_REJECT_REASON] [varchar](2) NULL
	,[DH_EXCEPTION_IND] [varchar](1) NULL
	,[DH_DT_PROV_ADDED] [varchar](10) NULL
	,[DH_LAST_ACTY_DT] [varchar](10) NULL
	,[DH_LAST_ACTY_TIME] [varchar](7) NULL
	,[DH_PIN] [varchar](7) NULL
	,[DH_TIN_UPDATE_TYPE] [varchar](1) NULL
	,[DH_TIN_UPDATE_DATE] [varchar](10) NULL
	,[DH_OWNER_EFFEC_BEG_DT] [varchar](10) NULL
	,[DH_OWNER_EFFEC_END_DT] [varchar](10) NULL
	,[PM_EFT_IND][varchar](01) NULL
	,[PM_CHDP_PROV_NUMBER][varchar](10) NULL
    )
insert into [dbo].[tmp_ProviderNameAddress]
([FileType],LoadType,LoadId ,LastLoadDate,[P_APPL_NUM],[P_ID],[P_NPI_NUM],[P_DEA_NUM] ,
	[P_TY_CD],[P_PRACT_TY_CD],[P_DOB_DT],[P_FED_TAX_ID],[P_SSN_NUM],[P_LAST_NAM],[P_FST_NAM] ,
	[P_MI_NAM],[P_SFX_NAM],[P_NAM],[P_DBA_LAST_NAM],[P_DBA_FST_NAM],[P_DBA_MI_NAM],[P_DBA_SFX_NAM] ,
	[P_DBA_NAM],[P_LINE1_AD],[P_LINE2_AD],[P_CITY_NAM],[P_ST_CD],[P_ZIP5_CD],[P_ZIP4_CD],[P_NABP_NUM] ,
	[DH_NAME_OF_FAC_ADMIN],[P_LINE1_AD2],[P_LINE2_AD2],[P_CITY_NAM2],[P_ST_CD2],[P_ZIP5_CD2],[P_ZIP4_CD2] ,
	[P_LINE1_AD3],[P_LINE2_AD3],[P_CITY_NAM3],[P_ST_CD3],[P_ZIP5_CD3],[P_ZIP4_CD3],[DH_ENROL_STAT_CD_1] ,
	[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DH_PROV_TELE_NO],[ProviderType],FileSource,STAT_EFF_DT,NMP_END_DT
	,[RE_ENROMENT_IN] 
			,[RE_ENR_EFF_DATE]  
			,[PROVIS_ENROLL_IND] 
			,[PROVIS_ENROLL_EFFEC_DT]  
			,[LAST_ACTVT_DT]  
			,[NMP_USER_ID] 
			,[DH_PROV_LOC_TYPE] 
			,[DH_PROV_CNTY] 
			,[DH_OUT_OF_STATE_IND] 
			,[DH_IMD_FACIL_TYPE] 
			,[DH_TYP_OF_PRAC_ORG] 
			,[DH_APP_DT]  
			,[DH_REJECT_REASON] 
			,[DH_EXCEPTION_IND] 
			,[DH_DT_PROV_ADDED]  
			,[DH_LAST_ACTY_DT]  
			,[DH_LAST_ACTY_TIME] 
			,[DH_PIN] 
			,[DH_TIN_UPDATE_TYPE] 
			,[DH_TIN_UPDATE_DATE]  
			,[DH_OWNER_EFFEC_BEG_DT]  
			,[DH_OWNER_EFFEC_END_DT]
			,[PM_EFT_IND]
			,[PM_CHDP_PROV_NUMBER]
	)
	
	SELECT[FileType]
		,LoadType = case 
						when [FileType] = 'M' then 'MonthlyProvider'
						when [FileType] = 'D' then 'DailyEnroller'
					  end	
		,LoadId  = case 
						when [FileType] = 'M' then 'MLOAD_' + CONVERT(varchar(10),getdate(), 112)
						when [FileType] = 'D' then 'DLOAD_' + CONVERT(varchar(10),getdate(), 112)
					  end	
		,LastLoadDate = GETDATE()
		
      ,[P_APPL_NUM]
      ,[P_ID] 
      ,[P_NPI_NUM]
      ,[P_DEA_NUM]
      ,[P_TY_CD]
      ,[P_PRACT_TY_CD]
      ,[P_DOB_DT]
      ,[P_FED_TAX_ID]
      ,[P_SSN_NUM]
      ,[P_LAST_NAM]
      ,[P_FST_NAM]
      ,[P_MI_NAM]
      ,[P_SFX_NAM]
      ,[P_NAM]
      ,[P_DBA_LAST_NAM]
      ,[P_DBA_FST_NAM]
      ,[P_DBA_MI_NAM]
      ,[P_DBA_SFX_NAM]
      ,[P_DBA_NAM]
      ,[P_LINE1_AD]
      ,[P_LINE2_AD]
      ,[P_CITY_NAM]
      ,[P_ST_CD]
      ,[P_ZIP5_CD]
      ,[P_ZIP4_CD]
      ,[P_NABP_NUM]
      ,[DH_NAME_OF_FAC_ADMIN]
      ,[P_LINE1_AD2]
      ,[P_LINE2_AD2]
      ,[P_CITY_NAM2]
      ,[P_ST_CD2]
      ,[P_ZIP5_CD2]
      ,[P_ZIP4_CD2]
      ,[P_LINE1_AD3]
      ,[P_LINE2_AD3]
      ,[P_CITY_NAM3]
      ,[P_ST_CD3]
      ,[P_ZIP5_CD3]
      ,[P_ZIP4_CD3]
      ,[DH_ENROL_STAT_CD_1] 
      ,[DH_OWNER_NUM]
      ,[DH_SERV_LOC_NUM]
      ,[DH_PROV_TELE_NO]
      ,[ProviderType]
      ,[FileSource]
      ,STAT_EFF_DT
      ,NMP_END_DT
      ,[RE_ENROMENT_IN] 
	,[RE_ENR_EFF_DATE]  
	,[PROVIS_ENROLL_IND] 
	,[PROVIS_ENROLL_EFFEC_DT]  
	,[LAST_ACTVT_DT]  
	,[NMP_USER_ID] 
	,[DH_PROV_LOC_TYPE] 
	,[DH_PROV_CNTY] 
	,[DH_OUT_OF_STATE_IND] 
	,[DH_IMD_FACIL_TYPE] 
	,[DH_TYP_OF_PRAC_ORG] 
	,[DH_APP_DT]  
	,[DH_REJECT_REASON] 
	,[DH_EXCEPTION_IND] 
	,[DH_DT_PROV_ADDED]  
	,[DH_LAST_ACTY_DT]  
	,[DH_LAST_ACTY_TIME] 
	,[DH_PIN] 
	,[DH_TIN_UPDATE_TYPE] 
	,[DH_TIN_UPDATE_DATE]  
	,[DH_OWNER_EFFEC_BEG_DT]  
	,[DH_OWNER_EFFEC_END_DT]
	,[PM_EFT_IND]
	,[PM_CHDP_PROV_NUMBER]
FROM [dbo].[ProviderNameAddress]


 --------------------------------------------------------
 --------------------------------------------------------
 --------------------------------------------------------
 update [tmp_ProviderNameAddress] set P_ST_CD3='CA' Where P_ST_CD3 IN ('VI','0V','UD','17','')
 
 update [tmp_ProviderNameAddress] 
 set p_ssn_num = null 
where p_ssn_num =''

update [tmp_ProviderNameAddress] 
 set p_npi_num = null 
where p_npi_num =''

update [tmp_ProviderNameAddress] 
 set p_fed_tax_id = null 
where p_fed_tax_id =''

update [tmp_ProviderNameAddress] 
 set p_dba_nam = null 
where p_dba_nam =''

update [tmp_ProviderNameAddress] 
 set p_nam = null 
where p_nam =''

update [tmp_ProviderNameAddress] 
 set p_last_nam = null 
where p_last_nam =''

update [tmp_ProviderNameAddress] 
 set p_fst_nam = null 
where p_fst_nam =''

update [tmp_ProviderNameAddress] 
 set P_MI_NAM = null 
where P_MI_NAM =''

Update [tmp_ProviderNameAddress] set P_LINE1_AD=null where P_LINE1_AD =''

Update [tmp_ProviderNameAddress] set P_LINE2_AD=null where P_LINE2_AD =''

Update [tmp_ProviderNameAddress] set P_LINE1_AD=null where P_LINE1_AD like '000%'

Update [tmp_ProviderNameAddress] set P_LINE2_AD=null where P_LINE2_AD like '000%'

Update [tmp_ProviderNameAddress] set P_FED_TAX_ID=null where P_FED_TAX_ID like '000%'

Update [tmp_ProviderNameAddress] set P_NAM=null where P_NAM like '000%'

Update [tmp_ProviderNameAddress] set P_DBA_NAM=null where P_DBA_NAM like '000%'

update tmp_ProviderNameAddress set P_MI_NAM=null where P_MI_NAM=''''

UPDATE tmp_ProviderNameAddress SET [DH_PROV_TELE_NO]=NULL WHERE [DH_PROV_TELE_NO]=''

UPDATE tmp_ProviderNameAddress SET P_FED_TAX_ID=NULL WHERE P_FED_TAX_ID=''

UPDATE tmp_ProviderNameAddress SET P_FED_TAX_ID=NULL WHERE P_FED_TAX_ID like '000%'

update [tmp_ProviderNameAddress] 
 set 
 P_LAST_NAM = case when P_LAST_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(P_LAST_NAM,', ',' '),',',' '))))) end
,P_FST_NAM=case when P_FST_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_FST_NAM))end
,P_MI_NAM = CASE WHEN P_MI_NAM IS NOT NULL AND P_MI_NAM <> ''THEN KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_MI_NAM))END
,P_DBA_LAST_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_LAST_NAM,', ',' '),',',' ')))
,P_DBA_FST_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_FST_NAM,', ',' '),',',' ')))
,P_DBA_MI_NAM=rtrim(ltrim(Replace(REPLACE(P_DBA_MI_NAM,', ',' '),',',' ')))
,P_LINE1_AD= case when P_LINE1_AD is not null and P_LINE1_AD<>'' then KYP.RemoveUnwantedCharacters(P_LINE1_AD)end
,P_LINE2_AD=case when P_LINE2_AD is not null and P_LINE2_AD<>'' then KYP.RemoveUnwantedCharacters(P_LINE2_AD)end
,P_LINE1_AD2= case when P_LINE1_AD2 is not null and P_LINE1_AD2<>'' then KYP.RemoveUnwantedCharacters(P_LINE1_AD2)end
,P_LINE2_AD2=case when P_LINE2_AD2 is not null and P_LINE2_AD2<>''then KYP.RemoveUnwantedCharacters(P_LINE2_AD2)end
,P_LINE1_AD3= case when P_LINE1_AD3 is not null and  P_LINE1_AD3<>''then KYP.RemoveUnwantedCharacters(P_LINE1_AD3)end
,P_LINE2_AD3=case when P_LINE2_AD3 is not null and P_LINE2_AD3<>'' then KYP.RemoveUnwantedCharacters(P_LINE2_AD3)end
,P_NAM=case when P_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_NAM))end
,P_DBA_NAM=case when P_DBA_NAM is not null  then KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(P_DBA_NAM))end

update [tmp_ProviderNameAddress] 
 set P_NAM = COALESCE(P_NAM, P_DBA_NAM)
where ProviderType='Organizaton'

update [tmp_ProviderNameAddress] 
 set P_LAST_NAM = COALESCE(P_LAST_NAM, P_DBA_LAST_NAM)
,P_FST_NAM = COALESCE(P_FST_NAM, P_DBA_FST_NAM)
 where ProviderType='Individual'
 
update [tmp_ProviderNameAddress] 
 set FullName = case when P_LAST_NAM IS NULL
			then COALESCE(P_LAST_NAM,'') +  COALESCE(P_FST_NAM, '') +  COALESCE((' ' + P_MI_NAM), '')
			else COALESCE(P_LAST_NAM,'') +  COALESCE((', ' + P_FST_NAM), '') +  COALESCE((' ' + P_MI_NAM), '')
			end
 where ProviderType='Individual'
 
update [tmp_ProviderNameAddress] 
 set DBAFullName = case when P_DBA_LAST_NAM IS NULL
			then COALESCE(P_DBA_LAST_NAM,'') +  COALESCE(P_DBA_FST_NAM, '') +  COALESCE((' ' + P_DBA_MI_NAM), '')
			else COALESCE(P_DBA_LAST_NAM,'') +  COALESCE((', ' + P_DBA_FST_NAM), '') +  COALESCE((' ' + P_DBA_MI_NAM), '')
			end
 where ProviderType='Individual'
 
update [tmp_ProviderNameAddress] 
 set FullName = COALESCE(FullName, DBAFullName)
where ProviderType='Individual'

----------------getting primary speciality
update y
set y.PrimarySpeciality= x.LongDescription
from [tmp_ProviderNameAddress] y
  inner join    
(select x.P_ID,x.LongDescription,x.row from(
select 
	x.P_ID,y.LongDescription, ROW_NUMBER()over(partition by x.P_ID order by x.id) as row
	FROM dbo.ProviderSpeciality x 
	inner join [KYP].[PDM_SpecialityCode] y
	on x.P_SPECL_CD=y.Value where x.P_SPECL_CD is not null and x.P_SPECL_CD<>'')x where x.row=1)x
on x.P_ID= y.p_id

---------------update pdm party for Individual records if already exists--
----------------------------------------------------------------------------------
update x
set x.ProvId = y.ProvID
,x.PartyId= y.PartyID
 from [tmp_ProviderNameAddress] x
 inner join [KYPEnrollment].[pAccount_PDM_Provider] y
 on x.p_id= y.ProvNumber
 where x.ProvId is null and x.PartyId is null

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT1=null
where isdate(DH_LAB_S_EFF_DT1)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT1 = null where cast(DH_LAB_S_EFF_DT1 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT1 = null where cast(DH_LAB_S_EFF_DT1 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT2=null
where isdate(DH_LAB_S_EFF_DT2)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT2 = null where cast(DH_LAB_S_EFF_DT2 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT2 = null where cast(DH_LAB_S_EFF_DT2 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT3=null
where isdate(DH_LAB_S_EFF_DT3)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT3 = null where cast(DH_LAB_S_EFF_DT3 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT3 = null where cast(DH_LAB_S_EFF_DT3 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT4=null
where isdate(DH_LAB_S_EFF_DT4)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT4 = null where cast(DH_LAB_S_EFF_DT4 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT4 = null where cast(DH_LAB_S_EFF_DT4 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT5=null
where isdate(DH_LAB_S_EFF_DT5)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT5 = null where cast(DH_LAB_S_EFF_DT5 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LAB_S_EFF_DT5 = null where cast(DH_LAB_S_EFF_DT5 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LB_S_DT=null
where isdate(DH_LB_S_DT)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LB_S_DT = null where cast(DH_LB_S_DT as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LB_S_DT = null where cast(DH_LB_S_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Speciality_Details] set DH_LB_E_DT=null
where isdate(DH_LB_E_DT)=0
update [Stage_CA_Lab_Speciality_Details] set DH_LB_E_DT = null where cast(DH_LB_E_DT as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Speciality_Details] set DH_LB_E_DT = null where cast(DH_LB_E_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Spec_Details] set DH_LAB_S_EFF_DT_1290=null
where isdate(DH_LAB_S_EFF_DT_1290)=0
update [Stage_CA_Lab_Spec_Details] set DH_LAB_S_EFF_DT_1290 = null where cast(DH_LAB_S_EFF_DT_1290 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Spec_Details] set DH_LAB_S_EFF_DT_1290 = null where cast(DH_LAB_S_EFF_DT_1290 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Spec_Details] set DH_LB_E_DT_1279=null
where isdate(DH_LB_E_DT_1279)=0
update [Stage_CA_Lab_Spec_Details] set DH_LB_E_DT_1279 = null where cast(DH_LB_E_DT_1279 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Spec_Details] set DH_LB_E_DT_1279 = null where cast(DH_LB_E_DT_1279 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Spec_Details] set DH_LB_S_DT_1278=null
where isdate(DH_LB_S_DT_1278)=0
update [Stage_CA_Lab_Spec_Details] set DH_LB_S_DT_1278 = null where cast(DH_LB_S_DT_1278 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Spec_Details] set DH_LB_S_DT_1278 = null where cast(DH_LB_S_DT_1278 as DATE)<'1900-01-01 00:00:00'

update [dbo].[Stage_CA_Lab_Type] set DH_LAB_S_EFF_DT_1290=null
where isdate(DH_LAB_S_EFF_DT_1290)=0
update [Stage_CA_Lab_Type] set DH_LAB_S_EFF_DT_1290 = null where cast(DH_LAB_S_EFF_DT_1290 as DATE)>'2079-06-06 23:59:00'
update [Stage_CA_Lab_Type] set DH_LAB_S_EFF_DT_1290 = null where cast(DH_LAB_S_EFF_DT_1290 as DATE)<'1900-01-01 00:00:00'
  
update [dbo].[ProviderSpeciality] set DH_SPE_CERT_DT=null
where isdate(DH_SPE_CERT_DT)=0
update [ProviderSpeciality] set DH_SPE_CERT_DT = null where cast(DH_SPE_CERT_DT as DATE)>'2079-06-06 23:59:00'
update [ProviderSpeciality] set DH_SPE_CERT_DT = null where cast(DH_SPE_CERT_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[tmp_ProviderNameAddress] set STAT_EFF_DT=null
where isdate(STAT_EFF_DT)=0 
update [tmp_ProviderNameAddress] set STAT_EFF_DT = null where cast(STAT_EFF_DT as DATE)>'2079-06-06 23:59:00'
update [tmp_ProviderNameAddress] set STAT_EFF_DT = null where cast(STAT_EFF_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[tmp_ProviderNameAddress] set NMP_END_DT=null
where isdate(NMP_END_DT)=0 
update [tmp_ProviderNameAddress] set NMP_END_DT = null where cast(NMP_END_DT as DATE)>'2079-06-06 23:59:00'
update [tmp_ProviderNameAddress] set NMP_END_DT = null where cast(NMP_END_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[tmp_ProviderNameAddress] set PROVIS_ENROLL_EFFEC_DT=null
where isdate(PROVIS_ENROLL_EFFEC_DT)=0 
update [tmp_ProviderNameAddress] set PROVIS_ENROLL_EFFEC_DT = null where cast(PROVIS_ENROLL_EFFEC_DT as DATE)>'2079-06-06 23:59:00'
update [tmp_ProviderNameAddress] set PROVIS_ENROLL_EFFEC_DT = null where cast(PROVIS_ENROLL_EFFEC_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].[tmp_ProviderNameAddress] set DH_DT_PROV_ADDED=null
where isdate(DH_DT_PROV_ADDED)=0  
update [tmp_ProviderNameAddress] set DH_DT_PROV_ADDED = null where cast(DH_DT_PROV_ADDED as DATE)>'2079-06-06 23:59:00'
update [tmp_ProviderNameAddress] set DH_DT_PROV_ADDED = null where cast(DH_DT_PROV_ADDED as DATE)<'1900-01-01 00:00:00'

update [dbo].[tmp_ProviderNameAddress] set RE_ENR_EFF_DATE=null
where isdate(RE_ENR_EFF_DATE)=0   
update [tmp_ProviderNameAddress] set RE_ENR_EFF_DATE = null where cast(RE_ENR_EFF_DATE as DATE)>'2079-06-06 23:59:00'
update [tmp_ProviderNameAddress] set RE_ENR_EFF_DATE = null where cast(RE_ENR_EFF_DATE as DATE)<'1900-01-01 00:00:00'


update [dbo].providerenrollstatdata set dh_STAT_EFF_DT5=null
where isdate(dh_STAT_EFF_DT5)=0  
update providerenrollstatdata set dh_STAT_EFF_DT5 = null where cast(dh_STAT_EFF_DT5 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_EFF_DT5 = null where cast(dh_STAT_EFF_DT5 as DATE)<'1900-01-01 00:00:00'


update [dbo].providerenrollstatdata set dh_STAT_EFF_DT4=null
where isdate(dh_STAT_EFF_DT4)=0 
update providerenrollstatdata set dh_STAT_EFF_DT4 = null where cast(dh_STAT_EFF_DT4 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_EFF_DT4 = null where cast(dh_STAT_EFF_DT4 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_END_DT4=null
where isdate(dh_STAT_END_DT4)=0  
update providerenrollstatdata set dh_STAT_END_DT4 = null where cast(dh_STAT_END_DT4 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_END_DT4 = null where cast(dh_STAT_END_DT4 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_EFF_DT3=null
where  isdate(dh_STAT_EFF_DT3)=0 
update providerenrollstatdata set dh_STAT_EFF_DT3 = null where cast(dh_STAT_EFF_DT3 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_EFF_DT3 = null where cast(dh_STAT_EFF_DT3 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_END_DT3=null
where  isdate(dh_STAT_END_DT3)=0 
update providerenrollstatdata set dh_STAT_END_DT3 = null where cast(dh_STAT_END_DT3 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_END_DT3 = null where cast(dh_STAT_END_DT3 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_EFF_DT2=null
where isdate(dh_STAT_EFF_DT2)=0 
update providerenrollstatdata set dh_STAT_EFF_DT2 = null where cast(dh_STAT_EFF_DT2 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_EFF_DT2 = null where cast(dh_STAT_EFF_DT2 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_END_DT2=null
where isdate(dh_STAT_END_DT2)=0 
update providerenrollstatdata set dh_STAT_END_DT2 = null where cast(dh_STAT_END_DT2 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_END_DT2 = null where cast(dh_STAT_END_DT2 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_EFF_DT1=null
where isdate(dh_STAT_EFF_DT1)=0  
update providerenrollstatdata set dh_STAT_EFF_DT1 = null where cast(dh_STAT_EFF_DT1 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_EFF_DT1 = null where cast(dh_STAT_EFF_DT1 as DATE)<'1900-01-01 00:00:00'

update [dbo].providerenrollstatdata set dh_STAT_END_DT1=null
where isdate(dh_STAT_END_DT1)=0  
update providerenrollstatdata set dh_STAT_END_DT1 = null where cast(dh_STAT_END_DT1 as DATE)>'2079-06-06 23:59:00'
update providerenrollstatdata set dh_STAT_END_DT1 = null where cast(dh_STAT_END_DT1 as DATE)<'1900-01-01 00:00:00'

update providerenrollstatdata set DH_ENROL_STAT_CD5 = null where DH_ENROL_STAT_CD5 in('0','')
update providerenrollstatdata set dh_STAT_EFF_DT5 = null where dh_STAT_EFF_DT5 =''
update providerenrollstatdata set dh_STAT_END_DT5 = null where dh_STAT_END_DT5 =''

update providerenrollstatdata set DH_ENROL_STAT_CD4 = null where DH_ENROL_STAT_CD4 in('0','')
update providerenrollstatdata set dh_STAT_EFF_DT4 = null where dh_STAT_EFF_DT4 =''
update providerenrollstatdata set dh_STAT_END_DT4 = null where dh_STAT_END_DT4 =''

update providerenrollstatdata set DH_ENROL_STAT_CD3 = null where DH_ENROL_STAT_CD3 in('0','')
update providerenrollstatdata set dh_STAT_EFF_DT3 = null where dh_STAT_EFF_DT3 =''
update providerenrollstatdata set dh_STAT_END_DT3 = null where dh_STAT_END_DT3 =''

update providerenrollstatdata set DH_ENROL_STAT_CD2 = null where DH_ENROL_STAT_CD2 in('0','')
update providerenrollstatdata set dh_STAT_EFF_DT2 = null where dh_STAT_EFF_DT2 =''
update providerenrollstatdata set dh_STAT_END_DT2 = null where dh_STAT_END_DT2 =''

update providerenrollstatdata set DH_ENROL_STAT_CD1 = null where DH_ENROL_STAT_CD1 in('0','')
update providerenrollstatdata set dh_STAT_EFF_DT1 = null where dh_STAT_EFF_DT1 =''
update providerenrollstatdata set dh_STAT_END_DT1 = null where dh_STAT_END_DT1 =''

update [dbo].ProviderCategoryServices set DH_CATSERV_END_DT=null
where isdate(DH_CATSERV_END_DT)=0 
update ProviderCategoryServices set DH_CATSERV_END_DT = null where cast(DH_CATSERV_END_DT as DATE)>'2079-06-06 23:59:00'
update ProviderCategoryServices set DH_CATSERV_END_DT = null where cast(DH_CATSERV_END_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].ProviderCategoryServices set DH_CATSERV_BEGIN_DT=null
where isdate(DH_CATSERV_BEGIN_DT)=0  
update ProviderCategoryServices set DH_CATSERV_BEGIN_DT = null where cast(DH_CATSERV_BEGIN_DT as DATE)>'2079-06-06 23:59:00'
update ProviderCategoryServices set DH_CATSERV_BEGIN_DT = null where cast(DH_CATSERV_BEGIN_DT as DATE)<'1900-01-01 00:00:00'

update [dbo].Stage_CA_Lab_Spec_Details set DH_LB_S_DT_1278=null
where isdate(DH_LB_S_DT_1278)=0  
update Stage_CA_Lab_Spec_Details set DH_LB_S_DT_1278 = null where cast(DH_LB_S_DT_1278 as DATE)>'2079-06-06 23:59:00'
update Stage_CA_Lab_Spec_Details set DH_LB_S_DT_1278 = null where cast(DH_LB_S_DT_1278 as DATE)<'1900-01-01 00:00:00'

update [dbo].Stage_CA_Lab_Spec_Details set DH_LB_E_DT_1279=null
where isdate(DH_LB_E_DT_1279)=0  
update Stage_CA_Lab_Spec_Details set DH_LB_E_DT_1279 = null where cast(DH_LB_E_DT_1279 as DATE)>'2079-06-06 23:59:00'
update Stage_CA_Lab_Spec_Details set DH_LB_E_DT_1279 = null where cast(DH_LB_E_DT_1279 as DATE)<'1900-01-01 00:00:00'


select * into #Accounts1 from [tmp_ProviderNameAddress]


---------------------------------------------------------------------------------------------
select x.Partyid, x.STAT_EFF_DT,x.NMP_END_DT,x.FileSource, x.[DH_PROV_TELE_NO],x.[P_FED_TAX_ID],x.P_SSN_NUM,x.[P_SFX_NAM],x.[P_LAST_NAM],x.[P_FST_NAM],x.[P_MI_NAM],x.[P_DOB_DT],x.[P_NPI_NUM], x.p_id
   ,x.fullname,x.LoadType,x.LoadID,x.LastLoadDate,'Provider' as [Type],1 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,2 as currentmodule
,x.DH_LAST_ACTY_DT into #tmpIndParties1
from #Accounts1 x
where x.ProviderType='Individual' and x.PartyId is null and x.ProvId is null --366980



---------insert individual party and person for new records-------------

declare @personTemp table (partyid INT , P_SSN_NUM varchar(9), P_SFX_NAM varchar(10), 
P_LAST_NAM varchar(50), P_FST_NAM varchar(50),P_MI_NAM varchar(50), P_DOB_DT datetime, P_NPI_NUM varchar(10), p_id varchar(20), [DH_PROV_TELE_NO] varchar(15), [P_FED_TAX_ID] varchar(10))


MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
select * from #tmpIndParties1
)src ON (trgt.partyid=src.partyid and trgt.isdeleted=0)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag )
 VALUES (src.[Type],src.FullName,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,'C',src.DH_LAST_ACTY_DT,'system','system',1)
output inserted.partyid, src.P_SSN_NUM,src.[P_SFX_NAM],src.[P_LAST_NAM],src.[P_FST_NAM],src.[P_MI_NAM],src.[P_DOB_DT],src.[P_NPI_NUM], src.p_id,src.[DH_PROV_TELE_NO],src.[P_FED_TAX_ID]
 into @personTemp;

INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           (PartyID,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,Phone1,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
select partyid, SUBSTRING(P_SSN_NUM,1,3)+'-'+SUBSTRING(P_SSN_NUM,4,2)+'-'+SUBSTRING(P_SSN_NUM,6,len(P_SSN_NUM)-5)
,P_SFX_NAM,case when len(P_FST_NAM)>25 then SUBSTRING(P_FST_NAM,1,25)else P_FST_NAM end
,P_MI_NAM,case when len(P_LAST_NAM)>25 then SUBSTRING(P_LAST_NAM,1,25)else P_LAST_NAM end
,P_DOB_DT,P_NPI_NUM,GETDATE(),'('+ SUBSTRING([DH_PROV_TELE_NO],1,3)+') '+SUBSTRING([DH_PROV_TELE_NO],4,3)+'-'+SUBSTRING([DH_PROV_TELE_NO],7,len([DH_PROV_TELE_NO])-5),'C',GetDate(),'system','system',1 from @personTemp 

update x
set x.PartyId= y.PartyID
 from #Accounts1 x
 inner join @personTemp y
 on x.p_id= y.p_id
 where x.PartyId is null
 
 
IF OBJECT_ID('tempdb..#tmpIndParties1','U') IS NOT NULL
begin 
drop table #tmpIndParties1
end
------------------------------------------------pdm_party for organization update------------



select x.STAT_EFF_DT,x.NMP_END_DT,x.FileSource,x.[DH_PROV_TELE_NO],x.[P_NAM],x.[P_DBA_NAM],x.[P_FED_TAX_ID],x.[P_NPI_NUM],
x.LoadType,x.LoadID,x.LastLoadDate,x.p_id,'Provider' as [Type],1 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,
0 as isdeleted, GETDATE()as datecreated,2 as currentmodule,x.partyid,x.P_SSN_NUM
,x.DH_LAST_ACTY_DT into #OrgParties
from #Accounts1 x
where x.ProviderType='Organization' and x.partyid is null and x.ProvId is null --263248



 ---insert org party 
 declare @OrgTemp table (partyid INT , P_FED_TAX_ID varchar(10), P_NAM varchar(50), 
P_DBA_NAM varchar(50),P_NPI_NUM varchar(10), p_id varchar(20),[DH_PROV_TELE_NO] varchar(15),P_SSN_Num varchar(10) )

MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(select distinct partyid, [Type],p_nam,IsProvider,IsEnrolled,IsTemp,IsActive,LoadType,LoadID,
LastLoadDate,isdeleted, datecreated,currentmodule,STAT_EFF_DT,NMP_END_DT,FileSource,P_FED_TAX_ID,P_DBA_NAM,[P_NPI_NUM],p_id,[DH_PROV_TELE_NO],P_SSN_NUM,DH_LAST_ACTY_DT from #OrgParties )src 
ON (trgt.partyid=src.partyid  and trgt.isdeleted=0)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated] ,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
 VALUES (src.[Type],src.p_nam,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.datecreated,'C',src.DH_LAST_ACTY_DT,'system','system',1)
output inserted.partyid, src.P_FED_TAX_ID,src.[P_NAM],src.P_DBA_NAM,src.[P_NPI_NUM],src.p_id,src.[DH_PROV_TELE_NO],src.P_SSN_NUM
 into @OrgTemp;
 
INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
   (PartyID,LegalName,DBAName1,TIN,NPI,DateCreated,Phone1,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,EIN)
select partyid, P_NAM,P_DBA_NAM,P_FED_TAX_ID,P_NPI_NUM,GETDATE()
,'('+ SUBSTRING([DH_PROV_TELE_NO],1,3)+') '+SUBSTRING([DH_PROV_TELE_NO],4,3)+'-'+SUBSTRING([DH_PROV_TELE_NO],7,len([DH_PROV_TELE_NO])-5)
,'C',GetDate(),'system','system',1,SUBSTRING(P_FED_TAX_ID,1,2)+'-'+SUBSTRING(P_FED_TAX_ID,3,len(P_FED_TAX_ID)-2) from @OrgTemp
 
 
update x
set x.PartyId= y.PartyID
 from #Accounts1 x
 inner join @OrgTemp y
 on x.p_id= y.p_id
 where x.PartyId is null
 
IF OBJECT_ID('tempdb..#OrgParties','U') IS NOT NULL
begin 
drop table #OrgParties
end


-----------------------------------------------------------

MERGE [KYPEnrollment].[pAccount_PDM_Provider]  trgt
USING 
( 	select y.partyid,
		y.P_TY_CD,
		y.P_NPI_Num,
		 y.p_id,
		y.P_DEA_NUM,
		y.PrimarySpeciality,
		category =case when y.ProviderType = 'Individual' then 'Physician' 
					when y.ProviderType = 'Organization' then 'Institutional' 
					end,
		'' as ProvNumber
		,Y.DH_ENROL_STAT_CD_1
from #Accounts1 y
	where y.provid is null )src
ON (trgt.provNumber=src.ProvNumber)
WHEN NOT MATCHED THEN 
	INSERT ( PartyID ,
		Category
		,Type 
		,NPI 
		,IsEnrolled
		,ProvNumber
		,Mon_MedicaidID
		,dateCreated
		,DateModified
		,DEA 
		,PrimarySpecialty 
		,IsDeleted
		,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag
		)
 VALUES (src.partyid,
		 src.category,
		src.P_TY_CD,
		case when src.P_NPI_NUM like '%[a-z]%' then null else src.P_NPI_NUM end
		,1
		, src.p_id
		, src.p_id
		,getdate()
		,getdate()
		,src.P_DEA_NUM
		,src.PrimarySpeciality
		,0
		,'C',GetDate(),'system','system',1
		);
 
update y
set y.type = z.ProviderTypeDescription
 from [KYPEnrollment].[pAccount_PDM_Provider] y
 inner join KYP.PDM_ProviderTypeCode z
on y.Type = z.ProviderTypeCode 


update x
set x.ProvId = y.ProvID
 from #Accounts1 x
 inner join [KYPEnrollment].[pAccount_PDM_Provider] y
 on x.p_id= y.ProvNumber
 where x.ProvId is null
 
 
--------------------------------------------------
Insert into [KYPEnrollment].[pAccount_PDM_Number] 
(PartyID,State,Number,LicenseBoardCode,DateCreated,ExpirationDate,IsDeleted,EffectiveDate,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy, CurrentRecordFlag ,Type)
select x.PartyId, null,x.P_LIC_CERT_NUM,x.P_ST_CD,GETDATE(),CONVERT(DATETIME,x.P_LIC_EXP_DT,121),0,CONVERT(DATETIME,x.P_LIC_EFF_DT,121),'C',GetDate(),'system','system',1,'Professional License'
	from (select c.PartyId,c.ProvId,d.*
	from  #Accounts1 c
		inner join [dbo].[ProviderLicense] d
	on c.p_id = d.p_id )x	
	

insert into [KYPEnrollment].[pAccount_PDM_Speciality]
(PartyID,Speciality_Code,TaxonomyCode, IsPrimary, DateCreated,SpecCertDate, Type,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy, CurrentRecordFlag,IsDeleted)		 
select x.PartyId,x.P_SPECL_CD,E.LongDescription, 1 as IsPrimary, GETDATE(),convert(varchar(10),DH_SPE_CERT_DT ,101) ,'Specialty Code','C',GetDate(),'system','system',1,0
from (select c.PartyId,c.provid,d.*, ROW_NUMBER()over(PARTITION by d.p_id order by id asc)as row
	from  #Accounts1 c
		inner join [dbo].[ProviderSpeciality] d
	on c.p_id = d.p_id)x
	 Left JOIN KYP.PDM_SpecialityCode E
	 ON x.P_SPECL_CD = E.Value
where x.row=1
union all
select x.PartyId,x.P_SPECL_CD,E.LongDescription,0 as IsPrimary,GETDATE(),convert(varchar(10),DH_SPE_CERT_DT ,101),'Specialty Code','C',GetDate(),'system','system',1,0
from (select c.PartyId,c.provid,d.*, ROW_NUMBER()over(PARTITION by d.p_id order by id asc)as row
	from  #Accounts1 c
		inner join [dbo].[ProviderSpeciality] d
	on c.p_id = d.p_id)x
	Left JOIN KYP.PDM_SpecialityCode E
	 ON x.P_SPECL_CD = E.Value
where x.row>1

insert into [KYPEnrollment].[pAccount_PDM_Speciality]
(PartyID,Speciality_Code,TaxonomyCode, IsPrimary, DateCreated, Type,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy, CurrentRecordFlag,IsDeleted)		 
select x.PartyId,x.DH_PROV_TAXONOMY_DATA,'', 1 as IsPrimary, GETDATE(),'Taxonomy Code','C',GetDate(),'system','system',1,0
from (select c.PartyId,c.provid,d.*, ROW_NUMBER()over(PARTITION by d.DH_PROV_NUMBER_201+d.DH_OWNER_NUM_2002+d.DH_SERV_LOC_NUM_2038+d.DH_KEY_PROV_TYP_3_205 order by id asc)as row
	from  #Accounts1 c
		inner join [dbo].Stage_CA_Taxonomy_DATA d
	on c.p_id = d.DH_PROV_NUMBER_201+d.DH_OWNER_NUM_2002+d.DH_SERV_LOC_NUM_2038+d.DH_KEY_PROV_TYP_3_205)x
where x.row=1
union all
select x.PartyId,x.DH_PROV_TAXONOMY_DATA,'',0 as IsPrimary,GETDATE(),'Taxonomy Code','C',GetDate(),'system','system',1,0 
from (select c.PartyId,c.provid,d.*, ROW_NUMBER()over(PARTITION by d.DH_PROV_NUMBER_201+d.DH_OWNER_NUM_2002+d.DH_SERV_LOC_NUM_2038+d.DH_KEY_PROV_TYP_3_205 order by id asc)as row
	from  #Accounts1 c
		inner join [dbo].Stage_CA_Taxonomy_DATA d
	on c.p_id = d.DH_PROV_NUMBER_201+d.DH_OWNER_NUM_2002+d.DH_SERV_LOC_NUM_2038+d.DH_KEY_PROV_TYP_3_205)x
where x.row>1


insert into [KYPEnrollment].[pAccount_PDM_Clia]
(PartyID, CliaNumber,CertificateType,lastAction,LastActionDate,LastActorUserId,LastActionApprovedByUsedID, CurrentRecordFlag)			 
select x.PartyId ,x.P_CLIA_NUM,x.CertificationType,'C',GetDate(),'system','system',1 
	from (select c.PartyId,c.ProvId, d.*
		from  #Accounts1 c
			left join [dbo].[ProviderCLIA] d
		on c.p_id = d.p_id)x


------------1st address------------
declare @Address table (addressId INT , providerId int, partyid int)

MERGE [KYPEnrollment].[pAccount_PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD,
		x.P_LINE2_AD,
		x.P_CITY_NAM,
		x.P_ST_CD,
		x.P_ZIP5_CD,
		x.P_ZIP4_CD,
		null as addressId,x.DH_SERV_LOC_NUM 
		,y.Description
		from #Accounts1 x 
		left join KYP.LK_Screening  y
		on x.P_ST_CD = y.Abreviation
		where TypeID=4)src
ON (trgt.addressid=src.addressId )
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,AddressType
		,lastAction,LastActionDate,LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo)
 VALUES (src.P_LINE1_AD,
		 src.P_LINE2_AD,
		src.P_CITY_NAM,
		src.Description
		,src.P_ZIP5_CD
		,Coalesce(src.P_ZIP5_CD,'')+'-'+coalesce(src.P_ZIP4_CD,'')
		,'Pay-to','C',GetDate(),'system','system',1	,src.DH_SERV_LOC_NUM)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address;
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
 select addressId,partyid,providerId, GETDATE(),1,0,'Pay-to','C',GetDate(),'system','system',1 from @Address
		
------------1st address------------

------------2nd address------------
declare @Address1 table (addressId INT , providerId int, partyid int, phone1 varchar(10))

MERGE [KYPEnrollment].[pAccount_PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD2,
		x.P_LINE2_AD2,
		x.P_CITY_NAM2,
		x.P_ST_CD2,
		x.P_ZIP5_CD2,
		x.P_ZIP4_CD2,
		null as addressId,z.Name, x.DH_PROV_TELE_NO,x.DH_SERV_LOC_NUM
		,y.Description
		from #Accounts1 x 
		left join KYP.LK_Screening y
		on x.P_ST_CD2 = y.Abreviation
		and TypeID=4
		left join [KYP].[CA_CountyCodes] z
		on z.Code= x.DH_PROV_CNTY
		)src
ON (trgt.addressid=src.addressId )
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,AddressType
		,County
		,lastAction,LastActionDate,LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo
		)
 VALUES (src.P_LINE1_AD2,
		 src.P_LINE2_AD2,
		src.P_CITY_NAM2,
		src.Description
		,src.P_ZIP5_CD2
		,Coalesce(src.P_ZIP5_CD2,'')+'-'+coalesce(src.P_ZIP4_CD2,'')
		,'Servicing'
		,src.Name,'C',GetDate(),'system','system',1,src.DH_SERV_LOC_NUM)
output inserted.AddressId,src.ProvId,src.PartyId, src.DH_PROV_TELE_NO
 into @Address1;
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,Phone1,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
 select addressId,partyid,providerId, GETDATE(),1,0,'Servicing',phone1,'C',GetDate(),'system','system',1 from @Address1
------------2nd address------------

------------2nd address Replicate For Individual Profile------------
declare @Address1d table (addressId INT , providerId int, partyid int, phone1 varchar(10))

MERGE [KYPEnrollment].[pAccount_PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD2,
		x.P_LINE2_AD2,
		x.P_CITY_NAM2,
		x.P_ST_CD2,
		x.P_ZIP5_CD2,
		x.P_ZIP4_CD2,
		null as addressId,z.Name, x.DH_PROV_TELE_NO,x.DH_SERV_LOC_NUM
		,y.Description
		from #Accounts1 x 
		left join KYP.LK_Screening y
		on x.P_ST_CD2 = y.Abreviation
		and TypeID=4
		left join [KYP].[CA_CountyCodes] z
		on z.Code= x.DH_PROV_CNTY
		)src
ON (trgt.addressid=src.addressId )
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,AddressType
		,County
		,lastAction,LastActionDate,LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo
		)
 VALUES (src.P_LINE1_AD2,
		 src.P_LINE2_AD2,
		src.P_CITY_NAM2,
		src.Description
		,src.P_ZIP5_CD2
		,Coalesce(src.P_ZIP5_CD2,'')+'-'+coalesce(src.P_ZIP4_CD2,'')
		,'Individual Profile'
		,src.Name,'C',GetDate(),'system','system',1,src.DH_SERV_LOC_NUM)
output inserted.AddressId,src.ProvId,src.PartyId, src.DH_PROV_TELE_NO
 into @Address1d;
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,Phone1,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
 select addressId,partyid,providerId, GETDATE(),1,0,'Individual Profile',phone1,'C',GetDate(),'system','system',1 from @Address1d
------------End 2nd address Replicate For Individual Profile------------

------------3rd address------------
declare @Address2 table (addressId INT , providerId int, partyid int)

MERGE [KYPEnrollment].[pAccount_PDM_Address]  trgt
USING 
( 	select distinct x.partyid, x.provid, x.P_LINE1_AD3,
		x.P_LINE2_AD3,
		x.P_CITY_NAM3,
		x.P_ST_CD3,
		x.P_ZIP5_CD3,
		x.P_ZIP4_CD3,
		null as addressId, x.DH_SERV_LOC_NUM 
		,y.Description
		from #Accounts1 x 
		left join KYP.LK_Screening y
		on x.P_ST_CD3 = y.Abreviation
		where TypeID=4
	)src
ON (trgt.addressid=src.addressId )
WHEN NOT MATCHED THEN 
	INSERT ( addressLine1 ,
		addressLine2
		,City 
		,State 
		,Zip
		,ZipPlus4
		,AddressType
		,lastAction,LastActionDate,LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo
		)
 VALUES (src.P_LINE1_AD3,
		 src.P_LINE2_AD3,
		src.P_CITY_NAM3,
		src.Description
		,src.P_ZIP5_CD3
		,Coalesce(src.P_ZIP5_CD3,'')+'-'+coalesce(src.P_ZIP4_CD3,'')
		,'Mailing'
		,'C',GetDate(),'system','system',1,src.DH_SERV_LOC_NUM)
output inserted.AddressId,src.ProvId,src.PartyId
 into @Address2;
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
 select addressId,partyid,providerId, GETDATE(),1,0,'Mailing','C',GetDate(),'system','system',1 from @Address2
------------3rd address------------

delete from ProviderIndOwner where coalesce(P_OWNER_LAST_NAM,'')in('','.') and coalesce(P_OWNER_FST_NAM,'')in('','.')

-----------individual Owner---------------------
 SELECT distinct	   
       --KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_LAST_NAM],', ',' '),',',' ')))))as [P_OWNER_LAST_NAM]
       x.P_OWNER_LAST_NAM
      ,KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_FST_NAM],', ',' '),',',' ')))))as [P_OWNER_FST_NAM]
      ,KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(rtrim(ltrim(Replace(REPLACE(x.[P_OWNER_MI_NAM],', ',' '),',',' ')))))as [P_OWNER_MI_NAM]
      ,x.[P_OWNER_TITL_NAM]
      ,x.[P_OWNER_DOB_DT]
      ,x.[P_OWNER_SSN_NUM]
      ,x.[P_LINE1_AD]
      ,x.[P_LINE2_AD]
      ,x.[P_CITY_NAM]
      ,x.[P_ST_CD]
      ,x.[P_ZIP5_CD]
      ,x.[P_ZIP4_CD]
      ,x.Owner_FullName 
      ,x.Owner_NPI
      ,y.PartyId
      ,y.ProvId
      ,y.LoadId
      ,y.LoadType
      ,y.LastLoadDate
      ,cast(null as int) as OwnerId
      ,CAST(null as INT) as ownerpartyid
      ,case when isdate(x.MOCA_END_DT)=1 then x.MOCA_END_DT else null end as MOCA_END_DT
      ,case when isdate(x.MOCA_EFF_DT)=1 then x.MOCA_EFF_DT else null end as MOCA_EFF_DT
      ,x.P_ID
      ,case when isdate(z.DH_MOCA_BILL_END_DT)=1 then z.DH_MOCA_BILL_END_DT else null end as DH_MOCA_BILL_END_DT
      ,case when isdate(z.DH_MOCA_BILL_EFF_DT)=1 then z.DH_MOCA_BILL_EFF_DT else null end as DH_MOCA_BILL_EFF_DT
      ,case when isdate(s.[Column 7])=1 then s.[Column 7] else null end as [Column 7]
into tmp_IndOwners
FROM [dbo].[ProviderIndOwner] x
inner join [dbo].#Accounts1 y
on x.P_ID=y.P_ID
left join dbo.Stage_MOCA_Billing z
on  x.P_ID = (z.DH_MOCA_BILL_PROV_NO + z.DH_MOCA_BILL_OWNER + z.DH_MOCA_BILL_LOCATION + z.DH_MOCA_BILL_PROV_TYPE)
and x.P_OWNER_SSN_NUM = z.DH_MOCA_BILL_SSN
left join Stage_MOCA_Detail S
on z.DH_MOCA_BILL_SSN = s.DH_MOCA_SSN

update tmp_IndOwners set DH_MOCA_BILL_END_DT = null where cast(DH_MOCA_BILL_END_DT as DATE)>'2079-06-06 23:59:00'
update tmp_IndOwners set [Column 7] = null where cast([Column 7] as DATE)>'2079-06-06 23:59:00'
update tmp_IndOwners set DH_MOCA_BILL_EFF_DT = null where cast(DH_MOCA_BILL_EFF_DT as DATE)>'2079-06-06 23:59:00'
update tmp_IndOwners set MOCA_END_DT = null where cast(MOCA_END_DT as DATE)>'2079-06-06 23:59:00'
update tmp_IndOwners set MOCA_EFF_DT = null where cast(MOCA_EFF_DT as DATE)>'2079-06-06 23:59:00'
update tmp_IndOwners set [P_OWNER_DOB_DT] = null where cast([P_OWNER_DOB_DT] as DATE)>'2079-06-06 23:59:00'


update tmp_IndOwners set Owner_NPI = null where Owner_NPI=''
update tmp_IndOwners set [P_OWNER_SSN_NUM] = null where [P_OWNER_SSN_NUM]=''
update tmp_IndOwners set Owner_FullName = P_OWNER_LAST_NAM+COALESCE((', ' + P_OWNER_FST_NAM), '') +  COALESCE((' ' + P_OWNER_MI_NAM), '')
update tmp_IndOwners set P_OWNER_LAST_NAM = null where P_OWNER_LAST_NAM=''
update tmp_IndOwners set P_OWNER_FST_NAM = null where P_OWNER_FST_NAM=''
update tmp_IndOwners set P_OWNER_MI_NAM = null where P_OWNER_MI_NAM=''

-----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------

select x.* 
into #tmpIndParties2 
 from(select * from tmp_IndOwners where ownerpartyid is null)x


-------insert individual party and person for new records-------------

declare @personTemp1 table (partyid INT ,provid int, P_SSN_NUM varchar(9), P_SFX_NAM varchar(10), 
P_LAST_NAM varchar(50), P_FST_NAM varchar(50),P_MI_NAM varchar(50), P_DOB_DT datetime, P_NPI_NUM varchar(10), p_id varchar(20), MOCA_EFF_DT datetime,MOCA_END_DT datetime,DH_MOCA_BILL_EFF_DT datetime,DH_MOCA_BILL_END_DT datetime,parentpartyid int)

MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
  select distinct x.ownerpartyid, x.[P_OWNER_LAST_NAM]
      ,x.[P_OWNER_FST_NAM]
      ,x.[P_OWNER_MI_NAM]
      ,x.[P_OWNER_TITL_NAM]
      ,x.[P_OWNER_DOB_DT]
      ,x.[P_OWNER_SSN_NUM]
      ,x.[P_LINE1_AD]
      ,x.[P_LINE2_AD]
      ,x.[P_CITY_NAM]
      ,x.[P_ST_CD]
      ,x.[P_ZIP5_CD]
      ,x.[P_ZIP4_CD]
      ,x.Owner_FullName 
      ,x.Owner_NPI
      ,x.LoadId
      ,x.LoadType
      ,x.LastLoadDate
      ,x.MOCA_END_DT
      ,'Individual Ownership' as [Type],0 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,p_id
      ,x.MOCA_EFF_DT
      ,x.DH_MOCA_BILL_END_DT
      ,x.DH_MOCA_BILL_EFF_DT
      ,x.[Column 7]
      ,x.partyid
from #tmpIndParties2 x where x.ownerpartyid is null
)src ON (trgt.partyid=src.ownerpartyid)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated], dateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,MOCARelationshipStartDate,MOCARelationshipEndDate)
 VALUES (src.[Type],src.Owner_FullName,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.MOCA_EFF_DT,src.MOCA_END_DT,'C',src.[Column 7],'system','system',1,src.DH_MOCA_BILL_EFF_DT,src.DH_MOCA_BILL_END_DT )
output inserted.partyid,null as provid, src.P_owner_SSN_NUM,src.[P_OWNER_TITL_NAM],src.[P_owner_LAST_NAM],src.[P_owner_FST_NAM],
src.[P_owner_MI_NAM],src.[P_owner_DOB_DT],src.Owner_NPI, src.p_id,src.MOCA_EFF_DT,src.MOCA_END_DT,src.DH_MOCA_BILL_EFF_DT,src.DH_MOCA_BILL_END_DT,src.partyid
 into @personTemp1;

INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           (PartyID,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
select partyid, SUBSTRING(P_SSN_NUM,1,3)+'-'+SUBSTRING(P_SSN_NUM,4,2)+'-'+SUBSTRING(P_SSN_NUM,6,len(P_SSN_NUM)-5)
,P_SFX_NAM,P_FST_NAM,P_MI_NAM,P_LAST_NAM,P_DOB_DT,P_NPI_NUM,MOCA_EFF_DT,MOCA_END_DT,'C',GetDate(),'system','system',1  from @personTemp1 
 

update x
set x.ParentPartyID = y.parentpartyid
from KYPEnrollment.pAccount_PDM_Party x
inner join @personTemp1 y
on x.partyid = y.partyid


IF OBJECT_ID('tempdb..#tmpIndParties2','U') IS NOT NULL
begin 
drop table #tmpIndParties2
end


------------------------------Organization owners


SELECT distinct
       KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(COALESCE(x.P_OWNER_BUSN_NAM,x.P_OWNER_DBA_NAM))) as P_OWNER_BUSN_NAM
      ,KYP.RemoveDoubleQuotes(KYP.RemoveSingleQuotes(x.P_OWNER_DBA_NAM))  as P_OWNER_DBA_NAM
      , x.[P_OWNER_TAX_ID]
      , x.[P_BUSN_LINE1_AD]
      , x.[P_BUSN_LINE2_AD]
      , x.[P_BUSN_CITY_NAM]
      , x.[P_BUSN_ST_CD]
      , x.[P_BUSN_ZIP5_CD]
      , x.[P_BUSN_ZIP4_CD]
       ,x.Owner_NPI
       ,case when isdate(x.MOCA_END_DT)=1 then x.MOCA_END_DT else null end as MOCA_END_DT
      ,y.PartyId
      ,y.ProvId
      ,y.LoadId
      ,y.LoadType
      ,y.LastLoadDate
      ,CAST(null as INT) as ownerid
      ,CAST(null as INT) as ownerpartyid
      ,x.P_ID
      ,case when isdate(x.MOCA_EFF_DT)=1 then x.MOCA_EFF_DT else null end as MOCA_EFF_DT
      ,case when isdate(z.DH_MOCA_BILL_EFF_DT)=1 then z.DH_MOCA_BILL_EFF_DT else null end as DH_MOCA_BILL_EFF_DT
      ,case when isdate(z.DH_MOCA_BILL_END_DT)=1 then z.DH_MOCA_BILL_END_DT else null end as DH_MOCA_BILL_END_DT
      ,case when isdate(s.[Column 7])=1 then s.[Column 7] else null end as [Column 7]
      into tmp_orgOwner
  FROM [dbo].[ProviderOrgOwner] x
  inner join #Accounts1 y
  on  x.[P_ID] =y.P_ID
  left join Stage_MOCA_Billing z
  on x.P_ID = (z.DH_MOCA_BILL_PROV_NO + z.DH_MOCA_BILL_OWNER + z.DH_MOCA_BILL_LOCATION + z.DH_MOCA_BILL_PROV_TYPE) and x.P_OWNER_TAX_ID=z.DH_MOCA_BILL_TIN
  left join Stage_MOCA_Detail S
  on z.DH_MOCA_BILL_TIN = s.DH_MOCA_TIN
  
update tmp_orgOwner set Owner_NPI = null where Owner_NPI=''
update tmp_orgOwner set [P_OWNER_TAX_ID] = null where [P_OWNER_TAX_ID]=''
update tmp_orgOwner set P_OWNER_BUSN_NAM = null where P_OWNER_BUSN_NAM=''
update tmp_orgOwner set P_OWNER_DBA_NAM = null where P_OWNER_DBA_NAM=''
 

 --------------------------------------------------------------------------------------------

select x.*
into #OrgParties1
from tmp_orgOwner x
where  x.ownerpartyid is null
 ----------------------------------------------------
 
 ---insert org party 
 declare @OrgTemp1 table (partyid INT,provid int, P_FED_TAX_ID varchar(10), P_NAM varchar(50), 
P_DBA_NAM varchar(50),P_NPI_NUM varchar(10),p_id varchar(20),MOCA_EFF_DT datetime,MOCA_END_DT datetime,parentpartyid int)

MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
( select x.*,'Entity Ownership' as [Type],0 as IsProvider,1 as IsEnrolled,0 as IsTemp,1 as IsActive,0 as isdeleted, GETDATE()as datecreated,2 as currentmodule
from #OrgParties1 x where x.ownerpartyid is null
 )src 
ON (trgt.partyid=src.ownerpartyid)
WHEN NOT MATCHED THEN 
	INSERT ( [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated],dateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,MOCARelationshipStartDate,MOCARelationshipEndDate )
 VALUES (src.[Type],src.P_OWNER_BUSN_NAM,src.IsProvider,src.IsEnrolled,src.IsTemp,src.IsActive,src.LoadType,src.LoadID,
src.LastLoadDate,src.isdeleted, src.MOCA_EFF_DT,src.MOCA_END_DT,'C',src.[Column 7],'system','system',1,src.DH_MOCA_BILL_EFF_DT,src.DH_MOCA_BILL_END_DT)
output inserted.partyid,src.ProvId, src.[P_OWNER_TAX_ID],src.P_OWNER_BUSN_NAM,src.P_OWNER_DBA_NAM,src.Owner_NPI,src.p_id,src.MOCA_EFF_DT,src.MOCA_END_DT,src.partyid
 into @OrgTemp1;

----insert new organizations	 
INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           (PartyID,LegalName,DBAName1,TIN,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,EIN)
select partyid, P_NAM,P_DBA_NAM,P_FED_TAX_ID,P_NPI_NUM,MOCA_EFF_DT,MOCA_END_DT,'C',GetDate(),'system','system',1
,SUBSTRING(P_FED_TAX_ID,1,2)+'-'+SUBSTRING(P_FED_TAX_ID,3,len(P_FED_TAX_ID)-2) from @OrgTemp1

 
update x
set x.ParentPartyID = y.parentpartyid
from KYPEnrollment.pAccount_PDM_Party x
inner join @OrgTemp1 y
on x.partyid = y.partyid


 
 IF OBJECT_ID('tempdb..#OrgParties1','U') IS NOT NULL
begin 
drop table #OrgParties1
end

-----------------------------------------------------
select * into #Accounts2 from #Accounts1 --For Chow Implementation

select x.* into #Accounts_Chow from 
(select *, ROW_NUMBER()over(partition by P_NPI_NUM,P_TY_CD,DH_SERV_LOC_NUM order by dh_owner_num desc) as row from [tmp_ProviderNameAddress])x
where x.row>1

delete from #Accounts2
where P_ID in(select P_ID from #Accounts_Chow)


insert into [KYPEnrollment].[pADM_Account]
(LegacyAccountNo, AccountType,NPI,NPIType,OwnerNo,ServiceLocationNo,PIN,DateCreated,AccountUpdateDate,AccountUpdatedBy,DBAName,ProviderTypeCode,
StatusAcc,LegalName,ApplicationDate, PartyID,IsDeleted,CreatedBy,profile_id
,EIN,SSN,ProviderType,StatusBeginDate,ReenrollmentIndicator,ReenrollmentDate,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy
,ActivationDate,DeactivationDate, AccountNumber,ProvLocTypeCd, ProvTypeUpdateDate,PackageName,DateModified,PracticeAddress)
select x.P_ID,
 case when x.FileSource = 'N' then 'NMP'
 when x.FileSource = 'O' then 'ORP'
 when x.FileSource = 'M' and x.P_TY_CD IN('004','008','074') then 'ATY'
 when x.FileSource = 'M' and x.DH_ENROL_STAT_CD_1 ='7' then 'R'
 when x.FileSource = 'M' and y.ProviderType='Individual' or  right(x.DH_TYP_OF_PRAC_ORG,1) = '1'
  then 'I'
 when x.FileSource = 'M' and right(x.DH_TYP_OF_PRAC_ORG,1) = '6' and
  x.P_TY_CD IN('003', '005', '006', '010', '012', '013', '018', '019', '021', '022','023', '025','027', '029', '031', '032', '037','062', '071', '078')
  then 'G'
 when x.FileSource = 'M' and x.P_TY_CD in ('007', '008', '012', '020', '026', '056', '067', '082', '085')
  then 'I'
 when x.FileSource = 'M' and x.P_TY_CD in ('080', '031', '006', '024', '027', '032', '025', '037', '018', '019','003', '057', '029', '005', '021')  and right(x.DH_TYP_OF_PRAC_ORG,1) = '1'
  then 'I'
 when x.FileSource = 'M' 
 and x.P_TY_CD in ('015','016','035','045','001','014','017','036','039','040','041','042','043','044','045','046','048','049','050','051','052','054','059','060','061','065','072','073','074','081','068','069','076','092','093')
   then 'F'
 when x.FileSource = 'M' 
 and x.P_TY_CD in ('080','089') and x.P_SSN_NUM=''
   then 'F'
 when x.FileSource = 'M' and x.P_TY_CD IN('080','089') and x.P_SSN_NUM<>''
  then 'I'
 when x.FileSource = 'M' and x.P_TY_CD IN('024', '030', '038', '075', '011', '033', '053', '055', '058', '063', '064', '066', '084', '095','057', '013', '028', '002', '009')
  then 'RES'
 when x.FileSource = 'M' and y.ProviderType='Organization'
  then 'I'
 else 'UNK'
 end as accountype 
,x.P_NPI_NUM,case when x.FileSource IN ('N','O') then 'Individual' else null end,x.DH_OWNER_NUM,x.DH_SERV_LOC_NUM,x.DH_PIN,x.DH_DT_PROV_ADDED,x.DH_LAST_ACTY_DT,'M',x.P_DBA_NAM,x.P_TY_CD, 
x.DH_ENROL_STAT_CD_1+' - '+l.Descriptor as StatusAcc ,P_NAM,cast(x.DH_APP_DT as datetime), x.PartyId,0,1,Null,x.P_FED_TAX_ID,x.P_SSN_NUM
,z.ProviderTypeDescription, x.STAT_EFF_DT,x.RE_ENROMENT_IN,x.RE_ENR_EFF_DATE,'C',GetDate(),'system','system'
,case when x.DH_ENROL_STAT_CD_1 in('1','7','9')then x.STAT_EFF_DT else null end
,case when x.DH_ENROL_STAT_CD_1 not in('1','7','9')then x.STAT_EFF_DT else null end
 ,800000000+ROW_NUMBER()OVER (ORDER BY x.p_id)
 ,x.DH_PROV_LOC_TYPE, x.LAST_ACTVT_DT
 ,case
  
	when x.FileSource = 'O' then 'ISP_P_ORP'
	 
	when x.FileSource = 'N' then 'ISP_RP_S_RM'  
	
	when y.ProviderType = 'Individual' and P_TY_CD='026' and DH_ENROL_STAT_CD_1 IN ('1','9') and x.FileSource = 'M' 
		then 'ISP_P_DM'
		
	when y.ProviderType = 'Organization' and P_TY_CD='026' and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
		then 'IGSP_P_DM'
		
	when y.ProviderType = 'Individual' and P_TY_CD='022' and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
		then 'GISP_P_DM'
		
	when y.ProviderType = 'Organization' and P_TY_CD='022' and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
		then 'GSP_P_DM'
	
	when P_TY_CD='026' and DH_ENROL_STAT_CD_1 IN ('7')  and x.FileSource = 'M' 
		then 'ISP_RP_P_DM'		
		
	when P_TY_CD IN ('003','032','006','012','019','025','027','031','037','056','018','005','007')
			and DH_ENROL_STAT_CD_1 IN ('7')  and x.FileSource = 'M' 
		then 'ISP_RP_U_RA'
		
	when y.ProviderType = 'Individual'
			and P_TY_CD IN ('032','003','006','012','019','025','027','031','056','037','018','005','007')
			and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'ISP_NP_AP'	

		when y.ProviderType = 'Individual' 
			and P_TY_CD IN ('003','032','018','005','007','006','012','019','025','027','031','037','062','010','023', '071', '078')
			and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'GISP_NP_AP'	
	
	when y.ProviderType = 'Organization'
			and P_TY_CD IN ('032','003','006','012','019','025','027','031','056','037','018','005','007')
			and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'IGSP_NP_AP'	
		
		when y.ProviderType = 'Organization' 
			and P_TY_CD IN ('003','032','018','005','007','006','012','019','025','027','031','037','062','010','023','071','078')
			and DH_ENROL_STAT_CD_1 IN ('1','9')  and x.FileSource = 'M' 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'GSP_AL_BL'	


/* Below is the logic for Historic Providers*/


--Physician/Surgeon below
when P_TY_CD='026' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  and x.FileSource = 'M' 
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)and (
			ltrim(rtrim(x.P_FED_TAX_ID))=''
			OR y.ProviderType ='Individual'
			or x.DH_TYP_OF_PRAC_ORG ='51'
			)
		then 'ISP_P_DM'

when P_TY_CD='026' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  and x.FileSource = 'M' 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
			and (
			(y.ProviderType ='Organization' and y.P_Org_LegalName<>'')
			or x.DH_TYP_OF_PRAC_ORG ='53'
			)
		then 'IGSP_P_DM'

--Physician/Surgeon Group below
when  P_TY_CD='022' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  and x.FileSource = 'M' 
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
			and (
			ltrim(rtrim(x.P_FED_TAX_ID))=''
			OR y.ProviderType ='Individual'
			)
		then 'GISP_P_DM'

when y.ProviderType IS null and 
			x.P_TY_CD='022' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'GSP_P_DM'		

when y.ProviderType ='Organization' and y.P_Org_LegalName<>'' and 
			x.P_TY_CD='022' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)
		then 'GSP_P_DM'

--Renderings below

when y.ProviderType IS null and P_TY_CD='026' and DH_ENROL_STAT_CD_1 not IN ('1','7','9')  and x.FileSource = 'M' 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NOS-IN-GRP]
			)
		then 'ISP_RP_P_DM'		
		
	when y.ProviderType IS null 
			and P_TY_CD IN ('003','032','006','012','019','025','027','031','037','056','018','005','007')
			and DH_ENROL_STAT_CD_1 not IN ('1','7','9')and x.FileSource = 'M' 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NOS-IN-GRP]
			)  
		then 'ISP_RP_U_RA'

--4 Allied Types Below Start
when P_TY_CD IN ('032','003','006','012','019','025','027','031','056','037','018','005','007')
			and DH_ENROL_STAT_CD_1 NOT IN ('1','7','9')  
			AND ltrim(rtrim(x.P_FED_TAX_ID)) IN ('000000000','','999999999')and x.FileSource = 'M'  --NO EIN for Sole Proprietor
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)and (
			ltrim(rtrim(x.P_FED_TAX_ID))=''
			OR y.ProviderType ='Individual'
			or DH_TYP_OF_PRAC_ORG ='51'
			)
		then 'ISP_NP_AP'

when y.ProviderType IS NULL 
			and P_TY_CD IN ('003','032','018','005','007','006','012','019','025','027','031','037','062','010','023', '071', '078')
			and DH_ENROL_STAT_CD_1 NOT IN ('1','7','9') 
			AND ltrim(rtrim(x.P_FED_TAX_ID)) IN ('000000000','','999999999')and x.FileSource = 'M'  --NO EIN for Sole Proprietor 
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)and (
			ltrim(rtrim(x.P_FED_TAX_ID))=''
			OR y.ProviderType ='Individual'			
			)
		then 'GISP_NP_AP'	

	when  P_TY_CD IN ('032','003','006','012','019','025','027','031','056','037','018','005','007')
			and DH_ENROL_STAT_CD_1 NOT IN ('1','7','9')  
			--AND ltrim(rtrim(x.P_FED_TAX_ID)) NOT IN ('000000000','','999999999')and x.FileSource = 'M'  -- A valid EIN for Incorporation
			and NOT exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)and (
			(y.ProviderType ='Organization' and y.P_Org_LegalName<>'')
			or x.DH_TYP_OF_PRAC_ORG ='53'
			)
		then 'IGSP_NP_AP'	
		
		when P_TY_CD IN ('003','032','018','005','007','006','012','019','025','027','031','037','062','010','023', '071', '078')
			and DH_ENROL_STAT_CD_1 NOT IN ('1','7','9') and x.FileSource = 'M'  
			and exists (
			select 1 from  dbo.stage_GroupProvider C
			where  x.P_NPI_NUM =  C.[PM-PROV-NUMBER]
			and x.DH_SERV_LOC_NUM = C.[PM-SERV-LOC-NUM]
			and x.DH_OWNER_NUM = C.[PM-OWNER-NUM]
			and x.P_TY_CD = C.[PM-KEY-PROV-TYP]
			)and (ltrim(rtrim(P_FED_TAX_ID)) NOT IN ('000000000','','999999999') -- A valid EIN for Incorporation
			or (y.ProviderType ='Organization' and y.P_Org_LegalName<>'')
			)
		then 'GSP_AL_BL'
	else ''
end as PackageType,
x.DH_LAST_ACTY_DT, coalesce(b.AddressLine1,'')+' '+coalesce(b.AddressLine2,'')+' '+coalesce(b.City,'')+' '+coalesce(b.State,'')+' '+coalesce(b.ZipPlus4,'')
from #Accounts2 x
left join  Hippaspace.dbo.HIPPA_ProviderDetails y On  y.NPI = x.P_NPI_NUM
left join KYP.PDM_ProviderTypeCode z
on x.P_TY_CD = z.ProviderTypeCode
left join KYPEnrollment.pAccount_PDM_Party p
on x.PartyId= p.PartyID
left join kypenrollment.LK_AccInternalUseDataCode l
on x.DH_ENROL_STAT_CD_1 = l.Code
and l.Type=10
left join KYPEnrollment.pAccount_PDM_Location a
on a.PartyID=x.PartyId
and a.Type='Servicing'
inner join KYPEnrollment.pAccount_PDM_Address b
on a.AddressID= b.AddressID


--NPI Type

UPDATE KYPEnrollment.pADM_Account SET NPIType='Individual'
WHERE AccountType in ('NMP','ORP') and NPIType IS NULL

UPDATE A SET A.NPIType=B.ProviderType
FROM  KYPEnrollment.pADM_Account A INNER JOIN Hippaspace.dbo.HIPPA_ProviderDetails B ON A.NPI=B.NPI WHERE A.NPIType IS NULL

UPDATE KYPEnrollment.pADM_Account SET NPIType='Individual'
WHERE NPIType IS NULL AND SUBSTRING(StatusAcc,1,1) in ('1','7','9') AND SSN <> ''

update KYPEnrollment.pADM_Account 
set NPIType = 'Organization' where NPIType is null and SUBSTRING(StatusAcc,1,1) in ('1','7','9') --83
--NPI Type

--PI-481
update KYPEnrollment.pADM_Account set AccountType='G' 
 where PackageName='GSP_P_DM' and AccountType='I' 
 and left(StatusAcc,1) in ('1','7','9') 

 update KYPEnrollment.pADM_Account set AccountType='I' 
 where PackageName='IGSP_NP_AP' and AccountType='G' 
 and left(StatusAcc,1) in ('1','7','9') 

 update KYPEnrollment.pADM_Account set AccountType='G' 
 where PackageName='GSP_AL_BL' and AccountType='I' 
 and left(StatusAcc,1) in ('1','7','9')
 
--End PI-481


insert into [KYPEnrollment].[pAccount_History]
(AccountID,ActionID,DateCreated,IsDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
select AccountID,50 as actionid,getdate(),0,'C',GetDate(),'system','system',1
from KYPEnrollment.pADM_Account 
where LegacyAccountNo is not null

-----CHOW Implementation

declare @MaxOwnershipCount int
declare @OwnershipCount int
select @OwnershipCount=1, @MaxOwnershipCount = MAX(cast(DH_OWNER_NUM as INT)) from #Accounts_Chow
while (@OwnershipCount <=@MaxOwnershipCount)
Begin


	select * into #LoopAccountsChow from #Accounts_Chow where cast(DH_OWNER_NUM as INT)= @OwnershipCount

	insert into [KYPEnrollment].[pADM_Account]
	(LegacyAccountNo, AccountType,NPI,NPIType,OwnerNo,ServiceLocationNo,PIN,DateCreated,AccountUpdateDate,AccountUpdatedBy,DBAName,ProviderTypeCode,
	StatusAcc,LegalName,ApplicationDate, PartyID,IsDeleted,CreatedBy,profile_id
	,EIN,SSN,ProviderType,StatusBeginDate,ReenrollmentIndicator,ReenrollmentDate,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy
	,ActivationDate,DeactivationDate, AccountNumber,ProvLocTypeCd, ProvTypeUpdateDate,IsPastOwner,PackageName,DateModified,PracticeAddress)
	select y.P_ID, x.AccountType ,x.NPI,x.NPIType,y.DH_OWNER_NUM,Y.DH_SERV_LOC_NUM,Y.DH_PIN,y.DH_DT_PROV_ADDED,x.AccountUpdateDate,x.AccountUpdatedBy,
	y.P_DBA_NAM,y.P_TY_CD,y.DH_ENROL_STAT_CD_1+' - '+l.Descriptor as StatusAcc,y.P_NAM,cast(y.DH_APP_DT as datetime), y.PartyId,x.IsDeleted,x.CreatedBy,x.profile_id
	,y.P_FED_TAX_ID,y.P_SSN_NUM,x.ProviderType, y.STAT_EFF_DT,y.RE_ENROMENT_IN,y.RE_ENR_EFF_DATE,x.lastAction,x.LastActionDate,x.LastActorUserId,x.LastActionApprovedBy
	,x.ActivationDate,x.DeActivationDate 
	,x.AccountNumber+'-'+ y.DH_OWNER_NUM as ChowAccountNumber ,y.DH_PROV_LOC_TYPE, y.LAST_ACTVT_DT,1 as ispastowner,
	x.PackageName,x.DateModified,coalesce(b.AddressLine1,'')+' '+coalesce(b.AddressLine2,'')+' '+coalesce(b.City,'')+' '+coalesce(b.State,'')+' '+coalesce(b.ZipPlus4,'')
	from KYPEnrollment.pADM_Account x
	inner join #LoopAccountsChow y
	on x.NPI = y.P_NPI_NUM
	and x.ProviderTypeCode =y.P_TY_CD
	and x.ServiceLocationNo=y.DH_SERV_LOC_NUM
	left join kypenrollment.LK_AccInternalUseDataCode l
	on y.DH_ENROL_STAT_CD_1 = l.Code
	and l.Type=10
	left join KYPEnrollment.pAccount_PDM_Location a
	on a.PartyID=x.PartyId
	and a.Type='Servicing'
	inner join KYPEnrollment.pAccount_PDM_Address b
	on a.AddressID= b.AddressID
	where x.IsPastOwner=0

	--insert into [KYPEnrollment].[pAccount_History]
	--(AccountID,ActionID,DateCreated,IsDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
	--select x.AccountID,x.actionid,x.DateCreated,x.IsDeleted,x.lastAction,x.LastActionDate,x.LastActorUserId,x.LastActionApprovedBy,x.CurrentRecordFlag
	--from
	--(select x.AccountID,50 as actionid,getdate() as DateCreated,0 as IsDeleted,'C' as lastAction,GetDate() as LastActionDate,'system' as LastActorUserId,'system' as LastActionApprovedBy,1 as CurrentRecordFlag, 
	--ROW_NUMBER() over(partition by x.NPI,x.ProviderTypeCode,x.ServiceLocationNo order by x.accountid desc)as row
	--from KYPEnrollment.pADM_Account x
	--inner join #LoopAccountsChow y
	--on x.NPI = y.P_NPI_NUM
	--and x.ProviderTypeCode =y.P_TY_CD
	--and x.ServiceLocationNo=y.DH_SERV_LOC_NUM
	--where x.LegacyAccountNo is not null and x.IsPastOwner=1)x
	--where x.row=1
	
	--Insert into KYPEnrollment.pAccount_History
	--(AccountID,ActionID,DateCreated,IsDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
	--select x.AccountID,x.actionid,x.DateCreated,x.IsDeleted,x.lastAction,x.LastActionDate,x.LastActorUserId,x.LastActionApprovedBy,x.CurrentRecordFlag
	--from
	--(select x.AccountID,60 as actionid,getdate() as DateCreated,0 as IsDeleted,'C' as lastAction,GetDate() as LastActionDate,'system' as LastActorUserId,'system' as LastActionApprovedBy,0 as CurrentRecordFlag, 
	--ROW_NUMBER() over(partition by x.NPI,x.ProviderTypeCode,x.ServiceLocationNo order by x.accountid desc)as row
	--from KYPEnrollment.pADM_Account x
	--inner join #Accounts1 y
	--on x.NPI = y.P_NPI_NUM
	--and x.ProviderTypeCode =y.P_TY_CD
	--and x.ServiceLocationNo=y.DH_SERV_LOC_NUM
	--where x.LegacyAccountNo is not null and x.IsPastOwner=1)x
	--where x.row<>1


	--update y
	--set	
	--y.LegacyAccountNo=x.P_ID, 
	--y.NPI=x.P_NPI_NUM,
	--y.OwnerNo=x.DH_OWNER_NUM,
	--y.ServiceLocationNo=x.DH_SERV_LOC_NUM,
	--y.PIN=x.DH_PIN,
	--y.DateCreated=x.DH_DT_PROV_ADDED,
	--y.AccountUpdateDate=x.DH_LAST_ACTY_DT,
	--y.DBAName=x.P_DBA_NAM,
	--y.ProviderTypeCode=x.P_TY_CD,
	--y.StatusAcc=x.DH_ENROL_STAT_CD_1+' - '+l.Descriptor,
	--y.LegalName=P_NAM,
	--y.ApplicationDate=cast(x.DH_APP_DT as datetime), 
	--y.PartyID=x.PartyId,
	--y.EIN=x.P_FED_TAX_ID,
	--y.SSN=x.P_SSN_NUM,
	--y.ProviderType=z.ProviderTypeDescription,
	--y.StatusBeginDate=x.STAT_EFF_DT,
	--y.ReenrollmentIndicator=x.RE_ENROMENT_IN,
	--y.ReenrollmentDate=x.RE_ENR_EFF_DATE,
	--y.ActivationDate=case when x.DH_ENROL_STAT_CD_1 in('1','7','9')then x.STAT_EFF_DT else null end,
	--y.DeactivationDate=case when x.DH_ENROL_STAT_CD_1 not in('1','7','9')then x.STAT_EFF_DT else null end, 
	--y.ProvLocTypeCd=x.DH_PROV_LOC_TYPE, 
	--y.ProvTypeUpdateDate=x.LAST_ACTVT_DT,
	--y.DateModified= x.DH_LAST_ACTY_DT,
	--y.PracticeAddress= coalesce(b.AddressLine1,'')+' '+coalesce(b.AddressLine2,'')+' '+coalesce(b.City,'')+' '+coalesce(b.State,'')+' '+coalesce(b.Zip,'')+'-'+coalesce(b.ZipPlus4,'')

	--from KYPEnrollment.pADM_Account y
	--inner join #LoopAccountsChow x
	--	on y.NPI = x.P_NPI_NUM
	--	and y.ProviderTypeCode =x.P_TY_CD
	--	and y.ServiceLocationNo=x.DH_SERV_LOC_NUM
	--	and y.IsPastOwner=1
	--left join KYP.PDM_ProviderTypeCode z
	--on x.P_TY_CD = z.ProviderTypeCode
	--left join KYPEnrollment.pAccount_PDM_Party p
	--on x.PartyId= p.PartyID
	--left join kypenrollment.LK_AccInternalUseDataCode l
	--on x.DH_ENROL_STAT_CD_1 = l.Code
	--and l.Type=10
	--left join KYPEnrollment.pAccount_PDM_Location a
	--on a.PartyID=x.PartyId
	--and a.Type='Servicing'
	--inner join KYPEnrollment.pAccount_PDM_Address b
	--on a.AddressID= b.AddressID

	DROP TABLE #LoopAccountsChow
	
	set @OwnershipCount = @OwnershipCount+1
End

-----CHOW Implementation
update x
set x.PartyID = y.PartyID
from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo = y.ProvNumber
where x.IsPastOwner=1

update x
set x.accountid = y.accountid
from [KYPEnrollment].[pAccount_pdm_party] x
inner join KYPEnrollment.pADM_Account y
on x.partyid = y.partyid
where y.LegacyAccountNo is not null

Insert into KYPEnrollment.HIS_MadeChange(
HistoryID,Field,TypeChange,NewValue,CreatedBy, DateCreate, ModifiedBy,DateModify, DeletedBy, DateDelete, IsDeleted, OldValue)
Select x.HistoryID, 'LabType' as Field, '' As TypeChange, Z.DH_LAB_Type as NewValue, '' as CreatedBy, getdate() as DateCreate, '' as ModifiedBy, getdate() as DateModify, '' as DeletedBy ,getdate() as DateDelete, '' as IsDeleted,  '' as OldValue 
From KYPEnrollment.pAccount_History x
Inner Join KYPEnrollment.pADM_Account Y
On x.AccountID = y.AccountID
Left Join (Select *, ROW_NUMBER()over(partition by x.[DH_PROV_NUMBER_201] order by x.id) as row
FROM dbo.Stage_CA_Lab_Type x ) z
ON Y.LegacyAccountNo = Z.[DH_PROV_NUMBER_201]+Z.DH_OWNER_NUM_2002+Z.DH_SERV_LOC_NUM_2038+Z.DH_KEY_PROV_TYP_3_205
where  z.row <> 1 and x.ActionID = 60 
Union 
Select x.HistoryID, 'LabStatusEffDate' as Field, '' As TypeChange, Z.DH_LAB_S_EFF_DT_1290 as NewValue, '' as CreatedBy, getdate() as DateCreate, '' as ModifiedBy, getdate() as DateModify, '' as DeletedBy ,getdate() as DateDelete, '' as IsDeleted,  '' as OldValue 
From KYPEnrollment.pAccount_History x
Inner Join KYPEnrollment.pADM_Account Y
On x.AccountID = y.AccountID
Left Join (Select *, ROW_NUMBER()over(partition by x.[DH_PROV_NUMBER_201] order by x.id) as row
FROM dbo.Stage_CA_Lab_Type x ) z
ON Y.LegacyAccountNo = Z.[DH_PROV_NUMBER_201]+Z.DH_OWNER_NUM_2002+Z.DH_SERV_LOC_NUM_2038+Z.DH_KEY_PROV_TYP_3_205
where  z.row <> 1 and x.ActionID = 60

insert into [KYPEnrollment].[pAccount_UniqueParty]
(SSN,EIN,BusinessLegalName,BusinessDBAName,lastAction,LastActionDate,LastActorUserId)
select X.P_SSN_NUM, x.TIN,x.LegalName,x.DBAName1,'C',GetDate(),'system'
 from (select z.P_SSN_NUM, x.*,y.loadtype,ROW_NUMBER()over(partition by x.tin,x.legalname order by OrgID)row
 from KYPEnrollment.pAccount_PDM_Organization x
 inner join KYPEnrollment.pAccount_PDM_Party y
 on x.PartyID= y.PartyID 
  left join #Accounts1 z 
 on x.partyid= z.PartyId )x
 where x.row=1 and x.loadType='MonthlyProvider'
 

insert into [KYPEnrollment].[pAccount_UniqueParty]
(EIN,SSN,LastName,MiddleName,FistName,DOB,lastAction,LastActionDate,LastActorUserId)
select case when LEN(x.P_FED_TAX_ID)>10 then SUBSTRING(x.P_FED_TAX_ID,1,10)else x.P_FED_TAX_ID end,case when LEN(x.SSN)>10 then SUBSTRING(x.SSN,1,10)else x.SSN end ,x.LastName,x.MiddleName,x.FirstName,x.DoB,'C',GetDate(),'system'
 from (select z.P_FED_TAX_ID, x.*,y.loadtype,ROW_NUMBER()over(partition by x.ssn,x.LastName,x.FirstName order by PersonID)row
 from KYPEnrollment.pAccount_PDM_Person x
 inner join KYPEnrollment.pAccount_PDM_Party y
 on x.PartyID= y.PartyID
 left join #Accounts1 z 
 on x.partyid= z.PartyId )x
 where x.row=1 and x.loadType='MonthlyProvider'



insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.TIN,z.LegalName,z.DBAName1 from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Organization] z
on y.PartyID= z.PartyID)x
on coalesce(y.EIN,'')=coalesce(x.TIN,'')
and y.BusinessLegalName = x.LegalName
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null


insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.TIN,z.LegalName,z.DBAName1 from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Organization] z
on y.PartyID= z.PartyID)x
on y.EIN=x.TIN
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null and x.LegalName is null


insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.SSN,z.LastName,z.FirstName from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Person] z
on y.PartyID= z.PartyID)x
on coalesce(y.SSN,'')=coalesce(x.SSN,'')
and y.LastName = x.LastName
and y.FistName = x.FirstName
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null


insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.SSN,z.LastName,z.FirstName from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Person] z
on y.PartyID= z.PartyID)x
on coalesce(y.SSN,'')=coalesce(x.SSN,'')
and y.LastName = x.LastName
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null and x.FirstName is null 

insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.SSN,z.LastName,z.FirstName from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Person] z
on y.PartyID= z.PartyID)x
on coalesce(y.SSN,'')=coalesce(x.SSN,'')
and y.FistName = x.FirstName
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null and x.LastName is null 

insert into [KYPEnrollment].[pAccount_UniqueParty_Account]
(AccountID,UniquePartyID,CurrentRecordFlag)
select x.AccountID, y.UniquePartyID,1 from [KYPEnrollment].[pAccount_UniqueParty] y
inner hash join 
(select x.AccountID,z.SSN,z.LastName,z.FirstName from KYPEnrollment.pADM_Account x
inner join KYPEnrollment.pAccount_PDM_Provider y
on x.LegacyAccountNo= y.ProvNumber
inner join [KYPEnrollment].[pAccount_PDM_Person] z
on y.PartyID= z.PartyID)x
on coalesce(y.SSN,'')=coalesce(x.SSN,'')
left hash join [KYPEnrollment].[pAccount_UniqueParty_Account] A
on A.AccountID = x.accountid
where A.AccountID is null and x.LastName is null  and x.FirstName is null

insert into [KYPEnrollment].[pAccount_Name]
(AccountID,Name, NameType,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
select z.AccountID,z.LegalName, 'LegalName' ,'C' as LastAction,GetDate() as LastActionDate,'system' as LastActorUserID,'system'  as LastActionApprovedBy,1 as CurrentRecordFlag
from KYPEnrollment.pADM_Account z
where z.LegacyAccountNo is not null
UNION ALL
select z.AccountID,z.DBAName, 'BusinessName' ,'C' as LastAction,GetDate() as LastActionDate,'system' as LastActorUserID,'system'  as LastActionApprovedBy,1 as CurrentRecordFlag
from KYPEnrollment.pADM_Account z
where z.LegacyAccountNo is not null and z.AccountType not in('NMP','ORP')




Insert into [KYPEnrollment].[pAccount_Owner]
(AccountID,OwnerNo,PracticeType,LegalName,TIN,SSN, EffectiveBeingDate, EffectiveEndDate,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
select y.AccountID, y.OwnerNo,x.DH_TYP_OF_PRAC_ORG,z.Name,x.P_FED_TAX_ID,x.P_SSN_NUM ,x.DH_OWNER_EFFEC_BEG_DT,x.DH_OWNER_EFFEC_END_DT ,'C' as LastAction,GetDate() as LastActionDate,'system' as LastActorUserID,'system'  as LastActionApprovedBy,1 as CurrentRecordFlag
from #Accounts1 x 
inner join KYPEnrollment.pADM_Account y
on x.P_ID= y.LegacyAccountNo
inner join KYPEnrollment.pAccount_PDM_Party z
on y.PartyID= z.PartyID



select Group_ProviderNO, Member_ProviderNO, null as grpAccId, null as memAccId, 
case FileSource when 'Y' then 'NEW_RENDERING_FROM_ACCOUNT' 
when 'S' then 'NEW_RENDERING_MIDLEVEL_FROM_ACCOUNT' end as AffilType,NmpProvType,NmpSartDate,NmpEndDate
into #RenderAffiliation
from kyp.PDM_MasterGroupProvider

update x
set x.grpAccId=y.AccountID
from #RenderAffiliation x 
inner join KYPEnrollment.pADM_Account y
on x.Group_ProviderNO= y.LegacyAccountNo

update x
set x.memAccId=y.AccountID
from #RenderAffiliation x 
inner join KYPEnrollment.pADM_Account y
on x.Member_ProviderNO= Substring(y.LegacyAccountNo,1,10)

update x
set x.memAccId=y.AccountID
from #RenderAffiliation x 
inner join KYPEnrollment.pADM_Account y
on x.Member_ProviderNO= y.LegacyAccountNo

insert into [KYPEnrollment].[pAccount_RenderingAffiliation]
(AccountID,AffiliatedAccountID,TypeAffiliation,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,
CurrentRecordFlag,AffiliatedAccountProvTypeCode,AffiliationStartDate,AffiliationEndDate)
select grpAccId,memAccId,AffilType,'C' as LastAction,GetDate() as LastActionDate,'system' as LastActorUserID,'system' 
 as LastActionApprovedBy,1 as CurrentRecordFlag,NmpProvType,NmpSartDate,NmpEndDate
 from #RenderAffiliation


--update x
--set x.AffiliationStartDate = case when isdate(y.[PM-NMP-EFF-DT])=1 then y.[PM-NMP-EFF-DT] else null end
--,x.AffiliationEndDate = case when isdate(y.[PM-NMP-END-DT])=1 then y.[PM-NMP-END-DT] else null end
--from KYPEnrollment.pAccount_RenderingAffiliation x
--inner join
--(select distinct x.AccountID,z.[PM-NMP-EFF-DT],z.[PM-NMP-END-DT]  
--from KYPEnrollment.pAccount_RenderingAffiliation x
--inner join KYPEnrollment.pADM_Account y
--on x.AccountID = y.AccountID
--inner join stage_NMPGroupProvider z
--on y.LegacyAccountNo=z.[PM-PROV-NUMBER]+z.[PM-OWNER-NUM]+z.[PM-SERV-LOC-NUM]+z.[PM-KEY-PROV-TYP])y
--on x.AccountID= y.AccountID
--where x.TypeAffiliation='NMP'

IF OBJECT_ID('tempdb..#RenderAffiliation','U') IS NOT NULL
begin 
drop table #RenderAffiliation
end

insert into [KYPEnrollment].[pAccount_UniqueParty_MOCAMapping]
(UniquePartyID,MOCAPartyID,EffectiveBeingDate,EffectiveEndDate,LastAction,LastActionDate,CurrentRecordFlag)
select x.UniquePartyID, y.PartyID, z.DH_OWNER_EFFEC_BEG_DT,z.DH_OWNER_EFFEC_END_DT ,'C' as LastAction,GetDate() as LastActionDate,1 as CurrentRecordFlag
from KYPEnrollment.pAccount_UniqueParty_Account x
inner join KYPEnrollment.pADM_Account y
on x.AccountID= y.AccountID
inner join #Accounts1 z
on y.LegacyAccountNo=z.P_ID

insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
 select x.AccountID,z.DH_ENROL_STAT_CD5, 'Enrollment' 
 ,x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
  z.dh_STAT_EFF_DT5,z.dh_STAT_END_DT5,y.P_LINE1_AD2,
		y.P_LINE2_AD2,
		y.P_CITY_NAM2,
		y.P_ST_CD2,
		coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',0
  from KYPEnrollment.pADM_Account x
  inner join #Accounts1 y
  on x.LegacyAccountNo= y.P_ID
  inner join providerenrollstatdata z
  on y.P_ID= z.p_id
  where coalesce(z.DH_ENROL_STAT_CD5,'')<>''


  insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
 select x.AccountID,z.DH_ENROL_STAT_CD4, 'Enrollment', x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
  z.dh_STAT_EFF_DT4,z.dh_STAT_END_DT4,y.P_LINE1_AD2,
		y.P_LINE2_AD2,
		y.P_CITY_NAM2,
		y.P_ST_CD2,
		coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',0
  from KYPEnrollment.pADM_Account x
  inner join #Accounts1 y
  on x.LegacyAccountNo= y.P_ID
  inner join ProviderEnrollStatData z
  on y.P_ID= z.p_id
    where coalesce(z.DH_ENROL_STAT_CD4,'')<>''
  

 insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
 select x.AccountID,z.DH_ENROL_STAT_CD3, 'Enrollment' 
, x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
  z.dh_STAT_EFF_DT3 ,z.dh_STAT_END_DT3 ,y.P_LINE1_AD2,
		y.P_LINE2_AD2,
		y.P_CITY_NAM2,
		y.P_ST_CD2,
		coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',0
  from KYPEnrollment.pADM_Account x
  inner join #Accounts1 y
  on x.LegacyAccountNo= y.P_ID
  inner join providerenrollstatdata z
  on y.P_ID= z.p_id
    where coalesce(z.DH_ENROL_STAT_CD3,'')<>'' 

  
  insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
 select x.AccountID,z.DH_ENROL_STAT_CD2, 'Enrollment' 
, x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
  z.dh_STAT_EFF_DT2,z.dh_STAT_END_DT2,y.P_LINE1_AD2,
		y.P_LINE2_AD2,
		y.P_CITY_NAM2,
		y.P_ST_CD2,
		coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',0
  from KYPEnrollment.pADM_Account x
  inner join #Accounts1 y
  on x.LegacyAccountNo= y.P_ID
  inner join providerenrollstatdata z
  on y.P_ID= z.p_id
  where coalesce(z.DH_ENROL_STAT_CD2,'')<>''
  


insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
select x.AccountID,z.DH_ENROL_STAT_CD1, 'Enrollment' 
, x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
z.dh_STAT_EFF_DT1,z.dh_STAT_END_DT1,y.P_LINE1_AD2,
	y.P_LINE2_AD2,
	y.P_CITY_NAM2,
	y.P_ST_CD2,
	coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',1
from KYPEnrollment.pADM_Account x
inner join #Accounts1 y
on x.LegacyAccountNo= y.P_ID
inner join providerenrollstatdata z
on y.P_ID= z.p_id
where coalesce(z.DH_ENROL_STAT_CD1,'')<>''



insert into [KYPEnrollment].[pADM_AccountStatus]
(AccountID,StatusValue,StatusType,BillingAccountNo,BillingNPI,BillingServiceLocationNo,
EffectiveBeginDate,EffectiveEndDate,BillingServiceAdrLn1,BillingServiceAdrLn2,BillingServiceCity,BillingServiceState,
BillingServiceZIP9,lastAction,LastActionDate,LastActionApprovedBy,CurrentRecordFlag)
 select x.AccountID,
  case when z.DH_ENROL_STAT_CD1='1' and y.FileSource='M' and y.P_TY_CD NOT IN('004','008','074') then 'Billing'
 when z.DH_ENROL_STAT_CD1='1' and y.FileSource='M' and y.P_TY_CD IN('004','008','074') then 'Atypical'
 when z.DH_ENROL_STAT_CD1='7' and y.FileSource='M' then 'Rendering'
  when y.FileSource='O' then 'ORP'
  when y.FileSource='N' then 'NMP'
else null end as StatusValue ,
case when z.DH_ENROL_STAT_CD1='1' and y.FileSource='M' and y.P_TY_CD NOT IN('004','008','074') then 'Billing'
 when z.DH_ENROL_STAT_CD1='1' and y.FileSource='M' and y.P_TY_CD IN('004','008','074') then 'Billing'
 when z.DH_ENROL_STAT_CD1='7' and y.FileSource='M' then 'Billing'
  when y.FileSource='O' then 'Billing'
  when y.FileSource='N' then 'Billing'
else null end as StatusType,
 x.LegacyAccountNo,y.P_NPI_NUM,x.ServiceLocationNo,
  z.dh_STAT_EFF_DT1,z.dh_STAT_END_DT1,y.P_LINE1_AD2,
		y.P_LINE2_AD2,
		y.P_CITY_NAM2,
		y.P_ST_CD2,
		coalesce(y.P_ZIP5_CD2,'')+coalesce(y.P_ZIP4_CD2,''),'C',GETDATE(),'system',1
  from KYPEnrollment.pADM_Account x
  inner join #Accounts1 y
  on x.LegacyAccountNo= y.P_ID
  inner join providerenrollstatdata z
  on y.P_ID= z.p_id
  
 Update A set StatusValue=StatusValue+'-'+l.Descriptor
 from [KYPEnrollment].[pADM_AccountStatus] A left join kypenrollment.LK_AccInternalUseDataCode l
	on A.StatusValue = l.Code and l.Type=10

insert into [KYPEnrollment].[EDM_AccountInternalUse]
(ProvisionalCode, TINUpdateType,TINUpdateDate,OutOfStateInd
,SpecProcTypeCode,RejectReasonCode,ExceptionIndicator
,accountid,ProvisionalCodeDate,LastAction,LastActionDate,LastActorUserID
,LastActionApprovedBy,CurrentRecordFlag,NameOfFacAdmin,IMDFacilType,PracTypeCode1,PracTypeCode2,CHDPCode)
select distinct PROVIS_ENROLL_IND,DH_TIN_UPDATE_TYPE,DH_TIN_UPDATE_DATE 
,DH_OUT_OF_STATE_IND,y.DH_SPEC_PROCESS_TYPE_CD,DH_REJECT_REASON,DH_EXCEPTION_IND
,z.AccountID,x.PROVIS_ENROLL_EFFEC_DT,'C',GETDATE(),'system','system',1,x.DH_NAME_OF_FAC_ADMIN,x.DH_IMD_FACIL_TYPE, left(x.DH_TYP_OF_PRAC_ORG,1),right(x.DH_TYP_OF_PRAC_ORG,1),x.PM_CHDP_PROV_NUMBER
from #Accounts1 x
LEFT join ProviderSpeciality y
on x.P_ID= y.P_ID
inner join KYPEnrollment.pADM_Account z
on x.P_ID= z.LegacyAccountNo

Update x set 
x.AtypicalProviderNo = Y.NPI
from [KYPEnrollment].[EDM_AccountInternalUse] x
inner join KYPEnrollment.pADM_Account Y
on x.AccountID =y.AccountID
and Y.AccountType = 'ATY'
 
 Update A set BillingStatus='1 - Billing'
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where  left(B.StatusAcc,1)='1' 
 and B.AccountType not in ('NMP','ORP')
 
  Update A set BillingStatus='5 - Atypical'
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where B.ProviderTypeCode in ('004', '008', '074') and left(B.StatusAcc,1)='1'
 and B.AccountType not in ('NMP','ORP')
 
 Update A set BillingStatus='2 - Rendering'
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where  left(B.StatusAcc,1)='7' 
 and B.AccountType not in ('NMP','ORP')
 
 Update A set BillingStatus='3 - ORP'
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where  left(B.StatusAcc,1)='7' 
 and B.AccountType='ORP'
 
 Update A set BillingStatus='2 - Rendering'
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where  left(B.StatusAcc,1)='7' 
 and B.AccountType='NMP'
 
 Update A set BillingBeginDate=B.ActivationDate ,A.BillingEndDate=B.DeActivationDate
 from KYPEnrollment.EDM_AccountInternalUse A
 inner join [KYPEnrollment].[pADM_Account]  B
 on A.AccountID=b.AccountID where left(B.StatusAcc,1) IN('1','7','9')

Insert INto [kypenrollment].[EDM_AccountInternalMany]
(AccountInternalUseID,CodeIdentification,CodeDescription,CodeType,CodeDateEffDate,CodeDateExpDate,isDeleted,
LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
select distinct z.AccountInternalUseID,y.DH_CATSERV_CD, x.descriptor , 'Category' as CodeType, y.DH_CATSERV_BEGIN_DT,y.DH_CATSERV_END_DT,0,
'C',GETDATE(),'system','system',1
from dbo.ProviderCategoryServices y
left join (select x.* from kypenrollment.LK_AccInternalUseDataCode x where x.Type=2)x
on cast(x.code as INT)= cast(y.DH_CATSERV_CD as int)
inner join
(select y.LegacyAccountNo,x.AccountInternalUseID 
from [KYPEnrollment].[EDM_AccountInternalUse] x
inner join KYPEnrollment.pADM_Account y
on x.accountid= y.accountid )z
on y.p_id= z.LegacyAccountNo
where y.DH_CATSERV_CD <>''

Insert INto [kypenrollment].[EDM_AccountInternalMany]
(AccountInternalUseID,CodeIdentification,CodeDescription,CodeType,isDeleted,
LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
select distinct z.AccountInternalUseID,y.DH_SANCTION_TXT,x.Descriptor,  'Sanction' as CodeType, 0,
'C',GETDATE(),'system','system',1
from dbo.ProviderSanction y
left join (select x.* from kypenrollment.LK_AccInternalUseDataCode x where x.Type=3)x
on  x.code = y.DH_SANCTION_TXT
inner join
(select y.LegacyAccountNo,x.AccountInternalUseID 
from [KYPEnrollment].[EDM_AccountInternalUse] x
inner join KYPEnrollment.pADM_Account y
on x.accountid= y.accountid )z
on y.p_id= z.LegacyAccountNo
where y.DH_SANCTION_TXT <>''


Insert INto [kypenrollment].[EDM_AccountInternalMany]
(AccountInternalUseID,CodeIdentification,CodeDescription,CodeType,CodeDateEffDate,CodeDateExpDate,isDeleted,
LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)

select distinct z.AccountInternalUseID,y.DH_LAB_SPEC_1277,x.descriptor, 'Specialty' as CodeType, y.DH_LB_S_DT_1278,y.DH_LB_E_DT_1279,0,
'C',GETDATE(),'system','system',1
from dbo.Stage_CA_Lab_Spec_Details y
left join (select x.* from kypenrollment.LK_AccInternalUseDataCode x where x.Type=5)x
on cast(x.code as INT)= cast(y.DH_LAB_SPEC_1277 as int)
inner join
(select y.LegacyAccountNo,x.AccountInternalUseID 
from [KYPEnrollment].[EDM_AccountInternalUse] x
inner join KYPEnrollment.pADM_Account y
on x.accountid= y.accountid )z
on y.DH_PROV_NUMBER_201+y.DH_OWNER_NUM_2002+y.DH_SERV_LOC_NUM_2038+y.DH_KEY_PROV_TYP_3_205= z.LegacyAccountNo
where 
coalesce(y.DH_LAB_SPEC_1277,'')<>'' and coalesce(y.DH_LB_S_DT_1278,'')<>'' 
--CP-34 start        CONVERT(varchar(10),DateStringColumn
--CONVERT(smalldatetime, A.Value)
/*
--CP-34  Script Updated  dropped table dbo.pADM_AccProvMapping  and created mapping between 
--Account.NPI+Account.OwnerNo+Account.ServiceLocationNo+Account.ProviderTypeCode=Provider.MedicaidID

  INSERT into   dbo.pADM_AccProvMapping  (AccountNumber,ProviderNumber)
  select distinct acc.LegacyAccountNo ,PR.MedicaidID 
  from   KYPEnrollment.pADM_Account acc 
   inner join  KYP.MDM_SearchProviders PR 
   on PR.MedicaidID =acc.LegacyAccountNo
   left join dbo.pADM_AccProvMapping  apm
   on acc.LegacyAccountNo = apm.AccountNumber
   where apm.AccountNumber is null
 */
--CP-34 end

--PD-224 start

update x
set x.Risk = y.Risk
,x.RiskDescriptor = y.descriptor
from  KYPEnrollment.pADM_Account x
inner join 
(select x.accountid, y.RiskCategory as descriptor, 
case when y.RiskCategory = 'Limited' then '1' 
when  y.RiskCategory = 'Moderate' then '2'
when  y.RiskCategory = 'High' then '3'
else null end as Risk
 from KYPEnrollment.pADM_Account x
inner join kyp.PDM_ProviderTypeCode y
on x.ProviderTypeCode = y.ProviderTypeCode
where x.LegacyAccountNo is not null)y
on x.AccountID= y.AccountID

--PD-224 end


insert into [KYPEnrollment].[pAccount_PDM_Document]
(PartyID,TypeDoc,NumberDoc,StateIssued,DateCreated, IsDeleted,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
SELECT party.PartyID,'No data','No data','No data',  GETDATE(),0,'C',GETDATE(),'system','system',1
FROM KYPEnrollment.pAccount_PDM_Party party
inner join KYPEnrollment.pAccount_PDM_Person person
on party.PartyID=person.PartyID
        AND party.IsDeleted=0
        AND person.Deleted=0
        AND party.CurrentRecordFlag=1
        AND person.CurrentRecordFlag=1
        and party.LoadType is not null
        and party.IsProvider=1
inner join KYPEnrollment.pADM_Account a
on a.AccountID= party.AccountID
and a.LegacyAccountNo is not null



INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           ([PartyID]
           ,[LegalName]
           ,[BusinessName]
           ,[Phone1]
           ,[Remarks]
           ,[DateCreated]
           ,[IsDeleted]
           ,[EIN]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
 select p.PartyID,p.Name,p.Name,pe.Phone1,'BusinessProfile',getdate(),0
 ,pe.SSN,'C',GETDATE(),'system','system',1 from KYPEnrollment.pAccount_PDM_Party p
 inner join KYPEnrollment.pAccount_PDM_Person pe
 on p.PartyID= pe.PartyID
 where p.IsProvider=1
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_EntityType]
           ([PartyID]
           ,[NameEntityType]
           ,[DateCreated]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
 select p.PartyID,'No data',getdate(),0,'C',GETDATE(),'system','system',1 
 from KYPEnrollment.pAccount_PDM_Party p
 inner join KYPEnrollment.pADM_Account a
 on p.AccountID= a.AccountID
 where p.IsProvider=1 and a.LegacyAccountNo is not null
 
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
           ([PartyID]
           ,[Number]
           ,[Type]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[DateCreated]
           ,[IsDeleted]
           ,[State]
           ,[LicenseBoardCode]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
           
  select x.PartyID,x.Number,'BusinessEinLicenses',x.EffectiveDate,x.ExpirationDate,GETDATE()
  ,0,x.State,x.LicenseBoardCode,'C',GETDATE(),'system','system',1 from [KYPEnrollment].[pAccount_PDM_Number] x
  inner join KYPEnrollment.pADM_Account y
  on x.PartyID= y.PartyID
   where x.Type='Professional License' and y.LegacyAccountNo is not null
  
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
           ([PartyID]
           ,[Number]
           ,[Type]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[DateCreated]
           ,[IsDeleted]
           ,[State]
           ,[LicenseBoardCode]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
           
  select x.PartyID,'No data','BusinessPermit',Null,Null,GETDATE()
  ,0,'No data',Null,'C',Null,'system','system',1 from [KYPEnrollment].[pAccount_PDM_Number] x
  inner join KYPEnrollment.pADM_Account y
  on x.PartyID= y.PartyID
   where y.LegacyAccountNo is not null and y.AccountType IN ('G' ,'I' , 'F','Res')
  
declare @personTempContact table (insertedpartyid INT , previousPartyid int)
 
MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
  select null as partyid, x.AccountID,'Contact Person' as [Type]
,x.Name,x.IsProvider,x.IsEnrolled,x.IsTemp,x.IsActive,x.LoadType,x.LoadID,
x.LastLoadDate,x.IsDeleted,x.DateCreated,x.LastAction,x.LastActionDate,
x.LastActorUserID,x.LastActionApprovedBy,x.CurrentRecordFlag,x.PartyID as parentpartyid,MOCARelationshipStartDate,MOCARelationshipEndDate
 from [KYPEnrollment].[pAccount_PDM_Party] x
 inner join [KYPEnrollment].[pAccount_PDM_Person] y
 on x.PartyID= y.PartyID
 inner join [KYPEnrollment].[pADM_Account] z
 on x.AccountID= z.AccountID
 where Type='Provider' and LoadID is not null and z.LegacyAccountNo is not null and z.NPIType is not null
)src ON (trgt.partyid=src.partyid)
WHEN NOT MATCHED THEN 
	INSERT ( [AccountID],[Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],
           [IsDeleted],[DateCreated], lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,MOCARelationshipStartDate,MOCARelationshipEndDate,parentpartyid)
 VALUES (src.AccountID,src.[Type],src.[Name],0,src.[IsEnrolled],src.[IsTemp],src.[IsActive],src.[LoadType],src.[LoadID],src.[LastLoadDate],
           src.[IsDeleted],src.[DateCreated],src.lastAction,src.LastActionDate,src.LastActorUserId,src.LastActionApprovedBy,src.CurrentRecordFlag,src.MOCARelationshipStartDate,src.MOCARelationshipEndDate,src.parentpartyid)
output inserted.partyid,src.parentpartyid into @personTempContact;

INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           (PartyID,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,Phone1)
select insertedpartyid,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag
,Phone1
from @personTempContact x
inner join [KYPEnrollment].[pAccount_PDM_person] y
on x.previousPartyid = y.PartyID
 
insert into KYPEnrollment.pAccount_PDM_DEA (PartyID,DEA,LastAction,LastActionDate,LastActorUserID,LastActionApprovedBy,CurrentRecordFlag)
select partyid,'No data','C',GETDATE(),'system','system',1 from KYPEnrollment.pAccount_PDM_Party where IsProvider=1 and LoadID is not null
--PI-493: Rajesh
Update A set A.Name='No Data'
from [KYPEnrollment].[pAccount_PDM_Party] A
inner Join KYPEnrollment.pADM_Account B on A.AccountID=b.AccountID 
where A.Type='Contact Person' and B.NPIType='Organization'
--End PI-493
INSERT INTO [KYPEnrollment].[pAccount_PDM_Insurance]
           ([PartyID]
           ,PolicyNumber
           ,[DateCreated]
           ,Type
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag],
           IsDeleted)
 select p.PartyID,'No data',getdate(),'Insurance','C',GETDATE(),'system','system',1,0
 from KYPEnrollment.pAccount_PDM_Party p
 inner join KYPEnrollment.pADM_Account a
 on p.AccountID= a.AccountID
 where p.IsProvider=1 and a.LegacyAccountNo is not null
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Insurance] 
           ([PartyID], PolicyNumber, [DateCreated],Type,[LastAction],[LastActionDate],[LastActorUserID], 
[LastActionApprovedBy],[CurrentRecordFlag],IsDeleted) 
 select p.PartyID,'No data',getdate(),'InsurancePage3','C',GETDATE(),'system','system',1,0 
 from KYPEnrollment.pAccount_PDM_Party p inner join KYPEnrollment.pADM_Account a 
 on p.AccountID= a.AccountID where p.IsProvider=1 and a.LegacyAccountNo is not null 
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_PlaceBusiness]
           ([PartyID]
           ,[DateCreated]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag],
           IsDeleted)
 select p.PartyID,getdate(),'C',GETDATE(),'system','system',1,0
 from KYPEnrollment.pAccount_PDM_Party p
 inner join KYPEnrollment.pADM_Account a
 on p.AccountID= a.AccountID
 where p.IsProvider=1 and a.LegacyAccountNo is not null
 
 
INSERT INTO [KYPEnrollment].[pAccount_RenderingSupervisor]
           (RenderingAffiliationId
           ,ProviderNumber
           ,Npi
           ,Name
           ,dateCreated
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag],
           IsDeleted)
 select p.RenderingAffiliationID,'No Data','No Data', 'No Data', getdate(),'C',GETDATE(),'system','system',1,0
 from KYPEnrollment.pAccount_RenderingAffiliation p
 inner join KYPEnrollment.pADM_Account a
 on p.AccountID= a.AccountID
 where a.LegacyAccountNo is not null
 
 Update KYPEnrollment.pAccount_RenderingAffiliation set AffiliatedAccountProvTypeCode='4a' where AffiliatedAccountProvTypeCode='4'
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_PaymentDetail]
           (PartyID
           ,DateCreated
           ,IsDeleted
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[EFT_Indicator])
 select a.PartyID,getdate(),0,'C',GETDATE(),'system','system',1,B.PM_EFT_IND
 from KYPEnrollment.pADM_Account a INNER JOIN #Accounts1 B
 ON a.LegacyAccountNo=B.P_ID
 where a.LegacyAccountNo is not null
 

Update [KYPEnrollment].[pAccount_PDM_Person] set ssn=null where ssn in('0','')
Update [KYPEnrollment].[pAccount_PDM_Person] set  NPI= null where NPI in('0','')
Update [KYPEnrollment].[pAccount_PDM_Person] set  LastName= null where LastName in('')
Update [KYPEnrollment].[pAccount_PDM_Person] set  FirstName= null where FirstName in('')

Update [KYPEnrollment].[pAccount_PDM_Organization] set tin=null where tin in('0','')
Update [KYPEnrollment].[pAccount_PDM_Organization] set NPI=null where NPI in('0','')
Update [KYPEnrollment].[pAccount_PDM_Organization] set DBAName1=null where DBAName1 in('')
Update [KYPEnrollment].[pAccount_PDM_Organization] set LegalName=null where LegalName in('')

update [KYPEnrollment].[pAccount_PDM_Number] 
set Number = NULL
where SUBSTRING(Number, PATINDEX('%[^0]%', Number+'.'), LEN(Number))=''

update [KYPEnrollment].[pAccount_PDM_Number]
set Number = NULL
where Number like '%999999999%'

update x
set x.npi= y.npi
from [KYPEnrollment].[pAccount_PDM_Person] x
inner join [KYPEnrollment].[pAccount_PDM_Provider] y
on x.PartyID = y.PartyID
where y.NPI is not null and  y.Category='Physician' and x.NPI is null

update x
set x.npi= y.npi
from [KYPEnrollment].[pAccount_PDM_Organization] x
inner join [KYPEnrollment].[pAccount_PDM_Provider] y
on x.PartyID = y.PartyID
where y.NPI is not null and  y.Category='Institutional' and x.NPI is null


update x
set x.accountid= y.accountid
from [KYPEnrollment].[pAccount_pdm_party] x
inner join
(select y.PartyID, x.AccountID
from [KYPEnrollment].[pAccount_pdm_party] x
inner join 
(select partyid, parentpartyid from KYPEnrollment.[pAccount_pdm_party] where IsProvider=0)y
on x.PartyID=y.ParentPartyID)y
on x.PartyID= y.PartyID

-- Start PI-325 Author: Rajesh Singh---

INSERT INTO [KYPEnrollment].[pAccount_PDM_LabStatus]
(AccountID,
StatusCode,
StatusEffectiveDate,
LastAction,
LastActionDate,
LastActionUser,
LastActionReason , 
LastActionComments, 
LastActionApprovedBy, 
CurrentRecordFlag)
select Y.AccountID,Y.DH_LAB_Type,y.DH_LAB_S_EFF_DT_1290,'C',GETDATE(),'System',Null,Null,'System',CurrentRecordFlag 
from (SELECT B.AccountID,A.ID, A.DH_LAB_Type,A.DH_LAB_S_EFF_DT_1290, Case when row='1' then 1 else 0 end as CurrentRecordFlag , row
FROM 
(Select *, ROW_NUMBER()over(partition by x.[DH_PROV_NUMBER_201]+ x.DH_OWNER_NUM_2002+x.DH_SERV_LOC_NUM_2038+x.DH_KEY_PROV_TYP_3_205 order by x.id) as row
 FROM dbo.Stage_CA_Lab_Type x where DH_LAB_Type is not null and DH_LAB_Type <> '') A
 inner join KYPEnrollment.pADM_Account B
on A.[DH_PROV_NUMBER_201]+A.DH_OWNER_NUM_2002+A.DH_SERV_LOC_NUM_2038+A.DH_KEY_PROV_TYP_3_205=B.LegacyAccountNo) Y 
order by AccountId asc, ID desc

Update A Set A.LabStatusCode= B.StatusCode,A.LabStatusCodeDate=B.StatusEffectiveDate 
from [KYPEnrollment].[EDM_AccountInternalUse] A
Inner Join [KYPEnrollment].[pAccount_PDM_LabStatus] B
on a.AccountID=b.AccountID
where B.CurrentRecordFlag=1

-- End --PI-325--

-----Begin KEN-5301 Author: Rajesh Singh-----

INSERT INTO [KYPEnrollment].[AccountSearch]
           ([AccountNumber],[EnrollmentStatus] ,[EnrolledOn],[ProviderType],[BillingStatus],[ScreeningLevel],[ServiceCity],
           [ServiceState],[ServiceZip],[PayCity],[PayState],[PayZip],[AccountName],[NPI],[SSN],[TAXID],[CategoryOfService],
           [ScheduledStatus],[StatusDate],[AccountID],[RiskScore],[ServiceAddressLine1],[ServiceAddressLine2],
           [PayAddressLine1],[PayAddressLine2],[License],AccountType,AccountTypeDesc)
           (  
select distinct A.AccountNumber,A.StatusAcc,A.DateCreated,A.ProviderType,G.BillingStatus,A.RiskDescriptor as ScreeningLevel,ServcCity,ServcState,ServcZip,
			PaytoCity,PaytoState,PaytoZip,A.LegalName,A.NPI,A.SSN,A.EIN,F.CodenDesc,'Unscheduled',A.StatusBeginDate,A.AccountID,A.RiskScore,
			ServcAddr1,ServcAddr2,PaytoAddr1,PaytoAddr2,H.License,A.AccountType,A.AccountTypeDescriptor
           from KYPEnrollment.pADM_Account A 
           left join (
           select A.PartyID,B.AddressID DAddressID,B.AddressLine1 ServcAddr1,B.AddressLine2 ServcAddr2,
           B.City ServcCity,B.State ServcState,B.Zip ServcZip
           from KYPEnrollment.pAccount_PDM_Location A
           Join KYPEnrollment.pAccount_PDM_Address B On A.AddressID=B.AddressID and B.AddressType='Servicing'
           )C  on A.PartyID=C.PartyID
           left join 
           (
           select A.PartyID,c.AddressID EAddressID,c.AddressLine1 PaytoAddr1,c.AddressLine2 PaytoAddr2,c.City PaytoCity,c.State				PaytoState,c.Zip PaytoZip
           from KYPEnrollment.pAccount_PDM_Location A
           Join KYPEnrollment.pAccount_PDM_Address c On A.AddressID=c.AddressID and c.AddressType='Pay-to'
           )D on A.PartyID=D.PartyId
           left Join (
           SELECT  AccountID,
			dbo.GROUP_CONCAT_D(DISTINCT Case when Y.CodeIdentification='777' then CodeIdentification
			else Y.CodeIdentification+' - '+isnull(Y.CodeDescription,'') end, N', ') AS CodenDesc
			FROM   KYPEnrollment.EDM_AccountInternalUse x
			Inner Join KYPEnrollment.EDM_AccountInternalMany y On x.AccountInternalUseID=y.AccountInternalUseID 
			where y.CodeType = 'Category'
			GROUP BY AccountID) F
           ON F.AccountID=A.AccountID
           left join KYPEnrollment.EDM_AccountInternalUse G on A.AccountID=G.AccountID
           left join (  SELECT  PartyID,dbo.GROUP_CONCAT_D(DISTINCT Case when number is not null and number<>'' then 
			number end, N', ') License
			FROM  KYPEnrollment.pAccount_PDM_Number
			where Type in
			('Professional License', 'Certificate', 'Other')
			GROUP BY PartyID ) H 
			ON A.PartyID=H.PartyID 
           )

-------End KEN-5301 ---------

delete from [KYPEnrollment].[pAccount_PDM_Location] where AddressID 
in
(select addressid from [KYPEnrollment].[pAccount_PDM_Address] where coalesce(AddressLine1,'') = '' and coalesce(AddressLine2,'')='' and coalesce(City,'') ='' and coalesce([State],'')=''  and coalesce(Zip,'')='' and coalesce(ZipPlus4,'')='')

delete from  [KYPEnrollment].[pAccount_PDM_Address] where coalesce(AddressLine1,'') = '' and coalesce(AddressLine2,'')='' and coalesce(City,'') ='' and coalesce([State],'')=''  and coalesce(Zip,'')='' and coalesce(ZipPlus4,'')=''


delete x from (select PartyID,Speciality_Code, ROW_NUMBER()over(partition by PartyID,Speciality_Code,TaxonomyCode,IsPrimary,Board,CurrentRecordFlag,Type,SpecCertDate order by SpecialityID)as row
 from [KYPEnrollment].[pAccount_PDM_Speciality])x
 where x.row>1
 
 --PI-182
insert into KYPEnrollment.pAccount_PDM_Owner_Role (TypeForm, IsDeleted, CurrentRecordFlag, Other, OtherValue,PartyID, DateCreated,
LastAction,LastActionDate,LastActionApprovedBy,LastActorUserID)
select 'OwnerControlInterestOwnerRole', 0, 1, 1,'No Data',PartyID,GETDATE(),'C',null,'System','System'  from KYPEnrollment.pAccount_PDM_Party
where TYPE in ('Individual Ownership','Entity Ownership')


INSERT  into [KYPEnrollment].[pAccount_PDM_Address] ( addressLine1 ,addressLine2,City ,State ,Zip,ZipPlus4,AddressType,lastAction,LastActionDate,
				LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo)
select partyid,null,null,null,Null,null,'Moca','C',GetDate(),'system','system',1,Null   from KYPEnrollment.pAccount_PDM_Party
where TYPE in ('Individual Ownership','Entity Ownership')
 
INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
select	null,A.partyid,Null, GETDATE(),1,0,Null,'C',GetDate(),'system','system',1 from KYPEnrollment.pAccount_PDM_Party A
where A.TYPE in ('Individual Ownership','Entity Ownership')
			
Update A  Set A.AddressID=B.AddressID from [KYPEnrollment].[pAccount_PDM_Location] A
 Inner Join [KYPEnrollment].[pAccount_PDM_Address] B on cast(A.partyid as Varchar(10))=B.addressLine1 where A.AddressID is null and B.AddressType='Moca'
 
Update [KYPEnrollment].[pAccount_PDM_Address] set addressLine1=null, AddressType=null where AddressType='Moca'

Update KYPEnrollment.pAccount_PDM_Party set CurrentRecordFlag=0 where 
TYPE in ('Individual Ownership','Entity Ownership') and MOCARelationshipEndDate<=GETDATE()
 	
--PI-182 



commit tran ProcessProvider
end try	
begin catch
	if @@TRANCOUNT > 0
	begin	
	rollback tran ProcessProvider			
	INSERT INTO [dbo].[ErroredProvidersForTheDay]
           ([ERNumber]
           ,[Error_Severity]
           ,[Error_State]
           ,[Error_Procedure]
           ,[Error_Line]
           ,[Error_Message])
	
	select 
	
	B.ERNumber
	,B.Error_Severity
	,B.Error_State
	,B.Error_Procedure
	,B.Error_Line
	,B.Error_Message
	from	 
	(
	SELECT
	ERROR_NUMBER() ERNumber
    ,ERROR_SEVERITY() Error_Severity
    ,ERROR_STATE() Error_State
    ,ERROR_PROCEDURE() Error_Procedure
    ,ERROR_LINE() Error_Line
    ,ERROR_MESSAGE() Error_Message
	) B
	

	end
end catch
END


GO

