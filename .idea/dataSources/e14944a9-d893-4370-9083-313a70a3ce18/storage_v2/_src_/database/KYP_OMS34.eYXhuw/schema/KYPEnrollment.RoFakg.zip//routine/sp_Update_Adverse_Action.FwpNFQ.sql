
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Adverse Action by Traking.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Adverse_Action]
@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100),
@data VARCHAR(MAX),
@acc_PK VARCHAR(100),
@acc_PK_value INT,
@is_text_date CHAR(1),
@app_party_id INT = null
AS
BEGIN
SET NOCOUNT ON;
DECLARE @app_adverse_action_id INT;

IF @action_taken='Added'
  BEGIN
  SELECT @app_adverse_action_id = AdverseActionID FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE TargetPath=@target_path;
   IF not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_adverse_action_id AND NameTable='pAccount_PDM_AdverseAction')

  BEGIN
  PRINT @action_taken
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @acc_party_id,NULL,@last_action_user_id,NULL,@app_adverse_action_id;
   INSERT INTO #Control_Add_row (FiledID,NameTable)
   VALUES(@app_adverse_action_id,'pAccount_PDM_AdverseAction');
  END
END

IF @action_taken='Updated'
  BEGIN
  PRINT @action_taken

    IF (@app_party_id is not null)
    BEGIN
      UPDATE [KYPEnrollment].[pAccount_PDM_AdverseAction] SET AppAdverseActionID = temp.appAdverseActionId
        FROM (	SELECT AdverseActionID as appAdverseActionId
            FROM KYPPORTAL.PortalKYP.pPDM_AdverseAction
            WHERE TargetPath = @target_path AND PartyID = @app_party_id )temp
        WHERE AdverseActionID = @acc_PK_value
    END

  EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_AdverseAction',@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;

    IF @app_party_id is not null
      EXEC [KYPEnrollment].[sp_Copy_Table_Adverse_Action_Docs] @acc_party_id,'pAccount_PDM_AdverseAction','AdverseActionID'

END

IF @action_taken='Deleted' AND @target_path LIKE '%pAccount_PDM_AdverseAction%'
  BEGIN
  PRINT @action_taken
  UPDATE KYPEnrollment.pAccount_PDM_AdverseAction SET CurrentRecordFlag = 0 WHERE AdverseActionID = @acc_PK_value;
END
END
GO

