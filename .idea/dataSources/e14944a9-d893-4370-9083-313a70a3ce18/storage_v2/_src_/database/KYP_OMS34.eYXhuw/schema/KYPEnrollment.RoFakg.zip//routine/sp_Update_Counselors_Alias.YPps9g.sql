
/* ==========================================================
-- Author:		<Palomino, Ruth>
-- PROCEDURE: Update Party Counselor Alias by Traking.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name :
-- ============================================================*/
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Counselors_Alias]


@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100),
@data VARCHAR(MAX),
@acc_PK VARCHAR(100),
@acc_PK_value INT,
@is_text_date CHAR(1),
@acc_table_name varchar(100)


AS
BEGIN
SET NOCOUNT ON;
DECLARE 
@app_party_id INT,
@acc_id int, 
@delete VARCHAR(MAX), 
@app_person_id int, 
@acc_person_id int, 
@target_path_person VARCHAR(200),
@new_party_counselor int,
@app_party_person_id int,
@app_other_person_id int

IF @action_taken='Added'
---------
  BEGIN
---------
	
	SELECT @app_person_id = PersonID, @app_other_person_id = PesonONID  FROM [KYPPORTAL].[PortalKYP].pPDM_Person_OtherName WHERE TargetPath=@target_path;
	   if @target_path NOT LIKE '%|%' and NOT EXISTS(SELECT TargePath FROM #Control_Add_row WHERE TargePath = @target_path)
	   begin
	   PRINT @app_person_id
			
			SELECT @target_path_person = TargetPath, @app_party_person_id = PartyID FROM [KYPPORTAL].[PortalKYP].pPDM_Person WHERE PersonID = @app_person_id
			if @target_path_person LIKE '%|%'
			begin
			
				SELECT @acc_person_id = substring(@target_path_person, patindex('%[0-9]%', @target_path_person), 1+patindex('%[0-9][^0-9]%', @target_path_person+'x')-patindex('%[0-9]%', @target_path_person))
				
				EXEC [KYPEnrollment].[sp_Copy_OtherName]  @app_other_person_id,@last_action_user_id,@acc_person_id;
			
				--INSERT INTO #Control_Add_row(FiledID,NameTable)
				INSERT INTO #Control_Add_row(TargePath)
				--VALUES(@target_path,'pAccount_PDM_Party');
				VALUES(@target_path);
				--END
			end
	   end
----------
  END
----------

IF @action_taken='Updated' AND (@acc_table_name in ('pAccount_PDM_Person_OtherName'))
		BEGIN
			PRINT @action_taken

			EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;

		END

IF NOT EXISTS (SELECT TargePath FROM #Control_Add_row WHERE TargePath = @target_path)
		BEGIN
  			IF @action_taken='Deleted' AND (@acc_table_name in ('pAccount_PDM_Person_OtherName'))
			BEGIN
				PRINT @action_taken
				SET @delete = 'UPDATE [KYPEnrollment].[' + @acc_table_name + '] SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + '=' +  CONVERT(VARCHAR(100),@acc_PK_value);
				EXECUTE (@delete);
				INSERT INTO #Control_Add_row(TargePath) VALUES(@target_path);
			END
		END

END
GO

