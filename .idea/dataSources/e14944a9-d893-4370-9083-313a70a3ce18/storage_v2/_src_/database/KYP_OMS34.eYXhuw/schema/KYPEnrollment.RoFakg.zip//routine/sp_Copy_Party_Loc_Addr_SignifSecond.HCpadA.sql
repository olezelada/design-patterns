
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_SignifSecond]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   --@type VARCHAR (50),
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_adr           INT,
      @new_party_adr       INT,
      @count_association   INT,
      @main_party_id       INT,
      @is_prepopulated     BIT,
      @target_path         VARCHAR (200),
      @full_name_person    VARCHAR (100),
      @type                VARCHAR (50),
      @org_id              INT,
      @legal_name          VARCHAR (100),
      @person_id           INT;
   PRINT '[sp_Copy_Party_Loc_Addr_Signif Second]';

   --new account
   IF @app_party_row_id IS NULL
      BEGIN
         DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200),
                           Type             VARCHAR (50)
                        )

         -- declare  @signif table (pk int identity(1,1),PartyID_Portal int, Type_sub varchar(50),PartyID_Enroll int)

         INSERT INTO @party
            SELECT p.PartyID,
                   p.IsPrepopulated,
                   p.TargetPath,
                   p.type
              FROM Kypportal.PortalKYP.pPDM_Party p
             WHERE     ParentPartyID = @party_id
                   AND p.type = 'WhollyOwnedSupplied'

         DECLARE
            @cont   INT,
            @tot    INT
         SELECT @tot = MAX (pk) FROM @party
         SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
            SELECT @party_adr = PartyID,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath,
                   @type = type
            FROM @party
            WHERE pk = @cont

            IF (@type = 'WhollyOwnedSupplied')                  --Second radio
               BEGIN
                  --BEGIN
                  EXEC @new_party_adr =
                          [KYPEnrollment].[sp_Copy_Party] @party_adr,
                                                          @new_party_id,
                                                          @account_id,
                                                          @last_action_user_id;
                  EXEC
                      @org_id =
                         [KYPEnrollment].[sp_Copy_Organization] @new_party_adr,
                                                                @party_adr,
                                                                @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
                                                         @party_adr,
                                                         NULL,
                                                         @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr,
                                                                     @new_party_adr,
                                                                     @last_action_user_id;

                  --mvc--

                  IF (@type = 'WhollyOwnedSupplied')
                     BEGIN
                        EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_adr,
                                                                  @party_adr,
                                                                  @last_action_user_id,
                                                                  NULL,
                                                                  NULL;
                     END


                  IF (@type = 'WhollyOwnedSupplied' AND @is_group = 1)
                     BEGIN
                        IF (@is_prepopulated IS NULL OR @is_prepopulated = 0)
                           BEGIN
                              SELECT @legal_name = LegalName
                              FROM KYPEnrollment.pAccount_PDM_Organization
                              WHERE OrgID = @org_id
                              --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Entity',@legal_name, @new_party_id;
                              EXEC [KYPEnrollment].[Create_Party_Associate] @new_party_adr,
                                                                            @new_party_adr,
                                                                            @account_id,
                                                                            @type,
                                                                            @party_adr;
                           END
                        ELSE
                           BEGIN
                              SELECT TOP 1
                                     @main_party_id = Item
                                FROM [KYPEnrollment].[SplitString] (
                                        @target_path,
                                        '|')
                              ORDER BY item;
                              SELECT TOP 1
                                     @main_party_id = MainPartyID
                              FROM [KYPEnrollment].[pAccount_Party_Associate]
                              WHERE PartyID = @main_party_id;
                              EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                            @new_party_adr,
                                                                            @account_id,
                                                                            @type,
                                                                            @party_adr;
                           END
                     END
               --END

               END

            --**
            SET @cont = @cont + 1
         END
      --end while
      END

   RETURN @new_party_adr
END


GO

