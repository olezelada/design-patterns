


CREATE TRIGGER [KYP].[trgChecklistMilestoneDashboard] ON [KYP].[ADM_Case]
AFTER UPDATE AS

BEGIN
	SET NOCOUNT ON;

	DECLARE @caseID INT
		,@applicationID INT
		,@applnType VARCHAR(50)
		,@IsPPURequired BIT
		,@supUpdateFlag VARCHAR(20)
		,@NewValue VARCHAR(100)
		,@checklistID INT
		,@TemplateID INT = 1
		,@number VARCHAR(15)
		,@resolutionStatus VARCHAR(150)
		,@WFStatus VARCHAR(100)
		,@WFMajorStep VARCHAR(100)
		,@taskID INT
		,@UserID VARCHAR(50)
		,@MajorDisposition VARCHAR(50)
		,@DateInitiated SMALLDATETIME
		,@CurrentlyAssignedToID VARCHAR(50)
		,@Name VARCHAR(50)
		,@NoofDays INT
		,@Rangename VARCHAR(20)
		,@CaseType VARCHAR(50)
		,@StatusCode INT
		,@Priority INT
		,@DaysCurrentStatus INT
		,@DateResolved SMALLDATETIME
		,@StatusCodeNumber INT
		,@ActivityStatus VARCHAR(25)
		,@ID INT
		,@Q1 INT
		,@YY INT
		,@YY1 INT
		,@Type INT
		,@MinorDisposition VARCHAR(50)
		,@UserFullName VARCHAR(100)
		,@isPPU BIT
		,@checkCond1 BIT = 0
		,@checkCond2 BIT = 0
		,@MILESTONE varchar(100)
		,@DAYSREMAINING INT
		
		,@isExist INT
		,@GroupRendering VARCHAR(10)
		,@LinkedApplication INT
		,@LinkedAccount INT; 	


	SELECT @IsPPURequired = IsPPURequired
		,@NewValue = MILESTONE
		,@applnType = ApplnType
		,@supUpdateFlag = SupUpdateFlag
		,@caseID = [CaseID]
		,@WFStatus = WFStatus
		,@WFMajorStep = WFMajorStep
		,@number = Number
		,@resolutionStatus = ResolutionStatus
		,@UserID = CurrentlyAssignedToID
		,@MajorDisposition = CurrentMajorDisposition
		,@DateInitiated = DateInitiated
		,@MinorDisposition = CurrentMinorDisposition
		,@Type = Type
		,@CaseType = ApplnTypeAlias
		,@StatuscodeNumber = StatusCodeNumber
		,@Priority = Priority
		,@DateResolved = DateResolved
		,@ActivityStatus = ActivityStatus
		,@isPPU = IsPPURequired
		,@wfstatus = WFStatus
		,@supUpdateFlag = SupUpdateFlag
		,@DAYSREMAINING = DAYS_REMAINING
	FROM inserted
	
	IF (
			@applnType = 'Rendering-S'
			OR (
				@applnType = 'Supplemental'
				AND (@supUpdateFlag = 'MR' OR @supUpdateFlag = '5B')
				)
			)
	BEGIN
		SET @TemplateID = 2
	END
	ELSE IF (
			@applnType = 'Supplemental'
			AND (@supUpdateFlag = 'SR' OR @supUpdateFlag = '5C')
			)
	BEGIN
		SET @TemplateID = 3
	END
	ELSE IF (
			@applnType = 'Supplemental'
			AND (@supUpdateFlag = 'NR' OR @supUpdateFlag = '5A')
			)
	BEGIN
		SET @TemplateID = 4
	END
	ELSE IF (
			@applnType = 'Disenrollment'
			OR @applnType = 'Disaffiliation'
			)
			
	BEGIN
		SET @TemplateID = 5
	END

	-------------------------  DashboardTable_Insert ------------------------------
	SELECT @CurrentlyAssignedToID = UserID
		,@UserFullName = FullName
	FROM KYP.OIS_User WITH (NOLOCK)
	WHERE PersonID = @UserID
	
	print @CurrentlyAssignedToID

	SET @Q1 = Datepart(qq, @DateInitiated)
	SET @YY = Datepart(yyyy, @DateInitiated)
	SET @YY1 = Right(Datepart(yy, @DateInitiated), 2)
	SET @NoofDays = Datediff(d, @DateInitiated, getdate());
	SET @DaysCurrentStatus = Datediff(d, @DateResolved, getdate());

	IF (
			@NoofDays >= 0
			AND @NoofDays <= 3
			)
	BEGIN
		SET @Rangename = '0-3 days';
	END
	ELSE IF (
			@NoofDays > 3
			AND @NoofDays <= 10
			)
	BEGIN
		SET @Rangename = '4-10 days';
	END
	ELSE IF (
			@NoofDays > 10
			AND @NoofDays <= 15
			)
	BEGIN
		SET @Rangename = '11-15 days';
	END
	ELSE IF (@NoofDays > 15)
	BEGIN
		SET @Rangename = '15+ days';
	END

	IF @MinorDisposition <> 'Unassigned'
	BEGIN
		SET @checkCond1 = 1
	END

	IF @wfstatus = 'Completed'
		OR @WFMajorStep = 'Completed'
	BEGIN
		SET @checkCond2 = 1
	END

	IF (
			@checkCond1 = 1
			AND @checkCond2 = 1
			)
	BEGIN
		UPDATE KYP.ADM_Case
		SET UserFullName = @UserFullName
			,DateResolved = GETDATE()
			,caseAge = ABS(@NoofDays)
			,CurrentlyAssignedToName = @CurrentlyAssignedToID
		WHERE CaseID = @caseID
		
		print @CurrentlyAssignedToID
	END
	ELSE IF (@checkCond1 = 1)
	BEGIN
		UPDATE KYP.ADM_Case
		SET UserFullName = @UserFullName
			,caseAge = ABS(@NoofDays)
			,CurrentlyAssignedToName = @CurrentlyAssignedToID
		WHERE CaseID = @caseID
	END
	ELSE IF (@checkCond2 = 1)
	BEGIN
		UPDATE KYP.ADM_Case
		SET DateResolved = GETDATE()
			,caseAge = ABS(@NoofDays)
		,CurrentlyAssignedToName = @CurrentlyAssignedToID
		WHERE CaseID = @caseID
	END
	ELSE
	BEGIN
		UPDATE KYP.ADM_Case
		SET caseAge = ABS(@NoofDays)
			,CurrentlyAssignedToName = @CurrentlyAssignedToID
		WHERE CaseID = @caseID
	END

	UPDATE KYP.DSH_DashBoardTable
	SET CurrentlyAssignedToID = @CurrentlyAssignedToID
		,CurrentMajorDisposition = @MajorDisposition
		,AgeByDays = @NoofDays
		,Statuscode = CASE 
			WHEN @StatuscodeNumber IN (
					10
					,11
					,13
					)
				THEN 1
			ELSE 2
			END
		,Range = @Rangename
		,Priority = @Priority
		,DaysCurrentStatus = @DaysCurrentStatus
		,Quarter = @Q1
		,Year = @YY
		,LasttwoDigYear = @YY1
		,CaseType = @CaseType
		,CurrentMinorDisposition = @MinorDisposition
		,IsPPURequired = @isPPU
		,isCompleted = CASE 
			WHEN @WFMajorStep = 'Completed'
				THEN 1
			ELSE 0
			END
	WHERE CaseID = @caseID
	
	-- Added the below IF statement for KEN-19589 by Lokesh on 5-Feb-2019 for KEN-19589
	IF Exists(Select VersionID From kyp.ois_app_version Where StateCode='CA')
	Begin
		IF Exists(Select CaseID from kyp.adm_case
					where CaseID = @caseID
						and wfminorstep='Unassigned'
						and MILESTONE='Automated Screening Completed'
						and AssignedFromID = 1
						and statuscodenumber=8) OR @supUpdateFlag = '5A'
		Begin

			SELECT @isExist = COUNT(1)
			FROM KYP.OIS_EntityCount
			WHERE CaseID = @caseID OPTION (MAXDOP 1)

			IF (@isExist = 0)
			BEGIN
				INSERT INTO KYP.OIS_EntityCount(CaseID, 
												Notes, 
												Attachments, 
												Findings, 
												LinkedAccounts, 
												LinkedApplications, 
												CurrentMilestoneStep, 
												TotalMilestoneStep)
				VALUES (
					@caseID
					,0
					,0
					,0
					,0
					,0
					,0
					,0
					) OPTION (MAXDOP 1)
			END

			SELECT @GroupRendering = group_providerNumber
			FROM KYPPORTAL.PortalKYP.pRenderingAffiliation
			WHERE group_providerNumber = @Number
				OR rendering_providerNumber = @Number

			SELECT @LinkedApplication = COUNT(1)-1
			FROM KYP.ADM_Case
			WHERE Number IN (
					SELECT rendering_providerNumber
					FROM KYPPORTAL.PortalKYP.pRenderingAffiliation
					WHERE group_providerNumber = @GroupRendering
					)
				OR Number = @GroupRendering

			SELECT @LinkedAccount = COUNT(1)
			FROM KYP.ADM_Case
			WHERE Caseid = @CaseID
				AND (
					Group_AccountNumber != 'P_Group_AccountNo'
					AND Group_AccountNumber IS NOT NULL
					)

			UPDATE KYP.OIS_EntityCount
			SET LinkedApplications = @LinkedApplication
			WHERE CaseID IN (
					SELECT CaseID
					FROM kyp.ADM_Case with (nolock)
					WHERE Number IN (
							SELECT rendering_providerNumber
							FROM KYPPORTAL.PortalKYP.pRenderingAffiliation
							WHERE group_providerNumber = @GroupRendering
							) 
					union		
					SELECT CaseID
					FROM kyp.ADM_Case with (nolock)
					WHERE Number=@GroupRendering				
						--OR Number = @GroupRendering
					) OPTION (MAXDOP 1)

			UPDATE KYP.OIS_EntityCount
			SET LinkedAccounts = @LinkedAccount
			WHERE CaseID = @CaseID	
		End
	End
	
	-- MD-1180
	IF EXISTS(select * from KYP.OIS_App_Version where StateCode = 'MD')
	BEGIN
		DECLARE @BaseLine INT;
		DECLARE @Now Date;
		DECLARE @TotalDays INT;
		DECLARE @HolidayID INT;
		DECLARE @NextDay Date;
			
		-------------------------  Set DueDate for Reverted Application ------------------------------
		IF(@MinorDisposition = 'Revert' AND @DAYSREMAINING = 2)
		BEGIN
		PRINT @MinorDisposition;
			SET @BaseLine = 2;
			SET @Now = GETDATE();
			SET @TotalDays = 0;
			SET @HolidayID = NULL;
			
			
			WHILE (@TotalDays <= @BaseLine)
			BEGIN
				SET @NextDay = DATEADD(day, 1, @Now);
				SET @HolidayID = (SELECT HolidayID FROM KYP.StateHoliday WHERE CAST(HolidayDate AS DATE) = CAST(@NextDay AS DATE));
				IF(((SELECT DATEPART(DW, @NextDay)) = 1 OR (SELECT DATEPART(DW, @NextDay)) = 7) OR @HolidayID <> '')
				BEGIN
					SET @Now = @NextDay;
					CONTINUE;
				END
				SET @Now = @NextDay;
				SET @TotalDays = @TotalDays + 1;
			END
			UPDATE KYP.ADM_Case SET DueDate = @Now WHERE CaseID = @caseID;
			UPDATE KYP.ADM_CaseExtended SET CaseAgeDaysRemaining = 3 WHERE CaseID = @caseID;
		END
		
		-------------------------  Set DueDate for RTP  ------------------------------
		IF(@DAYSREMAINING = 60)
		BEGIN		
			SET @BaseLine = 60;
			SET @Now = GETDATE();
			SET @TotalDays = 0;
			SET @HolidayID = NULL;
			
			WHILE (@TotalDays <= @BaseLine)
			BEGIN
				SET @NextDay = DATEADD(day, 1, @Now);
				SET @HolidayID = (SELECT HolidayID FROM KYP.StateHoliday WHERE CAST(HolidayDate AS DATE) = CAST(@NextDay AS DATE));
				IF(((SELECT DATEPART(DW, @NextDay)) = 1 OR (SELECT DATEPART(DW, @NextDay)) = 7) OR @HolidayID <> '')
				BEGIN
					SET @Now = @NextDay;
					CONTINUE;
				END
				SET @Now = @NextDay;
				SET @TotalDays = @TotalDays + 1;
			END
			UPDATE KYP.ADM_Case SET DueDate = @Now WHERE CaseID = @caseID;
			UPDATE KYP.ADM_CaseExtended SET CaseAgeDaysRemaining = 61 WHERE CaseID = @caseID;
		END
		
		-------------------------  Set DueDate for Re-Submit  ------------------------------
		IF(@MajorDisposition = 'Re-SubmitByProvider')
		BEGIN
			SET @BaseLine = 2;
			SET @Now = GETDATE();
			SET @TotalDays = 0;
			SET @HolidayID = NULL;
			WHILE (@TotalDays <= @BaseLine)
			BEGIN
				SET @NextDay = DATEADD(day, 1, @Now);
				SET @HolidayID = (SELECT HolidayID FROM KYP.StateHoliday WHERE CAST(HolidayDate AS DATE) = CAST(@NextDay AS DATE));
				IF(((SELECT DATEPART(DW, @NextDay)) = 1 OR (SELECT DATEPART(DW, @NextDay)) = 7) OR @HolidayID <> '')
				BEGIN
					SET @Now = @NextDay;
					CONTINUE;
				END
				SET @Now = @NextDay;
				SET @TotalDays = @TotalDays + 1;
			END
			UPDATE KYP.ADM_Case SET DueDate = @Now, IsMsgSent = 0, THRESHOLD = 'Normal', DAYS_REMAINING = 2 WHERE CaseID = @caseID;
			UPDATE KYP.ADM_CaseExtended SET CaseAgeDaysRemaining = 3 WHERE CaseID = @caseID;
		END
	END

	--Added by Sundar for Elk implementation on 25 Feb 2019
	IF Exists(Select VersionID from kyp.OIS_App_Version where StateCode='CA')
	Begin
		Update kyp.ADM_Case Set LastActionDate = Getdate()
		Where CaseID IN (Select CaseID from inserted);

		--Added Modified Date for Elk Implementation on 27-Feb-2019
		Update kypenrollment.ApplicationHistory
		Set ModifiedDate = GETDATE()
		Where ApplicationNumber = @number;
	End	

END


GO

