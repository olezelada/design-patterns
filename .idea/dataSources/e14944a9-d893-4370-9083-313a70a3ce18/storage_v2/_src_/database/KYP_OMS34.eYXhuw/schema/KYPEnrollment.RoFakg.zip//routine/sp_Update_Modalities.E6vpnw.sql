
/* ==========================================================
-- Author:		<Lacunza,Giresse>
-- PROCEDURE: Update Profecional Licenses (table Number) by Traking.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Modalities]
	
	@acc_party_id INT,
	@action_taken VARCHAR(50),
	@last_action_user_id VARCHAR(100),
	@target_path VARCHAR(200),
	@en_db_column VARCHAR(100), 
	@data VARCHAR(MAX), 
	@acc_PK VARCHAR(100), 
	@acc_PK_value INT,
	@is_text_date CHAR(1),
	@acc_table_name varchar (100)
AS
BEGIN
	
	DECLARE @acc_mod_party INT,@mod_id int,@application_no VARCHAR(15),@provider_type_code varchar(20),@app_mod_party int,
	@app_party int,@accid int,@max_case int,@applicationtype varchar(20),@case_id int
	
	IF @action_taken='Added'
	BEGIN
		
		SELECT @mod_id = ModalityId, @app_mod_party = m.PartyId ,@app_party = p.ParentPartyID
    	FROM [KYPPORTAL].[PortalKYP].[pPDM_Modalities] m inner join [KYPPORTAL].[PortalKYP].pPDM_Party p ON m.PartyId=p.PartyID
		WHERE m.TargetPath=@target_path and m.Approved=1 and p.IsDeleted=0
		

		
		if @target_path NOT LIKE '%|%' and NOT EXISTS(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_mod_party AND NameTable='pAccount_PDM_Modalities')
		begin
			PRINT @action_taken 
			
			IF 	exists (select AccountID from KYPEnrollment.pADM_Account where AccountID=@accid and ProviderTypeCode='076' and exists (select ModalityId from KYPPORTAL.PortalKYP.pPDM_Modalities m where m.ModlityCode<>'HDP' and ModalityId=@mod_id))
			OR exists (select AccountID from KYPEnrollment.pADM_Account where AccountID=@accid and ProviderTypeCode='051' and exists (select ModalityId from KYPPORTAL.PortalKYP.pPDM_Modalities m where m.ModlityCode='HDP' and ModalityId=@mod_id))			 
			begin 

			 
			 select @accid=AccountID from KYPEnrollment.pADM_Account where PartyID=@acc_party_id and IsDeleted=0
			 
			 
			 
			 EXEC @acc_mod_party = [KYPEnrollment].[sp_Copy_Party] @app_mod_party,	@acc_party_id,	@accid,	@last_action_user_id
			
				
			
						
              INSERT INTO KYPEnrollment.pAccount_PDM_Modalities (

              ModlityCode,
              ModalityDocNumber,
              DocInstanceId,
              LicenseNumber,
              Explanation,
              ReqTreatmentComp,
              PartyId,
              Deleted,
              LastAction,
              LastActionDate,
              LastActionUserID,
              LastActionReason,
              LastActionComments,
              LastActionApprovedByUsedID,
              CurrentRecordFlag,
              EffectiveDate,
              IsMedicationUnit
            )
              SELECT

                ModlityCode,
                ModalityDocNumber,
                DocInstanceId,
                LicenseNumber,
                Explanation,
                ReqTreatmentComp,
                @acc_mod_party,
                0,
                'C',
                GETDATE(),
                @last_action_user_id,
                @action_taken,
                @action_taken,
                @last_action_user_id,
                1,
                EffectiveDate,
                IsMedicationUnit

              FROM KYPPORTAL.PortalKYP.pPDM_Modalities
              WHERE Approved = 1 AND ModalityId = @mod_id;

			
		INSERT INTO #Control_Add_row(FiledID,NameTable)
		VALUES(@app_mod_party,'pAccount_PDM_Modalities'); 
			
	        end		
		end
		
		ELSE
		begin
		
			PRINT @action_taken 
			
		
			EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name, @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,NULL,@last_action_user_id,@action_taken;
		
		end
	
	END
	  
	IF @action_taken='Updated'
	
		
		BEGIN
			PRINT @action_taken
			EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name, @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,NULL,@last_action_user_id,@action_taken;
		END
	
	IF @action_taken='Deleted' 
	BEGIN
		PRINT @action_taken
		IF (@target_path like '%pAccount_PDM_Modalities%' or @acc_table_name = 'pAccount_PDM_Modalities')
		BEGIN
			UPDATE [KYPEnrollment].[pAccount_PDM_Modalities] SET CurrentRecordFlag = 0, Deleted=1 WHERE ModalityId = @acc_PK_value;	
		END

		IF (@target_path like '%pAccount_PDM_Party%' or @acc_table_name = 'pAccount_PDM_Party')
		BEGIN
			UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET CurrentRecordFlag = 0,IsDeleted=1 WHERE PartyID = @acc_PK_value;	
		END
	
	END
	
END


GO

