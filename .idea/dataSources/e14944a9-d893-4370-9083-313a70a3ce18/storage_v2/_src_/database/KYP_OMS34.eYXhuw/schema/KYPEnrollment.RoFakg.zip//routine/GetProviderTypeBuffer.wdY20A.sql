-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <18/10/2017>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[GetProviderTypeBuffer]

		@applicationNo VARCHAR(50),
		@caseId INT

AS
BEGIN

		DECLARE @appProviderType VARCHAR(50), @packagename VARCHAR(50),@appType varchar(50), @isFBP BIT


		SET NOCOUNT ON;

		SELECT
			@packagename = PackagesName,
			@appProviderType = ProviderTypeCode,
			@isFBP = FBPApp
		FROM KYPPORTAL.PortalKYP.pADM_Application
		WHERE IsDeleted = 0 AND ApplicationNo = @applicationNo


		IF (@packagename IN ('FSP_DMC_IN', 'FSP_DMC_SP'))
			BEGIN
				EXEC KYPEnrollment.DMCPackageBufferProvider @applicationNo, @caseId
			END


		IF (@packagename IN ('FSP_MDT_IN', 'FSP_MDT_SP'))
			BEGIN
				EXEC KYPEnrollment.MDTPackageBufferProvider @applicationNo, @caseId
			END

		IF (@packagename IN ('F_OOS_OE'))
		BEGIN
			EXEC [KYPEnrollment].[F_OOS_OE_PackageBufferProvider] @applicationNo,@caseId
		END

		IF (@packagename IN ('ISP_FSP_COP_AP', 'IGSP_FSP_COP_AP') AND @appProviderType = '015')
		BEGIN
			EXEC [KYPEnrollment].[OutOfStateCrossoverPackageBufferProvider] @applicationNo,@caseId
		END

		IF (@packagename IN ('F_THS_OE', 'F_THS_SP') AND @appProviderType  = '075')
		BEGIN
			EXEC [KYPEnrollment].[NewDPP_Tribal_Package_Buffer_Provider] @applicationNo,@caseId
		END

		IF (@isFBP = 1 )
		BEGIN
			EXEC [KYPEnrollment].[FBPpackageBufferAddress] @applicationNo,@caseId
		END	



		IF NOT EXISTS(SELECT *
									FROM #tempProviderType
									WHERE appName = @applicationNo)
			BEGIN
				INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber)
					SELECT
						@appProviderType,
						@applicationNo,
            CONVERT(VARCHAR(20), CONVERT(INT, 100000000+@caseId))
			END
			
			
			


END
GO

