CREATE FUNCTION [KYP].[RiskScore] (@Score integer)
returns varchar(10)
as
begin
     
	 DECLARE @res varchar(10);
     
    if(@Score >= 0 and @Score < 30)
     begin
          Set @res = '0-30';
     end
     else if(@Score > 30 and @Score <=60 )
     begin
          Set @res = '30-60';
     end
     else if(@Score > 61 and @Score <= 90)
     begin
          Set @res = '60-90';
     end
     else if (@Score > 90)
     begin
          Set @res = '>90';
     end
     return @res
end


GO

