
--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket				Description
--------------------------------------------------------------------------------------------------------
-- 1		05-Jan-2017		Sundar		CAPAVE-998				Fix for Alert Gen. Issue
-- 2		11-Apr-2017		Sundar		PI-749					Commented the Delete state. (alerts whose Providers are not changed in current month), Added a Delete Statem. to delete the Child Alerts
-- 3		23-May-2017		Sundar		CAPAVE-337				Added TIN and SSN for both Individual and Organizational providers
-- 4		08-jan-2019	    Mvillarroel DBAB-990				Commented the sentence disable/enabled trigger 	trg_MDM_AlertOnUpdate for prevent the deadlocks
CREATE PROCEDURE [dbo].[p_LoadSearchProviders]
AS
BEGIN

--ALTER TABLE KYP.MDM_Alert DISABLE TRIGGER trg_MDM_AlertOnUpdate

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_GeneratedAlerts')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_GeneratedAlerts
	END

	CREATE TABLE tmp_GeneratedAlerts (
		WatchedPartyID INT, 
		WatchedPartyName VARCHAR(300),
		Relevance int,
		AlertID INT
	)
	
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_AutoProviders')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_AutoProviders
	END

	CREATE TABLE tmp_AutoProviders (
		WatchedPartyID INT, 
		WatchedPartyName VARCHAR(300),
		AlertID INT,
		HMSID VARCHAR(15),
		ProvID INT,
		ProvNumber  VARCHAR(20),--(15), --#1
		EnrolledSince DATETIME,
		Category VARCHAR(15),
		ProvPartyID INT, 
		Name VARCHAR(300),
		AccGenNumber VARCHAR(50),
		DBAName1 VARCHAR(200),
		LegalName VARCHAR(200),
		FirstName VARCHAR(100),
		LastName VARCHAR(100),
		NPI VARCHAR(10),
		TIN VARCHAR(11),
		SSN VARCHAR(10),
		MatchType VARCHAR(10),
		SearchProviderExist BIT,
		PriorityLevel INT
	)
	
	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndAllParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndAllParties
	END

	CREATE TABLE tmp_IndAllParties (
		PerPartyID INT,
		FirstName VARCHAR(200),
		LastName VARCHAR(200),
		SSN VARCHAR(11),
		NPI VARCHAR(10),
		DEA VARCHAR(11),
		TIN varchar(10) --Added for #3 CAPAVE-337
	)

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_OrgAllParties')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_OrgAllParties
	END

	CREATE TABLE tmp_OrgAllParties (
		OrgPartyID INT,
		LegalName VARCHAR(300),
		TIN VARCHAR(10),
		SSN VARCHAR(11),
		NPI VARCHAR(10),
		DEA VARCHAR(11)
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_AlertGeneratedParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_AlertGeneratedParties
	END

	CREATE TABLE tmp_AlertGeneratedParties (
		PartyID INT,
		FirstName VARCHAR(200),
		LastName VARCHAR(200),
		SSN VARCHAR(11),
		NPI VARCHAR(10),
		DEA VARCHAR(11),
		TIN VARCHAR(10) --Added for #3 CAPAVE-337
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndMatchParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndMatchParties
	END

	CREATE TABLE tmp_IndMatchParties (
		PartyID INT
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndirectIndProviders')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndirectIndProviders
	END

	CREATE TABLE tmp_IndirectIndProviders (
		WatchedPartyID INT, 
		WatchedPartyName VARCHAR(300),
		AlertID INT,
		HMSID VARCHAR(15),
		ProvID INT,
		ProvNumber VARCHAR(20),
		EnrolledSince DATETIME,
		Category VARCHAR(15),
		ProvPartyID INT, 
		Name VARCHAR(300),
		AccGenNumber VARCHAR(50),
		FirstName VARCHAR(200),
		LastName VARCHAR(200),
		DBAName1 VARCHAR(200),
		LegalName VARCHAR(200),
		NPI VARCHAR(10),
		SSN VARCHAR(11),
		TIN VARCHAR(10),
		MatchType VARCHAR(30),
		SearchProviderExist BIT,
		PriorityLevel INT
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_AlertGeneratedOrgParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_AlertGeneratedOrgParties
	END

	CREATE TABLE tmp_AlertGeneratedOrgParties (
		PartyID INT,
		LegalName VARCHAR(300),
		TIN VARCHAR(10),
		SSN VARCHAR(11),
		NPI VARCHAR(10),
		DEA VARCHAR(11)
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_OrgMatchParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_OrgMatchParties
	END

	CREATE TABLE tmp_OrgMatchParties (
		PartyID INT
	)

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndirectOrgProviders')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndirectOrgProviders
	END

	CREATE TABLE tmp_IndirectOrgProviders (
		WatchedPartyID INT, 
		WatchedPartyName VARCHAR(300),
		AlertID INT,
		HMSID VARCHAR(15),
		ProvID INT,
		ProvNumber VARCHAR(20),
		EnrolledSince DATETIME,
		Category VARCHAR(15),
		ProvPartyID INT, 
		Name VARCHAR(300),
		AccGenNumber VARCHAR(50),
		FirstName VARCHAR(200),
		LastName VARCHAR(200),
		DBAName1 VARCHAR(200),
		LegalName VARCHAR(200),
		NPI VARCHAR(10),
		SSN VARCHAR(11),
		TIN VARCHAR(10),
		MatchType VARCHAR(20),
		SearchProviderExist BIT,
		PriorityLevel INT
	)
	
	IF EXISTS (
		SELECT 1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'tmp_ImpactedProvCount')
			AND type IN (N'U')
		)
	BEGIN
		DROP TABLE tmp_ImpactedProvCount
	END

	CREATE TABLE tmp_ImpactedProvCount (
		AlertID INT
		,ProvCount INT
		)

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_RelatedAlerts')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_RelatedAlerts
	END

	CREATE TABLE tmp_RelatedAlerts (
		ParentAlertID INT
		,ChildAlertID INT
		,ProviderCount INT
		)
	
	DECLARE @pmfloaddate DATETIME

	BEGIN TRY
		--BEGIN TRANSACTION SearchImpactedProviders
		
		SELECT TOP 1 @pmfloaddate = fileloaddate
		FROM KYP.MDM_MonthlyActiveProvider
		ORDER BY ID DESC

		INSERT INTO tmp_GeneratedAlerts
		SELECT WatchedPartyID, WatchedPartyName, Relevance,AlertID
		FROM KYP.MDM_Alert
		WHERE IsMerged = 'N'
		AND DateInitiated >= @pmfloaddate
		
		/***********************AUTO PROIVDERS MATCHING START***********************************/
		--- DIRECT ORGANIZATIONAL PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Auto', 0, 1
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = alrt.WatchedPartyID AND prov.Category = 'Institutional'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID

		--- DIRECT INDIVIDUAL PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Auto', 0, 2
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = alrt.WatchedPartyID AND prov.Category = 'Physician'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID

		--- DIRECT OWNER INDIVIDUAL PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Auto', 0, 3
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Owner own ON own.PartyID = alrt.WatchedPartyID
		INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID

		--- DIRECT OWNER ORGANIZATION PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Auto', 0, 4
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Owner own ON own.PartyID = alrt.WatchedPartyID
		INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID

		-- DIRECT EMPLOYEE INDIVIDUAL PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Auto', 0, 5
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = alrt.WatchedPartyID
		INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID

		-- DIRECT EMPLOYEE ORGANIZATIONAL PROVIDERS
		INSERT INTO tmp_AutoProviders (WatchedPartyID, WatchedPartyName, AlertID, ProvID, ProvNumber, EnrolledSince, 
										Category, ProvPartyID, Name, AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
		SELECT alrt.WatchedPartyID, alrt.WatchedPartyName, alrt.AlertID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince
			,prov.Category, prov.PartyID, par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Auto', 0, 6
		FROM tmp_GeneratedAlerts alrt
		INNER JOIN KYP.MDM_AlertDetail alrtdet ON alrt.AlertID = alrtdet.AlertID
		INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = alrt.WatchedPartyID
		INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
		INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
		INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID

		DELETE x
		FROM (
			SELECT *
				,ROW_NUMBER() OVER (
					PARTITION BY ProvPartyID
					,ProvNumber
					,AlertID
					,ProvID ORDER BY PriorityLevel ASC
					) AS row1
			FROM tmp_AutoProviders
			WHERE AlertID IS NOT NULL
		) x
		WHERE x.row1 > 1
		
		
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_AutoProviders x
		INNER JOIN KYP.MDM_HMSOrgNPI y ON x.NPI = y.NPI--x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_AutoProviders x
		INNER JOIN KYP.MDM_HMSOrgTaxID y ON x.TIN = y.TaxID--x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.TaxID IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				--AND (x.TIN = y.TaxID)
				)

		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_AutoProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.NPI = y.NPI --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = Y.FirstName)
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_AutoProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.SSN = y.SSN --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = Y.FirstName)
				--AND (x.SSN = y.SSN)
				)

		UPDATE x
		SET x.SearchProviderExist = 1
		FROM tmp_AutoProviders x
		INNER JOIN KYP.MDM_SearchProviders srcprov ON srcprov.AlertID = x.AlertID AND srcprov.ProviderID = x.ProvID AND srcprov.SearchPartyID = x.WatchedPartyID

		INSERT INTO KYP.MDM_SearchProviders ([AlertID],[ProviderID],[SearchPartyID],[HMS_ID],[Auto],[Impacted]
						,[ProviderName],[MedicaidID],[ProviderSince],[CreatedDate],[IsDeleted],[MatchType]
						,[AccGenNumber])
		SELECT x.AlertID, x.ProvID, x.WatchedPartyID, x.HMSID, 'Y', 1, x.Name, x.ProvNumber, x.EnrolledSince,
		GETDATE(), 0, x.MatchType, x.AccGenNumber
		FROM tmp_AutoProviders x
		WHERE x.SearchProviderExist = 0
		--SELECT AlertID, ProvNumber, HMSID, ProvID, ProvPartyID, WatchedPartyID FROM tmp_AutoProviders ORDER BY AlertID, ProvNumber
		/***********************AUTO PROIVDERS MATCHING END***********************************/
		
		
		/***********************INDIRECT INDIVIDUAL PROVIDERS MATCHING START***********************************/
		PRINT 'INDIRECT INDIVIDUAL'
		
		/*Populating all the existing individual parties*/	
		INSERT INTO tmp_IndAllParties(PerPartyID,FirstName,LastName,SSN,NPI,DEA,TIN) --Added TIN for #3 CAPAVE-337 
		SELECT A.PartyID, B.FirstName, B.LastName, B.SSN, B.NPI, C.DEA ,B.TaxId --Added TaxId for #3 CAPAVE-337
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
			AND A.IsDeleted <> 1
			AND A.CurrentModule = 2
			AND A.[Type] = 'Person'
		INNER JOIN KYP.PDM_Provider C ON B.PartyID = C.PartyID
	
		/*Populating all the existing organization parties*/	
		INSERT INTO tmp_OrgAllParties 
		SELECT A.PartyID, B.LegalName, B.TIN, B.SSN, B.NPI, C.DEA
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
			AND A.IsDeleted <> 1
			AND A.CurrentModule = 2
			AND A.[Type] = 'Organization'
		INNER JOIN KYP.PDM_Provider C ON B.PartyID = C.PartyID
		
		INSERT INTO tmp_AlertGeneratedParties(PartyID,FirstName,LastName,SSN,NPI,DEA,TIN) --Added TIN for #3 CAPAVE-337
		SELECT a.WatchedPartyID, b.FirstName, b.LastName, b.SSN, b.NPI, c.DEA, b.TIN --Added TIN for #3 CAPAVE-337
		FROM tmp_GeneratedAlerts a
		INNER JOIN tmp_IndAllParties b ON a.WatchedPartyID = b.PerPartyID
		INNER JOIN KYP.PDM_Provider c ON b.PerPartyID = c.PartyID

		DECLARE @FirstPartyID INT
			,@LastPartyID INT
			,@CurrentPartyID INT
			,@SSN VARCHAR(10)
			,@NPI VARCHAR(10)
			,@DEA VARCHAR(20)
			,@AlertID INT
			,@WatchedPartyName VARCHAR(300)
			,@TIN Varchar(10) --Added for #3 CAPAVE-337				

		SELECT @FirstPartyID = MIN(A.PartyID), @LastPartyID = MAX(A.PartyID), @CurrentPartyID = MIN(A.PartyID)
		FROM tmp_AlertGeneratedParties A

		WHILE (@CurrentPartyID <= @LastPartyID)
		BEGIN
			--PRINT @CurrentPartyID
			
			SELECT TOP 1 @AlertID = AlertID, @WatchedPartyName = WatchedPartyName FROM tmp_GeneratedAlerts WHERE WatchedPartyID = @CurrentPartyID
			
			IF (@AlertID IS NOT NULL)
			BEGIN
				SELECT @SSN = SSN, @NPI = NPI, @DEA = DEA 
					, @TIN = TIN --Added TIN for #3 CAPAVE-337
				FROM tmp_AlertGeneratedParties WHERE PartyID = @CurrentPartyID
				
				/************************************************ SAME SSN MATCH START ************************************************/		
				IF (@SSN IS NOT NULL)
				BEGIN
				
					INSERT INTO tmp_IndMatchParties
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.SSN = @SSN AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.SSN IS NOT NULL
					/*Start #3 CAPAVE-337*/
					Union
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.SSN = @SSN AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.SSN IS NOT NULL	
					/*End #3 CAPAVE-337*/					
					
					IF EXISTS (SELECT 1 FROM tmp_IndMatchParties)
					BEGIN
						-----SAME SSN INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME SSN INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME SSN INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME SSN INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME SSN INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						
						
						-----SAME SSN INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 1
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_IndMatchParties
				/************************************************ SAME SSN MATCH END ************************************************/
				
				/*Start #3 CAPAVE-337*/				
				/************************************************ SAME TAXID MATCH START ************************************************/
				IF (@TIN IS NOT NULL)
				BEGIN
					INSERT INTO tmp_IndMatchParties
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.TIN = @TIN AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.TIN IS NOT NULL
					union
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.TIN = @TIN AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.TIN IS NOT NULL					
										
					IF EXISTS (SELECT 1 FROM tmp_IndMatchParties)
					BEGIN
						-----SAME TAXID INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME TAXID INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME TAXID INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME TAXID INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME TAXID INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID				
						
						-----SAME TAXID INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 2
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_IndMatchParties
				/************************************************ SAME TAXID MATCH END ************************************************/
				/*End #3 CAPAVE-337*/
				
				/************************************************ SAME NPI MATCH START ************************************************/
				IF (@NPI IS NOT NULL)
				BEGIN
					INSERT INTO tmp_IndMatchParties
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.NPI = @NPI AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.NPI IS NOT NULL
					
					UNION
					
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.NPI = @NPI AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.NPI IS NOT NULL
					
					IF EXISTS (SELECT 1 FROM tmp_IndMatchParties)
					BEGIN
						-----SAME NPI INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME NPI INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME NPI INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME NPI INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME NPI INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						
						-----SAME NPI INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_IndMatchParties		
				/************************************************ SAME NPI MATCH END ************************************************/
				
				/************************************************ SAME LICENSE MATCH START ************************************************/
				INSERT INTO tmp_IndMatchParties
				SELECT x.PerPartyID FROM tmp_IndAllParties x
				INNER JOIN KYP.PDM_License lic ON x.PerPartyID = lic.PartyID
				WHERE lic.LicenseCode IN (SELECT lic1.LicenseCode FROM tmp_IndAllParties x1
											INNER JOIN KYP.PDM_License lic1 ON x1.PerPartyID = lic1.PartyID
											WHERE x1.PerPartyID = @CurrentPartyID
										)
				AND x.PerPartyID NOT IN (@CurrentPartyID) AND lic.LicenseCode IS NOT NULL
				
				UNION
				
				SELECT x.OrgPartyID FROM tmp_OrgAllParties x
				INNER JOIN KYP.PDM_License lic ON x.OrgPartyID = lic.PartyID
				WHERE lic.LicenseCode IN (SELECT lic1.LicenseCode FROM tmp_IndAllParties x1
											INNER JOIN KYP.PDM_License lic1 ON x1.PerPartyID = lic1.PartyID
											WHERE x1.PerPartyID = @CurrentPartyID
										)
				AND x.OrgPartyID NOT IN (@CurrentPartyID) AND lic.LicenseCode IS NOT NULL
				
				IF EXISTS (SELECT 1 FROM tmp_IndMatchParties)
				BEGIN
					-----SAME License INDIRECT OWNER INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
					
					-----SAME License INDIRECT OWNER ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
					
					---SAME License INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
					
					-----SAME License INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
					
					-----SAME License INDIRECT INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
					
					-----SAME License INDIRECT ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_IndMatchParties parssn
					INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
				END
				TRUNCATE TABLE tmp_IndMatchParties
				/************************************************ SAME LICENSE MATCH END ************************************************/
				
				
				/************************************************ SAME DEA MATCH START ************************************************/
				IF (@DEA IS NOT NULL)
				BEGIN
					INSERT INTO tmp_IndMatchParties
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.DEA = @DEA AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.DEA IS NOT NULL
					
					UNION
					
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.DEA = @DEA AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.DEA IS NOT NULL
					
					IF EXISTS (SELECT 1 FROM tmp_IndMatchParties)
					BEGIN
						-----SAME DEA INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						---SAME DEA INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectIndProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_IndMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
						WHERE prov.DEA IS NOT NULL
					END
				END
				TRUNCATE TABLE tmp_IndMatchParties
				/************************************************ SAME DEA MATCH END ************************************************/
			END
			
			SELECT @CurrentPartyID = MIN(x.PartyID)
			FROM tmp_AlertGeneratedParties x
			WHERE x.PartyID > @CurrentPartyID
		END

		DELETE x
		FROM (
			SELECT *
				,ROW_NUMBER() OVER (
					PARTITION BY ProvPartyID
					,ProvNumber
					,AlertID
					,ProvID ORDER BY PriorityLevel ASC
					) AS row1
			FROM tmp_IndirectIndProviders
			WHERE AlertID IS NOT NULL
		) x
		WHERE x.row1 > 1
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectIndProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.NPI = y.NPI --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = Y.FirstName)
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectIndProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.SSN = y.SSN --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = Y.FirstName)
				--AND (x.SSN = y.SSN)
				)

		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectIndProviders x
		INNER JOIN KYP.MDM_HMSOrgNPI y ON x.NPI = y.NPI --x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectIndProviders x
		INNER JOIN KYP.MDM_HMSOrgTaxID y ON x.TIN = y.TaxID --x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.TaxID IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				AND (x.TIN = y.TaxID)
				)

		UPDATE x
		SET x.SearchProviderExist = 1
		FROM tmp_IndirectIndProviders x
		INNER JOIN KYP.MDM_SearchProviders srcprov ON srcprov.AlertID = x.AlertID AND srcprov.ProviderID = x.ProvID AND srcprov.SearchPartyID = x.WatchedPartyID

		INSERT INTO KYP.MDM_SearchProviders ([AlertID],[ProviderID],[SearchPartyID],[HMS_ID],[Auto],[Impacted]
						,[ProviderName],[MedicaidID],[ProviderSince],[CreatedDate],[IsDeleted],[MatchType]
						,[AccGenNumber])
		SELECT x.AlertID, x.ProvID, x.WatchedPartyID, x.HMSID, 'Y', 1, x.Name, x.ProvNumber, x.EnrolledSince,
		GETDATE(), 1, x.MatchType, x.AccGenNumber
		FROM tmp_IndirectIndProviders x
		WHERE x.SearchProviderExist = 0

		--SELECT * FROM tmp_IndirectIndProviders
		
		/***********************INDIRECT INDIVIDUAL PROVIDERS MATCHING END***********************************/
		
		/***********************INDIRECT ORGANIZATION PROVIDERS MATCHING START***********************************/
		PRINT 'INDIRECT ORGANIZATION'

		INSERT INTO tmp_AlertGeneratedOrgParties
		SELECT a.WatchedPartyID, b.LegalName, b.TIN, b.SSN, b.NPI, c.DEA
		FROM tmp_GeneratedAlerts a
		INNER JOIN tmp_OrgAllParties b ON a.WatchedPartyID = b.OrgPartyID
		INNER JOIN KYP.PDM_Provider c ON b.OrgPartyID = c.PartyID

		--DECLARE @TIN VARCHAR(10) --Commented for #3 CAPAVE-337

		SELECT @FirstPartyID = NULL
			,@LastPartyID = NULL
			,@CurrentPartyID = NULL
			,@SSN = NULL
			,@NPI = NULL
			,@DEA = NULL
			,@AlertID = NULL
			,@TIN = NULL
			,@WatchedPartyName = NULL
			
		SELECT @FirstPartyID = MIN(A.PartyID), @LastPartyID = MAX(A.PartyID), @CurrentPartyID = MIN(A.PartyID)
		FROM tmp_AlertGeneratedOrgParties A

		WHILE (@CurrentPartyID <= @LastPartyID)
		BEGIN
			--PRINT @CurrentPartyID
			
			SELECT TOP 1 @AlertID = AlertID, @WatchedPartyName = WatchedPartyName FROM tmp_GeneratedAlerts WHERE WatchedPartyID = @CurrentPartyID
			
			IF (@AlertID IS NOT NULL)
			BEGIN
				SELECT @TIN = TIN, @NPI = NPI, @DEA = DEA FROM tmp_AlertGeneratedOrgParties WHERE PartyID = @CurrentPartyID
				
				/************************************************ SAME TAXID MATCH START ************************************************/
				IF (@TIN IS NOT NULL)
				BEGIN
					INSERT INTO tmp_OrgMatchParties
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.TIN = @TIN AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.TIN IS NOT NULL
					/*Start #3 CAPAVE-337*/
					union
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.TIN = @TIN AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.TIN IS NOT NULL					
					/*End #3 CAPAVE-337*/					
					
					IF EXISTS (SELECT 1 FROM tmp_OrgMatchParties)
					BEGIN
						-----SAME TAXID INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME TAXID INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME TAXID INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME TAXID INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME TAXID INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID				
						
						-----SAME TAXID INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same TaxID', 0, 1
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_OrgMatchParties
				/************************************************ SAME TAXID MATCH END ************************************************/
				
				/*Start #3 CAPAVE-337*/
				/************************************************ SAME SSN MATCH START ************************************************/		
				IF (@SSN IS NOT NULL)
				BEGIN
				
					INSERT INTO tmp_OrgMatchParties
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.SSN = @SSN AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.SSN IS NOT NULL
					Union
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.SSN = @SSN AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.SSN IS NOT NULL										
					
					IF EXISTS (SELECT 1 FROM tmp_OrgMatchParties)
					BEGIN
						-----SAME SSN INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME SSN INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME SSN INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME SSN INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME SSN INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						
						
						-----SAME SSN INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same SSN', 0, 2
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_OrgMatchParties
				/************************************************ SAME SSN MATCH END ************************************************/
				/*End #3 CAPAVE-337*/					
				
				/************************************************ SAME NPI MATCH START ************************************************/
				IF (@NPI IS NOT NULL)
				BEGIN
					INSERT INTO tmp_OrgMatchParties
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.NPI = @NPI AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.NPI IS NOT NULL
					
					UNION
					
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.NPI = @NPI AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.NPI IS NOT NULL
					
					IF EXISTS (SELECT 1 FROM tmp_OrgMatchParties)
					BEGIN
						-----SAME NPI INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME NPI INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						
						---SAME NPI INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						
						-----SAME NPI INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						
						-----SAME NPI INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						
						-----SAME NPI INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same NPI', 0, 3 --Changed the PriorityLevel from 2 to 3 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
					END
				END
				TRUNCATE TABLE tmp_OrgMatchParties
				
				
				/************************************************ SAME NPI MATCH END ************************************************/
				
				/************************************************ SAME LICENSE MATCH START ************************************************/
				INSERT INTO tmp_OrgMatchParties
				SELECT x.OrgPartyID FROM tmp_OrgAllParties x
				INNER JOIN KYP.PDM_License lic ON x.OrgPartyID = lic.PartyID
				WHERE lic.LicenseCode IN (SELECT lic1.LicenseCode FROM tmp_OrgAllParties x1
											INNER JOIN KYP.PDM_License lic1 ON x1.OrgPartyID = lic1.PartyID
											WHERE x1.OrgPartyID = @CurrentPartyID
										)
				AND x.OrgPartyID NOT IN (@CurrentPartyID)
				
				UNION
				
				SELECT x.PerPartyID FROM tmp_IndAllParties x
				INNER JOIN KYP.PDM_License lic ON x.PerPartyID = lic.PartyID
				WHERE lic.LicenseCode IN (SELECT lic1.LicenseCode FROM tmp_OrgAllParties x1
											INNER JOIN KYP.PDM_License lic1 ON x1.OrgPartyID = lic1.PartyID
											WHERE x1.OrgPartyID = @CurrentPartyID
										)
				AND x.PerPartyID NOT IN (@CurrentPartyID)
				
				IF EXISTS (SELECT 1 FROM tmp_OrgMatchParties)
				BEGIN
					-----SAME License INDIRECT OWNER INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
					
					-----SAME License INDIRECT OWNER ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
					
					---SAME License INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
					
					-----SAME License INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
					INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
					
					-----SAME License INDIRECT INDIVIDUAL PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
					INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
					
					-----SAME License INDIRECT ORGANIZATION PROVIDERS
					INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
													AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
					SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
							,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same License', 0, 4 --Changed the PriorityLevel from 3 to 4 for #3
					FROM tmp_OrgMatchParties parssn
					INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
					INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
					INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
				END
				TRUNCATE TABLE tmp_OrgMatchParties
				/************************************************ SAME LICENSE MATCH END ************************************************/
				
				
				/************************************************ SAME DEA MATCH START ************************************************/
				IF (@DEA IS NOT NULL)
				BEGIN
					INSERT INTO tmp_OrgMatchParties
					SELECT x.OrgPartyID FROM tmp_OrgAllParties x
					WHERE x.DEA = @DEA AND x.OrgPartyID NOT IN (@CurrentPartyID) AND x.DEA IS NOT NULL
					
					UNION
					
					SELECT x.PerPartyID FROM tmp_IndAllParties x
					WHERE x.DEA = @DEA AND x.PerPartyID NOT IN (@CurrentPartyID) AND x.DEA IS NOT NULL
					
					IF EXISTS (SELECT 1 FROM tmp_OrgMatchParties)
					BEGIN
						-----SAME DEA INDIRECT OWNER INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT OWNER ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Owner own ON own.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = own.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						---SAME DEA INDIRECT EMPLOYEE INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Person per ON per.PartyID = par.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT EMPLOYEE ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Employee emp ON emp.PartyID = parssn.PartyID
						INNER JOIN KYP.PDM_Provider prov ON prov.ProvID = emp.ProviderID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Party par ON par.PartyID = prov.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = par.PartyID						
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT INDIVIDUAL PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, FirstName, LastName, NPI, SSN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, per.FirstName, per.LastName, per.NPI, per.SSN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Physician'
						INNER JOIN KYP.PDM_Person per ON per.PartyID = prov.PartyID
						WHERE prov.DEA IS NOT NULL
						
						-----SAME DEA INDIRECT ORGANIZATION PROVIDERS
						INSERT INTO tmp_IndirectOrgProviders (AlertID, WatchedPartyID, ProvID, ProvNumber, EnrolledSince, Category, ProvPartyID, Name, 
														AccGenNumber, DBAName1, LegalName, NPI, TIN, MatchType, SearchProviderExist, PriorityLevel)
						SELECT @AlertID, prov.PartyID, prov.ProvID, prov.ProvNumber, prov.EnrolledSince, prov.Category, prov.PartyID
								,par.Name, prov.AccGenNumber, org.DBAName1, org.LegalName, org.NPI, org.TIN, 'Same DEA', 0, 5 --Changed the PriorityLevel from 4 to 5 for #3
						FROM tmp_OrgMatchParties parssn
						INNER JOIN KYP.PDM_Party par ON par.PartyID = parssn.PartyID AND par.CurrentModule = 2 AND par.IsDeleted <> 1
						INNER JOIN KYP.PDM_Provider prov ON prov.PartyID = par.PartyID AND prov.Category = 'Institutional'
						INNER JOIN KYP.PDM_Organization org ON org.PartyID = prov.PartyID
						WHERE prov.DEA IS NOT NULL
					END
				END
				TRUNCATE TABLE tmp_OrgMatchParties
				
				/************************************************ SAME DEA MATCH END ************************************************/
			END
			
			SELECT @CurrentPartyID = MIN(x.PartyID)
			FROM tmp_AlertGeneratedOrgParties x
			WHERE x.PartyID > @CurrentPartyID
		END

		DELETE x
		FROM (
			SELECT *
				,ROW_NUMBER() OVER (
					PARTITION BY ProvPartyID
					,ProvNumber
					,AlertID
					,ProvID ORDER BY PriorityLevel ASC
					) AS row1
			FROM tmp_IndirectOrgProviders
			WHERE AlertID IS NOT NULL
		) x
		WHERE x.row1 > 1
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectOrgProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.NPI = y.NPI --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = y.FirstName)
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectOrgProviders x
		INNER JOIN KYP.MDM_HMSIndProfData y ON x.SSN = y.SSN --x.FirstName = y.FirstName OR x.LastName = y.LastName
		WHERE x.Category = 'Physician'
			AND x.HMSID IS NULL
			AND x.FirstName IS NOT NULL
			AND x.LastName IS NOT NULL
			AND y.FirstName IS NOT NULL
			AND y.LastName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				(x.LastName = y.LastName OR x.FirstName = y.FirstName)
				--AND (x.SSN = y.SSN)
				)

		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectOrgProviders x
		INNER JOIN KYP.MDM_HMSOrgNPI y ON x.NPI = y.NPI --x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.NPI IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				--AND (x.NPI = y.NPI)
				)
				
		UPDATE x
		SET x.HMSID = y.HMSID
		FROM tmp_IndirectOrgProviders x
		INNER JOIN KYP.MDM_HMSOrgTaxID y ON x.TIN = y.TaxID --x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
		WHERE x.Category = 'Institutional'
			AND x.HMSID IS NULL
			AND x.DBAName1 IS NOT NULL
			AND y.OrgName IS NOT NULL
			AND y.TaxID IS NOT NULL
			AND (
				x.DBAName1 = y.OrgName OR x.LegalName = y.OrgName
				AND (x.TIN = y.TaxID)
				)

		UPDATE x
		SET x.SearchProviderExist = 1
		FROM tmp_IndirectOrgProviders x
		INNER JOIN KYP.MDM_SearchProviders srcprov ON srcprov.AlertID = x.AlertID AND srcprov.ProviderID = x.ProvID AND srcprov.SearchPartyID = x.WatchedPartyID

		INSERT INTO KYP.MDM_SearchProviders ([AlertID],[ProviderID],[SearchPartyID],[HMS_ID],[Auto],[Impacted]
						,[ProviderName],[MedicaidID],[ProviderSince],[CreatedDate],[IsDeleted],[MatchType]
						,[AccGenNumber])
		SELECT x.AlertID, x.ProvID, x.WatchedPartyID, x.HMSID, 'Y', 1, x.Name, x.ProvNumber, x.EnrolledSince,
		GETDATE(), 1, x.MatchType, x.AccGenNumber
		FROM tmp_IndirectOrgProviders x
		WHERE x.SearchProviderExist = 0

		--SELECT * FROM tmp_IndirectOrgProviders
		
		/***********************INDIRECT ORGANIZATION PROVIDERS MATCHING END***********************************/
	
		--Commented the below 2 statements for PI-749 #2		
		--PSM-177 fix start
		--getting newly loaded providers/modified providers from last provider load done 
		/*
		SELECT ProvID
		INTO #currentproviders
		FROM KYP.PDM_Provider
		WHERE DateCreated >= CAST(@pmfloaddate AS DATETIME)
			OR DateModified >= CAST(@pmfloaddate AS DATETIME)

		--deleting the providers which are not in the current load for the new alerts 
		--@FirstAlertID is the first alert in the current alert generation, @LastAlertID = last alertid in the current alert generation
		
		DELETE a
		FROM KYP.MDM_SearchProviders a
		INNER JOIN tmp_GeneratedAlerts c on a.AlertID = c.AlertID
		WHERE providerid NOT IN (
				SELECT ProvID
				FROM #currentproviders
				)

		--PSM-177 fix end 
		*/
		--KYP-18402 fix start - To take only active onwers
		--getting impacted providers from the new alerts which are genrated from owner/employee
		
		SELECT *
		INTO #searchproviders
		FROM kyp.MDM_SearchProviders
		WHERE alertid IN (
				SELECT AlertID
				FROM kyp.MDM_Alert
				WHERE DateInitiated >= @pmfloaddate
					AND WatchedPartyID IN (
						SELECT partyid
						FROM kyp.PDM_Owner
						
						UNION
						
						SELECT partyid
						FROM kyp.PDM_Employee
						)
				)

		--getting the impacted providers which are not updated in the current load from both owner and employee
		SELECT x.*
		INTO #searchproviderstoDel
		FROM #searchproviders x
		INNER JOIN (
			SELECT partyid
				,ProviderID
			FROM kyp.PDM_Owner
			WHERE DateModified < @pmfloaddate
				AND ProviderID IN (
					SELECT providerid
					FROM #searchproviders
					)
			
			UNION
			
			SELECT partyid
				,ProviderID
			FROM kyp.PDM_Employee
			WHERE DateModified < @pmfloaddate
				AND ProviderID IN (
					SELECT providerid
					FROM #searchproviders
					)
			) y ON x.SearchPartyID = y.PartyID
			AND x.ProviderID = y.ProviderID

		--deleting the impacted providers from #searchproviderstoDel list, 
		--for the owner/employee party itself is a parovider party and having modified date more than the cutoffdate
		DELETE x
		FROM #searchproviderstoDel x
		INNER JOIN kyp.PDM_Party y ON x.SearchPartyID = y.PartyID
		INNER JOIN kyp.mdm_Alert A ON x.AlertID = a.AlertID
			AND x.SearchPartyID = a.WatchedPartyID
		INNER JOIN kyp.PDM_Provider P ON a.WatchedPartyID = P.PartyID
		WHERE y.IsProvider = 1

		--deleting the impacted providers from #searchproviderstoDel, which are having modified date more than the cutoff date in owner table
		DELETE x
		FROM #searchproviderstoDel x
		INNER JOIN kyp.PDM_Owner y ON x.SearchPartyID = y.PartyID
			AND x.ProviderID = y.ProviderID
		WHERE y.DateModified >= @pmfloaddate

		--deleting the impacted providers from #searchproviderstoDel, which are having modified date more than the cutoff date in employee table
		DELETE x
		FROM #searchproviderstoDel x
		INNER JOIN kyp.PDM_Employee y ON x.SearchPartyID = y.PartyID
			AND x.ProviderID = y.ProviderID
		WHERE y.DateModified >= @pmfloaddate

		--retaining the impacted provider for the same provider
		DELETE x
		FROM #searchproviderstoDel x
		INNER JOIN kyp.PDM_Party y ON x.SearchPartyID = y.PartyID
		WHERE y.IsProvider = 1
			AND y.DateModified >= @pmfloaddate

		--updating mdm_alert employee count
		--mvc
		UPDATE x
		SET x.Employees = y.ecount,
		x.Row_Updation_Source='p_LoadSearchProviders'
		FROM kyp.MDM_Alert x
		INNER JOIN (
			SELECT e.partyid
				,COUNT(*) AS ecount
			FROM kyp.PDM_Employee e
			WHERE e.DateModified >= @pmfloaddate
			GROUP BY e.partyid
			) y ON x.WatchedPartyID = y.PartyID
		INNER JOIN #searchproviderstoDel z ON x.AlertID = z.AlertID

		--updating mdm_alert owner count 
		UPDATE x
		SET x.Owners = y.ocount,
		x.Row_Updation_Source='p_LoadSearchProviders'
		FROM kyp.MDM_Alert x
		INNER JOIN (
			SELECT e.partyid
				,COUNT(*) AS ocount
			FROM kyp.PDM_Owner e
			WHERE e.DateModified >= @pmfloaddate
			GROUP BY e.partyid
			) y ON x.WatchedPartyID = y.PartyID
		INNER JOIN #searchproviderstoDel z ON x.AlertID = z.AlertID

		-- Finally deleting the impacted providers from kyp.MDM_SearchProviders table using the searchid from #searchproviderstoDel
		DELETE
		FROM kyp.MDM_SearchProviders
		WHERE SearchID IN (
				SELECT SearchID
				FROM #searchproviderstoDel
				)

		--KYP-18402 fix end
		INSERT INTO KYP.MDM_ImpProviders (
			[Auto]
			,AlertID
			,CreatedBy
			,CreatedDate
			,HMS_ID
			,Impacted
			,IsDeleted
			,MatchType
			,MedicaidID
			,ProviderID
			,ProviderName
			,ProviderSince
			,SearchID
			,SearchPartyID
			,AccGenNumber
			)
		SELECT DISTINCT a.[Auto]
			,a.AlertID
			,1
			,GETDATE()
			,a.HMS_ID
			,a.Impacted
			,a.IsDeleted
			,a.MatchType
			,a.MedicaidID
			,a.ProviderID
			,a.ProviderName
			,a.ProviderSince
			,a.SearchID
			,a.SearchPartyID
			,a.AccGenNumber
		FROM KYP.MDM_SearchProviders a
		INNER JOIN tmp_GeneratedAlerts B ON A.AlertID = B.AlertID
		LEFT JOIN KYP.MDM_ImpProviders c ON a.SearchID = c.SearchID
		WHERE c.SearchID IS NULL

		INSERT INTO tmp_ImpactedProvCount
		SELECT A.AlertID
			,COUNT(A.AlertID) AS 'CNT'
		FROM KYP.MDM_SearchProviders A
		INNER JOIN KYP.MDM_Alert B ON A.AlertID = B.AlertID
		WHERE Impacted = 1 AND IsMerged = 'N' AND B.DateInitiated >= @pmfloaddate AND A.IsDeleted = 0
		GROUP BY A.AlertID
		ORDER BY A.AlertID

		INSERT INTO tmp_RelatedAlerts
		SELECT A.AlertID
			,B.ChildAlertID, 0 AS 'Count'
		FROM KYP.MDM_Alert A
		INNER JOIN KYP.MDM_RelatedAlerts B ON A.AlertID = B.ParentAlertID AND A.DateInitiated >= @pmfloaddate
			AND B.RelationshipType = 'Merged'
		WHERE ISNULL(B.IsDeleted, 1) <> 1
			AND A.IsMerged = 'N'
		ORDER BY A.AlertID

		UPDATE x
		SET x.RelatedProviders = y.ProvCount,
		x.Row_Updation_Source='p_LoadSearchProviders'
		FROM KYP.MDM_Alert x
		INNER JOIN tmp_ImpactedProvCount y ON x.AlertID = y.AlertID

		UPDATE x
		SET x.ProviderCount = y.ProvCount
		FROM tmp_RelatedAlerts x
		INNER JOIN tmp_ImpactedProvCount y ON x.ParentAlertID = y.AlertID

		UPDATE x
		SET x.RelatedProviders = y.ProviderCount,
		x.Row_Updation_Source='p_LoadSearchProviders'
		FROM KYP.MDM_Alert x
		INNER JOIN tmp_RelatedAlerts y ON x.AlertID = y.ChildAlertID
	
		/*#2 PI-749 Start */
		Delete From S	
		from kyp.MDM_SearchProviders S
		Join kyp.MDM_Alert A on S.AlertID = A.AlertID
		Join kyp.MDM_RelatedAlerts RA on S.AlertID=RA.ChildAlertID
		where RA.RelationshipType='Merged'
		and RA.MergedByUserID = 1
		and A.IsMerged = 'y'
		and A.WfStatus <> 'Completed';

		Delete From I
		from kyp.MDM_ImpProviders I
		Join kyp.MDM_Alert A on I.AlertID = A.AlertID
		Join kyp.MDM_RelatedAlerts RA on I.AlertID=RA.ChildAlertID
		where RA.RelationshipType='Merged'
		and RA.MergedByUserID = 1
		and A.IsMerged = 'y'
		and A.WfStatus <> 'Completed';
		/*#2 PI-749 End */
		
		/** Accounty History **/	
		
		/** Accounty History **/

	declare @size int,@AccAlertID int,@AccRevelance int, @AccWatchListName varchar(150)
	SELECT @size = COUNT(AlertID) from tmp_GeneratedAlerts
	
	while(@size != 0)
	begin
		select @AccAlertID = AlertID,@AccRevelance = Relevance,@AccWatchListName = WatchedPartyName from tmp_GeneratedAlerts
		exec(' xp_cmdshell ''C:\upload\AccountHistory\run.bat '+'Monitoring'+' '+@AccAlertID+' '+@AccWatchListName+' '+@AccRevelance+'''');
		delete from tmp_GeneratedAlerts where AlertID = @AccAlertID 
		SELECT @size = COUNT(AlertID) from tmp_GeneratedAlerts
	end

		--COMMIT TRANSACTION SearchImpactedProviders
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
		BEGIN
			--ROLLBACK TRAN SearchImpactedProviders

			INSERT INTO [dbo].[AlertGenerationErrors] (
				[ERNumber]
				,[Error_Severity]
				,[Error_State]
				,[Error_Procedure]
				,[Error_Line]
				,[Error_Message]
				,[Error_Time]
				)
			SELECT B.ERNumber
				,B.Error_Severity
				,B.Error_State
				,B.Error_Procedure
				,B.Error_Line
				,B.Error_Message
				,GETDATE()
			FROM (
				SELECT ERROR_NUMBER() ERNumber
					,ERROR_SEVERITY() Error_Severity
					,ERROR_STATE() Error_State
					,ERROR_PROCEDURE() Error_Procedure
					,ERROR_LINE() Error_Line
					,ERROR_MESSAGE() Error_Message
				) B
		END
	END CATCH
	
	IF EXISTS (
		SELECT 1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'tmp_ImpactedProvCount')
			AND type IN (N'U')
		)
	BEGIN
		DROP TABLE tmp_ImpactedProvCount
	END

	IF EXISTS (
		SELECT 1
		FROM sys.objects
		WHERE object_id = OBJECT_ID(N'tmp_RelatedAlerts')
			AND type IN (N'U')
		)
	BEGIN
		DROP TABLE tmp_RelatedAlerts
	END

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_GeneratedAlerts')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_GeneratedAlerts
	END

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_AutoProviders')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_AutoProviders
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndAllParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndAllParties
	END

	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_OrgAllParties')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_OrgAllParties
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_AlertGeneratedParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_AlertGeneratedParties
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndMatchParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndMatchParties
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndirectIndProviders')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndirectIndProviders
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_AlertGeneratedOrgParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_AlertGeneratedOrgParties
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_OrgMatchParties')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_OrgMatchParties
	END

	IF EXISTS (
				SELECT 1
				FROM sys.objects
				WHERE object_id = OBJECT_ID(N'tmp_IndirectOrgProviders')
					AND type IN (N'U')
				)
	BEGIN
		DROP TABLE tmp_IndirectOrgProviders
	END	
	
	--ALTER TABLE KYP.MDM_Alert enable TRIGGER trg_MDM_AlertOnUpdate
	
	
	
END


GO

