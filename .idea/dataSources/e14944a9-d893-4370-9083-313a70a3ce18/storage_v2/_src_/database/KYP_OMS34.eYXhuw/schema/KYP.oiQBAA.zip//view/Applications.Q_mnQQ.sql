


CREATE VIEW [KYP].[Applications]
AS
SELECT A.Risk as 'Screening Level',
	   A.PAN as 'Application Number',
	   A.ApplnType as 'Application Type',
	   A.ProviderName As 'Provider Name',
	   A.TypeDescription as ' Provider Type', 
	   A.Provider_NPI as 'NPI',
	   A.Provider_TIN as 'Tax ID',
	   A.AccountID as 'Account Number',	   
	   B.NormalizedRisk as 'Normalized Risk',
	   a.WFStatus as 'Application Status'
FROM KYP.ADM_Case AS A INNER JOIN KYP.ADM_Application AS B 
ON A.CaseID = B.CaseID AND A.Number = B.ApplicationNo 
WHERE A.IsPPURequired = 0;


GO

