
-- =============================================
-- Author:		<Lacunza,Giresse>
-- Create date: <2017-05-09>
-- Description:	<Description, This procedure copy Person, Provider, Party, Number and Alias from Portal into Enrollment for Counselor type Partys>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_FC_DMC_SP] (

	@new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT, 
	@last_Action_User_ID VARCHAR(100),
	@application_no VARCHAR(10),
	@application_Id INT,
	@application_type VARCHAR(40),
	@provider_type_code varchar(10)
	)
AS
BEGIN

DECLARE 
	@new_Address_Id INT,
	@new_person_id INT,
	
	@npi_Type VARCHAR(25),
	@npi VARCHAR (10),
	@account_number VARCHAR(20),

	@new_org_id int,
	@package varchar(10),
	@isGroup BIT ;

  select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id

	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,@new_Account_Id,@new_Party_Id,@last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';

	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id

	select @npi = NPI, @package = PackageName from KYPEnrollment.pADM_Account where AccountID=@new_Account_Id

	
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Person] @new_Party_Id,@party_Id,@last_action_user_id,'C';
	EXEC [KYPEnrollment].[sp_Copy_Document]@new_Party_Id,@party_Id,@last_action_user_id;
	
	EXEC [KYPEnrollment].[sp_Copy_AllOtherNames]	@party_Id,@last_Action_User_ID,  @new_Party_Id;
	
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Individual Profile', @last_Action_User_ID;
	 



	EXEC @new_org_id = [KYPEnrollment].[sp_Copy_Business_Profile]@new_Party_Id, @party_Id,@last_Action_User_ID;

    EXEC [KYPEnrollment].[sp_Contact_Person] @party_Id, @new_Party_Id,@last_action_user_id,@new_account_id;

   	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Mailing', @last_Action_User_ID;

  DECLARE @isSchoolSite VARCHAR(10), @isDonatedSpace VARCHAR(10)

  SELECT @isSchoolSite = IsSchoolSide, @isDonatedSpace = IsDonatedSpace FROM KYPEnrollment.pAccount_PDM_Location WHERE AddressID = @new_Address_Id

	IF('No' = @isSchoolSite AND 'No' = @isDonatedSpace)
		BEGIN
			--Insurance
			EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id, @party_Id,@last_action_user_id;
			--Place Of Business
			EXEC [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id;
		END
	ELSE IF('Yes' = @isDonatedSpace)
		BEGIN
			--Insurance
			EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id, @party_Id,@last_action_user_id;
		END


   
    EXEC [KYPEnrollment].[sp_Copy_Modalities] @new_Party_Id,@Party_id,@last_Action_User_ID, @provider_type_code;


    EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_Party_Id, @party_Id,@last_action_user_id,@new_account_id; 
	
    EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id, @party_Id,@last_action_user_id,@new_account_id; 

    EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_Id, @new_Party_Id, @last_action_user_id,NULL;
	
	--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
	IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
	BEGIN
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_Party_Id, null,@application_Id,@party_Id, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
	END

	EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id,@party_Id,@last_Action_User_ID;

	EXEC [KYPEnrollment].[sp_Copy_Affiliarion]@new_Account_Id,@party_Id,@last_Action_User_ID ,'Affiliation',@application_no,@application_Id;
         
    EXEC [KYPEnrollment].[sp_Copy_Counselor_Party] 	@party_Id,@new_Party_Id,@new_Account_Id,@last_action_user_id;

	EXEC [KYPEnrollment].[sp_Copy_Dea] @new_Party_Id, @party_Id, @last_action_user_id, NULL;
	EXEC [KYPEnrollment].[sp_Copy_Clia] @new_Party_Id, @party_Id, @last_action_user_id, NULL;
   
	
	
	SELECT @npi_Type = NPIType, @account_number = AccountNumber, @npi = NPI FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id and IsDeleted=0
	IF @npi_type = 'Organization'
	BEGIN
		SET  @new_person_id = @new_org_id
	END	
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id, @party_Id, 0, @provider_type_code, @account_number, NULL,'F',@application_Id,@isGroup,@application_type;

	
    
END


GO

