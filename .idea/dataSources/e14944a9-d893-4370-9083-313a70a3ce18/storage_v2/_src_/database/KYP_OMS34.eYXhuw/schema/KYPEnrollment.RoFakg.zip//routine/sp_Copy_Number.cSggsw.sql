
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Number.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @app_number_id : this is the DeaID Application that will be Create in Update Account, it is Null when account is create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Number]
	@party_account_id INT,
	@party_app_id INT,
	@last_action_user_id VARCHAR(100),
	@app_number_id INT
AS
BEGIN
	SET NOCOUNT ON 
	DECLARE @date_created DATE;
	SET @date_created =  GETDATE();
	
	IF @party_app_id IS NULL
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
			   ([PartyID]
			   ,[Number]
			   ,[Type]
			   ,[EffectiveDate]
			   ,[ExpirationDate]
			   ,[SecondNumber]
			   ,[SecondEffectiveDate]
			   ,[SecondExpirationDate]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[Name]
			   ,[State]
			   ,[IsPrimary]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag]
			   ,[AppNumberID])
		SELECT @party_account_id
			   ,[Number]
			   ,[Type]
			   ,[EffectiveDate]
			   ,[ExpirationDate]
			   ,[SecondNumber]
			   ,[SecondEffectiveDate]
			   ,[SecondExpirationDate]
			   ,[CreatedBy]
			   ,@date_created
			   ,[IsDeleted]
			   ,[Name]
			   ,[State]
			   ,[IsPrimary]
			   ,'C'
			   ,@date_created
			   ,@last_action_user_id
			   ,@last_action_user_id
			   ,1
			   ,NumberID
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Number] WHERE NumberID=@app_number_id
	END
	ELSE
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
			   ([PartyID]
			   ,[Number]
			   ,[Type]
			   ,[EffectiveDate]
			   ,[ExpirationDate]
			   ,[SecondNumber]
			   ,[SecondEffectiveDate]
			   ,[SecondExpirationDate]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[Name]
			   ,[State]
			   ,[IsPrimary]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag]
			   ,[AppNumberID])
		SELECT @party_account_id
			   ,[Number]
			   ,[Type]
			   ,[EffectiveDate]
			   ,[ExpirationDate]
			   ,[SecondNumber]
			   ,[SecondEffectiveDate]
			   ,[SecondExpirationDate]
			   ,[CreatedBy]
			   ,@date_created
			   ,[IsDeleted]
			   ,[Name]
			   ,[State]
			   ,[IsPrimary]
			   ,'C'
			   ,@date_created
			   ,@last_action_user_id
			   ,@last_action_user_id
			   ,1
			   ,NumberID
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Number] WHERE PartyID=@party_app_id AND IsDeleted = 0
	END

  EXEC KYPEnrollment.sp_Store_Copy_Table_Number_Docs @party_account_id,'pAccount_PDM_Number','NumberID'

END
GO

