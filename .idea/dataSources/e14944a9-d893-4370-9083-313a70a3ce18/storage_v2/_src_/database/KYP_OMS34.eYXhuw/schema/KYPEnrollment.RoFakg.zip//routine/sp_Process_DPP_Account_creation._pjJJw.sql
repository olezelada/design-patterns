

/* ==========================================================
-- Author:  <hbustamante>
-- PROCEDURE: create Account DPP Procedure.
-- PARAMETERS:
   @application_no			: Application Number that will be Account.
   , @last_Action_User_ID	: this is the user Enrollment.
   , @priority              : ADM_Case.Priority to Enrollment data base.
   , @risk                  : ADM_Case.risk to Enrollment data base.
   , @composite_risk        : ADM_Case.CompositeRisk to Enrollment data base.
   , @application_type      : app type for new DPP account from pPortalApplication
    ------------------------------------------
   , @provider_type_code    : 102 for DPP provider type
   , @newPackage			: DPP package for DPP
   , @new_account_number    : New account Number generated previously starts with 1300000...
   , @accountType           : DPP account Type
   , @npiType               : pADM_Application.NpiType in order to determine the npiType for the account DPP
-- ============================================================*/

CREATE PROCEDURE KYPEnrollment.sp_Process_DPP_Account_creation
   @application_no         VARCHAR (15)
   , @last_Action_User_ID    VARCHAR (100)
   , @priority               VARCHAR (3)
   , @risk                   VARCHAR (15)
   , @composite_risk         INT
   --, @application_type       VARCHAR (30) = NULL
    ------------------------------------------
   , @provider_type_code varchar(50)
   --, @newPackage VARCHAR(20)
   , @new_account_number VARCHAR(20)
   --, @accountType VARCHAR(5)
   , @npiType VARCHAR(100)
  ------------------------------------------
AS
BEGIN
   BEGIN TRANSACTION

   DECLARE
      @newPackage VARCHAR(20),
      @accountType VARCHAR(5),
      @application_type VARCHAR (30),
      @npi VARCHAR(10),
      @new_Account_Id     INT,
      @new_Party_Id       INT,
      @party_Id           INT,
      @application_Id     INT,
      @is_group           BIT;

   BEGIN TRY
      SELECT @application_Id = ApplicationID
		        , @party_Id = PartyID
		        , @npi = NPI
      FROM KYPPORTAL.PortalKYP.pADM_Application
      WHERE ApplicationNo = @application_no

    IF NOT EXISTS(SELECT DP.AccountID
                  FROM kyp.ADM_Case AC
                  JOIN kypenrollment.Padm_Account DP ON AC.Provider_NPI = DP.NPI
                  JOIN Kypenrollment.EDM_ApplicationInternalUse S ON AC.Number = S.ApplicationNumber
                                                                              AND DP.OwnerNo = S.BillingFutureStatus
                                                                              AND DP.ServiceLocationNo = S.ProvCrossReferenceCode
                                                                              AND DP.ProviderTypeCode = S.ProviderTypeCode
                  WHERE Ac.Number = @application_no
                  AND DP.ProviderTypeCode = '102'
                  AND DP.IsDeleted = 0)

    BEGIN
        PRINT('creating dpp pt 102 by create account process');
        EXEC [KYPEnrollment].[sp_Create_New_DPP_Account_From_Tribal]
                              @application_no
														 , @last_Action_User_ID
														 , @priority
														 , @risk
							               , @composite_risk
										         , @provider_type_code
											       , @new_account_number
											       , @npiType;
    END

      COMMIT TRANSACTION
   END TRY
   BEGIN CATCH
      IF @@TRANCOUNT > 0
         ROLLBACK TRANSACTION

      DECLARE
         @error_message    NVARCHAR (4000),
         @error_severity   INT;
      SELECT @error_message = ERROR_MESSAGE (),
             @error_severity = ERROR_SEVERITY ();
      RAISERROR (@error_message, @error_severity, 1);
   END CATCH
END

GO

