





Create View [KYP].[Vw_TotalReferredApplication] 
AS 
	SELECT ROW_NUMBER() over(order by ReferralDate) ReferralId, 
		COALESCE(LTRIM(RTRIM(NULLIF(Number,''))),'NA') As Number, 
		COALESCE(LTRIM(RTRIM(NULLIF(ProviderName,''))),'NA') As ProviderName, 
		COALESCE(LTRIM(RTRIM(NULLIF(Provider_NPI,''))),'NA') As Provider_NPI, 
		COALESCE(LTRIM(RTRIM(NULLIF(ApplnTypeAlias,''))),'NA') As ApplnType, 
		COALESCE(LTRIM(RTRIM(NULLIF(TypeDescription,''))),'NA') As TypeDescription, 
		COALESCE(LTRIM(RTRIM(NULLIF(MILESTONE,''))),'NA') As MILESTONE, 
		COALESCE(LTRIM(RTRIM(NULLIF(ASSIGNED_BY_NAME,''))),'NA') As ASSIGNED_BY_NAME, 
		Case When (RevertDate is  null) then COALESCE(LTRIM(RTRIM(NULLIF(CurrentlyAssignedToName,''))),'NA')
			Else 'System(Auto)' End As CurrentlyAssignedToName, 
		ReferralDate,
		COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(RevertDate as date), 101),''))),'NA') As RevertDate, 
		ISNULL(DaysWithReferral,0) AS DaysWithReferral, 
		DaysPostRevert, 
		CaseID, 
		COALESCE(LTRIM(RTRIM(NULLIF(ReferralTeamDesc,''))),'NA') As ReferralTeamDesc
	FROM KYP.ADM_Case 
		WHERE ReferralDate is not NULL


GO

