-- =============================================
-- Author:		Nitish G.
-- Create date: 12-May-2016
-- Description:	Journal Entry Trigger Code 
--				moved to this procedure
-- =============================================
--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No. Date   Author  JIRA    Ticket	   Reviewer  Description										
--------------------------------------------------------------------------------------------------------
--1		27/01/2017	Abhishek	CAPAVE-995	Sundar    inserting the value of @lastnoteid and Notenumber in the error logs table to verify the value
--2		06/04/2017	ABHISHEK	Capave-1002	Anup		Commented the select Statement for @currentWFstatus as it was picking default value from MDM_Alert table
CREATE PROCEDURE [KYP].[p_JournalEntry]
	-- Add the parameters for the stored procedure here
		 @MultipleCaseID VARCHAR(500)
		,@AlertNo VARCHAR(500)
		,@AlertID INT
		,@CurrentWFStatus VARCHAR(50)
		,@JournalEvent VARCHAR(50)
		,@Username VARCHAR(100)
		,@Description VARCHAR(100)
		,@PersonID INT
		,@AssignToUserID INT
		,@NotesDescription VARCHAR(MAX)
		,@NotesTitle VARCHAR(120)
		,@Number VARCHAR(20)
		,@FirstName VARCHAR(100)
		,@LastName VARCHAR(100)
		,@Name VARCHAR(8000)
		,@NoteID INT
		,@CurrentDate DATETIME
		,@Currenttag VARCHAR(5)
		,@Notenumber VARCHAR(15)
		,@Type VARCHAR(100)
		,@SubType VARCHAR(100)
		,@RelatedEntityType VARCHAR(200)
		,@JournalDescription VARCHAR(250)
		,@CaseID INT
		,@NoteEntityType VARCHAR(100)
		,@NoteEntityTypeID VARCHAR(100)
		,@NoteEntityDepID VARCHAR(100)
		,@NoteEntityDep VARCHAR(100)
		,@Level INT
		,@SmartletParameter VARCHAR(500)
		,@IsLastLevel BIT
		,@RelatedEntityID INT
		,@FullName VARCHAR(200)
		,@IsExistID INT
		,@NoteCount INT
		,@IsExistCaseID INT
		,@CaseNoteCNT INT
		,@InfoID INT				
		,@body NVARCHAR(MAX)
		,@EmailAddTo VARCHAR(500)
		,@EmailAddCC VARCHAR(500)
		,@Sub VARCHAR(MAX)
		,@ALIASNAME VARCHAR(100)
		,@MultipleTrackingNo VARCHAR(800)				
		,@DUPLICATEID INT
		,@MEDICAIDRESOLID VARCHAR(MAX)
		,@WATCHRESOLUTIONNAME VARCHAR(225)
		,@WATCHRESOLUTIONPROVIDERMEDICAIDID VARCHAR(225)
		,@WATCHDUMRESOLUTIONID VARCHAR(225)
		,@ResolutionID INT
		,@PersonID_UpdateBy INT
		,@FullName_UpdateBy VARCHAR(200)
		,@ProvID INT
		,@ProvMedicaID VARCHAR(100)
		,@NPI VARCHAR(20)
		,@FormattedContent VARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	-- Try block
	BEGIN TRY
	DECLARE @alertsidsfordeletion TABLE (alertid INT PRIMARY KEY);
	Declare @UName varchar(100)

    SELECT @AlertID = AlertID
    --, @CurrentWFStatus = CurrentWFStatus /* 2- CAPAVE-1002*/
    FROM KYP.MDM_Alert WHERE AlertNo = @AlertNo
    SET @UName = @Username;
    IF (LOWER(@Username) = 'system(auto)')
    BEGIN
		SET @UName = 'system'
    END
    PRINT @UName
	SELECT @PersonID = PersonID	FROM KYP.OIS_User WHERE UserID = @UName
	PRINT @PersonID + ''
	SELECT @FullName = FullName, @FirstName = FirstName	,@LastName = LastName FROM KYP.OIS_Person WHERE PersonID = @PersonID	
	SELECT @Number = 'NT-<NNNNNN>'	

	IF (LTRIM(RTRIM(ISNULL(@FirstName, ''))) != '')
	BEGIN	
	SELECT @Name = @LastName + COALESCE((', ' + @FirstName), '')
	END
	ELSE
	BEGIN
	SELECT @Name = @LastName
	END

	SELECT @Currenttag = Tag FROM KYP.OIS_Tag WHERE Tag = ','

	SELECT TOP 1 @ALIASNAME = KYPALIAS
	FROM KYP.OIS_App_Version
	WHERE InstalledDate = (
			SELECT MAX(InstalledDate)
			FROM KYP.OIS_App_Version
			)

	SELECT x.alertid
	INTO #alertsToUpdateActivityDate
	FROM (
		SELECT @AlertID AS alertid
		WHERE @AlertID IS NOT NULL
		
		UNION
		
		SELECT @CaseID AS alertid
		WHERE @CaseID IS NOT NULL
		
		UNION
		
		SELECT ChildAlertID AS alertid
		FROM kyp.MDM_RelatedAlerts WITH (NOLOCK)
		WHERE ParentAlertID IN (
				@AlertID
				,@CaseID
				)
			AND isnull(IsDeleted, '0') = 0
		) x

	--IF (LTRIM(RTRIM(ISNULL(@LastName, ''))) != '')
	IF (LTRIM(RTRIM(ISNULL(@FirstName, ''))) != '')
	BEGIN
		SELECT @Name = @LastName + COALESCE((', ' + @FirstName), '')
	END
	ELSE
	BEGIN
		SELECT @Name = @LastName
	END

	IF (
			@ALIASNAME IS NULL
			OR @ALIASNAME = ''
			)
	BEGIN
		SET @ALIASNAME = 'KYP';
	END
/*
	IF (
			@RelatedEntityType = 'SDM_Resolution'
			OR @Type = 'Reopened'
			)
	BEGIN
		SELECT @Name = @FirstName + ', ' + @LastName
	END
*/
	IF (@NotesTitle IS NULL)
	BEGIN
		SELECT @NotesTitle = replace(substring(@NotesDescription, 1, 99),char(10),char(32))
		print @NotesTitle
	END

	/* insert journal entry*/
	IF (
			@JournalEvent = 'AssignToOther'
			OR @JournalEvent = 'Team-Reassign'
			)
	BEGIN
		IF @AlertNo IS NOT NULL
		BEGIN
			EXEC dbo.createAssignToOther @AlertNo
				,@JournalEvent
				,@Username
				,@AssignToUserID
				,@RelatedEntityType
				,@NotesDescription
				,@NotesTitle
				,@Number
				,@Currenttag
				,@Type
				,@SubType
				,@SmartletParameter
				,@FormattedContent
		END
	END
			/*This changes is for KYP-1182 */
			/*---Insert jOURNAL ENTRY FOR  Screening Team APPLICATION------*/
	ELSE IF (@JournalEvent = 'Scr-Team-Reassign-App')
	BEGIN
		IF @MultipleCaseID IS NOT NULL
		BEGIN
			EXEC dbo.createAssignToOtherForApp @MultipleCaseID
				,@JournalEvent
				,@Username
				,@AssignToUserID
				,@RelatedEntityType
				,@NotesDescription
				,@NotesTitle
				,@Currenttag
				,@Number
				,@Type
				,@SubType
				/*START - Changes for http://jira/browse/KYP-2988 */
				,@CurrentWFStatus
				,@FormattedContent
				/*END - Changes for http://jira/browse/KYP-2988 */
		END
	END
			/*---END OF Insert jOURNAL ENTRY FOR Screening Team APPLICATION------*/
			/*This changes is for KYP-1184 */
			/*---Insert jOURNAL ENTRY FOR Screening Unassigned APPLICATION------*/
	ELSE IF (@JournalEvent = 'Scr-Unassigned-Reassign-App')
	BEGIN
		IF @MultipleCaseID IS NOT NULL
		BEGIN
			EXEC dbo.createAssignToOtherForApp @MultipleCaseID
				,@JournalEvent
				,@Username
				,@AssignToUserID
				,@RelatedEntityType
				,@NotesDescription
				,@NotesTitle
				,@Number
				,@Currenttag
				,@Type
				,@SubType
				/*START - Changes for http://jira/browse/KYP-2988 */
				,@CurrentWFStatus
				,@SmartletParameter
				/*END - Changes for http://jira/browse/KYP-2988 */
		END
	END
			/*---END OF Insert jOURNAL ENTRY FOR APPLICATION------*/
	ELSE IF @JournalEvent = 'AssignToSelf'
	BEGIN
		--------Create journal entry for Assign to self business event---------
		IF @AlertNo IS NOT NULL
		BEGIN
			EXEC dbo.createAssignToSelf @AlertNo
				,@JournalEvent
				,@Username
				,@AssignToUserID
				,@RelatedEntityType
				,@NotesDescription
				,@NotesTitle
				,@Number
				,@Currenttag
				,@Type
				,@SubType
				,@FormattedContent
		END
	END
	ELSE IF @JournalEvent = 'Complete-Workflow'
	BEGIN
		--CAPAVE-995/988
		--INSERT INTO dbo.AlertGenerationErrors(Error_Procedure, Error_Message, Error_Time)
		--Values ('NoteIssue:p_JournalEntry','*@AlertNo:'+@AlertNo+'*@Number:'+@Number+'*@RelatedEntityID'+convert(varchar(10),@RelatedEntityID),GETDATE())	
	
		EXEC dbo.createCompleteWorkflow @AlertNo
			,@JournalEvent
			,@Username
			,@AssignToUserID
			,@RelatedEntityType
			,@NotesDescription
			,@NotesTitle
			,@Number
			,@Currenttag
			,@Type
			,@SubType
			,@RelatedEntityID
			,@CurrentWFStatus
			,@FormattedContent
	END
	ELSE IF @JournalEvent = 'WF_SendMail'
	BEGIN
		SELECT @FullName = FullName
		FROM KYP.OIS_User WITH (NOLOCK)
		WHERE PersonID = @PersonID

		IF @FullName IS NOT NULL
		BEGIN
			SET @Sub = 'Alert# ' + @AlertNo + ' has been assigned to you in ' + @ALIASNAME + ' by ' + @FullName;
		END
		ELSE IF @FullName IS NULL
		BEGIN
			SET @Sub = 'Alert# ' + @AlertNo + ' has been assigned to you in ' + @ALIASNAME + ''
		END

		SET @body = '<html>
						<body>
						<table border="1" cellpadding = 5 cellspacing = "">
						  <tr>
							<td><b>	<font face="Cambria" size="2">Alert#:</font></b></td>
							<td>    <font face="Cambria" size="2">' + CONVERT(VARCHAR(20), @AlertNo) + ' </font>		</td>
						  </tr>
						  <tr>
								<td><b>	<font face="Cambria" size="2">Party Name:</font>	</b></td>
								<td>    <font face="Cambria" size="2">' + (
				SELECT WatchedPartyName
				FROM KYP.MDM_Alert WITH (NOLOCK)
				WHERE AlertNo = @AlertNo
				) + '</font></td>
						  </tr>
						  <tr>
								<td><b>	<font face="Cambria" size="2">Relevance:</font>	</b></td>
								<td>    <font face="Cambria" size="2">' + (
				SELECT Priority
				FROM KYP.MDM_Alert WITH (NOLOCK)
				WHERE AlertNo = @AlertNo
				) + ' </font></td>
						  </tr>
						  <tr>
								<td><b>	<font face="Cambria" size="2">Watchlist / Category:</font>	</b></td>
								<td>    <font face="Cambria" size="2">' + (
				SELECT WatchlistName
				FROM KYP.MDM_Alert WITH (NOLOCK)
				WHERE AlertNo = @AlertNo
				) + '</font></td>
						  </tr>
						</table>
						<br>
						
						</body>
					</html>'
		SET @EmailAddTo = (
				SELECT EmailID
				FROM KYP.OIS_User WITH (NOLOCK)
				WHERE PersonID = (
						SELECT AssignedToUserID
						FROM KYP.MDM_Alert WITH (NOLOCK)
						WHERE AlertNo = @AlertNo
						)
				)

		IF @EmailAddTo <> ''
			AND @EmailAddTo IS NOT NULL
		BEGIN
			--IF EXISTS (SELECT 1 FROM sys.service_queues WHERE name = N'ExternalMailQueue' AND is_receive_enabled = 1)
			--BEGIN
			EXEC msdb.dbo.sp_send_dbmail @profile_name = 'administrator'
				,@body = @body
				,@body_format = 'HTML'
				,@recipients = @EmailAddTo
				,@subject = @Sub;
				--END
		END
	END
	ELSE IF @JournalEvent = 'WF_DeleteRelatedData'
	BEGIN
		INSERT INTO @alertsidsfordeletion (alertid)
		SELECT @AlertID AS alertid
		
		UNION
		
		SELECT ChildAlertID
		FROM kyp.MDM_RelatedAlerts WITH (NOLOCK)
		WHERE ParentAlertID = @AlertID
			AND isnull(IsDeleted, '0') = 0

		SELECT @PersonID_UpdateBy = PersonID
			,@FullName_UpdateBy = FullName
		FROM KYP.OIS_User WITH (NOLOCK)
		WHERE UserID = @Username

		SELECT @ProvMedicaID = MedicaidID
		FROM KYP.MDM_Alert WITH (NOLOCK)
		WHERE AlertID = @AlertID
		OPTION (MAXDOP 1) --KYP-12224 

		SELECT @ProvID = ProviderID
		FROM KYP.MDM_AlertResolution WITH (NOLOCK)
		WHERE ResolutionID = @ResolutionID
		OPTION (MAXDOP 1)

		SELECT TOP 1 @NPI = NPI
		FROM KYP.PDM_Provider
		WHERE ProvID = @ProvID
		OPTION (MAXDOP 1)

		INSERT INTO KYP.MDM_ResolutionHistory (
			EventDateTime
			,EventName
			,Notes
			,ProviderID
			,ResolutionType
			,UserID
			,UserName
			,AlertID
			,ProNumber
			)
		SELECT GETDATE()
			,'Delete'
			,@NotesDescription
			,@NPI
			,ResolutionType
			,@Username
			,@FullName_UpdateBy
			,@AlertID
			,@ProvMedicaID
		FROM KYP.MDM_AlertResolution WITH (NOLOCK)
		WHERE AlertID IN (
				SELECT alertid
				FROM @alertsidsfordeletion
				)

		UPDATE KYP.MDM_AlertResolution
		SET IsDeleted = 1
		WHERE AlertID IN (
				SELECT alertid
				FROM @alertsidsfordeletion
				)

		UPDATE kyp.MDM_Alert
		SET LastActivityDate = GETDATE()
		WHERE alertid IN (
				SELECT alertid
				FROM #alertsToUpdateActivityDate
				)
	END
	ELSE IF @JournalEvent = 'WF_DeleteRelatedDataUnMerge'
	BEGIN
		DECLARE @WATCHPARTYID INT
			,@PROVDRID INT
			,@PARENTID INT;

		SELECT @WATCHPARTYID = WatchedPartyID
		FROM KYP.MDM_Alert
		WHERE AlertID = @AlertID

		SELECT @PROVDRID = ProvID
		FROM KYP.PDM_Provider
		WHERE PartyID = @WATCHPARTYID

		--SELECT @PARENTID=ParentAlertID FROM KYP.MDM_RelatedAlerts WHERE ChildAlertID=@AlertID
		UPDATE A
		SET AlertID = @AlertID
		FROM KYP.MDM_AlertResolution A
		INNER JOIN KYP.MDM_RelatedAlerts B ON A.AlertID = B.ParentAlertID
			AND A.ProviderID = @PROVDRID
			AND B.MergedByUserID <> '1'
	END
	ELSE IF @JournalEvent = 'WF_RemoveResolutions'
		AND @AlertNo IS NOT NULL
	BEGIN
		SELECT @PersonID_UpdateBy = PersonID
			,@FullName_UpdateBy = FullName
		FROM KYP.OIS_User WITH (NOLOCK)
		WHERE UserID = @Username

		SELECT @ResolutionID = ResolutionID
			,@ProvID = ProviderID
		FROM KYP.MDM_AlertResolution WITH (NOLOCK)
		WHERE ProviderMedicaidID = @AlertNo
			AND AlertID = @CaseID --ResolutionID = @ResolutionID
		OPTION (MAXDOP 1)

		SELECT TOP 1 @NPI = NPI
		FROM KYP.PDM_Provider
		WHERE ProvID = @ProvID
		OPTION (MAXDOP 1)

		INSERT INTO KYP.MDM_ResolutionHistory (
			EventDateTime
			,EventName
			,Notes
			,ProviderID
			,ResolutionType
			,UserID
			,UserName
			,AlertID
			,ProNumber
			)
		SELECT GETDATE()
			,'Delete'
			,@NotesDescription
			,@NPI
			,ResolutionType
			,@Username
			,@FullName_UpdateBy
			,@CaseID
			,@AlertNo
		FROM KYP.MDM_AlertResolution WITH (NOLOCK)
		WHERE ProviderMedicaidID = @AlertNo
			AND AlertID = @CaseID
			AND ISNULL(IsDeleted, 0) = 0
		OPTION (MAXDOP 1)

		UPDATE KYP.MDM_AlertResolution
		SET IsDeleted = 1
		WHERE AlertID = @CaseID
			AND ProviderMedicaidID = @AlertNo

		UPDATE kyp.MDM_Alert
		SET LastActivityDate = GETDATE()
		WHERE alertid IN (
				SELECT alertid
				FROM #alertsToUpdateActivityDate
				)
			/*	
			EXEC [KYP].[sp_RemoveAlertResolutions] @Username, @NotesDescription, @AlertNo, @CaseID, '1'
		*/
	END
			/*Screening Workflow history changes */
	ELSE IF @JournalEvent = 'WF_InsertScreeningHistory'
	BEGIN
		IF @MultipleCaseID IS NOT NULL
		BEGIN
			IF @MultipleCaseID = 'Referred'
			BEGIN
				EXEC [KYP].[sp_PopulateScreeningWorkflowHistory] @CaseID
					,@RelatedEntityType
					,@CurrentWFStatus
					,@Username
					,@NotesDescription
					,@MultipleTrackingNo
					,@MultipleCaseID
			END
			ELSE
			BEGIN
				DECLARE @sql NVARCHAR(MAX);

				SET @sql = ''

				SELECT --here "item" is CaseID
					@sql = @sql + ' EXEC [KYP].[sp_PopulateScreeningWorkflowHistory] ' + item + ', ' + @RelatedEntityType + ', ' + @CurrentWFStatus + ', ' + @Username + ', ' + @NotesDescription + ', ' + @MultipleTrackingNo + CHAR(13)
				FROM fnSplitString(@MultipleCaseID, ',')

				--from fnSplitString('1,2,3,4,5,6', ',')
				EXECUTE sp_executesql @sql
			END
		END
		ELSE
		BEGIN
			EXEC [KYP].[sp_PopulateScreeningWorkflowHistory] @CaseID
				,@RelatedEntityType
				,@CurrentWFStatus
				,@Username
				,@NotesDescription
				,@MultipleTrackingNo
				,@MultipleCaseID
		END
	END
	ELSE IF @JournalEvent = 'WF_BulkAcceptance'
	BEGIN
		EXEC [KYP].[sp_WFBulkAcceptance] @CaseID
	END
	
	ELSE IF @JournalEvent = 'WF_BulkDecline'
	BEGIN
		EXEC [KYP].[sp_WFBulkDecline] @CaseID, @NotesDescription, @Type 
	END
	
			/*Screening Workflow history changes */
	ELSE IF @JournalEvent = 'WF_InsertResolutionHistory'
	BEGIN
		UPDATE kyp.MDM_Alert
		SET LastActivityDate = GETDATE()
		WHERE alertid IN (
				SELECT alertid
				FROM #alertsToUpdateActivityDate
				)

		IF @AlertNo IS NULL
		BEGIN
			EXEC [KYP].[sp_PopulateAlertWorkflowHistory] @CaseID
				,@RelatedEntityID
				,@CurrentWFStatus
				,@Username
				,@NotesDescription
				,@MultipleTrackingNo
		END
		ELSE
		BEGIN
			DECLARE @CaseID_M INT;

			IF OBJECT_ID(N'tempdb..#tmp_1') IS NOT NULL
			BEGIN
				DROP TABLE #tmp_1
			END

			CREATE TABLE #tmp_1 (
				[ID] INT
				,AlertID INT
				)

			INSERT INTO #tmp_1
			SELECT *
			FROM dbo.Split(@AlertNo, ',')

			DECLARE multipleAlert CURSOR
			FOR
			SELECT AlertID
			FROM #tmp_1

			OPEN multipleAlert

			FETCH NEXT
			FROM multipleAlert
			INTO @CaseID_M

			WHILE @@Fetch_Status = 0
			BEGIN
				EXEC [KYP].[sp_PopulateAlertWorkflowHistory] @CaseID_M
					,@RelatedEntityID
					,@CurrentWFStatus
					,@Username
					,@NotesDescription
					,@MultipleTrackingNo

				FETCH NEXT
				FROM multipleAlert
				INTO @CaseID_M
			END

			CLOSE multipleAlert

			DEALLOCATE multipleAlert
		END
	END
	ELSE IF @JournalEvent = 'DUPLICATEWATCHLISTRESOLUTIONS'
	BEGIN		

		DECLARE EPLSORG_CURSOR CURSOR
		FOR --Renaming KYP Watchlist to Internal Watchlist KYP-9462 
		SELECT RESOLUTIONID
		FROM KYP.MDM_AlertResolution
		WHERE RESOLUTIONTYPE = 'Add to Internal Watchlist'
			AND ISDELETED = 0
			AND ALERTID = @MEDICAIDRESOLID

		OPEN EPLSORG_CURSOR

		FETCH NEXT
		FROM EPLSORG_CURSOR
		INTO @DUPLICATEID

		WHILE @@FETCH_STATUS = 0
		BEGIN
			SELECT @WATCHRESOLUTIONNAME = PROVIDERNAME
			FROM KYP.MDM_AlertResolution
			WHERE RESOLUTIONID = @DUPLICATEID

			SELECT @WATCHRESOLUTIONPROVIDERMEDICAIDID = PROVIDERMEDICAIDID
			FROM KYP.MDM_AlertResolution
			WHERE RESOLUTIONID = @DUPLICATEID

			SELECT @WATCHDUMRESOLUTIONID = RESOLUTIONID
			FROM KYP.MDM_AlertResolution
			WHERE RESOLUTIONID = @DUPLICATEID

			INSERT INTO kYP.MDM_BulkDupWatchlist (
				MedicaidID
				,ResolutionID
				,ProviderName
				)
			VALUES (
				@WATCHRESOLUTIONPROVIDERMEDICAIDID
				,@WATCHDUMRESOLUTIONID
				,@WATCHRESOLUTIONNAME
				)

			FETCH NEXT
			FROM EPLSORG_CURSOR
			INTO @DUPLICATEID
		END

		CLOSE EPLSORG_CURSOR

		DEALLOCATE EPLSORG_CURSOR
	END

	--------------------------------- Create Finding Preformance ------------------------------
	IF (@JournalEvent = 'ScreeningCreateFinding')
	BEGIN
		EXEC [KYP].[p_ScreeningCF] @InfoID = @InfoID
			,@Number = @Number
	END

	--------------------------------------------------------------------------------------------
	---------Start of Swapping Attachments and Notes For Centralized Notes----------------------
	IF (
			@JournalEvent IS NULL
			AND @AlertNo IS NOT NULL
			)
	BEGIN
		EXEC @NoteID = [KYP].[p_InsertOISNote] @UserID = @Username
			,@Name = @NotesTitle
			,@Type = @Type
			,@SubType = @SubType
			,@ParentID = 0
			,@DateCreated = @CurrentDate
			,@Author = @Name
			,@RelatedEntityType = @RelatedEntityType
			,@Content = @NotesDescription
			,@UnformattedContent = @NotesDescription
			,@Number = @Number
			,@VersionNo = 1
			,@isWorkpaper = 0
			,@isAcknowledged = 0
			,@WorkflowName = NULL
			,@isAdverse = 0
			,@Deleted = 0
			,@DeletedOn = NULL
			,@DeletedBy = NULL
			,@DeletedByUserID = NULL
			,@UpdatedOn = NULL
			,@UpdatedBy = NULL
			,@UpdatedByUserID = NULL
			,@IsImportant = 0
			,@IsLastVersion = 1
			,@IsSticky = 0
			,@IsReferenced = 0
			,@HasComments = 0
			,@HasDocuments = 0
			,@NumberSchemaInfo = @Number
			,@LastVersion = 1
			,@AllowComments = 0
			,@RestoredBy = NULL
			,@RestoredByUserID = NULL
			,@CaseID = @CaseID
			,@AlertID = @AlertID
			,@IncidentID = NULL
			,@Tags = NULL
			,@FullDateCreated = NULL
			,@RelatedEntityID = @RelatedEntityID
			,@Importance = 'Low'
			,@MultipleCaseID = @MultipleCaseID
			,@MultipleTrackingNo = @MultipleTrackingNo
			,@Score = 0
			,@DMSID = NULL
			,@DocumentCount = NULL
			,@PInID = NULL

		--Updating the ConfirmationNoteID with NoteID  when a record created in OIS_Note through bulk update. 
		IF (
				@SubType = 'DispositionDetail'
				OR @SubType = 'Disposition'
				)
		BEGIN
			UPDATE [KYP].[MDM_Alert]
			SET ConfirmationNoteID = @NoteID
			WHERE ConfirmationNoteID IS NULL
				AND AlertID = @AlertID;
		END

		IF @Currenttag IS NULL
		BEGIN
			INSERT INTO [KYP].[OIS_Tag] ([Tag])
			VALUES (',')
		END

		INSERT INTO [KYP].[OIS_JT_NoteTag] (
			[NoteID]
			,[Tag]
			)
		VALUES (
			@NoteID
			,','
			)

		----Get the notenumber------
		EXEC [KYP].[p_GenerateNoteNumber] @NoteID, @Notenumber = @Notenumber OUTPUT

		--/******* Updating note number in OIS_Note***********/
		UPDATE KYP.OIS_Note
		SET Number = @Notenumber
		WHERE NoteID = @NoteID

		/********Creating Journal entry********************/
		SELECT @JournalDescription = 'Notes Added-' + ' ' + @Type + ' ' + @Notenumber + ' ' + 'was added to' + ' ' + @RelatedEntityType

		INSERT INTO [KYP].[OIS_Journal] (
			[UserID]
			,[ACTIONID]
			,[Date_x]
			,[DESCRIPTION]
			,[EntityTable]
			,[Entity]
			,[EntityID]
			,[CaseID]
			,[ShortDescription]
			)
		VALUES (
			@Username
			,1
			,@CurrentDate
			,@JournalDescription
			,'OIS_Note'
			,'Note'
			,@NoteID
			,@CaseID
			,@JournalDescription
			)

		/**********Segregate the smartlet parameter for noteentity entry************/
		SELECT @NoteEntityType = NoteEntityType
			,@NoteEntityTypeID = NoteEntityTypeID
			,@NoteEntityDepID = NoteEntityDepID
			,@NoteEntityDep = NoteEntityDep
			,@Level = LEVEL
			,@IsLastLevel = IsLastLevel
		FROM simple_intlist_to_tbl(@SmartletParameter)

		/********Insert into Noteentity*************/
		INSERT INTO [KYP].[NoteEntity] (
			[NoteNumber]
			,[NoteEntityType]
			,[NoteEntityDep]
			,[NoteEntityTypeID]
			,[NoteEntityDepID]
			,[Level]
			,[IsLastLevel]
			)
		SELECT @Notenumber
			,NoteEntityType
			,NoteEntityDep
			,@AlertNo
			,@AlertNo
			,LEVEL
			,IsLastLevel
		FROM simple_intlist_to_tbl(@SmartletParameter)

		SELECT @IsExistID = ParentID
		FROM KYP.NoteCounts
		WHERE ParentID = @RelatedEntityID
			AND ParentTable = @RelatedEntityType

		SELECT @IsExistCaseID = ParentID
		FROM KYP.NoteCounts
		WHERE ParentID = @CaseID
			AND ParentTable = 'ADM_Case'

		SELECT @NoteCount = 0

		SELECT @CaseNoteCNT = 0

		SELECT @NoteCount = count(RelatedEntityID)
		FROM KYP.OIS_Note
		WHERE RelatedEntityID = @RelatedEntityID
			AND RelatedEntityType = @RelatedEntityType
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)

		SELECT @CaseNoteCNT = count(CaseID)
		FROM KYP.OIS_Note
		WHERE CaseID = @CaseID
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)

		IF @IsExistID IS NULL
		BEGIN
			INSERT INTO [KYP].[NoteCounts] (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@RelatedEntityID
				,@RelatedEntityType
				,@NoteCount
				)
		END
		ELSE
		BEGIN
			UPDATE [KYP].[NoteCounts]
			SET [Counts] = @NoteCount
			WHERE ParentID = @RelatedEntityID
				AND ParentTable = @RelatedEntityType
		END --if @IsExistID

		IF @IsExistCaseID IS NULL
		BEGIN
			INSERT INTO [KYP].[NoteCounts] (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@CaseID
				,'ADM_Case'
				,@CaseNoteCNT
				)
		END
		ELSE
		BEGIN
			UPDATE [KYP].[NoteCounts]
			SET [Counts] = @CaseNoteCNT
			WHERE ParentID = @CaseID
				AND ParentTable = 'ADM_Case'
		END --if @IsExistID

		IF (
				@RelatedEntityType = 'SDM_Resolution'
				AND @Type = 'Pended'
				)
		BEGIN
			UPDATE KYP.ADM_Case
			SET DateResolved = NULL
			WHERE CaseID = @CaseID

			UPDATE KYP.ADM_Case
			SET StatusName = 'Pended'
			WHERE CaseID = @CaseID
		END

		IF (
				@RelatedEntityType = 'SDM_Resolution'
				AND @Type = 'Completed'
				)
		BEGIN
			UPDATE KYP.ADM_Case
			SET DateResolved = NULL
			WHERE CaseID = @CaseID

			UPDATE KYP.ADM_Case
			SET StatusName = 'Completed'
			WHERE CaseID = @CaseID
		END
	END --(@JournalEvent is null and  @AlertNo is not null) 
			------------------------------------End of Swapping attachments and Notes For Centalized Notes---------------------------------------------------------
	ELSE IF (@JournalEvent IS NULL)
	BEGIN
		EXEC @NoteID = [KYP].[p_InsertOISNote] @UserID = @Username
			,@Name = @NotesTitle
			,@Type = @Type
			,@SubType = @SubType
			,@ParentID = 0
			,@DateCreated = @CurrentDate
			,@Author = @Name
			,@RelatedEntityType = @RelatedEntityType
			,@Content = @FormattedContent
			,@UnformattedContent = @NotesDescription
			,@Number = @Number
			,@VersionNo = 1
			,@isWorkpaper = 0
			,@isAcknowledged = 0
			,@WorkflowName = NULL
			,@isAdverse = 0
			,@Deleted = 0
			,@DeletedOn = NULL
			,@DeletedBy = NULL
			,@DeletedByUserID = NULL
			,@UpdatedOn = NULL
			,@UpdatedBy = NULL
			,@UpdatedByUserID = NULL
			,@IsImportant = 0
			,@IsLastVersion = 1
			,@IsSticky = 0
			,@IsReferenced = 0
			,@HasComments = 0
			,@HasDocuments = 0
			,@NumberSchemaInfo = @Number
			,@LastVersion = 1
			,@AllowComments = 0
			,@RestoredBy = NULL
			,@RestoredByUserID = NULL
			,@CaseID = @CaseID
			,@AlertID = @AlertID
			,@IncidentID = NULL
			,@Tags = NULL
			,@FullDateCreated = NULL
			,@RelatedEntityID = @RelatedEntityID
			,@Importance = 'Low'
			,@MultipleCaseID = @MultipleCaseID
			,@MultipleTrackingNo = @MultipleTrackingNo
			,@Score = 0
			,@DMSID = NULL
			,@DocumentCount = NULL
			,@PInID = NULL

		--Updating the ConfirmationNoteID with NoteID  when a record created in OIS_Note through bulk update. 
		IF (
				@SubType = 'DispositionDetail'
				OR @SubType = 'Disposition'
				)
		BEGIN
			UPDATE [KYP].[MDM_Alert]
			SET ConfirmationNoteID = @NoteID
			WHERE ConfirmationNoteID IS NULL
				AND AlertID = @AlertID;
		END

		IF @Currenttag IS NULL
		BEGIN
			INSERT INTO [KYP].[OIS_Tag] ([Tag])
			VALUES (',')
		END

		INSERT INTO [KYP].[OIS_JT_NoteTag] (
			[NoteID]
			,[Tag]
			)
		VALUES (
			@NoteID
			,','
			)

		--Get the notenumber------
		EXEC [KYP].[p_GenerateNoteNumber] @NoteID, @Notenumber = @Notenumber OUTPUT

		/******* Updating note number in OIS_Note***********/
		UPDATE KYP.OIS_Note
		SET Number = @Notenumber
		WHERE NoteID = @NoteID

		/********Creating Journal entry********************/
		SELECT @JournalDescription = 'Notes Added-' + ' ' + @Type + ' ' + @Notenumber + ' ' + 'was added to' + ' ' + @RelatedEntityType

		INSERT INTO [KYP].[OIS_Journal] (
			[UserID]
			,[ACTIONID]
			,[Date_x]
			,[DESCRIPTION]
			,[EntityTable]
			,[Entity]
			,[EntityID]
			,[CaseID]
			,[ShortDescription]
			)
		VALUES (
			@Username
			,1
			,@CurrentDate
			,@JournalDescription
			,'OIS_Note'
			,'Note'
			,@NoteID
			,@CaseID
			,@JournalDescription
			)

		/**********Segregate the smartlet parameter for noteentity entry************/
		SELECT @NoteEntityType = NoteEntityType
			,@NoteEntityTypeID = NoteEntityTypeID
			,@NoteEntityDepID = NoteEntityDepID
			,@NoteEntityDep = NoteEntityDep
			,@Level = LEVEL
			,@IsLastLevel = IsLastLevel
		FROM simple_intlist_to_tbl(@SmartletParameter)

		/********Insert into Noteentity*************/
		INSERT INTO [KYP].[NoteEntity] (
			[NoteNumber]
			,[NoteEntityType]
			,[NoteEntityDep]
			,[NoteEntityTypeID]
			,[NoteEntityDepID]
			,[Level]
			,[IsLastLevel]
			)
		SELECT @Notenumber
			,NoteEntityType
			,NoteEntityDep
			,NoteEntityTypeID
			,NoteEntityDepID
			,LEVEL
			,IsLastLevel
		FROM simple_intlist_to_tbl(@SmartletParameter)

		SELECT @IsExistID = ParentID
		FROM KYP.NoteCounts
		WHERE ParentID = @RelatedEntityID
			AND ParentTable = @RelatedEntityType

		SELECT @IsExistCaseID = ParentID
		FROM KYP.NoteCounts
		WHERE ParentID = @CaseID
			AND ParentTable = 'ADM_Case'

		SELECT @NoteCount = 0

		SELECT @CaseNoteCNT = 0

		SELECT @NoteCount = count(RelatedEntityID)
		FROM KYP.OIS_Note
		WHERE RelatedEntityID = @RelatedEntityID
			AND RelatedEntityType = @RelatedEntityType
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)

		SELECT @CaseNoteCNT = count(CaseID)
		FROM KYP.OIS_Note
		WHERE CaseID = @CaseID
			AND (
				Deleted IS NULL
				OR Deleted = 0
				)

		IF @IsExistID IS NULL
		BEGIN
			INSERT INTO [KYP].[NoteCounts] (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@RelatedEntityID
				,@RelatedEntityType
				,@NoteCount
				)
		END
		ELSE
		BEGIN
			UPDATE [KYP].[NoteCounts]
			SET [Counts] = @NoteCount
			WHERE ParentID = @RelatedEntityID
				AND ParentTable = @RelatedEntityType
		END --if @IsExistID

		IF @IsExistCaseID IS NULL
		BEGIN
			INSERT INTO [KYP].[NoteCounts] (
				[ParentID]
				,[ParentTable]
				,[Counts]
				)
			VALUES (
				@CaseID
				,'ADM_Case'
				,@CaseNoteCNT
				)
		END
		ELSE
		BEGIN
			UPDATE [KYP].[NoteCounts]
			SET [Counts] = @CaseNoteCNT
			WHERE ParentID = @CaseID
				AND ParentTable = 'ADM_Case'
		END --if @IsExistID

		IF (
				@RelatedEntityType = 'SDM_Resolution'
				AND @Type = 'Pended'
				)
		BEGIN
			UPDATE KYP.ADM_Case
			SET DateResolved = NULL
			WHERE CaseID = @CaseID

			UPDATE KYP.ADM_Case
			SET StatusName = 'Pended'
			WHERE CaseID = @CaseID
		END

		IF (
				@RelatedEntityType = 'SDM_Resolution'
				AND @Type = 'Completed'
				)
		BEGIN
			UPDATE KYP.ADM_Case
			SET DateResolved = NULL
			WHERE CaseID = @CaseID

			UPDATE KYP.ADM_Case
			SET StatusName = 'Completed'
			WHERE CaseID = @CaseID
		END
	END --(@JournalEvent <> 'AssignToSelf' or @JournalEvent is null) 

	DECLARE @RETVAL INT;

	SELECT @RETVAL = IDENT_CURRENT('kyp.MDM_JournalBasicInfo');

	IF OBJECT_ID(N'tempdb..#tmpData') IS NOT NULL
	BEGIN
		DROP TABLE #tmpData
	END

	CREATE TABLE #tmpData (
		TempID INT IDENTITY(1, 1) NOT NULL
		,ValueData VARCHAR(20)
		)

	SET IDENTITY_INSERT #tmpData ON

	INSERT INTO #tmpData (TempID)
	VALUES (@RETVAL);

	UPDATE #tmpData
	SET ValueData = 'Updated'
	WHERE TempID = @RETVAL;

	SET IDENTITY_INSERT #tmpData OFF

	DROP TABLE #tmpData
	END TRY
	BEGIN CATCH
		IF @@TranCount>0
			Rollback Transaction;	
				
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'Case_ID',@KeyValue = @CaseID;
	END CATCH
	
END
GO

