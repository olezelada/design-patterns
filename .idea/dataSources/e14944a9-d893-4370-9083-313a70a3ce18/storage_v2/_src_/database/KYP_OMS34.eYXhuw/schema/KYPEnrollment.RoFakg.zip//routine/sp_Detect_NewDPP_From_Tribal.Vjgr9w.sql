-- =============================================
-- Author:		<hbustamante>
-- Create date: <04/15/2019>
-- Description:	<This sp look already exist a DPP account created through Tribal application, if it was not created before it creates one>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Detect_NewDPP_From_Tribal]
@account_id int,
@applicatioNo varchar(10),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@composite_risk INT,
@caseId INT,
@risk VARCHAR(15),
@npiType VARCHAR(35),
@main_app_number varchar(10)

AS
BEGIN
DECLARE @accNumber VARCHAR(20), @newAccountNumber INT, @app_id INT, @acc_aux INT, @newAppType VARCHAR(50);
IF EXISTS(SELECT pq.QuestionID
				FROM KYPPORTAL.PortalKYP.pADM_Application a
					INNER JOIN KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie pq ON a.PartyID = pq.PartyId
				WHERE pq.IsDeleted = 0
					AND a.ApplicationNo = @applicatioNo
					AND ISNULL(pq.Value,'') = 'Yes'
					AND pq.Name = 'FormProfessionalLicenseCert')

  BEGIN

    IF NOT EXISTS(SELECT DP.AccountID,*
                  FROM kyp.ADM_Case AC
                  JOIN kypenrollment.Padm_Account DP ON AC.Provider_NPI=DP.NPI
                  JOIN Kypenrollment.EDM_SupplementalInternalUse S ON AC.Number=S.LastActionComments
                                                                              AND DP.OwnerNo=S.BillingFutureStatus
                                                                              AND DP.ServiceLocationNo=S.ProvCrossReferenceCode
                                                                              AND DP.ProviderTypeCode=S.ProviderTypeCode
                  WHERE Ac.Number = @applicatioNo
                  AND DP.ProviderTypeCode = '102'
                  AND DP.IsDeleted=0)

    BEGIN
        print 'CREATING 102 by Update account Process'

      SELECT @newAppType = pta.ProviderSubType
      FROM KYPPORTAL.PortalKYP.pProviderType_Application pta
        INNER JOIN KYPPORTAL.PortalKYP.pPortalApplication pa ON pa.PortalApplicationID = pta.PortalApplicationID
      WHERE pa.ApplicationCode IN ('F_DPP_OE', 'F_DPP_SP')
        AND pa.EntityType = @npiType

		  SELECT @app_id = ApplicationID
		  FROM KYPPORTAL.PortalKYP.pADM_Application
		  WHERE ApplicationNo=@applicatioNo
			SET @newAccountNumber = 130000000+@caseId
			print @newAccountNumber
			EXEC [KYPEnrollment].[sp_Create_New_DPP_Account_From_Tribal] @applicatioNo
														 , @last_Action_User_ID
														 , @priority
														 , @risk
							               , @composite_risk
										         , '102'
											       , @newAccountNumber
											       , @npiType;
        SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')

        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @newAccountNumber
            , @app_id
            , @applicatioNo
            , @newAppType)
    END

  END
END
GO

