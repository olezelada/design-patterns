
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date		Description
---------------------------------------------------------------------------------------
-- 1		MD-4				Sundar		20-Jul-2017	Added Input Doc functionality for MD
-- 2		CAPAVE-1839			Sundar		03-Aug-2017		Delete the staging tables if AccountType is 'Deleted'
-- 3		KEN-12838			Sundar		28-Aug-2017		Added new delete statement for 3.0 Input Doc. development

CREATE TRIGGER [KYPEnrollment].[AccountUpdate_tr] ON [KYPEnrollment].[AccountUpdateOn]
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    
	Declare @accountid int,
	@username varchar(100),
	@userdate date,
	@AccountType varchar(100),
	@StateCode varchar(2) --Added for #1 MD-4
	--select(convert(date,@userdate)) as userdatenew

    
	set @accountid =(select AccountID from inserted)
	set @username=(select userName from inserted)
	set @userdate =(select UserDate from inserted)
	set @AccountType=(select AccountType from inserted)
      
--      print @accountid;
	
	--Added for #1 MD-4
	Select @StateCode = StateCode
	From kyp.OIS_App_Version; 
		
/*Start #2 CAPAVE-1839*/
	IF (@AccountType = 'Deleted') 
	Begin 
		If (@StateCode = 'CA' or @StateCode IS NULL)
		Begin
			Delete from Kypenrollment.Idoc_Biller 
			Where AccountID = @accountid 
				and UserName = @UserName;
			
			Delete from kypenrollment.GroupRenderingforAccount
			Where AccountID = @accountid 
				and UserName = @UserName;
			
			Delete from kypenrollment.GroupAssociationforAccount
			Where AccountID = @accountid 
				and UserName = @UserName;
			
			Delete from kypenrollment.NMPRenderingForAccount
			Where AccountID = @accountid 
				and UserName = @UserName;	
							
			Delete from kypenrollment.MocaDetailforAccount
			Where AccountID = @accountid 
				and UserName = @UserName;	
			
			Delete from kypenrollment.AccountInputDocNMP
			Where AccountNumber = (Select AccountNumber
									From kypenrollment.Padm_Account
									Where AccountId = @accountid)
				and UserName = @username;
			
			Delete from kypenrollment.NMPBillingProvider
			Where AccountID = @accountid
				and UserName = @username;
					
			Delete from kypenrollment.AccountInputDocORP
			Where AccountID = @accountid
				and UserName = @username;			
			
			Delete from kypenrollment.AccountUpdatedYesterday
			where AccountID = @accountid
				and UserName = @username;	
				
			/*Start #3 KEN-12838*/				
			Delete from kypenrollment.GroupRendforAccount
			Where AccountID = @accountid 
				and UserName = @UserName;
			
			Delete from kypenrollment.GroupAssforAccount
			Where AccountID = @accountid 
				and UserName = @UserName;
							
			Delete from KYPEnrollment.ID_Biller_COS	
			where AccountID = @accountid
				and UserName = @username;	
				
			Delete from KYPEnrollment.ID_Biller_LAB	
			where AccountID = @accountid
				and UserName = @username;
				
			Delete from KYPEnrollment.ID_Biller_Specialty
			where AccountID = @accountid
				and UserName = @username;
				
			Delete from KYPEnrollment.ID_Biller_Taxonomy	
			where AccountID = @accountid
				and UserName = @username;											
			/*End #3 KEN-12838*/								
		End;
		
		If (@StateCode = 'MD')
		Begin
			Delete from kypenrollment.ID_BillerInfo
			where AccountID = @accountid
				and UserName = @username;	
				
			Delete from kypenrollment.ID_Speciality
			where AccountID = @accountid
				and UserName = @username;	
				
			Delete from kypenrollment.ID_Category
			where AccountID = @accountid
				and UserName = @username;	
				
			Delete from kypenrollment.ID_GroupAffiliation
			where AccountID = @accountid
				and UserName = @username;	
				
			Delete from kypenrollment.ID_LabClassification
			where AccountID = @accountid
				and UserName = @username;
		
		End;					
	End 
	Else
	Begin	
	/*End #2 CAPAVE-1839*/					
		--Begin Try
		IF @StateCode = 'CA' --Added for #1 MD-4
		Begin --Added for #1 MD-4		
			IF EXISTS(select 1 from KYPEnrollment.pADM_Account where AccountID=@accountid)/*adding if condition as create behviour is failing in application.*/
				BEGIN
				IF (@AccountType ='NMP')
					BEGIN
				
					Execute [KYPEnrollment].[sp_NMPBillingProvider_AccountInputDoc] @accountid,@username,@userdate;
					end
				else if(@AccountType='ORP')
					BEGIN
						--Execute [KYPEnrollment].[sp_update_AccountInputDoc_ORP] @accountid,@username,@userdate;
						Execute [KYPEnrollment].[Usp_IDoc_ORP] @accountid,@username,@userdate;
					end
				else
					BEGIN
						--  Execute [KYPEnrollment].[sp_Insert_AccountInputDoc] @accountid,@username,@userdate;
						Execute [KYPEnrollment].[Usp_IDoc_Biller] @accountid,@username,@userdate; --As per new performance changes calling new SP.
						
					end
			END;
		End --Added for #1 MD-4
		
		--Added the If block for #1 MD-4
		If @StateCode = 'MD'
		Begin
			Exec kypenrollment.Usp_MD_IDoc_Biller @AccountID,@UserName;
		End		
	End; --Added for #2 CAPAVE-1839
END


GO

