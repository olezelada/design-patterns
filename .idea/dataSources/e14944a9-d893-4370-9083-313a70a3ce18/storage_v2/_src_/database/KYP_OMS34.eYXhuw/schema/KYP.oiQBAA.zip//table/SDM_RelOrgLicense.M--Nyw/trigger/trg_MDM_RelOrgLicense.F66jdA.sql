
CREATE TRIGGER [KYP].[trg_MDM_RelOrgLicense] 
   ON  [KYP].[SDM_RelOrgLicense] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @screeningID int
	declare @id int
	
	select @screeningID = ScreeningID,@id = ID from inserted
	
	truncate table KYP.SDM_Related_Org_License
	
	INSERT INTO KYP.SDM_Related_Org_License
	SELECT  Z.MoreValueID,Z.ScreeningID,Z.TRLicense,Z.TRStateName,Z.TRValidity,Z.TRFirstIssue,Z.TROrgName,Z.TRLicenseType,Z.TRAuthority,Z.TRSTATUS FROM (
	SELECT MoreValueID,ScreeningID,TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS from(
		Select X.MoreValueID,X.ScreeningID,X.DetailAttributeName,X.DetailAttributeValue from(
			Select D.MoreValueID,M.ScreeningID,D.DetailAttributeName,D.DetailAttributeValue
				from KYP.SDM_MoreValue M inner join KYP.SDM_MoreValueDetail D 
				ON M.MoreValueID = D.MoreValueID 
		) X UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRLicense' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRStateName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRValidity' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRFirstIssue' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TROrgName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRLicenseType' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRAuthority' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , 'TRSTATUS' As DetailAttributeName , '' As DetailAttributeValue
)Y PIVOT(max(DetailAttributeValue)
	for DetailAttributeName IN (TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS)
) patx
) Z WHERE Z.MoreValueID != 0 AND LTRIM(RTRIM(ISNULL(Z.TRLicense,''))) != '' AND  Z.ScreeningID = @screeningID


-- After Inserting In to table delete
delete from KYP.SDM_RelOrgLicense where ID != @id

    -- Insert statements for trigger here

END


GO

