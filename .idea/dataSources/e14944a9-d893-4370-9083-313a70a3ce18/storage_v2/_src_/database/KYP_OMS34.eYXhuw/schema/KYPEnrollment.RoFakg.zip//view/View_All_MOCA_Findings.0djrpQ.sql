






CREATE VIEW [KYPEnrollment].[View_All_MOCA_Findings]
AS
SELECT note.UnformattedContent AS findingDescription,note.Name as titleFinding,app.ApplicationId as ApplicationID,
app.PartyID as PortalAppPartyID,basicInfo.PFieldID as FiledName,section.sectionName as SectionName,section.code as SectionCode,
basicInfo.InfoID as InfoID,note.NoteID as NoteID,note.ReasonCode as ReasonCode,app.CaseID as PortalCaseID ,basicInfo.CaseID as ENCaseID,
note.PInID as PInID,person.SSN as portalSSN,AccP.PartyId as AccountPartyID,AccP.PersonID as AccountPersonID,AccP.SSN as AccountSSN,
package.packageName as PackageName,package.applicationCode as PackageCode,section.subFormId as SectionSubFormId,
person.PersonID as portalpersonID,finding.FieldStatusID as PortalFindingID,
case when note.Type = 'Application Review' then 'APP REVIEW' 
			when note.Type = 'RELATED ACCOUNTS' then note.Type
			else 'SCREENING' end as category,
CASE WHEN note.ExternalYesNO IS NULL THEN 'N/D'
				 WHEN (note.ExternalYesNO = '1' or note.ExternalYesNO = 'Yes') THEN
						'EXTERNAL' 
				WHEN (note.ExternalYesNO = '0' or note.ExternalYesNO = 'NO')  THEN
						'INTERNAL' 
				ELSE NULL END As isexternaldesc,
(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u where p.PersonID = u.PersonID and u.UserID= note.UserID) as addedby,
note.DateCreated as Addedon,
note.status as status,
note.DocumentCount as DocumentCount

FROM KYPPORTAL.PortalKYP.pADM_Application app
inner join KYPPORTAL.PortalKYP.Cfg_FormPackage package on app.ApplicationCode = package.applicationCode
inner join KYP_OMS34.KYP.MDM_JournalBasicInfo basicInfo on basicInfo.PAppID=app.ApplicationID and IsIgnored=0
INNER JOIN KYP_OMS34.KYP.OIS_Note note on basicInfo.InfoID = note.PInID
inner join KYPPORTAL.PortalKYP.Enrollment_FieldStatus finding on app.ApplicationId=finding.ApplicationId and ElementType<>'Document' and basicInfo.PFieldID = finding.FieldID 
and basicInfo.PartyID=finding.PartyID
inner join KYPPORTAL.PortalKYP.Cfg_Section section on  finding.SubFormID = section.subFormId  AND finding.FormID = section.formId and package.packageId = section.packageId and section.sectionId=finding.SectionID
inner join KYPPORTAL.PortalKYP.pPDM_Person person on person.PartyID=finding.PartyID
inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.PartyID= finding.PartyID
inner Join (Select P.PartyId,Per.SSN,Per.PersonID
		From KYP_OMS34.KYPEnrollment.pAccount_PDM_Party P
		Join KYP_OMS34.KYPEnrollment.pAccount_PDM_Person Per on P.PartyID=Per.PartyId
		Where P.Type='Individual Ownership') AccP on Person.SSN = AccP.SSN
where note.ReasonCode='Application Update' and party.Type='Individual Ownership'  --and app.ApplicationNo='187CJBUI' 

union All

SELECT note.UnformattedContent AS findingDescription,note.Name as titleFinding,app.ApplicationId as ApplicationID,
app.PartyID as PortalAppPartyID,basicInfo.PFieldID as FiledName,section.sectionName as SectionName,section.code as SectionCode,
basicInfo.InfoID as InfoID,note.NoteID as NoteID,note.ReasonCode as ReasonCode,app.CaseID as PortalCaseID,basicInfo.CaseID as ENCaseID
,note.PInID as PInID,person.EIN as portalSSN,AccP.PartyId as AccountPartyID,AccP.OrgID as AccountPersonID,AccP.EIN as AccountSSN,
package.packageName as PackageName,package.applicationCode as PackageCode,section.subFormId as SectionSubFormId,
person.OrgID as portalpersonID, finding.FieldStatusID as PortalFindingID,
case when note.Type = 'Application Review' then 'APP REVIEW' 
			when note.Type = 'RELATED ACCOUNTS' then note.Type
			else 'SCREENING' end as category,
CASE WHEN note.ExternalYesNO IS NULL THEN 'N/D'
				 WHEN (note.ExternalYesNO = '1' or note.ExternalYesNO = 'Yes') THEN
						'EXTERNAL' 
				WHEN (note.ExternalYesNO = '0' or note.ExternalYesNO = 'NO')  THEN
						'INTERNAL' 
				ELSE NULL END As isexternaldesc,
(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u where p.PersonID = u.PersonID and u.UserID= note.UserID) as addedby,
note.DateCreated as Addedon,
note.status as status,
note.DocumentCount as DocumentCount	

FROM KYPPORTAL.PortalKYP.pADM_Application app
inner join KYPPORTAL.PortalKYP.Cfg_FormPackage package on app.ApplicationCode = package.applicationCode
inner join KYP_OMS34.KYP.MDM_JournalBasicInfo basicInfo on basicInfo.PAppID=app.ApplicationID and IsIgnored=0
INNER JOIN KYP_OMS34.KYP.OIS_Note note on basicInfo.InfoID = note.PInID
inner join KYPPORTAL.PortalKYP.Enrollment_FieldStatus finding on app.ApplicationId=finding.ApplicationId and ElementType<>'Document' and basicInfo.PFieldID = finding.FieldID 
and basicInfo.PartyID=finding.PartyID
inner join KYPPORTAL.PortalKYP.Cfg_Section section on  finding.SubFormID = section.subFormId  AND finding.FormID = section.formId and package.packageId = section.packageId and section.sectionId=finding.SectionID
inner join KYPPORTAL.PortalKYP.pPDM_Organization person on person.PartyID=finding.PartyID
inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.PartyID= finding.PartyID
inner Join (Select P.PartyId,Per.EIN,per.OrgID
		From KYP_OMS34.KYPEnrollment.pAccount_PDM_Party P
		Join KYP_OMS34.KYPEnrollment.pAccount_PDM_Organization Per on P.PartyID=Per.PartyId
		Where P.Type='Entity Ownership') AccP on Person.EIN = AccP.EIN
where note.ReasonCode='Application Update' and party.Type='Entity Ownership'  
--and app.ApplicationNo='187CJBUI' 


GO

