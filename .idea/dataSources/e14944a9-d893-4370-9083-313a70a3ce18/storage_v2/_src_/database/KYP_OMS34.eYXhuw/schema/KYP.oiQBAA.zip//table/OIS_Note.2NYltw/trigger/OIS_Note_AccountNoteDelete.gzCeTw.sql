

CREATE TRIGGER [KYP].[OIS_Note_AccountNoteDelete] ON [KYP].[OIS_Note]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
BEGIN

    Declare @NoteNumber 	varchar(100)
	Declare @NoteEntityDep 	varchar(100)
	Declare @IsDeleted 		varchar(4)
	Declare @OldIsDeleted 	varchar(4)
    Declare @pActionID		int
    Declare @CreatedBy varchar(100)
	Declare @AccountID varchar(100)
	Declare @HistoryID int
	Declare @Title varchar(100)
	DECLARE @Row_Updation_Source VARCHAR(100)

	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF isnull(@Row_Updation_Source,'') in ( 'KYP.p_InsertOISNote') AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END	

    Set @NoteNumber 		= (Select top 1 Number from Inserted order by noteid desc)

	Set @IsDeleted		 	= (Select top 1 isnull(Deleted,0) from Inserted order by noteid desc)
	Set @OldIsDeleted 		= (Select top 1 isnull(Deleted,0) from Deleted order by noteid desc)
	Set @NoteEntityDep 		= (Select top 1 NoteEntityDep from KYP.NoteEntity where NoteNumber = @NoteNumber and NoteEntityDep = 'pADM_Account' order by NoteEntityID desc)
    Set @pActionID			= 0
    
    if(@NoteEntityDep = 'pADM_Account')
    BEGIN
           
    	if update(Deleted) and @IsDeleted<>@OldIsDeleted and (@IsDeleted = 1 or @IsDeleted is null)
        Begin
        	set @pActionID = 46
	        Set @CreatedBy 	= (Select Top 1 DeletedBy from Inserted)

        END
        else
        if @IsDeleted=@OldIsDeleted
        BEGIN
        	set @pActionID = 45
	        Set @CreatedBy 	= (Select Top 1 UpdatedBy from Inserted)
 
		END
        
        if @pActionID>0 --updata has happened
        BEGIN
			print 'Account Note has been deleted'

			Set @AccountID 	= (Select top 1 NoteEntityDepID from KYP.NoteEntity where NoteNumber = @NoteNumber and NoteEntityDep = 'pADM_Account')
			Set @Title		= (Select Top 1 Name from Inserted)

			INSERT INTO 
			KYPEnrollment.pAccount_History
			(
			AccountID,
			ActionID,
			DateCreated,
			IsDeleted,
			LastActorUserID,
			LastActionDate
			) 
			VALUES (
			@AccountID,
			@pActionID,
			getdate(),
			0,
			@CreatedBy,
			getdate()  
			)
			
			set @HistoryID = (SELECT SCOPE_IDENTITY());
			print @HistoryID

			INSERT INTO 
			KYPEnrollment.HIS_Note
			(
			HistoryID,
			DateCreate,
			IsDeleted,
			NoteNumber,
			NoteTitle
			) 
			VALUES (
			@HistoryID,
			getDate(),
			0,
			@NoteNumber,
			@Title
			);
        End
    	
    END
    
END

GO

