
/******Script for update procedure************/
CREATE PROCEDURE [KYP].[p_UpdatePDMProvider] (
	@PartyID INT
	,@Category VARCHAR(15) = NULL
	,@Type VARCHAR(50) = NULL
	,@PrimarySpecialty VARCHAR(255) = NULL
	,@SecondSpecialty VARCHAR(150) = NULL
	,@NPI INT = NULL
	,@UPIN VARCHAR(6) = NULL
	,@CCN VARCHAR(6) = NULL
	,@HIN VARCHAR(9) = NULL
	,@Remarks VARCHAR(250) = NULL
	,@IsEnrolled BIT = NULL
	,@ProvNumber VARCHAR(20) = NULL
	,@CurrentModule INT = NULL
	,@Mon_MedicaidID VARCHAR(20) = NULL
	,@EnrolledSince DATETIME = NULL
	,@CreatedBy INT = NULL
	,@DateCreated DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified DATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted DATETIME = NULL
	,@IsDeleted BIT = NULL
	,@DEA VARCHAR(20) = NULL
	,@NABP_Num VARCHAR(15) = NULL
	,@AccGenNumber VARCHAR(50) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF ISNULL(@NPI, '') = ''
	BEGIN
		SET @NPI = NULL;
	END

	IF ISNULL(@IsEnrolled, '') = ''
	BEGIN
		SET @IsEnrolled = NULL;
	END

	IF ISNULL(@EnrolledSince, '') = ''
	BEGIN
		SET @EnrolledSince = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Category, '')))) = ''
	BEGIN
		SET @Category = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Type, '')))) = ''
	BEGIN
		SET @Type = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@PrimarySpecialty, '')))) = ''
	BEGIN
		SET @PrimarySpecialty = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@SecondSpecialty, '')))) = ''
	BEGIN
		SET @SecondSpecialty = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@UPIN, '')))) = ''
	BEGIN
		SET @UPIN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@CCN, '')))) = ''
	BEGIN
		SET @CCN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@HIN, '')))) = ''
	BEGIN
		SET @HIN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remarks, '')))) = ''
	BEGIN
		SET @Remarks = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@ProvNumber, '')))) = ''
	BEGIN
		SET @ProvNumber = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Mon_MedicaidID, '')))) = ''
	BEGIN
		SET @Mon_MedicaidID = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@DEA, '')))) = ''
	BEGIN
		SET @DEA = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@NABP_Num, '')))) = ''
	BEGIN
		SET @NABP_Num = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@AccGenNumber, '')))) = ''
	BEGIN
		SET @AccGenNumber = NULL;
	END

	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END

	IF ISNULL(@IsDeleted, '') = ''
	BEGIN
		SET @IsDeleted = NULL;
	END

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_Provider] Set '

	IF @Category IS NOT NULL
		SET @updatelist = '[Category] = ''' + @Category + ''''

	IF @Type IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Type] = ''' + replace(@Type, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Type] = ''' + replace(@Type, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @PrimarySpecialty IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PrimarySpecialty] = ''' + replace(@PrimarySpecialty, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[PrimarySpecialty] = ''' + replace(@PrimarySpecialty, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @SecondSpecialty IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[SecondSpecialty] = ''' + replace(@SecondSpecialty, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[SecondSpecialty] = ''' + replace(@SecondSpecialty, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @NPI IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[NPI] = ' + Convert(VARCHAR(12), @NPI)
		ELSE
			SET @updatelist = '[NPI] = ' + Convert(VARCHAR(12), @NPI)
	END

	IF @UPIN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[UPIN] = ''' + replace(@UPIN, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[UPIN] = ''' + replace(@UPIN, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @CCN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CCN] = ''' + replace(@CCN, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[CCN] = ''' + replace(@CCN, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @HIN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[HIN] = ''' + replace(@HIN, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[HIN] = ''' + replace(@HIN, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Remarks IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @IsEnrolled IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsEnrolled] = ' + CAST(@IsEnrolled AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsEnrolled] = ' + CAST(@IsEnrolled AS VARCHAR(1)) + ''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	IF @Mon_MedicaidID IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Mon_MedicaidID] = ''' + replace(@Mon_MedicaidID, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Mon_MedicaidID] = ''' + replace(@Mon_MedicaidID, '''', CHAR(39) + CHAR(39)) + ''''
	END

	---------------------------------------------------------------------------------------------------------------------
	-- START - Changes for KYP-2827 - Improper Type Data
	---------------------------------------------------------------------------------------------------------------------
	IF @ProvNumber IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProvNumber] = ''' + REPLACE(@ProvNumber, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[ProvNumber] = ''' + REPLACE(@ProvNumber, '''', CHAR(39) + CHAR(39)) + ''''
	END

	---------------------------------------------------------------------------------------------------------------------
	-- END - Changes for KYP-2827 - Improper Type Data
	---------------------------------------------------------------------------------------------------------------------
	IF @EnrolledSince IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[EnrolledSince] = ''' + convert(VARCHAR(25), @EnrolledSince, 121) + ''''
		ELSE
			SET @updatelist = '[EnrolledSince] = ''' + convert(VARCHAR(25), @EnrolledSince, 121) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	IF @DEA IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DEA] = ''' + replace(@DEA, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[DEA] = ''' + replace(@DEA, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @NABP_Num IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[NABP_Num] = ''' + replace(@NABP_Num, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[NABP_Num] = ''' + replace(@NABP_Num, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @AccGenNumber IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[AccGenNumber] = ''' + convert(VARCHAR(50), @AccGenNumber) + ''''
		ELSE
			SET @updatelist = '[AccGenNumber] = ''' + convert(VARCHAR(50), @AccGenNumber) + ''''
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
		-- START - Changes for KYP-2827 - Improper Type Data
		+ ' AND ProvNumber = ''' + CONVERT(VARCHAR(15), @ProvNumber) + ''''
	-- END - Changes for KYP-2827 - Improper Type Data
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

