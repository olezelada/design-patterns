
/******Script for update procedure************/
CREATE PROCEDURE [KYP].[p_UpdatePDMLicense] (
	@PartyID INT
	,@LicenseAuthority VARCHAR(100) = NULL
	,@EffectiveDate DATETIME = NULL
	,@ExpiryDate DATETIME = NULL
	,@LicenseType VARCHAR(25) = NULL
	,@LicenseSubType VARCHAR(25) = NULL
	,@LicenseCode VARCHAR(25) = NULL
	,@Remarks VARCHAR(250) = NULL
	,@CurrentModule SMALLINT = NULL
	,@CreatedBy INT = NULL
	,@DateCreated DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified DATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted DATETIME = NULL
	,@IsDeleted BIT = NULL
	,@LicenseState VARCHAR(50) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF (LTRIM(RTRIM(ISNULL(@LicenseAuthority, '')))) = ''
	BEGIN
		SET @LicenseAuthority = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LicenseType, '')))) = ''
	BEGIN
		SET @LicenseType = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LicenseSubType, '')))) = ''
	BEGIN
		SET @LicenseSubType = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LicenseCode, '')))) = ''
	BEGIN
		SET @LicenseCode = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remarks, '')))) = ''
	BEGIN
		SET @Remarks = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LicenseState, '')))) = ''
	BEGIN
		SET @LicenseState = NULL;
	END

	IF ISNULL(@EffectiveDate, '') = ''
	BEGIN
		SET @EffectiveDate = NULL;
	END

	IF ISNULL(@ExpiryDate, '') = ''
	BEGIN
		SET @ExpiryDate = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END

	IF ISNULL(@IsDeleted, '') = ''
	BEGIN
		SET @IsDeleted = NULL;
	END

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_License] Set '

	IF @LicenseAuthority IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LicenseAuthority] = ''' + replace(@LicenseAuthority, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LicenseAuthority] = ''' + replace(@LicenseAuthority, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @EffectiveDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[EffectiveDate] = ''' + convert(VARCHAR(25), @EffectiveDate, 121) + ''''
		ELSE
			SET @updatelist = '[EffectiveDate] = ''' + convert(VARCHAR(25), @EffectiveDate, 121) + ''''
	END

	IF @ExpiryDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ExpiryDate] = ''' + convert(VARCHAR(25), @ExpiryDate, 121) + ''''
		ELSE
			SET @updatelist = '[ExpiryDate] = ''' + convert(VARCHAR(25), @ExpiryDate, 121) + ''''
	END

	IF @LicenseType IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LicenseType] = ''' + replace(@LicenseType, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LicenseType] = ''' + replace(@LicenseType, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @LicenseSubType IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LicenseSubType] = ''' + replace(@LicenseSubType, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LicenseSubType] = ''' + replace(@LicenseSubType, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @LicenseCode IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LicenseCode] = ''' + replace(@LicenseCode, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LicenseCode] = ''' + replace(@LicenseCode, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Remarks IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	IF @LicenseState IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LicenseState] = ''' + replace(@LicenseState, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LicenseState] = ''' + replace(@LicenseState, '''', CHAR(39) + CHAR(39)) + ''''
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

