CREATE VIEW [KYP].[v_GetDistinctPartyAddress]
AS

SELECT     TOP (100) PERCENT row_number() OVER (ORDER BY PartyID ASC) AS ID, PartyID, Address, Address1, City, State, Zip
FROM         KYP.MDM_PartyAddress GROUP BY Address,  PartyID, Address1, City, State, Zip order by PartyID


GO

