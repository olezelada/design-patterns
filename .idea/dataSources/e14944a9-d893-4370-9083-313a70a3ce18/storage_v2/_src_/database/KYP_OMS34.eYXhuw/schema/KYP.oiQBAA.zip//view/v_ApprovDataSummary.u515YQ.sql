

CREATE VIEW [KYP].[v_ApprovDataSummary] 
AS
	SELECT 
	ROW_NUMBER() over(order by A.CaseID Desc) As RID,
	A.CaseID,
	A.ProviderName,A.Number,
	COALESCE(LTRIM(RTRIM(NULLIF(A.AccountNo,''))),'NA') As AccountNo,
	COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
	COALESCE(LTRIM(RTRIM(NULLIF(A.ApplnTypeAlias,''))),'NA') As ApplnType,
	COALESCE(LTRIM(RTRIM(NULLIF(A.TypeDescription,''))),'NA') As TypeDescription,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DateReceived as date), 101),''))),'NA') As DateReceivedAlias,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DateResolved as date), 101),''))),'NA') As DateResolvedAlias,
	COALESCE(LTRIM(RTRIM(NULLIF(A.UserFullName,''))),'NA') As UserFullName,
	A.WFStatus,A.IsPPURequired,A.ResolutionStatus, B.LegacyAccountNo, B.StateStatusAcc, A.DateReceived, A.DateResolved
FROM KYP.ADM_Case A 
Join kypenrollment.pADM_Account B on A.AccountNo = B.AccountNumber
WHERE A.IsPPURequired = 0 AND ISNULL(A.DateResolved,'') != '' AND A.WFStatus = 'Completed' 
	AND A.ResolutionStatus IN ('Enrolled/Provisional Status Granted','Approved','Approve')


GO

