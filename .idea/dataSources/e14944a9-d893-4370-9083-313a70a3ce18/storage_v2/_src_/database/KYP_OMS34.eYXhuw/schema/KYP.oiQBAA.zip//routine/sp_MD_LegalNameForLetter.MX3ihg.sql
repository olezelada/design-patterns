







/* ==========================================================
-- Author:		<Rahul>
-- PROCEDURE: create ExternalFindingsForLetter.   
-- PARAMETERS: @Number,@UserID

-- ============================================================*/


CREATE PROCEDURE [KYP].[sp_MD_LegalNameForLetter]
	@Number varchar(50),
	@Username varchar (50),
	@P_PRACT_TY_CD varchar(50)

AS

if(@P_PRACT_TY_CD='Accounts')
BEGIN 
INSERT INTO KYP.MD_LegalNameForLetter
			   (
			  ProviderName, 
			  UserID, 
			  Number
			  )

					  
					select GA.LegalName,@Username,GA.AccountNumber
					from KYPEnrollment.pADM_Account A 
					Inner Join kypenrollment.pAccount_RenderingAffiliation RA on Ra.AffiliatedAccountID=A.AccountID	
					Inner Join KYPEnrollment.pADM_Account GA on GA.AccountID = RA.AccountID
					WHERE A.AccountID=@Number
						
					

END
ELSE
BEGIN
	INSERT INTO KYP.MD_LegalNameForLetter
			   (
			  ProviderName, 
			  UserID, 
			  Number
			  )

							select p2.ProviderName,@Username,p2.Number
							from kyp.ADM_Case A1
							Inner Join KYPPORTAL.PortalKYP.pRenderingAffiliation p1 on P1.rendering_providerNumber=A1.Number 
							Inner Join KYPPORTAL.PortalKYP.pADM_Case p2 on p2.Number=p1.group_providerNumber  
							Where ISNUMERIC(p1.group_providerNumber)=0 
							and (A1.ApplnType  in ('New Rendering','Rendering-S') or A1.P_PRACT_TY_CD in ('Rendering','RS','NMP')) 
							and A1.Number=@Number --and AccountNo is null
					 
					UNION
							 select p2.LegalName,@Username,p2.AccountNumber
							 from kyp.ADM_Case A1
							 Inner Join KYPPORTAL.PortalKYP.pRenderingAffiliation p1 on P1.rendering_providerNumber=A1.Number 
							 Inner Join KYPEnrollment.pADM_Account p2 on p2.AccountNumber=p1.group_providerNumber
							 where ISNUMERIC(p1.group_providerNumber)=1 
							 and A1.ApplnType  in ('New Rendering','Rendering-S') and A1.Number=@Number --and AccountNo is null
					UNION 

							select p2.LegalName,@Username,p2.AccountNumber
							from kyp.ADM_Case A1
							Inner Join KYPPORTAL.PortalKYP.pRenderingAffiliation p1 on P1.rendering_providerNumber=A1.Number 
							Inner join KYPPORTAL.PortalKYP.pAffiliationServiceAddress p3 on p3.rendering_affiliation_id=p1.rendering_affiliation_id
							Inner Join KYPEnrollment.pADM_Account p2 on p2.AccountID=p3.accountId
							where ISNUMERIC(p1.group_providerNumber)=1 
							and A1.ApplnType  in ('New Rendering','Rendering-S') and A1.Number=@Number --and AccountNo is null

END


GO

