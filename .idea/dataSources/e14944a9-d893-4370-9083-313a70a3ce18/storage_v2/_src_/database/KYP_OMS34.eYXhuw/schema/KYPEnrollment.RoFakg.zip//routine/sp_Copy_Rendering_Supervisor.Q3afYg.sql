
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Rendering Supervisor.   
-- PARAMETERS:  
-- @application_no : Application Number that will be Account. 
-- @account_rendering_affiliation_id : AccountID that will be Create. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Rendering_Supervisor]
@application_no VARCHAR(15),
@account_rendering_affiliation_id INT,
@affiliation_id INT = NULL

AS
BEGIN
	SET NOCOUNT ON
	DECLARE
		@application_id INT,
		@date_create DATE,
		@count_affiliation INT,
		@rendering_affiliation_id INT

	BEGIN TRY
		SET @date_create= GETDATE();

	 	IF @affiliation_id IS NULL
	 	BEGIN
			SELECT @rendering_affiliation_id = rendering_affiliation_id FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] WHERE rendering_providerNumber = @application_no;
			INSERT INTO [KYPEnrollment].[pAccount_RenderingSupervisor]
				([RenderingAffiliationId]
				,[InstanceId]
				,[ProviderNumber]
				,[Npi]
				,[Name]
				,[LicenseOrID]
				,[LicenseOrIdNumber]
				,[ProfessionalLicense]
				,[isAccount]
				,[isDeleted]
				,[dateCreated]
				,[LicenseExpirationDate])
			SELECT @account_rendering_affiliation_id,
					[InstanceId],
					[ProviderNumber],
					[Npi],
					[Name],
					[LicenseOrID],
					[LicenseOrIdNumber],
					[ProfessionalLicense],
					[isAccount],
					[isDeleted],
					@date_create,
					[LicenseExpirationDate]
			FROM [KYPPORTAL].[PortalKYP].[pRenderingSupervisor] WHERE RenderingAffiliationId = @rendering_affiliation_id
		END
		ELSE
		BEGIN
			INSERT INTO [KYPEnrollment].[pAccount_RenderingSupervisor]
					([RenderingAffiliationId]
					,[InstanceId]
					,[ProviderNumber]
					,[Npi]
					,[Name]
					,[LicenseOrID]
					,[LicenseOrIdNumber]
					,[ProfessionalLicense]
					,[isAccount]
					,[isDeleted]
					,[dateCreated]
					,[LicenseExpirationDate])
				SELECT @account_rendering_affiliation_id,
						[InstanceId],
						[ProviderNumber],
						[Npi],
						[Name],
						[LicenseOrID],
						[LicenseOrIdNumber],
						[ProfessionalLicense],
						[isAccount],
						[isDeleted],
						@date_create,
						[LicenseExpirationDate]
				FROM [KYPPORTAL].[PortalKYP].[pRenderingSupervisor] WHERE RenderingAffiliationId = @affiliation_id
		END

	PRINT 'NEW SUPERVISOR'
	END TRY
	BEGIN CATCH
		IF @@TranCount>0
			Rollback Transaction;
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'application_no',@KeyValue = @application_no;
	END CATCH
END

GO

