
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: 
-- PARAMETERS: 

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Create_Significat_TaxId]
@party_id INT,
@Type VARCHAR(20),
@significatName VARCHAR(150),
@party_provider_id INT

AS
BEGIN
SET NOCOUNT ON 
PRINT'[Create_Significat_TaxID]'
INSERT INTO [KYPEnrollment].[pAccount_Significat_TaxID_Associate]
           ([PartyID]        
           ,[SignificatName]
           ,[Type]
           ,IdentityTaxID
           ,[CurrentRecordFlag])
     VALUES
           (@party_id
           ,@significatName
           ,@Type
           ,@party_provider_id
           ,1)

END


GO

