

CREATE TRIGGER [KYP].[trg_CaseAgeDailyBulk] 
   ON  [KYP].[CaseAge_Daily_Bulk]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;	
		
	
	DECLARE @currentSate varchar(30);
	DECLARE @Weekends varchar(20);
	SELECT @currentSate = StateCode from kyp.OIS_App_Version; 
	/************************************************MD PRODUCT LINE CASE AGING TIME CLOCK BLOCK START*******************************/
	if(@currentSate='MD')
	BEGIN
	    SELECT  @Weekends=DATENAME(WEEKDAY ,GETDATE()) 
		IF(@Weekends='Saturday' or @Weekends='Sunday')
		BEGIN	
			UPDATE KYP.ADM_Case SET DAYS_REMAINING = DAYS_REMAINING - 1	WHERE DAYS_REMAINING IS NOT NULL 
			AND CAST(DateReceived As DATE) != CAST(GETDATE() As DATE) 
			AND IsPPURequired = 0 AND Status='RTP'
			
			UPDATE KYP.ADM_CaseExtended SET CaseAgeDaysRemaining = CaseAgeDaysRemaining - 1 
			where CaseID in ( Select Caseid from KYP.ADM_Case where IsPPURequired = 0 AND Status='RTP')
		END
		ELSE
		BEGIN
			UPDATE C SET c.DAYS_REMAINING = CASE WHEN c.DAYS_REMAINING < ex.CaseAgeDaysRemaining  THEN c.DAYS_REMAINING
			WHEN (c.WFMajorStep IN ('Completed') OR c.CurrentMinorDisposition = 'Referred' 
			OR  c.CurrentMinorDisposition = 'Referred to Referrer') THEN c.DAYS_REMAINING ELSE  c.DAYS_REMAINING - 1 END
			from KYP.ADM_CaseExtended ex join KYP.ADM_Case c on c.CaseID = ex.CaseID 
			WHERE DAYS_REMAINING IS NOT NULL 
			AND CAST(DateReceived As DATE) != CAST(GETDATE() As DATE) 
			AND IsPPURequired = 0 
				
			UPDATE KYP.ADM_CaseExtended SET CaseAgeDaysRemaining = CaseAgeDaysRemaining - 1
		END
	/** Setting the Threshold based on Days and Application Type **/
	
	
	--Begin ModifiedBy: Rajesh Singh 
	UPDATE KYP.ADM_Case SET THRESHOLD = CASE 
	
				WHEN DAYS_REMAINING = 2 AND ApplnType in('New','New Rendering','New Group','Reenrollment','Revalidation') THEN 'Normal'		
				WHEN DAYS_REMAINING = 1 AND ApplnType in('New','New Rendering','New Group','Reenrollment','Revalidation') THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND ApplnType in ('New','New Rendering','New Group','Reenrollment','Revalidation') THEN 'OverDue'
				
				WHEN DAYS_REMAINING = 2 AND ApplnType in ('Supplemental','Disaffiliation','CHOW','Rendering-S','CHOA','Disenrollment') THEN 'Normal'
				WHEN DAYS_REMAINING = 1 AND ApplnType in ('Supplemental','Disaffiliation','CHOW','Rendering-S','CHOA','Disenrollment') THEN 'Critical'			
				WHEN DAYS_REMAINING <= 0 AND ApplnType in ('Supplemental','Disaffiliation','CHOW','Rendering-S','CHOA','Disenrollment') THEN 'OverDue'
				
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND (Status  = 'RTP' OR ActivityStatus  = 'Re-Submit') THEN 'Normal'
				WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 10 AND (Status  = 'RTP' OR ActivityStatus  = 'Re-Submit') THEN 'Warning'			
				WHEN DAYS_REMAINING <= 10 AND DAYS_REMAINING > 0 AND  (Status  = 'RTP' OR ActivityStatus  = 'Re-Submit') THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND (Status  = 'RTP' OR ActivityStatus  = 'Re-Submit') THEN 'OverDue'
				
				ELSE NULL END WHERE DAYS_REMAINING IS NOT NULL 
				AND CAST(DateReceived As DATE) != CAST(GETDATE() As DATE) 
				AND IsPPURequired = 0
	-- End OF Rajesh Singh---			
	    -- Insert statements for trigger here	   	    
	    /** UPDATING DaysWithReferral Column - To Display in Referred Application Reports **/
	    UPDATE KYP.ADM_Case 
	    SET DaysWithReferral = isnull(DaysWithReferral,0) + 1
	    WHERE (CurrentMinorDisposition = 'Referred' OR  CurrentMinorDisposition = 'Referred to Referrer')
	    AND ReferralDate IS NOT NULL 
	    AND WFMajorStep NOT IN ('Completed')
	    AND RevertDate is NULL
	    AND CAST(ReferralDate As DATE) != CAST(GETDATE() As DATE) 
		AND IsPPURequired = 0
	    
	    
	    /** UPDATING DaysPostRevert Column - To Display in Referred Application Reports **/
	    UPDATE KYP.ADM_Case 
	    SET DaysPostRevert = CASE WHEN RevertDate IS NULL Then
										 NULL
										 Else 
										 DATEDIFF(DD,RevertDate,GETDATE())
										 End
		WHERE IsPPURequired = 0
		AND WFMajorStep <> 'Completed'
END
/************************************************MD PRODUCT LINE CASE AGING TIME CLOCK BLOCK END*******************************/

ELSE
/************************************************CA PRODUCT LINE CASE AGING TIME CLOCK START*******************************/
BEGIN

		UPDATE KYP.ADM_Case SET DAYS_REMAINING = CASE WHEN WFMajorStep IN ('Completed') OR CurrentMinorDisposition = 'Referred' THEN DAYS_REMAINING ELSE DATEDIFF(DD,GETDATE(),DueDate) END
		WHERE DAYS_REMAINING IS NOT NULL 
		AND CAST(DateReceived As DATE) != CAST(GETDATE() As DATE) 
		AND IsPPURequired = 0
		
	/** Setting the Threshold based on Days and Application Type **/
	
	
	UPDATE KYP.ADM_Case SET THRESHOLD = CASE 
		
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING >= 30 AND PrefferedProvider = 'Preferred' AND Description is null THEN 'Warning'
				--WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 10 AND PrefferedProvider = 'Preferred' AND Description is null THEN 'Warning'			
				WHEN DAYS_REMAINING < 30 AND DAYS_REMAINING > 0 AND PrefferedProvider = 'Preferred' AND Description is null THEN 'Critical'
				WHEN DAYS_REMAINING < 0 AND PrefferedProvider = 'Preferred' AND Description is null THEN 'OverDue'
				
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND (Status  = 'RTP' OR Resubmitted  = '-R') THEN 'Normal'
				WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 10 AND (Status  = 'RTP' OR Resubmitted  = '-R') THEN 'Warning'			
				WHEN DAYS_REMAINING <= 10 AND DAYS_REMAINING > 0 AND  (Status  = 'RTP' OR Resubmitted  = '-R') THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND (Status  = 'RTP' OR Resubmitted  = '-R') THEN 'OverDue'
				
				--WHEN DAYS_REMAINING <= 90 AND DAYS_REMAINING > 60 AND  (ApplnType  != 'Supplemental' AND TypeDescription  = 'Mixed Group') THEN 'Normal'
				WHEN DAYS_REMAINING <= 180 AND DAYS_REMAINING > 60 AND (ApplnType  != 'Supplemental' AND TypeDescription  = 'Mixed Group' AND Description is null) THEN 'Normal'
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND (ApplnType  != 'Supplemental' AND TypeDescription  = 'Mixed Group' AND Description is null) THEN 'Warning'			
				WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 0 AND  (ApplnType  != 'Supplemental' AND TypeDescription  = 'Mixed Group' AND Description is null) THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND (ApplnType  != 'Supplemental' AND TypeDescription  = 'Mixed Group' AND Description is null) THEN 'OverDue'
				
				WHEN DAYS_REMAINING <= 90 AND DAYS_REMAINING > 60 AND (ApplnType  = 'Supplemental' AND (ProviderTypeCode = '026' OR ProviderTypeCode = '022') AND Description is null) THEN 'Normal'
				WHEN DAYS_REMAINING <= 180 AND DAYS_REMAINING > 60 AND (ApplnType  = 'Supplemental' AND (ProviderTypeCode != '026' OR ProviderTypeCode != '022') AND Description is null) THEN 'Normal'
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND (ApplnType  = 'Supplemental') AND Description is null THEN 'Warning'			
				WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 0 AND  (ApplnType  = 'Supplemental') AND Description is null THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND (ApplnType  = 'Supplemental') AND Description is null THEN 'OverDue'
				
				WHEN DAYS_REMAINING <= 90 AND DAYS_REMAINING > 60 AND (SupUpdateFlag  IN ('06','07','08','09','13') AND (ProviderTypeCode = '026' OR ProviderTypeCode = '022') AND Description is null) THEN 'Normal'
				WHEN DAYS_REMAINING <= 180 AND DAYS_REMAINING > 60 AND (SupUpdateFlag  IN ('06','07','08','09','13') AND (ProviderTypeCode != '026' OR ProviderTypeCode != '022') AND Description is null) THEN 'Normal'
				WHEN DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND (SupUpdateFlag  IN ('06','07','08','09','13') AND Description is null) THEN 'Warning'			
				WHEN DAYS_REMAINING <= 30 AND DAYS_REMAINING > 0 AND  (SupUpdateFlag  IN ('06','07','08','09','13') AND Description is null) THEN 'Critical'
				WHEN DAYS_REMAINING <=0 AND (SupUpdateFlag  IN ('06','07','08','09','13') AND Description is null) THEN 'OverDue'
				
				WHEN SupUpdateFlag IN ('01','04','11','12') AND ProviderTypeCode = '026' AND DAYS_REMAINING <= 90 AND DAYS_REMAINING > 60 AND Description is null THEN 'Normal'
				WHEN SupUpdateFlag IN ('01','04','11','12') AND ProviderTypeCode != '026' AND DAYS_REMAINING <= 180 AND DAYS_REMAINING > 60 AND Description is null THEN 'Normal'
				WHEN SupUpdateFlag IN ('01','04','11','12') AND DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND Description is null THEN 'Warning'
				WHEN SupUpdateFlag IN ('01','04','11','12') AND DAYS_REMAINING <= 30 AND DAYS_REMAINING > 0 AND Description is null THEN 'Critical'
				WHEN SupUpdateFlag IN ('01','04','11','12') AND DAYS_REMAINING <= 0 AND Description is null  THEN 'OverDue'
				
				WHEN SupUpdateFlag IN ('02','03','11','12') AND ProviderTypeCode = '022' AND DAYS_REMAINING <= 90 AND DAYS_REMAINING > 60 AND Description is null THEN 'Normal'
				WHEN SupUpdateFlag IN ('02','03','11','12') AND ProviderTypeCode != '022' AND DAYS_REMAINING <= 180 AND DAYS_REMAINING > 60 AND Description is null THEN 'Normal'
				WHEN SupUpdateFlag IN ('02','03','11','12') AND DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 AND Description is null THEN 'Warning'
				WHEN SupUpdateFlag IN ('02','03','11','12') AND DAYS_REMAINING <= 30 AND DAYS_REMAINING > 0 AND Description is null THEN 'Critical'
				WHEN SupUpdateFlag IN ('02','03','11','12') AND DAYS_REMAINING <= 0 AND Description is null THEN 'OverDue'
				
				WHEN Description = 'Revert' AND DAYS_REMAINING <= 60 AND DAYS_REMAINING > 30 THEN 'Normal'
				WHEN Description = 'Revert' AND DAYS_REMAINING <= 30 AND DAYS_REMAINING > 10 THEN 'Warning'
				WHEN Description = 'Revert' AND DAYS_REMAINING <= 10 AND DAYS_REMAINING > 0 THEN 'Critical'
				WHEN Description = 'Revert' AND DAYS_REMAINING <= 0 THEN 'OverDue'
				
				ELSE NULL END WHERE DAYS_REMAINING IS NOT NULL 
				AND CAST(DateReceived As DATE) != CAST(GETDATE() As DATE) 
				AND IsPPURequired = 0
				
	    -- Insert statements for trigger here	
	    
	       	    
	    /** UPDATING DaysWithReferral Column - To Display in Referred Application Reports **/
	    UPDATE KYP.ADM_Case 
	    SET DaysWithReferral = isnull(DaysWithReferral,0) + 1
	    WHERE (CurrentMinorDisposition = 'Referred' OR  CurrentMinorDisposition = 'Referred to Referrer')
	    AND ReferralDate IS NOT NULL 
	    AND WFMajorStep NOT IN ('Completed')
	    AND RevertDate is NULL
	    AND CAST(ReferralDate As DATE) != CAST(GETDATE() As DATE) 
		AND IsPPURequired = 0
	    
	    
	    
	    /** UPDATING DaysPostRevert Column - To Display in Referred Application Reports **/
	    UPDATE KYP.ADM_Case 
	    SET DaysPostRevert = CASE WHEN RevertDate IS NULL Then
										 NULL
										 Else 
										 DATEDIFF(DD,RevertDate,GETDATE())
										 End
		WHERE IsPPURequired = 0
		AND WFMajorStep <> 'Completed'
	   END
	   /************************************************CA PRODUCT LINE CASE AGING TIME CLOCK END*******************************/
END


GO

