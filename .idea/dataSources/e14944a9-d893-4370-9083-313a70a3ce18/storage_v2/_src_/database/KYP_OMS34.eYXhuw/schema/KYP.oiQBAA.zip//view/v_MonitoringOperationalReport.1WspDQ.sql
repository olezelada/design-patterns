CREATE VIEW [KYP].[v_MonitoringOperationalReport]
AS
SELECT row_number() OVER (ORDER BY B.AlertID ASC) AS ID,
	B.AlertID,
	B.AlertNo, 
	
	B.WatchlistName,
	B.MatchPercent,
	B.DateInitiated,
	CASE
		WHEN B.MatchStatusIndicator = 'F'
			THEN 'False Positive'
		 WHEN B.MatchStatusIndicator = 'I'
			THEN 'Ignored'
		WHEN B.MatchStatusIndicator = 'C'
			THEN 'Confirmed'
		WHEN B.MatchStatusIndicator = 'U'
			THEN 'Unconfirmed'
	END AS DetailStatus,
	B.DateClosed,
	D.UserID as AssignedToUserID,
	D.FullName as AssignmentUserIDName,
	A.ResolutionID,
	A.ResolutionType,
	A.ResolutionTypeID,
	F.ProviderID, 
	F.ProviderName,
	H.ProviderTypeDescription as ProviderType, 
	A.ResolutionDate as ResolutionDate, 
	A.ResolutionByUserID,
	C.Userid as ResolutionUserIDName,
	G.Mon_MedicaidID as MedicaidID,
	case 
		when B.CurrentWFStatus = 'CloseAlert'
			then 'Closed'
		else 'Open'	
	end as AlertStatus,
	DATEDIFF(DD, DateInitiated, GETDATE()) AS 'AlertAge'
	from 
	KYP.MDM_AlertResolution A
	INNER JOIN  KYP.MDM_Alert B
	ON A.AlertId = B.AlertID
	LEFT JOIN KYP.OIS_User C
	ON A.ResolutionByUserID = C.PersonID	
	LEFT JOIN KYP.OIS_User D
	ON B.AssignedToUserID = D.PersonID
	inner join KYP.MDM_SearchProviders F
	ON F.ALertID=A.AlertID and F.ProviderID =A.ProviderID
	inner join KYP.PDM_Provider G
	on G.ProvID=F.ProviderID
	inner join KYP.PDM_ProviderTypeCode H
	on G.Type=H.ProviderTypeCode
	
WHERE ISNULL(A.IsDeleted,0) =0 AND  ISNULL(B.IsDeleted,0) =0
and Impacted =1


GO

