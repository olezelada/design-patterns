






-- =============================================
-- Authors:   <RAlba, TJaldin>
-- Script Date: 11/13/2015
-- =============================================
CREATE TRIGGER [KYP].[CopyAccount] ON [KYP].[ADM_Case]
	WITH EXECUTE AS CALLER
FOR

UPDATE AS


BEGIN
	--SET IMPLICIT_TRANSACTIONS ON
	DECLARE @priority INT
		,@risk VARCHAR(50)
		,@compositeRisk INT
		,@applicatioNo VARCHAR(50)
		,@resolutionStatus VARCHAR(100)
		,@mileston VARCHAR(100)
		,@sStatus VARCHAR(100)
		,@activityStatus VARCHAR(100)
		,@id INT
		,@Number VARCHAR(50)
		,@AppNumber VARCHAR(50)
		,@SupUpdateFlag VARCHAR(20)
		,@lastActionUserID NVARCHAR(100)
		,@AccountNumber VARCHAR(20)
		,@Status VARCHAR(25)
		,@account_id INT
		,@EINH VARCHAR(15)
		,@applnType VARCHAR(50)
		,@Group_NPI INT
		,@accID INT
		,@Provider_NPI VARCHAR(10)
		,@accNo VARCHAR(20)
		,@AffSupUpdateFlag VARCHAR(25)
		,@account_internal_use_id INT
		,@ProvName VARCHAR(150)
		,@LastActionComments VARCHAR(200)
		,@rendering_providerNumber VARCHAR(100)
		,@group_providerNumber VARCHAR(100)
		,@DateReceived SMALLDATETIME
		,@AccountIDC INT
		,@EFT_Indicator VARCHAR(1)
		,@AccountPartyID INT
		,@ProviderTypeCode VARCHAR(10)
		,@ProviderTypeCodeOOSH VARCHAR(10)
		,@IsTribalAppln bit
		,@NewAccountRequired varchar(100)
		,@isReactivation bit
		,@ReactivateAppType varchar(25)
		,@ISDMC bit
		,@providerType varchar(20)
		,@isFBP bit
		,@Date smalldatetime = getdate()
		,@Account_No varchar(30)
		,@providerAccountType varchar(5)
		,@countApplication int
		,@countOperators int 
		,@resolutionName varchar(150)
		,@UserName varchar(200)
		,@StateCode varchar(5)
		,@CurrentUserID varchar(100)
		,@CurrentUserName varchar(100)
		,@Group_DisaffiliateAcNo varchar(30) --Added for KEN-21574
		,@Rendered_DisaffiliateAcNo varchar(30) --Added for KEN-21574
		,@isDPP bit		

	SELECT @Number = Number
	FROM inserted

	SELECT @ProvName = ProviderName,
			@Group_DisaffiliateAcNo = Group_DisaffiliateAcNo,  --Added for KEN-21574
			@Rendered_DisaffiliateAcNo = Rendered_DisaffiliateAcNo  --Added for KEN-21574
	FROM inserted

	SELECT @SupUpdateFlag = [SupUpdateFlag]
		,@EINH = Provider_TIN
		,@applnType = [ApplnType]
		,@Group_NPI = [Group_NPI]
		,@ProviderTypeCode = [ProviderTypeCode]
		,@Account_No=AccountNo 
		,@DateReceived = CONVERT(SMALLDATETIME, DateCreated)
		,@UserName= CurrentlyAssignedToName
	FROM KYP.ADM_Case
	WHERE Number = @Number
	
	select @resolutionName=serviceLocNo
	from KYPEnrollment.EDM_SupplementalInternalUse 
	where LastActionComments=@Number
	
	SELECT @NewAccountRequired=NewAccountRequired, @ISDMC=ISDMCNEWACCOUNTREQUIRED,@isReactivation = isReactivation,
	@ReactivateAppType = ReactivateAppType,@isFBP=IsFacilityBasedProvider,@isDPP=ISDPP
	FROM KYP.ADM_CaseExtended 
	WHERE Number = @Number

	SELECT @group_providerNumber = group_providerNumber
	FROM KYPPortal.PortalKYP.pRenderingAffiliation
	WHERE rendering_providerNumber = @Number;

	SELECT @accNo = AccountNo
		,@AppNumber = Number
	FROM KYP.ADM_Case
	WHERE Number = @group_providerNumber;

	IF (@AppNumber IS NULL)
	BEGIN
		SELECT @accID = [AccountID]
		FROM KYPEnrollment.pADM_Account
		WHERE AccountNumber = @group_providerNumber
	END
	ELSE
	BEGIN
		SELECT @accID = [AccountID]
		FROM KYPEnrollment.pADM_Account
		WHERE AccountNumber = @accNo
	END

	SET @ProviderTypeCodeOOSH = 'ABC';
	
	
	if(@applnType in('Supplemental','CHOA','Reenrollment','Revalidation') and (@providerTypeCode='030' or @providerTypeCode='038'))
BEGIN

      if(@providerTypeCode='030')
	   begin
			select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
			inner join KYPPORTAL.PortalKYP.pPDM_Vehicle vehicle on vehicle.partyid=party.PartyID 	
			where ApplicationNo=@Number
			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )and party.Type in('Aircraft','Pilot')and vehicle.Approved=1	
			
			select  @countOperators=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
			inner join KYPPORTAL.PortalKYP.pPDM_Operators  Operators  on Operators.partyid=party.PartyID 	
			where ApplicationNo=@Number
			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )and party.Type in('Aircraft','Pilot')and Operators.Approved=1	
	   end
	   else if(@providerTypeCode='038')
	   begin
			select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
			inner join KYPPORTAL.PortalKYP.pPDM_Vehicle vehicle on vehicle.partyid=party.PartyID 
			where ApplicationNo=@Number	
			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null ) and party.Type in('AmbulanceDriver','LitterWheelchairVanDriver','Van','Ambulance','Non-Medical Operator', 'Non-Medical Vehicle')
			and vehicle.Approved=1
			
			select  @countOperators=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
			inner join KYPPORTAL.PortalKYP.pPDM_Operators  Operators  on Operators.partyid=party.PartyID
			where ApplicationNo=@Number	
			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null ) and party.Type in('AmbulanceDriver','LitterWheelchairVanDriver','Van','Ambulance', 'Non-Medical Operator', 'Non-Medical Vehicle')
			and Operators.Approved=1
			print @countApplication
			print @countOperators
		end
 END
 

if(@applnType in('Supplemental','CHOA','Reenrollment','Revalidation') and (@providerTypeCode='051' or @providerTypeCode='076'))
BEGIN

    if(@providerTypeCode='076')
	begin
		select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
		inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 		
		inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID 
		where ApplicationNo=@Number  and modalities.ModlityCode ='HDP' and modalities.Approved=1 and 
		(party.IsPrepopulated!=1 or party.IsPrepopulated is null) and party.Type='Modality'                          
	end
	else if(@providerTypeCode='051')
	begin
		select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
		inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 		
		inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID 
		where ApplicationNo=@Number and modalities.ModlityCode !='HDP'and modalities.Approved=1 and party.Type='Modality'
		and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )
	end
 END
      
if(@applnType in('Supplemental','CHOA','Reenrollment','Revalidation') and @isFBP=1)
BEGIN

select @countApplication=Count(ID) from KYP.PDM_AdditionalParties where ApplicationNo=@Number and IsApproved=1

END

	--BEGIN TRANSACTION 
	BEGIN TRY
		IF (
				UPDATE (ResolutionStatus)
					OR
				UPDATE (MILESTONE)
					OR
				UPDATE (STATUS)
					OR
				UPDATE (ActivityStatus)
					OR
				UPDATE (RTPDAYS_REMAINING)
				)
		BEGIN
			SELECT @applicatioNo = [Number]
				,@AccountNumber = isnull(AccountNo, '')
				,@resolutionStatus = [ResolutionStatus]
				,@priority = [Priority]
				,@risk = risk
				,@compositeRisk = CompositeRisk
				,@mileston = [MILESTONE]
				,@sStatus = [Status]
				,@activityStatus = [ActivityStatus]
				,@id = [CaseID]
				,@lastActionUserID = [CurrentlyAssignedToName]
				,@Status = [Status]
				,@IsTribalAppln = IsTribalAppln
				,@providerType=ProviderTypeCode
			FROM inserted	
			
			IF (
					@resolutionStatus = 'Approved'
					AND @mileston <> 'Closed'
					AND (
						@applnType = 'New'
						OR @applnType = 'New Group'
						OR @applnType = 'New Rendering'
						)
					AND ISNULL(@AccountNumber,'') = ''
					)
			BEGIN
				-- This procedure is to Create  Account
				PRINT 'Before'
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;
		
				
	
				IF (@ProviderTypeCode = @ProviderTypeCodeOOSH)
				BEGIN
					EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
						,@lastActionUserID
						,@priority
						,@risk
						,@compositeRisk
						,@id
						,@AccountNumber;
				END
			END

			-- Updating IUD Data While Creating an Account
			ELSE IF (
					(@resolutionStatus = 'Approved'
				     or @resolutionStatus='Crossover Approved'
				     or @resolutionStatus='NPI Change'
				     )
					AND @mileston = 'Closed'
					AND @Status = 'Approved'
					AND @applnType <> 'CHOA'
					AND @applnType <> 'CHOW'
					AND @applnType <> 'Reenrollment'
					AND @applnType <> 'Revalidation'
					AND @ApplnType <> 'Supplemental'
					)
			BEGIN
				
				 EXECUTE [KYPEnrollment].[Copy_InternalUseData] @applicatioNo;				

				EXEC [KYPEnrollment].[p_Affecting_Portal] @applicatioNo
						,@resolutionStatus;

					IF (@applnType = 'New Rendering')
					BEGIN
						UPDATE KYPEnrollment.pAccount_RenderingAffiliation
						SET AccountID = @accID
						WHERE [AffiliatedAccountID] = @account_id
							AND AccountID IS NULL;
					END

					--SELECT @DateReceived = CONVERT(SMALLDATETIME, DateCreated)
					--FROM kyp.ADM_Case
					--WHERE Number = @Number;

					UPDATE KYPEnrollment.pAccount_RenderingAffiliation
					SET AffiliationStartDate = @DateReceived
						--,currentrecordflag = 1
						--,isdeleted = 0
					WHERE [AffiliatedAccountID] = @account_id
						AND AccountID = @accID
IF exists(select StateCode from KYP.OIS_App_Version where StateCode = 'MD')
BEGIN
					IF not EXISTS(SELECT resolutionstatus,Milestone,Status,applntype 
						  FROM deleted 
						 WHERE ResolutionStatus=@resolutionStatus 
						 AND MILESTONE=@mileston AND Status=@Status AND ApplnType=@applnType) 
		   
					BEGIN
						 PRINT ' there is change then execute the spreading '
					  
							--spreading mocas second approval
						 EXEC [KYPEnrollment].[sp_Spreading_Moca] @applicatioNo
						                                        ,@lastActionUserID
						                                        ,@AccountNumber;
					 END
 end
				
			END
						
					-- Updating IUD Data for NR Cases
			ELSE IF (
					@resolutionStatus = 'Approved'
					AND @mileston = 'Closed'
					AND @Status = 'Approve'
					AND @activityStatus = 'Completed'
					AND @SupUpdateFlag = '5A'
					)
			BEGIN
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;

				SELECT @account_id = ISNULL([AccountID], 0)
				FROM [KYPEnrollment].[pADM_Account]
				WHERE [AccountNumber] = @AccountNumber

				EXECUTE [KYPEnrollment].[Copy_SupplementalNRData] @account_id
					,@Number
			END
			-- Start KEN-17737
			ELSE IF(@resolutionStatus = 'Approved'
						AND @mileston = 'Closed'
						AND @Status = 'Approve'
						AND @SupUpdateFlag = '09'					
					)
			BEGIN
				EXEC [KYPEnrollment].[Copy_DisenrolledData] @AccountNumber,@DateReceived,@UserName,@ProviderTypeCode
			END
			--END KEN-17737
			
			/** Condition for Creating the new account and de-activating the existing account for Tribal Health Services and PT-021/029 **/
			ELSE IF (
					(ISNULL(@IsTribalAppln,0) = 1 OR ISNULL(@ProviderTypeCode,'0') = '021' OR ISNULL(@ProviderTypeCode,'0') = '029') 
					AND @resolutionStatus = 'Approved' AND @mileston <> 'Closed' 
					AND (@applnType = 'Supplemental' OR @applnType = 'New' OR @applnType = 'New Group')
				)
			BEGIN
			--Commenting this command, handling the de-activation of the account in the application side on-click of the Confirm button
			UPDATE KYPEnrollment.pADM_Account SET StatusAcc = '2 - Inactive',StatusBeginDate = GETDATE()-1,isDeactivationRequired = 1,FutureDate = null,StatusReasonCode = '14 -Other' WHERE [AccountNumber] = @AccountNumber;
				  EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
						,@lastActionUserID
						,@priority
						,@risk
						,@compositeRisk
						,@id
						,@AccountNumber;


				  EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @Number

			END
			
			-- This block is for multi account creation Supplemental
			  
			ELSE IF(@resolutionStatus='Approved' and @mileston<>'Closed' and 
						(@applnType='Supplemental'
							OR @applnType = 'CHOA'
							OR @applnType = 'Reenrollment'
							OR @applnType = 'Revalidation'
						) and (@providerType in ('030','038','051','076')or @isFBP=1 or @isDPP=1 or @resolutionName='Change in Ownership - Approved')
					)
					
			BEGIN			
			
				if(@resolutionName='Change in Ownership - Approved')
				begin
					set @AccountNumber=''
					update Kypenrollment.EDM_SupplementalInternalUse set AccountID=Null  Where LastActionComments=@Number
				end
		
			
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;
			END
			
			ELSE IF (@resolutionStatus = 'Approved' AND @mileston = 'Closed'AND @Status = 'Approved' and 
						(@applnType='Supplemental'
						 OR @applnType = 'CHOA'
						 OR @applnType = 'Reenrollment'
						 OR @applnType = 'Revalidation'
						)and (
							  (@providerType in ('030','038') and @countApplication>0 and @countOperators>0) 
						    or(@providerType in ('051','076') and @countApplication>0)
							or(@isFBP=1 and @countApplication>0)
							or @resolutionName='Change in Ownership - Approved'
							or @isDPP=1
						)
					)
			BEGIN
					EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @Number;
					IF (@isReactivation = 1 and @ReactivateAppType='NMP')
					BEGIN
						PRINT 'Reactivate'
						EXEC KYPEnrollment.sp_Affiliations_Reactivation @applicatioNo, @AccountNumber, @lastActionUserID
					END
					
			END
			
			
			
			ELSE IF(@resolutionStatus='Approved' and @mileston='Closed' and 
				   (@applnType='Supplemental'
						OR @applnType = 'CHOA'
						OR @applnType = 'Reenrollment'
						OR @applnType = 'Revalidation'
					) and 
					(@providerType in ('030','038','051','076') or @isFBP=1 or @isDPP=1)
					
					)
					
			BEGIN
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;
				IF (@isReactivation = 1 and @ReactivateAppType='NMP')
				BEGIN
					 PRINT 'Reactivate'
					 EXEC KYPEnrollment.sp_Affiliations_Reactivation @applicatioNo, @AccountNumber, @lastActionUserID
				END
				EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @Number
			END

			
			-- END of multi account creation block for Supplemental
			
			-- Updating Account And IUD for All Supplemental Cases
			ELSE IF (
					@resolutionStatus = 'Approved'
					AND @mileston = 'Closed'
					AND @Status = 'Approve'
					AND @activityStatus = 'Completed'
					AND @SupUpdateFlag <> '5A'
					AND @SupUpdateFlag <> '09'
					)
			BEGIN
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;


				IF (@isReactivation = 1 and @ReactivateAppType='NMP')
				  BEGIN
				  PRINT 'Reactivate'
					EXEC KYPEnrollment.sp_Affiliations_Reactivation @applicatioNo, @AccountNumber, @lastActionUserID
				  END

				EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @Number


			END
					--- Updating Account When Change of Address and Change of Ownership happend
					----------***----
			ELSE IF (
					@resolutionStatus = 'Approved'
					AND @mileston = 'Closed'
					AND @Status = 'Approved'
					AND (
						@applnType = 'CHOA'
						OR @applnType = 'CHOW'
						OR @applnType = 'Reenrollment'
						OR @applnType = 'Revalidation'
						OR @applnType = 'Supplemental'
						)					
					)
			BEGIN
				--KEN-11238 - START
				SELECT @EFT_Indicator = EFT_Indicator
				FROM KYPEnrollment.pAccount_PDM_PaymentDetail A
				INNER JOIN KYPEnrollment.pADM_Account B ON A.PartyID = B.PartyID
				WHERE B.AccountNumber = @AccountNumber;

				--KEN-11238 - END
				EXEC [KYPEnrollment].[sp_Create_Update_Account] @applicatioNo
					,@lastActionUserID
					,@priority
					,@risk
					,@compositeRisk
					,@id
					,@AccountNumber;

				EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @Number
				--KEN-20080
				IF (@isReactivation = 1 and @ReactivateAppType='NMP')
					BEGIN
						PRINT 'Reactivate'
						EXEC KYPEnrollment.sp_Affiliations_Reactivation @applicatioNo, @AccountNumber, @lastActionUserID
					END
				
				/*begin*/
				SELECT @account_id = ISNULL([AccountID], 0)
				FROM [KYPEnrollment].[pADM_Account]
				WHERE [AccountNumber] = @AccountNumber

				SELECT @account_internal_use_id = ISNULL([AccountInternalUseID], 0)
					,@LastActionComments = LastActionComments
				FROM KYPEnrollment.EDM_SupplementalInternalUse
				WHERE AccountID = @account_id 
				--MD-1436
				IF @LastActionComments  is null and ( @applnType = 'CHOW' OR @applnType = 'Revalidation')
				BEGIN
						SELECT @account_internal_use_id = ISNULL([AccountInternalUseID], 0)	,@LastActionComments = LastActionComments
						FROM KYPEnrollment.EDM_SupplementalInternalUse
						WHERE LastActionComments=@Number 
				END
				--MD-1436
				EXECUTE [KYPEnrollment].[Copy_SupplementalInternalUseData] @LastActionComments
				
				/*end*/
				

				EXEC [KYPEnrollment].[p_Affecting_Portal] @applicatioNo
					,@resolutionStatus;

				--KEN-10672
				IF @applnType = 'CHOA'
					OR @applnType = 'CHOW'
				BEGIN
					UPDATE [KYPEnrollment].[pADM_Account]
					SET AccProcessing = 0
					WHERE [AccountNumber] = @AccountNumber
				END

				--KEN-11238 - START	
				/*Due to default value constraint, EFT_Indicator setting from Y to N for MMIS because BO is inserting new account in case of CHOW only*/
				IF @applnType = 'CHOW'
				BEGIN
					SELECT @AccountPartyID = PartyID
					FROM [KYPEnrollment].[pADM_Account]
					WHERE [AccountNumber] = @AccountNumber

					UPDATE [KYPEnrollment].[pAccount_PDM_PaymentDetail]
					SET EFT_Indicator = @EFT_Indicator
					WHERE PartyID = @AccountPartyID
				END
						--KEN-11238 - END
			END
			
		END
				--COMMIT TRANSACTION 
				
		----Added this IF block for CAPAVE-2939 by Sundar on 24 Apr 2018
		IF (@mileston = 'Closed'
				and @activityStatus = 'Completed')
		BEGIN
			Select @Account_ID = AccountID 
			From Kypenrollment.Padm_Account 
			Where AccountNumber IN (Select AccountNo from KYP.ADM_CASE where Number = @Number);
			
			--Start MD-1389 by Nitheesh on 21 Sept 2018
			Select @StateCode = StateCode from Kyp.OIS_App_Version;
			
			IF(@StateCode = 'MD' AND @SupUpdateFlag = '09')
			BEGIN
				--select @DateReceived = DateCreated from KYP.ADM_Case where Number = @Number;
				
				Update KYPEnrollment.pADM_Account 
				set StatusAcc = '2 - Inactive',
					StatusReasonCode = '11 - Provider requested deactivation',
					StatusBeginDate = @DateReceived,
					StateStatusAcc = '70 - Terminate Voluntary',
					Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
				where AccountID = @Account_ID;	
				
				Update KYPEnrollment.pAccount_BizProfile_Details
				set AccountEnrollmentStatus = '2 - Inactive',
                    AccountBillingStatus = '2 - Inactive',
                    EffectiveBeginDate= @DateReceived
                    Where AccountNumber IN (Select AccountNo from KYP.ADM_CASE where Number = @Number);        

			END
			--End MD-1389 by Nitheesh on 21 Sept 2018
		
			-- Start KEN-20563 by Subhash on 20 Dec 2018
			-- Code to end the IUDWorkflow, once the application got closed from src end
			SELECT @CurrentUserID = CurrentlyAssignedToName FROM KYP.ADM_Case WHERE NUMBER = @Number;
			SELECT @CurrentUserName = FullName FROM KYP.OIS_User WHERE UserID = @CurrentUserID;
			
			UPDATE KYPEnrollment.EDM_IUDWorkflow 
			SET CurrentRecordFlag = 0,
				ApprovedByUserID = @CurrentUserID,
				ApprovedByUser = @CurrentUserName
			WHERE Number = @Number;
			-- End KEN-20563 by Subhash on 20 Dec 2018
		
			EXEC [KYPEnrollment].[sp_Insert_AccountInputDoc] @Account_ID, 'System', @Date;		

			IF @resolutionStatus in ('Approve','Approved','Change in Ownership - Approved','Crossover Approved','Dis-Enrolled by Provider','NPI Change')
			Begin			
				/*Start of KEN-21574 Implementation by Sundar on 5-Apr-2019*/
				If @applnType = 'New Rendering'
				Begin
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountNumber = @Account_No;
					
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountID = @accID;
					
					Update B
					Set B.IsProvOwnedData = 1,
						Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress]  A 
					join kypenrollment.pADM_Account B on A.AccountID = B.AccountID
					Where A.applicationNumber = @Number
					and isnull(A.isDeleted,0) = 0				
				End

				If @applnType = 'Rendering-S'
				Begin
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountNumber = @Account_No;
					
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountID = @accID;
					
					Update B
					Set B.IsProvOwnedData = 1,
						Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress]  A 
					join kypenrollment.pADM_Account B on A.AccountID = B.AccountID
					Where A.applicationNumber = @Number
					and isnull(A.isDeleted,0) = 0
				End

				If @applnType = 'Disaffiliation' and @Group_DisaffiliateAcNo is not null and @Rendered_DisaffiliateAcNo is not null
				Begin
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountNumber = @Group_DisaffiliateAcNo;
					
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountID = @Rendered_DisaffiliateAcNo;
				End

				If @applnType in ('CHOA','Disenrollment','Reenrollment','Revalidation')
				Begin
					Update kypenrollment.pADM_Account
						Set IsProvOwnedData = 1,
							Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					Where AccountNumber = @Account_No;
				End
				/*End of KEN-21574 Implementation*/
				
				--Added the below statement for Elastic Search implementation Quick Search by Sundar on 26-Jun-2019
				Exec KYP.USP_Load_PortalAddress @P_ApplicationNumber = @Number
			End
		End	
		

					
	END TRY

	BEGIN CATCH
		--ROLLBACK TRANSACTION 
		DECLARE @error_message NVARCHAR(4000)
			,@error_severity INT;

		SELECT @error_message = ERROR_MESSAGE()
			,@error_severity = ERROR_SEVERITY();

		RAISERROR (
				@error_message
				,@error_severity
				,1
				);
	END CATCH
		--SET IMPLICIT_TRANSACTIONS OFF
END


GO

