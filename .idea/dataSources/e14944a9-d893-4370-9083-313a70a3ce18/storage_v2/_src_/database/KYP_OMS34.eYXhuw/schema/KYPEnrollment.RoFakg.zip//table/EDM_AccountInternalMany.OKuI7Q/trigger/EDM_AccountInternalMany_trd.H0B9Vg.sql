

CREATE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_trd] ON [KYPEnrollment].[EDM_AccountInternalMany]
WITH EXECUTE AS CALLER
FOR DELETE
AS
BEGIN

       --Updated on 2/16/18
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=deleted.Row_Updation_Source FROM Deleted 
	IF @Row_Updation_Source = 'Trigger_return' AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Return Back to Proc'
		RETURN
	END

	Declare @IsTemporal bit
	Declare @AccountID int
    Declare @AccountInternalUseID int
    Declare @TempAction varchar(20)
    
    Select @AccountInternalUseID = AccountInternalUseID from Deleted
    Select @IsTemporal = IsTemporal from Deleted
    Select @TempAction = TempAction from Deleted
    Select @AccountID = AccountID from [KYPEnrollment].[EDM_AccountInternalUse] where  AccountInternalUseID = @AccountInternalUseID
    
    if((@TempAction = 'REMOVED' or @IsTemporal = 0 or @IsTemporal is null) and @AccountID>0)
    BEGIN
    	Declare @CodeType varchar(10)
        Declare @CodeDescription varchar(250)
        Declare @ModifiedType varchar(20)
        Declare @HistoryID int
        
        Select @CodeType = CodeType from Deleted
        Select @CodeDescription = CodeDescription from Deleted
                
        if(@CodeType='Sanction')
        Begin
        	set @ModifiedType = 'Sanction Code'
        End
        Else if(@CodeType='Specialty')
        Begin
        	set @ModifiedType = 'Lab Specialty Code'
        End
        Else if(@CodeType='Category')
        Begin
        	set @ModifiedType = 'Category of Service'
        End   
                INSERT INTO 
                  KYPEnrollment.pAccount_History
                  (
                    AccountID,
                    ActionID,
                    DateCreated,
                    IsDeleted,
                    LastActorUserID,
                    LastActionDate
                  ) 
                  VALUES (
                     @AccountID,
                     43,
                    getdate(),
                    0,
                    (select top 1 CreatedBy from Deleted),
                    getdate()  
                  )
                  
                  
                  set @HistoryID = (SELECT SCOPE_IDENTITY());
                  print @HistoryID

              
              
              INSERT INTO 
                  KYPEnrollment.HIS_MadeChange
                (
                  HistoryID,
                  Field,
                  NewValue,
                  DateCreate,
                  OldValue
                ) 
                VALUES (
                  @HistoryID,
                  @ModifiedType,
                  '',
                  getDate(),
                  @CodeDescription                 
                )
                
               -- print (SELECT SCOPE_IDENTITY())

    END
    
END

GO

