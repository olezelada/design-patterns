

CREATE PROCEDURE [dbo].[p_LoadDailyMonthlyFile_Direct_DB]
AS
BEGIN


                /********Declare Provider Looping Variables*****************/
                DECLARE @FirstProvider BIGINT
                                ,@LastProvider BIGINT
                                ,@CurrentProvider BIGINT
                                ,@ApplicationType VARCHAR(50)
                                ,@ReactivationAccountNo VARCHAR(MAX)
                                ,@isReactivation BIT
                                ,@ReactivateAppType VARCHAR(25)
                /********Declare PDM/SDM/ADM Table Handle Variables for Provider*****************/
                DECLARE @PDM_PartyId INT
                                ,@PDM_ProviderID INT
                                ,@PDM_LocationID INT
                                ,@PDM_AddressID INT
                                ,@intAddressExists INT
                /********Declare Additional PDM/SDM/ADM Table Handle Variables for screening Provider*****************/
                DECLARE @PDM_ProviderPartyId BIGINT
                                ,@PartyType VARCHAR(50)
                                ,@ADMCaseNumber VARCHAR(15)
                                ,@PDM_CaseID BIGINT
                                ,@PDM_ApplicationID BIGINT
                                ,@ADM_App_AddressID BIGINT
                                ,@ProviderPartyName VARCHAR(100)
                                ,@ProviderCLIANBR VARCHAR(10)
                                ,@ProviderTypeDescription VARCHAR(255)
                                ,@RiskCategoryCode INT
                                ,@RiskCategory VARCHAR(100)
                                ,@intScreenChkLoop INT
                                ,@intScreeningChecklistID INT
                                ,@ADMCaseType INT
                                ,@MinCLIAID INT
                /********Declare License Looping Variables*****************/
                DECLARE @FirstLicense BIGINT
                                ,@CurrentLicense BIGINT
                                ,@LastLicense BIGINT
                                ,@PDM_LicenseID BIGINT
                /********Declare Sec NPI Looping Variables*****************/
                /* linu: integer NPI into to varchar*/
                DECLARE @FirstSecondaryNPI VARCHAR(10)
                                ,@CurrentSecondaryNPI VARCHAR(10)
                                ,@LastSecondaryNPI VARCHAR(10)
                                ,@PDM_SecondaryNPI VARCHAR(10)
                /********Declare Crossover Looping Variables*****************/
                
                /********Declare MCARE Looping Variables*****************/
                DECLARE @FirstMedicare BIGINT
                                ,@CurrentMedicare BIGINT
                                ,@LastMedicare BIGINT
                                ,@PDM_MCARE_ID BIGINT
                DECLARE @FirstCLIA BIGINT
                                ,@CurrentCLIA BIGINT
                                ,@LastCLIA BIGINT
                                ,@PDM_CLIA_ID BIGINT
                /************Declare Speciality looping variables***************/
                DECLARE @FirstSpeciality BIGINT
                                ,@CurrentSpeciality BIGINT
                                ,@LastSpeciality BIGINT
                                ,@PDM_SpecialityID BIGINT
                                ,@MinSpecialtyID BIGINT
                                ,@PrimarySpecialtyCode VARCHAR(20)
                                ,@PrimarySpecialtyDescription VARCHAR(255)
                /************Declare Taxonomy looping variables***************/
                DECLARE @FirstTaxonomy BIGINT
                                ,@CurrentTaxonomy BIGINT
                                ,@LastTaxonomy BIGINT
                                ,@PDM_TaxonomyID BIGINT
                                ,@MinTaxonomyID BIGINT
                                ,@Taxonomy VARCHAR(20)
                                ,@TaxonomyDesc VARCHAR(max)
                /********Declare IndOwner Looping Variables*****************/
                DECLARE @FirstIndOwner BIGINT
                                ,@LastIndOwner BIGINT
                                ,@CurrentIndOwner BIGINT
                                ,@PDM_OwnerPartyId BIGINT
                                ,@PDM_OwnerID BIGINT
                /********Declare OrgOwner Looping Variables (PartyID and OwnerID of IndOwners is reused)*****************/
                DECLARE @FirstOrgOwner BIGINT
                                ,@LastOrgOwner BIGINT
                                ,@CurrentOrgOwner BIGINT
                /********Declare MD Employee Looping Variables*****************/
                DECLARE @FirstEmployee BIGINT
                                ,@CurrentEmployee BIGINT
                                ,@LastEmployee BIGINT
                                ,@PDM_EmployeePartyId BIGINT
                                ,@PDM_EmployeeID BIGINT
                /********Declare Variables to derive other info*****************/
                DECLARE @FileIndicator VARCHAR(1)
                                ,@ProviderOrApplicationNbr VARCHAR(20)
                                ,@ProviderType VARCHAR(1) --'I' for individual and 'O' for organizational
                                /********Declare filetype, provider identifier Provider Name 
and Address received in Daily/Monthly File******/
                DECLARE @FileType VARCHAR(1)
                                ,@P_APPL_NUM VARCHAR(20)
                                ,@P_ID VARCHAR(20)
                                ,@P_NPI_NUM VARCHAR(10)
                                ,@P_DEA_NUM VARCHAR(11)
                                ,@P_TY_CD VARCHAR(5)
                                ,@P_PRACT_TY_CD VARCHAR(7)
                                ,@P_PRACT_TY_CD_VALUE VARCHAR(50)
                                ,@P_DOB_DT VARCHAR(10)
                                ,@P_FED_TAX_ID VARCHAR(9)
                                ,@P_SSN_NUM VARCHAR(9)
                                ,@P_LAST_NAM VARCHAR(35)
                                ,@P_FST_NAM VARCHAR(35)
                                /** KEN-10181**/
                                ,@P_MI_NAM VARCHAR(25)
                                /** End of KEN-10181 **/
                                ,@P_SFX_NAM VARCHAR(10)
                                ,@P_NAM VARCHAR(100) -- Applicable only for organizational provider
                                ,@P_DBA_LAST_NAM VARCHAR(35)
                                ,@P_DBA_FST_NAM VARCHAR(15)
                                ,@P_DBA_MI_NAM VARCHAR(35)
                                ,@P_DBA_SFX_NAM VARCHAR(10)
                                ,@P_DBA_NAM VARCHAR(35) -- Applicable only for organizational provider
                                ,@P_LINE1_AD VARCHAR(30)
                                ,@P_LINE2_AD VARCHAR(30)
                                ,@P_CITY_NAM VARCHAR(20)
                                ,@P_ST_CD VARCHAR(2)
                                ,@P_ZIP5_CD VARCHAR(5)
                                ,@P_ZIP4_CD VARCHAR(4)
                                ,@P_NABP_NUM VARCHAR(11)
                                ,@P_LINE1_AD1 VARCHAR(30)
                                ,@P_LINE2_AD1 VARCHAR(30)
                                ,@P_CITY_NAM1 VARCHAR(20)
                                ,@P_ST_CD1 VARCHAR(2)
                                ,@P_ZIP5_CD1 VARCHAR(5)
                                ,@P_ZIP4_CD1 VARCHAR(4)
                                ,@P_LINE1_AD2 VARCHAR(30)
                                ,@P_LINE2_AD2 VARCHAR(30)
                                ,@P_CITY_NAM2 VARCHAR(20)
                                ,@P_ST_CD2 VARCHAR(2)
                                ,@P_ZIP5_CD2 VARCHAR(5)
                                ,@P_ZIP4_CD2 VARCHAR(4)
                                ,@P_Group_NPI VARCHAR(10)
                                ,@P_Group_AccountNo VARCHAR(20)
                                ,@P_Preffered VARCHAR(50)
                                ,@Group_DisaffiliateAcNo VARCHAR(50)
                                ,@Rendered_DisaffiliateAcNo VARCHAR(50)
                                ,@Moratoria bit
                                ,@CrossOverApp varchar(10)
                                ,@MDCToMDL bit
                                ,@MDLToMDC bit
                                ,@FeeRequired bit
                                ,@FeePaid bit
                                ,@FeeExempted bit
                                ,@FeeConfirmation VARCHAR(50)
                                ,@HDProgram varchar(50)
                                ,@NHDProgram varchar(50)
                                ,@ProvTypeDesc NVARCHAR(150)
                                ,@AirTransportation bit
                                ,@GroundTransportation bit
                                ,@OPIndicator int
                                ,@ISDMC bit       
                                ,@providerAccountType varchar(20)
                                ,@NewAccountName varchar(200) 
                                ,@countApplication int
                                ,@CHOWLocationType varchar(5)
                                ,@CHOWAccountNo varchar(20)
                                ,@ScreeningValue varchar(2)
                                ,@IsDppApp bit           
                /********Declare Provider License and State 
***********received in Daily/Monthly File******/
                DECLARE @P_LIC_CERT_NUM VARCHAR(25)
                                ,@P_LIC_ST_CD VARCHAR(2)
                                ,@P_LIC_BRD_NUM VARCHAR(40)
                                ,@P_LIC_EXP_DT VARCHAR(10) --Newly added column 1st Oct 2012
                                ,@P_LIC_EXP_DT_Conv DATETIME -- Converting varchar value to datetime
                                /********Declare Provider secondary NPI 
**********received in Daily/Monthly File******/
                DECLARE @P_ALT_ID VARCHAR(14)
                /********Declare Provider Medicare Nbr 
***********received in Daily/Monthly File******/
                DECLARE @P_MCARE_NUM VARCHAR(12)
                /********Declare Provider CLIA received 
************in Daily/Monthly File******/
                DECLARE @P_CLIA_NUM VARCHAR(10)
                /*******Declare Provider speciality******************/
                DECLARE @P_SPECL_CD VARCHAR(20)
                /********Declare Provider Taxonomy****************/
                DECLARE @P_TAXONOMY_CD VARCHAR(50)
                                ,@Taxonomy_Desc VARCHAR(50)
                /********Declare Provider's Individual Owner Name 
*****and Address received in Daily/Monthly File******/
                DECLARE @P_OWNER_LAST_NAM VARCHAR(20)
                                ,@P_OWNER_FST_NAM VARCHAR(15)
                                ,@P_OWNER_MI_NAM VARCHAR(15)
                                ,@P_OWNER_TITL_NAM VARCHAR(3)
                                ,@P_OWNER_DOB_DT VARCHAR(10)
                                ,@P_OWNER_SSN_NUM VARCHAR(9)
                                ,@P_OWNER_LINE1_AD VARCHAR(30)
                                ,@P_OWNER_LINE2_AD VARCHAR(30)
                                ,@P_OWNER_CITY_NAM VARCHAR(20)
                                ,@P_OWNER_ST_CD VARCHAR(2)
                                ,@P_OWNER_ZIP5_CD VARCHAR(5)
                                ,@P_OWNER_ZIP4_CD VARCHAR(4)
                                ,@P_OWNER_TAG VARCHAR(10)
                                ,@P_OWNER_NPI_IND INT
                /********Declare Provider's Organizational Owner Name 
****and Address received in Daily/Monthly File******/
                DECLARE @P_OWNER_BUSN_NAM VARCHAR(100)
                                ,@P_OWNER_DBA_NAM VARCHAR(100)
                                ,@P_OWNER_TAX_ID VARCHAR(9)
                                ,@P_BUSN_LINE1_AD VARCHAR(30)
                                ,@P_BUSN_LINE2_AD VARCHAR(30)
                                ,@P_BUSN_CITY_NAM VARCHAR(20)
                                ,@P_BUSN_ST_CD VARCHAR(2)
                                ,@P_BUSN_ZIP5_CD VARCHAR(5)
                                ,@P_BUSN_ZIP4_CD VARCHAR(4)
                                ,@Owner_NPI INT
                /********Declare Provider's Managing Directing Employee Name 
**********and Address received in Daily/Monthly File******/
                DECLARE @P_EMPL_LAST_NAM VARCHAR(20)
                                ,@P_EMPL_FST_NAM VARCHAR(15)
                                ,@P_EMPL_MI_NAM VARCHAR(15)
                                ,@P_EMPL_TITL_NAM VARCHAR(3)
                                ,@P_EMPL_SSN VARCHAR(9)
                                ,@P_EMPL_DOB_DT VARCHAR(10)
                                ,@P_EMPL_LINE1_AD VARCHAR(30)
                                ,@P_EMPL_LINE2_AD VARCHAR(30)
                                ,@P_EMPL_CITY_NAM VARCHAR(20)
                                ,@P_EMPL_ST_CD VARCHAR(2)
                                ,@P_EMPL_ZIP5_CD VARCHAR(5)
                                ,@P_EMPL_ZIP4_CD VARCHAR(4)
                                ,@DH_PROV_TELE_NO VARCHAR(50)
                /********Declare variables to derive Full Name for Individuals******/
                DECLARE @P_FULL_NAM VARCHAR(75)
                                ,@P_DBA_FULL_NAM VARCHAR(75)
                                ,@P_OWNER_FULL_NAM VARCHAR(75)
                                ,@P_EMPL_FULL_NAM VARCHAR(75)
                /********Declare variables to indicate loading******/
                DECLARE @now DATETIME
								,@DateTracking DATETIME
                                ,@LoadType VARCHAR(50)
                                ,@LoadID VARCHAR(20)
                                ,@LastLoadDate DATETIME
                /********Declare variables to avoid functions in SP parameters******/
                DECLARE @Category VARCHAR(15)
                /*,@intNPI varchar  linu: npi int to varchar*/
                /**********Declare for Provider Account Number(PAN)*********/
                DECLARE @GenPAN VARCHAR(10)
                                ,@AcID INT
                                ,@ProfileName VARCHAR(150)
                                ,@NPI VARCHAR(10)
                                ,/* linu: npi int to varchar*/
                                @TIN VARCHAR(11)
                                ,@SSN VARCHAR(11)
                                ,@PracticeType VARCHAR(50)
                                ,@DateCreated DATETIME
                                ,@DateDeleted DATETIME
                                ,@PAN VARCHAR(10)
                                ,
                                /*Account*/
                                @AccountNumber VARCHAR(15)
                                ,@ProviderName VARCHAR(150)
                                ,@PracticeAddress1 VARCHAR(250)
                                ,@PracticeAddress2 VARCHAR(250)
                                ,@City VARCHAR(25)
                                ,@State VARCHAR(25)
                                ,@Zip VARCHAR(5)
                                ,@ProviderStatus VARCHAR(50)
                                ,@ProfileID INT
                                ,@IsDeleted BIT
                                ,@Specialty VARCHAR(225)
                /**Declare for Application Type**/
                DECLARE @PDM_appType INT
                                ,@ApplnType VARCHAR(35)
                                ,@FullName VARCHAR(150)
                /********Get the looping ids******/
                /****Suplemenatry Update***/
                DECLARE @Sup_Update VARCHAR(20)
                                ,@LastUpdateAppID INT
                                ,@Account_No VARCHAR(20)
                                ,@caseAgeBaseLine INT
                                ,@SupUpdateCaseID INT
                                ,@FullnameParty varchar(500)
                                ,@LocationID int

                /*************************/

                /**** RTP Rescreen Flag ***/
                DECLARE @RtpRescreenFlag VARCHAR(50)
                ,@CurrentRtpRescreenFlag VARCHAR(50)
                ,@Resubmitted bit = 0
                ,@MOCA_COUNT INTEGER = 0   
                /*************************/
                
                /**** DisEnrollment Application CAPAVE=1136 ***/
                DECLARE @NPIType VARCHAR(50)
                /*************************/

                /**** DisEnrollment Application CAPAVE=1136 ***/
                DECLARE @IsTribalAppln BIT
                /*************************/
                
                /*************** Unscreened MOCA related Changes *******************/
                DECLARE @P_OWNER_LAST_NAM_MOCA VARCHAR(25)
                                ,@P_OWNER_FST_NAM_MOCA VARCHAR(25)
                                ,@P_OWNER_MI_NAM_MOCA VARCHAR(25)
                                ,@P_OWNER_TITL_NAM_MOCA VARCHAR(50)
                                ,@P_OWNER_DOB_DT_MOCA VARCHAR(10)
                                ,@P_OWNER_SSN_NUM_MOCA VARCHAR(11)
                                ,@P_OWNER_TAG_MOCA VARCHAR(10)
                                ,@P_OWNER_FULL_NAM_MOCA VARCHAR(100)
                                ,@P_OWNER_LINE1_AD_MOCA VARCHAR(30)
                                ,@P_OWNER_LINE2_AD_MOCA VARCHAR(30)
                                ,@P_OWNER_CITY_NAM_MOCA VARCHAR(20)
                                ,@P_OWNER_ST_CD_MOCA VARCHAR(2)
                                ,@P_OWNER_ZIP5_CD_MOCA VARCHAR(5)
                                ,@P_OWNER_ZIP4_CD_MOCA VARCHAR(4)
                                ,@P_OWNER_SCR_ON_DATE_MOCA smalldatetime
                                ,@DH_PROV_TELE_NO_MOCA VARCHAR(50)
                                
                                
                                ,@P_OWNER_BUSN_NAM_MOCA VARCHAR(100)
                                ,@P_OWNER_DBA_NAM_MOCA VARCHAR(500)
                                ,@P_OWNER_TAX_ID_MOCA VARCHAR(11)
                                ,@P_BUSN_LINE1_AD_MOCA VARCHAR(30)
                                ,@P_BUSN_LINE2_AD_MOCA VARCHAR(30)
                                ,@P_BUSN_CITY_NAM_MOCA VARCHAR(20)
                                ,@P_BUSN_ST_CD_MOCA VARCHAR(2)
                                ,@P_BUSN_ZIP5_CD_MOCA VARCHAR(5)
                                ,@P_BUSN_ZIP4_CD_MOCA VARCHAR(4)
                                ,@P_BUSN_SCR_ON_DATE_MOCA smalldatetime 
								,@MOCA_C int = 1
                                ,@MOCA_Cnt int
                                ,@MOCA_OWN_C int =1
                                ,@MOCA_OWN_Cnt int
                               
			Declare @Tab_MOCALinking Table(ID int Identity(1,1)
											,PartyID int 
											,P_OWNER_LAST_NAM_MOCA VARCHAR(25)
											,P_OWNER_FST_NAM_MOCA VARCHAR(25)
											,P_OWNER_MI_NAM_MOCA VARCHAR(25)
											,P_OWNER_TITL_NAM_MOCA VARCHAR(50)
											,P_OWNER_DOB_DT_MOCA VARCHAR(10)
											,P_OWNER_SSN_NUM_MOCA VARCHAR(11)
											,P_OWNER_TAG_MOCA VARCHAR(10)
											,P_OWNER_LINE1_AD_MOCA VARCHAR(30)
											,P_OWNER_LINE2_AD_MOCA VARCHAR(30)
											,P_OWNER_CITY_NAM_MOCA VARCHAR(20)
											,P_OWNER_ST_CD_MOCA VARCHAR(2)
											,P_OWNER_ZIP5_CD_MOCA VARCHAR(5)
											,P_OWNER_ZIP4_CD_MOCA VARCHAR(4) 
											,P_PROV_TELE_NO_MOCA VARCHAR(50) 
											,P_OWNER_SCR_ON_DATE_MOCA smalldatetime
												)
									
			Declare @Tab_MOCALinking_Own Table(ID int Identity(1,1)	
								,PartyID int				
								,P_OWNER_BUSN_NAM_MOCA VARCHAR(100)
                                ,P_OWNER_DBA_NAM_MOCA VARCHAR(500)
                                ,P_OWNER_TAX_ID_MOCA VARCHAR(11)
                                ,P_BUSN_LINE1_AD_MOCA VARCHAR(30)
                                ,P_BUSN_LINE2_AD_MOCA VARCHAR(30)
                                ,P_BUSN_CITY_NAM_MOCA VARCHAR(20)
                                ,P_BUSN_ST_CD_MOCA VARCHAR(2)
                                ,P_BUSN_ZIP5_CD_MOCA VARCHAR(5)
                                ,P_BUSN_ZIP4_CD_MOCA VARCHAR(4)
                                ,P_BUSN_SCR_ON_DATE_MOCA smalldatetime     
								)


                /** Additional Parties **/
                DECLARE 
                                                
                                                @ADPPartyType VARCHAR(50),
                                                @ADPFirstName VARCHAR(50),
                                                @ADPLastName VARCHAR(50),
            @ADPMiddleName VARCHAR(50),
                                                @ADPLegalName VARCHAR(200),
            @ADPSSN VARCHAR(10),
            @ADPTIN VARCHAR(10),
            @ADPLicense VARCHAR(20),
            @ADPProviderTypeCode VARCHAR(5),
            @ADPProviderTypeDescription VARCHAR(150),
            @ADPAddressType VARCHAR(20),
            @ADPAddressLine1 VARCHAR(150),
            @ADPAddressLine2 VARCHAR(150),
            @ADPCity VARCHAR(30),
            @ADPState VARCHAR(2),
            @ADPZipCode VARCHAR(10),
            @ADPZip5 VARCHAR(5),
            @ADPZip4 VARCHAR(4),
            @ADCurrentID int,
            @ADFirstID int,
            @ADLastID int,
            @IsFBP bit,
            @LocationNumber int,
            @ChangeServiceAddress int = 0 /** ADDED for CAPAVE-3812**/

                /************************/

                SET @caseAgeBaseLine = 90;

                SELECT @FirstProvider = MIN(ID)
                                ,@CurrentProvider = MIN(ID)
                                ,@LastProvider = MAX(ID)
                FROM dbo.ProvidersForTheDay

                /********Begin Processing of Current Provider******/
                WHILE (@CurrentProvider <= @LastProvider)
                BEGIN
                                BEGIN TRY
                                                BEGIN TRAN ProcessProvider

                                                /********Read file type and identifier of current provider******/
                                                SELECT @FileIndicator = FileType
                                                                ,@ProviderOrApplicationNbr = P_ID
                                                FROM dbo.ProvidersForTheDay
                                                WHERE ID = @CurrentProvider

                                                /********set loading indicator and time******/
                                                SELECT @now = GETDATE()
                                                                ,@LoadType = CASE 
                                                                                WHEN @FileIndicator = 'M'
                                                                                                THEN 'MonthlyProvider'
                                                                                WHEN @FileIndicator = 'D'
                                                                                                THEN 'DailyEnroller'
                                                                                END
                                                                ,@LoadID = CASE 
                                                                                WHEN @FileIndicator = 'M'
                                                                                                THEN 'MLOAD_' + CONVERT(VARCHAR(10), getdate(), 112)
                                                                                WHEN @FileIndicator = 'D'
                                                                                                THEN 'DLOAD_' + CONVERT(VARCHAR(10), getdate(), 112)
                                                                                END
                                                                ,@LastLoadDate = GETDATE()

                                                /********Read provider name and address from provider identifier******/
                                                SELECT @FileType = [FileType]
                                                                ,@P_APPL_NUM = [P_APPL_NUM]
                                                                ,@P_ID = [P_ID]
                                                                ,@P_NPI_NUM = [P_NPI_NUM]
                                                                ,@P_DEA_NUM = [P_DEA_NUM]
                                                                ,@P_TY_CD = [P_TY_CD]
                                                                ,@P_PRACT_TY_CD = [P_PRACT_TY_CD]
                                                                ,@P_DOB_DT = [P_DOB_DT]
                                                                ,@P_FED_TAX_ID = [P_FED_TAX_ID]
                                                                ,@P_SSN_NUM = [P_SSN_NUM]
                                                                ,@P_LAST_NAM = [P_LAST_NAM]
                                                                ,@P_FST_NAM = [P_FST_NAM]
                                                                ,@P_MI_NAM = [P_MI_NAM]
                                                                ,@P_SFX_NAM = [P_SFX_NAM]
                                                                ,@P_NAM = [P_NAM]
                                                                ,@P_DBA_LAST_NAM = [P_DBA_LAST_NAM]
                                                                ,@P_DBA_FST_NAM = [P_DBA_FST_NAM]
                                                                ,@P_DBA_MI_NAM = [P_DBA_MI_NAM]
                                                                ,@P_DBA_SFX_NAM = [P_DBA_SFX_NAM]
                                                                ,@P_DBA_NAM = [P_DBA_NAM]
                                                                ,@P_NABP_NUM = [P_NABP_NUM]
                                                                ,@P_LINE1_AD = [P_LINE1_AD]
                                                                ,@P_LINE2_AD = [P_LINE2_AD]
                                                                ,@P_CITY_NAM = [P_CITY_NAM]
                                                                ,@P_ST_CD = [P_ST_CD]
                                                                ,@P_ZIP5_CD = [P_ZIP5_CD]
                                                                ,@P_ZIP4_CD = [P_ZIP4_CD]
                                                                ,@P_LINE1_AD1 = [P_LINE1_AD2]
                                                                ,@P_LINE2_AD1 = [P_LINE2_AD2]
                                                                ,@P_CITY_NAM1 = [P_CITY_NAM2]
                                                                ,@P_ST_CD1 = [P_ST_CD2]
                                                                ,@P_ZIP5_CD1 = [P_ZIP5_CD2]
                                                                ,@P_ZIP4_CD1 = [P_ZIP4_CD2]
                                                                ,@P_LINE1_AD2 = [P_LINE1_AD3]
                                                                ,@P_LINE2_AD2 = [P_LINE2_AD3]
                                                                ,@P_CITY_NAM2 = [P_CITY_NAM3]
                                                                ,@P_ST_CD2 = [P_ST_CD3]
                                                                ,@P_ZIP5_CD2 = [P_ZIP5_CD3]
                                                                ,@P_ZIP4_CD2 = [P_ZIP4_CD3]
                                                                ,@Sup_Update = CONVERT(VARCHAR, ISNULL([P_SupUpdate_Flag], '0'))
                                                                ,@LastUpdateAppID = [LS_App]
                                                                ,@Account_No = [P_AccNo]
                                                                ,@P_Group_NPI = [P_Group_NPI]
                                                                ,@Group_DisaffiliateAcNo = [Group_DisaffiliateAcNo]
                                                                ,@Rendered_DisaffiliateAcNo = [Rendered_DisaffiliateAcNo]
                                                                ,@P_Group_AccountNo = [P_Group_AccountNo]
                                                                ,@DH_PROV_TELE_NO = [DH_PROV_TELE_NO]
                                                                ,@P_Preffered = LTRIM(RTRIM(ISNULL([P_PREFFERED], '')))
                                                                ,@NPIType=NpiType
                                                                ,@CrossOverApp =  upper(CrossOverApp)                                                                                            
                                                                ,@MDCToMDL = MDCToMDL
                                                                ,@MDLToMDC = MDLToMDC
                                                                ,@FeePaid = FeePaid 
                                                                ,@FeeRequired = FeeRequired
                                                                ,@FeeExempted = FeeExempted 
                                                                ,@FeeConfirmation = FeeConfirmation  
                                                                ,@HDProgram = HDProgram
                                                                ,@NHDProgram =NHDProgram                                  
                                                                ,@ProvTypeDesc = P_TY_DESC
                                                                ,@IsTribalAppln = BecomeTribal                
                                                                ,@OPIndicator = OPIndicators
                                                                ,@GroundTransportation= isnull(GroundTransportation,0) 
                                                                ,@AirTransportation=isnull(AirTransportation,0)
                                                                ,@ISDMC=          isnull(ISDMCNEWACCOUNTREQUIRED,0)
                                                                ,@IsFBP=isnull(IsFBP,0)
                                                                ,@ReactivationAccountNo = [ReactivationAccountNo]
                                                                ,@isReactivation = [isReactivation]
                                                                ,@CHOWLocationType = [QuestionnaireFlow]
                                                                ,@CHOWAccountNo = [QuestionnaireAccount]
																,@Moratoria = ISNULL(IsMoratorium,0)
																,@IsDppApp=ISNULL(IsDppApp,0)
                                                                --,@ReactivateAppType =[ReactivateAppType]
                                                FROM [dbo].[ProviderNameAddress]
                                                WHERE P_ID = @ProviderOrApplicationNbr
                                                
                                                IF (@Sup_Update = '5B' or @Sup_Update = 'MR' or @Sup_Update = '5A' or @Sup_Update = 'NR')
                                                BEGIN
														select @ScreeningValue=ScreeningValue from KYPEnrollment.pADM_Account where AccountNumber=@Account_No
														if(@ScreeningValue = 'SR')
														BEGIN
                                                                SET @Sup_Update = '5C'
																update KYPEnrollment.pADM_Account set ScreeningValue=NULL where AccountNumber=@Account_No
                                                        END
                                                END
                                             
												/** Title: Checking Service Address is matching with Account Service Address or not 									  
													Author: Rahul Raghavendra
													BUG : CAPAVE-3812
													Date Created: 18/12/2018**/	
											
												IF(@Sup_Update = '06' OR @Sup_Update = '12' OR @Sup_Update = '11')
												BEGIN
													
													select @ChangeServiceAddress=count(A.ApplicationNo) 
															from KYPPORTAL.PortalKyp.pAdm_Application A
															inner join KYPEnrollment.pAdm_Account B on A.AccountNumber=B.AccountNumber
															inner join KYPEnrollment.pAccount_PDM_Location c on B.Partyid=C.PartyId and C.Type='Servicing' and C.CurrentRecordFlag=1
															inner join KYPEnrollment.pAccount_PDM_Address D on C.AddressID=D.AddressID and D.CurrentRecordFlag=1
															inner join KYPPORTAL.PortalKYP.pPDM_Location E on A.Partyid=E.PartyId and E.Type='Servicing' and E.IsDeleted=0
															inner join KYPPORTAL.PortalKYP.pPDM_Address F on E.AddressID=F.AddressID and F.IsDeleted=0
															where A.Applicationno=@P_APPL_NUM and isnull(D.AddressLine1,'')=isnull(F.AddressLine1,'') and isnull(D.AddressLine2,'')=isnull(F.AddressLine2,'')
															and isnull(D.County,'')=isnull(F.County,'') and isnull(D.City,'')=isnull(F.City,'') and isnull(D.ZipPlus4,'')=isnull(F.ZipPlus4,'')
															and ISNULL(D.State,'')=ISNULL(F.State,'') and ISNULL(D.Country,'')=ISNULL(F.Country,'') 

												
												END                                                
                                                /** END  CAPAVE-3812 **/
                                                
                                                IF (@P_PRACT_TY_CD = '1')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'Individual Billing'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '2')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'Rendering'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '3')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'NMP'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '4')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'ORP'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '5')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'Group Billing'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '6')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'RS'
                                                END
                                                ELSE IF (@P_PRACT_TY_CD = '7')
                                                BEGIN
                                                                SET @P_PRACT_TY_CD_VALUE = 'Other Healthcare Business'
                                                END

                                                /** Find Either Organizatin Or Individual **/
                                                DECLARE @CaseType VARCHAR(30)
                                                DECLARE @SDMIsActive BIT = NULL
                                                DECLARE @ResubmitScrID INTEGER = NULL
                                                DECLARE @ResubmitAutoRisk INTEGER = NULL
												DECLARE @ResubmitEDDRisk INTEGER = NULL
												DECLARE @ResubmitCompositeRisk INTEGER = NULL
												DECLARE @ResubmitNormalizedRisk INTEGER = NULL
												DECLARE @ResubmitDateCreated smalldatetime = NULL

                                                IF (
                                                                                @Sup_Update = '5A'
                                                                                OR @Sup_Update = '5B'
                                                                                --OR @Sup_Update = '5C'
                                                                                OR @CrossOverApp = 'X'
                                                                                )
                                                BEGIN
                                                                SET @SDMIsActive = 1
                                                END

                                                PRINT 'Type of App : ' + @Sup_Update

                                                IF (
                                                                                @Sup_Update = '01'
                                                                                OR @Sup_Update = '04'
                                                                                )
                                                BEGIN
                                                                SET @ProviderType = 'I'
                                                END
                                                ELSE IF (
                                                                                @Sup_Update = '02'
                                                                                OR @Sup_Update = '03'
                                                                                )
                                                BEGIN
                                                                SET @ProviderType = 'O'
                                                END
                                                ELSE IF (
                                                                                @Sup_Update = '5A'
                                                                                OR @Sup_Update = '5B'
                                                                                OR @Sup_Update = '5C'
                                                                                )
                                                BEGIN
                                                                SET @Account_No = ISNULL(@Account_No, '0000000000');

                                                                SELECT @CaseType = SubType
                                                                FROM KYP.ADM_Case
                                                                WHERE AccountNo = @Account_No;

                                                                IF (@NPIType='Organization')
                                                                BEGIN
                                                                                                SET @ProviderType = 'O'
                                                                END
                                                                ELSE IF (@NPIType='Individual')
                                                                BEGIN
                                                                                SET @ProviderType = 'I'
                                                                END
                                                END
                                                ELSE IF (
                                                                                @Sup_Update = '06'
                                                                                OR @Sup_Update = '07'
                                                                                OR @Sup_Update = '08'
                                                                                OR @Sup_Update = '09'
                                                                                )
                                                BEGIN
                                                                SET @Account_No = ISNULL(@Account_No, '0000000000');

                                                                SELECT @CaseType = SubType
                                                                FROM KYP.ADM_Case
                                                                WHERE AccountNo = @Account_No;

                                                                IF (@NPIType='Organization')
                                                                BEGIN
                                                                                                SET @ProviderType = 'O'
                                                                END
                                                                ELSE IF (@NPIType='Individual')
                                                                BEGIN
                                                                                SET @ProviderType = 'I'
                                                                END
                                                END
                                                ELSE IF (
                                                                                @Sup_Update = '10'
                                                                                OR @Sup_Update = '11'
                                                                                OR @Sup_Update = '12'
                                                                                OR @Sup_Update = '13'
                                                                                )
                                                BEGIN
                                                                SET @Account_No = ISNULL(@Account_No, '0000000000');

                                                                SELECT @CaseType = SubType
                                                                FROM KYP.ADM_Case
                                                                WHERE AccountNo = @Account_No;

                                                                IF (@NPIType='Organization')
                                                                BEGIN
                                                                                                SET @ProviderType = 'O'
                                                                END
                                                                ELSE IF (@NPIType='Individual')
                                                                BEGIN
                                                                                SET @ProviderType = 'I'
                                                                END
                                                END
                                                ELSE IF (@Sup_Update = '0')
                                                BEGIN
                                                                IF (
                                                                                                (@P_NAM IS NOT NULL)
                                                                                                AND @P_DBA_NAM IS NOT NULL
                                                                                                AND (
                                                                                                                @P_LAST_NAM IS NULL
                                                                                                                AND @P_FST_NAM IS NULL
                                                                                                                AND @P_DBA_LAST_NAM IS NULL
                                                                                                                AND @P_DBA_FST_NAM IS NULL
                                                                                                                )
                                                                                                )
                                                                                SELECT @ProviderType = 'O'
                                                                ELSE IF (
                                                                                                @P_LAST_NAM IS NOT NULL
                                                                                                OR @P_FST_NAM IS NOT NULL
                                                                                                OR @P_DBA_LAST_NAM IS NOT NULL
                                                                                                OR @P_DBA_FST_NAM IS NOT NULL
                                                                                                )
                                                                                SELECT @ProviderType = 'I'
                                                END

                                                /********Read provider license nbr for Missisipi State, 
*********To be used for Individual Match******/
                                                SELECT @P_LIC_CERT_NUM = P_LIC_CERT_NUM
                                                FROM [dbo].[ProviderLicense]
                                                WHERE P_ID = @ProviderOrApplicationNbr --and P_ST_CD ='MS'

                                                /*******Identify Individual or Organizational Provider******/
                                                /*
if ((@P_NAM is not null) and @P_DBA_NAM is not null and (@P_LAST_NAM is null and @P_FST_NAM is  null 
                                and @P_DBA_LAST_NAM is null and @P_DBA_FST_NAM is null))
                select @ProviderType = 'O'
else if (@P_LAST_NAM is not null or @P_FST_NAM is not null 
                                or @P_DBA_LAST_NAM is not null or @P_DBA_FST_NAM is not null)       
                select @ProviderType = 'I'            
*/
                                                PRINT 'Provider Type : ' + @ProviderType

                                                /*******Generate Names for Providers******/
                                                IF @ProviderType = 'I'
                                                BEGIN
                                                                SELECT @P_LAST_NAM = rtrim(ltrim(Replace(REPLACE(@P_LAST_NAM, ', ', ' '), ',', ' ')))

                                                                SELECT @P_FST_NAM = rtrim(ltrim(Replace(REPLACE(@P_FST_NAM, ', ', ' '), ',', ' ')))

                                                                SELECT @P_MI_NAM = rtrim(ltrim(Replace(REPLACE(@P_MI_NAM, ', ', ' '), ',', ' ')))

                                                                SELECT @P_DBA_LAST_NAM = rtrim(ltrim(Replace(REPLACE(@P_DBA_LAST_NAM, ', ', ' '), ',', ' ')))

                                                                SELECT @P_DBA_FST_NAM = rtrim(ltrim(Replace(REPLACE(@P_DBA_FST_NAM, ', ', ' '), ',', ' ')))

                                                                SELECT @P_DBA_MI_NAM = rtrim(ltrim(Replace(REPLACE(@P_DBA_MI_NAM, ', ', ' '), ',', ' ')))

                                                                /*******Removing leading and trailing single quotes*************/
                                                                SELECT @P_FST_NAM = KYP.RemoveSingleQuotes(@P_FST_NAM)

                                                                SELECT @P_LAST_NAM = KYP.RemoveSingleQuotes(@P_LAST_NAM)

                                                                SELECT @P_MI_NAM = KYP.RemoveSingleQuotes(@P_MI_NAM)

                                                                /*************** Remove double quotes******************************/
                                                                SELECT @P_FST_NAM = KYP.RemoveDoubleQuotes(@P_FST_NAM)

                                                                SELECT @P_LAST_NAM = KYP.RemoveDoubleQuotes(@P_LAST_NAM)

                                                                SELECT @P_MI_NAM = KYP.RemoveDoubleQuotes(@P_MI_NAM)

                                                                --select @P_FULL_NAM = @P_LAST_NAM +  COALESCE((', ' + @P_FST_NAM), '') +  COALESCE((' ' + @P_MI_NAM), '')
                                                                --select @P_DBA_FULL_NAM = @P_DBA_LAST_NAM +  COALESCE((', ' + @P_DBA_FST_NAM), '') +  COALESCE((' ' + @P_DBA_MI_NAM), '')
                                                                --select @P_LAST_NAM = COALESCE(@P_LAST_NAM, @P_DBA_LAST_NAM)
                                                                --select @P_FST_NAM = COALESCE(@P_FST_NAM, @P_DBA_FST_NAM)
                                                                SELECT @P_LAST_NAM = COALESCE(@P_LAST_NAM, @P_DBA_LAST_NAM)

                                                                SELECT @P_FST_NAM = COALESCE(@P_FST_NAM, @P_DBA_FST_NAM)

                                                                IF (@P_LAST_NAM IS NULL)
                                                                BEGIN
                                                                                SELECT @P_FULL_NAM = COALESCE(@P_LAST_NAM, '') + COALESCE(@P_FST_NAM, '') + COALESCE((' ' + @P_MI_NAM), '')
                                                                END
                                                                ELSE
                                                                BEGIN
                                                                                SELECT @P_FULL_NAM = COALESCE(@P_LAST_NAM, '') + COALESCE((', ' + @P_FST_NAM), '') + COALESCE((' ' + @P_MI_NAM), '')
                                                                END

                                                                IF (@P_DBA_LAST_NAM IS NULL)
                                                                BEGIN
                                                                                SELECT @P_DBA_FULL_NAM = COALESCE(@P_DBA_LAST_NAM, '') + COALESCE(@P_DBA_FST_NAM, '') + COALESCE((' ' + @P_DBA_MI_NAM), '')
                                                                END
                                                                ELSE
                                                                BEGIN
                                                                                SELECT @P_DBA_FULL_NAM = COALESCE(@P_DBA_LAST_NAM, '') + COALESCE((', ' + @P_DBA_FST_NAM), '') + COALESCE((' ' + @P_DBA_MI_NAM), '')
                                                                END

                                                                SELECT @P_FULL_NAM = COALESCE(@P_FULL_NAM, @P_DBA_FULL_NAM)
                                                END
                                                ELSE IF @ProviderType = 'O'
                                                BEGIN
                                                                /*************Remove double quotes*****************/
                                                                SELECT @P_NAM = KYP.RemoveSingleQuotes(@P_NAM)

                                                                SELECT @P_DBA_NAM = KYP.RemoveSingleQuotes(@P_DBA_NAM)

                                                                /*************** Remove double quotes******************************/
                                                                SELECT @P_NAM = KYP.RemoveDoubleQuotes(@P_NAM)

                                                                SELECT @P_DBA_NAM = KYP.RemoveDoubleQuotes(@P_DBA_NAM)

                                                                SELECT @P_NAM = COALESCE(@P_NAM, @P_DBA_NAM)
                                                END

                                                PRINT 'Individual : ' + @P_FULL_NAM
                                                PRINT 'Organization : ' + @P_NAM

                                                /*****************Removing leading and trailing single,double quotes,back slash,forward slash and space from Address******************************/
                                                SELECT @P_LINE1_AD = KYP.RemoveUnwantedCharacters(@P_LINE1_AD)

                                                SELECT @P_LINE2_AD = KYP.RemoveUnwantedCharacters(@P_LINE2_AD)

                                                SELECT @P_LINE1_AD1 = KYP.RemoveUnwantedCharacters(@P_LINE1_AD1)

                                                SELECT @P_LINE2_AD1 = KYP.RemoveUnwantedCharacters(@P_LINE2_AD1)

                                                SELECT @P_LINE1_AD2 = KYP.RemoveUnwantedCharacters(@P_LINE1_AD2)

                                                SELECT @P_LINE2_AD2 = KYP.RemoveUnwantedCharacters(@P_LINE2_AD2)

                                                --Select 
                                                /*******Comparison and loading of monthly provider starts here******/
                                                IF @FileType = 'M'
                                                BEGIN
                                                                IF @ProviderType = 'I'
                                                                BEGIN
                                                                                /*******Try to find the PartyID of the provider, if it is an individual******/
                                                                                EXEC @PDM_PartyId = KYP.p_FindIndParty @LastName = @P_LAST_NAM
                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                ,@LIC_CERT_NUM = @P_LIC_CERT_NUM
                                                                                                ,@CurrentModule = 2

                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party and PDM_Person tables******/
                                                                                IF @PDM_PartyId = - 1
                                                                                BEGIN
                                                                                                /*select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                /*select @intNPI = @P_NPI_NUM  linu: integer NPI into to varchar*/
                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@IsTemp = 0
                                                                                                                ,@IsActive = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@IsDeleted = 0
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@CurrentModule = 2

                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_PartyId
                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@DateCreated = @now
                                                                                END
                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party and PDM_Person tables******/
                                                                                ELSE IF (
                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                )
                                                                                BEGIN
                                                                                                /* linu: integer NPI into to varchar            
select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@DateModified = @now

                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_PartyId
                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@DateModified = @now
                                                                                END
                                                                END
                                                                                                /*******Try to find the PartyID of the provider, 
*********if it is an organization******/
                                                                ELSE IF @ProviderType = 'O'
                                                                BEGIN
                                                                                EXEC @PDM_PartyId = KYP.p_FindOrgParty @OrgName = @P_NAM
                                                                                                ,@TAXID = @P_FED_TAX_ID
                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                ,@City = @P_CITY_NAM
                                                                                                ,@ZIP = @P_ZIP5_CD
                                                                                                ,@Adr_Line1 = @P_LINE1_AD
                                                                                                ,@CurrentModule = 2

                                                                                /*******If PartyID not found, insert record each in 
*********PDM_Party and PDM_Organization tables******/
                                                                                IF @PDM_PartyId = - 1
                                                                                BEGIN
                                                                                                /* linu: integer NPI into to varchar            
select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                ,@Name = @P_NAM
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@IsTemp = 0
                                                                                                                ,@IsActive = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@IsDeleted = 0
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@CurrentModule = 2

                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_PartyId
                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                ,@LegalName = @P_NAM
                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                END
                                                                                                                /*******If PartyID found, update the record in 
*********PDM_Party and PDM_Organization tables******/
                                                                                ELSE IF (
                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                )
                                                                                BEGIN
                                                                                                /* linu: integer NPI into to varchar
select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                ,@Name = @P_NAM
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@DateModified = @now

                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_PartyId
                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                ,@LegalName = @P_NAM
                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@DateModified = @now
                                                                                                                --,@NPI = @Owner_NPI
                                                                                END
                                                                END

                                                                /*******Get First CLIA Nbr for PDM_Provider table******/
                                                                SELECT @MinCLIAID = MIN(ID)
                                                                FROM dbo.ProviderCLIA
                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                SELECT @ProviderCLIANBR = P_CLIA_NUM
                                                                FROM dbo.ProviderCLIA
                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                AND ID = @MinCLIAID

                                                                /*******Get First Specialty for PDM_Provider table******/
                                                                SELECT @MinSpecialtyID = MIN(ID)
                                                                FROM dbo.ProviderSpeciality
                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                PRINT 'SPECIALTY FETCH'
                                                                PRINT @MinSpecialtyID

                                                                SELECT @PrimarySpecialtyCode = P_SPECL_CD
                                                                FROM dbo.ProviderSpeciality
                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                AND ID = @MinSpecialtyID

                                                                PRINT @PrimarySpecialtyCode

                                                                SELECT @PrimarySpecialtyDescription = LongDescription
                                                                FROM KYP.PDM_SpecialityCode
                                                                WHERE Value = @PrimarySpecialtyCode

                                                                PRINT @PrimarySpecialtyDescription

                                                                /*******Verify if the party exists as provider in PDM_Provider table******/
                                                                EXEC @PDM_ProviderID = KYP.p_FindProviderRecord @PartyID = @PDM_PartyId
                                                                                ,@ProvIdentifierID = @P_ID
                                                                                ,@CurrentModule = 2

                                                                /*******If not exists insert record in PDM_Provider table******/
                                                                IF @PDM_ProviderID = - 1
                                                                BEGIN
                                                                                /* linu: integer NPI into to varchar            
select @intNPI =CONVERT(int, @P_NPI_NUM)*/
                                                                                SELECT @Category = CASE 
                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                THEN 'Physician'
                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                THEN 'Institutional'
                                                                                                                ELSE NULL
                                                                                                                END

                                                                                EXEC @PDM_ProviderID = [KYP].[p_InsertPDMProvider] @PartyID = @PDM_PartyId
                                                                                                ,@Category = @Category
                                                                                                ,@Type = @P_TY_CD
                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                ,@IsEnrolled = 1
                                                                                                ,@ProvNumber = @P_ID
                                                                                                ,@Mon_MedicaidID = @P_ID
                                                                                                ,@DateCreated = @now
                                                                                                ,@DEA = @P_DEA_NUM
                                                                                                ,@CLIA = @ProviderCLIANBR
                                                                                                ,@NABPNum = @P_NABP_NUM
                                                                                                ,@PrimarySpecialty = @PrimarySpecialtyDescription
                                                                END
                                                                                                /*******If exists update the record in PDM_Provider table******/
                                                                ELSE IF (
                                                                                                @PDM_ProviderID IS NOT NULL
                                                                                                AND @PDM_ProviderID <> 0
                                                                                                )
                                                                BEGIN
                                                                                /* linu: integer NPI into to varchar            
select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                SELECT @Category = CASE 
                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                THEN 'Physician'
                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                THEN 'Institutional'
                                                                                                                ELSE NULL
                                                                                                                END

                                                                                EXEC [KYP].[p_UpdatePDMProvider] @PartyID = @PDM_PartyId
                                                                                                ,@Category = @Category
                                                                                                ,@Type = @P_TY_CD
                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                ,@IsEnrolled = 1
                                                                                                ,@ProvNumber = @P_ID
                                                                                                ,@Mon_MedicaidID = @P_ID
                                                                                                ,@DateModified = @now
                                                                                                ,@DEA = @P_DEA_NUM
                                                                                                ,@NABP_Num = @P_NABP_NUM
                                                                                                ,@PrimarySpecialty = @PrimarySpecialtyDescription
                                                                END

                                                                /*******Insert address for Provider
if not exists already******/
                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_PartyId
                                                                                ,@AddressLine1 = @P_LINE1_AD
                                                                                ,@City = @P_CITY_NAM
                                                                                ,@Zip = @P_ZIP5_CD
                                                                                ,@State = @P_ST_CD
                                                                                ,@CurrentModule = 2

                                                                IF @intAddressExists = - 1
                                                                BEGIN
                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD
                                                                                                ,@AddressLine2 = @P_LINE2_AD
                                                                                                ,@City = @P_CITY_NAM
                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                ,@ZipPlus4 = @P_ZIP4_CD
                                                                                                ,@State = @P_ST_CD
                                                                                                ,@DateCreated = @now

                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                ,@PartyID = @PDM_PartyId
                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                ,@DateCreated = @now
                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                END --End Provider Address Insert                           

                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_PartyId
                                                                                ,@AddressLine1 = @P_LINE1_AD1
                                                                                ,@City = @P_CITY_NAM1
                                                                                ,@Zip = @P_ZIP5_CD1
                                                                                ,@State = @P_ST_CD1
                                                                                ,@CurrentModule = 2

                                                                IF @intAddressExists = - 1
                                                                BEGIN
                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD1
                                                                                                ,@AddressLine2 = @P_LINE2_AD1
                                                                                                ,@City = @P_CITY_NAM1
                                                                                                ,@Zip = @P_ZIP5_CD1
                                                                                                ,@ZipPlus4 = @P_ZIP4_CD1
                                                                                                ,@State = @P_ST_CD1
                                                                                                ,@DateCreated = @now

                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                ,@PartyID = @PDM_PartyId
                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                ,@DateCreated = @now
                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                END --End Provider Address Insert

                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_PartyId
                                                                                ,@AddressLine1 = @P_LINE1_AD2
                                                                                ,@City = @P_CITY_NAM2
                                                                                ,@Zip = @P_ZIP5_CD2
                                                                                ,@State = @P_ST_CD2
                                                                                ,@CurrentModule = 2

                                                                IF @intAddressExists = - 1
                                                                BEGIN
                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD2
                                                                                                ,@AddressLine2 = @P_LINE2_AD2
                                                                                                ,@City = @P_CITY_NAM2
                                                                                                ,@Zip = @P_ZIP5_CD2
                                                                                                ,@ZipPlus4 = @P_ZIP4_CD2
                                                                                                ,@State = @P_ST_CD2
                                                                                                ,@DateCreated = @now

                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                ,@PartyID = @PDM_PartyId
                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                ,@DateCreated = @now
                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                END --End Provider Address Insert

                                                                /********Begin processing of Provider Licenses, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderLicense
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Provider Licenses******/
                                                                                SELECT @FirstLicense = MIN(ID)
                                                                                                ,@CurrentLicense = MIN(ID)
                                                                                                ,@LastLicense = MAX(ID)
                                                                                FROM dbo.ProviderLicense
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentLicense <= @LastLicense)
                                                                                BEGIN
                                                                                                /********Read License Fields of Provider******/
                                                                                                SELECT @P_LIC_CERT_NUM = [P_LIC_CERT_NUM]
                                                                                                                ,@P_LIC_ST_CD = [P_ST_CD]
                                                                                                                ,@P_LIC_BRD_NUM = [P_LIC_BRD_NUM]
                                                                                                                ,@P_LIC_EXP_DT = [P_LIC_EXP_DT]
                                                                                                FROM [dbo].[ProviderLicense]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentLicense

                                                                                                /****Convert Expiry date to datetime**********/
                                                                                                SELECT @P_LIC_EXP_DT_Conv = CONVERT(DATETIME, @P_LIC_EXP_DT, 121)

                                                                                                SELECT @P_LIC_CERT_NUM = REPLACE(@P_LIC_CERT_NUM, '.', '')

                                                                                                /*******Try to find the LicenseID of the provider*****/
                                                                                                EXEC @PDM_LicenseID = [KYP].[p_FindLicenseRecord] @PartyID = @PDM_PartyId
                                                                                                                ,@LicenseState = @P_LIC_ST_CD
                                                                                                                ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                ,@CurrentModule = 2
                                                                                                                ,@ExpiryDate = @P_LIC_EXP_DT_Conv

                                                                                                /*******If LicenseID not found, insert record in
******PDM_License table, else update record******/
                                                                                                IF @PDM_LicenseID = - 1
                                                                                                                EXEC [KYP].[p_InsertPDMLicense] @PartyID = @PDM_PartyId
                                                                                                                                ,@LicenseState = @P_LIC_ST_CD
                                                                                                                                ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                                ,@LicenseAuthority = @P_LIC_BRD_NUM
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@ExpiryDate = @P_LIC_EXP_DT_Conv
                                                                                                ELSE IF @PDM_LicenseID IS NOT NULL
                                                                                                                AND @PDM_LicenseID <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMLicense] @PartyID = @PDM_PartyId
                                                                                                                                ,@LicenseState = @P_LIC_ST_CD
                                                                                                                                ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                                ,@LicenseAuthority = @P_LIC_BRD_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                ,@ExpiryDate = @P_LIC_EXP_DT_Conv

                                                                                                /*****Nullify all License Fields for next iteration*******/
                                                                                                SELECT @P_LIC_CERT_NUM = NULL
                                                                                                                ,@P_LIC_ST_CD = NULL
                                                                                                                ,@P_LIC_BRD_NUM = NULL
                                                                                                                ,@P_LIC_EXP_DT = NULL
                                                                                                                ,@P_LIC_EXP_DT_Conv = NULL

                                                                                                SELECT @CurrentLicense = MIN(ID)
                                                                                                FROM dbo.ProviderLicense
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentLicense
                                                                                END --End while for license
                                                                END --End License Processing Block

                                                                PRINT 'Test'

                                                                /********Begin processing of Secondary NPI, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderSecondaryNPI
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Secondary NPI******/
                                                                                SELECT @FirstSecondaryNPI = MIN(ID)
                                                                                                ,@CurrentSecondaryNPI = MIN(ID)
                                                                                                ,@LastSecondaryNPI = MAX(ID)
                                                                                FROM dbo.ProviderSecondaryNPI
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentSecondaryNPI <= @LastSecondaryNPI)
                                                                                BEGIN
                                                                                                /********Read Secondary NPI of Provider******/
                                                                                                SELECT @P_ALT_ID = [P_ALT_ID]
                                                                                                FROM [dbo].[ProviderSecondaryNPI]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentSecondaryNPI

                                                                                                /* linu: integer NPI into to varchar            
select @intNPI = CONVERT(int, @@P_ALT_ID)*/
                                                                                                /*******Try to find the SecondaryNPI of the provider*****/
                                                                                                EXEC @PDM_SecondaryNPI = [KYP].[p_FindSecondaryNPIRecord] @PartyID = @PDM_PartyId
                                                                                                                ,@NPI = @P_ALT_ID
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If Secondary NPI not found, insert record in
******PDM_SecondaryNPI table, else update record******/
                                                                                                IF @PDM_SecondaryNPI = - 1
                                                                                                                EXEC [KYP].[p_InsertPDMSecondaryNPI] @PartyID = @PDM_PartyId
                                                                                                                                ,@NPI = @P_ALT_ID
                                                                                                                                ,@DateCreated = @now
                                                                                                ELSE IF @PDM_SecondaryNPI IS NOT NULL
                                                                                                                AND @PDM_SecondaryNPI <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMSecondaryNPI] @PartyID = @PDM_PartyId
                                                                                                                                ,@NPI = @P_ALT_ID
                                                                                                                                ,@DateModified = @now

                                                                                                /*****Nullify all Secondary NPI Fields for next iteration*******/
                                                                                                SELECT @P_ALT_ID = NULL

                                                                                                SELECT @CurrentSecondaryNPI = MIN(ID)
                                                                                                FROM dbo.ProviderSecondaryNPI
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentSecondaryNPI
                                                                                END --End while for Secondary NPI
                                                                END --End Secondary NPI Processing Block

                                                                /********Begin processing of MCARE, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderMedicare
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Medicare******/
                                                                                SELECT @FirstMedicare = MIN(ID)
                                                                                                ,@CurrentMedicare = MIN(ID)
                                                                                                ,@LastMedicare = MAX(ID)
                                                                                FROM dbo.ProviderMedicare
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentMedicare <= @LastMedicare)
                                                                                BEGIN
                                                                                                /********Read MCARE of Provider******/
                                                                                                SELECT @P_MCARE_NUM = [P_MCARE_NUM]
                                                                                                FROM [dbo].[ProviderMedicare]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentMedicare

                                                                                                /*******Try to find the MCARE of the provider*****/
                                                                                                EXEC @PDM_MCARE_ID = [KYP].[p_FindMCARERecord] @PartyID = @PDM_PartyId
                                                                                                                ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If MCARE not found, insert record in
******PDM_MCARENBR table, else update record******/
                                                                                                IF @PDM_MCARE_ID = - 1
                                                                                                                EXEC [KYP].[p_InsertPDMMCARENBR] @PartyID = @PDM_PartyId
                                                                                                                                ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                                ,@DateCreated = @now
                                                                                                ELSE IF @PDM_MCARE_ID IS NOT NULL
                                                                                                                AND @PDM_MCARE_ID <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMMCARENBR] @PartyID = @PDM_PartyId
                                                                                                                                ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                /*****START - KYP-2827 - Changes*******/
                                                                                                                                ,@MCAREID = @PDM_MCARE_ID

                                                                                                /*****END - KYP-2827 - Changes*******/
                                                                                                /*****Nullify all MCARE Fields for next iteration*******/
                                                                                                SELECT @P_MCARE_NUM = NULL

                                                                                                SELECT @CurrentMedicare = MIN(ID)
                                                                                                FROM dbo.ProviderMedicare
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentMedicare
                                                                                END --End while for MCARE
                                                                END --End MCARE Processing Block

                                                                /*******************Begin Processing of Speciality*****************/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderSpeciality
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Speciality******/
                                                                                SELECT @FirstSpeciality = MIN(ID)
                                                                                                ,@CurrentSpeciality = MIN(ID)
                                                                                                ,@LastSpeciality = MAX(ID)
                                                                                FROM dbo.ProviderSpeciality
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentSpeciality <= @LastSpeciality)
                                                                                BEGIN
                                                                                                /********Read Speciality of Provider******/
                                                                                                SELECT @P_SPECL_CD = [P_SPECL_CD]
                                                                                                FROM [dbo].[ProviderSpeciality]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentSpeciality

                                                                                                /*******Try to find the Speciality of the provider*****/
                                                                                                EXEC @PDM_SpecialityID = [KYP].[p_FindProviderSpeciality] @PartyID = @PDM_PartyId
                                                                                                                ,@Speciality_Code = @P_SPECL_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If Speciality not found, insert record in
******PDM_Speciality table, else update record******/
                                                                                                IF @PDM_SpecialityID = - 1
                                                                                                                EXEC [KYP].[p_InsertPDMSpeciality] @PartyID = @PDM_PartyId
                                                                                                                                ,@Speciality_Code = @P_SPECL_CD
                                                                                                                                ,@DateCreated = @now
                                                                                                ELSE IF @PDM_SpecialityID IS NOT NULL
                                                                                                                AND @PDM_SpecialityID <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMSpeciality] @PartyID = @PDM_PartyId
                                                                                                                                ,@Speciality_Code = @P_SPECL_CD
                                                                                                                                ,@DateModified = @now

                                                                                                /*****Nullify all speciality Fields for next iteration*******/
                                                                                                SELECT @P_SPECL_CD = NULL

                                                                                                SELECT @CurrentSpeciality = MIN(ID)
                                                                                                FROM dbo.[ProviderSpeciality]
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentSpeciality
                                                                                END --End while for Speciality
                                                                END --End Speciality Processing Block

                                                                /*******************Begin Processing of Taxonomy*****************/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderTaxonomy
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Taxonomy******/
                                                                                SELECT @FirstTaxonomy = MIN(ID)
                                                                                                ,@CurrentTaxonomy = MIN(ID)
                                                                                                ,@LastTaxonomy = MAX(ID)
                                                                                FROM dbo.ProviderTaxonomy
                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                AND ISNULL(P_Taxonomy_CD, '') <> ''

                                                                                WHILE (@CurrentTaxonomy <= @LastTaxonomy)
                                                                                BEGIN
                                                                                                /********Read Taxonomy of Provider******/
                                                                                                SELECT @P_TAXONOMY_CD = [P_Taxonomy_CD]
                                                                                                FROM [dbo].[ProviderTaxonomy]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentTaxonomy

                                                                                                /*******Try to find the Taxonomy of the provider*****/
                                                                                                EXEC @PDM_TaxonomyID = KYP.p_FindProviderTaxonomy @PartyID = @PDM_PartyId
                                                                                                                ,@Taxonomy_Code = @P_TAXONOMY_CD
                                                                                                                ,@CurrentModule = 1

                                                                                                /************Try to get Taxonomy Description *********************/
                                                                                                SELECT @Taxonomy_Desc = [TaxonomyHMSDesc]
                                                                                                FROM [kyp].[LK_Taxonomy]
                                                                                                WHERE [TaxonomyCode] = @P_TAXONOMY_CD

                                                                                                /*******If Taxonomy not found, insert record in
******PDM_Taxonomy table, else update record******/
                                                                                                IF @PDM_TaxonomyID = - 1
                                                                                                                AND @P_TAXONOMY_CD IS NOT NULL
                                                                                                                EXEC [KYP].[p_InsertPDMTaxonomy] @PartyID = @PDM_PartyId
                                                                                                                                ,@Taxonomy = @P_TAXONOMY_CD
                                                                                                                                ,@TaxonomyDesc = @Taxonomy_Desc
                                                                                                ELSE IF @PDM_TaxonomyID IS NOT NULL
                                                                                                                AND @PDM_TaxonomyID <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMTaxonomy] @TaxonomyID = @PDM_TaxonomyID
                                                                                                                                ,@PartyID = @PDM_PartyId
                                                                                                                                ,@Taxonomy = @P_Taxonomy_CD
                                                                                                                                ,@TaxonomyDesc = @Taxonomy_Desc

                                                                                                /*****Nullify all Taxonomy Fields for next iteration*******/
                                                                                                SELECT @P_TAXONOMY_CD = NULL

                                                                                                SELECT @CurrentTaxonomy = MIN(ID)
                                                                                                FROM dbo.[ProviderTaxonomy]
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ISNULL(P_Taxonomy_CD, '') <> ''
                                                                                                                AND ID > @CurrentTaxonomy
                                                                                END --End while for Taxonomy
                                                                END --End Taxonomy Processing Block

                                                                /********Begin processing of CLIA, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderCLIA
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing CLIA******/
                                                                                SELECT @FirstCLIA = MIN(ID)
                                                                                                ,@CurrentCLIA = MIN(ID)
                                                                                                ,@LastCLIA = MAX(ID)
                                                                                FROM dbo.ProviderCLIA
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentCLIA <= @LastCLIA)
                                                                                BEGIN
                                                                                                /********Read CLIA Nbr of Provider******/
                                                                                                SELECT @P_CLIA_NUM = [P_CLIA_NUM]
                                                                                                FROM [dbo].[ProviderCLIA]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentCLIA

                                                                                                /*******Try to find the CLIA Nbr of the provider*****/
                                                                                                EXEC @PDM_CLIA_ID = [KYP].[p_FindCLIARecord] @PartyID = @PDM_PartyId
                                                                                                                ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If CLIA NBR not found, insert record in
******PDM_CLIA table, else update record******/
                                                                                                IF @PDM_CLIA_ID = - 1
                                                                                                                EXEC [KYP].[p_InsertPDMCLIA] @PartyID = @PDM_PartyId
                                                                                                                                ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                                ,@DateCreated = @now
                                                                                                ELSE IF @PDM_CLIA_ID IS NOT NULL
                                                                                                                AND @PDM_CLIA_ID <> 0
                                                                                                                EXEC [KYP].[p_UpdatePDMCLIA] @PartyID = @PDM_PartyId
                                                                                                                                ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                                ,@DateModified = @now

                                                                                                /*****Nullify all CLIA Fields for next iteration*******/
                                                                                                SELECT @P_CLIA_NUM = NULL

                                                                                                SELECT @CurrentCLIA = MIN(ID)
                                                                                                FROM dbo.ProviderCLIA
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentCLIA
                                                                                END --End while for CLIA
                                                                END --End CLIA Processing Block

                                                                /********Begin processing of Individual Owners, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderIndOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Individual Owners******/
                                                                                SELECT @FirstIndOwner = MIN(ID)
                                                                                                ,@CurrentIndOwner = MIN(ID)
                                                                                                ,@LastIndOwner = MAX(ID)
                                                                                FROM dbo.ProviderIndOwner
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentIndOwner <= @LastIndOwner)
                                                                                BEGIN
                                                                                                /********Read Individual Owner Name and Address******/
                                                                                                SELECT @P_OWNER_LAST_NAM = [P_OWNER_LAST_NAM]
                                                                                                                ,@P_OWNER_FST_NAM = [P_OWNER_FST_NAM]
                                                                                                                ,@P_OWNER_MI_NAM = [P_OWNER_MI_NAM]
                                                                                                                ,@P_OWNER_TITL_NAM = [P_OWNER_TITL_NAM]
                                                                                                                ,@P_OWNER_DOB_DT = [P_OWNER_DOB_DT]
                                                                                                                ,@P_OWNER_SSN_NUM = [P_OWNER_SSN_NUM]
                                                                                                                ,@P_OWNER_LINE1_AD = [P_LINE1_AD]
                                                                                                                ,@P_OWNER_LINE2_AD = [P_LINE2_AD]
                                                                                                                ,@P_OWNER_CITY_NAM = [P_CITY_NAM]
                                                                                                                ,@P_OWNER_ST_CD = [P_ST_CD]
                                                                                                                ,@P_OWNER_ZIP5_CD = [P_ZIP5_CD]
                                                                                                                ,@P_OWNER_ZIP4_CD = [P_ZIP4_CD]
                                                                                                                ,@P_OWNER_NPI_IND = CONVERT(INT,[Owner_NPI])
                                                                                                FROM [dbo].[ProviderIndOwner]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentIndOwner
                                                                                                                
                                                                                                SELECT @P_OWNER_NPI_IND = Pr.NPI FROM KYPPORTAL.PortalKYP.pPDM_Provider Pr
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Person Pe ON Pr.PartyID = Pe.PartyID
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party P ON Pe.PartyID = P.PartyID 
																								INNER JOIN KYPPORTAL.PortalKYP.pADM_Application A ON A.PartyID = P.ParentPartyID 
																								WHERE A.ApplicationNo = @ProviderOrApplicationNbr 
																								AND P.Type = 'Individual Ownership'  
																								AND Pe.LastName = @P_OWNER_LAST_NAM 
																								AND Pe.FirstName = @P_OWNER_FST_NAM 
																								AND REPLACE(Pe.SSN,'-','') = @P_OWNER_SSN_NUM

                                                                                                /*KYP3.3 To check the application type for MOCA change for Owner*/
                                                                                                SELECT @FullName = COALESCE(@P_OWNER_LAST_NAM, '') + COALESCE(@P_OWNER_FST_NAM, '')

                                                                                                EXEC @PDM_appType = [kyp].[p_AddApplicationType] @P_OWNER_SSN_NUM = @P_OWNER_SSN_NUM
                                                                                                                ,@FullName = @FullName

                                                                                                IF @PDM_appType = - 1
                                                                                                                SET @ApplnType = 'MOCA CHANGE'
                                                                                                ELSE
                                                                                                                SET @ApplnType = 'Data Update'

                                                                                                /********Remove the leading and trailing single quotes**************/
                                                                                                SELECT @P_OWNER_LAST_NAM = KYP.RemoveSingleQuotes(@P_OWNER_LAST_NAM)

                                                                                                SELECT @P_OWNER_FST_NAM = KYP.RemoveSingleQuotes(@P_OWNER_FST_NAM)

                                                                                                SELECT @P_OWNER_MI_NAM = KYP.RemoveSingleQuotes(@P_OWNER_MI_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_OWNER_LAST_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_LAST_NAM)

                                                                                                SELECT @P_OWNER_FST_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_FST_NAM)

                                                                                                SELECT @P_OWNER_MI_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_MI_NAM)

                                                                                                /********Derive Owner's Full Name******/
                                                                                                SELECT @P_OWNER_LAST_NAM = rtrim(ltrim(Replace(REPLACE(@P_OWNER_LAST_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_OWNER_FST_NAM = rtrim(ltrim(Replace(REPLACE(@P_OWNER_FST_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_OWNER_MI_NAM = rtrim(ltrim(Replace(REPLACE(@P_OWNER_MI_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_OWNER_FULL_NAM = @P_OWNER_LAST_NAM + COALESCE((', ' + @P_OWNER_FST_NAM), '') + COALESCE((' ' + @P_OWNER_MI_NAM), '')

                                                                                                /*******Try to find the PartyID of the owner******/
                                                                                                EXEC @PDM_OwnerPartyId = KYP.p_FindIndParty @LastName = @P_OWNER_LAST_NAM
                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Person and PDM_Owner tables******/
                                                                                                IF @PDM_OwnerPartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                ,@Name = @P_OWNER_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 2

                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT
                                                                                                                                ,@NPI = @P_OWNER_NPI_IND
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                ,@DateCreated = @now
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Person and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_FULL_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT
                                                                                                                                ,@NPI = @P_OWNER_NPI_IND
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 2

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Insert 2 addresses for Owner, One for Owner, 
other for Provider******/
                                                                                                /*******=====>Owner Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@AddressLine1 = @P_OWNER_LINE1_AD
                                                                                                                ,@City = @P_OWNER_CITY_NAM
                                                                                                                ,@Zip = @P_OWNER_ZIP5_CD
                                                                                                                ,@State = @P_OWNER_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_OWNER_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_OWNER_LINE2_AD
                                                                                                                                ,@City = @P_OWNER_CITY_NAM
                                                                                                                                ,@Zip = @P_OWNER_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_OWNER_ZIP4_CD
                                                                                                                                ,@State = @P_OWNER_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Owner Address Insert

                                                                                                /*******=====>Provider Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@AddressLine1 = @P_LINE1_AD
                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                ,@State = @P_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_LINE2_AD
                                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_ZIP4_CD
                                                                                                                                ,@State = @P_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Provider Address Insert

                                                                                                /*****Nullify all Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_LAST_NAM = NULL
                                                                                                                ,@P_OWNER_FST_NAM = NULL
                                                                                                                ,@P_OWNER_MI_NAM = NULL
                                                                                                                ,@P_OWNER_TITL_NAM = NULL
                                                                                                                ,@P_OWNER_DOB_DT = NULL
                                                                                                                ,@P_OWNER_SSN_NUM = NULL
                                                                                                                ,@P_OWNER_LINE1_AD = NULL
                                                                                                                ,@P_OWNER_LINE2_AD = NULL
                                                                                                                ,@P_OWNER_CITY_NAM = NULL
                                                                                                                ,@P_OWNER_ST_CD = NULL
                                                                                                                ,@P_OWNER_ZIP5_CD = NULL
                                                                                                                ,@P_OWNER_ZIP4_CD = NULL
                                                                                                                ,@P_OWNER_NPI_IND = NULL

                                                                                                SELECT @CurrentIndOwner = MIN(ID)
                                                                                                FROM dbo.ProviderIndOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentIndOwner
                                                                                END --End While loop for Individual Owners
                                                                END --End of Individual Owner processing block

                                                                /********Begin processing of Organizational Owners, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderOrgOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Organizational Owners******/
                                                                                SELECT @FirstOrgOwner = MIN(ID)
                                                                                                ,@CurrentOrgOwner = MIN(ID)
                                                                                                ,@LastOrgOwner = MAX(ID)
                                                                                FROM dbo.ProviderOrgOwner
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentOrgOwner <= @LastOrgOwner)
                                                                                BEGIN
                                                                                                /********Read Organizational Owner Name and Address******/
                                                                                                SELECT @P_OWNER_BUSN_NAM = [P_OWNER_BUSN_NAM]
                                                                                                                ,@P_OWNER_DBA_NAM = [P_OWNER_DBA_NAM]
                                                                                                                ,@P_OWNER_TAX_ID = [P_OWNER_TAX_ID]
                                                                                                                ,@P_BUSN_LINE1_AD = [P_BUSN_LINE1_AD]
                                                                                                                ,@P_BUSN_LINE2_AD = [P_BUSN_LINE2_AD]
                                                                                                                ,@P_BUSN_CITY_NAM = [P_BUSN_CITY_NAM]
                                                                                                                ,@P_BUSN_ST_CD = [P_BUSN_ST_CD]
                                                                                                                ,@P_BUSN_ZIP5_CD = [P_BUSN_ZIP5_CD]
                                                                                                                ,@P_BUSN_ZIP4_CD = [P_BUSN_ZIP4_CD]
                                                                                                                ,@Owner_NPI = CONVERT(INT,Owner_NPI)
                                                                                                FROM [dbo].[ProviderOrgOwner]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentOrgOwner
                                                                                                                
                                                                                                SELECT @Owner_NPI = O.NPI FROM KYPPORTAL.PortalKYP.pPDM_Organization O
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party P ON O.PartyID = P.PartyID 
																								INNER JOIN KYPPORTAL.PortalKYP.pADM_Application A ON A.PartyID = P.ParentPartyID 
																								WHERE A.ApplicationNo = @ProviderOrApplicationNbr 
																								AND P.Type = 'Entity Ownership' 
																								AND O.LegalName = @P_OWNER_BUSN_NAM 
																								AND O.DBAName1 = @P_OWNER_DBA_NAM 
																								AND REPLACE(O.EIN,'-','') = @P_OWNER_TAX_ID

                                                                                                /********Derive Organizational Owner's Name******/
                                                                                                /*************Remove single quotes*****************/
                                                                                                SELECT @P_OWNER_BUSN_NAM = KYP.RemoveSingleQuotes(@P_OWNER_BUSN_NAM)

                                                                                                SELECT @P_OWNER_DBA_NAM = KYP.RemoveSingleQuotes(@P_OWNER_DBA_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_OWNER_BUSN_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_BUSN_NAM)

                                                                                                SELECT @P_OWNER_DBA_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_DBA_NAM)

                                                                                                SELECT @P_OWNER_BUSN_NAM = COALESCE(@P_OWNER_BUSN_NAM, @P_OWNER_DBA_NAM)

                                                                                                /*******Try to find the PartyID of the Organizational owner******/
                                                                                                EXEC @PDM_OwnerPartyId = KYP.p_FindOrgParty @OrgName = @P_OWNER_BUSN_NAM
                                                                                                                ,@TAXID = @P_OWNER_TAX_ID
                                                                                                                ,@City = @P_BUSN_CITY_NAM
                                                                                                                ,@ZIP = @P_BUSN_ZIP5_CD
                                                                                                                ,@Adr_Line1 = @P_BUSN_LINE1_AD
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Organization and PDM_Owner tables******/
                                                                                                IF @PDM_OwnerPartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 2

                                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@NPI = @Owner_NPI

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@DateCreated = @now
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Organization and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM
                                                                                                                                ,@DateModified = @now
                                                                                                                                ,@NPI = @Owner_NPI

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 2

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Insert 2 addresses for Owner, One for Owner, 
other for Provider******/
                                                                                                /*******=====>Owner Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@AddressLine1 = @P_BUSN_LINE1_AD
                                                                                                                ,@City = @P_BUSN_CITY_NAM
                                                                                                                ,@Zip = @P_BUSN_ZIP5_CD
                                                                                                                ,@State = @P_BUSN_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_BUSN_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_BUSN_LINE2_AD
                                                                                                                                ,@City = @P_BUSN_CITY_NAM
                                                                                                                                ,@Zip = @P_BUSN_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_BUSN_ZIP4_CD
                                                                                                                                ,@State = @P_BUSN_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Owner Address Insert

                                                                                                /*******=====>Provider Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@AddressLine1 = @P_LINE1_AD
                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                ,@State = @P_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_LINE2_AD
                                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_ZIP4_CD
                                                                                                                                ,@State = @P_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Provider Address Insert

                                                                                                /*****Nullify all Organizational Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_BUSN_NAM = NULL
                                                                                                                ,@P_OWNER_DBA_NAM = NULL
                                                                                                                ,@P_OWNER_TAX_ID = NULL
                                                                                                                ,@P_BUSN_LINE1_AD = NULL
                                                                                                                ,@P_BUSN_LINE2_AD = NULL
                                                                                                                ,@P_BUSN_CITY_NAM = NULL
                                                                                                                ,@P_BUSN_ST_CD = NULL
                                                                                                                ,@P_BUSN_ZIP5_CD = NULL
                                                                                                                ,@P_BUSN_ZIP4_CD = NULL
                                                                                                                ,@Owner_NPI = NULL

                                                                                                SELECT @CurrentOrgOwner = MIN(ID)
                                                                                                FROM dbo.ProviderOrgOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentOrgOwner
                                                                                END --End While loop for Organizational Owners
                                                                END --End of Organizational Owner processing block

                                                                /********Begin processing of MD Employees, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderEmployee
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing MD Employees******/
                                                                                SELECT @FirstEmployee = MIN(ID)
                                                                                                ,@CurrentEmployee = MIN(ID)
                                                                                                ,@LastEmployee = MAX(ID)
                                                                                FROM dbo.ProviderEmployee
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentEmployee <= @LastEmployee)
                                                                                BEGIN
                                                                                                /********Read MD Employee's Name and Address******/
                                                                                                SELECT @P_EMPL_LAST_NAM = [P_EMPL_LAST_NAM]
                                                                                                                ,@P_EMPL_FST_NAM = [P_EMPL_FST_NAM]
                                                                                                                ,@P_EMPL_MI_NAM = [P_EMPL_MI_NAM]
                                                                                                                ,@P_EMPL_TITL_NAM = [P_EMPL_TITL_NAM]
                                                                                                                ,@P_EMPL_SSN = [P_EMPL_SSN]
                                                                                                                ,@P_EMPL_DOB_DT = [P_EMPL_DOB_DT]
                                                                                                                ,@P_EMPL_LINE1_AD = [P_LINE1_AD]
                                                                                                                ,@P_EMPL_LINE2_AD = [P_LINE2_AD]
                                                                                                                ,@P_EMPL_CITY_NAM = [P_CITY_NAM]
                                                                                                                ,@P_EMPL_ST_CD = [P_ST_CD]
                                                                                                                ,@P_EMPL_ZIP5_CD = [P_ZIP5_CD]
                                                                                                                ,@P_EMPL_ZIP4_CD = [P_ZIP4_CD]
                                                                                                FROM [dbo].[ProviderEmployee]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentEmployee

                                                                                                SELECT @FullName = COALESCE(@P_EMPL_LAST_NAM, '') + COALESCE(@P_EMPL_FST_NAM, '')

                                                                                                /*KYP3.3 To check the application type for MOCA change for Employee*/
                                                                                                EXEC @PDM_appType = [kyp].[p_AddApplicationType] @P_EMPL_SSN = @P_EMPL_SSN
                                                                                                                ,@FullName = @FullName

                                                                                                IF @PDM_appType = - 1
                                                                                                                SET @ApplnType = 'MOCA CHANGE'
                                                                                                ELSE
                                                                                                                SET @ApplnType = 'Data Update'

                                                                                                /********Remove the leading and trailing single quotes**************/
                                                                                                SELECT @P_EMPL_LAST_NAM = KYP.RemoveSingleQuotes(@P_EMPL_LAST_NAM)

                                                                                                SELECT @P_EMPL_FST_NAM = KYP.RemoveSingleQuotes(@P_EMPL_FST_NAM)

                                                                                                SELECT @P_EMPL_MI_NAM = KYP.RemoveSingleQuotes(@P_EMPL_MI_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_EMPL_LAST_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_LAST_NAM)

                                                                                                SELECT @P_EMPL_FST_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_FST_NAM)

                                                                                                SELECT @P_EMPL_MI_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_MI_NAM)

                                                                                                /********Derive MD Employee's Full Name******/
                                                                                                SELECT @P_EMPL_LAST_NAM = rtrim(ltrim(Replace(REPLACE(@P_EMPL_LAST_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_EMPL_FST_NAM = rtrim(ltrim(Replace(REPLACE(@P_EMPL_FST_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_EMPL_MI_NAM = rtrim(ltrim(Replace(REPLACE(@P_EMPL_MI_NAM, ', ', ' '), ',', ' ')))

                                                                                                SELECT @P_EMPL_FULL_NAM = @P_EMPL_LAST_NAM + COALESCE((', ' + @P_EMPL_FST_NAM), '') + COALESCE((' ' + @P_EMPL_MI_NAM), '')

                                                                                                /*******Try to find the PartyID of the MD Employee******/
                                                                                                EXEC @PDM_EmployeePartyId = KYP.p_FindIndParty @LastName = @P_EMPL_LAST_NAM
                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                ,@CurrentModule = 2

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Person and PDM_Owner tables******/
                                                                                                IF @PDM_EmployeePartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_EmployeePartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                ,@Name = @P_EMPL_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 2

                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                                ,@Salunation = @P_EMPL_TITL_NAM
                                                                                                                                ,@FirstName = @P_EMPL_FST_NAM
                                                                                                                                ,@LastName = @P_EMPL_LAST_NAM
                                                                                                                                ,@MiddleName = @P_EMPL_MI_NAM
                                                                                                                                ,@DoB = @P_EMPL_DOB_DT
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                ,@DateCreated = @now
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Person and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_EmployeePartyId IS NOT NULL
                                                                                                                                AND @PDM_EmployeePartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@Name = @P_EMPL_FULL_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                                ,@Salunation = @P_EMPL_TITL_NAM
                                                                                                                                ,@FirstName = @P_EMPL_FST_NAM
                                                                                                                                ,@LastName = @P_EMPL_LAST_NAM
                                                                                                                                ,@MiddleName = @P_EMPL_MI_NAM
                                                                                                                                ,@DoB = @P_EMPL_DOB_DT
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_EmployeeID = [KYP].[p_FindEmployeeRecord] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 2

                                                                                                                IF @PDM_EmployeeID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_EmployeeID IS NOT NULL
                                                                                                                                AND @PDM_EmployeeID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Insert 2 addresses for Employee, One for Employee, 
other for Provider******/
                                                                                                /*******=====>Employee Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_EmployeePartyId
                                                                                                                ,@AddressLine1 = @P_EMPL_LINE1_AD
                                                                                                                ,@City = @P_EMPL_CITY_NAM
                                                                                                                ,@Zip = @P_EMPL_ZIP5_CD
                                                                                                                ,@State = @P_EMPL_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_EMPL_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_EMPL_LINE2_AD
                                                                                                                                ,@City = @P_EMPL_CITY_NAM
                                                                                                                                ,@Zip = @P_EMPL_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_EMPL_ZIP4_CD
                                                                                                                                ,@State = @P_EMPL_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Employee Address Insert

                                                                                                /*******=====>Provider Address<======********/
                                                                                                EXEC @intAddressExists = [KYP].[p_FindPartyAddress] @PartyID = @PDM_EmployeePartyId
                                                                                                                ,@AddressLine1 = @P_LINE1_AD
                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                ,@State = @P_ST_CD
                                                                                                                ,@CurrentModule = 2

                                                                                                IF @intAddressExists = - 1
                                                                                                BEGIN
                                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD
                                                                                                                                ,@AddressLine2 = @P_LINE2_AD
                                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                                ,@Zip = @P_ZIP5_CD
                                                                                                                                ,@ZipPlus4 = @P_ZIP4_CD
                                                                                                                                ,@State = @P_ST_CD
                                                                                                                                ,@DateCreated = @now

                                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                                ,@PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = NULL
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                                END --End Provider Address Insert

                                                                                                /*****Nullify all Employee Fields for next iteration*******/
                                                                                                SELECT @P_EMPL_LAST_NAM = NULL
                                                                                                                ,@P_EMPL_FST_NAM = NULL
                                                                                                                ,@P_EMPL_MI_NAM = NULL
                                                                                                                ,@P_EMPL_TITL_NAM = NULL
                                                                                                                ,@P_EMPL_SSN = NULL
                                                                                                                ,@P_EMPL_DOB_DT = NULL
                                                                                                                ,@P_EMPL_LINE1_AD = NULL
                                                                                                                ,@P_EMPL_LINE2_AD = NULL
                                                                                                                ,@P_EMPL_CITY_NAM = NULL
                                                                                                                ,@P_EMPL_ST_CD = NULL
                                                                                                                ,@P_EMPL_ZIP5_CD = NULL
                                                                                                                ,@P_EMPL_ZIP4_CD = NULL

                                                                                                SELECT @CurrentEmployee = MIN(ID)
                                                                                                FROM dbo.ProviderEmployee
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentEmployee
                                                                                END --End While loop for MD Employees
                                                                END --End of MD Employee processing block
                                                END --End Of Monitoring processing record
                                                                                /*******Comparison and loading of daily application starts here******/
                                                ELSE IF @FileType = 'D'
                                                BEGIN
                                                                /*******Get First Specialty for PDM_Provider table******/
                                                                SELECT @MinSpecialtyID = MIN(ID)
                                                                FROM dbo.ProviderSpeciality
                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                PRINT 'SPECIALTY FETCH'
                                                                PRINT @MinSpecialtyID

                                                                SELECT @PrimarySpecialtyCode = P_SPECL_CD
                                                                FROM dbo.ProviderSpeciality
                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                AND ID = @MinSpecialtyID

                                                                PRINT @PrimarySpecialtyCode

                                                                SELECT @PrimarySpecialtyDescription = LongDescription
                                                                FROM KYP.PDM_SpecialityCode
                                                                WHERE Value = @PrimarySpecialtyCode

                                                                PRINT @PrimarySpecialtyDescription

                                                                /**********Get Provider Party Name**********/
                                                                IF (@ProviderType = 'O')
                                                                BEGIN
                                                                                SET @ProviderPartyName = @P_NAM
                                                                                IF @ProviderPartyName IS NULL OR @ProviderPartyName = ''
                                                                                BEGIN
                                                                                                SET @ProviderPartyName = @P_FULL_NAM
                                                                                END
                                                                END
                                                                ELSE
                                                                BEGIN
                                                                                SET @ProviderPartyName = @P_FULL_NAM
                                                                                IF @ProviderPartyName IS NULL OR @ProviderPartyName = ''
                                                                                BEGIN
                                                                                                SET @ProviderPartyName = @P_NAM
                                                                                END
                                                                END

                                                                --select @ProviderPartyName = COALESCE(@P_NAM, @P_FULL_NAM)
                                                                PRINT '@Provider Name : ' + @ProviderPartyName

                                                                IF NOT EXISTS (
                                                                                                SELECT 1
                                                                                                FROM KYP.PDM_Party A
                                                                                                INNER JOIN KYP.PDM_Provider B ON A.PartyID = B.PartyID
                                                                                                                AND ISNULL(A.IsDeleted, 0) = 0
                                                                                                WHERE ISNULL(A.CurrentModule, 0) = ISNULL(1, 0)
                                                                                                                AND B.ProvNumber = @P_ID
                                                                                                )
                                                                BEGIN
                                                                                /*******Try to find Provider PartyID ******/
                                                                                EXEC @PDM_ProviderPartyId = KYP.p_FindProviderParty @Name = @ProviderPartyName
                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                ,@ProvNumber = @P_ID
                                                                                                ,@DEA = @P_DEA_NUM
                                                                                                ,@CurrentModule = 1

                                                                                /****If ProviderPartyId not found insert record 
                                                                each in PDM_Party and PDM_Provider********/
                                                                                SELECT @MinCLIAID = MIN(ID)
                                                                                FROM dbo.ProviderCLIA
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                SELECT @ProviderCLIANBR = P_CLIA_NUM
                                                                                FROM dbo.ProviderCLIA
                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                AND ID = @MinCLIAID

                                                                                IF (@PDM_ProviderPartyId = - 1)
                                                                                BEGIN
                                                                                                /* linu: integer NPI into to varchar            
                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                SELECT @Category = CASE 
                                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                                THEN 'Physician'
                                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                                THEN 'Institutional'
                                                                                                                                ELSE NULL
                                                                                                                                END

                                                                                                SELECT @PartyType = CASE 
                                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                                THEN 'Person'
                                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                                THEN 'Organization'
                                                                                                                                ELSE NULL
                                                                                                                                END

                                                                                                EXEC @PDM_ProviderPartyId = [KYP].[p_InsertPDMParty] @Type = @PartyType
                                                                                                                ,@Name = @ProviderPartyName
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@IsTemp = 0
                                                                                                                ,@IsActive = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@IsDeleted = 0
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@CurrentModule = 1

                                                                                                EXEC @PDM_ProviderID = [KYP].[p_InsertPDMProvider] @PartyID = @PDM_ProviderPartyId
                                                                                                                ,@Category = @Category
                                                                                                                ,@Type = @P_TY_CD
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@ProvNumber = @P_ID
                                                                                                                ,@Mon_MedicaidID = @P_ID
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@DEA = @P_DEA_NUM
                                                                                                                ,@CLIA = @ProviderCLIANBR
                                                                                                                ,@NABPNum = @P_NABP_NUM
                                                                                                                ,@PrimarySpecialty = @PrimarySpecialtyDescription
                                                                                END --End if Provider Party not found                      
                                                                                                                /****If ProviderPartyId Found get the ProviderID for it********/
                                                                                ELSE IF @PDM_ProviderPartyId IS NOT NULL
                                                                                                AND @PDM_ProviderPartyId <> 0
                                                                                BEGIN
                                                                                                SELECT @PDM_ProviderID = ProvID
                                                                                                FROM KYP.PDM_Provider
                                                                                                WHERE PartyID = @PDM_ProviderPartyId
                                                                                END --End if Provider Party found                             

                                                                                IF @ProviderType = 'I'
                                                                                BEGIN
                                                                                                /*******Try to find the PartyID of the person******/
                                                                                                EXEC @PDM_PartyId = KYP.p_FindIndParty @LastName = @P_LAST_NAM
                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@LIC_CERT_NUM = NULL
                                                                                                                ,@CurrentModule = 1

                                                                                                /*******If PartyID not found, insert record 
                                                                *********each in PDM_Party and PDM_Person tables******/
                                                                                                IF @PDM_PartyId = - 1
                                                                                                BEGIN
                                                                                                                /* linu: integer NPI into to varchar
                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                /*
                                                                                                                                                
                                                                /********Remove the leading and trailing single quotes**************/

                                                                Select @P_FST_NAM=KYP.RemoveSingleQuotes(@P_FST_NAM)
                                                                Select @P_LAST_NAM=KYP.RemoveSingleQuotes(@P_LAST_NAM)
                                                                Select @P_MI_NAM=KYP.RemoveSingleQuotes(@P_MI_NAM)

                                                                /*************** Remove double quotes******************************/
                                                                Select @P_FST_NAM=KYP.RemoveDoubleQuotes(@P_FST_NAM)
                                                                Select @P_LAST_NAM=KYP.RemoveDoubleQuotes(@P_LAST_NAM)
                                                                Select @P_MI_NAM=KYP.RemoveDoubleQuotes(@P_MI_NAM)
                                                                */
                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_PartyId
                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@TaxID = @P_FED_TAX_ID
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
                                                                *********in PDM_Party and PDM_Person tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                /* linu: integer NPI into to varchar            
                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_PartyId
                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                ,@TaxID = @P_FED_TAX_ID
                                                                                                END
                                                                                END
                                                                                                                /*******Try to find the PartyID of the organization***********/
                                                                                ELSE IF @ProviderType = 'O'
                                                                                BEGIN
                                                                                                EXEC @PDM_PartyId = KYP.p_FindOrgParty @OrgName = @P_NAM
                                                                                                                ,@TAXID = @P_FED_TAX_ID
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                ,@ZIP = @P_ZIP5_CD
                                                                                                                ,@Adr_Line1 = @P_LINE1_AD
                                                                                                                ,@CurrentModule = 1

                                                                                                /*******If PartyID not found, insert record each in 
                                                                *********PDM_Party and PDM_Organization tables******/
                                                                                                IF @PDM_PartyId = - 1
                                                                                                BEGIN
                                                                                                                /* linu: integer NPI into to varchar            
                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                                ,@Name = @P_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_PartyId
                                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                                ,@LegalName = @P_NAM
                                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record in 
                                                                *********PDM_Party and PDM_Organization tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                /* linu: integer NPI into to varchar            
                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                ,@Name = @P_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_PartyId
                                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                                ,@LegalName = @P_NAM
                                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                --,@NPI = @Owner_NPI
                                                                                                END
                                                                                END

                                                                                /*********Populate PDM_MasterParty for Provider Party*****/
                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                ,@PDM_PartyID = @PDM_ProviderPartyId
                                                                                                ,@PDM_PartyName = @ProviderPartyName
                                                                                                ,@Type = 'ProviderParty'

                                                                                IF @ProviderType = 'I'
                                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                                ,@PDM_PartyID = @PDM_PartyId
                                                                                                                ,@PDM_PartyName = @P_FULL_NAM
                                                                                                                ,@Type = 'ProviderPerson'
                                                                                ELSE IF @ProviderType = 'O'
                                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                                ,@PDM_PartyID = @PDM_PartyId
                                                                                                                ,@PDM_PartyName = @P_NAM
                                                                                                                ,@Type = 'ProviderOrganization'
                                                                END --- Resubmission block
                                                                ELSE IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM KYP.PDM_Party A
                                                                                                INNER JOIN KYP.PDM_Provider B ON A.PartyID = B.PartyID
                                                                                                                AND ISNULL(A.IsDeleted, 0) = 0
                                                                                                WHERE A.CurrentModule = 1
                                                                                                                AND B.ProvNumber = @P_ID
                                                                                                )
                                                                BEGIN
                                                                                /* linu: integer NPI into to varchar            
                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                IF @ProviderType = 'I'
                                                                                BEGIN
                                                                                                EXEC @PDM_ProviderPartyId = KYP.p_FindScreenIndParty @TrackingNumber = @P_ID
                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                ,@LIC_CERT_NUM = NULL
                                                                                                                ,@LIC_STATE = NULL
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 1
                                                                                END
                                                                                ELSE IF @ProviderType = 'O'
                                                                                BEGIN
                                                                                                EXEC @PDM_ProviderPartyId = KYP.p_FindScreenOrgParty @TrackingNumber = @P_ID
                                                                                                                ,@OrgName = @P_NAM
                                                                                                                ,@TAXID = @P_FED_TAX_ID
                                                                                                                ,@City = NULL
                                                                                                                ,@ZIP = NULL
                                                                                                                ,@Adr_Line1 = NULL
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 1
                                                                                END

                                                                                /********************if nothing exists**************************/
                                                                                SELECT @MinCLIAID = MIN(ID)
                                                                                FROM dbo.ProviderCLIA
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                SELECT @ProviderCLIANBR = P_CLIA_NUM
                                                                                FROM dbo.ProviderCLIA
                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                AND ID = @MinCLIAID

                                                                                IF (@PDM_ProviderPartyId = - 1)
                                                                                BEGIN
                                                                                                /* linu: integer NPI into to varchar            
                                                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                SELECT @Category = CASE 
                                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                                THEN 'Physician'
                                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                                THEN 'Institutional'
                                                                                                                                ELSE NULL
                                                                                                                                END

                                                                                                SELECT @PartyType = CASE 
                                                                                                                                WHEN @ProviderType = 'I'
                                                                                                                                                THEN 'Person'
                                                                                                                                WHEN @ProviderType = 'O'
                                                                                                                                                THEN 'Organization'
                                                                                                                                ELSE NULL
                                                                                                                                END

                                                                                                EXEC @PDM_ProviderPartyId = [KYP].[p_InsertPDMParty] @Type = @PartyType
                                                                                                                ,@Name = @ProviderPartyName
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@IsTemp = 0
                                                                                                                ,@IsActive = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@IsDeleted = 0
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@CurrentModule = 1

                                                                                                EXEC @PDM_ProviderID = [KYP].[p_InsertPDMProvider] @PartyID = @PDM_ProviderPartyId
                                                                                                                ,@Category = @Category
                                                                                                                ,@Type = @P_TY_CD
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@ProvNumber = @P_ID
                                                                                                                ,@Mon_MedicaidID = @P_ID
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@DEA = @P_DEA_NUM
                                                                                                                ,@CLIA = @ProviderCLIANBR
                                                                                                                ,@NABPNum = @P_NABP_NUM
                                                                                                                ,@PrimarySpecialty = @PrimarySpecialtyDescription

                                                                                                IF @ProviderType = 'I'
                                                                                                BEGIN
                                                                                                                /*******Try to find the PartyID of the person******/
                                                                                                                EXEC @PDM_PartyId = KYP.p_FindIndParty @LastName = @P_LAST_NAM
                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@LIC_CERT_NUM = NULL
                                                                                                                                ,@CurrentModule = 1

                                                                                                                /*******If PartyID not found, insert record 
                                                                                                                                                                                                                *********each in PDM_Party and PDM_Person tables******/
                                                                                                                IF @PDM_PartyId = - 1
                                                                                                                BEGIN
                                                                                                                                /* linu: integer NPI into to varchar
                                                                                                                                                                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                                                ,@IsProvider = 0
                                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                                ,@IsTemp = 0
                                                                                                                                                ,@IsActive = 1
                                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                                ,@IsDeleted = 0
                                                                                                                                                ,@DateCreated = @now
                                                                                                                                                ,@CurrentModule = 1

                                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_PartyId
                                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                                                ,@TaxID = @P_FED_TAX_ID
                                                                                                                END
                                                                                                                                                /*******If PartyID found, update the record 
                                                                                                                                                                                                                *********in PDM_Party and PDM_Person tables******/
                                                                                                                ELSE IF (
                                                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                                                )
                                                                                                                BEGIN
                                                                                                                                /* linu: integer NPI into to varchar            
                                                                                                                                                                                                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                                                ,@IsProvider = 0
                                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                                ,@DateModified = @now

                                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_PartyId
                                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                                ,@DateModified = @now
                                                                                                                                                ,@TaxID = @P_FED_TAX_ID
                                                                                                                END
                                                                                                END
                                                                                                                                /*******Try to find the PartyID of the organization***********/
                                                                                                ELSE IF @ProviderType = 'O'
                                                                                                BEGIN
                                                                                                                EXEC @PDM_PartyId = KYP.p_FindOrgParty @OrgName = @P_NAM
                                                                                                                                ,@TAXID = @P_FED_TAX_ID
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@City = @P_CITY_NAM
                                                                                                                                ,@ZIP = @P_ZIP5_CD
                                                                                                                                ,@Adr_Line1 = @P_LINE1_AD
                                                                                                                                ,@CurrentModule = 1

                                                                                                                /*******If PartyID not found, insert record each in 
                                                                                                                                                                                                *********PDM_Party and PDM_Organization tables******/
                                                                                                                IF @PDM_PartyId = - 1
                                                                                                                BEGIN
                                                                                                                                /* linu: integer NPI into to varchar            
                                                                                                                                                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                                EXEC @PDM_PartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                                                ,@Name = @P_NAM
                                                                                                                                                ,@IsProvider = 0
                                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                                ,@IsTemp = 0
                                                                                                                                                ,@IsActive = 1
                                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                                ,@IsDeleted = 0
                                                                                                                                                ,@DateCreated = @now
                                                                                                                                                ,@CurrentModule = 1

                                                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_PartyId
                                                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                                                ,@LegalName = @P_NAM
                                                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                END
                                                                                                                                                /*******If PartyID found, update the record in 
                                                                                                                                                                                                *********PDM_Party and PDM_Organization tables******/
                                                                                                                ELSE IF (
                                                                                                                                                @PDM_PartyId IS NOT NULL
                                                                                                                                                AND @PDM_PartyId <> 0
                                                                                                                                                )
                                                                                                                BEGIN
                                                                                                                                /* linu: integer NPI into to varchar
                                                                                                                                                                                                                select @intNPI = CONVERT(int, @P_NPI_NUM)*/
                                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                                ,@Name = @P_NAM
                                                                                                                                                ,@IsProvider = 0
                                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                                ,@DateModified = @now

                                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_PartyId
                                                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                                                ,@LegalName = @P_NAM
                                                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                                ,@DateModified = @now
                                                                                                                                                --,@NPI = @Owner_NPI
                                                                                                                END
                                                                                                END

                                                                                                /*********Populate PDM_MasterParty for Provider Party*****/
                                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                                ,@PDM_PartyID = @PDM_ProviderPartyId
                                                                                                                ,@PDM_PartyName = @ProviderPartyName
                                                                                                                ,@Type = 'ProviderParty'

                                                                                                IF @ProviderType = 'I'
                                                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                                                ,@PDM_PartyID = @PDM_PartyId
                                                                                                                                ,@PDM_PartyName = @P_FULL_NAM
                                                                                                                                ,@Type = 'ProviderPerson'
                                                                                                ELSE IF @ProviderType = 'O'
                                                                                                                EXEC [KYP].[p_InsertPDMMasterParty] @ProviderNumber = @P_ID
                                                                                                                                ,@PDM_PartyID = @PDM_PartyId
                                                                                                                                ,@PDM_PartyName = @P_NAM
                                                                                                                                ,@Type = 'ProviderOrganization'
                                                                                END --End if Provider Party not found                      
                                                                                                                /***********if old party then it will not create new party*********************/
                                                                                ELSE
                                                                                BEGIN
                                                                                                SELECT @PDM_ProviderPartyId = B.PartyID
                                                                                                FROM KYP.PDM_Party A
                                                                                                INNER JOIN KYP.PDM_Provider B ON A.PartyID = B.PartyID
                                                                                                                AND ISNULL(A.IsDeleted, 0) = 0
                                                                                                WHERE A.CurrentModule = 1
                                                                                                                AND B.ProvNumber = @P_ID
                                                                                                                AND A.IsEnrolled = 1

                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_ProviderPartyId
                                                                                                                ,@Name = @ProviderPartyName
                                                                                                                ,@IsProvider = 1
                                                                                                                ,@LoadType = @LoadType
                                                                                                                ,@LoadID = @LoadID
                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                ,@DateModified = @now

                                                                                                EXEC KYP.p_UpdatePDMProvider @PartyID = @PDM_ProviderPartyId
                                                                                                                ,@Category = @Category
                                                                                                                ,@Type = @P_TY_CD
                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                ,@DateModified = @now
                                                                                                                ,@IsEnrolled = 1
                                                                                                                ,@ProvNumber = @P_ID
                                                                                                                ,@Mon_MedicaidID = @P_ID
                                                                                                                ,@DEA = @P_DEA_NUM

                                                                                                UPDATE KYP.PDM_MasterParty
                                                                                                SET PDM_PartyName = @ProviderPartyName
                                                                                                WHERE ProviderNumber = @P_ID
                                                                                                                AND Type = 'ProviderParty'

                                                                                                IF @ProviderType = 'I'
                                                                                                BEGIN
                                                                                                                SELECT @PDM_PartyId = PDM_PartyID
                                                                                                                FROM KYP.PDM_MasterParty
                                                                                                                WHERE ProviderNumber = @P_ID
                                                                                                                                AND Type = 'ProviderPerson'

                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                ,@Name = @P_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_PartyId
                                                                                                                                ,@SSN = @P_SSN_NUM
                                                                                                                                ,@Salunation = @P_SFX_NAM
                                                                                                                                ,@FirstName = @P_FST_NAM
                                                                                                                                ,@LastName = @P_LAST_NAM
                                                                                                                                ,@MiddleName = @P_MI_NAM
                                                                                                                                ,@DoB = @P_DOB_DT
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                ,@TaxID = @P_FED_TAX_ID

                                                                                                                UPDATE KYP.PDM_MasterParty
                                                                                                                SET PDM_PartyName = @P_FULL_NAM
                                                                                                                WHERE ProviderNumber = @P_ID
                                                                                                                                AND Type = 'ProviderPerson'
                                                                                                END
                                                                                                ELSE IF @ProviderType = 'O'
                                                                                                BEGIN
                                                                                                                SELECT @PDM_PartyId = PDM_PartyID
                                                                                                                FROM KYP.PDM_MasterParty
                                                                                                                WHERE ProviderNumber = @P_ID
                                                                                                                                AND Type = 'ProviderOrganization'

                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_PartyId
                                                                                                                                ,@Name = @P_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_PartyId
                                                                                                                                ,@TIN = @P_FED_TAX_ID
                                                                                                                                ,@LegalName = @P_NAM
                                                                                                                                ,@DBAName1 = @P_DBA_NAM
                                                                                                                                ,@NPI = @P_NPI_NUM
                                                                                                                                ,@DateModified = @now
                                                                                                                                --,@NPI = @Owner_NPI

                                                                                                                UPDATE KYP.PDM_MasterParty
                                                                                                                SET PDM_PartyName = @P_NAM
                                                                                                                WHERE ProviderNumber = @P_ID
                                                                                                                                AND Type = 'ProviderOrganization'
                                                                                                END
                                                                                END
                                                                END -- Resubmission block end 

                                                                
                                                                /**********Try to get typedescription and priority for provider type *************/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderTaxonomy
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Taxonomy******/
                                                                                SELECT @FirstTaxonomy = MIN(ID)
                                                                                                ,@CurrentTaxonomy = MIN(ID)
                                                                                                ,@LastTaxonomy = MAX(ID)
                                                                                FROM dbo.ProviderTaxonomy
                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                AND ISNULL(P_Taxonomy_CD, '') <> ''

                                                                                WHILE (@CurrentTaxonomy <= @LastTaxonomy)
                                                                                BEGIN
                                                                                                /********Read Taxonomy of Provider******/
                                                                                                SELECT @P_TAXONOMY_CD = [P_Taxonomy_CD]
                                                                                                FROM [dbo].[ProviderTaxonomy]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentTaxonomy

                                                                                                /*******Try to find the Taxonomy of the provider*****/
                                                                                                EXEC @PDM_TaxonomyID = KYP.p_FindProviderTaxonomy @PartyID = @PDM_ProviderPartyId
                                                                                                                ,@Taxonomy_Code = @P_TAXONOMY_CD
                                                                                                                ,@CurrentModule = 1

                                                                                                PRINT 'TAXONOMY : '
                                                                                                PRINT @PDM_PartyId
                                                                                                PRINT @PDM_TaxonomyID

                                                                                                /************Try to get Taxonomy Description *********************/
                                                                                                SELECT @Taxonomy_Desc = [TaxonomyHMSDesc]
                                                                                                FROM [kyp].[LK_Taxonomy]
                                                                                                WHERE [TaxonomyCode] = @P_TAXONOMY_CD

                                                                                                --exec  [KYP].[p_InsertPDMTaxonomy]
                                                                                                --                             @PartyID = @PDM_PartyId
                                                                                                --                             ,@Taxonomy = @P_TAXONOMY_CD
                                                                                                --                             ,@TaxonomyDesc=@Taxonomy_Desc
                                                                                                /*******If Taxonomy not found, insert record in
******PDM_Taxonomy table, else update record******/
                                                                                                IF @PDM_TaxonomyID = - 1
                                                                                                BEGIN
                                                                                                                PRINT 'TAXONOMY INSERT'

                                                                                                                EXEC [KYP].[p_InsertPDMTaxonomy] @PartyID = @PDM_ProviderPartyId
                                                                                                                                ,@Taxonomy = @P_TAXONOMY_CD
                                                                                                                                ,@TaxonomyDesc = @Taxonomy_Desc
                                                                                                END
                                                                                                ELSE IF @PDM_TaxonomyID IS NOT NULL
                                                                                                                AND @PDM_TaxonomyID <> 0
                                                                                                BEGIN
                                                                                                                PRINT 'TAXONOMY UPDATE'

                                                                                                                EXEC [KYP].[p_UpdatePDMTaxonomy] @TaxonomyID = @PDM_TaxonomyID
                                                                                                                                ,@PartyID = @PDM_ProviderPartyId
                                                                                                                                ,@Taxonomy = @P_Taxonomy_CD
                                                                                                                                ,@TaxonomyDesc = @Taxonomy_Desc
                                                                                                END

                                                                                                /*****Nullify all Taxonomy Fields for next iteration*******/
                                                                                                SELECT @P_TAXONOMY_CD = NULL

                                                                                                SELECT @CurrentTaxonomy = MIN(ID)
                                                                                                FROM dbo.[ProviderTaxonomy]
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ISNULL(P_Taxonomy_CD, '') <> ''
                                                                                                                AND ID > @CurrentTaxonomy
                                                                                END --End while for Taxonomy
                                                                END --End Taxonomy Processing Block

                                                                SELECT @ProviderTypeDescription = ProviderTypeDescription
                                                                                ,@RiskCategoryCode = RiskCategoryCode
                                                                                ,@RiskCategory = RiskCategory
                                                                FROM KYP.PDM_ProviderTypeCode
                                                                WHERE ProviderTypeCode = @P_TY_CD
                                                                
                                                                
                                                                
                                                                if((select count(AccountID) from KYPEnrollment.pADM_Account where ProviderTypeCode='002' and NPI=@P_NPI_NUM)>0)
                                                                BEGIN
                                                                                                                
                                                                SET @RiskCategory='Moderate'
                                                                
                                                                END
                                                                /*Handling below*/
                                                                --IF(@P_TY_CD = '015')
                                                                --BEGIN
                                                                                --SET @ProviderTypeDescription = 'Out of State Hospital'
                                                                --END 
                                                                
                                                                
                                                                
                                                                IF(@RiskCategory = 'Limited')
                                                                BEGIN
                                                                                SET @RiskCategoryCode = 1
                                                                END 
                                                                ELSE IF(@RiskCategory = 'Moderate')
                                                                BEGIN
                                                                                SET @RiskCategoryCode = 2
                                                                END 
                                                                ELSE IF(@RiskCategory = 'High')
                                                                BEGIN
                                                                                SET @RiskCategoryCode = 3
                                                                END
                                                                ELSE 
                                                                BEGIN
                                                                                SET @RiskCategoryCode = 1
                                                                END

                                                                --PRINT @RiskCategoryCode
                                                                ----------: Risk Category in case of Supplimental application, what is defined for that Account  should only :------------ Modified by Ameet, Modified Date : 8 March 2016 
                                                                IF (
                                                                                                @Sup_Update = 'SR'
                                                                                                OR @Sup_Update = 'MR'
                                                                                                OR @Sup_Update = 'NR'
                                                                                                OR @Sup_Update = 'CHOA'
                                                                                                OR @Sup_Update = 'CHOW'
                                                                                                OR @Sup_Update = '5C'
                                                                                                OR @Sup_Update = '5B'
                                                                                                OR @Sup_Update = '5A'
                                                                                                OR @Sup_Update = '06'
                                                                                                OR @Sup_Update = '07'
                                                                                                )
                                                                BEGIN
                                                                                SELECT @RiskCategoryCode = ISNULL(Risk, @RiskCategoryCode)
                                                                                FROM KYPEnrollment.pADM_Account
                                                                                WHERE AccountNumber = @Account_No
                                                                END

                                                                --- Modification done here 
                                                                SELECT @ADMCaseType = SortOder
                                                                FROM KYP.LK_Screening
                                                                WHERE TypeID = 1
                                                                                AND Description = @ProviderTypeDescription

                                                                /**********Conditionally Insert Record in KYP.ADM_Case *************/
                                                                EXEC @PDM_CaseID = [KYP].[p_FindADMCaseRecord] @Number = @P_ID
                                                                
                                                                /***start of resubmission block*******/
                                                                IF @PDM_CaseID > 0
                                                                                --if @PDM_CaseID is not null and @PDM_CaseID <>0
                                                                BEGIN
                                                                                SELECT @PDM_ApplicationID = ADM_Application.ApplicationID
                                                                                FROM KYP.ADM_Application      WHERE ADM_Application.CaseID = @PDM_CaseID
                                                                                                AND ISNULL(ADM_Application.IsDeleted, 0) = 0;

                                                                                SELECT @caseAgeBaseLine = ISNULL(BASELINE, 60)
                                                                                FROM KYP.ADM_CASE_AGE_CONFIG      WHERE PRACTICE_TYPE = @P_PRACT_TY_CD;

                                                                                SET @caseAgeBaseLine = 60;

                                                                                /***Logically delete all previous application associations except SDM_ApplicationParty*****/
                                                                                /***Physically delete all records from SDM_ApplicationParty and PDM_MasterParty*****/
																				
																				SELECT @DateTracking = Track.DateTracking FROM KYPPORTAL.PORTALKYP.pApplicationHistoryTracking Track,
																								KYPPORTAL.PORTALKYP.pADM_Application APP,
																								KYPPORTAL.PORTALKYP.pADM_Case CAS
																								WHERE Track.ApplicationNumber = APP.ApplicationNo
																								AND CAS.CaseID = APP.CaseID
																								AND CAS.Status = 'Resubmitted'
																								AND Track.ApplicationMilestone = 'Resubmitted'
																								AND APP.ApplicationNo = @P_ID
																				
																				IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE 
																				TABLE_NAME = N'ProviderNameAddress')
                                                                                BEGIN   
                                                                                    SELECT @Moratoria = P.IsMoratorium FROM [dbo].ProviderNameAddress P WHERE P.P_ID = @P_ID
                                                                                END
																				
                                                                                UPDATE KYP.ADM_Case
                                                                                SET Resubmitted = '-R'
                                                                                                ,IsPPURequired = 1
                                                                                                ,StatusSubName = 'Under Review'
                                                                                                --,InternalAppStatus = 1
                                                                                                ,ProviderName = @ProviderPartyName
                                                                                                ,Provider_NPI = @P_NPI_NUM
                                                                                                ,Provider_SSN = @P_SSN_NUM
                                                                                                ,Provider_TIN = @P_FED_TAX_ID
                                                                                                ,StatusCodeNumber = 10
                                                                                                --,MILESTONE = 'Re-Submitted'
                                                                                                ,STATUS = 'Re-Submit'
                                                                                                ,ActivityStatus = 'Re-Submit'
                                                                                                ,CurrentMilestoneStep = 10
                                                                                                ,TotalMilestoneStep = 13
                                                                                                ,CurrentMajorDisposition = 'Re-SubmitByProvider'
                                                                                                ,DateReceived = @DateTracking
                                                                                                ,RTPDateCreated = @DateTracking
                                                                                                ,DueDate = DATEADD(dd, @caseAgeBaseLine, @DateTracking)
																								,DateInitiated = @DateTracking
                                                                                                ,DAYS_REMAINING = @caseAgeBaseLine
                                                                                                ,THRESHOLD = 'Normal'
                                                                                                ,FeePaid = @FeePaid 
																								,FeeRequired = @FeeRequired
																								,FeeExempted = @FeeExempted 
																								,FeeConfirmation = @FeeConfirmation 
																								,IsMoratoria = @Moratoria
																								,ProviderTypeCode = @P_TY_CD
																								,TypeDescription = @ProviderTypeDescription
																								,LastActionDate = Getdate() --Added this field for Elastic search implementation for Quick Search
                                                                                WHERE CaseID = @PDM_CaseID
                                                                                
                                                                                
                                                                                /* CAPAVE-4522 START */
                                                                                /****************** Individual Ownership *******************/
                                                                                Update c
																				Set C.IsDeleted = 1, C.IsActive = 0
																				From (select t1.ApplicationNo,t2.PartyID,t2.ApplicationID,t3.FirstName,t3.LastName,t3.SSN
																						from  KYP.ADM_Application t1
																						Join KYP.SDM_ApplicationParty t2 on t2.ApplicationID=t1.ApplicationID
																						join KYP.PDM_Person t3 on t2.PartyID=t3.PartyID
																						where t2.PartyType='Owner Person'
																						) A
																				Join (select t1.ApplicationNo,t2.PartyID,t3.FirstName,t3.LastName,replace(t3.SSN,'-','') SSN
																						from KYPPORTAL.PortalKYP.pADM_Application t1
																						Join KYPPORTAL.PortalKYP.pPDM_Party t2 on t1.PartyID=t2.parentpartyid
																						Join KYPPORTAL.PortalKYP.pPDM_Person t3 on t2.PartyID=t3.PartyID
																						where t2.Type='Individual Ownership'
																						and t2.IsDeleted=1
																						) b on A.ApplicationNo=b.ApplicationNo
																				join KYP.SDM_ApplicationParty c on a.partyid=c.partyid and a.ApplicationID=c.ApplicationID
																				where a.FirstName=B.FirstName and A.LastName=B.LastName and A.SSN=B.SSN
																				and c.PartyType='Owner Person'
																				and C.IsDeleted=0
																				and a.ApplicationNo = @P_ID


																				/****************** Entity Ownership *******************/
																				Update c
																				Set C.IsDeleted = 1, C.IsActive = 0
																				From (select t1.ApplicationNo,t2.PartyID,t2.ApplicationID,t3.LegalName,t3.TIN
																						from  KYP.ADM_Application t1
																						Join KYP.SDM_ApplicationParty t2 on t2.ApplicationID=t1.ApplicationID
																						join KYP.PDM_Organization t3 on t2.PartyID=t3.PartyID
																						where t2.PartyType='Owner Organization'
																						) A
																				Join (select t1.ApplicationNo,t2.PartyID,t3.LegalName,replace(t3.EIN,'-','') EIN
																						from KYPPORTAL.PortalKYP.pADM_Application t1
																						Join KYPPORTAL.PortalKYP.pPDM_Party t2 on t1.PartyID=t2.parentpartyid
																						Join KYPPORTAL.PortalKYP.pPDM_Organization t3 on t2.PartyID=t3.PartyID
																						where t2.Type='Entity Ownership'
																						and t2.IsDeleted=1
																						) b on A.ApplicationNo=b.ApplicationNo
																				join KYP.SDM_ApplicationParty c on a.partyid=c.partyid and a.ApplicationID=c.ApplicationID
																				where a.LegalName=B.LegalName and A.TIN=B.EIN
																				and c.PartyType='Owner Organization'
																				and C.IsDeleted=0
																				and a.ApplicationNo = @P_ID
                                                                                
                                                                                /* CAPAVE-4522 END */
																				
                                                                                
                                                                                /* CAPAVE-4668 Start
																					Updating the ProviderTypeCode in the InternalUse related tables based on the application type
                                                                                */
                                                                                DECLARE @ApplnNo varchar(10)
                                                                                SELECT @ApplicationType = ApplnType,@ApplnNo = Number FROM KYP.ADM_Case WHERE CaseID = @PDM_CaseID
                                                                                
                                                                                IF(@applnType in ('New','New Rendering','New Group'))
                                                                                BEGIN
																					UPDATE KYPEnrollment.EDM_ApplicationInternalUse 
																					SET ProviderTypeCode = @P_TY_CD
																					WHERE ApplicationNumber = @ApplnNo 
																				END
																				ELSE
																				BEGIN
																					UPDATE KYPEnrollment.EDM_SupplementalInternalUse 
																					SET ProviderTypeCode = @P_TY_CD
																					WHERE LastActionComments = @ApplnNo 
																				END
																				/*CAPAVE-4668 END*/
																				
																				if((@Sup_Update in('SR','MR','CHOA','Reenrollment','Revalidation') OR @Sup_Update in('5C','5B','06','11','12')) and (@P_TY_CD='030' or @P_TY_CD='038'))
                                                                                BEGIN
                                                                                                                                select @providerAccountType=ProviderTypeCode from KYPEnrollment.pADM_Account where AccountNumber=@Account_No
                                                                                                                                
                                                                                                                                
                                                                                                                                if(@providerAccountType='030')
                                                                                                                                begin
																																	select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																	inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
																																	and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )and party.Type in('Aircraft','Pilot')
																																	where ApplicationNo=@P_ID
																																		if(@countApplication>0)
																																			begin
																																				set @ISDMC=1;
                                                                                                                                                set @NewAccountName='Air'
                                                                                                                                                
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                end
                                                                                                                                else if(@providerAccountType='038')
                                                                                                                                begin
																																	select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																	inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
																																	and (party.IsPrepopulated!=1 or party.IsPrepopulated is null ) and party.Type in('AmbulanceDriver','LitterWheelchairVanDriver','Van','Ambulance', 'Non-Medical Operator', 'Non-Medical Vehicle')
																																	where ApplicationNo=@P_ID
																																		if(@countApplication>0)
																																			begin
																																				set @ISDMC=1;
                                                                                                                                                set @NewAccountName='Ground'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                                
                                                                                                                                end
                                                                                                  END
                                                                                
                                                                                IF((@Sup_Update in('SR','MR','CHOA','Reenrollment','Revalidation') OR @Sup_Update in('5C','5B','06','11','12'))and (@P_TY_CD='051' or @P_TY_CD='076'))
                                                                                BEGIN
                                                                                                                                select @providerAccountType=ProviderTypeCode from KYPEnrollment.pADM_Account where AccountNumber=@Account_No
                                --                                                                                              
																																                                                                                                                                
                                                                                                                                if(@providerAccountType='076')
                                                                                                                                begin
																																SET @countApplication=0;
																																			select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID and party.Type='Modality' 
																																			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null ) 
																																			inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID and modalities.ModlityCode ='HDP'
																																			where ApplicationNo=@P_ID 
																																			if(@countApplication>0)
																																			begin
																																				set @ISDMC=1
																																				set @NewAccountName='HDP'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                               
                                                                                                                                                
                                                                                                                                end
                                                                                                                                else if(@providerAccountType='051')
                                                                                                                                begin
																																SET @countApplication=0;
																																			select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID and party.Type='Modality'
																																			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )
																																			inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID and modalities.ModlityCode !='HDP'
																																			where ApplicationNo=@P_ID 
																																			if(@countApplication>0)
																																			begin
																																				set @ISDMC=1
																																				set @NewAccountName='NHDP'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                end
                                                                                                                                
                                                                                                                               
                                                                                END
                                                                                
                                                                                
                                                                                UPDATE KYP.ADM_CaseExtended SET
                                                                                GroundTransportation = @GroundTransportation,
                                                                                AirTransportation = @AirTransportation,
                                                                                ISDMCNEWACCOUNTREQUIRED = @ISDMC,
                                                                                NewAccountRequired = @NewAccountName,
                                                                                IsFacilityBasedProvider = @IsFBP,  
                                                                                ISDPP=@IsDppApp,                            
                                                                                IsServiceAddressChange=case when(@ChangeServiceAddress > 0) then 1 else 0 END /*ADDED For CAPAVE-3812*/
                                                                                WHERE CaseID = @PDM_CaseID
																				
																				IF( @ISDMC = 1)
                                                                                BEGIN
																					UPDATE KYP.ADM_Case SET GenNo = '11'  WHERE CaseID = @PDM_CaseID
                                                                                END
                                                                                    
																					
                                                                             
                                                                                UPDATE KYP.PDM_MasterParty
                                                                                SET CaseID = @PDM_CaseID
                                                                                WHERE ProviderNumber = @P_ID

                                                                                UPDATE KYP.PDM_Provider
                                                                                SET CLIA = @ProviderCLIANBR
                                                                                WHERE ProvNumber = @P_ID
                                                                                
                                                                                SET @Resubmitted = 1   
                                                                                
                                                                                
                                                                                -- end Of comment For Enrollment
                                                                                --delete from KYP.SDM_ApplicationParty where ApplicationID = @PDM_ApplicationID
                                                                                --ALTER TABLE KYP.OIS_Note DISABLE TRIGGER OIS_Note_AccountNoteDelete

                                                                                --update KYP.SDM_ApplicationParty set IsDeleted=1 where ApplicationID = @PDM_ApplicationID
                                                                                --ALTER TABLE KYP.OIS_Note ENABLE TRIGGER OIS_Note_AccountNoteDelete

                                                                                DELETE
                                                                                FROM KYP.PDM_Location
                                                                                WHERE PDM_Location.PartyID = @PDM_ProviderPartyId

                                                                                DELETE
                                                                                FROM KYP.PDM_Location
                                                                                WHERE PDM_Location.PartyID = @PDM_PartyId

                                                                                DELETE
                                                                                FROM KYP.ADM_App_License
                                                                                WHERE ADM_App_License.ApplicationID = @PDM_ApplicationID

                                                                                --delete from KYP.PDM_MasterParty where ProviderNumber = @P_ID
                                                                                UPDATE KYP.SDM_ScreeningChecklist
                                                                                SET SDM_ScreeningChecklist.IsDeleted = 1
                                                                                WHERE SDM_ScreeningChecklist.ApplicationID = @PDM_ApplicationID

                                                                                --UPDATE KYP.SDM_ApplicationParty
                                                                                --SET IsDeleted = 1
                                                                                --             ,IsActive = 0
                                                                                --WHERE ApplicationID = @PDM_ApplicationID

                                                                                UPDATE KYP.ADM_App_Location
                                                                                SET ADM_App_Location.IsDeleted = 1
                                                                                WHERE ADM_App_Location.ApplicationID = @PDM_ApplicationID

                                                                                --update  KYP.ADM_App_License set IsDeleted = 1 where ApplicationID = @PDM_ApplicationID
                                                                                UPDATE KYP.ADM_App_Owner
                                                                                SET ADM_App_Owner.IsDeleted = 1
                                                                                WHERE ADM_App_Owner.ApplicationID = @PDM_ApplicationID

                                                                                UPDATE KYP.ADM_App_Employee
                                                                                SET ADM_App_Employee.IsDeleted = 1
                                                                                WHERE ADM_App_Employee.ApplicationID = @PDM_ApplicationID  
                                                                                
                                                                                --Added the below statement for Elastic Search implementation Quick Search by Sundar on 26-Jun-2019
																				Exec KYP.USP_Load_PortalAddress @P_ApplicationNumber = @P_ID                       
                                                                                
                                                                END --End of resubmission block

                                                                ELSE IF @PDM_CaseID = - 1
                                                                BEGIN
                                                                                
                                                                                SET @Resubmitted = 0   
                                                                                /***Changes made for KYP3.3***/
                                                                                EXEC [dbo].[generateSequenceNumber] @GenPAN OUTPUT
                                                                                
                                                                                /** Generate Moratorium Flag until BO team genrate flag. This is workaround.**/
                                                                                -- This will be 
                                                                                --IF EXISTS(SELECT * FROM [MISC_SRC].INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'MoratoriumData')
                                                                                --BEGIN                                                                   
                                                                                --                Declare @MCounty NVARCHAR(10), @MCity NVARCHAR(35), @MZIPCode NVARCHAR(5);
                                                                                
                                                                                --                SELECT @MCounty = ISNULL(County,''),@MCity = ISNULL(City,''), @MZIPCode = SUBSTRING(@MZIPCode,0,6)  
                                                                                --                FROM KYPPORTAL.PortalKYP.pADM_Application A INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location L                ON A.PartyID = L.PartyID 
                                                                                --                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address D ON L.AddressID = D.AddressID
                                                                                --                WHERE A.ApplicationNo = @P_ID AND L.Type = 'Servicing'
                                                                                
                                                                                --                IF EXISTS(SELECT * FROM [MISC_SRC].[dbo].MoratoriumData WHERE County = @MCounty AND ZIPCode = @MZIPCode
                                                                                --                AND City = @MCity AND ProviderTypeCode = @P_TY_CD)
                                                                                --                BEGIN
                                                                                --                                SET @Moratoria = 1
                                                                                --                END
                                                                                --END                                                                       
                                                                                
                                                                                	IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'ProviderNameAddress')
																					BEGIN	
																					 SELECT @Moratoria = P.IsMoratorium FROM [dbo].ProviderNameAddress P WHERE P.P_ID = @P_ID
																					END
                                                                                
                                                                                IF(@ProviderTypeDescription = 'Other' AND ISNULL(@ProvTypeDesc,'') != '')
                                                                                BEGIN
                                                                                                SET @ProviderTypeDescription =  @ProvTypeDesc
                                                                                END       
                                                                                
                                                                                IF((@P_TY_CD='030' or @P_TY_CD='038') AND (@Sup_Update = '01' OR @Sup_Update = '02'  OR @Sup_Update = '03'))
                                                                                BEGIN
																					SET @ProviderTypeDescription =  @ProviderTypeDescription;
                                                                                END
																				
																				/*Making 'Out of State Hospital Outpatient' to 'Out of State Hospital' for PT-015*/
																				/*IF(@P_TY_CD = '015')
																				BEGIN
																					IF(@Sup_Update = '01' OR @Sup_Update = '02' OR @Sup_Update = '03')
																					BEGIN
																						SET @ProviderTypeDescription = REPLACE(@ProviderTypeDescription,'Out of State Hospital Outpatient','Out of State Hospital');
																					END
																				
																				END*/
                                                                                
																				/* KEN-16295: Now, ProviderTypeDescription is fetching from KYP.PDM_ProviderTypeCode for O&P Package, so commented this block */
                                                                                --IF (ISNULL(@OPIndicator,0) != 0)
                                                                                --BEGIN
                                                                                                --SELECT @ProviderTypeDescription = ISNULL(Description,@ProviderTypeDescription)
                                                                                                --FROM KYP.LK_Screening where TypeID = 378 AND Abreviation = @OPIndicator
                                                                                --END
                                                                                
                                                                                SELECT @DateTracking = Track.DateTracking FROM KYPPORTAL.PORTALKYP.pApplicationHistoryTracking Track,
																								KYPPORTAL.PORTALKYP.pADM_Application APP,
																								KYPPORTAL.PORTALKYP.pADM_Case CAS
																								WHERE Track.ApplicationNumber = APP.ApplicationNo
																								AND CAS.CaseID = APP.CaseID
																								AND CAS.Status = 'Submitted'
																								AND Track.ApplicationMilestone = 'Submitted'
																								AND APP.ApplicationNo = @P_ID

                                                                                IF @ProviderType = 'I'
                                                                                BEGIN
                                                                                                PRINT 'ADMCase'
                                                                                                
                                                                                                
                                                                                                
                                                                                                EXEC @PDM_CaseID = [KYP].[p_InsertADMCase] @Number = @P_ID
                                                                                                                ,@Type = @ADMCaseType
                                                                                                                ,@EnrollmentType = NULL
                                                                                                                ,@SubType = 'Physician'
                                                                                                                ,@Status = ''
                                                                                                                ,@StatusCodeNumber = 12
                                                                                                                ,@CurrentMajorDisposition = 'Screening'
                                                                                                                ,@CurrentMinorDisposition = 'Provider Check'
                                                                                                                ,@ActivityStatus = 'In Progress'
                                                                                                                ,@InvestigationAge = NULL
                                                                                                                ,@GenNo = NULL
                                                                                                                ,@CaseOwnerID = NULL
                                                                                                                ,@AssignedFromID = NULL
                                                                                                                ,@CurrentlyAssignedToID = NULL
                                                                                                                ,@CurrentlyAssignedToName = NULL
                                                                                                                ,@ResolutionStatus = NULL
                                                                                                                ,@DateResolved = NULL
                                                                                                                ,@DateAssigned = NULL
                                                                                                                ,@DateReceived = @DateTracking
                                                                                                                ,@DateInitiated = @DateTracking
                                                                                                                ,@DueDate = NULL
                                                                                                                ,@EndDate = NULL
                                                                                                                ,@DateCreated = @DateTracking
                                                                                                                ,@ProviderName = @ProviderPartyName
                                                                                                                ,@ProcessModule = 'ScreeningWF'
                                                                                                                ,@Description = NULL
                                                                                                                ,@Priority = @RiskCategoryCode
                                                                                                                ,@TypeDescription = @ProviderTypeDescription
                                                                                                                ,@StatusCodeName = 'New Enrollment'
                                                                                                                ,@Risk = NULL
                                                                                                                ,@StatusName = 'Under Review'
                                                                                                                ,@Provider_NPI = @P_NPI_NUM
                                                                                                                ,@Provider_SSN = @P_SSN_NUM
                                                                                                                ,@Provider_TIN = @P_FED_TAX_ID
                                                                                                                ,@Provider_MID = NULL
                                                                                                                ,@StatusSubName = 'Under Review' ---After this columns added for kyp3.3
                                                                                                                ,@PAN = @GenPAN
                                                                                                                ,@ApplnType = 'New' --Passing 'new' as application type when the provider profile is coming for the first time
                                                                                                                ,@AccountID = @AcID
                                                                                                                ,@P_PRACT_TY_CD = @P_PRACT_TY_CD_VALUE
                                                                                                                ,@Sup_Update = @Sup_Update -- for suplementary update
                                                                                                                ,@Account_No = @Account_No -- for suplementary update
                                                                                                                ,@LastUpdateAppID = @LastUpdateAppID -- for suplementary update
                                                                                                                ,@Group_NPI = @P_Group_NPI
                                                                                                                ,@Group_AccountNumber = @P_Group_AccountNo
                                                                                                                ,@Preffered = @P_Preffered
                                                                                                                ,@Group_DisaffiliateAcNo = @Group_DisaffiliateAcNo
                                                                                                                ,@Rendered_DisaffiliateAcNo = @Rendered_DisaffiliateAcNo
                                                                                                                ,@ProviderTypeCode = @P_TY_CD
                                                                                                                ,@IsMoratoria = @Moratoria
                                                                                                                ,@HDProgram = @HDProgram
                                                                                                                ,@NHDProgram = @NHDProgram 
                                                                                                                ,@CrossOverApp = @CrossOverApp
                                                                                                                ,@FeeRequired = @FeeRequired
                                                                                                                ,@FeePaid = @FeePaid
                                                                                                                ,@FeeExempted = @FeeExempted
                                                                                                                ,@MDCToMDL = @MDCToMDL
                                                                                                                ,@MDLToMDC = @MDLToMDC
                                                                                                                ,@FeeConfirmation = @FeeConfirmation
                                                                                                                ,@ProvTypeDesc = @ProvTypeDesc
                                                                                                                ,@IsTribalAppln = @IsTribalAppln    
                                                                                                                ,@OrtProsthetic = @OPIndicator

                                                                                                                

                                                                                                UPDATE KYP.PDM_MasterParty
                                                                                                SET CaseID = @PDM_CaseID
                                                                                                WHERE ProviderNumber = @P_ID
                                                                                END
                                                                                ELSE IF @ProviderType = 'O'
                                                                                BEGIN
                                                print 'IN O'
                                                                                                EXEC @PDM_CaseID = [KYP].[p_InsertADMCase] @Number = @P_ID
                                                                                                                ,@Type = @ADMCaseType
                                                                                                                ,@EnrollmentType = NULL
                                                                                                                ,@SubType = 'Institutional'
                                                                                                                ,@Status = ''
                                                                                                                ,@StatusCodeNumber = 12
                                                                                                                ,@CurrentMajorDisposition = 'Screening'
                                                                                                                ,@CurrentMinorDisposition = 'Provider Check'
                                                                                                                ,@ActivityStatus = 'In Progress'
                                                                                                                ,@InvestigationAge = NULL
                                                                                                                ,@GenNo = NULL
                                                                                                                ,@CaseOwnerID = NULL
                                                                                                                ,@AssignedFromID = NULL
                                                                                                                ,@CurrentlyAssignedToID = NULL
                                                                                                                ,@CurrentlyAssignedToName = NULL
                                                                                                                ,@ResolutionStatus = NULL
                                                                                                                ,@DateResolved = NULL
                                                                                                                ,@DateAssigned = NULL
                                                                                                                ,@DateReceived = @DateTracking
                                                                                                                ,@DateInitiated = @DateTracking
                                                                                                                ,@DueDate = NULL
                                                                                                                ,@EndDate = NULL
                                                                                                                ,@DateCreated = @DateTracking
                                                                                                                ,@ProviderName = @ProviderPartyName
                                                                                                                ,@ProcessModule = 'ScreeningWF'
                                                                                                                ,@Description = NULL
                                                                                                                ,@Priority = @RiskCategoryCode
                                                                                                                ,@TypeDescription = @ProviderTypeDescription
                                                                                                                ,@StatusCodeName = 'New Enrollment'
                                                                                                                ,@Risk = NULL
                                                                                                                ,@StatusName = 'Under Review'
                                                                                                                ,@Provider_NPI = @P_NPI_NUM
                                                                                                                ,@Provider_SSN = @P_SSN_NUM
                                                                                                                ,@Provider_TIN = @P_FED_TAX_ID
                                                                                                                ,@Provider_MID = NULL
                                                                                                                ,@StatusSubName = 'Under Review' ---After this columns added for kyp3.3
                                                                                                                ,@PAN = @GenPAN
                                                                                                                ,@ApplnType = 'New' --Passing 'new' as application type when the provider profile is coming for the first time
                                                                                                                ,@AccountID = @AcID
                                                                                                                ,@P_PRACT_TY_CD = @P_PRACT_TY_CD_VALUE
                                                                                                                ,@Sup_Update = @Sup_Update -- for suplementary update
                                                                                                                ,@Account_No = @Account_No -- for suplementary update
                                                                                                                ,@LastUpdateAppID = @LastUpdateAppID -- for suplementary update
                                                                                                                ,@Group_NPI = @P_Group_NPI
                                                                                                                ,@Group_AccountNumber = @P_Group_AccountNo --Changed the variable value from P_Group_AccountNo to @P_Group_AccountNo on 27-nov-2018
                                                                                                                ,@Preffered = @P_Preffered
                                                                                                                ,@Group_DisaffiliateAcNo = @Group_DisaffiliateAcNo
                                                                                                                ,@Rendered_DisaffiliateAcNo = @Rendered_DisaffiliateAcNo
                                                                                                                ,@ProviderTypeCode = @P_TY_CD
                                                                                                                ,@IsMoratoria = @Moratoria
                                                                                                                ,@HDProgram = @HDProgram
                                                                                                                ,@NHDProgram = @NHDProgram
                                                                                                                ,@CrossOverApp = @CrossOverApp
                                                                                                                ,@FeeRequired = @FeeRequired
                                                                                                                ,@FeePaid = @FeePaid
                                                                                                                ,@FeeExempted = @FeeExempted
                                                                                                                ,@MDCToMDL = @MDCToMDL
                                                                                                                ,@MDLToMDC = @MDLToMDC
                                                                                                                ,@FeeConfirmation = @FeeConfirmation
                                                                                                                ,@ProvTypeDesc = @ProvTypeDesc
                                                                                                                ,@IsTribalAppln = @IsTribalAppln     
                                                                                                                ,@OrtProsthetic = @OPIndicator
                                                                


                                                                                                UPDATE KYP.PDM_MasterParty
                                                                                                SET CaseID = @PDM_CaseID
                                                                                                WHERE ProviderNumber = @P_ID
                                                                                END
                                                                                /*******************Indicater for Supplemental application for MT**************/
                                                                                
                                                                                if((@Sup_Update in('SR','MR','CHOA','Reenrollment','Revalidation') OR @Sup_Update in('5C','5B','06','11','12')) and (@P_TY_CD='030' or @P_TY_CD='038'))
                                                                                BEGIN
                                                                                                                                select @providerAccountType=ProviderTypeCode from KYPEnrollment.pADM_Account where AccountNumber=@Account_No
                                                                                                                                
                                                                                                                                
                                                                                                                                if(@providerAccountType='030')
                                                                                                                                begin
																																	select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																	inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
																																	and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )and party.Type in('Aircraft','Pilot')
																																	where ApplicationNo=@P_ID
																																		if(@countApplication>0)
																																			begin
																																				set @ISDMC=1;
                                                                                                                                                set @NewAccountName='Air'
                                                                                                                                                
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                end
                                                                                                                                else if(@providerAccountType='038')
                                                                                                                                begin
																																	select  @countApplication=Count(party.PartyID) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																	inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID 
																																	and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )and party.Type in('AmbulanceDriver','LitterWheelchairVanDriver','Van','Ambulance','Non-Medical Operator', 'Non-Medical Vehicle')
																																	where ApplicationNo=@P_ID
																																		if(@countApplication>0)
																																			begin
																																				set @ISDMC=1;
                                                                                                                                                set @NewAccountName='Ground'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                                
                                                                                                                                end
                                                                                                                                
                                                                                END
                                                                                
                                                                               ELSE IF((@Sup_Update in('SR','MR','CHOA','Reenrollment','Revalidation') OR @Sup_Update in('5C','5B','06','11','12'))and (@P_TY_CD='051' or @P_TY_CD='076'))
                                                                                BEGIN
                                                                                                                                select @providerAccountType=ProviderTypeCode from KYPEnrollment.pADM_Account where AccountNumber=@Account_No
                                --                                                                                              
																																                                                                                                                                
                                                                                                                                if(@providerAccountType='076')
                                                                                                                                begin
																																SET @countApplication=0;
																																			select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID and party.Type='Modality' 
																																			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null ) 
																																			inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID and modalities.ModlityCode ='HDP'
																																			where ApplicationNo=@P_ID 
																																			if(@countApplication>0)
																																			begin
																																				set @ISDMC=1
																																				set @NewAccountName='HDP'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                               
                                                                                                                                                
                                                                                                                                end
                                                                                                                                else if(@providerAccountType='051')
                                                                                                                                begin
																																SET @countApplication=0;
																																			select @countApplication=Count(ModalityId) from KYPPORTAL.PortalKYP.pADM_Application Appln
																																			inner join KYPPORTAL.PortalKYP.pPDM_Party party on party.ParentPartyID=Appln.PartyID and party.Type='Modality'
																																			and (party.IsPrepopulated!=1 or party.IsPrepopulated is null )
																																			inner join KYPPORTAL.PortalKYP.pPDM_Modalities modalities on modalities.PartyID = party.PartyID and modalities.ModlityCode !='HDP'
																																			where ApplicationNo=@P_ID 
																																			if(@countApplication>0)
																																			begin
																																				set @ISDMC=1
																																				set @NewAccountName='NHDP'
																																			END
																																			else
																																			Begin
																																				set @ISDMC=0
																																				set @NewAccountName=Null
																																			END
                                                                                                                                end
                                                                                                                                
                                                                                                                               
                                                                                END
                                                                                
                                                                                
                                                                                
                                                                                /********************Update OF ADM_CaseExtended**************/
                                                                                PRINT @ReactivationAccountNo
                                                                                
                                                                                 if(@CHOWLocationType='5')
                                                                                Begin
																					select @CHOWAccountNo=B.ProfileID from KYPEnrollment.pADM_Account A 
																					inner join KYPEnrollment.pAccount_BizProfile_Details B on A.AccountID=B.AccountID
																					where 
																					StatusAcc in ('1 - Active','3 - Pending','7 - Active Rendering (indirect)','9 - Temporary Suspended') and NPI=@P_NPI_NUM
																				END
                                                                                
                                                                                
                                                                                IF @PDM_CaseID > 0
                                                                                BEGIN
                                                                                                EXEC [KYP].[p_InsertADMCaseExtended] 
                                                                                                 @Number=@P_ID
                                                                                                ,@CaseID=@PDM_CaseID
                                                                                                ,@Ground= @GroundTransportation 
                                                                                                ,@Air=@AirTransportation
                                                                                                ,@ISDMC= @ISDMC
                                                                                                ,@NewAccountName=@NewAccountName
                                                                                                ,@IsFBP=@IsFBP
                                                                                                ,@ReactivateAppType=@P_PRACT_TY_CD_VALUE
                                                                                                ,@ReactivationAccNo = @ReactivationAccountNo
																								,@isReactivation = @isReactivation
																								,@CHOWLocationType = @CHOWLocationType
																								,@CHOWAccountNo =@CHOWAccountNo
																								,@IsDppApp=@IsDppApp
																								,@ChangeServiceAddress=@ChangeServiceAddress /** ADDED for CAPAVE-3812 **/

																								
                                                                                END       

                                                                                /********************Suplementary Update Block**************/
                                                                                IF @PDM_CaseID > 0
                                                                                BEGIN
                                                                                                IF (
                                                                                                                                @Sup_Update = 'SR'
                                                                                                                                OR @Sup_Update = '5C'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Supplemental'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Supplemental')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Supplemental' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'MR'
                                                                                                                                OR @Sup_Update = '5B'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Supplemental'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                           insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Supplemental')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Supplemental' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'NR'
                                                                                                                                OR @Sup_Update = '5A'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Supplemental'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Supplemental')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Supplemental' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'CHOA'
                                                                                                                                OR @Sup_Update = '06'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'CHOA'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                           insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'CHOA')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'CHOA' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'CHOW'
                                                                                                                                OR @Sup_Update = '07'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'CHOW'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                           insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'CHOW')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'CHOW' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'New Group'
                                                                                                                                OR @Sup_Update = '03'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'New Group'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @isReactivation = 1
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Supplemental'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                                ,SupUpdateFlag='14'
                                                                                                                WHERE CaseID = @PDM_CaseID
                                                                                                 END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'New Rendering'
                                                                                                                                OR @Sup_Update = '04'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'New Rendering'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'Rendering-S'
                                                                                                                                OR @Sup_Update = '13'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Rendering-S'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Rendering-S')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Rendering-S' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'Reenrollment'
                                                                                                                                OR @Sup_Update = '11'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Reenrollment'
                                                                                                                                ,IsPPURequired = 1
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Reenrollment')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Reenrollment' + '''');
                                                                                                END
                                                                                                
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'Revalidation'
                                                                                                                                OR @Sup_Update = '12'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET IsPPURequired = 1
                                                                                                                                ,ApplnType = 'Revalidation'
                                                                                                                WHERE CaseID = @PDM_CaseID
                             insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Revalidation')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Revalidation' + '''');
                                                                                                END
                                                                                                ELSE IF (
                                                                                                                                @Sup_Update = 'Disenrollment'
                                                                                                                                OR @Sup_Update = '09'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Disenrollment'
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Disenrollment')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Disenrollment' + '''');
                                                                                                END
                                                                                                ELSE IF (@Sup_Update = '02')
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'New'
                                                                                                                                ,AffSupUpdateFlag = 'New Group'
                                                                                                                WHERE CaseID = @PDM_CaseID
                                                                                                END
                                                                                                ELSE IF (@Sup_Update = '08')
                                                                                                BEGIN
                                                                                                                UPDATE KYP.ADM_Case
                                                                                                                SET ApplnType = 'Disaffiliation'
                                                                                                                WHERE CaseID = @PDM_CaseID
                            insert into kyp.ParametersAccountHistory(TypeProcess,Account_No,P_ID,UpdateType ) values ('Screening',@Account_No,@P_ID,'Disaffiliation')
                                                                                                                --EXEC (' xp_cmdshell ''C:\upload\AccountHistory\run.bat ' + 'Screening' + ' ' + @Account_No + ' ' + @P_ID + ' ' + 'Disaffiliation' + '''');
                                                                                                END
                                                                                END
                            /* Added as part of MDKYP-770 / CAPAVE-3454  Begin*/  
                            EXEC [KYP].[sp_UpdateApplnTypeAlias] @Number = @P_ID
							/* Added as part of MDKYP-770 / CAPAVE-3454  End*/

                                                                                /*Start KEN-13234 */     
                                                                                -- Moved this code to Server side
                                                                                /*Update T1
                                                                                Set T1.Priority = Case When (ApplnType IN ('New','New Group','New Rendering','CHOA')) Then 3
                                                                                                                                                                Else 2 End,
                                                                                                T1.Risk = Case When (ApplnType IN ('New','New Group','New Rendering','CHOA')) Then 'High'
                                                                                                                                                                Else 'Moderate' End                                                        
                                                                                From Kyp.ADM_Case T1
                                                                                
                                                                                Join Kypenrollment.PortalAddress T2 on T2.EnrollCaseID = T1.CaseID --and T2.Type = 'Servicing'
                                                                                Where T2.Type = 'Servicing' 
                                                                                and T1.CaseID = @PDM_CaseID
                                                                                AND T1.ProviderTypeCode = '024'
                                                                                and T2.County in ('LA','LA COUNTY','los angeles','los angeles County')*/
                                                                                /*End KEN-13234*/

                                                                                /****************END Suplementary Update Block************/
                                                                                /***************DAILY FILE UPLOAD ENDS**************************/
                                                                                /**********Insert Record in KYP.ADM_Application*************/
                                                                                EXEC @PDM_ApplicationID = [KYP].[p_InsertADMApplication] @CaseID = @PDM_CaseID
                                                                                                ,@AppProvID = @PDM_ProviderID
                                                                                                ,@ApplicationNo = @P_ID
                                                                                                ,@Type = NULL
                                                                                                ,@Remarks = 'Testing'
                                                                                                ,@Source = 'Admin'
                                                                                                ,@Status = 'Active'
                                                                                                ,@RiskCategory = NULL
                                                                                                ,@AutoRisk = NULL
                                                                                                ,@EDDRisk = NULL
                                                                                                ,@CompositeRisk = NULL
                                                                                                ,@DateSubmitted = NULL
                                                                                                ,@DateReviewed = NULL
                                                                                                ,@DateScreened = NULL
                                                                                                ,@DateCompleted = NULL
                                                                                                ,@ReviewedBy = NULL
                                                                                                ,@ScreenedBy = NULL
                                                                                                ,@CompletedBy = NULL
                                                                                                ,@DateCreated = @now
                                                                                                ,@ScreeningReminderDate = NULL
                                                                                                ,@CrossOverApp = @CrossOverApp
                                                                                                ,@FeeRequired = @FeeRequired
                                                                                                ,@FeePaid = @FeePaid
                                                                                                ,@FeeExempted = @FeeExempted
                                                                                                ,@MDCToMDL = @MDCToMDL
                                                                                                ,@MDLToMDC = @MDLToMDC
                                                                                                ,@FeeConfirmation = @FeeConfirmation

                                                                    --Added the below statement for Elastic Search implementation Quick Search by Sundar on 26-Jun-2019
																	Exec KYP.USP_Load_PortalAddress @P_ApplicationNumber = @P_ID                                                                                                                  
                                                                END --End of new insert in ADM_Case and ADM_Application

                                                                    /************Insert Provider and Ind/Org PartyIds to SDM_ApplicationParty**********/

                                                                    
                                                                    IF @Resubmitted = 1 /** Resubmission scenario make isactive = 1 for new owners added **/
                                                                    BEGIN                                                                               
                                                                                   UPDATE KYP.SDM_ApplicationParty SET PartyID = @PDM_ProviderPartyId WHERE ApplicationID = @PDM_ApplicationID AND IsActive = 1 AND PartyType = 'Provider'
                                                                                   IF @ProviderType = 'I'
                                                                                   BEGIN
                                                                                                  UPDATE KYP.SDM_ApplicationParty SET PartyID = @PDM_PartyId WHERE ApplicationID = @PDM_ApplicationID AND IsActive = 1 AND PartyType = 'Provider Person'             
                                                                                   END
                                                                                   ELSE IF @ProviderType = 'O'
                                                                                   BEGIN
                                                                                                  UPDATE KYP.SDM_ApplicationParty SET PartyID = @PDM_PartyId WHERE ApplicationID = @PDM_ApplicationID AND IsActive = 1 AND PartyType = 'Provider Organization'
                                                                                   END                                                                                 
																				
																				
                                                                    END

                                                                    ELSE IF @Resubmitted = 0
                                                                    BEGIN
                                                                                   IF @ProviderType = 'I'
                                                                                   BEGIN
                                                                                                   EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                   ,@ScreeningID = NULL
                                                                                                                   ,@PartyID = @PDM_ProviderPartyId
                                                                                                                   ,@PartyType = 'Provider'
                                                                                                                   ,@VerificationNoteID = NULL
                                                                                                                   ,@IsVerified = 1
                                                                                                                   ,@IsActive = @SDMIsActive
                                                                                                                   ,@PartyRole = 'Provider'
                                                                                                                   ,@AutoRisk = NULL
                                                                                                                   ,@EDDRisk = NULL
                                                                                                                   ,@CompositeRisk = NULL
                                                                                                                   ,@DateCreated = @now
                                                                                                                   ,@IsDeleted = 0

                                                                                                   EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                   ,@ScreeningID = NULL
                                                                                                                   ,@PartyID = @PDM_PartyId
                                                                                                                   ,@PartyType = 'Provider Person'
                                                                                                                   ,@VerificationNoteID = NULL
                                                                                                                   ,@IsVerified = 1
                                                                                                                   ,@IsActive = @SDMIsActive
                                                                                                                   ,@PartyRole = 'Person'
                                                                                                                   ,@AutoRisk = NULL
                                                                                                                   ,@EDDRisk = NULL
                                                                                                                   ,@CompositeRisk = NULL
                                                                                                                   ,@DateCreated = @now
                                                                                                                   ,@IsDeleted = 0

                                                                                   END
                                                                                   ELSE IF @ProviderType = 'O'
                                                                                   BEGIN
                                                                                                   EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                   ,@ScreeningID = NULL
                                                                                                                   ,@PartyID = @PDM_ProviderPartyId
                                                                                                                   ,@PartyType = 'Provider'
                                                                                                                   ,@VerificationNoteID = NULL
                                                                                                                   ,@IsVerified = 1
                                                                                                                   ,@IsActive = @SDMIsActive
                                                                                                                   ,@PartyRole = 'Provider'
                                                                                                                   ,@AutoRisk = NULL
                                                                                                                   ,@EDDRisk = NULL
                                                                                                                   ,@CompositeRisk = NULL
                                                                                                                   ,@DateCreated = @now
                                                                                                                   ,@IsDeleted = 0


                                                                                                   EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                   ,@ScreeningID = NULL
                                                                                                                   ,@PartyID = @PDM_PartyId
                                                                                                                   ,@PartyType = 'Provider Organization'
                                                                                                                   ,@VerificationNoteID = NULL
                                                                                                                   ,@IsVerified = 1
                                                                                                                   ,@IsActive = NULL
                                                                                                                   ,@PartyRole = 'Organization'
                                                                                                                   ,@AutoRisk = NULL
                                                                                                                   ,@EDDRisk = NULL
                                                                                                                   ,@CompositeRisk = NULL
                                                                                                                   ,@DateCreated = @now
                                                                                                                   ,@IsDeleted = 0

                                                                                   END
                                                                    END
                                                                                
                                                                                
                                                                                /** Load Facilty Based Providers and Additional Parties **/
                                                                                 
                                                                                IF EXISTS(SELECT 1 FROM dbo.AdditionalProviderParties WHERE PID = @ProviderOrApplicationNbr)
                                                                                BEGIN
																					
																					UPDATE KYP.PDM_AdditionalParties SET IsDeleted = 1 where ApplicationNo = @ProviderOrApplicationNbr AND PartyType = 'FacilityBusiness Address';
																					
                                                                                                /** Checking Facilty Based Providers **/
                                                                                                SELECT @ADFirstID = MIN(ID) ,@ADCurrentID = MIN(ID),@ADLastID  = MAX(ID)
                                                                                                FROM dbo.AdditionalProviderParties WHERE PID = @ProviderOrApplicationNbr AND PartyType = 'FacilityBusiness Address';
                                                                                                
                                                                                                declare @FirstFBP bit = 0, @FacilityId int;
                                                                                                
                                                                                                WHILE (@ADCurrentID <= @ADLastID)
                                                                                                BEGIN
                                                                                                          
                                                                                                                /** Reterive the data from Staging table **/
                                                                                                                SELECT 
                                                                                                                @ADPPartyType = [PartyType],
                                                                                                                @ADPFirstName = [FirstName],
                                                                                                                @ADPLastName = [LastName],
                                                                                                                @ADPMiddleName = [MiddleName],
                                                                                                                @ADPLegalName = [LegalName],
                                                                                                                @ADPSSN = [SSN],
                                                                                                                @ADPTIN = [TIN],
                                                                                                                @ADPLicense = [License],
                                                                                                                @ADPProviderTypeCode = [ProviderTypeCode],
                                                                                                                @ADPProviderTypeDescription = [ProviderTypeDescription],
                                                                                                                @ADPAddressType = [AddressType],
                                                                                                                @ADPAddressLine1 = [AddressLine1],
                                                                                                                @ADPAddressLine2 = [AddressLine2],
                                                                                                                @ADPCity = [City],
                                                                                                                @ADPState = [State],
                                                                                                                @ADPZipCode = [ZipCode],
                                                                                                                @ADPZip5 = [Zip5],
                                                                                                                @ADPZip4 = [Zip4],
                                                                                                                @LocationNumber=[LocationNo]
                                                                                                                FROM [dbo].[AdditionalProviderParties]
                                                                                                                WHERE PID = @ProviderOrApplicationNbr 
                                                                                                                AND ID = @ADCurrentID
                                                                                                                AND PartyType = 'FacilityBusiness Address';
                                                                                                                
                                                                                                                /** INSERT Party Table and Fetch PartyID **/
                                                                                                                

                                                                                                                
                                                                                                               /* EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] 
                                                                                                                                 @Type = 'Person'
                                                                                                                                ,@Name = @ADPLegalName
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 2
                                                                                                                                ,@TypeOfParty = @ADPPartyType
                                                                                                                
                                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] 
                                                                                                                                @ApplicationID = @PDM_ApplicationID
                                                                                                                   ,@ScreeningID = NULL
                                                                                                                   ,@PartyID = @PDM_OwnerPartyId
                                                                                                                   ,@PartyType = 'Facility Provider'
                                                                                                                  ,@VerificationNoteID = NULL
                                                                                                                   ,@IsVerified = 1
                                                                                                                   ,@IsActive = NULL
                                                                                                                   ,@PartyRole = 'Provider'
                                                                                                                   ,@AutoRisk = NULL
                                                                                                                   ,@EDDRisk = NULL
                                                                                                                   ,@CompositeRisk = NULL
                                                                                                                   ,@DateCreated = @now
                                                                                                                   ,@IsDeleted = 1
                                                                                                                   ,@TypeOfParty = @ADPPartyType*/
                                                                                                                   
                                                                                                              SELECT @ProviderTypeDescription = ProviderTypeDescription FROM KYP.PDM_ProviderTypeCode
																											  WHERE ProviderTypeCode = @P_TY_CD    
                                                                                                             declare @FullZip VARCHAR(10), @FullAddress VARCHAR(2000);

																			SET @FullAddress = ISNULL(@ADPAddressLine1,'') + ' ' + ISNULL(@ADPAddressLine2,'') + ' ' + ISNULL(@ADPCity,'') + ' ' + ISNULL(@ADPState,'') + ' ' + ISNULL(@ADPZipCode,'')
                                                                                                                                                                                          
                                                                                                  	                                                                                                             
	                                                                                                             
                                                                                               
                                                                                                   IF((select count(LocationNo) from KYP.PDM_AdditionalParties where ApplicationNo = @P_ID and LocationNo = @LocationNumber)=0)
                                                                                                   BEGIN
                                                                                                   
																									   EXEC [KYP].[p_InsertAdditionalParties]
																																	@CaseID = @PDM_CaseID,
																																	@ApplicationID = @PDM_ApplicationID,
																																	@PartyID  = @PDM_OwnerPartyId,
																																	@ApplicationNo = @ProviderOrApplicationNbr,
																																	@PartyType = @ADPPartyType,
																																	@FirstName = @ADPFirstName,
																																	@LastName  = @ADPLastName,
																																	@MiddleName = @ADPMiddleName,
																																	@LegalName = @ADPLegalName ,
																																	@SSN = @ADPSSN,
																																	@TIN = @ADPTIN,
																																	@License = @ADPLicense,
																																	@ProviderTypeCode = @ADPProviderTypeCode,
																																	@ProviderTypeDescription =  @ADPProviderTypeDescription,
																																	@AddressType = @ADPAddressType,
																																	@AddressLine1 = @ADPAddressLine1,
																																	@AddressLine2 = @ADPAddressLine2,
																																	@City = @ADPCity,
																																	@State = @ADPState,
																																	@ZipCode = @ADPZipCode,
																																	@Zip5 = @ADPZip5,
																																	@Zip4 = @ADPZip4,
																																	@IsActive = 1,
																																	@IsDeleted = 0,
																																	@FullAddress = @FullAddress,
																																	@IsApproved = 0,
																																	@IsParent = 0,
																																	@LocationNumber=@LocationNumber
																									END
																									ELSE
																									BEGIN
																										
																										EXEC [KYP].[p_UpdateAdditionalParties]
																												
																																	@CaseID = @PDM_CaseID,
																																	@ApplicationID = @PDM_ApplicationID,
																																	@PartyID  = @PDM_OwnerPartyId,
																																	@ApplicationNo = @ProviderOrApplicationNbr,
																																	@PartyType = @ADPPartyType,
																																	@FirstName = @ADPFirstName,
																																	@LastName  = @ADPLastName,
																																	@MiddleName = @ADPMiddleName,
																																	@LegalName = @ADPLegalName ,
																																	@SSN = @ADPSSN,
																																	@TIN = @ADPTIN,
																																	@License = @ADPLicense,
																																	@ProviderTypeCode = @ADPProviderTypeCode,
																																	@ProviderTypeDescription =  @ADPProviderTypeDescription,
																																	@AddressType = @ADPAddressType,
																																	@AddressLine1 = @ADPAddressLine1,
																																	@AddressLine2 = @ADPAddressLine2,
																																	@City = @ADPCity,
																																	@State = @ADPState,
																																	@ZipCode = @ADPZipCode,
																																	@Zip5 = @ADPZip5,
																																	@Zip4 = @ADPZip4,
																																	@IsActive = 1,
																																	@IsDeleted = 0,
																																	@FullAddress = @FullAddress,
																																	@IsApproved = 0,
																																	@IsParent = 0,
																																	@LocationNumber=@LocationNumber
																									
																									END
                                                                                                                                
                                                                                                
                                                                                                SELECT @ADCurrentID = MIN(ID)
                                                                                                FROM dbo.AdditionalProviderParties WHERE PID = @ProviderOrApplicationNbr 
                                                                                                                AND PartyType = 'FacilityBusiness Address' AND ID > @ADCurrentID;
                                                                                              
                                                                                                END
                                                                                              
                                                                                END
                                                                                
                                                                                    /** Make IsFacilityBasedProvider Provider to zero **/
                                                                                    
                                                                                    if((select count(ID) from KYP.PDM_AdditionalParties where ApplicationNo = @P_ID)=0 )
                                                                                    Begin
																						Update KYP.ADM_CaseExtended set IsFacilityBasedProvider=0 where Number = @P_ID
                                                                                    END
                                                                                    
                                                                                    

                                                                    /************Insert PDM_Address and PDM_Location for Ind/Org PartyID + ProviderPartyID **********/
                                                                    EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_LINE1_AD
                                                                                    ,@AddressLine2 = @P_LINE2_AD
                                                                                    ,@City = @P_CITY_NAM
                                                                                    ,@Zip = @P_ZIP5_CD
                                                                                    ,@ZipPlus4 = @P_ZIP4_CD
                                                                                    ,@State = @P_ST_CD
                                                                                    ,@DateCreated = @now

                                                                    EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                    ,@PartyID = @PDM_ProviderPartyId
                                                                                    ,@ProviderID = @PDM_ProviderID
                                                                                                ,@PersonID = @PDM_ApplicationID
                                                                                    ,@DateCreated = @now
                                                                                    ,@Phone1 = @DH_PROV_TELE_NO

                                                                    EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                    ,@PartyID = @PDM_PartyId
                                                                                    ,@ProviderID = @PDM_ProviderID
                                                                                                ,@PersonID = @PDM_ApplicationID
                                                                                    ,@DateCreated = @now
                                                                                    ,@Phone1 = @DH_PROV_TELE_NO

                                                                    /************Insert a record in KYP.ADM_App_Provider **********/
                                                                    IF @ProviderType = 'I'
                                                                    BEGIN
                                                                                    EXEC [KYP].[p_InsertADMAppProvider] @PartyID = @PDM_ProviderPartyId
                                                                                                    ,@Category = 'Person'
                                                                                                    ,@Type = NULL
                                                                                                    ,@NPI = @P_NPI_NUM
                                                                                                    ,@UPIN = NULL
                                                                                                    ,@CCN = NULL
                                                                                                    ,@HIN = NULL
                                                                                                    ,@Remarks = NULL
                                                                                                    ,@DateCreated = @now
                                                                    END
                                                                    ELSE IF @ProviderType = 'O'
                                                                    BEGIN
                                                                                    EXEC [KYP].[p_InsertADMAppProvider] @PartyID = @PDM_ProviderPartyId
                                                                                                    ,@Category = 'Organization'
                                                                                                    ,@Type = NULL
                                                                                                    ,@NPI = @P_NPI_NUM
                                                                                                    ,@UPIN = NULL
                                                                                                    ,@CCN = NULL
                                                                                                    ,@HIN = NULL
                                                                                                    ,@Remarks = NULL
                                                                                                    ,@DateCreated = @now
                                                                    END

                                                                    /************Insert a record in SDMScreeningChecklist **********/
                                                                    SET @intScreenChkLoop = 1

                                                                    WHILE (@intScreenChkLoop <= 11)
                                                                    BEGIN
                                                                                    IF @intScreenChkLoop < 3
                                                                                                    SET @intScreeningChecklistID = 1
                                                                                    ELSE IF @intScreenChkLoop >= 3
                                                                                                    AND @intScreenChkLoop <= 5
                                                                                                    SET @intScreeningChecklistID = 2
                                                                                    ELSE
                                                                                                    SET @intScreeningChecklistID = 3

                                                                                    EXEC [KYP].[p_InsertSDMScreeningChecklist] @ApplicationID = @PDM_ApplicationID
                                                                                                    ,@ChecklistQuestID = @intScreenChkLoop
                                                                                                    ,@Completed = 0
                                                                                                    ,@NA = NULL
                                                                                                    ,@Remarks = NULL
                                                                                                    ,@DateCreated = @now
                                                                                                    ,@ChecklistID = @intScreeningChecklistID

                                                                                    SELECT @intScreenChkLoop = @intScreenChkLoop + 1
                                                                    END /*****End While For SDM_ScreeningChecklist insert*******/

                                                                    /************Insert ADM_App_Address and ADM_App_Location of the Provider **********/
                                                                    EXEC @ADM_App_AddressID = [KYP].[p_InsertADMAppAddress] @AddressLine1 = @P_LINE1_AD
                                                                                    ,@AddressLine2 = @P_LINE2_AD
                                                                                    ,@City = @P_CITY_NAM
                                                                                    ,@Zip = @P_ZIP5_CD
                                                                                    ,@ZipPlus4 = @P_ZIP4_CD
                                                                                    ,@State = @P_ST_CD
                                                                                    ,@DateCreated = @now

                                                                    EXEC [KYP].[p_InsertADMAppLocation] @AddressID = @ADM_App_AddressID
                                                                                    ,@ApplicationID = @PDM_ApplicationID
                                                                                    ,@DateCreated = @now

                                                                    /********Begin processing of Provider Licenses, if exist******/
                                                                    IF EXISTS (
                                                                                                    SELECT 1
                                                                                                    FROM dbo.ProviderLicense
                                                                                                    WHERE ProviderLicense.p_id = @ProviderOrApplicationNbr
                                                                                                    )
                                                                    BEGIN
                                                                                    /********Get the looping ids for processing Provider Licenses******/
                                                                                    SELECT @FirstLicense = MIN(ProviderLicense.ID)
                                                                                                    ,@CurrentLicense = MIN(ProviderLicense.ID)
                                                                                                    ,@LastLicense = MAX(ProviderLicense.ID)
                                                                                    FROM dbo.ProviderLicense
                                                                                    WHERE ProviderLicense.p_id = @ProviderOrApplicationNbr

                                                                                    WHILE (@CurrentLicense <= @LastLicense)
                                                                                    BEGIN
                                                                                                    /********Read License Fields of Provider******/
                                                                                                    SELECT @P_LIC_CERT_NUM = ProviderLicense.P_LIC_CERT_NUM
                                                                                                                    ,@P_LIC_ST_CD = ProviderLicense.P_ST_CD
                                                                                                                    ,@P_LIC_BRD_NUM = ProviderLicense.P_LIC_BRD_NUM
                                                                                                                    ,@P_LIC_EXP_DT = ProviderLicense.P_LIC_EXP_DT
                                                                                                    FROM [dbo].[ProviderLicense]
                                                                                                    WHERE ProviderLicense.P_ID = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderLicense.ID = @CurrentLicense

                                                                                                    /****Convert Expiry date to datetime**********/
                                                                                                    SELECT @P_LIC_EXP_DT_Conv = CONVERT(DATETIME, @P_LIC_EXP_DT, 121)

                                                                                                    SELECT @P_LIC_CERT_NUM = REPLACE(@P_LIC_CERT_NUM, '.', '')

                                                                                                    /*******Try to find the LicenseID of the provider*****/
                                                                                                    EXEC @PDM_LicenseID = [KYP].[p_FindLicenseRecord] @PartyID = @PDM_PartyId
                                                                                                                    ,@LicenseState = @P_LIC_ST_CD
                                                                                                                    ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                    ,@ExpiryDate = @P_LIC_EXP_DT_Conv
                                                                                                                    ,@CurrentModule = 1

                                                                                                    /*******If LicenseID not found, insert record in
    ******PDM_License table, else update record******/
                                                                                                    IF @PDM_LicenseID = - 1
                                                                                                                    EXEC [KYP].[p_InsertPDMLicense] @PartyID = @PDM_PartyId
                                                                                                                                    ,@LicenseState = @P_LIC_ST_CD
                                                                                                                                    ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                                    ,@LicenseAuthority = @P_LIC_BRD_NUM
                                                                                                                                    ,@ExpiryDate = @P_LIC_EXP_DT_Conv
                                                                                                                                    ,@DateCreated = @now
                                                                                                    ELSE IF @PDM_LicenseID IS NOT NULL
                                                                                                                    AND @PDM_LicenseID <> 0
                                                                                                                    EXEC [KYP].[p_UpdatePDMLicense] @PartyID = @PDM_PartyId
                                                                                                                                    ,@LicenseState = @P_LIC_ST_CD
                                                                                                                                    ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                                    ,@LicenseAuthority = @P_LIC_BRD_NUM
                                                                                                                                    ,@ExpiryDate = @P_LIC_EXP_DT_Conv
                                                                                                                                    ,@DateModified = @now
                                                                                                                
                                                                                                                                
                                                                                                                                IF @P_LIC_BRD_NUM = 'BOC'
                                                                                                                                BEGIN
                                                                                                                                                UPDATE KYP.ADM_CASE SET OP_BOC = 1 WHERE Number = @ProviderOrApplicationNbr
                                                                                                                                END
                                                                                                                                IF @P_LIC_BRD_NUM = 'ABCOP' 
                                                                                                                                BEGIN
                                                                                                                                                UPDATE KYP.ADM_CASE SET OP_ABOCP = 1 WHERE Number = @ProviderOrApplicationNbr
                                                                                                                                END
                                                                                                                                
                                                                                                                
                                                                                                    /*******Insert licenses in ADM_App_License******/
                                                                                                    EXEC [KYP].[p_InsertADMAppLicense] @ApplicationID = @PDM_ApplicationID
                                                                                                                    ,@LicenseAuthority = @P_LIC_BRD_NUM
                                                                                                                    ,@LicenseCode = @P_LIC_CERT_NUM
                                                                                                                    ,@State = @P_LIC_ST_CD
                                                                                                                    ,@ExpiryDate = @P_LIC_EXP_DT_Conv
                                                                                                                    ,@DateCreated = @now

                                                                                                    /*****Nullify all License Fields for next iteration*******/
                                                                                                    SELECT @P_LIC_CERT_NUM = NULL
                                                                                                                    ,@P_LIC_ST_CD = NULL
                                                                                                                    ,@P_LIC_BRD_NUM = NULL
                                                                                                                    ,@P_LIC_EXP_DT = NULL

                                                                                                    SELECT @CurrentLicense = MIN(ProviderLicense.ID)
                                                                                                    FROM dbo.ProviderLicense
                                                                                                    WHERE ProviderLicense.p_id = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderLicense.ID > @CurrentLicense
                                                                                    END --End while for license
                                                                    END --End License Processing Block

                                                                    /********Begin processing of Secondary NPI, if exist******/
                                                                    IF EXISTS (
                                                                                                    SELECT 1
                                                                                                    FROM dbo.ProviderSecondaryNPI
                                                                                                    WHERE ProviderSecondaryNPI.p_id = @ProviderOrApplicationNbr
                                                                                                    )
                                                                    BEGIN
                                                                                    /********Get the looping ids for processing Secondary NPI******/
                                                                                    SELECT @FirstSecondaryNPI = MIN(ProviderSecondaryNPI.ID)
                                                                                                    ,@CurrentSecondaryNPI = MIN(ProviderSecondaryNPI.ID)
                                                                                                    ,@LastSecondaryNPI = MAX(ProviderSecondaryNPI.ID)
                                                                                    FROM dbo.ProviderSecondaryNPI
                                                                                    WHERE ProviderSecondaryNPI.p_id = @ProviderOrApplicationNbr

                                                                                    WHILE (@CurrentSecondaryNPI <= @LastSecondaryNPI)
                                                                                    BEGIN
                                                                                                    /********Read Secondary NPI of Provider******/
                                                                                                    SELECT @P_ALT_ID = ProviderSecondaryNPI.P_ALT_ID
                                                                                                    FROM [dbo].[ProviderSecondaryNPI]
                                                                                                    WHERE ProviderSecondaryNPI.P_ID = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderSecondaryNPI.ID = @CurrentSecondaryNPI

                                                                                                    /* linu: integer NPI into to varchar       
    select @intNPI = CONVERT(int, @P_ALT_ID)*/
                                                                                                    /*******Try to find the SecondaryNPI of the provider*****/
                                                                                                    EXEC @PDM_SecondaryNPI = [KYP].[p_FindSecondaryNPIRecord] @PartyID = @PDM_PartyId
                                                                                                                    ,@NPI = @P_ALT_ID
                                                                                                                    ,@CurrentModule = 1

                                                                                                    /*******If Secondary NPI not found, insert record in
    ******PDM_SecondaryNPI table, else update record******/
                                                                                                    IF @PDM_SecondaryNPI = - 1
                                                                                                                    EXEC [KYP].[p_InsertPDMSecondaryNPI] @PartyID = @PDM_PartyId
                                                                                                                                    ,@NPI = @P_ALT_ID
                                                                                                                                    ,@DateCreated = @now
                                                                                                    ELSE IF @PDM_SecondaryNPI IS NOT NULL
                                                                                                                    AND @PDM_SecondaryNPI <> 0
                                                                                                                    EXEC [KYP].[p_UpdatePDMSecondaryNPI] @PartyID = @PDM_PartyId
                                                                                                                                    ,@NPI = @P_ALT_ID
                                                                                                                                    ,@DateModified = @now

                                                                                                    /*****Nullify all Secondary NPI Fields for next iteration*******/
                                                                                                    SELECT @P_ALT_ID = NULL

                                                                                                    SELECT @CurrentSecondaryNPI = MIN(ProviderSecondaryNPI.ID)
                                                                                                    FROM dbo.ProviderSecondaryNPI
                                                                                                    WHERE ProviderSecondaryNPI.p_id = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderSecondaryNPI.ID > @CurrentSecondaryNPI
                                                                                    END --End while for Secondary NPI
                                                                    END --End Secondary NPI Processing Block

                                                                    /********Begin processing of MCARE, if exist******/
                                                                    IF EXISTS (
                                                                                                    SELECT 1
                                                                                                    FROM dbo.ProviderMedicare
                                                                                                    WHERE ProviderMedicare.p_id = @ProviderOrApplicationNbr
                                                                                                    )
                                                                    BEGIN
                                                                                    /********Get the looping ids for processing Medicare******/
                                                                                    SELECT @FirstMedicare = MIN(ProviderMedicare.ID)
                                                                                                    ,@CurrentMedicare = MIN(ProviderMedicare.ID)
                                                                                                    ,@LastMedicare = MAX(ProviderMedicare.ID)
                                                                                    FROM dbo.ProviderMedicare
                                                                                    WHERE ProviderMedicare.p_id = @ProviderOrApplicationNbr

                                                                                    WHILE (@CurrentMedicare <= @LastMedicare)
                                                                                    BEGIN
                                                                                                    /********Read MCARE of Provider******/
                                                                                                    SELECT @P_MCARE_NUM = ProviderMedicare.P_MCARE_NUM
                                                                                                    FROM [dbo].[ProviderMedicare]
                                                                                                    WHERE ProviderMedicare.P_ID = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderMedicare.ID = @CurrentMedicare

                                                                                                    /*******Try to find the MCARE of the provider*****/
                                                                                                    EXEC @PDM_MCARE_ID = [KYP].[p_FindMCARERecord] @PartyID = @PDM_PartyId
                                                                                                                    ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                    ,@CurrentModule = 1

                                                                                                    /*******If MCARE not found, insert record in
    ******PDM_MCARENBR table, else update record******/
                                                                                                    IF @PDM_MCARE_ID = - 1
                                                                                                                    EXEC [KYP].[p_InsertPDMMCARENBR] @PartyID = @PDM_PartyId
                                                                                                                                    ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                                    ,@DateCreated = @now
                                                                                                    ELSE IF @PDM_MCARE_ID IS NOT NULL
                                                                                                                    AND @PDM_MCARE_ID <> 0
                                                                                                                    EXEC [KYP].[p_UpdatePDMMCARENBR] @PartyID = @PDM_PartyId
                                                                                                                                    ,@MCARE_NUM = @P_MCARE_NUM
                                                                                                                                    ,@DateModified = @now
                                                                                                                                    ,@MCAREID = @PDM_MCARE_ID

                                                                                                    /*****Nullify all MCARE Fields for next iteration*******/
                                                                                                    SELECT @P_MCARE_NUM = NULL

                                                                                                    SELECT @CurrentMedicare = MIN(ProviderMedicare.ID)
                                                                                                    FROM dbo.ProviderMedicare
                                                                                                    WHERE ProviderMedicare.p_id = @ProviderOrApplicationNbr
                                                                                                                    AND ProviderMedicare.ID > @CurrentMedicare
                                                                                    END --End while for MCARE
                                                                    END --End MCARE Processing Block

                                                                    /*******************Begin Processing of Speciality*****************/
                                                                    IF EXISTS (
                                                                                                    SELECT 1
                                                                                                    FROM dbo.ProviderSpeciality
                                                                                                    WHERE p_id = @ProviderOrApplicationNbr
                                                                                                    )
                                                                    BEGIN
                                                                                    /********Get the looping ids for processing Speciality******/
                                                                                    SELECT @FirstSpeciality = MIN(ID)
                                                                                                    ,@CurrentSpeciality = MIN(ID)
                                                                                                    ,@LastSpeciality = MAX(ID)
                                                                                    FROM dbo.ProviderSpeciality
                                                                                    WHERE p_id = @ProviderOrApplicationNbr

                                                                                    WHILE (@CurrentSpeciality <= @LastSpeciality)
                                                                                    BEGIN
                                                                                                    /********Read Speciality of Provider******/
                                                                                                    SELECT @P_SPECL_CD = P_SPECL_CD
                                                                                                    FROM [dbo].[ProviderSpeciality]
                                                                                                    WHERE P_ID = @ProviderOrApplicationNbr
                                                                                                                    AND ID = @CurrentSpeciality

                                                                                                    /*******Try to find the Speciality of the provider*****/
                                                                                                    EXEC @PDM_SpecialityID = [KYP].[p_FindProviderSpeciality] @PartyID = @PDM_ProviderPartyId
                                                                                                                    ,@Speciality_Code = @P_SPECL_CD
                                                                                                                    ,@CurrentModule = 2

                                                                                                    /*******If Speciality not found, insert record in
    ******PDM_Speciality table, else update record******/
                                                                                                    IF @PDM_SpecialityID = - 1
                                                                                                    BEGIN
                                                                                                                   

                                                                                                                    EXEC [KYP].[p_InsertPDMSpeciality] @PartyID = @PDM_ProviderPartyId
                                                                                                                                    ,@Speciality_Code = @P_SPECL_CD
                                                                                                                                    ,@DateCreated = @now
                                                                                                    END
                                                                                                    ELSE IF @PDM_SpecialityID IS NOT NULL
                                                                                                                    AND @PDM_SpecialityID <> 0
                                                                                                    BEGIN
                                                                                                                   

                                                                                                                    EXEC [KYP].[p_UpdatePDMSpeciality] @PartyID = @PDM_ProviderPartyId
                                                                                                                                    ,@Speciality_Code = @P_SPECL_CD
                                                                                                                                    ,@DateModified = @now
                                                                                                    END

                                                                                                    /*****Nullify all speciality Fields for next iteration*******/
                                                                                                    SELECT @P_SPECL_CD = NULL

                                                                                                    SELECT @CurrentSpeciality = MIN(ID)
                                                                                                    FROM dbo.[ProviderSpeciality]
                                                                                                    WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                    AND ID > @CurrentSpeciality
                                                                                    END --End while for Speciality
                                                                    END --End Speciality Processing Block

                                                                    /********Begin processing of CLIA, if exist******/
                                                                    IF EXISTS (
                                                                                                    SELECT 1
                                                                                                    FROM dbo.ProviderCLIA
                                                                                                    WHERE p_id = @ProviderOrApplicationNbr
                                                                                                    )
                                                                    BEGIN
                                                                                    /********Get the looping ids for processing CLIA******/
                                                                                    SELECT @FirstCLIA = MIN(ID)
                                                                                                    ,@CurrentCLIA = MIN(ID)
                                                                                                    ,@LastCLIA = MAX(ID)
                                                                                    FROM dbo.ProviderCLIA
                                                                                    WHERE p_id = @ProviderOrApplicationNbr

                                                                                    WHILE (@CurrentCLIA <= @LastCLIA)
                                                                                    BEGIN
                                                                                                    /********Read CLIA Nbr of Provider******/
                                                                                                    SELECT @P_CLIA_NUM = P_CLIA_NUM
                                                                                                    FROM [dbo].[ProviderCLIA]
                                                                                                    WHERE P_ID = @ProviderOrApplicationNbr
                                                                                                                    AND ID = @CurrentCLIA

                                                                                                    /*******Try to find the CLIA Nbr of the provider*****/
                                                                                                    EXEC @PDM_CLIA_ID = [KYP].[p_FindCLIARecord] @PartyID = @PDM_PartyId
                                                                                                                    ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                    ,@CurrentModule = 1

                                                                                                    /*******If CLIA NBR not found, insert record in
    ******PDM_CLIA table, else update record******/
                                                                                                    IF @PDM_CLIA_ID = - 1
                                                                                                                    EXEC [KYP].[p_InsertPDMCLIA] @PartyID = @PDM_PartyId
                                                                                                                                    ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                                    ,@DateCreated = @now
                                                                                                    ELSE IF @PDM_CLIA_ID IS NOT NULL
                                                                                                                    AND @PDM_CLIA_ID <> 0
                                                                                                                    EXEC [KYP].[p_UpdatePDMCLIA] @PartyID = @PDM_PartyId
                                                                                                                                    ,@CLIA_NBR = @P_CLIA_NUM
                                                                                                                                    ,@DateModified = @now

                                                                                                    /*****Nullify all CLIA Fields for next iteration*******/
                                                                                                    SELECT @P_CLIA_NUM = NULL

                                                                                                    SELECT @CurrentCLIA = MIN(ID)
                                                                                                    FROM dbo.ProviderCLIA
                                                                                                    WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                    AND ID > @CurrentCLIA
                                                                                    END --End while for CLIA
                                                                    END --End CLIA Processds
                                                                
                                                                /******* START : CHECK MOCA Before ********/
                                                                IF OBJECT_ID('tempdb.dbo.#BeforeMOCA', 'U') IS NOT NULL  DROP TABLE #BeforeMOCA;
                                                                IF OBJECT_ID('tempdb.dbo.#AfterMOCA', 'U') IS NOT NULL  DROP TABLE #AfterMOCA;

                                                                SELECT * INTO #BeforeMOCA FROM 
                                                                    (SELECT PartyID FROM KYP.SDM_ApplicationParty 
                                                                                   WHERE ApplicationID = @PDM_ApplicationID AND IsActive = 1) AS X
                                                                /******* END  : CHECK MOCA Before *********/

                                                                /********Begin processing of Individual Owners, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderIndOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Individual Owners******/
                                                                                SELECT @FirstIndOwner = MIN(ID)
                                                                                                ,@CurrentIndOwner = MIN(ID)
                                                                                                ,@LastIndOwner = MAX(ID)
                                                                                FROM dbo.ProviderIndOwner
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentIndOwner <= @LastIndOwner)
                                                                                BEGIN
                                                                                                /********Read Individual Owner Name and Address******/
                                                                                                SELECT @P_OWNER_LAST_NAM = [P_OWNER_LAST_NAM]
                                                                                                                ,@P_OWNER_FST_NAM = [P_OWNER_FST_NAM]
                                                                                                                ,@P_OWNER_MI_NAM = [P_OWNER_MI_NAM]
                                                                                                                ,@P_OWNER_TITL_NAM = [P_OWNER_TITL_NAM]
                                                                                                                ,@P_OWNER_DOB_DT = [P_OWNER_DOB_DT]
                                                                                                                ,@P_OWNER_SSN_NUM = [P_OWNER_SSN_NUM]
                                                                                                                ,@P_OWNER_LINE1_AD = [P_LINE1_AD]
                                                                                                                ,@P_OWNER_LINE2_AD = [P_LINE2_AD]
                                                                                                                ,@P_OWNER_CITY_NAM = [P_CITY_NAM]
                                                                                                                ,@P_OWNER_ST_CD = [P_ST_CD]
                                                                                                                ,@P_OWNER_ZIP5_CD = [P_ZIP5_CD]
                                                                                                                ,@P_OWNER_ZIP4_CD = [P_ZIP4_CD]
                                                                                                                ,@P_OWNER_TAG = [TAG]
                                                                                                                ,@P_OWNER_NPI_IND = CONVERT(INT,[Owner_NPI])
                                                                                                FROM [dbo].[ProviderIndOwner]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentIndOwner
                                                                                                                
                                                                                                                
                                                                                                                
                                                                                                SELECT @P_OWNER_NPI_IND = Pr.NPI FROM KYPPORTAL.PortalKYP.pPDM_Provider Pr
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Person Pe ON Pr.PartyID = Pe.PartyID
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party P ON Pe.PartyID = P.PartyID 
																								INNER JOIN KYPPORTAL.PortalKYP.pADM_Application A ON A.PartyID = P.ParentPartyID 
																								WHERE A.ApplicationNo = @ProviderOrApplicationNbr 
																								AND P.Type = 'Individual Ownership'  
																								AND Pe.LastName = @P_OWNER_LAST_NAM
																								AND Pe.FirstName = @P_OWNER_FST_NAM
																								AND REPLACE(Pe.SSN,'-','') = @P_OWNER_SSN_NUM

                                                                                                /********Remove the leading and trailing single quotes**************/
                                                                                                SELECT @P_OWNER_LAST_NAM = KYP.RemoveSingleQuotes(@P_OWNER_LAST_NAM)

                                                                                                SELECT @P_OWNER_FST_NAM = KYP.RemoveSingleQuotes(@P_OWNER_FST_NAM)

                                                                                                SELECT @P_OWNER_MI_NAM = KYP.RemoveSingleQuotes(@P_OWNER_MI_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_OWNER_LAST_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_LAST_NAM)

                                                                                                SELECT @P_OWNER_FST_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_FST_NAM)

                                                                                                SELECT @P_OWNER_MI_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_MI_NAM)

                                                                                                /********Derive Owner's Full Name******/
                                                                                                SELECT @P_OWNER_FULL_NAM = @P_OWNER_LAST_NAM + COALESCE((', ' + @P_OWNER_FST_NAM), '') + COALESCE((' ' + @P_OWNER_MI_NAM), '')

                                                                                                /*******Try to find the PartyID of the owner******/
                                                                                                EXEC @PDM_OwnerPartyId = KYP.p_FindScreenIndParty @TrackingNumber = @P_ID
                                                                                                                ,@LastName = @P_OWNER_LAST_NAM
                                                                                                                ,@FirstName = @P_OWNER_FST_NAM
                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                ,@LIC_CERT_NUM = NULL
                                                                                                                ,@LIC_STATE = NULL
                                                                                                                ,@NPI = NULL
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 0

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Person and PDM_Owner tables******/
                                                                                                IF @PDM_OwnerPartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                ,@Name = @P_OWNER_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT
                                                                                                                                ,@NPI = @P_OWNER_NPI_IND
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                ,@DateCreated = @now

                                                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make autoscreen flag true **/
                                                                                                                                BEGIN
                                                                                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                                                                                END
                                                                                                                                
                                                                                                                                
                                                                                                                /** SET Tag As a New for Screen new cases**/
                                                                                                                
                                                                                                               -- SET @P_OWNER_TAG = 'New'
                                                                                                                                
                                                                                                                                
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Person and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                AND @P_OWNER_TAG <> 'Unchanged'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_FULL_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT
                                                                                                                                ,@NPI = @P_OWNER_NPI_IND
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 1

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM
                                                                                                                                                ,@DateModified = @now
                                                                                                                                                
                                                                                                                                                
                                                                                                           /** If Update MOCA details find Screen (New) Or Not (NoChange)***/
                                                                                                           
                                                                                                          
                                                                                                           
                                                                                                           
                                                                                                           
                                                                                                END

                                                                                                /*******Logically Delete all previous address and********* location for this party******/
                                                                                                IF (@P_OWNER_TAG <> 'Unchanged')
                                                                                                BEGIN
																									UPDATE A
																									SET A.IsDeleted = 1
																									FROM KYP.PDM_Location A
																									INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
																													AND A.PartyID = @PDM_OwnerPartyId

                                                                                                UPDATE B
                                                                                                SET B.IsDeleted = 1
                                                                                                FROM KYP.PDM_Location A
                                                                                                INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
                                                                                                                AND A.PartyID = @PDM_OwnerPartyId

                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_OWNER_LINE1_AD
                                                                                                                ,@AddressLine2 = @P_OWNER_LINE2_AD
                                                                                                                ,@City = @P_OWNER_CITY_NAM
                                                                                                                ,@Zip = @P_OWNER_ZIP5_CD
                                                                                                                ,@ZipPlus4 = @P_OWNER_ZIP4_CD
                                                                                                                ,@State = @P_OWNER_ST_CD
                                                                                                                ,@DateCreated = @now

																									/********Create mapping of created address in PDM_Location 
	*********table for incoming address*********/
																									EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
																													,@PartyID = @PDM_OwnerPartyId
																													,@ProviderID = NULL
																													,@PersonID = @PDM_ApplicationID
																													,@DateCreated = @now
																													,@Phone1 = @DH_PROV_TELE_NO
                                                                                                                
                                                                                                 END

                                                                                                

                                                                                    IF @Resubmitted = 1 /** Resubmission scenario make isactive = 1 for new owners added **/
                                                                                                BEGIN                                                                                                   
                                                                                                                 SET @SDMIsActive = 1
                                                                                                                SELECT @ResubmitScrID = ScreeningID,
                                                                                                                @ResubmitAutoRisk = AutoRisk,
                                                                                                                @ResubmitEDDRisk = EDDRisk,
                                                                                                                @ResubmitCompositeRisk = CompositeRisk,
                                                                                                                @ResubmitNormalizedRisk = NormalizedRisk,
                                                                                                                @ResubmitDateCreated = DateCreated FROM KYP.SDM_ApplicationParty WHERE SDM_ApplicationParty.PartyID = @PDM_OwnerPartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID 
                                                                                                                 UPDATE KYP.SDM_ApplicationParty SET SDM_ApplicationParty.IsActive = 0, SDM_ApplicationParty.IsDeleted = 1 WHERE SDM_ApplicationParty.PartyID = @PDM_OwnerPartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID                                                                                                     
                                                                                     END

                                                                                                /************Insert Individual Owner to SDM_ApplicationParty**********/
                                                                                                IF (@P_OWNER_TAG <> 'Unchanged')
                                                                                                BEGIN
                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                ,@ScreeningID = @ResubmitScrID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@PartyType = 'Owner Person'
                                                                                                                ,@VerificationNoteID = NULL
                                                                                                                ,@IsVerified = 1
                                                                                                                ,@IsActive = @SDMIsActive
                                                                                                                ,@PartyRole = 'Person'
                                                                                                                ,@AutoRisk = @ResubmitAutoRisk
                                                                                                                ,@EDDRisk = @ResubmitEDDRisk
                                                                                                                ,@CompositeRisk = @ResubmitCompositeRisk
                                                                                                                ,@DateCreated = @ResubmitDateCreated
                                                                                                                ,@Tag = @P_OWNER_TAG
                                                                                                                ,@IsDeleted = 0

                                                                                                 END

                                                                                                /************Insert Individual Owner to ADM_AppOwner**********/
                                                                                                EXEC [KYP].[p_InsertADMAppOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@ApplicationID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now

                                                                                                /*****Nullify all Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_LAST_NAM = NULL
                                                                                                                ,@P_OWNER_FST_NAM = NULL
                                                                                                                ,@P_OWNER_MI_NAM = NULL
                                                                                                                ,@P_OWNER_TITL_NAM = NULL
                                                                                                                ,@P_OWNER_DOB_DT = NULL
                                                                                                                ,@P_OWNER_SSN_NUM = NULL
                                                                                                                ,@P_OWNER_LINE1_AD = NULL
                                                                                                                ,@P_OWNER_LINE2_AD = NULL
                                                                                                                ,@P_OWNER_CITY_NAM = NULL
                                                                                                                ,@P_OWNER_ST_CD = NULL
                                                                                                                ,@P_OWNER_ZIP5_CD = NULL
                                                                                                                ,@P_OWNER_ZIP4_CD = NULL
                                                                                                                ,@P_OWNER_TAG = NULL
                                                                                                                ,@P_OWNER_NPI_IND = NULL

                                                                                                SELECT @CurrentIndOwner = MIN(ID)
                                                                                                FROM dbo.ProviderIndOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentIndOwner
                                                                                END --End While loop for Individual Owners
                                                                END --End of Individual Owner processing block

                                                                /********Begin processing of Organizational Owners, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderOrgOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing Organizational Owners******/
                                                                                SELECT @FirstOrgOwner = MIN(ID)
                                                                                                ,@CurrentOrgOwner = MIN(ID)
                                                                                                ,@LastOrgOwner = MAX(ID)
                                                                                FROM dbo.ProviderOrgOwner
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentOrgOwner <= @LastOrgOwner)
                                                                                BEGIN
                                                                                                /********Read Organizational Owner Name and Address******/
                                                                                                SELECT @P_OWNER_BUSN_NAM = [P_OWNER_BUSN_NAM]
                                                                                                                ,@P_OWNER_DBA_NAM = [P_OWNER_DBA_NAM]
                                                                                                                ,@P_OWNER_TAX_ID = [P_OWNER_TAX_ID]
                                                                                                                ,@P_BUSN_LINE1_AD = [P_BUSN_LINE1_AD]
                                                                                                                ,@P_BUSN_LINE2_AD = [P_BUSN_LINE2_AD]
                                                                                                                ,@P_BUSN_CITY_NAM = [P_BUSN_CITY_NAM]
                                                                                                                ,@P_BUSN_ST_CD = [P_BUSN_ST_CD]
                                                                                                                ,@P_BUSN_ZIP5_CD = [P_BUSN_ZIP5_CD]
                                                                                                                ,@P_BUSN_ZIP4_CD = [P_BUSN_ZIP4_CD]
                                                                                                                ,@P_OWNER_TAG = [TAG]
                                                                                                                ,@Owner_NPI = CONVERT(INT,Owner_NPI)
                                                                                                FROM [dbo].[ProviderOrgOwner]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentOrgOwner
                                                                                                                
                                                                                                SELECT @Owner_NPI = O.NPI FROM KYPPORTAL.PortalKYP.pPDM_Organization O
																								INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party P ON O.PartyID = P.PartyID 
																								INNER JOIN KYPPORTAL.PortalKYP.pADM_Application A ON A.PartyID = P.ParentPartyID 
																								WHERE A.ApplicationNo = @ProviderOrApplicationNbr 
																								AND P.Type = 'Entity Ownership' 
																								AND O.LegalName = @P_OWNER_BUSN_NAM 
																								AND O.DBAName1 = @P_OWNER_DBA_NAM 
																								AND REPLACE(O.EIN,'-','') = @P_OWNER_TAX_ID

                                                                                                /********Derive Organizational Owner's Name******/
                                                                                                /*************Remove Single quotes*****************/
                                                                                                SELECT @P_OWNER_BUSN_NAM = KYP.RemoveSingleQuotes(@P_OWNER_BUSN_NAM)

                                                                                                SELECT @P_OWNER_DBA_NAM = KYP.RemoveSingleQuotes(@P_OWNER_DBA_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_OWNER_BUSN_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_BUSN_NAM)

                                                                                                SELECT @P_OWNER_DBA_NAM = KYP.RemoveDoubleQuotes(@P_OWNER_DBA_NAM)

                                                                                                SELECT @P_OWNER_BUSN_NAM = COALESCE(@P_OWNER_BUSN_NAM, @P_OWNER_DBA_NAM)

                                                                                                /*******Try to find the PartyID of the Organizational owner******/
                                                                                                EXEC @PDM_OwnerPartyId = KYP.p_FindScreenOrgParty @TrackingNumber = @P_ID
                                                                                                                ,@OrgName = @P_OWNER_BUSN_NAM
                                                                                                                ,@TAXID = @P_OWNER_TAX_ID
                                                                                                                ,@City = @P_BUSN_CITY_NAM
                                                                                                                ,@ZIP = @P_BUSN_ZIP5_CD
                                                                                                                ,@Adr_Line1 = @P_BUSN_LINE1_AD
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 0

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Organization and PDM_Owner tables******/
                                                                                                IF @PDM_OwnerPartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM
                                                                                                                                ,@DateCreated = @now
	                                                                                                                            ,@NPI = @Owner_NPI

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@DateCreated = @now

                                                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make autoscreen flag true **/
                                                                                                                                BEGIN
                                                                                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                                                                                END
                                                                                                                                
                                                                                                                 --SET @P_OWNER_TAG = 'New'
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Organization and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                AND @P_OWNER_TAG <> 'Unchanged'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM
                                                                                                                                ,@DateModified = @now
                                                                                                                                ,@NPI = @Owner_NPI

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 1

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Logically Delete all previous address and
********* location for this party******/														IF(@P_OWNER_TAG <> 'Unchanged')
BEGIN
                                                                                                UPDATE A
                                                                                                SET A.IsDeleted = 1
                                                                                                FROM KYP.PDM_Location A
                                                                                                INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
                                                                                                                AND A.PartyID = @PDM_OwnerPartyId

                                                                                                UPDATE B
                                                                                                SET B.IsDeleted = 1
                                                                                                FROM KYP.PDM_Location A
                                                                                                INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
                                                                                                                AND A.PartyID = @PDM_OwnerPartyId

                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_BUSN_LINE1_AD
                                                                                                                ,@AddressLine2 = @P_BUSN_LINE2_AD
                                                                                                                ,@City = @P_BUSN_CITY_NAM
                                                                                                                ,@Zip = @P_BUSN_ZIP5_CD
                                                                                                                ,@ZipPlus4 = @P_BUSN_ZIP4_CD
                                                                                                                ,@State = @P_BUSN_ST_CD
                                                                                                                ,@DateCreated = @now

                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@ProviderID = NULL
                                                                                                                ,@PersonID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO
                                                                                               END

                                                                                                

                                                                                     IF @Resubmitted = 1 /** Resubmission scenario make isactive = 1 for new owners added **/
                                                                                                BEGIN                                                                                                   
                                                                                                                SET @SDMIsActive = 1
                                                                                                                SELECT @ResubmitScrID = ScreeningID,
                                                                                                                @ResubmitAutoRisk = AutoRisk,
                                                                                                                @ResubmitEDDRisk = EDDRisk,
                                                                                                                @ResubmitCompositeRisk = CompositeRisk,
                                                                                                                @ResubmitNormalizedRisk = NormalizedRisk,
                                                                                                                @ResubmitDateCreated = DateCreated FROM KYP.SDM_ApplicationParty WHERE SDM_ApplicationParty.PartyID = @PDM_OwnerPartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID 
                                                                                                                 UPDATE KYP.SDM_ApplicationParty SET SDM_ApplicationParty.IsActive = 0, SDM_ApplicationParty.IsDeleted = 1 WHERE SDM_ApplicationParty.PartyID = @PDM_OwnerPartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID  
                                                                                     END

                                                                                                /************Insert Organizational Owner to SDM_ApplicationParty**********/
                                                                                                
                                                                                                IF(@P_OWNER_TAG <> 'Unchanged')
                                                                                                BEGIN
                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                ,@ScreeningID = @ResubmitScrID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@PartyType = 'Owner Organization'
                                                                                                                ,@VerificationNoteID = NULL
                                                                                                                ,@IsVerified = 1
                                                                                                                ,@IsActive = @SDMIsActive
                                                                                                                ,@PartyRole = 'Organization'
                                                                                                                ,@AutoRisk = @ResubmitAutoRisk
                                                                                                                ,@EDDRisk = @ResubmitEDDRisk
                                                                                                                ,@CompositeRisk = @ResubmitCompositeRisk
                                                                                                                ,@DateCreated = @ResubmitDateCreated
                                                                                                                ,@Tag = @P_OWNER_TAG
                                                                                                                ,@IsDeleted = 0

                                                                                                END

                                                                                                /************Insert Organizational Owner to ADM_AppOwner**********/
                                                                                                EXEC [KYP].[p_InsertADMAppOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                ,@ApplicationID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now

                                                                                                /*****Nullify all Organizational Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_BUSN_NAM = NULL
                                                                                                                ,@P_OWNER_DBA_NAM = NULL
                                                                                                                ,@P_OWNER_TAX_ID = NULL
                                                                                                                ,@P_BUSN_LINE1_AD = NULL
                                                                                                                ,@P_BUSN_LINE2_AD = NULL
                                                                                                                ,@P_BUSN_CITY_NAM = NULL
                                                                                                                ,@P_BUSN_ST_CD = NULL
                                                                                                                ,@P_BUSN_ZIP5_CD = NULL
                                                                                                                ,@P_BUSN_ZIP4_CD = NULL
                                                                                                                ,@P_OWNER_TAG = NULL
                                                                                                                ,@Owner_NPI = NULL

                                                                                                SELECT @CurrentOrgOwner = MIN(ID)
                                                                                                FROM dbo.ProviderOrgOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentOrgOwner
                                                                                END --End While loop for Organizational Owners
                                                                END --End of Organizational Owner processing block
                                                                
                                                                
                                                                
                                                                /******************************************************** START of Unscreened related MOCA changes **********************************************************/                                                           
                                         /********Begin processing of Individual Owners, if exist(Unscreened MOCA related changes) ******/
IF EXISTS (
		select T5.LastName,T5.FirstName,T5.MiddleName,T5.SSN,T5.Salutation
		From kypportal.portalkyp.padm_application T1
		Join kypportal.portalkyp.pprofile T2 on t1.Profile_ID = T2.Profile_ID
		Join kypenrollment.TaxidProfile T3 on T3.ProfileID = T2.EnrollmentProfileID and T3.taxID =  @P_FED_TAX_ID
		Join kypenrollment.paccount_pdm_Party T4 on T3.TaxIDProfileID = T4.TaxIDProfileID and (T4.ScreenedOn IS NULL OR @now >= dateadd(yy,5,T4.ScreenedOn))
		Join kypenrollment.paccount_pdm_person T5 on T4.Partyid = T5.Partyid
		Where T1.applicationNo=@ProviderOrApplicationNbr
		and T4.Type in ('Individual Ownership')
		and T4.currentrecordflag=1)
                                                                                                
		BEGIN
		
		Insert into @Tab_MOCALinking(PartyID 
					,P_OWNER_LAST_NAM_MOCA
					,P_OWNER_FST_NAM_MOCA
					,P_OWNER_MI_NAM_MOCA
					,P_OWNER_TITL_NAM_MOCA
					,P_OWNER_DOB_DT_MOCA
					,P_OWNER_SSN_NUM_MOCA
					,P_OWNER_TAG_MOCA
					,P_OWNER_LINE1_AD_MOCA
					,P_OWNER_LINE2_AD_MOCA
					,P_OWNER_CITY_NAM_MOCA
					,P_OWNER_ST_CD_MOCA
					,P_OWNER_ZIP5_CD_MOCA
					,P_OWNER_ZIP4_CD_MOCA
					,P_PROV_TELE_NO_MOCA
					,P_OWNER_SCR_ON_DATE_MOCA)
							                                                         
            /********Read Individual Owner Name and Address******/
            SELECT T4.PartyID  
            ,T5.LastName
			,T5.FirstName
            ,T5.MiddleName
            ,T5.Salutation
            ,T5.DOB
            ,T5.SSN 
            ,NULL
            ,NULL
            ,NULL
            ,NULL  
            ,NULL
            ,NULL
            ,NULL
            ,NULL 
            ,t4.ScreenedOn
			From kypportal.portalkyp.padm_application T1
			Join kypportal.portalkyp.pprofile T2 on t1.Profile_ID = T2.Profile_ID
			Join kypenrollment.TaxidProfile T3 on T3.ProfileID = T2.EnrollmentProfileID and T3.TaxID = @P_FED_TAX_ID
			Join kypenrollment.paccount_pdm_Party T4 on T3.TaxIDProfileID = T4.TaxIDProfileID and (T4.ScreenedOn IS NULL OR @now >= dateadd(yy,5,T4.ScreenedOn))
			Join kypenrollment.paccount_pdm_person T5 on T4.Partyid = T5.Partyid
			--Join KYPEnrollment.pAccount_PDM_Location T6 on T4.PartyID = T6.PartyID and T6.Type = 'Servicing'
			--Join KYPEnrollment.pAccount_PDM_Address T7 on T6.AddressID = T7.AddressID and T7.AddressLine1<>'No Data'
			Left Join KYPPORTAL.PortalKYP.StoredMOCADeleted T6 on T4.Partyid=T6.StoreMOCAPartyid AND T6.Status='confirmed'
			Where T1.applicationNo=@ProviderOrApplicationNbr
			and T4.Type in ('Individual Ownership')
			and T4.currentrecordflag=1
			and T6.StoreMOCAPartyid is null
			
			Set @MOCA_Cnt = @@RowCount;
			
			While (@MOCA_C <= @MOCA_Cnt)
            BEGIN
			
			SELECT @P_OWNER_LAST_NAM_MOCA = P_OWNER_LAST_NAM_MOCA
            ,@P_OWNER_FST_NAM_MOCA = P_OWNER_FST_NAM_MOCA
            ,@P_OWNER_MI_NAM_MOCA = P_OWNER_MI_NAM_MOCA
            ,@P_OWNER_TITL_NAM_MOCA = P_OWNER_TITL_NAM_MOCA
            ,@P_OWNER_DOB_DT_MOCA = P_OWNER_DOB_DT_MOCA
            ,@P_OWNER_SSN_NUM_MOCA = P_OWNER_SSN_NUM_MOCA 
            ,@P_OWNER_TAG_MOCA = NULL
            ,@P_OWNER_LINE1_AD_MOCA = P_OWNER_LINE1_AD_MOCA
            ,@P_OWNER_LINE2_AD_MOCA = P_OWNER_LINE2_AD_MOCA
            ,@P_OWNER_CITY_NAM_MOCA = P_OWNER_CITY_NAM_MOCA
            ,@P_OWNER_ST_CD_MOCA = P_OWNER_ST_CD_MOCA
            ,@P_OWNER_ZIP5_CD_MOCA = P_OWNER_ZIP5_CD_MOCA
            ,@P_OWNER_ZIP4_CD_MOCA = P_OWNER_ZIP4_CD_MOCA
            ,@P_OWNER_SCR_ON_DATE_MOCA = P_OWNER_SCR_ON_DATE_MOCA
            ,@DH_PROV_TELE_NO_MOCA = P_PROV_TELE_NO_MOCA
            From @Tab_MOCALinking
            Where ID = @MOCA_C;
Print @P_OWNER_LAST_NAM_MOCA
Print @P_OWNER_FST_NAM_MOCA

Print @P_OWNER_MI_NAM_MOCA


            /********Remove the leading and trailing single quotes**************/
            --SELECT @P_OWNER_LAST_NAM_MOCA = KYP.RemoveSingleQuotes(@P_OWNER_LAST_NAM_MOCA)

            --SELECT @P_OWNER_FST_NAM_MOCA = KYP.RemoveSingleQuotes(@P_OWNER_FST_NAM_MOCA)

            --SELECT @P_OWNER_MI_NAM_MOCA = KYP.RemoveSingleQuotes(@P_OWNER_MI_NAM_MOCA)

            /*************** Remove double quotes******************************/
            --SELECT @P_OWNER_LAST_NAM_MOCA = KYP.RemoveDoubleQuotes(@P_OWNER_LAST_NAM_MOCA)

            --SELECT @P_OWNER_FST_NAM_MOCA = KYP.RemoveDoubleQuotes(@P_OWNER_FST_NAM_MOCA)

            --SELECT @P_OWNER_MI_NAM_MOCA = KYP.RemoveDoubleQuotes(@P_OWNER_MI_NAM_MOCA)

            /********Derive Owner's Full Name******/
            SELECT @P_OWNER_FULL_NAM_MOCA = @P_OWNER_LAST_NAM_MOCA + COALESCE((', ' + @P_OWNER_FST_NAM_MOCA), '') + COALESCE((' ' + @P_OWNER_MI_NAM_MOCA), '')

            /*******Try to find the PartyID of the owner******/
            EXEC @PDM_OwnerPartyId = KYP.p_FindScreenIndParty @TrackingNumber = @P_ID
            ,@LastName = @P_OWNER_LAST_NAM_MOCA
            ,@FirstName = @P_OWNER_FST_NAM_MOCA
            ,@SSN = @P_OWNER_SSN_NUM_MOCA
            ,@LIC_CERT_NUM = NULL
            ,@LIC_STATE = NULL
			,@NPI = NULL
            ,@CurrentModule = 1
            ,@Isprovider = 0
            
            SET @P_OWNER_SSN_NUM_MOCA = Replace(@P_OWNER_SSN_NUM_MOCA,'-','')
            
            IF(@now >= dateadd(yy,5,@P_OWNER_SCR_ON_DATE_MOCA))
				BEGIN
					SET @PDM_OwnerPartyId = - 1
				END
            ELSE
				BEGIN
					SET @PDM_OwnerPartyId = @PDM_OwnerPartyId
				END

            /*******If PartyID not found, insert record 
			*********each in PDM_Party, PDM_Person and PDM_Owner tables******/
            IF @PDM_OwnerPartyId = - 1
																								BEGIN
																												EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
																																,@Name = @P_OWNER_FULL_NAM_MOCA
																																,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM_MOCA
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM_MOCA
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM_MOCA
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM_MOCA
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM_MOCA
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT_MOCA
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM_MOCA
                                                                                                                                ,@DateCreated = @now
                                                                                                                                
																																/*
                                                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make autoscreen flag true **/
                                                                                                                                BEGIN
                                                                                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                                                                                END
                                                                                                                                */
                                                                                                                                
                                                                                                                                
                                                                                                                /** SET Tag As a New for Screen new cases**/
                                                                                                                
                                                                                                                SET @P_OWNER_TAG_MOCA = 'Screened'
                                                                                                                                
                                                                                                                                
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Person and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                AND @P_OWNER_TAG_MOCA <> 'Unchanged'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_FULL_NAM_MOCA
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@SSN = @P_OWNER_SSN_NUM_MOCA
                                                                                                                                ,@Salunation = @P_OWNER_TITL_NAM_MOCA
                                                                                                                                ,@FirstName = @P_OWNER_FST_NAM_MOCA
                                                                                                                                ,@LastName = @P_OWNER_LAST_NAM_MOCA
                                                                                                                                ,@MiddleName = @P_OWNER_MI_NAM_MOCA
                                                                                                                                ,@DoB = @P_OWNER_DOB_DT_MOCA
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 1

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM_MOCA
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_OWNER_TITL_NAM_MOCA
                                                                                                                                                ,@DateModified = @now
                                                                                                                                                
                                                                                                                                                
                                                                                                           /** If Update MOCA details find Screen (New) Or Not (NoChange)***/
                                                                                                           
                                                                                                          
                                                                                                           
                                                                                                           
                                                                                                           
                                                                                                END
																								
																								
                                                                                                                

																									/********Create record in PDM_Address table for incoming address*********/
																									EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_OWNER_LINE1_AD_MOCA
                                                                                                                ,@AddressLine2 = @P_OWNER_LINE2_AD_MOCA
                                                                                                                ,@City = @P_OWNER_CITY_NAM_MOCA
                                                                                                                ,@Zip = @P_OWNER_ZIP5_CD_MOCA
                                                                                                                ,@ZipPlus4 = @P_OWNER_ZIP4_CD_MOCA
                                                                                                                ,@State = @P_OWNER_ST_CD_MOCA
                                                                                                                ,@DateCreated = @now

																									/********Create mapping of created address in PDM_Location 
																									*********table for incoming address*********/
																									EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
																													,@PartyID = @PDM_OwnerPartyId
																													,@ProviderID = NULL
																													,@PersonID = @PDM_ApplicationID
																													,@DateCreated = @now
																													,@Phone1 = @DH_PROV_TELE_NO_MOCA
                                                                                                                
                                                                                                 --END

                                                                                                

                                                                                    

                                                                                                /************Insert Individual Owner to SDM_ApplicationParty**********/
                                                                                                IF (@P_OWNER_TAG_MOCA <> 'Unchanged')
                                                                                                BEGIN
                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                ,@ScreeningID = @ResubmitScrID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@PartyType = 'Owner Person'
                                                                                                                ,@VerificationNoteID = NULL
                                                                                                                ,@IsVerified = 1
                                                                                                                ,@IsActive = @SDMIsActive
                                                                                                                ,@PartyRole = 'Person'
                                                                                                                ,@AutoRisk = NULL
                                                                                                                ,@EDDRisk = NULL
                                                                                                                ,@CompositeRisk = NULL
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@Tag = @P_OWNER_TAG_MOCA
                                                                                                                ,@IsDeleted = 0

                                                                                                END

                                                                                                

                                                                                                /*****Nullify all Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_LAST_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_FST_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_MI_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_TITL_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_DOB_DT_MOCA = NULL
                                                                                                                ,@P_OWNER_SSN_NUM_MOCA = NULL
                                                                                                                ,@P_OWNER_LINE1_AD_MOCA = NULL
                                                                                                                ,@P_OWNER_LINE2_AD_MOCA = NULL
                                                                                                                ,@P_OWNER_CITY_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_ST_CD_MOCA = NULL
                                                                                                                ,@P_OWNER_ZIP5_CD_MOCA = NULL
                                                                                                                ,@P_OWNER_ZIP4_CD_MOCA = NULL
                                                                                                                ,@P_OWNER_TAG_MOCA = NULL
                                                                                                                ,@P_OWNER_SCR_ON_DATE_MOCA = NULL
                                                                                                                
                                                                                                                Set @MOCA_C	= @MOCA_C+1
																								End --New while loop for MOCA Linking end

                                                                                                SELECT @CurrentIndOwner = MIN(ID)
                                                                                                FROM dbo.ProviderIndOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentIndOwner
                                                                                --END --End While loop for Individual Owners
        END --End of Individual Owner processing block
                                                                
                                                                
                                                                 /********Begin processing of Organizational Owners, if exist (Unscreened MOCA related changes)******/
                                                                IF EXISTS (
                                                                            
																			select T5.BusinessName,T5.DBAName1,T5.TIN 
																			From kypportal.portalkyp.padm_application T1
																			Join kypportal.portalkyp.pprofile T2 on t1.Profile_ID = T2.Profile_ID
																			Join kypenrollment.TaxidProfile T3 on T3.ProfileID = T2.EnrollmentProfileID and T3.TaxID = @P_FED_TAX_ID
																			Join kypenrollment.paccount_pdm_Party T4 on T3.TaxIDProfileID = T4.TaxIDProfileID AND (T4.ScreenedOn IS NULL OR @now >= dateadd(yy,5,T4.ScreenedOn))
																			Join kypenrollment.paccount_pdm_Organization T5 on T4.Partyid = T5.Partyid
																			Where T1.applicationNo=@ProviderOrApplicationNbr
																			and T4.Type in ('Entity Ownership')
																			and T4.currentrecordflag=1
                                                                                                )
                                                                BEGIN	
                                                                /*
                                                                                /********Get the looping ids for processing Organizational Owners******/
                                                                                SELECT @FirstOrgOwner = MIN(ID)
                                                                                                ,@CurrentOrgOwner = MIN(ID)
                                                                                                ,@LastOrgOwner = MAX(ID)
                                                                                FROM dbo.ProviderOrgOwner
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentOrgOwner <= @LastOrgOwner)
                                                                                */
                                                                                --BEGIN			
                                                                                
																		Insert into @Tab_MOCALinking_Own(PartyID 
																				,P_OWNER_BUSN_NAM_MOCA 
																				,P_OWNER_DBA_NAM_MOCA 
																				,P_OWNER_TAX_ID_MOCA 
																				,P_BUSN_LINE1_AD_MOCA 
																				,P_BUSN_LINE2_AD_MOCA 
																				,P_BUSN_CITY_NAM_MOCA 
																				,P_BUSN_ST_CD_MOCA 
																				,P_BUSN_ZIP5_CD_MOCA 
																				,P_BUSN_ZIP4_CD_MOCA
																				,P_BUSN_SCR_ON_DATE_MOCA )
                                                                                                /********Read Organizational Owner Name and Address******/
                                                                                                SELECT  T4.PartyID
																										,T5.LegalName
                                                                                                        ,T5.DBAName1
                                                                                                        ,T5.TIN
                                                                                                        ,NULL
                                                                                                        ,NULL
                                                                                                        ,NULL
                                                                                                        ,NULL
                                                                                                        ,NULL
                                                                                                        ,NULL
                                                                                                        ,T4.ScreenedOn
																								From kypportal.portalkyp.padm_application T1
																								Join kypportal.portalkyp.pprofile T2 on t1.Profile_ID = T2.Profile_ID
																								Join kypenrollment.TaxidProfile T3 on T3.ProfileID = T2.EnrollmentProfileID and T3.TaxID = @P_FED_TAX_ID
																								Join kypenrollment.paccount_pdm_Party T4 on T3.TaxIDProfileID = T4.TaxIDProfileID AND (T4.ScreenedOn IS NULL OR @now >= dateadd(yy,5,T4.ScreenedOn))
																								Join kypenrollment.paccount_pdm_Organization T5 on T4.Partyid = T5.Partyid 
																								--Join KYPEnrollment.pAccount_PDM_Location T6 on T5.PartyID = T6.PartyID
																								--Join KYPEnrollment.pAccount_PDM_Address T7 on T6.AddressID = T7.AddressID AND T7.AddressLine1<>'No Data'
																								Left Join KYPPORTAL.PortalKYP.StoredMOCADeleted T6 on T4.Partyid=T6.StoreMOCAPartyid AND T6.Status='confirmed'
																								Where T1.applicationNo=@ProviderOrApplicationNbr
																								and T4.Type in ('Entity Ownership')
																								and T4.currentrecordflag=1
																								and T6.StoreMOCAPartyid is null
																								
																								Set @MOCA_OWN_Cnt = @@RowCount;
																								
																								--New while loop for MOCA Linking Starts
																								While (@MOCA_OWN_C <= @MOCA_OWN_Cnt)
																								BEGIN
																								
																								SELECT @P_OWNER_BUSN_NAM_MOCA = P_OWNER_BUSN_NAM_MOCA
                                                                                                                ,@P_OWNER_DBA_NAM_MOCA = P_OWNER_DBA_NAM_MOCA
                                                                                                                ,@P_OWNER_TAX_ID_MOCA = P_OWNER_TAX_ID_MOCA
                                                                                                                ,@P_BUSN_LINE1_AD_MOCA = P_BUSN_LINE1_AD_MOCA
                                                                                                                ,@P_BUSN_LINE2_AD_MOCA = P_BUSN_LINE2_AD_MOCA
                                                                                                                ,@P_BUSN_CITY_NAM_MOCA = P_BUSN_CITY_NAM_MOCA 
                                                                                                                ,@P_BUSN_ST_CD_MOCA = P_BUSN_ST_CD_MOCA
                                                                                                                ,@P_BUSN_ZIP5_CD_MOCA = P_BUSN_ZIP5_CD_MOCA
                                                                                                                ,@P_BUSN_ZIP4_CD_MOCA = P_BUSN_ZIP4_CD_MOCA
                                                                                                                ,@P_BUSN_SCR_ON_DATE_MOCA = P_BUSN_SCR_ON_DATE_MOCA
                                                                                                From @Tab_MOCALinking_Own
                                                                                                Where ID = @MOCA_OWN_C;
                                                                                                
                                                                                                
                                                                                                PRINT @P_OWNER_BUSN_NAM_MOCA;
                                                                                                PRINT @P_OWNER_DBA_NAM_MOCA;

                                                                                                /********Derive Organizational Owner's Name******/
                                                                                                /*************Remove Single quotes*****************/
                                                                                                --SELECT @P_OWNER_BUSN_NAM_MOCA = KYP.RemoveSingleQuotes(@P_OWNER_BUSN_NAM_MOCA)

                                                                                                --SELECT @P_OWNER_DBA_NAM_MOCA = KYP.RemoveSingleQuotes(@P_OWNER_DBA_NAM_MOCA)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                --SELECT @P_OWNER_BUSN_NAM_MOCA = KYP.RemoveDoubleQuotes(@P_OWNER_BUSN_NAM_MOCA)

                                                                                                --SELECT @P_OWNER_DBA_NAM_MOCA = KYP.RemoveDoubleQuotes(@P_OWNER_DBA_NAM_MOCA)

                                                                                                SELECT @P_OWNER_BUSN_NAM_MOCA = COALESCE(@P_OWNER_BUSN_NAM_MOCA, @P_OWNER_DBA_NAM_MOCA)

                                                                                                /*******Try to find the PartyID of the Organizational owner******/
                                                                                                EXEC @PDM_OwnerPartyId = KYP.p_FindScreenOrgParty @TrackingNumber = @P_ID
                                                                                                                ,@OrgName = @P_OWNER_BUSN_NAM_MOCA
                                                                                                                ,@TAXID = @P_OWNER_TAX_ID_MOCA
                                                                                                                ,@City = @P_BUSN_CITY_NAM_MOCA
                                                                                                                ,@ZIP = @P_BUSN_ZIP5_CD_MOCA
                                                                                                                ,@Adr_Line1 = @P_BUSN_LINE1_AD_MOCA
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 0
                                                                                                                
                                                                                                                
																								SET @P_OWNER_TAX_ID_MOCA = replace(@P_OWNER_TAX_ID_MOCA,'-','')
																								
																								IF(@now >= dateadd(yy,5,@P_BUSN_SCR_ON_DATE_MOCA))
																									BEGIN
																										SET @PDM_OwnerPartyId = - 1
																									END
																								ELSE
																									BEGIN
																										SET @PDM_OwnerPartyId = @PDM_OwnerPartyId
																									END

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Organization and PDM_Owner tables******/
                                                                                                IF @PDM_OwnerPartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_OwnerPartyId = [KYP].[p_InsertPDMParty] @Type = 'Organization'
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM_MOCA
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDM_Organization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID_MOCA
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM_MOCA
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM_MOCA
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@DateCreated = @now

                                                                                                                                /*
                                                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make autoscreen flag true **/
                                                                                                                                BEGIN
                                                                                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                                                                                END
                                                                                                                                */
                                                                                                                                
                                                                                                                 SET @P_OWNER_TAG_MOCA = 'Screened'
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Organization and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_OwnerPartyId IS NOT NULL
                                                                                                                                AND @PDM_OwnerPartyId <> 0
                                                                                                                                AND @P_OWNER_TAG_MOCA <> 'Unchanged'
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@Name = @P_OWNER_BUSN_NAM_MOCA
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMOrganization] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@TIN = @P_OWNER_TAX_ID_MOCA
                                                                                                                                ,@LegalName = @P_OWNER_BUSN_NAM_MOCA
                                                                                                                                ,@DBAName1 = @P_OWNER_DBA_NAM_MOCA
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_OwnerID = [KYP].[p_FindOwnerRecord] @PartyID = @PDM_OwnerPartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 1

                                                                                                                IF @PDM_OwnerID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_OwnerID IS NOT NULL
                                                                                                                                AND @PDM_OwnerID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMOwner] @PartyID = @PDM_OwnerPartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Logically Delete all previous address and
********* location for this party******/														IF(@P_OWNER_TAG_MOCA <> 'Unchanged')
																							BEGIN
                                                                                               

                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_BUSN_LINE1_AD_MOCA
                                                                                                                ,@AddressLine2 = @P_BUSN_LINE2_AD_MOCA
                                                                                                                ,@City = @P_BUSN_CITY_NAM_MOCA
                                                                                                                ,@Zip = @P_BUSN_ZIP5_CD_MOCA
                                                                                                                ,@ZipPlus4 = @P_BUSN_ZIP4_CD_MOCA
                                                                                                                ,@State = NULL
                                                                                                                ,@DateCreated = @now

                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@ProviderID = NULL
                                                                                                                ,@PersonID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO_MOCA
                                                                                            END

                                                                                                

                                                                                    

                                                                                                /************Insert Organizational Owner to SDM_ApplicationParty**********/
                                                                                                
                                                                                                IF(@P_OWNER_TAG_MOCA <> 'Unchanged')
                                                                                                BEGIN
                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                ,@ScreeningID = @ResubmitScrID
                                                                                                                ,@PartyID = @PDM_OwnerPartyId
                                                                                                                ,@PartyType = 'Owner Organization'
                                                                                                                ,@VerificationNoteID = NULL
                                                                                                                ,@IsVerified = 1
                                                                                                                ,@IsActive = @SDMIsActive
                                                                                                                ,@PartyRole = 'Organization'
                                                                                                                ,@AutoRisk = NULL
                                                                                                                ,@EDDRisk = NULL
                                                                                                                ,@CompositeRisk = NULL
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@Tag = @P_OWNER_TAG_MOCA
                                                                                                                ,@IsDeleted = 0

                                                                                                END

                                                                                                

                                                                                                /*****Nullify all Organizational Owner Fields for next iteration*******/
                                                                                                SELECT @P_OWNER_BUSN_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_DBA_NAM_MOCA = NULL
                                                                                                                ,@P_OWNER_TAX_ID_MOCA = NULL
                                                                                                                ,@P_BUSN_LINE1_AD_MOCA = NULL
                                                                                                                ,@P_BUSN_LINE2_AD_MOCA = NULL
                                                                                                                ,@P_BUSN_CITY_NAM_MOCA = NULL
                                                                                                                ,@P_BUSN_ST_CD_MOCA = NULL
                                                                                                                ,@P_BUSN_ZIP5_CD_MOCA = NULL
                                                                                                                ,@P_BUSN_ZIP4_CD_MOCA = NULL
                                                                                                                ,@P_OWNER_TAG_MOCA = NULL
                                                                                                                ,@P_BUSN_SCR_ON_DATE_MOCA = NULL
                                                                                                                
                                                                                                                
                                                                                                                Set @MOCA_OWN_C	= @MOCA_OWN_C+1
																								End --New while loop for MOCA Linking end

                                                                                                SELECT @CurrentOrgOwner = MIN(ID)
                                                                                                FROM dbo.ProviderOrgOwner
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentOrgOwner
                                                                                --END --End While loop for Organizational Owners
                                                                END --End of Organizational Owner processing block                       
                                                               
      /******************************************************** END of Unscreened related MOCA changes **********************************************************/              

                                                                /********Begin processing of MD Employees, if exist******/
                                                                IF EXISTS (
                                                                                                SELECT 1
                                                                                                FROM dbo.ProviderEmployee
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                )
                                                                BEGIN
                                                                                /********Get the looping ids for processing MD Employees******/
                                                                                SELECT @FirstEmployee = MIN(ID)
                                                                                                ,@CurrentEmployee = MIN(ID)
                                                                                                ,@LastEmployee = MAX(ID)
                                                                                FROM dbo.ProviderEmployee
                                                                                WHERE p_id = @ProviderOrApplicationNbr

                                                                                WHILE (@CurrentEmployee <= @LastEmployee)
                                                                                BEGIN
                                                                                                /********Read MD Employee's Name and Address******/
                                                                                                SELECT @P_EMPL_LAST_NAM = [P_EMPL_LAST_NAM]
                                                                                                                ,@P_EMPL_FST_NAM = [P_EMPL_FST_NAM]
                                                                                                                ,@P_EMPL_MI_NAM = [P_EMPL_MI_NAM]
                                                                                                                ,@P_EMPL_TITL_NAM = [P_EMPL_TITL_NAM]
                                                                                                                ,@P_EMPL_SSN = [P_EMPL_SSN]
                                                                                                                ,@P_EMPL_DOB_DT = [P_EMPL_DOB_DT]
                                                                                                                ,@P_EMPL_LINE1_AD = [P_LINE1_AD]
                                                                                                                ,@P_EMPL_LINE2_AD = [P_LINE2_AD]
                                                                                                                ,@P_EMPL_CITY_NAM = [P_CITY_NAM]
                                                                                                                ,@P_EMPL_ST_CD = [P_ST_CD]
                                                                                                                ,@P_EMPL_ZIP5_CD = [P_ZIP5_CD]
                                                                                                                ,@P_EMPL_ZIP4_CD = [P_ZIP4_CD]
                                                                                                FROM [dbo].[ProviderEmployee]
                                                                                                WHERE [P_ID] = @ProviderOrApplicationNbr
                                                                                                                AND [ID] = @CurrentEmployee

                                                                                                /********Remove the leading and trailing single quotes**************/
                                                                                                SELECT @P_EMPL_LAST_NAM = KYP.RemoveSingleQuotes(@P_EMPL_LAST_NAM)

                                                                                                SELECT @P_EMPL_FST_NAM = KYP.RemoveSingleQuotes(@P_EMPL_FST_NAM)

                                                                                                SELECT @P_EMPL_MI_NAM = KYP.RemoveSingleQuotes(@P_EMPL_MI_NAM)

                                                                                                /*************** Remove double quotes******************************/
                                                                                                SELECT @P_EMPL_LAST_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_LAST_NAM)

                                                                                                SELECT @P_EMPL_FST_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_FST_NAM)

                                                                                                SELECT @P_EMPL_MI_NAM = KYP.RemoveDoubleQuotes(@P_EMPL_MI_NAM)

                                                                                                /********Derive MD Employee's Full Name******/
                                                                                                SELECT @P_EMPL_FULL_NAM = @P_EMPL_LAST_NAM + COALESCE((', ' + @P_EMPL_FST_NAM), '') + COALESCE((' ' + @P_EMPL_MI_NAM), '')

                                                                                                /*******Try to find the PartyID of the MD Employee******/
                                                                                                EXEC @PDM_EmployeePartyId = KYP.p_FindScreenIndParty @TrackingNumber = @P_ID
                                                                                                                ,@LastName = @P_EMPL_LAST_NAM
                                                                                                                ,@FirstName = @P_EMPL_FST_NAM
                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                ,@NPI = NULL
                                                                                                                ,@LIC_CERT_NUM = NULL
                                                                                                                ,@LIC_STATE = NULL
                                                                                                                ,@CurrentModule = 1
                                                                                                                ,@Isprovider = 0

                                                                                                /*******If PartyID not found, insert record 
*********each in PDM_Party, PDM_Person and PDM_Owner tables******/
                                                                                                IF @PDM_EmployeePartyId = - 1
                                                                                                BEGIN
                                                                                                                EXEC @PDM_EmployeePartyId = [KYP].[p_InsertPDMParty] @Type = 'Person'
                                                                                                                                ,@Name = @P_EMPL_FULL_NAM
                                                                                                                                ,@IsProvider = 0
                                                                                                                                ,@IsEnrolled = 1
                                                                                                                                ,@IsTemp = 0
                                                                                                                                ,@IsActive = 1
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@IsDeleted = 0
                                                                                                                                ,@DateCreated = @now
                                                                                                                                ,@CurrentModule = 1

                                                                                                                EXEC [KYP].[p_InsertPDMPerson] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                                ,@Salunation = @P_EMPL_TITL_NAM
                                                                                                                                ,@FirstName = @P_EMPL_FST_NAM
                                                                                                                                ,@LastName = @P_EMPL_LAST_NAM
                                                                                                                                ,@MiddleName = @P_EMPL_MI_NAM
                                                                                                                                ,@DoB = @P_EMPL_DOB_DT
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateCreated = @now

                                                                                                                EXEC [KYP].[p_InsertPDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                ,@DateCreated = @now

                                                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make autoscreen flag true **/
                                                                                                                                BEGIN
                                                                                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                                                                                END
                                                                                                END
                                                                                                                                /*******If PartyID found, update the record 
*********in PDM_Party, PDM_Person and PDM_Owner(update/insert) tables******/
                                                                                                ELSE IF (
                                                                                                                                @PDM_EmployeePartyId IS NOT NULL
                                                                                                                                AND @PDM_EmployeePartyId <> 0
                                                                                                                                )
                                                                                                BEGIN
                                                                                                                EXEC [KYP].[p_UpdatePDMParty] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@Name = @P_EMPL_FULL_NAM
                                                                                                                                ,@LoadType = @LoadType
                                                                                                                                ,@LoadID = @LoadID
                                                                                                                                ,@LastLoadDate = @LastLoadDate
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC [KYP].[p_UpdatePDMPerson] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@SSN = @P_EMPL_SSN
                                                                                                                                ,@Salunation = @P_EMPL_TITL_NAM
                                                                                                                                ,@FirstName = @P_EMPL_FST_NAM
                                                                                                                                ,@LastName = @P_EMPL_LAST_NAM
                                                                                                                                ,@MiddleName = @P_EMPL_MI_NAM
                                                                                                                                ,@DoB = @P_EMPL_DOB_DT
                                                                                                                                ,@NPI = NULL
                                                                                                                                ,@DateModified = @now

                                                                                                                EXEC @PDM_EmployeeID = [KYP].[p_FindEmployeeRecord] @PartyID = @PDM_EmployeePartyId
                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                ,@CurrentModule = 1

                                                                                                                IF @PDM_EmployeeID = - 1
                                                                                                                                EXEC [KYP].[p_InsertPDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                                ,@DateCreated = @now
                                                                                                                ELSE IF @PDM_EmployeeID IS NOT NULL
                                                                                                                                AND @PDM_EmployeeID <> 0
                                                                                                                                EXEC [KYP].[p_UpdatePDMEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                                                ,@ProviderID = @PDM_ProviderID
                                                                                                                                                ,@Designation = @P_EMPL_TITL_NAM
                                                                                                                                                ,@DateModified = @now
                                                                                                END

                                                                                                /*******Logically Delete all previous address and
********* location for this party******/
                                                                                                UPDATE A
                                                                                                SET A.IsDeleted = 1
                                                                                                FROM KYP.PDM_Location A
                                                                                                INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
                                                                                                                AND A.PartyID = @PDM_EmployeePartyId

                                                                                                UPDATE B
                                                                                                SET B.IsDeleted = 1
                                                                                                FROM KYP.PDM_Location A
                                                                                                INNER JOIN KYP.PDM_Address B ON A.AddressID = B.AddressID
                                                                                                                AND A.PartyID = @PDM_EmployeePartyId

                                                                                                /********Create record in PDM_Address table for incoming address*********/
                                                                                                EXEC @PDM_AddressID = [KYP].[p_InsertPDMAddress] @AddressLine1 = @P_EMPL_LINE1_AD
                                                                                                                ,@AddressLine2 = @P_EMPL_LINE2_AD
                                                                                                                ,@City = @P_EMPL_CITY_NAM
                                                                                                                ,@Zip = @P_EMPL_ZIP5_CD
                                                                                                                ,@ZipPlus4 = @P_EMPL_ZIP4_CD
                                                                                                                ,@State = @P_EMPL_ST_CD
                                                                                                                ,@DateCreated = @now

                                                                                                /********Create mapping of created address in PDM_Location 
*********table for incoming address*********/
                                                                                                EXEC [KYP].[p_InsertPDMLocation] @AddressID = @PDM_AddressID
                                                                                                                ,@PartyID = @PDM_EmployeePartyId
                                                                                                                ,@ProviderID = NULL
                                                                                                                ,@PersonID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@Phone1 = @DH_PROV_TELE_NO

                                                                                                

                                                                                                IF @Resubmitted = 1 /** Resubmission scenario make isactive = 1 for new owners added **/
                                                                                                BEGIN                                                                                                   
                                                                                                                 SET @SDMIsActive = 1
                                                                                                                SELECT @ResubmitScrID = ScreeningID FROM KYP.SDM_ApplicationParty WHERE SDM_ApplicationParty.PartyID = @PDM_OwnerPartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID 
                                                                                                                  UPDATE KYP.SDM_ApplicationParty SET SDM_ApplicationParty.IsActive = 0, SDM_ApplicationParty.IsDeleted = 1 WHERE SDM_ApplicationParty.PartyID = @PDM_EmployeePartyId
                                                                                                                AND SDM_ApplicationParty.ApplicationID = @PDM_ApplicationID  
                                                                                     END

                                                                                                /************Insert MDEmployee to SDM_ApplicationParty**********/
                                                                                                EXEC [KYP].[p_InsertSDMApplicationParty] @ApplicationID = @PDM_ApplicationID
                                                                                                                ,@ScreeningID = @ResubmitScrID
                                                                                                                ,@PartyID = @PDM_EmployeePartyId
                                                                                                                ,@PartyType = 'Managing Control Person'
                                                                                                                ,@VerificationNoteID = NULL
                                                                                                                ,@IsVerified = 1
                                                                                                                ,@IsActive = @SDMIsActive
                                                                                                                ,@PartyRole = 'Person'
                                                                                                                ,@AutoRisk = NULL
                                                                                                                ,@EDDRisk = NULL
                                                                                                                ,@CompositeRisk = NULL
                                                                                                                ,@DateCreated = @now
                                                                                                                ,@IsDeleted = 0


                                                                                                /************Insert MDEmployee to ADM_AppEmployee**********/
                                                                                                EXEC [KYP].[p_InsertADMAppEmployee] @PartyID = @PDM_EmployeePartyId
                                                                                                                ,@ApplicationID = @PDM_ApplicationID
                                                                                                                ,@DateCreated = @now

                                                                                                /*****Nullify all Employee Fields for next iteration*******/
                                                                                                SELECT @P_EMPL_LAST_NAM = NULL
                                                                                                                ,@P_EMPL_FST_NAM = NULL
                                                                                                                ,@P_EMPL_MI_NAM = NULL
                                                                                                                ,@P_EMPL_TITL_NAM = NULL
                                                                                                                ,@P_EMPL_SSN = NULL
                                                                                                                ,@P_EMPL_DOB_DT = NULL
                                                                                                                ,@P_EMPL_LINE1_AD = NULL
                                                                                                                ,@P_EMPL_LINE2_AD = NULL
                                                                                                                ,@P_EMPL_CITY_NAM = NULL
                                                                                                                ,@P_EMPL_ST_CD = NULL
                                                                                                                ,@P_EMPL_ZIP5_CD = NULL
                                                                                                                ,@P_EMPL_ZIP4_CD = NULL

                                                                                                SELECT @CurrentEmployee = MIN(ID)
                                                                                                FROM dbo.ProviderEmployee
                                                                                                WHERE p_id = @ProviderOrApplicationNbr
                                                                                                                AND ID > @CurrentEmployee
                                                                                END --End While loop for MD Employees
                                                                END --End of MD Employee processing block

                                                                /******* START : CHECK MOCA After ********/
                                                                SELECT * INTO #AfterMOCA FROM 
                                                                   (SELECT PartyID FROM KYP.SDM_ApplicationParty 
                                                                       WHERE ApplicationID = @PDM_ApplicationID AND IsActive = 1) AS X 
                                                                SELECT @MOCA_COUNT = COUNT(1) FROM (SELECT * FROM #AfterMOCA EXCEPT SELECT * FROM #BeforeMOCA) AS X

                                                                IF @MOCA_COUNT > 0
                                                                BEGIN
                                                                    UPDATE KYP.ADM_Case SET RtpRescreenFlag = 'AutoScreen' WHERE CaseID = @PDM_CaseID
                                                                    SET @MOCA_COUNT = 0
                                                                END
                                                                ELSE IF @Resubmitted = 1
                                                                BEGIN
                                                                    UPDATE KYP.ADM_Case
                                                                    SET MILESTONE = 'Re-Submitted'                                                                                         
                                                                    WHERE CaseID = @PDM_CaseID
                                                                END
                                                                /******* END  : CHECK MOCA After *********/

                                                END --End Of Screening processing record
                                                
                                                
                                                declare @t2 table (SortID int IDENTITY(1,1),AppPartyID int,ApplicationID int,ScreeningID int,PartyID int,PartyType varchar(50),VerificationNoteID int,IsVerified bit null,
												IsActive bit null,PartyRole varchar(25),AutoRisk int,EDDRisk int,CompositeRisk int,CreatedBy int,DateCreated smalldatetime,ModifiedBy int,DateModified smalldatetime,
												DeletedBy int,DateDeleted smalldatetime,IsDeleted bit null, MatchCriteria varchar(20),OIGLEIEPartyID varchar (2000), EPLSPartyID varchar(2000), NormalizedRisk int, 
												IsVisisted bit null,TypeOfParty varchar(50), Tag varchar(50))
												INSERT INTO @t2
												Select S.* 
												from KYP.PDM_Party P INNER JOIN KYP.SDM_ApplicationParty S
												ON P.PartyID = S.PartyID AND S.IsDeleted = 0
												WHERE S.ApplicationID = @PDM_ApplicationID Order by P.Name

                                                UPDATE t1 SET t1.VerificationNoteID = t2.SortID 
  												FROM KYP.SDM_ApplicationParty t1 INNER JOIN 
												@t2 t2 ON t1.ApplicationID = t2.ApplicationID 
												AND t1.PartyID = t2.PartyID 
												WHERE t1.IsDeleted = 0 AND t1.ApplicationId = @PDM_ApplicationID
												
            
                                                --change exported=1 in pADM_Application table
                                                update kypportal.portalkyp.pADM_Application set exported=1 where ApplicationNo=@ProviderOrApplicationNbr
                        --delete only applicationno exported             
                                                delete from kypportal.PortalKYP.ProviderStagingFull_Portal where [Column 1]=@ProviderOrApplicationNbr 
                                                
                                                --Added by Pullaiah on 13-Feb-2018 for KEN-13234 
                                                Update T1
                                                Set T1.SpecPharmacy = T3.Value
                                                From kyp.ADM_Case T1
                                                Join KYPPORTAL.PortalKYP.pADM_Application T2 on T1.Number = T2.ApplicationNo
                                                Join KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie T3 on T2.PartyID = T3.PartyID
                                                Where T3.Name = 'specialty'
                                                
                                                --Added by Pullaiah on 13-Feb-2018 for KEN-13234 
                                                
                                                /**********Adding Condition for application history*****/
                                
                                IF (@P_TY_CD = '015' OR @P_TY_CD = '016' OR  @P_TY_CD = '051' OR @P_TY_CD = '076' OR 
                                     @P_TY_CD = '038' OR @P_TY_CD = '030' )
									BEGIN
										Declare  @ApplicationNumber varchar(10)
										set @ApplicationNumber = (select applicationnumber from kypenrollment.padm_account where accountnumber=@Account_No)
										
										If object_id('tempdb.dbo.#TempTable') is not null
											Drop table #TempTable
										
										select IDENTITY(int, 1, 1) as ID,AccountNumber INTO #TempTable from kypenrollment.padm_account where applicationnumber=@ApplicationNumber
				                        DECLARE @LoopCounter INT = 1
				                        WHILE ( @LoopCounter < 3)
											BEGIN
											    Declare @AccountNumberTrans varchar(15)
											    Set @AccountNumberTrans = (Select AccountNumber from #TempTable where ID =@LoopCounter)
												--Added Modified Date for Elk Implementation on 27-Feb-2019
												insert into kypenrollment.ApplicationHistory(AccountNumber,ApplicationNumber,CreatedDate,ModifiedDate)
												values (@AccountNumberTrans,@P_ID,GETDATE(),GETDATE())
												SET @LoopCounter  = @LoopCounter  + 1
											END
									END
								ELSE
									BEGIN
										--Added Modified Date for Elk Implementation on 27-Feb-2019
										Insert into kypenrollment.ApplicationHistory(AccountNumber,applicationnumber,CreatedDate,ModifiedDate)
										values (@Account_No,@P_ID,GETDATE(),GETDATE())	
									END
				/**********Adding Condition for application history*****/
							                                                
									--Added the below Update statement by Sundar on 28Mar2019 for KEN-21068
									Update T1
									Set T1.ServiceAddress = Isnull(T2.AddressLine1+', ','')+Isnull(T2.AddressLine2+', ','')+Isnull(T2.City+', ','')+ISNULL(T2.StateCode+', ','')+ISNULL(T2.ZipPlus4+', ','')+ISNULL(T2.County,'')
									From kyp.Adm_Case t1
									Join kyp.View_AllAddresses t2 on t1.Number = t2.ApplicationNo
									Where t1.CaseID = @PDM_CaseID
									and T2.Type = 'Servicing';
													
                                                COMMIT TRAN ProcessProvider
                                                
                                                
                                END TRY

                                BEGIN CATCH
                                                DECLARE @errMsg VARCHAR(500)
                                                                ,@errLine VARCHAR(50)

                                                SELECT @errLine = ERROR_LINE()
                                                                ,@errMsg = ERROR_MESSAGE();

                                                IF @@TRANCOUNT > 0
                                                BEGIN
                                                                ROLLBACK TRAN ProcessProvider

                                                                INSERT INTO [dbo].[ErroredProvidersForTheDay] (
                                                                                [ID]
                                                                                ,[FileType]
                                                                                ,[P_ID]
                                                                                ,[ERNumber]
                                                                                ,[Error_Severity]
                                                                                ,[Error_State]
                                                                                ,[Error_Procedure]
                                                                                ,[Error_Line]
                                                                                ,[Error_Message]
                                                                                )
                                                                SELECT A.ID
                                                                                ,A.FileType
                                                                                ,P_ID
                                                                                ,B.ERNumber
                                                                                ,B.Error_Severity
                                                                                ,B.Error_State
                                                                                ,B.Error_Procedure
                                                                                ,B.Error_Line
                                                                                ,B.Error_Message
                                                                FROM (
                                                                                SELECT ID
                                                                                                ,FileType
                                                                                                ,P_ID
                                                                                FROM dbo.ProvidersForTheDay
                                                                                WHERE ID = @CurrentProvider
                                                                                ) A
                                                                CROSS JOIN (
                                                                                SELECT ERROR_NUMBER() ERNumber
                                                                                                ,ERROR_SEVERITY() Error_Severity
                                                                                                ,ERROR_STATE() Error_State
                                                                                                ,ERROR_PROCEDURE() Error_Procedure
                                                                                                ,ERROR_LINE() Error_Line
                                                                                                ,ERROR_MESSAGE() Error_Message
                                                                                ) B
                                                END
                                END CATCH

                                /**********Nullify all the variables except provider looping 
***********variables for next processing Below*****/
                                SELECT @PDM_PartyId = NULL
                                                ,@PDM_ProviderID = NULL
                                                ,@PDM_LocationID = NULL
                                                ,@PDM_AddressID = NULL
                                                ,@intAddressExists = NULL

                                SELECT @PDM_ProviderPartyId = NULL
                                                ,@PartyType = NULL
                                                ,@ADMCaseNumber = NULL
                                                ,@PDM_CaseID = NULL
                                                ,@PDM_ApplicationID = NULL
                                                ,@ADM_App_AddressID = NULL
                                                ,@ProviderPartyName = NULL
                                                ,@ProviderCLIANBR = NULL
                                                ,@ProviderTypeDescription = NULL
                                                ,@RiskCategoryCode = NULL
                                                ,@intScreenChkLoop = NULL
                                                ,@intScreeningChecklistID = NULL
                                                ,@ADMCaseType = NULL

                                SELECT @FirstLicense = NULL
                                                ,@CurrentLicense = NULL
                                                ,@LastLicense = NULL
                                                ,@PDM_LicenseID = NULL

                                SELECT @FirstSecondaryNPI = NULL
                                                ,@CurrentSecondaryNPI = NULL
                                                ,@LastSecondaryNPI = NULL
                                                ,@PDM_SecondaryNPI = NULL

                                SELECT @FirstMedicare = NULL
                                                ,@CurrentMedicare = NULL
                                                ,@LastMedicare = NULL
                                                ,@PDM_MCARE_ID = NULL

                                SELECT @FirstCLIA = NULL
                                                ,@CurrentCLIA = NULL
                                                ,@LastCLIA = NULL
                                                ,@PDM_CLIA_ID = NULL

                                SELECT @FirstSpeciality = NULL
                                                ,@CurrentSpeciality = NULL
                                                ,@LastSpeciality = NULL
                                                ,@PDM_SpecialityID = NULL
                                                ,@MinSpecialtyID = NULL
                                                ,@PrimarySpecialtyCode = NULL
                                                ,@PrimarySpecialtyDescription = NULL

                                SELECT @FirstIndOwner = NULL
                                                ,@LastIndOwner = NULL
                                                ,@CurrentIndOwner = NULL
                                                ,@PDM_OwnerPartyId = NULL
                                                ,@PDM_OwnerID = NULL

                                SELECT @FirstOrgOwner = NULL
                                                ,@LastOrgOwner = NULL
                                                ,@CurrentOrgOwner = NULL

                                SELECT @FirstEmployee = NULL
                                                ,@CurrentEmployee = NULL
                                                ,@LastEmployee = NULL
                                                ,@PDM_EmployeePartyId = NULL
                                                ,@PDM_EmployeeID = NULL

                                SELECT @FileIndicator = NULL
                                                ,@ProviderOrApplicationNbr = NULL
                                                ,@ProviderType = NULL

                                SELECT @FileType = NULL
                                                ,@P_APPL_NUM = NULL
                                                ,@P_ID = NULL
                                                ,@P_NPI_NUM = NULL
                                                ,@P_DEA_NUM = NULL
                                                ,@P_TY_CD = NULL
                                                ,@P_PRACT_TY_CD = NULL
                                                ,@P_DOB_DT = NULL
                                                ,@P_FED_TAX_ID = NULL
                                                ,@P_SSN_NUM = NULL
                                                ,@P_LAST_NAM = NULL
                                                ,@P_FST_NAM = NULL
                                                ,@P_MI_NAM = NULL
                                                ,@P_SFX_NAM = NULL
                                                ,@P_NAM = NULL
                                                ,@P_DBA_LAST_NAM = NULL
                                                ,@P_DBA_FST_NAM = NULL
                                                ,@P_DBA_MI_NAM = NULL
                                                ,@P_DBA_SFX_NAM = NULL
                                                ,@P_DBA_NAM = NULL
                                                ,@P_LINE1_AD = NULL
                                                ,@P_LINE2_AD = NULL
                                                ,@P_CITY_NAM = NULL
                                                ,@P_ST_CD = NULL
                                                ,@P_ZIP5_CD = NULL
                                                ,@P_ZIP4_CD = NULL
                                                ,@P_NABP_NUM = NULL

                                SELECT @P_LIC_CERT_NUM = NULL
                                                ,@P_LIC_ST_CD = NULL
                                                ,@P_LIC_BRD_NUM = NULL

                                SELECT @P_ALT_ID = NULL

                                SELECT @P_MCARE_NUM = NULL

                                SELECT @P_CLIA_NUM = NULL

                                SELECT @P_OWNER_LAST_NAM = NULL
                                                ,@P_OWNER_FST_NAM = NULL
                                                ,@P_OWNER_MI_NAM = NULL
                                                ,@P_OWNER_TITL_NAM = NULL
                                                ,@P_OWNER_DOB_DT = NULL
                                                ,@P_OWNER_SSN_NUM = NULL
                                                ,@P_OWNER_LINE1_AD = NULL
                                                ,@P_OWNER_LINE2_AD = NULL
                                                ,@P_OWNER_CITY_NAM = NULL
                                                ,@P_OWNER_ST_CD = NULL
                                                ,@P_OWNER_ZIP5_CD = NULL
                                                ,@P_OWNER_ZIP4_CD = NULL

                                SELECT @P_OWNER_BUSN_NAM = NULL
                                                ,@P_OWNER_DBA_NAM = NULL
                                                ,@P_OWNER_TAX_ID = NULL
                                                ,@P_BUSN_LINE1_AD = NULL
                                                ,@P_BUSN_LINE2_AD = NULL
                                                ,@P_BUSN_CITY_NAM = NULL
                                                ,@P_BUSN_ST_CD = NULL
                                                ,@P_BUSN_ZIP5_CD = NULL
                                                ,@P_BUSN_ZIP4_CD = NULL

                                SELECT @P_EMPL_LAST_NAM = NULL
                                                ,@P_EMPL_FST_NAM = NULL
                                                ,@P_EMPL_MI_NAM = NULL
                                                ,@P_EMPL_TITL_NAM = NULL
                                                ,@P_EMPL_SSN = NULL
                                                ,@P_EMPL_DOB_DT = NULL
                                                ,@P_EMPL_LINE1_AD = NULL
                                                ,@P_EMPL_LINE2_AD = NULL
                                                ,@P_EMPL_CITY_NAM = NULL
                                                ,@P_EMPL_ST_CD = NULL
                                                ,@P_EMPL_ZIP5_CD = NULL
                                                ,@P_EMPL_ZIP4_CD = NULL

                                SELECT @P_FULL_NAM = NULL
                                                ,@P_DBA_FULL_NAM = NULL
                                                ,@P_OWNER_FULL_NAM = NULL
                                                ,@P_EMPL_FULL_NAM = NULL

                                SELECT @now = NULL
                                                ,@LoadType = NULL
                                                ,@LoadID = NULL
                                                ,@LastLoadDate = NULL

                                SELECT @Category = NULL

                                /*,@intNPI = NULL*/
                                SELECT @CurrentProvider = MIN(ID)
                                FROM dbo.ProvidersForTheDay
                                WHERE ID > @CurrentProvider
                END
                                                /********End Processing of Current Provider******/
				If object_id('tempdb.dbo.#TempTable') is not null
					Drop table #TempTable

END


GO

