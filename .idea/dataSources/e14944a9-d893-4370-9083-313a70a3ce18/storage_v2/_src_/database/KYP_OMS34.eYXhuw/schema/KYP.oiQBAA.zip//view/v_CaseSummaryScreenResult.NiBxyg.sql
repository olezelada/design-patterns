

CREATE VIEW [KYP].[v_CaseSummaryScreenResult] AS

Select CONVERT(VARCHAR(20),C.CaseID)As CaseID,C.Number ApplicationNumber,C.AccountNo AccountNumber,M.Name, M.SSN, M.TIN,M.Type,M.Associations,M.EffectiveDate 
		,M.ScreenedOn
from KYPPortal.portalkyp.padm_application A
Join KYPPortal.PortalKYP.pProfile P on A.profile_id = P.profile_id
Join kyp.ADM_Case C on A.ApplicationNo = C.Number
Join KYPEnrollment.TaxIDProfile T on P.EnrollmentProfileId = T.profileID and C.Provider_TIN = T.taxID
Join (Select pa.AccountID
			,pa.PartyID
			,isnull(pe.LastName, '') + ' ' + isnull(pe.FirstName, '') + ' ' + isnull(pe.MiddleName, '') NAME
			,'Individual' Type
			,'' TIN
			,pe.SSN
			,(
				CASE owr.PercentCheck
					WHEN 1
						THEN 'Ownership Interest; '
					ELSE ''
					END
				) + (
				CASE owr.[Partner]
					WHEN 1
						THEN 'Partner; '
					ELSE ''
					END
				) + (
				CASE owr.Managing
					WHEN 1
						THEN 'Managing Employee; '
					ELSE ''
					END
				) + (
				CASE owr.Agent
					WHEN 1
						THEN 'Agent; '
					ELSE ''
					END
				) + (
				CASE owr.Director
					WHEN 1
						THEN 'Director/Officer; '
					ELSE ''
					END
				) + (
				CASE owr.Other
					WHEN 1
						THEN 'Other; '
					ELSE ''
					END
				) AS Associations
			,convert(VARCHAR, owr.OtherDate, 101) AS EffectiveDate
			,pa.TaxIDprofileID
			,Convert(varchar(10),Pa.ScreenedOn,101) as ScreenedOn			
		FROM KYPEnrollment.pAccount_PDM_Party pa
		JOIN KYPEnrollment.pAccount_PDM_Person pe ON pe.PartyID = pa.PartyID
		JOIN KYPEnrollment.pAccount_PDM_Owner_Role owr ON pa.PartyID = owr.PartyID
		WHERE pa.[Type] = 'Individual Ownership'
			AND pa.CurrentRecordFlag = 1
		Union
		Select pa.AccountID
				,pa.PartyID
				,org.LegalName
				,'Organizational'
				,org.EIN
				,''
				,(
					CASE owr.PercentCheck
						WHEN 1
							THEN 'Ownership Interest; '
						ELSE ''
						END
					) + (
					CASE owr.[Partner]
						WHEN 1
							THEN 'Partner; '
						ELSE ''
						END
					) + (
					CASE owr.Managing
						WHEN 1
							THEN 'Managing Employee; '
						ELSE ''
						END
					) + (
					CASE owr.Agent
						WHEN 1
							THEN 'Agent; '
						ELSE ''
						END
					) + (
					CASE owr.Director
						WHEN 1
							THEN 'Director/Officer; '
						ELSE ''
						END
					) + (
					CASE owr.Other
						WHEN 1
							THEN 'Other; '
						ELSE ''
						END
					) AS Associations
				,convert(VARCHAR, owr.OtherDate, 101) AS EffectiveDate
				,pa.TaxIDprofileID
				,Convert(varchar(10),Pa.ScreenedOn,101) as ScreenedOn				
		FROM KYPEnrollment.pAccount_PDM_Party pa 
		JOIN KYPEnrollment.pAccount_PDM_Organization org ON org.PartyID = pa.PartyID
		JOIN KYPEnrollment.pAccount_PDM_Owner_Role owr ON pa.PartyID = owr.PartyID
		WHERE pa.[Type] = 'Entity Ownership'
			AND pa.CurrentRecordFlag = 1) M ON M.TaxIDprofileID = T.taxIDprofileID


GO

