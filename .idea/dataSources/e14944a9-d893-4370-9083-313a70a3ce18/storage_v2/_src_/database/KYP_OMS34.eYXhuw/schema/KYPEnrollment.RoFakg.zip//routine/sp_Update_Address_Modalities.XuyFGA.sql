

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Address_Modalities]
                                      @party_account_id INT,
                                      @party_app_id INT,
                                       @LastActionUserID   VARCHAR(100),
                                       @provider_type_code VARCHAR(50)
AS
BEGIN

 DECLARE @partys_id TABLE(pk INT IDENTITY (1, 1), PartID INT);
 DECLARE @tot INT,@cont INT,@party_m INT,@address INT,@location INT;

 INSERT INTO @partys_id (PartID)
 SELECT p.PartyID
 FROM KYPEnrollment.pAccount_PDM_Party p
 WHERE  p.ParentPartyID=@party_account_id and p.IsDeleted=0 and p.Type='Modality'

 SELECT @tot = MAX(pk)  FROM @partys_id;
 SET @cont = 1;
 WHILE @cont <= @tot
  BEGIN
  SELECT @party_m=PartID FROM @partys_id  WHERE pk = @cont

  UPDATE [KYPEnrollment].[pAccount_PDM_Modalities] SET CurrentRecordFlag = 0, Deleted=1 WHERE PartyId = @party_m;
  UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET CurrentRecordFlag = 0,IsDeleted=1 WHERE PartyID = @party_m;

  select @location= l.LocationID , @address = ad.AddressID
  from KYPEnrollment.pAccount_PDM_Location l INNER JOIN KYPEnrollment.pAccount_PDM_Address ad
  ON ad.AddressID=l.AddressID where l.Type='modResAddress' AND l.PartyID=@party_m

  update KYPEnrollment.pAccount_PDM_Location set IsDeleted=1, CurrentRecordFlag=0 where LocationID=@location;
  update KYPEnrollment.pAccount_PDM_Address set CurrentRecordFlag=0 where AddressID=@address;

  SET @cont = @cont + 1;
  END

  EXEC [KYPEnrollment].[sp_Copy_Modalities] @party_account_id,@party_app_id,@LastActionUserID, @provider_type_code;


END


GO

