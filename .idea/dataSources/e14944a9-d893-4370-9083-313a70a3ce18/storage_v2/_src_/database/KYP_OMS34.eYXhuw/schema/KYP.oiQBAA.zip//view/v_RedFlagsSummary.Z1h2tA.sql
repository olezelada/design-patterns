


CREATE VIEW [KYP].[v_RedFlagsSummary]
AS
SELECT     row_number() OVER (ORDER BY Q.ScreeningID ASC) AS ID, *
FROM         
(
	SELECT 
	ROW_NUMBER() OVER (PARTITION BY A.ScreeningID, B.Attribute ORDER BY A.FlagID) AS SubRowNumber,
	A.ScreeningID,
	A.FlagID,
	B.FlagType,
	B.Attribute,
	B.DisplayName,
	B.ToolTipText,
	B.Description,
	C.AttributeValue
	FROM KYP.SDM_RedFlag A
	INNER JOIN KYP.SDM_RedFlagDetails C ON A.RedFlagID = C.RedFlagID
	INNER JOIN KYP.LK_RedFlagConfiguration B ON A.FlagID = B.FlagID
	WHERE ISNULL(A.IsDeleted, 0) = 0 AND ISNULL(C.IsDeleted, 0) = 0
) Q


GO

