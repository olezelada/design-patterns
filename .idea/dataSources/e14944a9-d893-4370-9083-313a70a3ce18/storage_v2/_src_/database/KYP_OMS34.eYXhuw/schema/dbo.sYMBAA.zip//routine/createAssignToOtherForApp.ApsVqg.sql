


-- =============================================
-- Author:		<Shamim Ansari>
-- Create date: <14/06/2013>
-- Description:	<KYP-1182 and KYP-1184 >  
-- Update: 		<Lperez>
-- Update date: <7/02/2015>
-- =============================================
CREATE PROCEDURE [dbo].[createAssignToOtherForApp] 
--Variable Declaration
	@MultipleCaseID varchar(MAX),
	@JournalEvent varchar(50),
	@Username varchar(25),
	@AssignToUserID int,
	@RelatedEntityType varchar(50),
	@NotesDescription varchar(max),
	@NotesTitle varchar(120),
	@Number varchar(20),
	@Currenttag varchar(5),
	@Type varchar(100),
	@SubType varchar(100)
	
	/*START - Changes for http://jira/browse/KYP-2988 */
    ,@CurrentWFStatus varchar(50)    
    /*END - Changes for http://jira/browse/KYP-2988 */
    
    ,@FormattedContent varchar(max) /* KYP 3.4 - SCREEN 16 */
    
AS
BEGIN
     Declare 
    @AlertID int,
    /*START - Changes for http://jira/browse/KYP-2988 */
    --@AppNumber int,
    @AppNumber VARCHAR(15),
    --@CurrentWFStatus varchar(50),
    /*END - Changes for http://jira/browse/KYP-2988 */
    @Description varchar(500),
    @PersonID int,
    @FirstName varchar(25),
    @LastName varchar(25),
    @Name varchar(100),
    @CurrentDate datetime,
    @JournalDescription varchar(250),
    @FullName varchar(200),
    @index int,
    @sliceOfStringValue varchar(2000),
    @StringValue varchar(max), 
    @Delimiter char(1),
    @TempCaseID varchar(100),
    
 
    @NoteID int,
    @Notenumber varchar(15),
    @NoteEntityType varchar(100),
    @NoteEntityTypeID varchar(100),
    @NoteEntityDepID varchar(100),
    @NoteEntityDep varchar(100),
    @Level int,
    @SmartletParameter varchar(500),
    @IsLastLevel bit,
    @RelatedEntityID int,
    @CaseID int,
    @IsExistID int,
    @NoteCount int
    
    /*START - Changes for http://jira/browse/KYP-2988 */
    ,
    @body NVARCHAR(MAX),
	@EmailAddTo VARCHAR(500),		
	@EmailAddCC VARCHAR(500),
	@Sub VARCHAR(MAX),
		
	@ProviderType VARCHAR(30),
    @CMSRiskLevel VARCHAR(10),
    @RiskScore INT,
    @StateCode VARCHAR(2),
    @TrackingTitle VARCHAR(10),
    @ALIASNAME VARCHAR(100),
    @MultipleTrackingNo varchar(50),
    @PInID int
	/*END - Changes for http://jira/browse/KYP-2988 */
   
    Select @PersonID=PersonID from KYP.OIS_User where UserID=@Username
    Select @FullName=FullName from KYP.OIS_User where PersonID=@AssignToUserID
    --Select @FullName=FullName from KYP.OIS_Person where PersonID=@PersonID
    Select @FirstName=FirstName from KYP.OIS_Person where PersonID=@PersonID
    Select @LastName=LastName from KYP.OIS_Person where PersonID=@PersonID
    Select @Name= @LastName +  COALESCE((', ' + @FirstName), '') 
    Select @CaseID =Null	
    Select @CurrentDate=getdate()
    
    
    Select @Description='Application acknowledged by'+' '+ @Name 
    --Set @Description ='Test'
 
    select @StringValue=@MultipleCaseID
    select @Delimiter=','
    Select @IsExistID=0
    select @NoteCount=0
   SELECT TOP 1 @ALIASNAME = KYPALIAS FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
      IF (@ALIASNAME IS NULL OR @ALIASNAME = '')
    BEGIN
		SET @ALIASNAME = 'KYP';
    END 
      
      Select @index = 1    
            --if len(@StringValue)<1 or @StringValue is null  return    
    
      while @index!= 0    
      begin    
            Select @index = charindex(@Delimiter,@StringValue)    
            
            if @index!=0 
            begin   
                  Select @sliceOfStringValue = left(@StringValue,@index - 1) 
                  --select left(@StringValue,@index - 1)   
            end      
            else    
				begin
                  Select @sliceOfStringValue = @StringValue   
                end 
           
            if(len(@sliceOfStringValue)>0)
              --select @sliceOfStringValue  
              begin
				--Taking the CaseID one by one  
				Select @TempCaseID=@sliceOfStringValue
				Select @StringValue = right(@StringValue,len(@StringValue) - @index)   
              end
             
            if len(@StringValue) = 0
            begin
             break    
            end
      
  Select @AppNumber=Number from KYP.ADM_Case where CaseID=@sliceOfStringValue
            
        
        --Temp code will be puutted here
        
 
/**********************************************************************************************************/
-- START : KYP-2988 - Assigning the application to any user should be notified via an e-mail. - 10-Sep-2013
/**********************************************************************************************************/
	SELECT @StateCode = StateCode FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
	
   IF(@CurrentWFStatus = 'Assign To Other')
       BEGIN 
			SELECT @ProviderType = TypeDescription FROM KYP.ADM_Case WHERE CaseID = @sliceOfStringValue
			SELECT @CMSRiskLevel = Risk FROM KYP.ADM_Case WHERE CaseID = @sliceOfStringValue
			SELECT @RiskScore = CompositeRisk FROM KYP.ADM_Application WHERE CaseID = @sliceOfStringValue
			
			IF @StateCode = 'NM'
			BEGIN
				SET @TrackingTitle = 'Provider#'
			END
			ELSE
			BEGIN
				SET @TrackingTitle = 'Tracking#'
			END
		   SET @Sub = @TrackingTitle + ' ' + CONVERT(VARCHAR,@AppNumber) + ' has been assigned to you in ' + @ALIASNAME + ' by ' 
					  + (SELECT FullName FROM KYP.OIS_User WHERE UserID = @Username);
		
		   SET @body = '<html>
							<body>
							<table border="1" cellpadding = 5 cellspacing = "">
							  <tr>
								<td><b>	<font face="Cambria" size="2">'+ @TrackingTitle + ':</font></b></td>
								<td><font face="Cambria" size="2">'+ CONVERT(VARCHAR,@AppNumber) + '</font></td>
							  </tr>
							  <tr>
								<td><b>	<font face="Cambria" size="2">Provider Type:</font></b></td>
								<td><font face="Cambria" size="2">'+ @ProviderType +'</font></td>
							  </tr>							  
							  <tr>
								<td><b>	<font face="Cambria" size="2">Risk:</font></b></td>
								<td><font face="Cambria" size="2">'+ ISNULL(@CMSRiskLevel,'') +'</font></td>
							  </tr>	
							   <tr>
								<td><b>	<font face="Cambria" size="2">Risk Score:</font></b></td>
								<td><font face="Cambria" size="2">'+ CONVERT(VARCHAR,@RiskScore) +'</font></td>
							  </tr>							  	
							</table>
							<br>
							<br><font face="Cambria" size="2">This is a system generated message. Please do not reply.</font>
							</body>
						</html>'
			   SET @EmailAddTo = (SELECT EmailID FROM KYP.OIS_User WHERE PersonID = @AssignToUserID)			   
		       
		       -- IF No Email ID
		       IF @EmailAddTo <> '' and @EmailAddTo is not null
		       BEGIN		       		       		       
				EXEC msdb.dbo.sp_send_dbmail
					@profile_name = 'administrator', -- replace with your SQL Database Mail Profile 
					@body = @body,
					@body_format ='HTML',		
					@recipients = @EmailAddTo,					
					@subject = @Sub;
			   END
		END		
 /***********************************************************************************************/
-- END : KYP-2988 - Assigning the application to any user should be notified via an e-mail. 28-Aug-2013
/***********************************************************************************************/
 
 IF (@FormattedContent IS NULL)		/* KYP 3.4 - SCREEN 16 */
 BEGIN
		SET @FormattedContent = @NotesDescription
 END
   
 exec @NoteID = [KYP].[p_InsertOISNote]	
 @UserID=@Username,@Name=@NotesTitle,@Type=@Type,@SubType=@SubType,
 @ParentID=0, @DateCreated = @CurrentDate, @Author=@Name,@RelatedEntityType =@RelatedEntityType,
 @Content= @FormattedContent, @UnformattedContent=@NotesDescription , @Number=@Number , 
 @VersionNo =1, @isWorkpaper=0, @isAcknowledged=0 , @WorkflowName=NULL, @isAdverse=0,
 @Deleted=0, @DeletedOn=NULL, @DeletedBy=NULL , @DeletedByUserID=NULL , @UpdatedOn=NULL,
 @UpdatedBy =NULL, @UpdatedByUserID=NULL , @IsImportant=0 , @IsLastVersion=1 , @IsSticky=0 ,
 @IsReferenced=0 , @HasComments=0 , @HasDocuments=0 , @NumberSchemaInfo=@Number , @LastVersion =1,
 @AllowComments =0, @RestoredBy=NULL , @RestoredByUserID=NULL , @CaseID=NULL , @AlertID =NULL,
 @IncidentID =NULL, @Tags =NULL, @FullDateCreated=NULL , @RelatedEntityID=@RelatedEntityID , @Importance='Low',
 @Score =0, @DMSID =NULL, @DocumentCount=NULL ,@MultipleCaseID=NULL,@MultipleTrackingNo=NULL,@PInID=NULL 
   
   
           
     /* if @Currenttag is null
      begin
          INSERT INTO [KYP].[OIS_Tag]
           ([Tag])
          VALUES
           (',')
      end*/
      
           INSERT INTO [KYP].[OIS_JT_NoteTag]
           ([NoteID]
           ,[Tag])
      VALUES
           (@NoteID
           ,',')
           
           
    --Get the notenumber------
    
    exec [KYP].[p_GenerateNoteNumber] @NoteID,
    @Notenumber=@Notenumber output
    
    /******* Updating note number in OIS_Note***********/ 
    update KYP.OIS_Note set Number= @Notenumber where NoteID= @NoteID
    
    --/*Updating the CaseID in OIS_Note Entity for KYP-1182 and KYP-1184*/
    
    update KYP.OIS_Note set CaseID=@TempCaseID where NoteID=@NoteID
    /********Creating Journal entry********************/
    
   Select  @JournalDescription='Notes Added-'+' '+@Type+' '+@Notenumber+' '+'was added to'+' '+@RelatedEntityType
    
    INSERT INTO [KYP].[OIS_Journal]
           ([UserID],[ACTIONID],[Date_x],[DESCRIPTION],[EntityTable],[Entity],[EntityID],[CaseID]
           ,[ShortDescription])
     VALUES
           (@Username,1,@CurrentDate,@JournalDescription,'OIS_Note','Note',@NoteID,@CaseID
           ,@JournalDescription)
           
  /**********Segregate the smartlet parameter for noteentity entry************/  
    
    Select @SmartletParameter='ADM_Case-'+convert(varchar(10),@sliceOfStringValue)
    
 
    select 
    @NoteEntityType =NoteEntityType,
    @NoteEntityTypeID =NoteEntityTypeID,
    @NoteEntityDepID =NoteEntityDepID,
    @NoteEntityDep= NoteEntityDep,
    @Level =Level,
    @IsLastLevel=IsLastLevel
    from  simple_intlist_to_tbl(@SmartletParameter)       
     
     
     /********Insert into Noteentity*************/
     INSERT INTO [KYP].[NoteEntity]
           ([NoteNumber]
           ,[NoteEntityType]
           ,[NoteEntityDep]
           ,[NoteEntityTypeID]
           ,[NoteEntityDepID]
           ,[Level]
           ,[IsLastLevel])
    
           select @Notenumber
           ,NoteEntityType
           ,NoteEntityDep
           ,NoteEntityTypeID
           ,NoteEntityDepID
           ,Level
           ,IsLastLevel from  simple_intlist_to_tbl(@SmartletParameter)  
       
     
           
      select @IsExistID= ParentID from  KYP.NoteCounts where ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
      
     
      
      
      Select @NoteCount=count(RelatedEntityID) from KYP.OIS_Note where RelatedEntityID=@RelatedEntityID 
      and RelatedEntityType=@RelatedEntityType and (Deleted is null or Deleted=0)
      
      if @IsExistID =0
      begin
     
      
       INSERT INTO [KYP].[NoteCounts]
           ([ParentID]
           ,[ParentTable]
           ,[Counts])
        VALUES
           (@RelatedEntityID,
           @RelatedEntityType,
           @NoteCount)
      end
      
      begin
       UPDATE [KYP].[NoteCounts]
        SET [ParentID] = @RelatedEntityID
      ,[ParentTable] = @RelatedEntityType
      ,[Counts] = @NoteCount
       WHERE ParentID = @RelatedEntityID 
      and ParentTable=@RelatedEntityType
       
      end --if @IsExistID*/
      
      
     Select @IsExistID=0
     select @NoteCount=0


   
   
           
END -- End WHILE	
END --End main


GO

