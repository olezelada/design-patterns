


CREATE procedure [KYP].[sp_UpdateApplnTypeAlias] @Number varchar(15)= NULL

as begin 

	Declare 
	@ApplnTypeAlias varchar(50),
	@ApplnType varchar(50),
	@StateCode varchar(5),
	@P_PRACT_TY_CD varchar(50),
	@ApplicationType varchar(50),
	@ApplicationCode varchar(20);
		select @StateCode = StateCode from KYP.OIS_App_Version
		select @ApplnType = ApplnType, @P_PRACT_TY_CD = P_PRACT_TY_CD from KYP.ADM_Case where Number = @Number;
		select @ApplicationCode = ApplicationCode,@ApplicationType = ApplicationType from KYPPortal.portalKYP.pADM_Application where ApplicationNo = @Number
		if (@StateCode='MD')
			Begin
				if(@P_PRACT_TY_CD='Other Healthcare Business' and @ApplnType = 'New Group')
					begin
						set @ApplnTypeAlias = 'Resource';
					end
				else if(@P_PRACT_TY_CD='Facility' and @ApplnType = 'New Group')
				begin
					if(@ApplicationCode = 'FAC_I_MDH')
						begin
							set @ApplnTypeAlias = 'Facility Inpatient';
						end
					else
						begin
							set @ApplnTypeAlias = 'Facility Outpatient';
						end
				end
				else if(@P_PRACT_TY_CD='Atypical' and @ApplnType = 'New')
					begin
						set @ApplnTypeAlias = 'Atypical Solo';
					end
				else if(@P_PRACT_TY_CD='Atypical' and @ApplnType = 'New Group')
					begin
						set @ApplnTypeAlias = 'Atypical Organization';
					end
				else
					begin
						set @ApplnTypeAlias = @ApplnType;
					end
			End
		else
			Begin
				if(@ApplicationType = 'Reactivate NMP Application')
					Begin
						set @ApplnTypeAlias = 'Reactivate NMP Application';
					End
				else if(@ApplicationType = 'Reactivate ORP Application')
					Begin
						set @ApplnTypeAlias = 'Reactivate ORP Application';
					End
				else if(@ApplicationType = 'New application/Change of ownership')
					Begin
						set @ApplnTypeAlias = 'New application/Change of ownership';
					End
				else if(@ApplicationType = 'Revalidation-Change of NPI')
					Begin
						set @ApplnTypeAlias = 'Revalidation-Change of NPI';
					End
				else
					Begin
						set @ApplnTypeAlias = @ApplnType;
					End			 
			End
		
	Update KYP.ADM_Case set ApplnTypeAlias = @ApplnTypeAlias where Number = @Number

end


GO

