


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[trg_MDM_AlertOnInsert] ON [KYP].[MDM_Alert]
AFTER INSERT
AS
BEGIN

   --**
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF (isnull(@Row_Updation_Source,'') in ( 'p_UpdateAlertage' ,'KYP.MDM_Alert') AND Update(Row_Updation_Source)) or not exists (select * from inserted)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	--**
	DECLARE @alertID INT
		,@UserID INT
		,@CurrentlyAssignedToID VARCHAR(50)
		,@MajorDisposition VARCHAR(50)
		,@DateInitiated SMALLDATETIME
		,@PartyName VARCHAR(100)
		,@AlertNumber VARCHAR(15)
		,@NoofDays INT
		,@Rangename VARCHAR(20)
		,@WatchlistName VARCHAR(100)
		,@Priority VARCHAR(15)
		,@DateResolved SMALLDATETIME
		,@DaysCurrentStatus INT
		,@StatuscodeNumber INT
		,@Statuscode VARCHAR(10)
		,@CurrentWFStatus VARCHAR(100)
		,@IsMerged VARCHAR(2);

	SELECT @alertID = AlertID
		,@UserID = AssignedToUserID
		,@MajorDisposition = CurrentMajorDisposition
		,@PartyName = WatchedPartyName
		,@AlertNumber = AlertNo
		,@WatchlistName = WatchlistName
		,@DateInitiated = DateInitiated
		,@Priority = Priority
		,@DateResolved = DateClosed
		,@CurrentWFStatus = WFStatus
		,@IsMerged = ISMERGED
		,@StatuscodeNumber = StatusCodeNumber
	FROM inserted

	SET @CurrentlyAssignedToID = (
			SELECT DISTINCT Top 1 UserID
			FROM KYP.OIS_User
			WHERE PersonID = @UserID
			)
	SET @NoofDays = ABS(DATEDIFF(d, @DateInitiated, GETDATE()))
	SET @Rangename = KYP.AuditDays(@DateInitiated)
	SET @DaysCurrentStatus = ABS(DATEDIFF(d, @DateResolved, GETDATE()))
	SET @Statuscode = (
			SELECT Top 1 Description
			FROM KYP.LK_Screening
			WHERE TypeID = 2
				AND SortOder = @StatuscodeNumber
			)

	IF NOT EXISTS (
			SELECT 1
			FROM [KYP].[MDM_DashBoardTable]
			WHERE AlertID = @alertID
			)
	BEGIN
		INSERT INTO [KYP].[MDM_DashBoardTable] (
			[AlertID]
			,[AgeByDays]
			,[Range]
			,[AlertType]
			,[CurrentlyAssignedToID]
			,[CurrentWFStatus]
			,[CurrentMajorDisposition]
			,[DateInitiated]
			,[DateResolved]
			,[PartyName]
			,[AlertNumber]
			,[Statuscode]
			,[StatuscodeNumber]
			,[Month]
			,[RiskRange]
			,[NPI]
			,[RiskScore]
			,[Priority]
			,[DaysCurrentStatus]
			,[IsMerged]
			)
		VALUES (
			@alertID
			,@NoofDays
			,@Rangename
			,@WatchlistName
			,@CurrentlyAssignedToID
			,@CurrentWFStatus
			,@MajorDisposition
			,@DateInitiated
			,@DateResolved
			,@PartyName
			,@AlertNumber
			,@Statuscode
			,@StatuscodeNumber
			,NULL
			,NULL
			,NULL
			,NULL
			,@Priority
			,@DaysCurrentStatus
			,@IsMerged
			)
	END
END


GO

