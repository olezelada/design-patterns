CREATE PROCEDURE [KYPEnrollment].[OutOfStateCrossoverPackageBufferProvider]

		@applicatioNo VARCHAR(50),
		@caseId INT

AS
	BEGIN
		SET NOCOUNT ON;
				INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber)
				VALUES ('015', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 150000000+@caseId))),
				('016', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 160000000+@caseId)))

	END


GO

