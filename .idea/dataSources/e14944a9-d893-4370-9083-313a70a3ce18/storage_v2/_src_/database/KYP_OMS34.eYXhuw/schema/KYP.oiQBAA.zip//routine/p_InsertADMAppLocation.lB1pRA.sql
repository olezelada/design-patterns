/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMAppLocation]
(@AddressID int
 ,@ApplicationID int
 ,@PersonID int =NULL
 ,@Type int = NULL
 ,@WorkingDays varchar(25)=NULL
 ,@WorkingHours varchar(25)=NULL
 ,@Phone1 varchar(15)=NULL
 ,@Phone2 varchar(15)=NULL
 ,@Fax varchar(15)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0

)
as begin 

INSERT INTO [KYP].[ADM_App_Location]
           ([AddressID]
           ,[ApplicationID]
           ,[PersonID]
           ,[Type]
           ,[WorkingDays]
           ,[WorkingHours]
           ,[Phone1]
           ,[Phone2]
           ,[Fax]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@AddressID
           ,@ApplicationID
           ,@PersonID
           ,@Type
           ,@WorkingDays
           ,@WorkingHours
           ,@Phone1
           ,@Phone2
           ,@Fax
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[ADM_App_Location]')

end


GO

