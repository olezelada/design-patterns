


CREATE VIEW [KYP].[V_RelAlerts]
AS
SELECT     row_number() OVER (ORDER BY KYP.MDM_Alert.AlertID ASC) AS ID, KYP.MDM_Alert.AlertID, KYP.MDM_Alert.AlertNo, KYP.MDM_Alert.MatchStatusIndicator, 
KYP.MDM_Alert.MatchPercent, KYP.MDM_Alert.WatchedPartyName, KYP.MDM_Alert.WatchlistName, KYP.MDM_Alert.DateInitiated, KYP.MDM_RelatedAlerts.RelationshipType, 
KYP.MDM_RelatedAlerts.ChildAlertID, KYP.MDM_RelatedAlerts.ParentAlertID, KYP.MDM_Alert.WFMinorDisposition AS 'CurrentWFMinorStatus', KYP.MDM_Alert.WatchedPartyID, 
KYP.MDM_Alert.WatchedPartyType, KYP.MDM_Alert.Priority
FROM         KYP.MDM_Alert INNER JOIN
                      KYP.MDM_RelatedAlerts ON KYP.MDM_Alert.AlertID = KYP.MDM_RelatedAlerts.ChildAlertID
WHERE     (ISNULL(KYP.MDM_RelatedAlerts.IsDeleted, 0) = 0)


GO

