
/* ==========================================================
-- Author:		<clopez>
-- PROCEDURE: Update tables that have new PartyId for each row.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User. 
-- @target_path : target path to Tracking.
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name : Table Name to contain field that will be update.  
-- @table_code : Type of Table.  
-- @stored_value : input Type that be Update.
-- @account_id : AccountID that will be update.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Table_SupervisingPhysician]
   @acc_party_id           INT,
   @action_taken           VARCHAR (50),
   @last_action_user_id    VARCHAR (100),
   @target_path            VARCHAR (200),
   @en_db_column           VARCHAR (100),
   @data                   VARCHAR (MAX),
   @acc_PK                 VARCHAR (100),
   @acc_PK_value           INT,
   @is_text_date           CHAR (1),
   @acc_table_name         VARCHAR (100),
   @table_code             VARCHAR (20),
   @stored_value           VARCHAR (MAX),
   @account_id             INT,
   @new_fields_values      VARCHAR (MAX) = NULL,
   @row_uuid               VARCHAR (100) = NULL
AS
BEGIN
  SET  NOCOUNT ON;
  DECLARE
    @app_party_row_id      INT,
    @type                  VARCHAR (50),
    @parent_party_id       INT;
  DECLARE
    @partyOwner   INT,
    @part         INT
  IF (@action_taken = 'Updated' OR (@target_path LIKE '%|%' AND @action_taken = 'Added'))
  BEGIN
      EXEC [KYPEnrollment].[sp_Update_Field]  @acc_table_name, @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date, @stored_value, @last_action_user_id, @action_taken;
  END
  ELSE
  BEGIN

    SELECT @app_party_row_id = PartyID, @type = Type, @parent_party_id = ParentPartyID
    FROM   [KYPPORTAL].[PortalKYP].[pPDM_Party]
    WHERE  TargetPath = @target_path;

    IF  ((@action_taken = 'Added') AND (@target_path NOT LIKE '%|%') AND
        (NOT EXISTS (
            SELECT FiledID
            FROM   #Control_Add_row
            WHERE  FiledID = @parent_party_id
            AND    NameTable = 'supervisingPhysTable')))
    BEGIN
        PRINT 'Copying rows from "supervisingPhysTable" App-PartyID:';
        PRINT @parent_party_id;

        EXEC [KYPEnrollment].[sp_Copy_Supervising_Physician] @account_id, @acc_party_id, @parent_party_id, @last_action_user_id;
        INSERT INTO #Control_Add_row (FiledID, NameTable) VALUES (@parent_party_id, 'supervisingPhysTable');

        PRINT 'End of copy table';
    END
    ELSE
    BEGIN
        IF (@action_taken = 'Deleted') AND (@data = 'Row Deleted') AND (@acc_table_name IS NOT NULL)
        BEGIN
            EXECUTE ( 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + ' = ' + @acc_PK_value);
        END
        ELSE
        BEGIN
            EXEC [KYPEnrollment].[sp_Update_Field]  @acc_table_name, @en_db_column, NULL, @acc_PK, @acc_PK_value, @is_text_date, @stored_value, @last_action_user_id, @action_taken;
        END
    END
  END
END


GO

