

-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <29/09/2017>
-- Description:	<Copy all other names>
-- =============================================

CREATE  PROCEDURE [KYPEnrollment].[sp_Copy_AllOtherNames]
	--@acc_person_id INT,--AQUI EL ID DE LA PERSONA QUE ACABAMOS DE CREAR/COPIAR EN EL EXEC COPY PERSON
	@partyID int, --party de portal
	@last_action_user_id VARCHAR(100),
	--@person_other_id INT,
	@acc_party_id INT
AS
BEGIN

	declare @other_names_id table (pk int identity(1,1),PesonONID int);
	declare @tot int, @cont int,@add int,@new_add int,@loc int,@app_person_id INT
	DECLARE @date_created DATE; 

	select @app_person_id = PersonID from [KYPPORTAL].[PortalKYP].[pPDM_Person] where PartyID=@partyID

	SET NOCOUNT ON;

	IF EXISTS (SELECT PesonONID FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] where PersonID=@app_person_id and IsDeleted=0)
	BEGIN
			
		SET @date_created =  GETDATE();

						DECLARE @personId INT;
						SELECT @personId = PersonID FROM [KYPEnrollment].[pAccount_PDM_Person] WHERE PartyID=@acc_party_id;

						INSERT INTO [KYPEnrollment].[pAccount_PDM_Person_OtherName]

								   ([PersonID]
								   ,[FirstName]
								   ,[LastName]
								   ,[MiddleName]
								   ,[CreatedBy]
								   ,[DateCreated]
								   ,[IsDeleted]
								   ,[LastAction]
								   ,[LastActionDate]
								   ,[LastActorUserID]
								   ,[LastActionApprovedBy]
								   ,[CurrentRecordFlag])
	           
						SELECT	@personId,
								[FirstName],
								[LastName],
								[MiddleName],
								[CreatedBy],
								@date_created,
								[IsDeleted],
								'C',
								@date_created,
								@last_action_user_id,
								@last_action_user_id,
								1
						FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] 
						WHERE PersonID=@app_person_id AND IsDeleted=0;

		PRINT 'New Other Name';				
    END
END


GO

