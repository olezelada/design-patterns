
CREATE VIEW [KYPEnrollment].[v_EDM_ApplicationInternalMany]
AS
SELECT *
	,CASE ISNULL(CodeIdentification, '')
		WHEN ''
			THEN CodeDescription
		ELSE isnull(CodeIdentification,'') + ' - ' + CodeDescription
		END AS 'CodeDescriptionFull'
FROM KYPEnrollment.EDM_ApplicationInternalMany


GO

