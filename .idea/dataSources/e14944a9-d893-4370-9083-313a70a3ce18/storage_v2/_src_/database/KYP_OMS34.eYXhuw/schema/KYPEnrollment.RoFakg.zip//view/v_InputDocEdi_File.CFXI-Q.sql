










CREATE VIEW [KYPEnrollment].[v_InputDocEdi_File]
AS
SELECT     row_number() OVER (ORDER BY AccountID ASC) AS ID, *
FROM         
(
select  DISTINCT x.AccountID,x.PartyID, x.ProvNameScan,
 Analyst,
 CONVERT( varchar(10), x.AnalystDate, 101) AS AnalystDT,
 Reviewer,
 CONVERT( varchar(10), x.ReviewerDate, 101) AS ReviewerDT,
 Supervisor,
 CONVERT( varchar(10), x.SupervisorDate, 101) AS SupervisorDT,
NPI,OwnerNo,ServiceLocationNo as SerLocNo ,ProviderTypeCode + '- '+ProviderType AS ProviderType,LegalName,

SSN,
CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffBDT,
CASE CONVERT(varchar(10),x.EffectiveEndDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT,


EIN,
CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdDate,

TINUpdateType AS TINUpdType,
 ProvLocTypeCd,DBAName,Phone1,AddressLine1 as AdsL1,AddressLine2 as AdsL2,
 City,Acc_State,ZipPlus4,MAddressLine1 AS MAdsL1,MAddressLine2 as MAdsL2,MCity,MState,MZipPlus4,
SAddressLine1 as SAdsL1 ,SAddressLine2 as SAdsL2,SCity,SState,SZipPlus4,OutOfStateInd,--PSS055 PROVIDER DETAIL SCREEN
CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail, PracticeCode,StatusAcc,
CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt,RejectReasonCode AS RejResCode,--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
 --CodeIdentificationCateg,
--CodeDateEffDate,
--CodeDateExpDate,
Number,
CASE CONVERT(varchar(10),x.EffectiveDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT,


x.CliaNumber,x.SpecProcTypeCode,x.ProvisionalCode as ProvCode,
CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT,

ReenrollmentIndicator as ReEnrollIn,
--PSS038 PHYSICIAN CERTIFICATION Speciality_Code,
 SCodeIdentification1 as ScodeIdty1,SCodeIdentification2 as ScodeIdty2 ,SCodeIdentification3  as ScodeIdty3,SCodeIdentification4  as ScodeIdty4,SCodeIdentification5  as ScodeIdty5,
 SCodeIdentification6 as  ScodeIdty6,SCodeIdentification7 as ScodeIdty7 ,SCodeIdentification8 as ScodeIdty8,
  TaxonomyCode1 as TaxnC1,TaxonomyCode2 as TaxnC2,TaxonomyCode3 as TaxnC3,TaxonomyCode4 as TaxnC4,
  TaxonomyCode5 as TaxnC5,TaxonomyCode6 as TaxnC6,TaxonomyCode7 as TaxnC7,
 CCodeIdentification1 as CCodeIdty1,CONVERT( varchar(10), CAST (CCodeDateEffDate1 AS DATE), 101) AS  CCodeEffDT1 ,CONVERT( varchar(10), CAST(CCodeDateExpDate1 AS DATE), 101) AS CCodeExpDT1
,CCodeIdentification2 as CCodeIdty2,CONVERT( varchar(10), CAST (CCodeDateEffDate2 AS DATE), 101) AS CCodeEffDT2 ,CONVERT( varchar(10), CAST(CCodeDateExpDate2 AS DATE), 101) AS CCodeExpDT2
,CCodeIdentification3 as CCodeIdty3,CONVERT( varchar(10), CAST (CCodeDateEffDate3 AS DATE), 101) AS CCodeEffDT3 ,CONVERT( varchar(10), CAST(CCodeDateExpDate3 AS DATE), 101) AS CCodeExpDT3
,CCodeIdentification4 as CCodeIdty4,CONVERT( varchar(10), CAST (CCodeDateEffDate4 AS DATE), 101) AS CCodeEffDT4 ,CONVERT( varchar(10), CAST(CCodeDateExpDate4 AS DATE), 101) AS CCodeExpDT4
,CCodeIdentification5 as CCodeIdty5,CONVERT( varchar(10), CAST (CCodeDateEffDate5 AS DATE), 101) AS CCodeEffDT5 ,CONVERT( varchar(10), CAST(CCodeDateExpDate5 AS DATE), 101) AS CCodeExpDT5
,CCodeIdentification6 as CCodeIdty6,CONVERT( varchar(10), CAST (CCodeDateEffDate6 AS DATE), 101) AS CCodeEffDT6 ,CONVERT( varchar(10), CAST(CCodeDateExpDate6 AS DATE), 101) AS CCodeExpDT6
,CCodeIdentification7 as CCodeIdty7,CONVERT( varchar(10), CAST (CCodeDateEffDate7 AS DATE), 101) AS CCodeEffDT7 ,CONVERT( varchar(10), CAST(CCodeDateExpDate7 AS DATE), 101) AS CCodeExpDT7
,CCodeIdentification8 as CCodeIdty8,CONVERT( varchar(10), CAST (CCodeDateEffDate8 AS DATE), 101) AS CCodeEffDT8 ,CONVERT( varchar(10), CAST(CCodeDateExpDate8 AS DATE), 101) AS CCodeExpDT8
,CCodeIdentification9 as CCodeIdty9,CONVERT( varchar(10), CAST (CCodeDateEffDate9 AS DATE), 101)AS CCodeEffDT9 ,CONVERT( varchar(10), CAST(CCodeDateExpDate9 AS DATE), 101) AS CCodeExpDT9

,Speciality_Code1 AS Spec_C1,CONVERT( varchar(10), CAST(SpecCertDate1 AS DATE), 101) AS SpecCertDT1
,Speciality_Code2 AS Spec_C2,CONVERT( varchar(10), CAST(SpecCertDate2 AS DATE), 101) AS SpecCertDT2
,Speciality_Code3 AS Spec_C3,CONVERT( varchar(10), CAST(SpecCertDate3 AS DATE), 101) AS SpecCertDT3 
  ,GRPIDTY,
 LABStat,LABEFFDT,
 DOCNO 

 from (


SELECT 
A.AccountID As AccountID,
U1.LastActorUserID AS Analyst,
U1.LastActionDate AS AnalystDate,
u2.UserID AS Supervisor ,
U2.LastActionDate AS SupervisorDate,
U3.UserID AS Reviewer,
U3.LastActionDate AS ReviewerDate,
A.LastActionDate,
A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
A.PartyID ,
--PED PROVIDER MASTER FILE INPUT DOCUMENT
A.LegalName AS ProvNameScan,
--Document Review and Approve Signatures
--PMF Transaction Signatures
A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
A.ProviderType,
--PSS059 OWNER SCREEN
A.LegalName,
A.SSN,
B.EffectiveBeingDate,
B.EffectiveEndDate,
A.EIN,
C.TINUpdateDate,
C.TINUpdateType,
c.ProvisionalCode AS ProvLocTypeCd,
D.CodeIdentification,
--PSS070 LOCATION SCREEN 
A.DBAName,
Case when(R.Type='Individual Ownership') then 
E.Phone1 ELSE
Q.Phone1
END
  AS Phone1,

-- TO PAY ADDRESS
F.AddressLine1,F.AddressLine2,F.City,F.State as Acc_State,F.Zip+'-'+F.ZipPlus4 AS ZipPlus4,
--MAILING ADDRESS
G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.State AS MState,G.Zip+'-'+G.ZipPlus4 AS MZipPlus4,
--SERVICE ADDRESS
H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.State AS SState,H.Zip+'-'+H.ZipPlus4 AS SZipPlus4,
C.OutOfStateInd,
--PSS055 PROVIDER DETAIL SCREEN
A.ApplicationDate,
A.ProviderType AS ProviderTypeDETAIL,
C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,


A.StatusAcc,
A.StatusBeginDate,
C.RejectReasonCode,
--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
--I.CodeIdentification AS CodeIdentificationCateg,
--I.CodeDateEffDate,
--I.CodeDateExpDate,
J.Number,
J.EffectiveDate,
K.CliaNumber,
C.SpecProcTypeCode,
C.ProvisionalCode,
C.ProvisionalCodeDate,
A.ReenrollmentIndicator,
--PSS038 PHYSICIAN CERTIFICATION
L.Speciality_Code,
Case when(A.AccountType='G') then
'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
ELSE 
'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
END AS GRPIDTY,
C.LabSpecCode+ '-'+C.LabSpecCodeDesc AS LABStat,
C.LabSpecCodeEfDate as LABEFFDT,
A.AccountNumber AS DOCNO


 from KYPEnrollment.pADM_Account A 
  left join
  (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName , ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID
   where y.RoleName in('ReviewerS','Reviewer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U1 on U1.AccountID=A.AccountID 
   
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID , ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID
   where y.RoleName in('SupervisorR','SupervisorS'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U2 on U2.AccountID=A.AccountID
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID , ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID
   where y.RoleName in('ConfirmerS','Confirmer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U3 on U3.AccountID=A.AccountID
 
LEFT OUTER JOIN 
KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
LEFT OUTER JOIN
KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID and C.CurrentRecordFlag = 1
LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
--This is for Pay-to Address Details
left outer join 
(select F.AddressLine1,F.AddressLine2,F.City,F.State,F.Zip, F.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address F 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on F.AddressID = X.AddressID 
	 and X.Type='Pay-to'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = a.PartyID 
--This is for Service Address Details	 
left outer join 	 
	(select H.AddressLine1,H.AddressLine2,H.City,H.State,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County  from KYPEnrollment.pAccount_PDM_Address H 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on H.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)H
	 on H.PartyID = a.PartyID 
--This is for Mailing Address Details
left outer join(select G.AddressLine1,G.AddressLine2,G.City,G.State,G.Zip,G.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address G
inner join KYPEnrollment.pAccount_PDM_Location X
	 on G.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)G
	 on G.PartyID = a.PartyID	 
	 
	 
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address F ON F.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Pay-to' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address G ON G.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Mailing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address H ON H.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Servicing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.EDM_AccountInternalMany I ON I.AccountInternalUseID=C.AccountInternalUseID AND C.AccountID=A.AccountID AND I.CodeType = 'Category'
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Number J ON J.PartyID=A.PartyID AND J.Type='Professional License' AND J.CurrentRecordFlag=1
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Speciality L ON L.PartyID=A.PartyID and  L.IsPrimary=NULL and L.CurrentRecordFlag=1
--LEFT  OUTER JOIN KYPEnrollment.pAccount_RenderingAffiliation M ON M.AccountID=A.AccountID and A.AccountType='NMP'
LEFT  OUTER JOIN KYPEnrollment.pADM_AccountStatus N ON N.AccountID=A.AccountID and N.CurrentRecordFlag=1
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID

)x
left join (
select AccountID, SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
   TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,
CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3

  from(    
   
   -- DH-SANCTION-TXT-2019 occurs 8 times
                -- 8 Occurance for 'CodeIdentification' from "KYPEnrollment.EDM_AccountInternalMany" table where CodeType = 'Sanction'
              SELECT C.AccountId, CONVERT(varchar(20),CodeIdentification) as CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
    inner join KYPEnrollment.EDM_AccountInternalUse C 
    on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
  
    
       UNION All
        SELECT A.Accountid, CONVERT(varchar(MAx), P.TaxonomyCode)
         ,'TaxonomyCode'+CONVERT(varchar(10), ROW_NUMBER()  over(partition by A.Accountid order by  SpecialityID desc) ) seq
                FROM KYPEnrollment.pAccount_PDM_Speciality P
                inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID And P.Type='Taxonomy Code'
               
       UNION ALL
	SELECT C.AccountId,CONVERT(varchar(20),CodeIdentification)
	,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
 
	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateEffDate)
	,'CCodeDateEffDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
 
	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateExpDate)
	,'CCodeDateExpDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
        
	UNION ALL 
	SELECT A.Accountid,CONVERT(varchar(20), P.Speciality_Code)
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc  ) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID And P.Type='Specialty Code'	
	 
	UNION ALL 
	SELECT A.Accountid,CONVERT(varchar(20), P.SpecCertDate)
	,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID  And P.Type='Specialty Code'	
		
       )ML(AccountId,StatusValue,seq)

PIVOT (max(ml.StatusValue)  
	 FOR ml.seq IN (SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
   TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,
CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
)) pvt 


  )y
on x.AccountID= y.AccountId

where x.IsDeleted=0 AND x.AccountUpdatedBy != 'M' 
AND CONVERT(VARCHAR, x.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101) 
)Z


GO

