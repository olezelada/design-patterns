-- =============================================
-- Author:   <Lperez>
-- PROCEDURE que elimina todos los flag que esten relacionados un account apartir de su party id 
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Disable_All_Flag_Account]
	@partyId INT,@lastActionUserID varchar(100)
AS
BEGIN

	Declare @message varchar(100),@partyIDTmp int,@personID INT,@locationID INT,@addressID INT,@date smalldatetime
	
	SELECT @message = 'Disable Flag ' + CONVERT(char(10), @partyId)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	SET @date = GETDATE()
	
	DECLARE Disable_All_Flag_Account_Cursor CURSOR FOR 
	SELECT t.* FROM (SELECT PartyID  FROM KYPEnrollment.pAccount_PDM_Party WHERE PartyID =@partyId
	UNION ALL
	SELECT PartyID  FROM KYPEnrollment.pAccount_PDM_Party WHERE ParentPartyID = @partyId
	UNION ALL
	SELECT papp.PartyID  FROM KYPEnrollment.pAccount_PDM_Party papp INNER JOIN (SELECT PartyID  FROM KYPEnrollment.pAccount_PDM_Party WHERE ParentPartyID =@partyId) allpart ON  allpart.PartyID = papp.ParentPartyID
	) t
		
	OPEN Disable_All_Flag_Account_Cursor;
	FETCH NEXT FROM Disable_All_Flag_Account_Cursor INTO @partyIDTmp	
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		--Disable all account 
		UPDATE KYPEnrollment.pAccount_PDM_Party SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID  WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_EntityType SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID  WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Document SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Insurance SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_OwnerhipTransaction SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Organization SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Clia SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Speciality SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_PaymentDetail SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_AdverseAction SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Number SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_UniqueParty_MOCAMapping SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date WHERE MOCAPartyID = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_OwnershipRelationship SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyIDOwned = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_OwnershipRelationship SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyIDOwner = @partyIDTmp
		UPDATE KYPEnrollment.pAccount_PDM_Provider SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		-- Disable all account Person an Other person
		DECLARE Disable_All_Flag_Person_Cursor CURSOR FOR 
		SELECT t.personID FROM KYPEnrollment.pAccount_PDM_Person t WHERE t.PartyID=@partyIDTmp
			
		OPEN Disable_All_Flag_Person_Cursor;
		FETCH NEXT FROM Disable_All_Flag_Person_Cursor INTO @personID	
		WHILE @@FETCH_STATUS = 0
		BEGIN	
			UPDATE KYPEnrollment.pAccount_PDM_Person SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PersonID = @personID
			UPDATE KYPEnrollment.pAccount_PDM_Person_OtherName  SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PersonID = @personID
			FETCH NEXT FROM Disable_All_Flag_Person_Cursor INTO @personID
		END;
		CLOSE Disable_All_Flag_Person_Cursor;
		DEALLOCATE Disable_All_Flag_Person_Cursor;	
		--Disable all account location 
		UPDATE KYPEnrollment.pAccount_PDM_Location SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date,LastActorUserID=@lastActionUserID WHERE PartyID = @partyIDTmp
		--Disable all account Address 
		DECLARE Disable_All_Flag_Address_Cursor CURSOR FOR 
		SELECT t.AddressID FROM KYPEnrollment.pAccount_PDM_Location t WHERE t.PartyID=@partyIDTmp
			
		OPEN Disable_All_Flag_Address_Cursor;
		FETCH NEXT FROM Disable_All_Flag_Address_Cursor INTO @addressID	
		WHILE @@FETCH_STATUS = 0
		BEGIN	
			UPDATE KYPEnrollment.pAccount_PDM_Address SET CurrentRecordFlag =0,LastAction = 'D',LastActionDate=@date WHERE AddressID = @addressID
			FETCH NEXT FROM Disable_All_Flag_Address_Cursor INTO @addressID
		END;
		CLOSE Disable_All_Flag_Address_Cursor;
		DEALLOCATE Disable_All_Flag_Address_Cursor;	
		PRINT 'DISABLE FLAG ALL'
		FETCH NEXT FROM Disable_All_Flag_Account_Cursor INTO @partyIDTmp
	END;
	CLOSE Disable_All_Flag_Account_Cursor;
	DEALLOCATE Disable_All_Flag_Account_Cursor;			
END


GO

