CREATE VIEW [KYP].[Review_documents_view]
AS
SELECT     [KYP].OIS_EntityReview.EntityReviewID, [KYP].OIS_EntityReview.ReviewBy, [KYP].OIS_EntityReview.ReviewDate, 
                      [KYP].OIS_EntityReview.CurrentStatus, [KYP].OIS_EntityReview.CaseNumber AS Expr1, [KYP].OIS_EntityReview.DateExpected, 
                      [KYP].OIS_EntityReview.DateSentforReview, [KYP].OIS_EntityReview.CreatedBy, [KYP].OIS_Attachment.AttachmentID, 
                      [KYP].OIS_Attachment.FileName, [KYP].OIS_Attachment.Author, [KYP].OIS_Attachment.Title, [KYP].OIS_Attachment.Status, 
                      [KYP].OIS_Attachment.Description, [KYP].OIS_Attachment.DMSID, [KYP].OIS_Attachment.Version, [KYP].OIS_Attachment.SubType, 
                      [KYP].OIS_Attachment.FileType, [KYP].OIS_Attachment.Owner, [KYP].OIS_Attachment.Created, [KYP].OIS_Attachment.Modified, 
                      [KYP].OIS_Attachment.Received, [KYP].OIS_Attachment.Due, [KYP].OIS_Attachment.Requirement, [KYP].OIS_Attachment.CaseNumber, 
                      [KYP].OIS_Attachment.Type, [KYP].OIS_Attachment.DocumentTypeID, [KYP].OIS_Attachment.FolderPath, [KYP].OIS_EntityReview.Role, 
                      [KYP].OIS_Attachment.Deleted,
                      [KYP].OIS_Attachment.Number, [KYP].OIS_Attachment.IconType
FROM         [KYP].OIS_EntityReview INNER JOIN
                      [KYP].OIS_JT_ReviewAttachment ON [KYP].OIS_EntityReview.EntityReviewID = [KYP].OIS_JT_ReviewAttachment.EntityReviewID INNER JOIN
                      [KYP].OIS_Attachment ON [KYP].OIS_JT_ReviewAttachment.AttachmentID = [KYP].OIS_Attachment.AttachmentID


GO

