
CREATE VIEW [dbo].[view_MoratoriaDetails]
AS
SELECT 
		MD.ID AS ID,
		MD.County AS County,
		CD.CountyDescription AS CountyName,
		MD.City AS City,
		CCD.CityDescription AS CityName,
		MD.ZIPCOde AS ZIP,
		MD.ProviderTypeCode AS ProviderTypeCode,
		PTC.ProviderTypeDescription AS ProviderTypeName,
		MD.MoratoriaStartDate AS StartDate,
		MD.MoratoriaEndDate AS EndDate,
		MD.ModifiedBy AS ModifiedBy,
		MD.ModifiedDate AS ModifiedDate,
		MD.IsDeleted AS IsDeleted
	FROM 
		MoratoriumData MD,
		CountyDetails CD,
		CityDetails CCD,
		KYPENROLLMENTDev.KYP.PDM_ProviderTypeCode PTC 
	WHERE
		MD.County = CD.CountyCode AND
		MD.City = CCD.CityCode AND
		MD.ProviderTypeCode = PTC.ProviderTypeCode


GO

