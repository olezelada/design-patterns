


-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_RelationRenderingUpdate]	
	@providerNumber varchar(15)
	
AS
BEGIN
    DECLARE @renderingID INT,
    @lastActionUserID varchar(100),
			@providerNumberA varchar(15),
			@providerNumberB varchar(15),
			@affiliatedAccountID INT,
			@isCount INT,
			@isCountA INT,
			@isCountB INT,
			@accountID INT,
			@accountIDB INT,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()
			
	DECLARE RelationRendering_Cursor CURSOR FOR 	
	select [rendering_affiliation_id],[group_providerNumber],[rendering_providerNumber] from [KYPPORTAL].[PortalKYP].pRenderingAffiliation WHERE [rendering_providerNumber] = @providerNumber
	
	OPEN RelationRendering_Cursor;
	FETCH NEXT FROM RelationRendering_Cursor INTO @renderingID, @providerNumberA,@providerNumberB
	
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		SET @isCount = 0
		SET @isCountA = 0
		SET @isCountB = 0
		
		SELECT @accountID = [AccountID] FROM [KYPEnrollment].[pADM_Account] WHERE [ApplicationNumber] = @providerNumberA and IsDeleted = '1';
		SELECT @accountIDB = [AccountID] FROM [KYPEnrollment].[pADM_Account] WHERE [ApplicationNumber] = @providerNumberB and IsDeleted = '1';
		
		SELECT @isCount = COUNT(DISTINCT [Number])FROM [KYP].ADM_Case WHERE [ResolutionStatus]='Approved' AND [Number] = @providerNumberA;
		SELECT @isCountA = COUNT(DISTINCT [TypeAffiliation]) FROM [KYPEnrollment].[pAccount_RenderingAffiliation] WHERE [AffiliatedAccountID] = @accountIDB AND [AccountID] = @accountID; 
		SELECT @isCountB = COUNT(DISTINCT [TypeAffiliation]) FROM [KYPEnrollment].[pAccount_RenderingAffiliation] WHERE [AccountID] = @accountID GROUP BY [AccountID];
		
		SELECT @message = '@@ingreso:@isCount= ' + CONVERT(char(10), @isCount)+', @isCountB=' + CONVERT(char(10), @isCountB)+', @isCountA=' + CONVERT(char(10), @isCountA)
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		IF(@isCount=1 AND @isCountB > 0 AND @isCountA = 0)
		BEGIN
			SELECT @message = '@@ingreso:@isCount,@isCountB,@isCountA ' + CONVERT(char(10), @isCount)+',' + CONVERT(char(10), @isCountB)+',' + CONVERT(char(10), @isCountA)
			RAISERROR(@message, 0, 1) WITH NOWAIT
			
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
			([AccountID]
			,[AffiliatedAccountID]
			,[TypeAffiliation]
			,[LastActionDate]
			--,[LastActorUserID]
			--,[LastActionApprovedBy]
			,[CurrentRecordFlag]
			,[LastAction]
			,[isDeleted])
			SELECT @accountID
			,@affiliatedAccountID
			,[type_affiliation]
			,@dateCreated
			--,@lastActionUserID
			--,@lastActionUserID
			,'1'
			,'C'
			,0
			FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] WHERE [rendering_affiliation_id] = @renderingID
		END
		FETCH NEXT FROM RelationRendering_Cursor INTO @renderingID, @providerNumberA,@providerNumberB		
	END;
	CLOSE RelationRendering_Cursor;
	DEALLOCATE RelationRendering_Cursor;
END


GO

