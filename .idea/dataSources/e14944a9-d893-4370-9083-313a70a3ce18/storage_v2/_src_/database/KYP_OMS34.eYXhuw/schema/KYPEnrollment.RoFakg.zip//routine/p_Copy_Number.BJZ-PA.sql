

-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Number recive 3 parametros 
-- @partyIdPortal old id party portal ,@partyIdOMS nuevo party id account, @lastActionUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Number]
	@partyIdPortal INT,
	@partyIdOMS INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF((SELECT COUNT([NumberID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Number] WHERE PartyID = @partyIdPortal)>0)
	BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
	([PartyID] ,
	[Number] ,
	[Type] ,
	[EffectiveDate] ,
	[ExpirationDate] ,
	[LastAction],
	[LastActionDate],
	[LastActorUserID]	,
	[LastActionApprovedBy],
	[CurrentRecordFlag],
	[Name] ,
	[State] ,
	[documentInstanceId])
	SELECT @partyIdOMS
	,[Number]
	,[Type]
	,[EffectiveDate]
	,[ExpirationDate]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[Name]
	,[State]
	,[documentInstanceId]
	--,[TypeForm]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Number] WHERE PartyID = @partyIdPortal

	SELECT @message = 'New Number ' + CONVERT(char(10), 'Number copy')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	END					
END


GO

