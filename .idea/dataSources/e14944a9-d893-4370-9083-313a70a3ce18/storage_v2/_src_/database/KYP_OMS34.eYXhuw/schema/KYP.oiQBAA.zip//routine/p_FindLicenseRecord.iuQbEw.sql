-- =============================================
-- Author:		Yogesh Sharma
-- Create date: Aug 03 2012
-- Description:	Find the LicenseID of Party if license is received
-- =============================================
CREATE PROCEDURE [KYP].[p_FindLicenseRecord]
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@LicenseState varchar(50)
	,@LicenseCode varchar(25)
	,@ExpiryDate datetime = NULL	
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @LicenseID int
	/********Get the LicenseID based on PartyID, License State and License Nbr**********/
	if exists (	
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_License B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.LicenseState = @LicenseState
		and B.LicenseCode = @LicenseCode
		and ISNULL(B.ExpiryDate,getdate()) = ISNULL(@ExpiryDate, GETDATE())
	)
	begin
	select @LicenseID = B.LicenseID
	from KYP.PDM_Party A
	inner join KYP.PDM_License B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.LicenseState = @LicenseState
		and B.LicenseCode = @LicenseCode	
	    and ISNULL(B.ExpiryDate,getdate()) = ISNULL(@ExpiryDate, GETDATE())
    return @LicenseID	
	end	
	else 
	return -1   	
END


GO

