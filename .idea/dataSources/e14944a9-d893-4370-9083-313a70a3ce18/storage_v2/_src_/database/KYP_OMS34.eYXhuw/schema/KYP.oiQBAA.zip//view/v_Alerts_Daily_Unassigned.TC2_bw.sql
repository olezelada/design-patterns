
CREATE VIEW [KYP].[v_Alerts_Daily_Unassigned]
AS
SELECT top (100) percent 
	AlertID AS ID,
	AlertNo as AlertNumber,   
	WatchedPartyName as PartyName,
	MatchPercent,
	Priority, 
	DateInitiated as AlertDate 

FROM KYP.MDM_Alert 
WHERE ISNULL(IsMerged,'') in ( 'N','') 
and  
WFStatus <> 'Completed' 

and 
--START OF CAPAVE-300 
StatusCodeNumber in (11,12) 
--END OF CAPAVE-300

AND 

(DATEDIFF(Day,DateInitiated,GETDATE()) > 3
 OR 
 DATEDIFF(Day,ISNULL(AssignedDate,DateInitiated),GETDATE()) > 3)

ORDER BY DateInitiated Asc


GO

