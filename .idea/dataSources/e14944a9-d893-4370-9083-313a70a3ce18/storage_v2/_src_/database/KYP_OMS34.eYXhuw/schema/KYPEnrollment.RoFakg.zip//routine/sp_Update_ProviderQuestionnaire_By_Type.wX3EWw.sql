-- =============================================
-- Author:		<Author, hbustamante>
-- Create date: <03/01/2019>
-- Description:	<this procedure UPDATE ProviderQuestionnaire by type>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_ProviderQuestionnaire_By_Type]

	@type_questionnaire VARCHAR(50)
	, @account_Party_Id INT
	, @new_value_text VARCHAR(MAX)
	, @app_party_id INT
AS
BEGIN
SET NOCOUNT ON;
DECLARE @dateModified DATE;
SET @dateModified = GETDATE();
IF EXISTS(SELECT Questionid FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] WHERE Type = @type_questionnaire AND PartyID = @account_Party_Id AND CurrentRecordFlag = 1)
			BEGIN
				UPDATE [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie]
					SET value = CASE WHEN LEN(ISNULL(@new_value_text, '')) = 0
								THEN 'No'
								ELSE @new_value_text
								END
						, DateModified = @dateModified
						, LastAction = 'U'
				WHERE Type = @type_questionnaire AND PartyID = @account_Party_Id
			END
			ELSE
			BEGIN
				EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] 	@app_party_id, @account_Party_Id, @type_questionnaire
			END

END
GO

