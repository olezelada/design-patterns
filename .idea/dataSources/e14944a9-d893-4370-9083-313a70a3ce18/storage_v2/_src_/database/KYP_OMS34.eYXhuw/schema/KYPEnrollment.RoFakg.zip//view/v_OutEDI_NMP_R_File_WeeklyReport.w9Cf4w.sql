
CREATE VIEW [KYPEnrollment].[v_OutEDI_NMP_R_File_WeeklyReport]
AS
SELECT row_number() OVER (ORDER BY RenderingAffiliationID ASC) AS ID, *
FROM         
(
Select DISTINCT x.TypeAffiliation,x.RenderingAffiliationID,x.LastActionDate ,x.IsDeleted, --,x.LastUpdatedBy --LastActionDate for fetch the data based on specific date

 x.BallingNPI,x.OwnerNo,x.ServiceLocationNo ,x.ProviderTypeCode
-- Detail S record 
,x.NMPRenderingLicense,NMPRenderingNPI
-- Here three field not yet cleared 
,AffiliationStartDate,AffiliationEndDate

from( 
select
RAff.TypeAffiliation,RAff.RenderingAffiliationID,RAff.LastActionDate,RAff.AffiliationStartDate,AffiliationEndDate,RAff.LastUpdatedBy
-- Field of pADM_Account A (Billing)
,A.NPI AS BallingNPI,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode,A.IsDeleted,A.DateCreated 

-- Field of pAccount_PDM_Number (For Rendring)
,AR.NPI AS NMPRenderingNPI

,LIC.Number AS NMPRenderingLicense
--,(select Number from KYPEnrollment.pAccount_PDM_Number where PartyID=(Select PartyID from KYPEnrollment.pADM_Account where AccountID=RAff.AffiliatedAccountID))as NMPRenderingLicense
--,(Select NPI from KYPEnrollment.pADM_Account where AccountID=RAff.AffiliatedAccountID )AS  NMPRenderingNPI

from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
-- This is for NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
--License of NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Number LIC on LIC.PartyID=AR.PartyID AND LIC.Type='Professional License' AND LIC.CurrentRecordFlag=1
--where RAff.AffiliationStartDate != RAff.AffiliationEndDate
where RAff.TypeAffiliation ='NMP' AND A.IsDeleted=0 
) x
-- where x.TypeAffiliation='NMP' AND x.IsDeleted=0 AND (x.LastUpdatedBy != 'M' OR LastUpdatedBy is NULL )
--AND CONVERT(VARCHAR, x.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-7, 101) and  
--CONVERT(VARCHAR, x.LastActionDate , 101) <=  CONVERT(VARCHAR, GETDATE(), 101) 
--where CONVERT(VARCHAR, x.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-1, 101) 

) z
------------------------------------------------------------------- Close of NMP Relationship file ----------------------------------------------------------------------


GO

