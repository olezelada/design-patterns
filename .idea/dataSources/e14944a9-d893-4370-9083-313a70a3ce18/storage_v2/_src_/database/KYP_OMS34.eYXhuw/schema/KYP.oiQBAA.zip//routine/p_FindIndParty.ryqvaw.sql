
-- =============================================
-- Author:		Yogesh Sharma
-- Create date: July 28 2012
-- Description:	Finds Individual Party based on LastName+SSN+NPI
-- Modified: Nitish Gondkar
-- Modified Date: 02-Aug-2013
-- Modified Description: Removed ISNULL check from SSN & NPI
-- =============================================
CREATE PROCEDURE [KYP].[p_FindIndParty]
	-- Add the parameters for the stored procedure here
	@LastName VARCHAR(50)
	,@SSN VARCHAR(9) = NULL
	,@NPI VARCHAR(10) = NULL
	,@LIC_CERT_NUM VARCHAR(15) = NULL
	,@CurrentModule SMALLINT = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @PartyID INT

	IF (LTRIM(RTRIM(ISNULL(@LastName, '')))) = ''
	BEGIN
		SET @LastName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@SSN, '')))) = ''
	BEGIN
		SET @SSN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@NPI, '')))) = ''
	BEGIN
		SET @NPI = NULL;
	END

	/********Do a LastName+SSN+NPI match**********/
	IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LastName = @LastName
				AND (B.SSN = @SSN AND ISNULL(B.SSN, '0') <> '0')
				AND (B.NPI = CONVERT(INT, @NPI) AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LastName = @LastName
			AND (B.SSN = @SSN AND ISNULL(B.SSN, '0') <> '0')
			AND (B.NPI = CONVERT(INT, @NPI) AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LastName = @LastName
				AND (B.SSN = @SSN AND ISNULL(B.SSN, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LastName = @LastName
			AND (B.SSN = @SSN AND ISNULL(B.SSN, '0') <> '0')

		RETURN @PartyID
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM KYP.PDM_Party A
			INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
				AND ISNULL(A.IsDeleted, 0) = 0
			WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
				AND B.LastName = @LastName
				AND (B.NPI = CONVERT(INT, @NPI) AND ISNULL(B.NPI, '0') <> '0')
			)
	BEGIN
		SELECT @PartyID = A.PartyID
		FROM KYP.PDM_Party A
		INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
			AND ISNULL(A.IsDeleted, 0) = 0
		WHERE ISNULL(A.CurrentModule, 0) = ISNULL(@CurrentModule, 0)
			AND B.LastName = @LastName
			AND (B.NPI = CONVERT(INT, @NPI) AND ISNULL(B.NPI, '0') <> '0')

		RETURN @PartyID
	END
	ELSE
		RETURN - 1
END


GO

