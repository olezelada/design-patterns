
CREATE TRIGGER [KYPEnrollment].[updateSortOrderTask] ON [KYPEnrollment].[MT_Task]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
SET NOCOUNT ON
IF ( UPDATE(IsDeleted))
BEGIN
	DECLARE @SortOrderId int	
	DECLARE @TemplateID int
	set @SortOrderId = 1	
	select @TemplateID=i.TemplateID from inserted i;
	DECLARE @TaskID int	
	
	DECLARE pMT_Task_Tmp CURSOR FOR
	select mtt.TaskID from KYPEnrollment.MT_Task mtt where mtt.TemplateID=@TemplateID AND (mtt.IsDeleted='false' OR mtt.IsDeleted IS NULL) order by mtt.TaskID asc;
	OPEN pMT_Task_Tmp;
	
	FETCH NEXT FROM pMT_Task_Tmp INTO @TaskID
	WHILE @@FETCH_STATUS = 0 
		BEGIN
								
			UPDATE KYPEnrollment.MT_Task SET SortOrder = @SortOrderId where TaskID=@TaskID	
			set @SortOrderId = @SortOrderId + 1	
			FETCH NEXT FROM pMT_Task_Tmp INTO @TaskID
			
		END			
	CLOSE pMT_Task_Tmp
	DEALLOCATE pMT_Task_Tmp	
		
END


GO

