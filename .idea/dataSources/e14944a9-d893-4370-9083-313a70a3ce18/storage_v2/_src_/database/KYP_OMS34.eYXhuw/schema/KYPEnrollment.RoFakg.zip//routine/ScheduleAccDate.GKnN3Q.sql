


CREATE FUNCTION [KYPEnrollment].[ScheduleAccDate]()

RETURNS Date

AS
BEGIN

  DECLARE @RevEnabled bit ,@RevYears int, @RevMonths int,@ReDate date= DATEADD(yy, 5, getdate())

		SELECT TOP 1
			   @RevEnabled=[Enabled]      
			  ,@RevYears =[RevalidationPeriodYears]
			  ,@RevMonths=[RevalidationPeriodMonths]     
		  FROM [KYPEnrollment].[ScheduledAccountsSetup]
		  ORDER BY ID DESC
		  
		  IF @RevEnabled = 1
		  BEGIN
			SET @ReDate  = DATEADD(mm, @RevMonths, DATEADD(yy, @RevYears, getdate()))
		    
		  END
 
      RETURN @ReDate ;
END


GO

