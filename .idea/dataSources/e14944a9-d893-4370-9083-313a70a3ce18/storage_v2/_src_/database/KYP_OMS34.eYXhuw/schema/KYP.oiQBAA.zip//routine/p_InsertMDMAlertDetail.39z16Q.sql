--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket					Description
--------------------------------------------------------------------------------------------------------
-- 1		30-Jun-2017		Sundar		CAPAVE-254					Updated 5 fields from MDM_StageAlerts to KYP.MDM_AlertDetailPartyMatch

/******Script for insert procedure************/
CREATE PROCEDURE [KYP].[p_InsertMDMAlertDetail] (
	@AlertID INT
	,@FName VARCHAR(50) = NULL
	,@MName VARCHAR(50) = NULL
	,@LName VARCHAR(50) = NULL
	,@OrganizationName VARCHAR(500) = NULL
	,@AliasName VARCHAR(50) = NULL
	,@SSN VARCHAR(15) = NULL
	,@TAXID VARCHAR(20) = NULL
	,@DOB DATETIME = NULL
	,@LicenseNo VARCHAR(20) = NULL
	,@NPI INT = NULL
	,@DEA VARCHAR(20) = NULL
	,@DBAName VARCHAR(100) = NULL
	,@LegalName VARCHAR(500) = NULL
	,@OwnerName VARCHAR(50) = NULL
	,@CreatedDate DATETIME = NULL
	,@CreatedBy INT = NULL
	,@ModifiedDate DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DeletedDate DATETIME = NULL
	,@DeletedBy INT = NULL
	,@IsDeleted BIT = NULL
	,@UPIN VARCHAR(6) = NULL
	,@HMS_PIID VARCHAR(10) = NULL
	,@HMS_POID VARCHAR(10) = NULL
	,@LoadID VARCHAR(30) = NULL
	,@LoadType VARCHAR(1) = NULL
	,@LastLoadDate DATETIME = NULL
	,@EPLS_TermDate VARCHAR(10) = NULL
	,@EPLS_ActionDate VARCHAR(10) = NULL
	,@EPLS_Agency VARCHAR(25) = NULL
	,@LEIE_EXCLType VARCHAR(50) = NULL
	,@LEIE_EXCLDate VARCHAR(10) = NULL
	,@LEIE_REINDATE VARCHAR(10) = 0
	,@Offense_Code VARCHAR(10) = NULL
	,@Offense_Date VARCHAR(10) = NULL
	,@Offense_Description VARCHAR(255) = NULL
	,@Board_Code VARCHAR(15) = NULL
	,@Board_Description VARCHAR(255) = NULL
	,@Action_Code VARCHAR(10) = NULL
	,@Action_Date VARCHAR(10) = NULL
	,@Action_Description VARCHAR(255) = NULL
	,@Sanc_PeriodStartDt VARCHAR(10) = NULL
	,@Sanc_PeriodEndDt VARCHAR(10) = NULL
	,@Sanc_FineAmt VARCHAR(8) = NULL
	,@License_State VARCHAR(5) = NULL
	,@License_Type VARCHAR(3) = NULL
	,@License_Status VARCHAR(1) = NULL
	,@License_Start_Date VARCHAR(10) = NULL
	,@License_Expire_Date VARCHAR(10) = NULL
	,@DEA_RANK VARCHAR(2) = NULL
	,@DEA_Expire VARCHAR(10) = NULL
	,@DEA_Active VARCHAR(1) = NULL
	,@UniqueKey VARCHAR(550) = NULL
	,@DOD DATETIME
	,@MCSIS_ID INT
	,@WatchlistPartyID VARCHAR(20)
	,@AlertGenCriteria VARCHAR(250)
	,@TerminationEffectiveDate datetime --Added for #4 CAPAVE-254
	,@TerminationImportDate datetime --Added for #4 CAPAVE-254
	,@AdditionalComments varchar(500) --Added for #4 CAPAVE-254	
	)
AS
BEGIN
	INSERT INTO [KYP].[MDM_AlertDetail] (
		[AlertID]
		,[FName]
		,[MName]
		,[LName]
		,[OrganizationName]
		,[AliasName]
		,[SSN]
		,[TAXID]
		,[DOB]
		,[LicenseNo]
		,[NPI]
		,[DEA]
		,[DBAName]
		,[LegalName]
		,[OwnerName]
		,[CreatedDate]
		,[CreatedBy]
		,[ModifiedDate]
		,[ModifiedBy]
		,[DeletedDate]
		,[DeletedBy]
		,[IsDeleted]
		,[UPIN]
		,[HMS_PIID]
		,[HMS_POID]
		,[LoadID]
		,[LoadType]
		,[LastLoadDate]
		,[EPLS_TermDate]
		,[EPLS_ActionDate]
		,[EPLS_Agency]
		,[LEIE_EXCLType]
		,[LEIE_EXCLDate]
		,[LEIE_REINDATE]
		,[Offense_Code]
		,[Offense_Date]
		,[Board_Code]
		,[Action_Date]
		,[Sanc_PeriodStartDt]
		,[Sanc_PeriodEndDt]
		,[Sanc_FineAmt]
		,[License_State]
		,[License_Type]
		,[License_Status]
		,[License_Start_Date]
		,[License_Expire_Date]
		,[DEA_RANK]
		,[DEA_Expire]
		,[DEA_Active]
		,[UniqueKey]
		,[DOD]
		,[Action_Code]
		,[Action_Description]
		,[Offense_Description]
		,[Board_Description]
		,[MCSIS_ID]
		,[NPIID]
		,[watchlistpartyid]
		,[AlertGenCriteria]
		,TerminationEffectiveDate --Added for #4 CAPAVE-254
		,TerminationImportDate --Added for #4 CAPAVE-254
		,AdditionalComments --Added for #4 CAPAVE-254		
		)
	VALUES (
		@AlertID
		,@FName
		,@MName
		,@LName
		,@OrganizationName
		,@AliasName
		,@SSN
		,@TAXID
		,@DOB
		,@LicenseNo
		,@NPI
		,@DEA
		,@DBAName
		,@LegalName
		,@OwnerName
		,@CreatedDate
		,@CreatedBy
		,@ModifiedDate
		,@ModifiedBy
		,@DeletedDate
		,@DeletedBy
		,@IsDeleted
		,@UPIN
		,@HMS_PIID
		,@HMS_POID
		,@LoadID
		,@LoadType
		,@LastLoadDate
		,@EPLS_TermDate
		,@EPLS_ActionDate
		,@EPLS_Agency
		,@LEIE_EXCLType
		,@LEIE_EXCLDate
		,@LEIE_REINDATE
		,@Offense_Code
		,@Offense_Date
		,@Board_Code
		,@Action_Date
		,@Sanc_PeriodStartDt
		,@Sanc_PeriodEndDt
		,@Sanc_FineAmt
		,@License_State
		,@License_Type
		,@License_Status
		,@License_Start_Date
		,@License_Expire_Date
		,@DEA_RANK
		,@DEA_Expire
		,@DEA_Active
		,@UniqueKey
		,@DOD
		,@Action_Code
		,@Action_Description
		,@Offense_Description
		,@Board_Description
		,@MCSIS_ID
		,@WatchlistPartyID
		,@WatchlistPartyID
		,@AlertGenCriteria
		,@TerminationEffectiveDate --Added for #4 CAPAVE-254
		,@TerminationImportDate --Added for #4 CAPAVE-254
		,@AdditionalComments --Added for #4 CAPAVE-254			
		)

	RETURN IDENT_CURRENT('[KYP].[MDM_AlertDetail]')
END
GO

