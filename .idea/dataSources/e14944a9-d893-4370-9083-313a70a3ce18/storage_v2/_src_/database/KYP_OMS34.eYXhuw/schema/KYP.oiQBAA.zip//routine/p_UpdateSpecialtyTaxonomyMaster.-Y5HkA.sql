-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 25-Feb-2014
-- Description:	Taxonomy data for Specialty Table
-- =============================================
CREATE PROCEDURE [KYP].[p_UpdateSpecialtyTaxonomyMaster]
	-- Add the parameters for the stored procedure here
	@HippaServerName VARCHAR(250),
	@HippaDatabaseName VARCHAR(250),
	@HippaUserName VARCHAR(100),
	@HippaPwd VARCHAR(100)
AS
BEGIN
	DECLARE 
	@HippaLoginServer VARCHAR(100),
	@HippaLoginUsername VARCHAR(100),
	@HippaLoginPwd VARCHAR(100),
	
	@GroupID INT,
	@Description VARCHAR(500),
	@checkTaxonomyQuery NVARCHAR(4000),
	@ParmDefinition NVARCHAR(500),
	@retval VARCHAR(400),
	@Taxonomy VARCHAR(400)
	
	SET @HippaLoginServer = ''''+ @HippaServerName +''''
	SET @HippaLoginUsername = ''''+ @HippaUserName +''''
	SET @HippaLoginPwd = ''''+ @HippaPwd +''''

	IF NOT EXISTS(SELECT * FROM sys.servers WHERE name = @HippaServerName)
	BEGIN
		EXECUTE sp_addlinkedserver @HippaServerName
		EXECUTE sp_addlinkedsrvlogin @HippaServerName, 'false', @HippaLoginUsername, @HippaLoginUsername, @HippaLoginPwd
	END
	
	DECLARE myCursor CURSOR  
	FOR
	SELECT GroupID FROM KYP.PDM_SpecialityGroup  WHERE Description LIKE '[0-9]%X'
	OPEN myCursor
	FETCH NEXT FROM  myCursor into @GroupID
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @Description = Description FROM KYP.PDM_SpecialityGroup WHERE GroupID = @GroupID
		
		SELECT @checkTaxonomyQuery = 'SELECT TOP 1 @Taxonomy = P_Taxonomy FROM [' + @HippaServerName + '].[' + @HippaDatabaseName + '].dbo.HIPPA_License
								      WHERE P_Taxonomy_Code = ''' + @Description + ''''
										  
		SET @ParmDefinition = '@Taxonomy VARCHAR(400) OUTPUT'
			
		EXECUTE sp_Executesql @checkTaxonomyQuery, @ParmDefinition, @Taxonomy = @retval OUTPUT;
													  
		IF (@retval IS NOT NULL)
		BEGIN
			UPDATE KYP.PDM_SpecialityGroup SET IdentifierDesc = @retval WHERE GroupID = @GroupID
		END		
		
	FETCH NEXT FROM  myCursor into @GroupID
	END
	CLOSE myCursor
	DEALLOCATE myCursor	
	
END


GO

