
CREATE VIEW [KYP].[v_WorkFlowOption] 
AS

SELECT ROW_NUMBER() OVER(order by RoleName) As ID,Z.* FROM (
SELECT DISTINCT RoleName ,CurrentMinorDisposition,[ReScreen],[SetReminderDate],[Consult],[Returned],[Reassign],[Escalate],[Suspended],[Resumed],[Reverted],[ScreeningDate] FROM (
SELECT X.RoleName,X.CurrentMinorDisposition,X.WFOptions,X.Privilege FROM (
Select RoleName,CurrentMinorDisposition,WFOptions,Privilege from KYP.OIS_WFOptions)X)Y
PIVOT (max(Privilege) 
	for WFOptions IN ([ReScreen],[SetReminderDate],[Consult],[Returned],[Reassign],[Escalate],
	[Suspended],[Resumed],[Reverted],[ScreeningDate])
)PWF 
)Z


GO

