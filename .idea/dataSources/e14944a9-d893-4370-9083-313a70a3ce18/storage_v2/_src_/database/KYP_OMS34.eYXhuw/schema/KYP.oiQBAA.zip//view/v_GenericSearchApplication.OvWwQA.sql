



CREATE VIEW [KYP].[v_GenericSearchApplication]
AS
SELECT DISTINCT A.CaseID
 ,D.Number AS Application
 ,D.AccountNo AS Provider
 ,D.DateReceived
 ,CASE 
  WHEN D.WFMinorStep = 'Pending Approval'
   THEN 'Approved'
  WHEN D.WFMinorStep = 'Pending Rejection'
   THEN 'Rejected'
  END AS ApplicationStatus
 ,D.ApplnTypeAlias as ApplnType
 ,CASE 
  WHEN D.Priority = 1
   THEN 'Limited'
  WHEN D.Priority = 2
   THEN 'Moderate'
  WHEN D.Priority = 3
   THEN 'High'
  END AS Risk
 ,CASE 
 WHEN
   D.TypeDescription IS NOT NULL
  THEN
  T.ProviderTypeCode + '-' + D.TypeDescription
  END AS ProviderTypeCodeFull
 ,ISNULL(B.NormalizedRisk, 0) AS CompositeRisk
 ,D.TypeDescription
 ,T.ProviderTypeCode
 ,D.ProviderName
 ,D.Provider_NPI AS ProviderNPI
 ,A.AKAName
 ,A.NPI
 ,A.SSN
 ,A.TIN
 ,A.LicenseCode
 ,A.Addresses
 ,D.WFStatus
 ,(
  SELECT U.FullName
  FROM KYP.OIS_Person U
  WHERE U.PersonID = D.CurrentlyAssignedToID
  ) AS Assignee
 ,D.CurrentlyAssignedToName AS UserID
 ,D.MILESTONE
 ,D.P_PRACT_TY_CD AS PracticeType
 ,D.DAYS_REMAINING
 ,CASE 
  WHEN D.DueDate IS NULL
   THEN ''
  WHEN D.DueDate IS NOT NULL
   THEN D.DueDate
  END AS DueDate
 ,A.City
 ,UPPER(A.STATE) AS STATE
 ,SUBSTRING(A.Zip,1,5) + SUBSTRING(A.Zip,7,4) as Zip
 ,U.LegacyAccountno 
 ,D.GenNo
FROM KYP.ADM_Case D
INNER JOIN KYP.ADM_Application B ON D.CaseID = B.CaseID
 AND D.IsPPURequired = 'false'
INNER JOIN KYP.SDM_ApplicationParty C ON C.ApplicationID = B.ApplicationID
 AND C.IsActive = 1
INNER JOIN KYP.GenericSearchApplication A ON D.CaseID = A.CaseID
LEFT JOIN KYP.v_PDMProviderType T ON T.ProviderTypeDescription = D.TypeDescription
LEFT JOIN KYPEnrollment.pADM_Account U ON D.AccountNo = U.AccountNumber
where D.IsPPURequired=0 AND D.WFProcessing=0

GO

