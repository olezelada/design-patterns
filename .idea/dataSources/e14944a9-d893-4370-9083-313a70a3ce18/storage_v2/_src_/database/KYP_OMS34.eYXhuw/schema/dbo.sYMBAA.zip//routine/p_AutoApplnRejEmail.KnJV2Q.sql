-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 03-Feb-2014
-- Description:	Automatic Application Rejection Email
-- =============================================
CREATE PROCEDURE [dbo].[p_AutoApplnRejEmail] 
	-- Add the parameters for the stored procedure here
	@FileName VARCHAR(200),
	@FileCreationDate DateTime
AS
BEGIN
	DECLARE 
		@body NVARCHAR(MAX),
		@EmailAddTo VARCHAR(500),		
		@EmailAddCC VARCHAR(500),
		@Sub VARCHAR(MAX),

		@ApplicationNum VARCHAR(8),
		@DailyFileName VARCHAR(100),
		@PostedDate VARCHAR(100),
		@ProviderName VARCHAR(200),
		@Reason VARCHAR(MAX),
		
		@State VARCHAR(2)
		
		
    /*INSERT INTO dbo.ProviderFile (FileName, FileCreationDate)
    VALUES (@FileName, @FileCreationDate)*/
    
    SELECT TOP 1 @State = StateCode FROM KYP.OIS_App_Version ORDER BY BuildNo DESC 
    SELECT @EmailAddTo = ReminderToMailID FROM KYP.MDM_ReminderMailID WHERE ReminderName = 'KYPAppRejEmailTo'
    SELECT @EmailAddCC = ReminderToMailID FROM KYP.MDM_ReminderMailID WHERE ReminderName = 'KYPAppRejEmailCC'
    

    
    /*Cursor to check only mandatory fields*/
    DECLARE myCursor CURSOR FOR
		SELECT case when [Column 2] is not null then [Column 2] when [Column 1] is not null then [Column 1]  
else [Column 2] end FROM dbo.ProviderStagingFull 
		WHERE ([Column 10] IS NULL OR LTRIM(RTRIM([Column 10])) = '') AND 
			  ([Column 11] IS NULL OR LTRIM(RTRIM([Column 11])) = '') AND 
			  ([Column 14] IS NULL OR LTRIM(RTRIM([Column 14])) = '') AND 
			  ([Column 15] IS NULL OR LTRIM(RTRIM([Column 15])) = '') 
    
    SET @Sub = 'Rejected Applications from ' + @State +' Server'	
    SET @ProviderName = 'Not Available'
    SET @Reason = 'Data is not available in any of the following mandatory fields
				   <br>
				   P_LAST_NAM, P_FST_NAM, P_NAM, P_DBA_LAST_NAM'
    
    OPEN myCursor
    FETCH NEXT FROM myCursor INTO @ApplicationNum
    WHILE @@FETCH_STATUS = 0
    BEGIN
		SET @body = '<html>
				<body>
				
				<font face="Cambria" size="2">The following application(s) have been automatically rejected for KYP screening due to a data format error.</font>
				<BR>
				<BR>
				<font face="Cambria" size="2">Please resolve the specified error and resubmit the application.</font>
				<BR>
				<BR>				
				<table border="1" cellpadding = 5 cellspacing = "">
				<tr>
					<td><b>	<font face="Cambria" size="2">Application #:</font></b></td>
					<td>    <font face="Cambria" size="2">'+  ISNULL(@ApplicationNum,'') + '</font>		</td>
				</tr>
				 <tr>
					<td><b>	<font face="Cambria" size="2">Daily File Name:</font>	</b></td>
	 				<td>    <font face="Cambria" size="2">'+ ISNULL(@FileName,'') +'</font></td>
				</tr>
				<tr>
					<td><b>	<font face="Cambria" size="2">Poster Date:</font>	</b></td>
					<td>    <font face="Cambria" size="2">'+ CONVERT(VARCHAR,ISNULL(@FileCreationDate,''),106) +' </font></td>
				</tr>
				<tr>
					<td><b>	<font face="Cambria" size="2">Provider Name:</font>	</b></td>
					<td>    <font face="Cambria" size="2">'+ ISNULL(@ProviderName,'') +'</font></td>
				</tr>
				<tr>
	  				<td><b>	<font face="Cambria" size="2">Reason:</font>	</b></td>
	  				<td>    <font face="Cambria" size="2">'+ISNULL(@Reason,'')+'</font></td>
				</tr>
				</table>
				<br>
				<br>
				
				<font face="Cambria" size="2">
				From, <br>
				Digital Harbor 
				<br>
				<br>
				This is a system generated message. Please do not reply.
				</font>
				</body>
				</html>'
    
    EXEC msdb.dbo.sp_send_dbmail
		@profile_name = 'administrator', -- replace with your SQL Database Mail Profile 
		@body = @body,
		@body_format ='HTML',		
		@recipients = @EmailAddTo,
		@copy_recipients = @EmailAddCC,
		@subject = @Sub ;
    
	FETCH NEXT FROM myCursor INTO @ApplicationNum	
    END
    CLOSE myCursor
	DEALLOCATE myCursor
    
END


GO

