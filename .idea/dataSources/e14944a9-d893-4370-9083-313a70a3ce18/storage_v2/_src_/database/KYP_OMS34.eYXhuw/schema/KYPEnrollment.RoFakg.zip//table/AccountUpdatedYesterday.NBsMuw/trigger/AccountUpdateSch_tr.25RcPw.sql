



--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		MD-4				Sundar		20-Jul-2017		Added Input Doc functionality for MD


CREATE TRIGGER [KYPEnrollment].[AccountUpdateSch_tr] ON [KYPEnrollment].[AccountUpdatedYesterday]

AFTER INSERT
AS
BEGIN
	Declare @accountid int,
	@username varchar(100),
	@userdate datetime,
	@AccountType varchar(100),
	@StateCode Varchar(2) --Added for #1 MD-4
	    
	set @accountid =(select AccountID from inserted)
	set @username=(select userName from inserted)
	set @userdate =(select convert(date,UserDate) from inserted)
	set @AccountType=(select AccountType from inserted)

	--Added for #1 MD-4
	Select @StateCode = StateCode
	From kyp.OIS_App_Version

	IF EXISTS(select 1 from KYPEnrollment.pADM_Account where AccountID=AccountID)/*adding if condition as create behviour is failing in application.*/
				AND @StateCode = 'CA' --Added for #1 MD-4
	BEGIN
		IF (@AccountType ='NMP')
			BEGIN
		
				Execute [KYPEnrollment].[sp_NMPBillingProvider_AccountInputDoc] @accountid,@username,@userdate;
			end
		else if(@AccountType='ORP')
			BEGIN
				--Execute [KYPEnrollment].[sp_update_AccountInputDoc_ORP] @accountid,@username,@userdate;
				Execute [KYPEnrollment].[Usp_IDoc_ORP] @accountid,@username,@userdate;
			end
		else
			BEGIN
				--Execute [KYPEnrollment].[sp_update_AccountInputDoc] @accountid,@username,@userdate;
				Execute [KYPEnrollment].[Usp_IDoc_Biller] @accountid,@username,@userdate;
			end
	END;
	
	--Added the If block for #1 MD-4
	IF @StateCode = 'MD'
	Begin
		Exec KYPEnrollment.Usp_MD_IDoc_Biller @accountid, @username;
	End;
  
END


GO

