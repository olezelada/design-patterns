
CREATE TRIGGER [dbo].[DeleteAppUserRole]
   ON  [dbo].[USERROLETABLE]
   FOR DELETE
AS 
BEGIN

	declare @userName varchar(50)
	select @userName = user_name from DELETED;
	
    delete from KYP.OIS_JT_UserRole where UserId = @userName 
        and RoleId in (select roleId from KYP.OIS_Role where RoleName in (select role_name from DELETED) )

END


GO

