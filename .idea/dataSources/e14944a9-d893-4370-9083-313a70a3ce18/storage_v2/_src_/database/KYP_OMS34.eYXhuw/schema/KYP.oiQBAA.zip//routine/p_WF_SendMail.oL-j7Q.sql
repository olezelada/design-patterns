

CREATE PROCEDURE [KYP].[p_WF_SendMail]
	@PersonID INT,
	@AlertNo VARCHAR(100),
	@ALIASNAME VARCHAR(200)
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @FullName VARCHAR(100),
			@Sub VARCHAR(100),
			@body VARCHAR(MAX),
			@EmailAddTo VARCHAR(150);
	
    SELECT @FullName = FullName FROM KYP.OIS_User WITH (NOLOCK) WHERE PersonID = @PersonID

	IF @FullName IS NOT NULL
	BEGIN
		SET @Sub = 'Alert# ' + @AlertNo + ' has been assigned to you in ' + @ALIASNAME + ' by ' + @FullName;
	END
	ELSE IF @FullName IS NULL
	BEGIN
		SET @Sub = 'Alert# ' + @AlertNo + ' has been assigned to you in ' + @ALIASNAME + ''
	END

	SET @body = '<html>
							<body>
							<table border="1" cellpadding = 5 cellspacing = "">
							  <tr>
								<td><b>	<font face="Cambria" size="2">Alert#:</font></b></td>
								<td>    <font face="Cambria" size="2">' + CONVERT(VARCHAR, @AlertNo) + ' </font>		</td>
							  </tr>
							  <tr>
									<td><b>	<font face="Cambria" size="2">Party Name:</font>	</b></td>
									<td>    <font face="Cambria" size="2">' + (SELECT WatchedPartyName FROM KYP.MDM_Alert WITH (NOLOCK) WHERE AlertNo = @AlertNo) + '</font></td>
							  </tr>
							  <tr>
									<td><b>	<font face="Cambria" size="2">Relevance:</font>	</b></td>
									<td>    <font face="Cambria" size="2">' + (SELECT Priority FROM KYP.MDM_Alert WITH (NOLOCK) WHERE AlertNo = @AlertNo) + ' </font></td>
							  </tr>
							  <tr>
									<td><b>	<font face="Cambria" size="2">Watchlist / Category:</font>	</b></td>
									<td>    <font face="Cambria" size="2">' + (SELECT WatchlistName FROM KYP.MDM_Alert WITH (NOLOCK) WHERE AlertNo = @AlertNo) + '</font></td>
							  </tr>
							</table>
							<br>
							
							</body>
						</html>'
	SET @EmailAddTo = (
			SELECT EmailID
			FROM KYP.OIS_User WITH (NOLOCK)
			WHERE PersonID = (
					SELECT AssignedToUserID
					FROM KYP.MDM_Alert WITH (NOLOCK)
					WHERE AlertNo = @AlertNo
					)
			)

	IF @EmailAddTo <> ''
		AND @EmailAddTo IS NOT NULL
	BEGIN
		EXEC msdb.dbo.sp_send_dbmail @profile_name = 'administrator'
			,-- replace with your SQL Database Mail Profile 
			@body = @body
			,@body_format = 'HTML'
			,@recipients = @EmailAddTo
			,
			--@copy_recipients = @EmailAddCC,
			@subject = @Sub;
	END
END


GO

