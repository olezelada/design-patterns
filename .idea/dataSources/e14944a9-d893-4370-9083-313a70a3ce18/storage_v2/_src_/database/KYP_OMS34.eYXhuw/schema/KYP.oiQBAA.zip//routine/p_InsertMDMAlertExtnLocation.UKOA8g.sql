/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertMDMAlertExtnLocation]
(@AlertID int
 ,@AddressID int
 ,@Type varchar(25)=NULL
 ,@Phone1 varchar(15) = NULL
 ,@Phone2 varchar(15)=NULL
 ,@Fax varchar(15)=NULL
 ,@Remarks varchar(250)=NULL
 ,@State varchar(25)=NULL
 ,@CreatedDate datetime=NULL
 ,@CreatedBy int=NULL
 ,@ModifiedDate datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedDate datetime=NULL
 ,@DeletedBy int=NULL
 ,@IsDeleted bit=NULL
)
as begin 

INSERT INTO [KYP].[MDM_AlertExtnLocation]
           ([AlertID]
           ,[AddressID]
           ,[Type]
           ,[Phone1]
           ,[Phone2]
           ,[Fax]
           ,[Remarks]
           ,[CreatedDate]
           ,[CreatedBy]
           ,[ModifiedDate]
           ,[ModifiedBy]
           ,[DeletedDate]
           ,[DeletedBy]
           ,[IsDeleted])
     VALUES
           (@AlertID
           ,@AddressID
           ,@Type
           ,@Phone1
           ,@Phone2
           ,@Fax
           ,@Remarks
           ,@CreatedDate
           ,@CreatedBy
           ,@ModifiedDate
           ,@ModifiedBy
           ,@DeletedDate
           ,@DeletedBy
           ,@IsDeleted)
	return IDENT_CURRENT('[KYP].[MDM_AlertExtnLocation]')

end


GO

