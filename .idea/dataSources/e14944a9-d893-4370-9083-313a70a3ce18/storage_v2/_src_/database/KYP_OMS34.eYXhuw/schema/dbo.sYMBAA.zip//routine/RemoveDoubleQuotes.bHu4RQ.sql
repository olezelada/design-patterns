-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RemoveDoubleQuotes] 
(
	@NameValue varchar(250)
)
RETURNS varchar(250)
AS
BEGIN
	--declare 
--@MyStr varchar(50)




select @NameValue =REPLACE(@NameValue,CHAR(34),'')



return @NameValue


END


GO

