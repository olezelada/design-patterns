
-- =============================================
-- Author:		<Author,,Lperez>
-- inserta la un identificador para un moca que no hacido encontrado
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Create_UniqueParty]
	@ein varchar(10),
	@ssn varchar(10),
	@businessType varchar(50),
	@busEntityTypeInde varchar(30),
	@businessLegalName varchar(150),
	@lastName varchar(50),
	@middleName varchar(50),
	@fistName varchar(50),
	@dob smalldatetime,	
	@lastActionUserID varchar(100)
AS
BEGIN
    DECLARE @dateCreated date,
			@uniqueParty int
    	
	SET @dateCreated = GETDATE()	
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
	([EIN]
	,[SSN]
	,[BusinessType]
	,[BusinessEntityTypeIdentifier]
	,[BusinessLegalName]
	,[BusinessDBAName]
	,[LastName]
	,[MiddleName]
	,[FistName]
	,[DOB]
	,[LastAction]
	,[LastActorUserID]
	,[LastActionDate]
	,[LastActionApprovedByUsedId])
	VALUES
	(@ein
	,@ssn
	,@businessType
	,@busEntityTypeInde
	,@businessLegalName
	,@businessLegalName
	,@lastName
	,@middleName 
	,@fistName 
	,@dob 
	,'C'
	,@lastActionUserID
	,@dateCreated
	,@lastActionUserID)
	
	SET @uniqueParty = Scope_Identity()	
	
	return @uniqueParty
END


GO

