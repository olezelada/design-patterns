








CREATE VIEW [KYPEnrollment].[view_SubContractorTaxIdProfile]
AS
SELECT row_number() over (order by PartyID DESC) AS ViewID, result.*
		FROM(
			SELECT party.PartyID, party.Type, 
				case when party.Type = 'SubcontractorIndividual' then person.PersonID  else org.OrgID end as MocaID, 
				case when party.Type = 'SubcontractorIndividual' then person.FirstName  else org.LegalName end as  FirstName,
				case when party.Type = 'SubcontractorIndividual' then person.LastName else '' end as LastName,
				case when party.Type = 'SubcontractorIndividual' then person.MiddleName else '' end as MiddleName, 
				case when party.Type = 'SubcontractorIndividual' then (person.FirstName + ' ' +  person.LastName) else org.LegalName  end as legalName,
				
				case when ISNULL(party.Type,'') = 'SubcontractorIndividual' then
						COALESCE(LTRIM(RTRIM(NULLIF( person.Phone1,''))),'NA')
					when ISNULL(party.Type,'') = 'SubcontractorEntity' then
						COALESCE(LTRIM(RTRIM(NULLIF( org.Phone1,''))),'NA')
					else 'NA'  end as PhoneNumber
				,COALESCE(LTRIM(RTRIM(NULLIF( T.Description,''))),'NA')as Description
				,COALESCE(LTRIM(RTRIM(NULLIF( T.Amount,''))),'NA')as Amount
				,COALESCE(LTRIM(RTRIM(NULLIF( A.AddressLine1,''))),'NA')as AddressLine1 
				,COALESCE(LTRIM(RTRIM(NULLIF( A.AddressLine2,''))),'NA')as AddressLine2 
				,COALESCE(LTRIM(RTRIM(NULLIF( A.City,''))),'NA')as City 
				,COALESCE(LTRIM(RTRIM(NULLIF( A.STATE,''))),'NA')as STATE
				,COALESCE(LTRIM(RTRIM(NULLIF( A.County,''))),'NA')as County 
				,COALESCE(LTRIM(RTRIM(NULLIF( A.ZipPlus4,''))),'NA')as ZipPlus4 
				,COALESCE(LTRIM(RTRIM(NULLIF( R.PercentValue,''))),'NA')as PercentValue 
				,COALESCE(LTRIM(RTRIM(NULLIF( R.OtherValue,''))),'NA')as Title 
				,COALESCE(LTRIM(RTRIM(NULLIF( org.EIN,''))),'NA')as TIN 
				,COALESCE(LTRIM(RTRIM(NULLIF( org.OrgNumber,''))),'NA')as CorporateNumber,
				A.AddressID,
				L.LocationID,
				taxIdProfile.taxID,
				taxIdProfile.profileID,
				taxIdProfile.taxIDprofileID

			FROM
				KYPEnrollment.pAccount_PDM_Party party
				LEFT JOIN KYPEnrollment.TaxIDProfile taxIdProfile ON party.taxIDprofileID = taxIdProfile.taxIDprofileID
				
				LEFT JOIN KYPEnrollment.pAccount_PDM_Person person on party.PartyID = person.PartyID  
				LEFT JOIN KYPEnrollment.pAccount_PDM_Organization org on party.PartyID = org.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role R ON party.PartyID = R.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction T ON party.PartyID = T.PartyID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Location L ON party.PartyID = L.PartyID and L.CurrentRecordFlag = 1
				LEFT JOIN KYPEnrollment.pAccount_PDM_Address A ON L.AddressID = A.AddressID
			WHERE
				
				 party.IsDeleted = 0 AND party.CurrentRecordFlag = 1 AND (party.taxIDprofileID is not null AND party.taxIDprofileID <> '')
				 AND (party.MOCARelationshipEndDate IS NULL OR party.MOCARelationshipEndDate > GETDATE())
				 and ((party.Type = 'SubcontractorIndividual' and person.Deleted=0) or (party.Type = 'SubcontractorEntity' and org.IsDeleted=0 ))  
		)
		AS result


GO

