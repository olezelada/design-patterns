


CREATE VIEW [KYP].[v_DocSearch]
AS
--Getting All document related to Accounts
Select 'Account' as DocRelatedTo ,
case
WHEN ois.Type is null THEN ois.Title--Made changes for MD-1348
WHEN ois.Type='EnrollmentResolution' THEN 'Resolution Document'
else ois.Type
END as DocumentType,

case
WHEN ois.Title is null THEN 'Others'
else ois.Title
END as DocumentTitle,
ois.Created as DocumentSubmission,ac.AccountNumber as AppAccNo,
case
WHEN ac.LegacyAccountNo is null THEN 'N/A'
else ac.LegacyAccountNo
END as ProviderID,
ac.LegalName as ProviderName, ac.NPI as NPI,ac.SSN,ac.TIN as TaxID,ois.DMSID 
from kyp.ois_attachment ois inner join KYP.AttachmentEntity ae on ois.AttachmentID=ae.AttachmentID --and ae.AttachmentEntityType='pADM_Account' and ois.deleted=0
inner join KYPEnrollment.pADM_Account ac on ae.AttachmentEntityTypeID=ac.AccountID
where ae.AttachmentEntityType='pADM_Account' and ois.deleted=0 --and ac.AccountNumber='800090124'

union

--Getting All document related to Accounts from portal
--Added for MD-1334
Select 'Account' as DocRelatedTo ,
case
WHEN ois.Type is null THEN ois.Title--Made changes for MD-1348
WHEN ois.Type='EnrollmentResolution' THEN 'Resolution Document'
else ois.Type
END as DocumentType,

case
WHEN ois.Title is null THEN 'Others'
else ois.Title
END as DocumentTitle,
ois.Created as DocumentSubmission,ac.AccountNumber as AppAccNo,
case
WHEN ac.LegacyAccountNo is null THEN 'N/A'
else ac.LegacyAccountNo
END as ProviderID,
ac.LegalName as ProviderName, ac.NPI as NPI,ac.SSN,ac.TIN as TaxID,ois.DMSID 
from kyp.ois_attachment ois 
inner join KYPEnrollment.pADM_Account ac on ois.FolderPath=ac.AccountNumber
where ois.FolderPath is not null and ois.deleted=0-- and ac.AccountNumber='800090124'

union

--Getting All document related to Application from enrollment
Select  'Application' as DocRelatedTo ,
case
WHEN ois.Type is null THEN 'Others'
WHEN ois.Type='EnrollmentResolution' THEN 'Resolution Document'
else ois.Type
END as DocumentType,

case
WHEN ois.Title is null THEN 'Others'
else ois.Title
END as DocumentTitle,


ois.Created as DocumentSubmission,ac.Number as AppAccNo,
case
WHEN U.LegacyAccountNo is null THEN 'N/A'
else U.LegacyAccountNo
END as ProviderID,

ac.ProviderName as ProviderName, ac.Provider_NPI as NPI,a.SSN as SSN,a.TIN as TaxID,ois.DMSID  
from kyp.ois_attachment ois inner join
KYP.AttachmentEntity ae on ois.AttachmentID=ae.AttachmentID
inner join KYP.ADM_Case ac on ae.AttachmentEntityTypeID=ac.CaseID 
inner join KYP.ADM_Application ap on ap.CaseID=ac.CaseID and ac.IsPPURequired='false'
inner join KYP.SDM_ApplicationParty sa on sa.ApplicationID=ap.ApplicationID and sa.IsActive=1
inner JOIN KYP.GenericSearchApplication a ON ac.CaseID = A.CaseID
LEFT JOIN KYPEnrollment.pADM_Account U ON ac.AccountNo = U.AccountNumber
where ac.IsPPURequired=0 and (ois.deleted=0 or ois.deleted is null) --Made changes for MD-1373



union 
--Getting all document related to application from PORTAL
Select 'ApplicationPortal' as DocRelatedTo, 
case
WHEN ois.NameDocument is null THEN 'Others'
else ois.NameDocument
END as DocumentType,
case
WHEN ois.NameDocument is null THEN 'Others'
else ois.NameDocument
END as DocumentTitle,
ois.dateCreated as DocumentSubmission,ac.Number 
as AppAccNo,
case
WHEN pac.LegacyAccountNo is null THEN 'N/A'
else pac.LegacyAccountNo
END as ProviderID,
ac.ProviderName as ProviderName,ae.NPI,REPLACE(per.SSN, '-', '') as SSN,REPLACE(po.EIN,'-','') as TaxID,ois.DMSID                                  
from  KYPEnrollment.pEDM_ReviewDocument ois--KYPPORTAL.PortalKYP.pApplicationDocumentFile ois 
inner join KYPPORTAL.PortalKYP.pADM_Application ae on ois.applicationId=ae.ApplicationID
inner join KYPPORTAL.PortalKYP.pADM_Case ac on ae.CaseID=ac.CaseID
left join KYP.ADM_Case eac on ac.Number=eac.Number and eac.IsPPURequired=0 and eac.WFProcessing is not null
left join KYPEnrollment.pADM_Account pac on pac.AccountNumber=eac.AccountNo--Made changes for MD-1328
left join KYPPORTAL.PortalKYP.pPDM_Person per on ae.PartyID=per.PartyID 
left join KYPPORTAL.PortalKYP.pPDM_Organization po on ae.PartyID=po.PartyID
where ois.isDeleted=0 and  ois.NameDocument!=''


GO

