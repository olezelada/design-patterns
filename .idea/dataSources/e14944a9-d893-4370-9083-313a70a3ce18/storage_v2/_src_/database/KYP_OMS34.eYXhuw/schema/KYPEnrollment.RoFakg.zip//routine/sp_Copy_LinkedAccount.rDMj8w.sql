
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Linked Account.   
-- PARAMETERS: 
-- @account_id : AccountID that will be create. 
-- @linked_with_account_id : AccountID having similarities. 
-- @link_type : Type of Linked.
-- @linking_remarks : Remarks to Linked. 
-- @last_actor_user_id : Enrollemt user. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_LinkedAccount]
	@account_id INT,
	@linked_with_account_id INT,
	@link_type VARCHAR(10),
	@linking_remarks VARCHAR(100),
	@last_actor_user_id VARCHAR(100)	
AS
BEGIN
    SET NOCOUNT ON
	DECLARE @date_created DATE,@linked_account_id INT
	
	SET @date_created = GETDATE();
	
	INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
	([AccountID]
	,[LinkedWithAccountID]
	,[LinkType]
	,[LinkingRemarks]
	,[LastAction]
	,[LastActionDate]
	,[LastActorUserID]
	,[LastActionApprovedBy]
	,[CurrentRecordFlag])
	VALUES(
	@account_id,
	@linked_with_account_id,
	@link_type,
	@linking_remarks,
	'C',
	@date_created,
	@last_actor_user_id,
	@last_actor_user_id,
	1)
	
	SELECT @linked_account_id = SCOPE_IDENTITY();	
	
	PRINT 'New linked Account : '+CONVERT(VARCHAR(10), @linked_account_id);
	RETURN @linked_account_id
END


GO

