
-- =============================================
-- Author:		Vinoth
-- Create date: 18th June 2014
-- Description:	To get the number in words below twenty
-- =============================================
CREATE FUNCTION [KYP].[numberToWords] 
(
	@Number INT
)
RETURNS VARCHAR(1024)
AS
BEGIN

	DECLARE @InwWords VARCHAR(1024)

	SET @InwWords =
	(
		SELECT CASE
		WHEN @Number BETWEEN 1 AND 19
		THEN (SELECT KYP.valuesBelowTwenty(@Number))
		WHEN @Number BETWEEN 20 AND 99 
		THEN (SELECT KYP.valuesBelowhundred(@Number/10))+ ' ' + KYP.numberToWords( @Number % 10)
		--WHEN @Number BETWEEN 100 AND 999 
		--THEN (KYP.numberToWords( @Number / 100))+' Hundred '+ KYP.numberToWords( @Number % 100)
		--WHEN @Number BETWEEN 1000 AND 99999 
		--THEN (KYP.numberToWords( @Number / 1000))+' Thousand '+ KYP.numberToWords( @Number % 1000) 
		--WHEN @Number BETWEEN 100000 AND 9999999 
		--THEN (KYP.numberToWords( @Number / 100000))+' Lac '+ KYP.numberToWords( @Number % 100000)
		--WHEN @Number >= 10000000 
		--THEN (KYP.numberToWords( @Number / 10000000))+' Crore '+ KYP.numberToWords( @Number % 10000000)
		ELSE 'ZERO' END
	)
	
	SELECT @InwWords = RTRIM(@InwWords)
	SELECT @InwWords = RTRIM(LEFT(@InwWords,len(@InwWords)-1)) WHERE RIGHT(@InwWords,1)=' '
	
	RETURN (UPPER(@InwWords))
END


GO

