


/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Unique Party Account.   
-- PARAMETERS:  
-- @party_account_id : partyID Account that will be Associate. 
-- @new_account_id : partyID to new Account that will be create.
-- @npi_type : NIP typr to new Account.  
-- @last_Action_User_Id : this is the user Enrollment.
-- @is_update : Flag if process Update or Create unique Party.  
-- ============================================================*/


CREATE PROCEDURE [KYPEnrollment].[sp_Create_Unique_Party_Account_new]
@party_account_id INT,
@new_account_id INT,
@npi_type VARCHAR(100),
@last_action_user_id VARCHAR(100),
@is_update BIT
AS
BEGIN
	DECLARE
		@count INT,
		@uniqueParty INT,
		@unique_party_old INT,
		@unique_party_account INT,
		@dateCreated DATE,
		@unincorpSoleProprietor VARCHAR(150),
		@firstName VARCHAR(150),
		@lastName VARCHAR(150),	
		@middlename VARCHAR(150),
		@dob SMALLDATETIME,
		@ssn VARCHAR(12),
		@legalName VARCHAR(150),		
		@EIN VARCHAR(12),
		@dBAName NVARCHAR(150)
		
		SET @dateCreated = GETDATE()
		
		SELECT TOP 1 @lastName =  LastName, @firstName = FirstName , @ssn = SSN, @middlename=ISNULL(MiddleName,''), @dob=DoB
		FROM [KYPEnrollment].[pAccount_PDM_Person] WHERE PartyID = @party_account_id
				
		
		SELECT @legalName=LegalName, @EIN=EIN, @dBAName=ISNULL(DBAName1,'')
		FROM [KYPEnrollment].[pAccount_PDM_Organization] WHERE PartyID = @party_account_id
		
		SELECT @unincorpSoleProprietor =NameEntityType FROM [KYPEnrollment].[pAccount_PDM_EntityType] WHERE PartyID = @party_account_id

		SET @ssn = replace(@ssn,'-','')
		SET @EIN = replace(@EIN,'-','')
	
	IF(@is_update = 0)
	BEGIN
		IF(@npi_type='Individual')
		BEGIN		
			SET @uniqueParty = 0
				
			SELECT TOP 1 @uniqueParty = UniquePartyID
			FROM [KYPEnrollment].[pAccount_UniqueParty] 
			Where LastName = @lastName AND  FistName = @firstName AND SSN = @ssn
			
			IF(@uniqueParty=0)
			BEGIN

				--EXECUTE @uniqueParty = [KYPEnrollment].[sp_Create_UniqueParty] @EIN, @ssn, @unincorpSoleProprietor,@legalName, @lastName, @middlename, @firstName, @dob, @last_action_user_id;			
			
				INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
				([EIN]
				,[SSN]
				,[BusinessType]
				,[BusinessLegalName]
				,[BusinessDBAName]
				,[LastName]
				,[MiddleName]
				,[FistName]
				,[DOB]
				,[LastAction]
				,[LastActorUserID]
				,[LastActionDate]
				,[LastActionApprovedByUsedId])
				VALUES
				(@ein
				,@ssn
				,@unincorpSoleProprietor
				,@legalName
				,@legalName
				,@lastname
				,@middlename 
				,@firstname 
				,@dob 
				,'C'
				,@last_action_user_id
				,GETDATE()
				,@last_action_user_id)
	
				SET @uniqueparty = SCOPE_IDENTITY()	
	
	
			--
			
			END
				--EXECUTE [KYPEnrollment].[sp_Create_UniquePartyAccount] @new_account_id, @uniqueParty, 'TRUE';
				--
			
				INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
				([AccountID]
				,[UniquePartyID]
				,[CurrentRecordFlag])
				VALUES
				( @new_account_id
				,@uniqueParty
				,'TRUE')
		
		END	
		IF(@npi_type='Organization')
		BEGIN	
			SET @uniqueParty = 0
			SELECT TOP 1  @uniqueParty = ISNULL(UniquePartyID,0)
			FROM [KYPEnrollment].[pAccount_UniqueParty] 
			WHERE (0.98<=(select f.Score from [dbo].[CompareStringMetrics](BusinessLegalName ,@legalName) f where f.metric='JaroWinkler'))
			AND EIN = @EIN
			
			IF(@uniqueParty=0)
			BEGIN
				--EXECUTE @uniqueParty = [KYPEnrollment].[sp_Create_UniqueParty] @EIN, NULL, @unincorpSoleProprietor,@legalName, NULL, NULL, NULL, NULL, @last_action_user_id
			--
			INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
				([EIN]
				,[SSN]
				,[BusinessType]
				,[BusinessLegalName]
				,[BusinessDBAName]
				,[LastName]
				,[MiddleName]
				,[FistName]
				,[DOB]
				,[LastAction]
				,[LastActorUserID]
				,[LastActionDate]
				,[LastActionApprovedByUsedId])
				VALUES
				(@ein
				,NULL
				,@unincorpSoleProprietor
				,@legalName
				,@legalName
				,NULL
				,NULL 
				,NULL 
				,NULL 
				,'C'
				,@last_action_user_id
				,GETDATE()
				,@last_action_user_id)
	
				SET @uniqueparty = SCOPE_IDENTITY()	
			
			
			END
				--EXECUTE [KYPEnrollment].[sp_Create_UniquePartyAccount] @new_account_id, @uniqueParty, 'TRUE';	
				--
				INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
				([AccountID]
				,[UniquePartyID]
				,[CurrentRecordFlag])
				VALUES
				( @new_account_id
				,@uniqueParty
				,'TRUE')
		END
		PRINT 'Create Unique Party'
	END
	IF(@is_update = 1)
	BEGIN
		SELECT @unique_party_old= UniquePartyID, @unique_party_account= UniquePartyAccountID 
		FROM [KYPEnrollment].[pAccount_UniqueParty_Account] WHERE AccountID=@new_account_id		
		IF(@npi_type='Individual')
		BEGIN		
			SET @uniqueParty = 0
				
			SELECT TOP 1 @uniqueParty = UniquePartyID                                                                                                              
			FROM [KYPEnrollment].[pAccount_UniqueParty] 
			Where LastName = @lastName AND  FistName = @firstName AND SSN = @ssn	
					
			IF(@unique_party_old <> @uniqueParty)
			BEGIN
				IF(@uniqueParty=0)
				BEGIN
					--EXECUTE @uniqueParty = [KYPEnrollment].[sp_Create_UniqueParty] @EIN, @ssn, @unincorpSoleProprietor, @legalName, @lastName, @middlename, @firstName, @dob, @last_action_user_id;								
				   --
				   INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
				([EIN]
				,[SSN]
				,[BusinessType]
				,[BusinessLegalName]
				,[BusinessDBAName]
				,[LastName]
				,[MiddleName]
				,[FistName]
				,[DOB]
				,[LastAction]
				,[LastActorUserID]
				,[LastActionDate]
				,[LastActionApprovedByUsedId])
				VALUES
				(@ein
				,@ssn
				,@unincorpSoleProprietor
				,@legalName
				,@legalName
				,@lastname
				,@middlename 
				,@firstname 
				,@dob 
				,'C'
				,@last_action_user_id
				,GETDATE()
				,@last_action_user_id)
	
				SET @uniqueparty = SCOPE_IDENTITY()	
	
				
				END
				
				--EXECUTE [KYPEnrollment].[sp_Create_UniquePartyAccount] @new_account_id, @uniqueParty, 'TRUE';
				--
				INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
				([AccountID]
				,[UniquePartyID]
				,[CurrentRecordFlag])
				VALUES
				( @new_account_id
				,@uniqueParty
				,'TRUE')	
				UPDATE [KYPEnrollment].[pAccount_UniqueParty_Account] SET CurrentRecordFlag = 0 where UniquePartyAccountID=@unique_party_account
			
							
			END	
		END	
		IF(@npi_type='Organization')
		BEGIN				
			SET @uniqueParty = 0
			
			SELECT TOP 1  @uniqueParty = ISNULL(UniquePartyID,0)
			FROM [KYPEnrollment].[pAccount_UniqueParty] 
			WHERE (0.98<=(select f.Score from [dbo].[CompareStringMetrics](BusinessLegalName ,@legalName) f where f.metric='JaroWinkler'))
			AND EIN = @EIN
			
			IF(@unique_party_old <> @uniqueParty)
			BEGIN
				IF(@uniqueParty=0)
				BEGIN					
					--EXECUTE @uniqueParty = [KYPEnrollment].[sp_Create_UniqueParty] @EIN, NULL, @unincorpSoleProprietor,@legalName, NULL, NULL, NULL, NULL, @last_action_user_id			
				    --
				    INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
				([EIN]
				,[SSN]
				,[BusinessType]
				,[BusinessLegalName]
				,[BusinessDBAName]
				,[LastName]
				,[MiddleName]
				,[FistName]
				,[DOB]
				,[LastAction]
				,[LastActorUserID]
				,[LastActionDate]
				,[LastActionApprovedByUsedId])
				VALUES
				(@ein
				,NULL
				,@unincorpSoleProprietor
				,@legalName
				,@legalName
				,NULL
				,NULL 
				,NULL 
				,NULL 
				,'C'
				,@last_action_user_id
				,GETDATE()
				,@last_action_user_id)
	
				SET @uniqueparty = SCOPE_IDENTITY()	
				END
				UPDATE [KYPEnrollment].[pAccount_UniqueParty_Account] SET CurrentRecordFlag = 0 where UniquePartyAccountID=@unique_party_account
				--EXECUTE [KYPEnrollment].[sp_Create_UniquePartyAccount] @new_account_id, @uniqueParty, 'TRUE';
				
				INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
				([AccountID]
				,[UniquePartyID]
				,[CurrentRecordFlag])
				VALUES
				( @new_account_id
				,@uniqueParty
				,'TRUE')
				
			
			END
		END
		PRINT 'Update Unique Party';
	END
END


GO

