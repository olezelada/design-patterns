
CREATE view [KYP].[v_MoratoriumAppReport] As
	--SELECT 
--	DISTINCT
--	C.CaseID As RID,
--	C.CaseID,
--	C.Number As ApplicationNumber,	
--	REPLACE(LTRIM(RTRIM(ISNULL(C.ApplnTypeAlias,'NA'))),'','NA') As ApplicationType,
--	REPLACE(LTRIM(RTRIM(ISNULL(C.ProviderName,'NA'))),'','NA') As ProviderName,
--	REPLACE(LTRIM(RTRIM(ISNULL(C.TypeDescription,'NA'))),'','NA') As ProviderType,
--	REPLACE(LTRIM(RTRIM(ISNULL(C.Provider_NPI,'NA'))),'','NA') As NPI,
--	REPLACE(LTRIM(RTRIM(ISNULL(C.UserFullName,'NA'))),'','NA') As AssignedToReviewer,
--	CASE WHEN R.IsExempt = 0 THEN 'Reject' ELSE 'Exempt' END  As MoratoriumDecision,
--	REPLACE(LTRIM(RTRIM(ISNULL(D.County,'NA'))),'','NA') As MoratoriumCountry,
--	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(C.DateReceived as date), 101),''))),'NA') As ApplicationReceivedDate,
--	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(R.MoratoriaDecisionDate as date), 101),''))),'NA') As MoratoriumDecisionDate
--FROM 
--	KYP.ADM_Case C INNER JOIN KYPEnrollment.PortalAddress D on C.CaseID = D.EnrollCaseID
--	LEFT JOIN KYP.ADM_CaseExtended R on C.CaseID = R.CaseID 
--WHERE
--	D.Type='Servicing' 
--	AND C.IsMoratoria = 'true' 
--	--AND IsExempt IS NOT NULL

	SELECT DISTINCT
		C.CaseID As RID,
		C.CaseID,
		C.Number As ApplicationNumber,	
		REPLACE(LTRIM(RTRIM(ISNULL(C.ApplnTypeAlias,'NA'))),'','NA') As ApplicationType,
		REPLACE(LTRIM(RTRIM(ISNULL(C.ProviderName,'NA'))),'','NA') As ProviderName,
		REPLACE(LTRIM(RTRIM(ISNULL(C.TypeDescription,'NA'))),'','NA') As ProviderType,
		REPLACE(LTRIM(RTRIM(ISNULL(C.Provider_NPI,'NA'))),'','NA') As NPI,
		REPLACE(LTRIM(RTRIM(ISNULL(C.UserFullName,'NA'))),'','NA') As AssignedToReviewer,
		CASE WHEN R.IsExempt = 0 THEN 'Reject' ELSE 'Exempt' END  As MoratoriumDecision,
		REPLACE(LTRIM(RTRIM(ISNULL(Addr.County,'NA'))),'','NA') As MoratoriumCountry,
		COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(C.DateReceived as date), 101),''))),'NA') As ApplicationReceivedDate,
		COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(R.MoratoriaDecisionDate as date), 101),''))),'NA') As MoratoriumDecisionDate
		FROM KYP.ADM_Case C LEFT JOIN KYP.ADM_CaseExtended R ON C.CaseID = R.CaseID
		LEFT JOIN KYPPORTAL.PortalKYP.pADM_Application KPA ON C.Number = KPA.ApplicationNo
		INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location Loc ON Loc.PartyID = KPA.PartyID
		INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address Addr ON Addr.AddressID = Loc.AddressID
	WHERE 
		Loc.Type = 'Servicing' AND 
		C.IsMoratoria = 1
GO

