
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: 
-- PARAMETERS: 

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Create_Moca_TaxId]
@party_id INT,
@type VARCHAR(20),
@moca_name VARCHAR(150),
@party_provider_id INT

AS
BEGIN
SET NOCOUNT ON 
PRINT'[Create_Moca_TaxId]'
INSERT INTO [KYPEnrollment].[pAccount_Moca_TaxID_Associate]
           ([PartyID],
			 [MocaName],
			 [Type],
			 [IdentityTaxID],
			 [CurrentRecordFlag])
     VALUES
           (@party_id
           ,@moca_name
           ,@type
           ,@party_provider_id
           ,1)

END


GO

