--Audit Team View
CREATE VIEW [KYP].[OIS_View_AuditTeam] 
AS
SELECT
  NEWID() as UniqueID, 
  --ateam.AuditTeamID,
  ateam.UserID,
  ateam.CaseID,
  CAST(MAX(CAST(atr.ViewAuditData as INT)) AS BIT) AS ViewAuditData,
  CAST(MAX(CAST(atr.PrintAuditData as INT)) AS BIT) AS PrintAuditData,
  CAST(MAX(CAST(atr.PrintWP as INT)) AS BIT) AS PrintWP,
  CAST(MAX(CAST(atr.ExportWP as INT)) AS BIT) AS ExportWP,
  CAST(MAX(CAST(atr.AddDataToWorkOfSelf as INT)) AS BIT) AS AddDataToWorkOfSelf,
  CAST(MAX(CAST(atr.ModifyDataOfSelf as INT)) AS BIT) AS ModifyDataOfSelf,
  CAST(MAX(CAST(atr.ModifyDataOfOthersExludingAdmin as INT)) AS BIT) AS ModifyDataOfOthersExludingAdmin,
  CAST(MAX(CAST(atr.AddDataToWorkOfOthers as INT)) AS BIT) AS AddDataToWorkOfOthers,
  CAST(MAX(CAST(atr.CreateAudit as INT)) AS BIT) AS CreateAudit,
  CAST(MAX(CAST(atr.ExportAuditData as INT)) AS BIT) AS ExportAuditData,
  CAST(MAX(CAST(atr.AddReviewerNotesOnly as INT)) AS BIT) AS AddReviewerNotesOnly,
  CAST(MAX(CAST(atr.ModifyReviewerNotesOfSelf as INT)) AS BIT) AS ModifyReviewerNotesOfSelf,
  CAST(MAX(CAST(atr.DeleteDataOfSelf as INT)) AS BIT) AS DeleteDataOfSelf,
  CAST(MAX(CAST(atr.DeleteDataOfOthers as INT)) AS BIT) AS DeleteDataOfOthers,
  CAST(MAX(CAST(atr.AssignAudit as INT)) AS BIT) AS AssignAudit,
  CAST(MAX(CAST(atr.ReAssignAudit as INT)) AS BIT) AS ReAssignAudit,
  CAST(MAX(CAST(atr.AddTeam as INT)) AS BIT) AS AddTeam,
  CAST(MAX(CAST(atr.DeleteTeam as INT)) AS BIT) AS DeleteTeam,
  CAST(MAX(CAST(atr.LockAudit as INT)) AS BIT) AS LockAudit,
  CAST(MAX(CAST(atr.ModifyDataAll as INT)) AS BIT) AS ModifyDataAll
  /**/
FROM 
  KYP.OIS_AuditTeam as ateam, KYP.OIS_AuditTeamRole as atr
WHERE 
	ateam.AuditTeamRoleID = atr.AuditTeamRoleID
and	ateam.[Active]=1
group by ateam.UserID, ateam.CaseID


GO

