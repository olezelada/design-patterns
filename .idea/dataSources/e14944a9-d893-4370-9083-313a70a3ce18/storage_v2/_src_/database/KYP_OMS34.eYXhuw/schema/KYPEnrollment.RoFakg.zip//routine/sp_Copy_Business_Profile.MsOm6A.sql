
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Business Profile form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Profile]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON 
DECLARE @org_id INT,@date_created DATE;
SET @date_created =  GETDATE();

EXEC @org_id = [KYPEnrollment].[sp_Copy_Organization] @party_account_id,@party_app_id,@last_action_user_id;

INSERT INTO [KYPEnrollment].[pAccount_PDM_EntityType]
           ([PartyID]
           ,[NameEntityType]
           ,[TypeProfit]
           ,[CorporateNumber]
           ,[StateIncorporated]
           ,[LlcNumber]
           ,[StateRegistered]
           ,[TypeNonProfit]
           ,[Other]
           ,[DateCreated]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
           
 SELECT		@party_account_id
           ,[NameEntityType]
           ,[TypeProfit]
           ,[CorporateNumber]
           ,[StateIncorporated]
           ,[LlcNumber]
           ,[StateRegistered]
           ,[TypeNonProfit]
           ,[Other]
           ,@date_created
           ,[IsDeleted]
           ,'C'
           ,@date_created
           ,@last_action_user_id
           ,@last_action_user_id
           ,1  
 FROM [KYPPORTAL].[PortalKYP].[pADM_App_EntityType] WHERE PartyID=@party_app_id
 
EXEC [KYPEnrollment].[sp_Copy_Number] @party_account_id, @party_app_id, @last_action_user_id, NULL;
 
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
           ([PartyID]
           ,[Type]
           ,[CreatedBy]
           ,[DateCreated]
           ,[IsDeleted]
           ,[Number]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
 SELECT    @party_account_id
           ,[LicenseType]
           ,[CreatedBy]
           ,@date_created
           ,[IsDeleted]
           ,[LicenseCode]
           ,'C'
           ,@date_created
           ,@last_action_user_id
           ,@last_action_user_id
           ,1

 FROM [KYPPORTAL].[PortalKYP].[pPDM_License] WHERE PartyID=@party_app_id                             

PRINT 'New Organization '+ CONVERT(VARCHAR(10),@org_id)+' Business Profile';
RETURN @org_id;
END


GO

