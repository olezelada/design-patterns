

-- =============================================
-- Author:		<Rahul Raghavendra>
-- Create date: <21/09/2016>
-- Description:	<Issue Number:PI-595>
--*1: Status Effective Date is empty in Status Table so fetching it from pADM_Account.
/*PI-680*/
--/*2*/ Re enrollment Indicator and its date are corrected by getting from KYPEnrollment.EDM_AccountInternalUse
--/*2*/ When status end date is null it is set to 2069/12/31
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1															Status Effective Date is empty in Status Table so fetching it from pADM_Account.
-- 2		PI-680												Re enrollment Indicator and its date are corrected by getting from KYPEnrollment.EDM_AccountInternalUse and When status end date is null it is set to 2069/12/31
-- 3		CAPAVE-1284,1285	Sundar		17-Feb-2017			Added pAccount_RenderingAffiliation.LastActorUserID <> 'System' condition to ignore Delta changes
-- 4		PI-785				Sundar		28-Apr-2017			Introduced color changes for Rend. NPI
-- 5		CAPAVE-1753			Sundar		03-Jul-2017			Changed the logic for Reviewer, Supervisor and Confirmer fields
-- 6		PI-813				Sundar		11-Jul-2017			Changed the logic for highlighting AffiliationStartDate by considering LastActionDate 
-- 7		PI-814				Sundar		12-Jul-2017			Added the default date, when AffiliationEndDate is null
-- 8		KEN-12837			Sundar		23-Aug-2017			Implemented PAVE 3.0 changes for Input Document
-- 9		PI-831				Sundar		1-Sep-2017			Renamed the fields to fix the alignment issue
-- 10		PI-834				Sundar		2-Sep-2017			Changed the logic for Status Begin Date
-- 11		PI-845				Sundar		4-Sep-2017			Changed the logic for Service and Mailing address
-- 12		PI-844				Sundar		8-Sep-2017			Changed the query for PI-844 
-- 13		KEN-13823			Sundar		22-Sep-2017			Corrected the AffiliationEndDate default value to 2069-12-31
-- 14		CAPAVE-2186			Sundar		13-Oct-2017			StatusBeginDate is corrected by fetching from RenderingAccount instead of Group Account
-- 15		KEN-15462			Sundar		9-Mar-2018			Added IsApproved = 1 to consider only the approved IUD changes
-- 16		CAPAVE-2687			Ganesh		11-Apr-2018			Input Doc: NMP LIC Field blank Old value vs New value
-- 17		CAPAVE-2769			Ganesh		11-Apr-2018			Input Doc Integration: NMP License Number Field
-- 18		KEN-17512			Sundar		27-May-2018			Added AccountID not null condition in Rendering_Affiliation table
-- 19		KEN-18239			Sundar		27-Jul-2018			Considered IsPrimary Field for displaying License
-- 20		KEN-19169			Sundar		4-Dec-2018			Not Considering StatusAcc from Rendering_History table

CREATE PROCEDURE [KYPEnrollment].[sp_NMPBillingProvider_AccountInputDoc]
	-- Add the parameters for the stored procedure here
	@acc_party_id INT,
	@Username varchar(100),
	@UserDate date
	
AS
Declare @party_id int,
        @Accountnumber varchar(10)
BEGIN

set @party_id=(select PartyID from KYPEnrollment.pADM_Account where AccountID=@acc_party_id )

set @Accountnumber=(select AccountNumber from KYPEnrollment.pADM_Account where AccountID=@acc_party_id )

/*TO delete the records before Inserting*/
--IF EXISTS (SELECT * FROM KYPEnrollment.AccountInputDocNMP WHERE AccountNumber = @Accountnumber AND UserName=@Username)
--truncate table KYPEnrollment.AccountInputDocNMP


----IF EXISTS (SELECT * FROM KYPEnrollment.NMPBillingProvider WHERE AccountID=@acc_party_id AND UserName=@Username)
--truncate table KYPEnrollment.NMPBillingProvider 

--/*TO delete the records before Inserting*/


    -- Insert statements for procedure here
	insert into [KYPEnrollment].[AccountInputDocNMP] (
							LegalName,
							AccountNumber,
							Reviewer,
							ReviewerLD,
							Supervisor,
							SupervisorLD,
							Confirmer,
							ConfirmerLD,
							ProfileID,
							UserName,
							AppDT,
							NPI --Added for #8 KEN-12837
				)
	select 
			A.LegalName
			,A.AccountNumber
			,U1.FullName as Reviewer
			,convert( varchar(10),U1.LastActionDate,101) as ReviewerLD
			,U2.FullName as Supervisor
			,convert( varchar(10),U2.LastActionDate,101) as SupervisorLD
			--,U3.FullName as Confirmer --Commented for CAPAVE-1753
			--,convert( varchar(10),U3.LastActionDate,101) as ConfirmerLD--Commented for CAPAVE-1753
			,U1.FullName as Confirmer --Added for CAPAVE-1753
			,convert( varchar(10),U1.LastActionDate,101) as ConfirmerLD --Added for CAPAVE-1753
			,z.ProfileID
			,@Username,
			CONVERT(varchar(10),A.ApplicationDate,101) as ApplicationDate,
			A.NPI --Added for #8 KEN-12837
	from KYPEnrollment.pADM_Account A 
		 /*Commented the code for CAPAVE-1753*/
		 /* left join
		  (SELECT * FROM  (select ACC.AccountID, LastActionDate,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
		   from KYPEnrollment.pAccount_History Acc
		INNER JOIN
		   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
		   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
		   where y.RoleName in('ReviewerS','Reviewer'))ROL
		   ON ACC.LastActorUserID =ROL.UserID)X
		   WHERE X.ROW=1) U1 on U1.AccountID=A.AccountID
		   
		   left join 
		   
		   (SELECT * FROM  (select ACC.AccountID, LastActionDate,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
		   from KYPEnrollment.pAccount_History Acc
		INNER JOIN
		   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
		   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
		   where y.RoleName in('SupervisorR','SupervisorS','Supervisor')
		   )ROL
		   ON ACC.LastActorUserID =ROL.UserID)X
		   WHERE X.ROW=1) U2 on U2.AccountID=A.AccountID
		   left join 
		   
		   (SELECT * FROM  (select ACC.AccountID,LastActionDate,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
		   from KYPEnrollment.pAccount_History Acc
		INNER JOIN
		   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
		   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
		   where y.RoleName in('ConfirmerS','Confirmer'))ROL
		   ON ACC.LastActorUserID =ROL.UserID)X
		   WHERE X.ROW=1) U3 on U3.AccountID=A.AccountID
		   */
		   /*CAPAVE-1753 Start*/
		Left Join (SELECT distinct AccountID, FullName, LastActionDate
				FROM (Select A.AccountID,Ur.UserID,U.FullName, DateTime LastActionDate, ROW_NUMBER() Over( Partition by A.AccountID ORDER BY C.CaseID desc,id DESC) R
							From KYP.ADM_WorkflowHistory H
							Join KYP.ADM_Case C on H.CaseID = Convert(varchar(20),C.CaseID)
							Join KYPEnrollment.pADM_Account A on C.AccountNo = A.AccountNumber
							Join KYP.OIS_JT_UserRole UR on H.UserID = UR.UserID	
							Join KYP.OIS_Role R on UR.RoleID = R.RoleID
							Join kyp.OIS_User U on UR.UserID=U.UserID
							Where H.UserID is not null
							and r.RoleName in('ReviewerS','Reviewer')
							) RT	
				Where RT.R = 1) U1 on A.AccountID = U1.AccountID
		Left Join (SELECT distinct AccountID, FullName, LastActionDate
				FROM (Select A.AccountID,Ur.UserID,U.FullName, DateTime LastActionDate, ROW_NUMBER() Over( Partition by A.AccountID ORDER BY C.CaseID desc,id DESC) R
							From KYP.ADM_WorkflowHistory H
							Join KYP.ADM_Case C on H.CaseID = Convert(varchar(20),C.CaseID)
							Join KYPEnrollment.pADM_Account A on C.AccountNo = A.AccountNumber
							Join KYP.OIS_JT_UserRole UR on H.UserID = UR.UserID	
							Join KYP.OIS_Role R on UR.RoleID = R.RoleID
							Join kyp.OIS_User U on UR.UserID=U.UserID
							Where H.UserID is not null
							and r.RoleName in('SupervisorR','ConfirmerS')
							) RT	
				Where RT.R = 1) U2 on A.AccountID = U2.AccountID
	   /*CAPAVE-1753 End*/			    
		LEFT  OUTER JOIN KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID   
		where A.AccountID=@acc_party_id

	/*
	NMP Billing
	*/

	;With N as 
	(Select t2.AccountID,Convert(Date,T2.DateModified) DateModified,T2.FieldName,T2.ToValue
		From (Select AccountID,FieldName,MAX(ID) ID		
				From KYPEnrollment.INPUTDOC_RenderingHistory
				Where DateSearch>=@UserDate
				and AccountID=@acc_party_id
				Group by AccountID,FieldName) T1
		Join KYPEnrollment.INPUTDOC_RenderingHistory T2 on T1.ID = T2.ID),
	NV as (Select *
			--From N Pivot (MAX([ToValue]) for FieldName in (LegalName,SSN,ProvC,ProvCDate,StatusAcc,StsEffBnDT,StsEffEdDT,REENR,[REENR_DT],[srADD1],[srADD2],[srcity],[srstate],[srZip4])) P),
			--From N Pivot (MAX([ToValue]) for FieldName in (LegalName,SSN,ProvC,ProvCDate,StatusAcc,StatusBgnDt,StsEffEdDT,REENR,[REENR_DT],[srADD1],[srADD2],[srcity],[srstate],[srZip4])) P), /*PI-680 StatusBgnDt COLUMN is changed */
			From N Pivot (MAX([ToValue]) for FieldName in (LegalName,SSN,ProvCode,ProvCodeDT,StatusAcc,StatusBgnDt,StsEffEdDT,ReEnrollIn,ReEnrollDate
																--,[srADD1],[srADD2],[srcity],[srstate],[srZip4] --Commented for #11 PI-845
																--,[MADD1],[MADD2],[MCity],[MState],[MZip4] --Added for #8 KEN-12837 --Commented for #11 PI-845
					)) P), /*PI-680 StatusBgnDt,ProvCode,ProvCodeDT,ReEnrollIn,ReEnrollDate is changed*/
	OV as (Select Case when (CONVERT( date,RAff.LastActionDate)>=@UserDate
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285
							) Then A.NPI End as NPI_New
				,Case when (CONVERT( date,RAff.LastActionDate)>=@UserDate
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285			
							) Then A.OwnerNo End as OwnerNo_New
				,Case when (CONVERT( date,RAff.LastActionDate)>=@UserDate
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285			 
							) Then A.ServiceLocationNo End as ServiceLocationNo_New
				,Case when (CONVERT( date,RAff.LastActionDate)>=@UserDate
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285			
							) Then A.ProviderTypeCode End as ProviderType_New
				,A.NPI
				,A.OwnerNo
				,A.ServiceLocationNo
				,A.ProviderTypeCode
				,AR.NPI AS NMPRendNPI
				,Case when (CONVERT( date,LIC.LastActionDate)>=@UserDate
							and Lic.LastActorUserID<>'System' --#3 CAPAVE-1284,1285			
							) Then LIC.Number End as NMPRendLic_New
				,LIC.Number
				,LEFT(AR.ProviderTypeCode,1) as ProvTC
				,Case when (--CONVERT( date,RAff.AffiliationStartDate)>=@UserDate --Commented on 11-Jul-2017 for PI-813 (#6)
							CONVERT(Date,RAFF.LastActionDate)>=@UserDate --Added on 11-Jul-2017 for PI-813	(#6)			
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285			
							) then CONVERT( varchar(10),RAff.AffiliationStartDate,101)end AS AffiliationStartDate_New
				,CONVERT( varchar(10),RAff.AffiliationStartDate,101) AS AffiliationStartDate
				,Case when (--CONVERT( date,(RAff.AffiliationEndDate))>=@UserDate --Commented on 11-Jul-2017 for PI-813 (#6)
							--and (RAff.AffiliationEndDate!='2069-12-31') --Commented on 11-Jul-2017 for PI-813 (#6)
							CONVERT(Date,RAFF.LastActionDate)>=@UserDate --Added on 11-Jul-2017 for PI-813 (#6)						
							and raff.LastActorUserID<>'System' --#3 CAPAVE-1284,1285						
							) then isnull(CONVERT(varchar(10),RAff.AffiliationEndDate,101),'12/31/2069') end AS AffiliationEndDate_New --Added Isnull condition on 12-Jul-2017 for PI-814 (#7)
				,CONVERT(varchar(10),RAff.AffiliationEndDate,101) AS AffiliationEndDate
				,RAff.AffiliatedAccountID as AccountID
				,convert(date,raff.LastActionDate) as LastActionDate
				,RAff.AffiliationStartDate as AffiliationStartsort
				,case when(RAff.AffiliationEndDate!='2069-12-31')then RAff.AffiliationEndDate end  AS Affiliationsort
				,AR.LegalName,
				AR.SSN,
				D.ProvisionalCode ProvC,
				D.ProvisionalCodeDate ProvCDate,
				AR.StatusAcc,
				--ISNULL(acs.EffectiveBeginDate,a.StatusBeginDate) StsEffBnDT, --/**1*/--Commented for #10 PI-834
				--acs.EffectiveBeginDate StsEffBnDT,
				--A.StatusBeginDate StsEffBnDT, --Added for #10 PI-834	--Commented for CAPAVE-2186
				AR.StatusBeginDate StsEffBnDT, --Added for CAPAVE-2186			
				acs.EffectiveEndDate StsEffEdDT,
				--ar.ReenrollmentIndicator REENR,
				--ar.ReenrollmentDate [REENR_DT],
				
				D.ReEnrolInd REENR,/*PI-680*/ /*2*/
				D.ReEnrolDate [REENR_DT],/*PI-680*/ /*2*/
				e.AddressLine1 [srADD1],
				e.AddressLine2 [srADD2],
				e.City [srcity],
				e.Abreviation [srstate],
				e.ZipPlus4 [srZip4],
				/*Start #8 KEN-12837*/				
				f.AddressLine1 [MADD1],
				f.AddressLine2 [MADD2],
				f.City [Mcity],
				f.Abreviation [Mstate],
				f.ZipPlus4 [MZip4]	
				/*End #8 KEN-12837*/						
			from KYPEnrollment.pAccount_RenderingAffiliation RAff
			LEFT JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID 
			LEFT JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
			left join KYPEnrollment.EDM_AccountInternalUse D on D.AccountID=RAff.AffiliatedAccountID 
																AND (D.IsApproved = 1 OR D.IsApproved is null) --Added for #  KEN-15462
			/*													
			left join (select PartyID,MAX(NumberID) NumberID
						From KYPEnrollment.pAccount_PDM_Number
						where Type='Professional License'
							AND CurrentRecordFlag=1
						Group by PartyID) LIC1 on LIC1.PartyID=AR.PartyID 
			*/													
			--Added for CAPAVE-2687, 2769 - Begin
			Left Join (Select PartyID, NumberID
							From (
									Select PartyID,NumberID,Row_Number() Over(Partition by PartyID order by Sortorder) R
									From (
									--Added the first select stat. for KEN-18239 by Sundar
									Select PartyID,Max(NumberID) NumberID, 0 as SortOrder
									From kypenrollment.pAccount_PDM_Number
									Where CurrentRecordFlag=1
										AND IsPrimary=1
										AND Number is not null
									Group by PartyID
									Union all
									select PartyID,MAX(NumberID) NumberID, 1 as SortOrder
									From KYPEnrollment.pAccount_PDM_Number
									where (Type='Professional License' AND Number IS NOT NULL)
										  AND CurrentRecordFlag=1
									Group by PartyID
									Union all
									select PartyID,MAX(NumberID) NumberID, 2 as SortOrder
									From KYPEnrollment.pAccount_PDM_Number
									where (Type='Certificate' AND Number IS NOT NULL)
										  AND CurrentRecordFlag=1
									Group by PartyID
									Union all
									select PartyID,MAX(NumberID) NumberID, 3 as SortOrder
									From KYPEnrollment.pAccount_PDM_Number
									where (Type='Other' AND Number IS NOT NULL)
										  AND CurrentRecordFlag=1
									Group by PartyID) T) T1
						where R=1) LIC1 on LIC1.PartyID=AR.PartyID
			-- CAPAVE-2687, 2769 - End
 
			LEFT JOIN KYPEnrollment.pAccount_PDM_Number LIC on LIC.NumberID=LIC1.NumberID			
			left join (select AccountID,MAX(AccountStatusID) AccountStatusID
						from KYPEnrollment.pADM_AccountStatus
						Where CurrentRecordFlag=1 AND StatusType='Enrollment'
						group by AccountID) ACS1 ON Acs1.AccountID=AR.AccountID
			left join KYPEnrollment.pADM_AccountStatus ACS on Acs.AccountStatusID=ACS1.AccountStatusID 
			left join (select SR.AddressLine1,SR.AddressLine2,SR.City ,LS.Abreviation ,SR.ZipPlus4 ,SR.County,x.PartyID  
						from KYPEnrollment.pAccount_PDM_Address SR
						inner join KYPEnrollment.pAccount_PDM_Location X on SR.AddressID = X.AddressID 
												--and X.Type='Individual Profile' --Commented for #8 KEN-12837
												and X.Type='Servicing' --Added for #8 KEN-12837
												and X.CurrentRecordFlag=1
						Left join kyp.LK_Screening LS on SR.State=LS.Description
						) E on E.PartyID = AR.PartyID
			--Added the below statement for #8 KEN-12837
			left join (select SR.AddressLine1,SR.AddressLine2,SR.City ,LS.Abreviation ,SR.ZipPlus4 ,SR.County,x.PartyID  
						from KYPEnrollment.pAccount_PDM_Address SR
						inner join KYPEnrollment.pAccount_PDM_Location X on SR.AddressID = X.AddressID 
												and X.Type='Mailing' 
												and X.CurrentRecordFlag=1
						Left join kyp.LK_Screening LS on SR.State=LS.Description
						) F on F.PartyID = AR.PartyID							
			Where RAff.AffiliatedAccountID=@acc_party_id and RAff.isDeleted=0 --KEN-7639
			and RAFF.AccountID is not null --Added for KEN-17512			
			)
	Insert into [KYPEnrollment].[NMPBillingProvider]
	(
		NPI_New,
		NPI_Old,
		OwnerNo_New,
		OwnerNo_Old,
		ServiceLocationNo_New,
		ServiceLocationNo_Old,
		ProviderType_New,
		ProviderType_Old,
		NMPRendNPI_New, --Added for #4 PI-785	
		NMPRendNPI,
		NMPRendLic_New,
		NMPRendLic_Old,
		ProvTC_New, --Added for #4 PI-785
		ProvTC,
		AffiliationStartDate_new,
		AffiliationStartDate_Old,
		AffiliationEndDate_New,
		AffiliationEndDate_old,
		AccountID,
		LegalName_Old,
		LegalName_New,
		SSN_Old,
		SSN_New,
		ProvENR_Old,
		ProvENR_New,
		ProEDTO, --Changed teh field from ProvENR_EFFDT_Old to ProEDTO for #9 PI-831 
		ProEDTN, --Changed teh field from ProvENR_EFFDT_New to ProEDTN for #9 PI-831
		StatusO, --Changed teh field from StatusAcc_Old to StatusO for #9 PI-831 
		StatusN, --Changed teh field from StatusAcc_New to StatusN for #9 PI-831 
		StsDTO, --Changed teh field from StatusAcc_EFFDT_Old to StsDTO for #9 PI-831 
		StsDTN, --Changed teh field from StatusAcc_EFFDT_New to StsDTN for #9 PI-831 
		StatusAcc_ENDDT_Old,
		StatusAcc_ENDDT_New,
		REENR_Old,
		REENR_New,
		REDTO,--Changed teh field from REENR_DT_O to REDTO for #9 PI-831
		REDTN,--Changed teh field from REENR_DT_N to REDTN for #9 PI-831
		srADD1_Old,
		srADD1_New,
		srADD2_Old,
		srADD2_New,
		srcity_Old,
		srcity_New,
		srState_Old,
		srState_New,
		srZipPlus4_Old,
		srZipPlus4_New,
		LastActionDate,
		AffiliationStartsort,
		Affiliationsort,
		UserName,
		/*Start #8 KEN-12837*/
		Seq, 
		MADD1_Old,		
		MADD1_New,
		MADD2_Old,
		MADD2_New,
		Mcity_Old,
		Mcity_New,
		MState_Old,
		MState_New,
		MZipPlus4_Old,
		MZipPlus4_New
		/*End #8 KEN-12837*/	
	)
	Select 
		 OV.NPI_New
		,Case When OV.NPI_New IS null then OV.NPI End as NPI_Old
		,OV.OwnerNo_New
		,Case When OV.OwnerNo_New IS null then OV.OwnerNo End as OwnerNo_Old
		,OV.ServiceLocationNo_New
		,Case When OV.ServiceLocationNo_New IS null then OV.ServiceLocationNo End as ServiceLocationNo_Old
		,OV.ProviderType_New
		,Case When OV.ProviderType_New IS null then OV.ProviderTypeCode End as ProviderType_Old
		--,OV.NMPRendNPI --Commented for #4 PI-785
		/* Start #4 PI-785*/
		,Case When (OV.NMPRendLic_New is not null) Then OV.NMPRendNPI 
			When OV.AffiliationStartDate_New is not null then OV.NMPRendNPI
			When OV.AffiliationEndDate_New is not null then OV.NMPRendNPI	
			Else NULL		
			End as NMPRendNPI_New		
		,Case When ((OV.NMPRendLic_New is null)
				and OV.AffiliationStartDate_New is null 
				and OV.AffiliationEndDate_New is null) Then OV.NMPRendNPI
			Else NULL 
			End AS NMPRendNPI
		/* End #4 PI-785*/	
		,OV.NMPRendLic_New
		,Case When OV.NMPRendLic_New IS null then OV.Number End as NMPRendLic_Old
		--,OV.ProvTC --Commented for #4 PI-785
		/*Added for #4 PI-785 Start*/
		,Case When (OV.NMPRendLic_New is not null) Then OV.ProvTC
					When OV.AffiliationStartDate_New IS NOT null then OV.ProvTC
					When OV.AffiliationEndDate_New IS NOT null then OV.ProvTC	
					Else NULL		
					End as ProvTC_New
		,Case When (OV.NMPRendLic_New is null
					and OV.AffiliationStartDate_New is null 
					and OV.AffiliationEndDate_New is null) Then OV.ProvTC
				Else NULL 
				End as ProvTC 	
		/*Added for #4 PI-785 End*/	
		,OV.AffiliationStartDate_new
		,Case When OV.AffiliationStartDate_New IS null then OV.AffiliationStartDate End as AffiliationStartDate_Old
		,OV.AffiliationEndDate_New
		,Case When OV.AffiliationEndDate_New IS null then isnull(OV.AffiliationEndDate,'12/31/2069') End as AffiliationEndDate_old
		,OV.AccountID as AccountID
		,Case when NV.LegalName is null then OV.LegalName END LegalName_Old
		,NV.LegalName LegalName_New
		,Case when NV.SSN is null then OV.SSN END SSN_Old
		,NV.SSN SSN_New
		,Case when NV.ProvCode is null then OV.ProvC END ProvC_Old
		,NV.ProvCode ProvC_New
		,Case when NV.ProvCodeDT is null then convert(varchar(10),OV.ProvCDate,101) END ProvCDate_Old
		,convert(varchar(10),NV.ProvCodeDT,101) ProvCDate_New
		,Case when NV.StatusAcc is null then OV.StatusAcc END StatusAcc_Old
		,Case when NV.AccountID is not null then OV.StatusAcc END StatusAcc_New -- Added Case Statment for KEN-19169 on 4-Dec-2018 by Sundar
		,Case when NV.StatusBgnDt is null then convert(varchar(10),OV.StsEffBnDT,101) END StsEffBnDT_Old
		,convert(varchar(10),NV.StatusBgnDt,101) StsEffBnDT_New
		--,Case when NV.StsEffEdDT is null then convert(varchar(10),OV.StsEffEdDT,101) END StsEffEdDT_Old
		,Case when NV.StsEffEdDT is null then convert(varchar(10),isnull(OV.StsEffEdDT,'2069-12-31'),101) END StsEffEdDT_Old /*PI-680*/ /*2*/
		,convert(varchar(10),NV.StsEffEdDT,101) StsEffEdDT_New
		,Case when NV.ReEnrollIn is null then OV.REENR END REENR_Old
		,NV.ReEnrollIn REENR_New
		,Case when NV.ReEnrollDate is null then convert(varchar(10),OV.REENR_DT,101) END REENR_DT_Old
		,convert(varchar(10),NV.ReEnrollDate,101) REENR_DT_New
		--,Case when NV.srADD1 is null then OV.srADD1 END srADD1_Old --Commented for  #11 PI-845
		,OV.srADD1 srADD1_Old --Added for  #11 PI-845
		--,NV.srADD1 srADD1_New --Commented for  #11 PI-845
		,Null srADD1_New --Added for  #11 PI-845		
		,OV.srADD2 srADD2_Old --Added for  #11 PI-845		
		--,Case when NV.srADD2 is null then OV.srADD2 END srADD2_Old --Commented for  #11 PI-845
		--,NV.srADD2 srADD2_New--Commented for  #11 PI-845
		,Null srADD2_New --Added for  #11 PI-845	
		,OV.srcity srcity_Old --Added for  #11 PI-845			
		--,Case when NV.srcity is null then OV.srcity END srcity_Old --Commented for  #11 PI-845
		--,NV.srcity srcity_New--Commented for  #11 PI-845
		,Null srcity_New --Added for  #11 PI-845
		,OV.srstate srstate_Old --Added for  #11 PI-845			
		--,Case when NV.srstate is null then OV.srstate END srstate_Old --Commented for  #11 PI-845
		--,NV.srstate srstate_New--Commented for  #11 PI-845
		,Null srstate_New --Added for  #11 PI-845	
		--,Case when NV.srZip4 is null then OV.srZip4 END srZip4_Old --Commented for  #11 PI-845
		--,NV.srZip4 srZip4_New--Commented for  #11 PI-845
		,OV.srZip4 srZip4_Old --Added for  #11 PI-845			
		,Null srZip4_New --Added for  #11 PI-845	
		,OV.LastActionDate
		,OV.Affiliationsort
		,OV.AffiliationStartsort
		,@userName	
		/*Start #8 KEN-12837*/	
		,Row_Number() over(Order by OV.LastActionDate desc,OV.Affiliationsort desc,OV.AffiliationStartsort desc)--Added for #8 KEN-12837
		--Commented for #11 PI-845
		/*		
		,Case When NV.MADD1 IS null Then OV.MADD1 End MADD1_Old
		,NV.MADD1 MADD1_New
		,Case When NV.MADD2 IS null Then OV.MADD2 End MADD2_Old
		,NV.MADD2 MADD2_New		
		,Case When NV.MCity IS null Then OV.MCity End MCity_Old
		,NV.MCity MCity_New
		,Case When NV.MState IS null Then OV.MState End MState_Old
		,NV.MState MState_New
		,Case When NV.MZip4 IS null Then OV.MZip4 End MZipPlus4_Old
		,NV.MZip4 MZipPlus4_New
		*/
		--Added for #11 PI-845
		,OV.MADD1 MADD1_Old
		,NULL MADD1_New
		,OV.MADD2 MADD2_Old
		,NULL MADD2_New		
		,OV.MCity MCity_Old
		,NULL MCity_New
		,OV.MState MState_Old
		,NULL MState_New
		,OV.MZip4 MZipPlus4_Old
		,NULL MZipPlus4_New			
		/*End #8 KEN-12837*/	
	from OV
	Left Join NV on OV.AccountID = NV.AccountID
	where ov.AccountID = @acc_party_id
	order by convert(date,OV.LastActionDate) desc,  OV.Affiliationsort desc,OV.AffiliationStartsort desc	

	/*Start #8 KEN-12837*/
	--Changed the query for #12 PI-844 
	;With Q1 as (Select T1.AccountID,isnull(T1.FieldName,'') FieldName,T1.[ToValue]
				From Kypenrollment.INPUTDOC_BILLER T1
				Join (select FieldName,MAX(ID) ID
						from kypenrollment.INPUTDOC_BILLER
						where AccountID = @acc_party_id
						and FieldName in ('Fname','MName','LName','Title','Suffix')
						and CONVERT(date,DateModified) >= @UserDate
						Group by FieldName) T2 on T1.ID = T2.ID),
	Q2 as (Select AccountId,
					Max(Case When FieldName = 'FName' then [toValue] Else Null End) as [FName],
					Max(Case When FieldName = 'LName' then [toValue] Else Null End) as LName,
					Max(Case When FieldName = 'MName' then [toValue] Else Null End) as MName,
					Max(Case When FieldName = 'Suffix' then [toValue] Else Null End) as suffix,	
					Max(Case When FieldName = 'Title' then [toValue] Else Null End) as Title					
			From Q1	
			Group by AccountID)
	Update A
	Set A.FName_New = B.FName,
		A.MName_New = B.MName,
		A.LName_New = B.LName,
		A.Title_New = B.Title,
		A.SufixN = B.Suffix, --Renamed the column from Suffix_New to SufixN for #9 PI-831		
		A.LegalName_New = Case When (B.FName IS NOT null) then Ac.LegalName 
								When (B.LName IS NOT null) then Ac.LegalName
								When (B.MName IS NOT null) then Ac.LegalName
								Else Null End
	From kypenrollment.NMPBillingProvider A
		Join kypenrollment.pADM_Account Ac on A.AccountID = Ac.AccountID
		Join Q2 B on A.AccountID = B.AccountID	
		
	Update A
	Set A.FName_Old = Case When A.FName_New is NULL Then B.FName End,
		A.MName_Old = Case When A.MName_New is NULL Then B.MName End,
		A.LName_Old = Case When A.LName_New is NULL Then B.LName End,
		A.Title_Old = Case When A.Title_New is NULL Then B.Title End,
		A.SufixO = Case When A.SufixN is NULL Then B.Suffix End,  --Renamed the column from Suffix_Old to SufixO for #9 PI-831
		A.LegalName_Old = Case When A.LegalName_New is null then C.LegalName End --Added for #12 PI-844 		
	From kypenrollment.NMPBillingProvider A
		Join kypenrollment.AccountInputDocFullLoad B on A.AccountID = B.AccountID
		Join kypenrollment.pADM_Account C on A.AccountID = C.AccountID		
	Where A.AccountID = @Acc_Party_ID
	/*End #8 KEN-12837*/
	
END


GO

