


CREATE PROCEDURE [KYPEnrollment].[Association_TaxID_new](
  @account_id INT,
  @party_id_account INT,
  @tax_id VARCHAR(10),
  @application_id INT,
  @party_id_app INT,
  @last_Action_User_ID VARCHAR(100),
  @accepted BIT,
  @application_type VARCHAR(50) = NULL
)
AS
BEGIN
 DECLARE @profile_id varchar(40)

 SELECT @profile_id = ProfileID
 FROM KYPEnrollment.pAccount_BizProfile_Details
 WHERE AccountID = @account_id

 EXEC [KYPEnrollment].[Add_Association_TaxID_new]@account_id,@party_id_account,@tax_id,@application_id,@party_id_app,@last_Action_User_ID,@accepted,@application_type;
 --++
 --+++++++++++
  select * from kypenrollment.pAccount_PDM_Party where AccountID in (
select tax.accountid from kypenrollment.paccount_taxid_associate tax  where taxid='878888888' ) and temppartyid is not null

  --+++++++++++
 EXEC [KYPEnrollment].[sp_Correct_PartyAssociate] @tax_id, @profile_id;

 --EXEC [KYPEnrollment].[Update_All_Account] @account_id,@party_id_account,@tax_id,@application_id,@party_id_app,@last_Action_User_ID, @accepted,@application_type;

--+++++++++++
select * from kypenrollment.pAccount_PDM_Party where AccountID in (
select tax.accountid from kypenrollment.paccount_taxid_associate tax  where taxid='878888888' ) and temppartyid is not null

  --+++++++++++
END


GO

