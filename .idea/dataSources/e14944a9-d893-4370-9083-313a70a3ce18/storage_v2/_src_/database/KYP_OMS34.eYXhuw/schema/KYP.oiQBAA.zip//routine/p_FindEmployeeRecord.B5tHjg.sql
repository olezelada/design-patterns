-- =============================================
-- Author:		Yogesh Sharma
-- Create date: July 28 2012
-- Description:	Find the EmployeeID if Party exists as an employee of the provider 
-- =============================================
CREATE PROCEDURE [KYP].[p_FindEmployeeRecord]
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@ProviderID int
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @EmployeeID int
	/********Get the EmployeeID based on PartyID of Employee + ProviderID of the provider**********/
	if exists (	
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_Employee B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.ProviderID = @ProviderID
	)
	begin
	select @EmployeeID = B.EmployeeID
	from KYP.PDM_Party A
	inner join KYP.PDM_Employee B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.ProviderID = @ProviderID	
    return @EmployeeID	
	end	
	else 
	return -1   	
END


GO

