-- =============================================
-- Author:        VINOD
-- Create date: 14-02-2012
-- Description:   Update the number of days between the start date and the end date
-- =============================================
CREATE TRIGGER [KYP].[updateNumDays]
   ON  [KYP].[OIS_CaseTracker]
   AFTER INSERT,UPDATE
AS 
BEGIN
      SET NOCOUNT ON;
      DECLARE @@InsertedID INT, @@DateDiff INT, @@StartDate DATETIME, @@EndDate DATETIME
    -- Insert statements for trigger here
      SET @@InsertedID = (SELECT TrackerID from inserted);
      SET @@StartDate = (SELECT DateStarted from inserted);
      SET @@EndDate = (SELECT DateCompleted from inserted);
      IF ISNULL(@@EndDate,'') = ''
            SET @@EndDate = getDate();
      SET @@DateDiff = DateDiff(dd,@@StartDate,@@EndDate);
      --UPDATE oishealth.OIS_CaseTracker SET DateStarted = Convert(DateTime,'02/11/2012 12:24:50 PM') where trackerid = 12
      UPDATE KYP.OIS_CaseTracker SET NumDays = Convert(int,@@DateDiff) WHERE TrackerID = @@InsertedID
END


GO

