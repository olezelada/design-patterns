
CREATE PROCEDURE [KYP].[p_WF_DeleteRelatedData]
   @AlertNo             VARCHAR (500),
   @JournalEvent        VARCHAR (50),
   @Username            VARCHAR (25),
   @NotesDescription    VARCHAR (MAX),
   @CaseID              INT
AS
BEGIN
   SET  NOCOUNT ON;

   DECLARE @AlertID   INT

   SELECT @AlertID = AlertID
   FROM KYP.MDM_Alert
   WHERE AlertNo = @AlertNo

   IF @JournalEvent = 'WF_DeleteRelatedData'
      BEGIN
         EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                @NotesDescription,
                                                '',
                                                @AlertID,
                                                '2'

         UPDATE KYP.OIS_Note
            SET Deleted = 1
          WHERE NoteID IN
                   (SELECT ResolutionNoteID
                      FROM KYP.MDM_AlertPvdSuspension
                     WHERE ResolutionID IN (SELECT ResolutionID
                                              FROM KYP.MDM_AlertResolution
                                             WHERE AlertID = @AlertID))

         UPDATE KYP.OIS_Note
            SET Deleted = 1
          WHERE NoteID IN
                   (SELECT ResolutionNoteID
                      FROM KYP.MDM_AlertPIUReferral
                     WHERE ResolutionID IN (SELECT ResolutionID
                                              FROM KYP.MDM_AlertResolution
                                             WHERE AlertID = @AlertID))

         UPDATE KYP.OIS_Note
            SET Deleted = 1
          WHERE NoteID IN
                   (SELECT ResolutionNoteID
                      FROM KYP.MDM_AlertOIGReferral
                     WHERE ResolutionID IN (SELECT ResolutionID
                                              FROM KYP.MDM_AlertResolution
                                             WHERE AlertID = @AlertID))

         UPDATE KYP.OIS_Note
            SET Deleted = 1
          WHERE NoteID IN
                   (SELECT ResolutionNoteID
                      FROM KYP.MDM_AlertNewResolutions
                     WHERE ResolutionID IN (SELECT ResolutionID
                                              FROM KYP.MDM_AlertResolution
                                             WHERE AlertID = @AlertID))

         UPDATE KYP.MDM_AlertNewResolutions
            SET IsDeleted = 1
          WHERE ResolutionID IN (SELECT ResolutionID
                                   FROM KYP.MDM_AlertResolution
                                  WHERE AlertID = @AlertID)

         UPDATE KYP.MDM_AlertOIGReferral
            SET IsDeleted = 1
          WHERE ResolutionID IN (SELECT ResolutionID
                                   FROM KYP.MDM_AlertResolution
                                  WHERE AlertID = @AlertID)

         UPDATE KYP.MDM_AlertPIUReferral
            SET IsDeleted = 1
          WHERE ResolutionID IN (SELECT ResolutionID
                                   FROM KYP.MDM_AlertResolution
                                  WHERE AlertID = @AlertID)

         UPDATE KYP.MDM_AlertPvdSuspension
            SET IsDeleted = 1
          WHERE ResolutionID IN (SELECT ResolutionID
                                   FROM KYP.MDM_AlertResolution
                                  WHERE AlertID = @AlertID)

  --ALTER TABLE KYP.MDM_AlertResolution DISABLE TRIGGER trg_MDM_ResolutionOnInsert

         UPDATE KYP.MDM_AlertResolution
            SET IsDeleted = 1,
				Row_Updation_Source = 'KYP.p_WF_DeleteRelatedData'
          WHERE AlertID = @AlertID

  --ALTER TABLE KYP.MDM_AlertResolution ENABLE TRIGGER trg_MDM_ResolutionOnInsert

         DECLARE @ImpMedicaidID   VARCHAR (200)

         DECLARE
            grpMultipleProviders CURSOR FOR
               SELECT MedicaidID
                 FROM KYP.MDM_ImpProviders
                WHERE AlertID = @AlertID AND ISNULL (IsDeleted, '0') = 0

         OPEN grpMultipleProviders

         FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID

         WHILE @@Fetch_Status = 0
         BEGIN
            EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                   @NotesDescription,
                                                   @ImpMedicaidID,
                                                   @CaseID,
                                                   '1'

            FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID
         END

         CLOSE grpMultipleProviders

         DEALLOCATE grpMultipleProviders

         --UPDATE KYP.MDM_SearchProviders
         --SET Remarks = NULL
         -- ,Impacted = 0
         --WHERE AlertID = @AlertID
         -- AND SearchID IN (
         --  SELECT SearchID
         --  FROM KYP.MDM_ImpProviders
         --  WHERE AlertID = @AlertID
         --  )

         --UPDATE KYP.MDM_ImpProviders
         --SET Remarks = NULL
         -- ,CreatedBy = NULL
         -- ,CreatedDate = NULL
         -- ,ModifiedBy = NULL
         -- ,ModifiedDate = NULL
         -- ,IsDeleted = 1
         --WHERE AlertID = @AlertID

         DECLARE @count   INT
         DECLARE @maxCount   INT
         DECLARE @childAlertID   INT

         SET @count = 1

         SELECT @maxCount = COUNT (*)
         FROM kyp.MDM_RelatedAlerts
         WHERE ParentAlertID = @AlertID AND isnull (IsDeleted, '0') = 0

         WHILE @count <= @maxCount
         BEGIN
            SELECT @childAlertID = x.ChildAlertID
              FROM (SELECT ChildAlertID,
                           ROW_NUMBER () OVER (ORDER BY mergedid) AS row
                      FROM kyp.MDM_RelatedAlerts
                     WHERE     ParentAlertID = @AlertID
                           AND isnull (IsDeleted, '0') = 0) x
             WHERE x.row = @count

            EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                   @NotesDescription,
                                                   '',
                                                   @childAlertID,
                                                   '2'

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertPvdSuspension
                        WHERE ResolutionID IN
                                 (SELECT ResolutionID
                                    FROM KYP.MDM_AlertResolution
                                   WHERE AlertID = @childAlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertPIUReferral
                        WHERE ResolutionID IN
                                 (SELECT ResolutionID
                                    FROM KYP.MDM_AlertResolution
                                   WHERE AlertID = @childAlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertOIGReferral
                        WHERE ResolutionID IN
                                 (SELECT ResolutionID
                                    FROM KYP.MDM_AlertResolution
                                   WHERE AlertID = @childAlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertNewResolutions
                        WHERE ResolutionID IN
                                 (SELECT ResolutionID
                                    FROM KYP.MDM_AlertResolution
                                   WHERE AlertID = @childAlertID))

            UPDATE KYP.MDM_AlertNewResolutions
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @childAlertID)

            UPDATE KYP.MDM_AlertOIGReferral
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @childAlertID)

            UPDATE KYP.MDM_AlertPIUReferral
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @childAlertID)

            UPDATE KYP.MDM_AlertPvdSuspension
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @childAlertID)

   --ALTER TABLE KYP.MDM_AlertResolution DISABLE TRIGGER trg_MDM_ResolutionOnInsert

            UPDATE KYP.MDM_AlertResolution
               SET IsDeleted = 1,
				   Row_Updation_Source = 'KYP.p_WF_DeleteRelatedData'
             WHERE AlertID = @childAlertID

   --ALTER TABLE KYP.MDM_AlertResolution ENABLE TRIGGER trg_MDM_ResolutionOnInsert

            DECLARE @ImpMedicaidID2   VARCHAR (200)

            DECLARE
               grpMultipleProviders CURSOR FOR SELECT MedicaidID
                                                 FROM KYP.MDM_ImpProviders
                                                WHERE     AlertID =
                                                             @childAlertID
                                                      AND ISNULL (IsDeleted,
                                                                  '0') = 0

            OPEN grpMultipleProviders

            FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID2

            WHILE @@Fetch_Status = 0
            BEGIN
               EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                      @NotesDescription,
                                                      @ImpMedicaidID2,
                                                      @CaseID,
                                                      '1'

               FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID2
            END

            CLOSE grpMultipleProviders

            DEALLOCATE grpMultipleProviders

            --UPDATE KYP.MDM_SearchProviders
            --SET Remarks = NULL
            -- ,Impacted = 0
            --WHERE AlertID = @childAlertID
            -- AND SearchID IN (
            --  SELECT SearchID
            --  FROM KYP.MDM_ImpProviders
            --  WHERE AlertID = @childAlertID
            --  )

            --UPDATE KYP.MDM_ImpProviders
            --SET Remarks = NULL
            -- ,CreatedBy = NULL
            -- ,CreatedDate = NULL
            -- ,ModifiedBy = NULL
            -- ,ModifiedDate = NULL
            -- ,IsDeleted = 1
            --WHERE AlertID = @childAlertID

            SET @count = @count + 1
         END
      END
   ELSE
      IF @JournalEvent = 'WF_DeleteRelatedDataUnMerge'
         BEGIN
            EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                   @NotesDescription,
                                                   '',
                                                   @AlertID,
                                                   '2'

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertPvdSuspension
                        WHERE ResolutionID IN (SELECT ResolutionID
                                                 FROM KYP.MDM_AlertResolution
                                                WHERE AlertID = @AlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertPIUReferral
                        WHERE ResolutionID IN (SELECT ResolutionID
                                                 FROM KYP.MDM_AlertResolution
                                                WHERE AlertID = @AlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertOIGReferral
                        WHERE ResolutionID IN (SELECT ResolutionID
                                                 FROM KYP.MDM_AlertResolution
                                                WHERE AlertID = @AlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE NoteID IN
                      (SELECT ResolutionNoteID
                         FROM KYP.MDM_AlertNewResolutions
                        WHERE ResolutionID IN (SELECT ResolutionID
                                                 FROM KYP.MDM_AlertResolution
                                                WHERE AlertID = @AlertID))

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE     TYPE = 'Disposition'
                   AND RelatedEntityType = 'MDM_Alert'
                   AND RelatedEntityID = @AlertID

            UPDATE KYP.OIS_Note
               SET Deleted = 1
             WHERE     TYPE = 'Special Instructions'
                   AND RelatedEntityType = 'MDM_Alert'
                   AND RelatedEntityID = @AlertID

            UPDATE KYP.MDM_AlertNewResolutions
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @AlertID)

            UPDATE KYP.MDM_AlertOIGReferral
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @AlertID)

            UPDATE KYP.MDM_AlertPIUReferral
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @AlertID)

            UPDATE KYP.MDM_AlertPvdSuspension
               SET IsDeleted = 1
             WHERE ResolutionID IN (SELECT ResolutionID
                                      FROM KYP.MDM_AlertResolution
                                     WHERE AlertID = @AlertID)

  --ALTER TABLE KYP.MDM_AlertResolution DISABLE TRIGGER trg_MDM_ResolutionOnInsert

            UPDATE KYP.MDM_AlertResolution
               SET IsDeleted = 1,
				   Row_Updation_Source = 'KYP.p_WF_DeleteRelatedData'
             WHERE AlertID = @AlertID

  --ALTER TABLE KYP.MDM_AlertResolution ENABLE TRIGGER trg_MDM_ResolutionOnInsert

            DECLARE @ImpMedicaidID1   VARCHAR (200)

            DECLARE
               grpMultipleProviders CURSOR FOR
                  SELECT MedicaidID
                    FROM KYP.MDM_ImpProviders
                   WHERE AlertID = @AlertID AND ISNULL (IsDeleted, '0') = 0

            OPEN grpMultipleProviders

            FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID1

            WHILE @@Fetch_Status = 0
            BEGIN
               EXEC [KYP].[sp_RemoveAlertResolutions] @Username,
                                                      @NotesDescription,
                                                      @ImpMedicaidID1,
                                                      @CaseID,
                                                      '1'

               FETCH NEXT FROM grpMultipleProviders   INTO @ImpMedicaidID1
            END

            CLOSE grpMultipleProviders

            DEALLOCATE grpMultipleProviders

            --UPDATE KYP.MDM_SearchProviders
            --SET Remarks = NULL
            -- ,Impacted = 0
            --WHERE AlertID = @AlertID
            -- AND SearchID IN (
            --  SELECT SearchID
            --  FROM KYP.MDM_ImpProviders
            --  WHERE AlertID = @AlertID
            --  )

            --UPDATE KYP.MDM_ImpProviders
            --SET Remarks = NULL
            -- ,CreatedBy = NULL
            -- ,CreatedDate = NULL
            -- ,ModifiedBy = NULL
            -- ,ModifiedDate = NULL
            -- ,IsDeleted = 1
            --WHERE AlertID = @AlertID

            SELECT UserName,
                   EventName,
                   ResolutionType,
                   ProviderID,
                   EventDateTime,
                   Notes,
                   UserID,
                   AlertID,
                   ProNumber
              INTO #tmpResolution
              FROM KYP.MDM_ResolutionHistory
             WHERE AlertID = @AlertID

            DELETE FROM KYP.MDM_ResolutionHistory
             WHERE AlertID = @AlertID

            INSERT INTO KYP.MDM_ResolutionHistory
               SELECT x.UserName,
                      x.EventName,
                      x.ResolutionType,
                      x.ProviderID,
                      x.EventDateTime,
                      x.Notes,
                      x.UserID,
                      y.ParentAlertID,
                      x.ProNumber
                 FROM #tmpResolution x
                      INNER JOIN kyp.MDM_RelatedAlerts y
                         ON x.AlertID = y.ChildAlertID
                WHERE ISNULL (y.IsDeleted, '0') = 1
         END
END


GO

