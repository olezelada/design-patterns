
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Subcontractor_Ownership_Interest]
	@partyId INT, @newPartyIdProv INT,@accountId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

	Declare
		@dateCreated DATE,
		@inPartiesSubcontractor varchar(300)
	Declare
		@intErrorCode int,
		@partyIDs VARCHAR(500),
		@counts INT,
		@item INT,
		@isEqual INT,
		@message varchar(100)
	
	SET @dateCreated = GETDATE()
	SET @counts=0
	
	------------------------  Ownership/Control Interest Entity ----------------------------	
	
	DECLARE @partySubEnt_Id INT,@partySubEntB_Id INT, @SubTransEnt_Id INT, @addressSubEnt_Id INT, @locationSubEnt_Id INT,@orgSubEnt_id INT,
			@newPartySubTransEnt_Id INT,@newPartySubTransEntB_Id INT, @newAddressSubEnt_Id INT, @providerSubEnt_Id INT,@advSubEnt_id INT
	
	DECLARE OwnershipEnt_Cursor CURSOR FOR 	
	SELECT org.OrgID, party.PartyID                   
	FROM [KYPPORTAL].[PortalKYP].pPDM_Party as party INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Organization org ON party.PartyID = org.PartyID
	WHERE party.ParentPartyID = @partyId  AND  party.Type = 'Entity Ownership'
	
	OPEN OwnershipEnt_Cursor;
	FETCH NEXT FROM OwnershipEnt_Cursor INTO @orgSubEnt_id, @partySubEnt_Id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartySubTransEnt_Id = [KYPEnrollment].[p_Copy_Party] @partySubEnt_Id,@newPartyIdProv,@accountId,@lastActionUserID;
				
		--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
		EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubTransEnt_Id,@partySubEnt_Id,1;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Organization] @orgSubEnt_id,@newPartySubTransEnt_Id,@lastActionUserID;
				
		DECLARE SubcontractorEntAddLoca_Cursor CURSOR FOR 	
		SELECT address.AddressID, location.LocationID                   
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Organization org ON party.PartyID = org.PartyID
		WHERE party.PartyID = @partySubEnt_Id  AND  party.Type = 'Entity Ownership'
		
		OPEN SubcontractorEntAddLoca_Cursor;
		FETCH NEXT FROM SubcontractorEntAddLoca_Cursor INTO @addressSubEnt_Id, @locationSubEnt_Id 
		
		WHILE @@FETCH_STATUS = 0
		BEGIN			
			--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
			EXEC @newAddressSubEnt_Id = [KYPEnrollment].[p_Copy_Address] @addressSubEnt_Id,@lastActionUserID;
						
			--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Location] @locationSubEnt_Id,@newAddressSubEnt_Id,@newPartySubTransEnt_Id,NULL,NULL,@lastActionUserID;
						
			FETCH NEXT FROM SubcontractorEntAddLoca_Cursor INTO @addressSubEnt_Id, @locationSubEnt_Id 			
		END;
		CLOSE SubcontractorEntAddLoca_Cursor;
		DEALLOCATE SubcontractorEntAddLoca_Cursor;
				
		--***********Legal Applicant/Provider name************--
		SELECT @message = 'SubcontractorEntEntityAdvAction_Cursor---- : ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		SELECT @message = '@partySubEnt_Idr---- : ' + CONVERT(char(10), @partySubEnt_Id)
		RAISERROR(@message, 0, 1) WITH NOWAIT
				
		DECLARE SubcontractorEntEntityAdvAction_Cursor CURSOR FOR 	 
		SELECT party.PartyID, address.AddressID, location.LocationID,org.OrgID, pro.ProvID                 
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Organization org ON party.PartyID = org.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Provider pro ON party.PartyID = pro.PartyID
		WHERE party.ParentPartyID = @partySubEnt_Id  AND  party.Type = 'EntityAdvAction'	
			
		OPEN SubcontractorEntEntityAdvAction_Cursor;
		FETCH NEXT FROM SubcontractorEntEntityAdvAction_Cursor INTO @partySubEntB_Id, @addressSubEnt_Id, @locationSubEnt_Id, @orgSubEnt_id, @providerSubEnt_Id
		
		WHILE @@FETCH_STATUS = 0
		BEGIN			
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubTransEntB_Id = [KYPEnrollment].[p_Copy_Party] @partySubEntB_Id,@newPartySubTransEnt_Id,@accountId,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
			EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubTransEntB_Id,@partySubEntB_Id,1;			
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
			EXEC @newAddressSubEnt_Id = [KYPEnrollment].[p_Copy_Address] @addressSubEnt_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Location] @locationSubEnt_Id,@newAddressSubEnt_Id,@newPartySubTransEntB_Id,NULL,NULL,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Provider] @providerSubEnt_Id,@newPartySubTransEntB_Id,@lastActionUserID;
						
			--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Organization] @orgSubEnt_id,@newPartySubTransEntB_Id,@lastActionUserID;
			
			FETCH NEXT FROM SubcontractorEntEntityAdvAction_Cursor INTO @partySubEntB_Id, @addressSubEnt_Id, @locationSubEnt_Id, @orgSubEnt_id, @providerSubEnt_Id 			
		END;
		CLOSE SubcontractorEntEntityAdvAction_Cursor;
		DEALLOCATE SubcontractorEntEntityAdvAction_Cursor;
		
		SELECT @message = 'SubcontractorEntEntityAdvAction_Cursor---- : ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
		EXEC [KYPEnrollment].[p_Copy_Owner_Role] @partySubEnt_Id,@newPartySubTransEnt_Id,NULL,'party',@lastActionUserID;
		
		----------Program Actions----------------------------------------------------
		SELECT @message = 'New Program Actions: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		DECLARE OwnershipEnt_ProgramActions_Cursor CURSOR FOR 			             
		SELECT party.PartyID,pro.ProvID, adac.AdverseActionID                
		FROM [KYPPORTAL].[PortalKYP].pPDM_Party as party INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] adac ON party.PartyID = adac.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Provider pro ON party.PartyID = pro.PartyID
		WHERE party.ParentPartyID = @partySubEnt_Id  AND  party.Type = 'EntityQuestion'	
			
		OPEN OwnershipEnt_ProgramActions_Cursor;
		FETCH NEXT FROM OwnershipEnt_ProgramActions_Cursor INTO @partySubEntB_Id,@providerSubEnt_Id, @advSubEnt_id
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubTransEntB_Id = [KYPEnrollment].[p_Copy_Party] @partySubEntB_Id,@newPartySubTransEnt_Id,@accountId,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
			EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubTransEntB_Id,@partySubEntB_Id,1;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Provider] @providerSubEnt_Id,@newPartySubTransEntB_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_AdverseAction] @AdverseActionPartyID INT, @newPartyID INT, @typeSQL varchar(15)	(party OR AdverseAction)
			EXEC [KYPEnrollment].[p_Copy_AdverseAction] @partySubEntB_Id,@newPartySubTransEntB_Id,'party',@lastActionUserID;
						
			FETCH NEXT FROM OwnershipEnt_ProgramActions_Cursor INTO @partySubEntB_Id,@providerSubEnt_Id, @advSubEnt_id
		END;
		CLOSE OwnershipEnt_ProgramActions_Cursor;
		DEALLOCATE OwnershipEnt_ProgramActions_Cursor;
		
		SELECT @message = 'New Program Actions: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT
				
		--adverse Action Questionarie
		INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
		([PartyID] ,
		[Type_x] ,
		[Reason] ,
		[State_x] ,
		[Date_x] ,
		[DateType] ,
		[EffectiveDate] ,
		[NPI] ,
		[City] ,
		[ProgramType] ,
		[Where_x] ,
		[Action_x] ,
		[LicenseAuthority] ,
		[LastAction] ,
		[LastActionDate] ,
		[LastActorUserID] ,
		[LastActionApprovedBy], 
		[CurrentRecordFlag],
		[LegalName] ,
		[DBA] ,
		[AppFormID])
		SELECT @newPartySubTransEnt_Id
		,[Type_x]
		,[Reason]
		,[State_x]
		,[Date_x]
		,[DateType]
		,[EffectiveDate]
		,[NPI]
		,[City]
		,[ProgramType]
		,[Where_x]
		,[Action_x]
		,[LicenseAuthority]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[IsDeleted]
		,[LegalName]
		,[DBA]
		,[AppFormID]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE PartyID = @partySubEnt_Id AND [Type_x] IN ('EntityActionConviction','EntityActionLiability','EntityActionSettlement')
			
		----------Subcontractor Associations-------------------------------------------7-8-2015---------	
		SELECT @message = 'New Subcontractor Associations Entity: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		DECLARE @ownerRelationID INT, @partyIDOwned INT, @pdmOwnerID INT, @newOwnerRelationID INT, @newPartyIDOwned INT, @newPdmOwnerID INT,@typeAssociation VARCHAR(250),
		@sPartyID INT, @sAddressID INT, @sLocationID INT, @sPersonID INT, @newPartySubEntC_Id INT,@isNewPartyIDB INT
				
		DECLARE Subcontractor_AssociationsEnt_Cursor CURSOR FOR
		SELECT orl.[OwnerRelationID], orl.[PartyIDOwned], ore.[PdmOwnerID],orl.[TypeAssociation] FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] orl INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Owner_Role] ore ON orl.OwnerRelationID =ore.OwnerRelationID
		WHERE [PartyIDOwner] = @partySubEnt_Id AND (orl.[TypeAssociation] IN ('SubcontractorEntityAssociation','SubcontractorIndividualAssociation'))
		
		OPEN Subcontractor_AssociationsEnt_Cursor;
		FETCH NEXT FROM Subcontractor_AssociationsEnt_Cursor INTO @ownerRelationID , @partyIDOwned , @pdmOwnerID, @typeAssociation
		
		WHILE @@FETCH_STATUS = 0
		BEGIN	
			SET @isEqual = 0
			SET @isNewPartyIDB = 0
		
			DECLARE PartyIdsA_Cursor CURSOR FOR 		
			SELECT Item	FROM [KYPEnrollment].[SplitString](@partyIDs, ',')
			
			OPEN PartyIdsA_Cursor;
			FETCH NEXT FROM PartyIdsA_Cursor INTO @item
			
			WHILE @@FETCH_STATUS = 0
			BEGIN							
				IF(@partyIDOwned=@item)
				BEGIN					
					SET @isEqual = 1	
					SELECT @isNewPartyIDB=[NewPartyID] FROM [KYPEnrollment].[pAccount_PDM_PartyParty] WHERE [OldPartyID] = @partyIDOwned				
				END
				FETCH NEXT FROM PartyIdsA_Cursor INTO @item
			END;
			CLOSE PartyIdsA_Cursor;
			DEALLOCATE PartyIdsA_Cursor;
			
			IF (@typeAssociation = 'SubcontractorIndividualAssociation')
			BEGIN			
				SELECT @sPartyID=party.partyID, @sAddressID=address.AddressID, @sLocationID=location.LocationID, @sPersonID=person.PersonID
				FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
					  [KYPPORTAL].[PortalKYP].pPDM_Person  AS person ON party.PartyID = person.PartyID
				WHERE  party.PartyID = @partyIDOwned
			END
			ELSE
			BEGIN	
				IF (@typeAssociation = 'SubcontractorEntityAssociation')
				BEGIN		
					SELECT @sPartyID=party.partyID, @sAddressID=address.AddressID, @sLocationID=location.LocationID, @sPersonID=org.OrgID 
					FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Organization as org ON party.PartyID = org.PartyID
					WHERE party.PartyID = @partyIDOwned
				END	
			END		
			IF ((@typeAssociation = 'SubcontractorIndividualAssociation') OR (@typeAssociation = 'SubcontractorEntityAssociation'))
			BEGIN	
				SELECT @message = 'SubcontractorIndividualAssociation AND SubcontractorEntityAssociation: ' + CONVERT(char(10), @sPartyID)
				RAISERROR(@message, 0, 1) WITH NOWAIT
				IF(@isEqual = 0)
				BEGIN
					--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
					EXEC @newPartySubEntC_Id = [KYPEnrollment].[p_Copy_Party] @sPartyID,@newPartyIdProv,@accountId,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
					EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubEntC_Id,@sPartyID,1;
									
					--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
					EXEC @newAddressSubEnt_Id = [KYPEnrollment].[p_Copy_Address] @sAddressID,@lastActionUserID;
									
					--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
					EXEC [KYPEnrollment].[p_Copy_Location] @sLocationID,@newAddressSubEnt_Id,@newPartySubEntC_Id,NULL,NULL,@lastActionUserID;
															
					IF (@typeAssociation = 'SubcontractorEntityAssociation')
					BEGIN				
						--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
						EXEC [KYPEnrollment].[p_Copy_Organization] @sPersonID,@newPartySubEntC_Id,@lastActionUserID;						
					END
					ELSE
					BEGIN
						IF (@typeAssociation = 'SubcontractorIndividualAssociation')
						BEGIN					
							--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
							EXEC [KYPEnrollment].[p_Copy_Person] @sPersonID,@newPartySubEntC_Id,@lastActionUserID;						
						END
					END
					SELECT @message = '[pAccount_PDM_OwnershipRelationship] ' + CONVERT(char(10), 'BEGIN')
					RAISERROR(@message, 0, 1) WITH NOWAIT
					
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partyId INT,	@newPartyId INT
					EXEC [KYPEnrollment].[p_Copy_OwnerhipTransaction] @sPartyID ,@newPartySubEntC_Id,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
					EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID,@newPartySubTransEnt_Id,@newPartySubEntC_Id,@lastActionUserID;
									
					-----------------[pAccount_PDM_Owner_Role]--------------------------------
					--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
					EXEC [KYPEnrollment].[p_Copy_Owner_Role] @pdmOwnerID,NULL,@newOwnerRelationID,'owner_Role',@lastActionUserID;			
				END	
				ELSE
				BEGIN
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
					EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID,@newPartySubTransEnt_Id,@isNewPartyIDB,@lastActionUserID;
									
					-----------------[pAccount_PDM_Owner_Role]--------------------------------
					--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
					EXEC [KYPEnrollment].[p_Copy_Owner_Role] @ownerRelationID,NULL,@newOwnerRelationID,'OwnerRelation',@lastActionUserID;	
				END
			END		
			IF(@counts =0)
			BEGIN
				SET @partyIDs=@partyIDOwned
				SET @counts=1
			END
			ELSE
			BEGIN
				SET @partyIDs=@partyIDs+','+CONVERT(char(20), @partyIDOwned)
			END
			FETCH NEXT FROM Subcontractor_AssociationsEnt_Cursor INTO @ownerRelationID , @partyIDOwned , @pdmOwnerID, @typeAssociation
		END;
		CLOSE Subcontractor_AssociationsEnt_Cursor;
		DEALLOCATE Subcontractor_AssociationsEnt_Cursor;	
			
		SELECT @message = 'New Subcontractor Associations Entity: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		
		-----------------------------------------------Other Associations Entity---------------------------------------------------------------				
		DECLARE Other_AssociationsEnt_Cursor CURSOR FOR
		SELECT orl.[OwnerRelationID], orl.[PartyIDOwned],party.[Type] FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] party INNER JOIN 
		[KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] orl ON party.PartyID =orl.PartyIDOwned
		WHERE [PartyIDOwner] = @partySubEnt_Id AND (orl.[TypeAssociation] = 'EntityOwnershipAssociation')
		OPEN Other_AssociationsEnt_Cursor;
		FETCH NEXT FROM Other_AssociationsEnt_Cursor INTO @ownerRelationID , @partyIDOwned , @typeAssociation
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@typeAssociation = 'OtherOwnershipIndividual')
			BEGIN			
				SELECT @sPartyID=party.partyID, @sAddressID=address.AddressID, @sLocationID=location.LocationID, @sPersonID=person.PersonID
				FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
					  [KYPPORTAL].[PortalKYP].pPDM_Person  AS person ON party.PartyID = person.PartyID
				WHERE  party.PartyID = @partyIDOwned
			END
			ELSE
			BEGIN	
				IF (@typeAssociation = 'OtherOwnershipEntity')
				BEGIN		
					SELECT @sPartyID=party.partyID, @sAddressID=address.AddressID, @sLocationID=location.LocationID, @sPersonID=org.OrgID 
					FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Organization as org ON party.PartyID = org.PartyID
					WHERE party.PartyID = @partyIDOwned
				END	
			END	
				
			IF ((@typeAssociation = 'OtherOwnershipIndividual') OR (@typeAssociation = 'OtherOwnershipEntity'))
			BEGIN
				--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
				EXEC @newPartySubEntC_Id = [KYPEnrollment].[p_Copy_Party] @sPartyID,@newPartySubTransEnt_Id,@accountId,@lastActionUserID;
				
				--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
				EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubEntC_Id,@sPartyID,1;
				
				--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
				EXEC @newAddressSubEnt_Id = [KYPEnrollment].[p_Copy_Address] @sAddressID,@lastActionUserID;
				
				--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
				EXEC [KYPEnrollment].[p_Copy_Location] @sLocationID,@newAddressSubEnt_Id,@newPartySubEntC_Id,NULL,NULL,@lastActionUserID;			
										
				IF (@typeAssociation = 'OtherOwnershipEntity')
				BEGIN				
					--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
					EXEC [KYPEnrollment].[p_Copy_Organization] @sPersonID,@newPartySubEntC_Id,@lastActionUserID;					
				END
				ELSE
				BEGIN
					IF (@typeAssociation = 'OtherOwnershipIndividual')
					BEGIN					
						--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
						EXEC [KYPEnrollment].[p_Copy_Person] @sPersonID,@newPartySubEntC_Id,@lastActionUserID;						
					END
				END
				SELECT @message = '[pAccount_PDM_OwnershipRelationship] ' + CONVERT(char(10), 'BEGIN')
				RAISERROR(@message, 0, 1) WITH NOWAIT
				
				--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
				EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID,@newPartySubTransEnt_Id ,@newPartySubEntC_Id,@lastActionUserID;
			
			END		
			FETCH NEXT FROM Other_AssociationsEnt_Cursor INTO @ownerRelationID , @partyIDOwned , @typeAssociation
		END;
		CLOSE Other_AssociationsEnt_Cursor;
		DEALLOCATE Other_AssociationsEnt_Cursor;	
		
		SELECT @message = 'New Ownership/Control Interest Organization: ' + CONVERT(char(10), 'OK')
		RAISERROR(@message, 0, 1) WITH NOWAIT		
	
	FETCH NEXT FROM OwnershipEnt_Cursor INTO @orgSubEnt_id, @partySubEnt_Id
	END;
	CLOSE OwnershipEnt_Cursor;
	DEALLOCATE OwnershipEnt_Cursor;
		
		
	------------------------  Ownership/Control Interest Individual -----------------------------------------------------------------------
	DECLARE @partySubInd_Id INT, @subcontractorInd_Id INT, @addressSubInd_Id INT, @locationSubInd_Id INT,
			@personSubInd_id INT, @newPartySubInd_Id INT, @newAddressSubInd_Id INT, @partySubIndB_Id INT, @orgSubInd_id INT, @providerSubInd_Id INT,
			@newPartySubTransIndB_Id INT, @advSubInd_id INT, @newProviderSubInd_Id INT,@providerSubIndB_Id INT
			
	SELECT @message = 'Ownership/Control Interest Individual: ' + CONVERT(char(10), 'BEGIN')
	RAISERROR(@message, 0, 1) WITH NOWAIT
		
	DECLARE OwnershipInd_Cursor CURSOR FOR 
	SELECT party.PartyID, address.AddressID, location.LocationID, pers.PersonID , prov.ProvID 
	FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
	  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
	  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
	  [KYPPORTAL].[PortalKYP].pPDM_Person as pers ON party.PartyID = pers.PartyID INNER JOIN 
	  [KYPPORTAL].[PortalKYP].pPDM_Provider as prov ON party.PartyID = prov.PartyID
	WHERE party.ParentPartyID = @partyId  AND  party.Type = 'Individual Ownership'
	
	OPEN OwnershipInd_Cursor;
	FETCH NEXT FROM OwnershipInd_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id,@providerSubInd_Id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartySubInd_Id = [KYPEnrollment].[p_Copy_Party] @partySubInd_Id,@newPartyIdProv,@accountId,@lastActionUserID;
				
		--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
		EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubInd_Id,@partySubInd_Id,1;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressSubInd_Id = [KYPEnrollment].[p_Copy_Address] @addressSubInd_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationSubInd_Id,@newAddressSubInd_Id,@newPartySubInd_Id,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Person] @personSubInd_id,@newPartySubInd_Id,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Provider] @providerSubInd_Id,@newPartySubInd_Id,@lastActionUserID;
		
		SELECT @message = 'SubcontractorIndAdvAction_Cursor--------: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		DECLARE SubcontractorIndAdvAction_Cursor CURSOR FOR 	 
		SELECT party.PartyID, address.AddressID, location.LocationID,org.OrgID, pro.ProvID                 
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Organization org ON party.PartyID = org.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Provider pro ON party.PartyID = pro.PartyID
		WHERE party.ParentPartyID = @partySubInd_Id  AND  party.Type = 'Individual Identification'	
			
		OPEN SubcontractorIndAdvAction_Cursor;
		FETCH NEXT FROM SubcontractorIndAdvAction_Cursor INTO @partySubIndB_Id, @addressSubInd_Id, @locationSubInd_Id, @orgSubInd_id, @providerSubIndB_Id
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubTransIndB_Id = [KYPEnrollment].[p_Copy_Party] @partySubIndB_Id,@newPartySubInd_Id,@accountId,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
			EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubTransIndB_Id,@partySubIndB_Id,1;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
			EXEC @newAddressSubInd_Id = [KYPEnrollment].[p_Copy_Address] @addressSubInd_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Location] @locationSubInd_Id,@newAddressSubInd_Id,@newPartySubTransIndB_Id,NULL,NULL,@lastActionUserID;
						
			--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Provider] @providerSubIndB_Id,@newPartySubTransIndB_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Organization] @orgSubInd_id,@newPartySubTransIndB_Id,@lastActionUserID;
			
			FETCH NEXT FROM SubcontractorIndAdvAction_Cursor INTO @partySubIndB_Id, @addressSubInd_Id, @locationSubInd_Id, @orgSubInd_id, @providerSubIndB_Id 			
		END;
		CLOSE SubcontractorIndAdvAction_Cursor;
		DEALLOCATE SubcontractorIndAdvAction_Cursor;
		
		SELECT @message = 'SubcontractorIndAdvAction_Cursor--------: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT
				
		-----------------[pAccount_PDM_Owner_Role]--------------------------------
		--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
		EXEC [KYPEnrollment].[p_Copy_Owner_Role] @partySubInd_Id,@newPartySubInd_Id,NULL,'party',@lastActionUserID;				
		----------Program Actions----------------------------------------------------
		
		SELECT @message = 'New Program Actions: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		DECLARE OwnershipInd_ProgramActions_Cursor CURSOR FOR 			             
		SELECT party.PartyID,pro.ProvID, adac.AdverseActionID                
		FROM [KYPPORTAL].[PortalKYP].pPDM_Party as party INNER JOIN
			[KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] adac ON party.PartyID = adac.PartyID INNER JOIN
			[KYPPORTAL].[PortalKYP].pPDM_Provider pro ON party.PartyID = pro.PartyID
		WHERE party.ParentPartyID = @partySubInd_Id  AND  party.Type = 'InvActionQuestion'	
			
		OPEN OwnershipInd_ProgramActions_Cursor;
		FETCH NEXT FROM OwnershipInd_ProgramActions_Cursor INTO @partySubIndB_Id,@providerSubInd_Id, @advSubInd_id
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubTransIndB_Id = [KYPEnrollment].[p_Copy_Party] @partySubIndB_Id,@newPartySubInd_Id,@accountId,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
			EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubTransIndB_Id,@partySubIndB_Id,1;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Provider] @providerSubInd_Id,@newPartySubTransIndB_Id,@lastActionUserID;
			
			--ALTER PROCEDURE [KYPEnrollment].[p_Copy_AdverseAction] @AdverseActionPartyID INT,@newPartyID INT,@typeSQL varchar(15)(party or AdverseAction)
			EXEC [KYPEnrollment].[p_Copy_AdverseAction] @partySubIndB_Id ,@newPartySubTransIndB_Id ,'party',@lastActionUserID;
			
			FETCH NEXT FROM OwnershipInd_ProgramActions_Cursor INTO @partySubIndB_Id,@providerSubInd_Id, @advSubInd_id
		END;
		CLOSE OwnershipInd_ProgramActions_Cursor;
		DEALLOCATE OwnershipInd_ProgramActions_Cursor;
		
		SELECT @message = 'New Program Actions: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		--adverse Action Questionarie
		INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
		([PartyID] ,
		[Type_x] ,
		[Reason] ,
		[State_x] ,
		[Date_x] ,
		[DateType] ,
		[EffectiveDate] ,
		[NPI] ,
		[City] ,
		[ProgramType] ,
		[Where_x] ,
		[Action_x] ,
		[LicenseAuthority] ,
		[LastAction] ,
		[LastActionDate] ,
		[LastActorUserID] ,
		[LastActionApprovedBy], 
		[CurrentRecordFlag],
		[LegalName] ,
		[DBA] ,
		[AppFormID])
		SELECT @newPartySubInd_Id
		,[Type_x]
		,[Reason]
		,[State_x]
		,[Date_x]
		,[DateType]
		,[EffectiveDate]
		,[NPI]
		,[City]
		,[ProgramType]
		,[Where_x]
		,[Action_x]
		,[LicenseAuthority]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[IsDeleted]
		,[LegalName]
		,[DBA]
		,[AppFormID]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] 
		WHERE PartyID = @partySubInd_Id AND [Type_x] IN ('IndQuestionnaireSuspendedRevoked','IndQuestionnaireDisciplinaryHearing','IndQuestionnaireOtherApproval','InvActionConviction','InvActionLiability','InvActionSettlement')
		--([Type_x] = 'IndQuestionnaireSuspendedRevoked' OR [Type_x] = 'IndQuestionnaireDisciplinaryHearing' OR [Type_x] = 'IndQuestionnaireOtherApproval' OR	[Type_x] = 'InvActionConviction' OR [Type_x] = 'InvActionLiability' OR [Type_x] = 'InvActionSettlement' )
			
		----------Subcontractor Associations-------------------------------------------7-8-2015---------		
		SELECT @message = 'New Subcontractor Associations Individual: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		DECLARE @ownerRelationIDE INT, @partyIDOwnedE INT, @pdmOwnerIDE INT, @newOwnerRelationIDE INT, @newPartyIDOwnedE INT, @newPdmOwnerIDE INT,@typeAssociationE VARCHAR(250),
		@sPartyIDE INT, @sAddressIDE INT, @sLocationIDE INT, @sPersonIDE INT, @newPartySubIndB_Id INT, @isNewPartyID INT
		
		DECLARE Subcontractor_AssociationsInd_Cursor CURSOR FOR
		SELECT orl.[OwnerRelationID], orl.[PartyIDOwned], ore.[PdmOwnerID],orl.[TypeAssociation] 
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] orl INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Owner_Role] ore ON orl.OwnerRelationID =ore.OwnerRelationID
		WHERE [PartyIDOwner] = @partySubInd_Id AND orl.[TypeAssociation] IN('SubcontractorEntityAssociation','SubcontractorIndividualAssociation')
		--(orl.[TypeAssociation] = 'SubcontractorEntityAssociation' OR orl.[TypeAssociation] = 'SubcontractorIndividualAssociation')
		
		OPEN Subcontractor_AssociationsInd_Cursor;
		FETCH NEXT FROM Subcontractor_AssociationsInd_Cursor INTO @ownerRelationIDE , @partyIDOwnedE , @pdmOwnerIDE, @typeAssociationE
		
		WHILE @@FETCH_STATUS = 0
		BEGIN					
			SET @isEqual = 0
			SET @isNewPartyID = 0
		
			DECLARE PartyIdsA_Cursor CURSOR FOR 		
			SELECT Item	FROM [KYPEnrollment].[SplitString](@partyIDs, ',')
			
			OPEN PartyIdsA_Cursor;
			FETCH NEXT FROM PartyIdsA_Cursor INTO @item
			
			WHILE @@FETCH_STATUS = 0
			BEGIN							
				IF(@partyIDOwnedE=@item)
				BEGIN					
					SET @isEqual = 1	
					SELECT @isNewPartyID=[NewPartyID] FROM [KYPEnrollment].[pAccount_PDM_PartyParty] WHERE [OldPartyID] = @partyIDOwnedE				
				END
				FETCH NEXT FROM PartyIdsA_Cursor INTO @item
			END;
			CLOSE PartyIdsA_Cursor;
			DEALLOCATE PartyIdsA_Cursor;			
			
			SELECT @message = '@isNewPartyID=====@partyIDOwnedE: ' + CONVERT(char(10), @isNewPartyID) + CONVERT(char(10), @partyIDOwnedE)
			RAISERROR(@message, 0, 1) WITH NOWAIT
			
			IF (@typeAssociationE = 'SubcontractorIndividualAssociation')
			BEGIN			
				SELECT @sAddressIDE=address.AddressID, @sLocationIDE=location.LocationID, @sPersonIDE=person.PersonID
				FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
					  [KYPPORTAL].[PortalKYP].pPDM_Person  AS person ON party.PartyID = person.PartyID
				WHERE  party.PartyID = @partyIDOwnedE
			END
			ELSE
			BEGIN	
				IF (@typeAssociationE = 'SubcontractorEntityAssociation')
				BEGIN		
					SELECT @sAddressIDE=address.AddressID, @sLocationIDE=location.LocationID, @sPersonIDE=org.OrgID 
					FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Organization as org ON party.PartyID = org.PartyID
					WHERE party.PartyID = @partyIDOwnedE
				END	
			END		
			IF ((@typeAssociationE = 'SubcontractorIndividualAssociation') OR (@typeAssociationE = 'SubcontractorEntityAssociation'))
			BEGIN
				IF(@isEqual=0)
				BEGIN	
					--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
					EXEC @newPartySubIndB_Id = [KYPEnrollment].[p_Copy_Party] @partyIDOwnedE,@newPartyIdProv,@accountId,@lastActionUserID;								
					
					--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
					EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubIndB_Id,@partyIDOwnedE,1;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
					EXEC @newAddressSubInd_Id = [KYPEnrollment].[p_Copy_Address] @sAddressIDE,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
					EXEC [KYPEnrollment].[p_Copy_Location] @sLocationIDE,@newAddressSubInd_Id,@newPartySubIndB_Id,NULL,NULL,@lastActionUserID;
										
					IF (@typeAssociationE = 'SubcontractorEntityAssociation')
					BEGIN
						--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
						EXEC [KYPEnrollment].[p_Copy_Organization] @sPersonIDE,@newPartySubIndB_Id,@lastActionUserID;						
					END
					ELSE
					BEGIN
						IF (@typeAssociationE = 'SubcontractorIndividualAssociation')
						BEGIN
							--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
							EXEC [KYPEnrollment].[p_Copy_Person] @sPersonIDE,@newPartySubIndB_Id,@lastActionUserID;							
						END
					END	
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partyId INT,	@newPartyId INT
					EXEC [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partyIDOwnedE ,@newPartySubIndB_Id,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
					EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationIDE,@newPartySubInd_Id,@newPartySubIndB_Id,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
					EXEC [KYPEnrollment].[p_Copy_Owner_Role] @pdmOwnerIDE,NULL,@newOwnerRelationID,'owner_Role',@lastActionUserID;					
				END					
				ELSE
				BEGIN
					--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
					EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationIDE,@newPartySubInd_Id,@isNewPartyID,@lastActionUserID;
					
					--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
					EXEC [KYPEnrollment].[p_Copy_Owner_Role] @pdmOwnerIDE,NULL,@newOwnerRelationID,'owner_Role',@lastActionUserID;
				END
			END					
			IF(@counts =0)
			BEGIN
				SET @partyIDs=@partyIDOwnedE
				SET @counts=1
			END
			ELSE
			BEGIN
				SET @partyIDs=@partyIDs+','+CONVERT(char(20), @partyIDOwnedE)
			END				
			FETCH NEXT FROM Subcontractor_AssociationsInd_Cursor INTO @ownerRelationIDE , @partyIDOwnedE , @pdmOwnerIDE, @typeAssociationE
		END;
		CLOSE Subcontractor_AssociationsInd_Cursor;
		DEALLOCATE Subcontractor_AssociationsInd_Cursor;
			
		SELECT @message = 'New Subcontractor Associations Individual: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT
		
		-----------------------------------------------Other Associations Individual---------------------------------------------------------------				
		DECLARE Other_AssociationsInd_Cursor CURSOR FOR
		SELECT orl.[OwnerRelationID], orl.[PartyIDOwned],party.[Type] FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] party INNER JOIN 
		[KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] orl ON party.PartyID =orl.PartyIDOwned
		WHERE [PartyIDOwner] = @partySubInd_Id AND (orl.[TypeAssociation] = 'EntityOwnershipAssociation')
		OPEN Other_AssociationsInd_Cursor;
		FETCH NEXT FROM Other_AssociationsInd_Cursor INTO @ownerRelationIDE , @partyIDOwnedE , @typeAssociationE
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF (@typeAssociationE = 'OtherOwnershipIndividual')
			BEGIN			
				SELECT @sPartyIDE=party.partyID, @sAddressIDE=address.AddressID, @sLocationIDE=location.LocationID, @sPersonIDE=person.PersonID
				FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
					  [KYPPORTAL].[PortalKYP].pPDM_Person  AS person ON party.PartyID = person.PartyID
				WHERE  party.PartyID = @partyIDOwnedE
			END
			ELSE
			BEGIN	
				IF (@typeAssociationE = 'OtherOwnershipEntity')
				BEGIN		
					SELECT @sPartyIDE=party.partyID, @sAddressIDE=address.AddressID, @sLocationIDE=location.LocationID, @sPersonIDE=org.OrgID 
					FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
					[KYPPORTAL].[PortalKYP].pPDM_Organization as org ON party.PartyID = org.PartyID
					WHERE party.PartyID = @partyIDOwnedE
				END	
			END	
				
			IF ((@typeAssociationE = 'OtherOwnershipIndividual') OR (@typeAssociationE = 'OtherOwnershipEntity'))
			BEGIN
				--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
				EXEC @newPartySubEntC_Id = [KYPEnrollment].[p_Copy_Party] @sPartyIDE,@newPartySubInd_Id,@accountId,@lastActionUserID;
								
				--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
				EXEC @newAddressSubEnt_Id = [KYPEnrollment].[p_Copy_Address] @sAddressIDE,@lastActionUserID;
				
				--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
				EXEC [KYPEnrollment].[p_Copy_Location] @sLocationIDE,@newAddressSubEnt_Id,@newPartySubEntC_Id,NULL,NULL,@lastActionUserID;			
										
				IF (@typeAssociationE = 'OtherOwnershipEntity')
				BEGIN				
					--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
					EXEC [KYPEnrollment].[p_Copy_Organization] @sPersonIDE,@newPartySubEntC_Id,@lastActionUserID;						
				END
				ELSE
				BEGIN
					IF (@typeAssociation = 'OtherOwnershipIndividual')
					BEGIN					
						--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
						EXEC [KYPEnrollment].[p_Copy_Person] @sPersonIDE,@newPartySubEntC_Id,@lastActionUserID;						
					END
				END				
				--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
				EXEC @newOwnerRelationID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationIDE,@newPartySubInd_Id ,@newPartySubEntC_Id,@lastActionUserID;			
			END		
			FETCH NEXT FROM Other_AssociationsInd_Cursor INTO @ownerRelationIDE , @partyIDOwnedE , @typeAssociationE
		END;
		CLOSE Other_AssociationsInd_Cursor;
		DEALLOCATE Other_AssociationsInd_Cursor;	
		--------------------------------------------------------------------------------------------------------------
		
		SELECT @message = 'New Ownership/Control Interest Individual: ' + CONVERT(char(10), 'OK')
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		
	FETCH NEXT FROM OwnershipInd_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id,@providerSubInd_Id
	END;
	CLOSE OwnershipInd_Cursor;
	DEALLOCATE OwnershipInd_Cursor;	
	
	--------------------------------------Individual Associations------------------------------------------------------------------------
	DECLARE @partyPartyID INT, @newPartyPartyID INT,@newPartyPartyIDB INT, @oldPartyPartyID INT, @isTrue INT, @ownerRelationAssID INT, @partyAssIDOwned INT, @partyAssInd_Id INT,
	@partyPartyIDTmp INT, @newPartyPartyIDTmp INT, @oldPartyPartyIDTmp INT, @newOwnerRelationAssID INT,@pdmOwnerAssID INT
	
	SELECT @message = 'Individual Associations: ' + CONVERT(char(10), 'BEGIN')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	DECLARE OwnershipAssInd_Cursor CURSOR FOR 
	SELECT party.PartyID
	FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Person as pers ON party.PartyID = pers.PartyID
	WHERE party.ParentPartyID = @partyId  AND  party.Type = 'Individual Ownership'
	
	OPEN OwnershipAssInd_Cursor;
	FETCH NEXT FROM OwnershipAssInd_Cursor INTO @partyAssInd_Id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN	
		SELECT @message = 'Individual Associations @partyAssInd_Id: ' + CONVERT(char(10), @partyAssInd_Id)
		RAISERROR(@message, 0, 1) WITH NOWAIT
	
		DECLARE OwnershipIndAss_Cursor CURSOR FOR 
		SELECT po.OwnerRelationID,po.PartyIDOwned
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] AS po 
		WHERE po.[PartyIDOwner] = @partyAssInd_Id  AND [TypeAssociation] IN ('OwnershipEntityAssociation','OwnershipIndividualAssociation')
		OPEN OwnershipIndAss_Cursor;
		FETCH NEXT FROM OwnershipIndAss_Cursor INTO @ownerRelationAssID,@partyAssIDOwned
		
		WHILE @@FETCH_STATUS = 0
		BEGIN	
			SELECT @message = '@partyAssIDOwned=@partyAssInd_Id: ' + CONVERT(char(10), @partyAssIDOwned)+'='+ CONVERT(char(10), @partyAssInd_Id)
			RAISERROR(@message, 0, 1) WITH NOWAIT
			
			select @newPartyPartyID=ppy.[NewPartyID]
			from [KYPEnrollment].[pAccount_PDM_PartyParty] ppy 
			WHERE ppy.[OldPartyID] = @partyAssInd_Id 
			
			select @newPartyPartyIDB=ppy.[NewPartyID]
			from [KYPEnrollment].[pAccount_PDM_PartyParty] ppy 
			WHERE ppy.[OldPartyID] = @partyAssIDOwned 
						
			SELECT @message = '@newPartyPartyID: ' + CONVERT(char(10), @newPartyPartyID)
			RAISERROR(@message, 0, 1) WITH NOWAIT
			
			SELECT @message = '@newPartyPartyIDB: ' + CONVERT(char(10), @newPartyPartyIDB)
			RAISERROR(@message, 0, 1) WITH NOWAIT
			
			SELECT @message = '@pdmOwnerAssID: ' + CONVERT(char(10), @pdmOwnerAssID)
			RAISERROR(@message, 0, 1) WITH NOWAIT

			IF (ISNULL(@newPartyPartyID,0) <> 0 AND ISNULL(@newPartyPartyIDB,0) <> 0)
			BEGIN
				--PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationID INT, @newPartyIDOwner INT,	@newPartyIDOwned INT
				EXEC @newOwnerRelationAssID = [KYPEnrollment].[p_Copy_OwnershipRelationship] @ownerRelationAssID,@newPartyPartyID ,@newPartyPartyIDB,@lastActionUserID;
				
				-----------------[pAccount_PDM_Owner_Role]--------------------------------
				--PROCEDURE [KYPEnrollment].[p_Copy_Owner_Role]	@pdmOwnerID INT,@newPartyID INT,@newOwnerRelationID INT,@isType varchar(15) (party, owner_Role or OwnerRelation)
				EXEC [KYPEnrollment].[p_Copy_Owner_Role] @ownerRelationAssID,NULL,@newOwnerRelationAssID,'OwnerRelation',@lastActionUserID;				
			END			
			FETCH NEXT FROM OwnershipIndAss_Cursor INTO @ownerRelationAssID,@partyAssIDOwned
		END;
		CLOSE OwnershipIndAss_Cursor;
		DEALLOCATE OwnershipIndAss_Cursor;
		FETCH NEXT FROM OwnershipAssInd_Cursor INTO @partyAssInd_Id
	END;
	CLOSE OwnershipAssInd_Cursor;
	DEALLOCATE OwnershipAssInd_Cursor;	
	
	SELECT @message = 'Individual Associations: ' + CONVERT(char(10), 'END')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	--------------------------------------------------------------------------------------------------------------
	
	SELECT @message = 'Ownership/Control Interest Individual: ' + CONVERT(char(10), 'END')
	RAISERROR(@message, 0, 1) WITH NOWAIT
		
	--------------------------- SubcontractorInd_Ind_Cursor-----------------------------------------
	DECLARE @isNewPartyIDA INT
	
	SET @partyIDs=RTRIM(LTRIM(replace(@partyIDs,' ', '')))
	SELECT @message = '@partyIDs-------------------' + CONVERT(char(500), @partyIDs)
	RAISERROR(@message, 0, 1) WITH NOWAIT		
		
	DECLARE SubcontractorInd_Cursor CURSOR FOR 
	SELECT party.partyID, address.AddressID, location.LocationID, person.PersonID
	FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
		  [KYPPORTAL].[PortalKYP].pPDM_Person  AS person ON party.PartyID = person.PartyID
	WHERE  party.ParentPartyID = @partyId  AND  party.Type = 'SubcontractorIndividual'
	
	OPEN SubcontractorInd_Cursor;
	FETCH NEXT FROM SubcontractorInd_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN					
		SET @isEqual = 0
		
		DECLARE PartyIdsA_Cursor CURSOR FOR 		
		SELECT Item	FROM [KYPEnrollment].[SplitString](@partyIDs, ',')
		
		OPEN PartyIdsA_Cursor;
		FETCH NEXT FROM PartyIdsA_Cursor INTO @item
		
		WHILE @@FETCH_STATUS = 0
		BEGIN						
			IF(@partySubInd_Id=@item)
			BEGIN							
				SET @isEqual = 1				
				SELECT @isNewPartyIDA=[NewPartyID] FROM [KYPEnrollment].[pAccount_PDM_PartyParty] WHERE [OldPartyID] = @partySubInd_Id			
			END
			FETCH NEXT FROM PartyIdsA_Cursor INTO @item
		END;
		CLOSE PartyIdsA_Cursor;
		DEALLOCATE PartyIdsA_Cursor;
		
		IF(@isEqual=0)
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubInd_Id = [KYPEnrollment].[p_Copy_Party] @partySubInd_Id,@newPartyIdProv,@accountId,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Insert_PDM_PartyParty] @partyPartyId INT, @newPartyId INT, @oldPartyId INT, @action INT
			EXEC [KYPEnrollment].[p_Insert_PDM_PartyParty] NULL,@newPartySubInd_Id,@partySubInd_Id,1;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
			EXEC @newAddressSubInd_Id = [KYPEnrollment].p_Copy_Address @addressSubInd_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Location] @locationSubInd_Id,@newAddressSubInd_Id,@newPartySubInd_Id,NULL,NULL,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Person] @personSubInd_id,@newPartySubInd_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partyId INT, @newPartyId INT
			EXEC @newAddressSubInd_Id = [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partySubInd_Id,@newPartySubInd_Id,@lastActionUserID;
		END			
		FETCH NEXT FROM SubcontractorInd_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id
	END;
	CLOSE SubcontractorInd_Cursor;
	DEALLOCATE SubcontractorInd_Cursor;
	
	----------------------------- SubcontractorInd_Ent_Cursor-----------------------------------			
	SET @isNewPartyIDA=0
	SET @partyIDs=RTRIM(LTRIM(replace(@partyIDs,' ', '')))
	SELECT @message = '@partyIDs-------------------' + CONVERT(char(500), @partyIDs)
	RAISERROR(@message, 0, 1) WITH NOWAIT
			
	DECLARE SubcontractorEnt_Cursor CURSOR FOR 
	SELECT party.partyID, address.AddressID, location.LocationID, org.OrgId
	FROM  [KYPPORTAL].[PortalKYP].pPDM_Address AS address INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Location AS location ON address.AddressID = location.AddressID INNER JOIN
		  [KYPPORTAL].[PortalKYP].pPDM_Party AS party ON location.PartyID = party.PartyID INNER JOIN           
		  [KYPPORTAL].[PortalKYP].pPDM_Organization  AS org ON party.PartyID = org.PartyID
	WHERE  party.ParentPartyID = @partyId  AND  party.Type = 'SubcontractorEntity'
	
	OPEN SubcontractorEnt_Cursor;
	FETCH NEXT FROM SubcontractorEnt_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN				
		SET @isEqual = 0
		
		DECLARE PartyIdsA_Cursor CURSOR FOR 		
		SELECT Item	FROM [KYPEnrollment].[SplitString](@partyIDs, ',')
		
		OPEN PartyIdsA_Cursor;
		FETCH NEXT FROM PartyIdsA_Cursor INTO @item
		
		WHILE @@FETCH_STATUS = 0
		BEGIN						
			IF(@partySubInd_Id=@item)
			BEGIN				
				SET @isEqual = 1			
				SELECT @isNewPartyIDA=[NewPartyID] FROM [KYPEnrollment].[pAccount_PDM_PartyParty] WHERE [OldPartyID] = @partySubInd_Id		
			END
			FETCH NEXT FROM PartyIdsA_Cursor INTO @item
		END;
		CLOSE PartyIdsA_Cursor;
		DEALLOCATE PartyIdsA_Cursor;
		
		IF(@isEqual=0)
		BEGIN
			--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
			EXEC @newPartySubInd_Id = [KYPEnrollment].[p_Copy_Party] @partySubInd_Id,@newPartyIdProv,@accountId,@lastActionUserID;
						
			--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
			EXEC @newAddressSubInd_Id = [KYPEnrollment].p_Copy_Address @addressSubInd_Id,@lastActionUserID;
			
			--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT, @newAddressId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Location] @locationSubInd_Id,@newAddressSubInd_Id,@newPartySubInd_Id,NULL,NULL,@lastActionUserID;
						
			--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_Organization] @personSubInd_id,@newPartySubInd_Id,@lastActionUserID;		
			
			--PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partyId INT, @newPartyId INT
			EXEC [KYPEnrollment].[p_Copy_OwnerhipTransaction] @partySubInd_Id,@newPartySubInd_Id,@lastActionUserID;	
		END		
		FETCH NEXT FROM SubcontractorEnt_Cursor INTO @partySubInd_Id, @addressSubInd_Id, @locationSubInd_Id, @personSubInd_id
	END;
	CLOSE SubcontractorEnt_Cursor;
	DEALLOCATE SubcontractorEnt_Cursor;					
END


GO

