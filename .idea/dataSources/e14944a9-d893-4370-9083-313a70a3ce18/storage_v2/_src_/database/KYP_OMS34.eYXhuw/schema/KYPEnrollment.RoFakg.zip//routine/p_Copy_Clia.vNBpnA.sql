
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Clia recive 3 parametros
-- @partyIdPortal id party old portal con el cual se realiza la insert ,@partyIdOMS nuevo id party para realizar el registro ,@lastActionUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Clia]
	@partyIdPortal INT,
	@partyIdOMS INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF((SELECT COUNT([CliaID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Clia] WHERE PartyID = @partyIdPortal)>0)
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Clia]
	([LabType]
	,[CertificateType]
	,[LabName]
	,[LabAddressLine1]
	,[LabAddressLine2]
	,[LabCity]
	,[LabState]
	,[LabZip9]
	,[LastAction]
	,[LastActionDate]
	,[LastActorUserID]	
	,[LastActionApprovedByUsedID]
	,[CurrentRecordFlag]
	,[PartyID]
	,[CliaNumber]
	,[RegistrationNumber])	
	SELECT null --[LabType]
	,null --[CertificateType]
	,null --[LabName] 
	,null --[LabAddressLine1]
	,null --[LabAddressLine2]
	,null --[LabCity]
	,null --[LabState]
	,null --[LabZip9]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,@partyIdOMS
	,[CliaNumber]
	,[RegistrationNumber]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Clia] WHERE PartyID = @partyIdPortal

	SELECT @message = 'New newCliaId: ' + CONVERT(char(10), 'Clia copy')
	RAISERROR(@message, 0, 1) WITH NOWAIT

	END					
END


GO

