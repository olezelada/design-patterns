

CREATE VIEW [KYP].[v_InstitutionalRAlerts]
AS
SELECT DISTINCT 
                      TOP (100) PERCENT KYP.MDM_Alert.AlertID, KYP.MDM_Alert.AlertNo, KYP.MDM_Alert.AssignedByUserID, KYP.MDM_Alert.DateInitiated, 
                      KYP.MDM_Alert.WatchlistName, KYP.MDM_Alert.MatchPercent, KYP.MDM_Alert.WatchedPartyID, KYP.MDM_Alert.WatchedPartyName, 
                      KYP.MDM_Alert.IsMerged, KYP.MDM_Alert.NoOfMergedAlerts, KYP.MDM_Alert.IsDeleted, KYP.MDM_Alert.DateInitiated AS Expr1, 
                      KYP.MDM_Alert.WatchedPartyName AS FullName, KYP.MDM_Alert.WatchedPartyType, KYP.PDM_Organization.DBAName1, 
                      KYP.PDM_Organization.DBAName2, KYP.PDM_Organization.LegalName, KYP.PDM_Organization.TIN, KYP.PDM_Party.Name, 
                      KYP.MDM_Alert.WFMinorDisposition AS 'CurrentWFMinorStatus', KYP.MDM_Alert.AssignedToUserID, KYP.OIS_User.FullName AS Full_Name
                      , KYP.MDM_Alert.Priority
FROM         KYP.MDM_Alert INNER JOIN
                      KYP.PDM_Party ON KYP.MDM_Alert.WatchedPartyID = KYP.PDM_Party.PartyID LEFT OUTER JOIN
                      KYP.OIS_User ON KYP.MDM_Alert.AssignedToUserID = KYP.OIS_User.PersonID LEFT OUTER JOIN
                      KYP.PDM_Organization ON KYP.PDM_Organization.PartyID = KYP.MDM_Alert.WatchedPartyID LEFT OUTER JOIN
                      KYP.PDM_Owner ON KYP.PDM_Owner.PartyID = KYP.MDM_Alert.WatchedPartyID
WHERE     (KYP.MDM_Alert.WatchedPartyType = 'Institutional' AND KYP.MDM_Alert.ActivityStatus NOT IN ('Consulted'))
ORDER BY KYP.MDM_Alert.AlertID


GO

