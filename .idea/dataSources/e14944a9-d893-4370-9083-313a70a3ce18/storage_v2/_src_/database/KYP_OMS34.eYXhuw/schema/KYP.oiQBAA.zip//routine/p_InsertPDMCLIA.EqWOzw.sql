/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMCLIA]
(
 @PartyID int
 ,@CLIA_NBR varchar(15)= NULL
 ,@DateModified Datetime=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
 
)
as begin 

INSERT INTO [KYP].[PDM_CLIA]
           (
           [PartyID]
           ,[CLIA_NBR]
           ,[DateModified]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted])
     VALUES
           (@PartyID
           ,@CLIA_NBR
           ,@DateModified
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DeletedBy
           ,@DateDeleted)

	return IDENT_CURRENT('[KYP].[PDM_CLIA]')

end


GO

