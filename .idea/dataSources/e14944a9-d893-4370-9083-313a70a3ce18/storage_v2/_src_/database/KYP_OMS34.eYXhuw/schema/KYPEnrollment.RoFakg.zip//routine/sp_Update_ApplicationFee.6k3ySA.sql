
/* ==========================================================
-- Author:		<JVera>
-- PROCEDURE: create ApplicationFee form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_ApplicationFee]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON
DECLARE @date_created DATE;
SET @date_created =  GETDATE();

if exists(select * FROM [KYPPORTAL].[PortalKYP].[pPDM_ApplicationFee] WHERE PartyID =@party_app_id )
BEGIN

	UPDATE [KYPEnrollment].[pAccount_PDM_ApplicationFee]
	SET CurrentRecordFlag = 0
	WHERE PartyID = @party_account_id;

	EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @party_account_id, @party_app_id, @last_Action_User_ID;
END

PRINT 'Update ApplicationFee'       
END


GO

