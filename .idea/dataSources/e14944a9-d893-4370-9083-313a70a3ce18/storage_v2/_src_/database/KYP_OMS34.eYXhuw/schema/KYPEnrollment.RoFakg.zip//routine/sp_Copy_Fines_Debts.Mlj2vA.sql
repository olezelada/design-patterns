
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Fines/Debts form.   
-- PARAMETERS:  
-- @party_id : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create.
-- @last_action_user_id : this is the user Enrollment.
-- @app_fine_id : this is the FineDebtID Application that will be Create in Update Account, it is Null when account is create.  
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Fines_Debts] 	
	@party_id INT,
	@new_party_id INT,
	@last_action_user_id VARCHAR(100),
	@app_fine_id INT

AS
BEGIN
    SET NOCOUNT ON
	DECLARE @date_create DATE
	SET @date_create = GETDATE();
	
	IF @app_fine_id IS NOT NULL
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_FineDebt]
			([PartyID] ,
			[Type] ,
			[AgencyName] ,
			[Amount] ,
			[DateIssued] ,
			[DatePaidInFull] ,
			[LastAction],
			[LastActionDate],
			[LastActorUserID]	,
			[LastActionApprovedBy],
			[CurrentRecordFlag],
			[documentInstanceId],
			[IsDeleted],
			[AppFineDebtID])
			SELECT @new_party_id
			,[Type]
			,[AgencyName]
			,[Amount]
			,[DateIssued]
			,[DatePaidInFull]
			,'C'
			,@date_create
			,@last_action_user_id
			,@last_action_user_id
			,1
			,[documentInstanceId]
			,[IsDeleted]
			,[FineDebtID]
			FROM [KYPPORTAL].[PortalKYP].[pPDM_FineDebt] WHERE FineDebtID = @app_fine_id
			
	END
	ELSE
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_FineDebt]
		([PartyID] ,
		[Type] ,
		[AgencyName] ,
		[Amount] ,
		[DateIssued] ,
		[DatePaidInFull] ,
		[LastAction],
		[LastActionDate],
		[LastActorUserID]	,
		[LastActionApprovedBy],
		[CurrentRecordFlag],
		[documentInstanceId],
		[IsDeleted],
		[AppFineDebtID])
		SELECT @new_party_id
		,[Type]
		,[AgencyName]
		,[Amount]
		,[DateIssued]
		,[DatePaidInFull]
		,'C'
		,@date_create
		,@last_action_user_id
		,@last_action_user_id
		,1
		,[documentInstanceId]
		,[IsDeleted]
		,[FineDebtID]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_FineDebt] WHERE PartyID = @party_id
    END

	DECLARE @tot INT
	DECLARE @cont INT
	DECLARE @documentInstanceId INT, @accountFineDebtId INT
	DECLARE @temporal TABLE(id INT IDENTITY (1, 1), documentInstanceId INT, accountFineDebtId INT)
	DECLARE @new_account_id INT

	SELECT @new_account_id = AccountID FROM KYPEnrollment.pADM_Account WHERE PartyID = @new_party_id

	INSERT INTO @temporal (documentInstanceId, accountFineDebtId)
		SELECT appAC.documentInstanceId, accAC.FineDebtId FROM KYPEnrollment.pAccount_PDM_FineDebt accAc
			INNER JOIN KYPPORTAL.PortalKYP.pPDM_FineDebt appAC on appAC.FineDebtID = accAc.AppFineDebtID
		WHERE accAc.PartyID = @new_party_id


	SELECT @tot = MAX(id) FROM @temporal
	SET @cont = 1;

	WHILE @cont <= @tot
		BEGIN

			SELECT
				@documentInstanceId = t.documentInstanceId,
				@accountFineDebtId = t.accountFineDebtId
			FROM @temporal t
			WHERE t.id = @cont
			EXEC KYPEnrollment.sp_Store_Attachments_References @new_Account_Id, @documentInstanceId, @accountFineDebtId,
																												 'pAccount_PDM_FineDebt', 'FineDebtId'

			SET @cont = @cont + 1

		END

END


GO

