CREATE PROCEDURE [KYPEnrollment].[sp_Update_PartyAssociate_Taxid_Bulk]
 	 @taxid varchar(10),-- = '951750445'
 	 @profileid varchar(40)-- = '0000125463'
AS

BEGIN
declare @cont       int,
        @UniqueID   int
        -- ,@currentrecordflag bit 
		 --rollback
CREATE TABLE #TempUnique
	(
		ID			INT PRIMARY KEY IDENTITY(1,1),
		Uniqueid	int
		)
		
CREATE TABLE #insertPartytemp
(
	profileid			VARCHAR(40),
	EIN					VARCHAR(20),
	AccountID			INT,
	AccountNumber		VARCHAR(20),
	partyid_acc			INT,
	PartyID				INT,
	ParentPartyID		INT,
	type				VARCHAR(50),
	name				VARCHAR(150),
	SSN_TIN				VARCHAR(30),
	CurrentRecordFlag	BIT
)


--***---
INSERT INTO #TempUnique
SELECT UniqueMOCAsProfileTINWiseID
      FROM(SELECT *,ROW_NUMBER() OVER (PARTITION BY MOCAType,SSNorTIN,FirstName,LastName,LegalName ORDER BY UniqueMOCAsProfileTINwiseID) RowNumber
                  FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW
                  WHERE CurrentRecordFlag = 0 AND
                        NOT EXISTS (SELECT 1
                                          FROM KYPEnrollment.UniqueMOCAsProfileTINwise UMW1
                                          WHERE ISNULL(UMW.SSNorTIN,'')       = ISNULL(UMW1.SSNorTIN,'') AND 
                                                ISNULL(UMW.FirstName,'')      = ISNULL(UMW1.FirstName,'') AND
                                                ISNULL(UMW.LastName,'')       = ISNULL(UMW1.LastName,'') AND 
                                                ISNULL(UMW.LegalName,'')      = ISNULL(UMW1.LegalName,'') AND
                                                UMW1.ProfileID                = @ProfileID AND
                                                UMW1.TaxID                    = @TaxID AND
                                                UMW1.CurrentRecordFlag        = 1) AND
                        ProfileID   = @ProfileID AND
                        TaxID       = @TaxID) ILV
      WHERE ILV.RowNumber = 1
UNION
SELECT UniqueMOCAsProfileTINWiseID
      FROM KYPEnrollment.UniqueMOCAsProfileTINwise
      WHERE CurrentRecordFlag = 1 AND
            IsDeleted         = 0 AND
            ProfileID         = @ProfileID AND
            TaxID             = @TaxID

			
Select ProfileID,TaxID,MocaType,REPLACE(isnull(SSNorTIN,''),'-','') as SSN_TIN, case when isnull(legalname,'')<>'' then legalname else isnull(LastName,'')+','+isnull(FirstName,'') end as Name,CurrentRecordFlag into #TempUnique2
 from KYPEnrollment.UniqueMOCAsProfileTINwise
 un
Join #tempunique tn on un.UniqueMOCAsProfileTINwiseID = tn.Uniqueid


INSERT INTO #insertPartytemp(profileid,EIN,AccountID,AccountNumber,partyid_acc,PartyID,ParentPartyID,type,name,SSN_TIN,CurrentRecordFlag)
select replace(prof.ProfileID,'-','') as profileid, replace(isnull(acc.EIN,''),'-','') as EIN,parti.AccountID,acc.AccountNumber,acc.partyid as partyid_acc,parti.PartyID,ParentPartyID,type,isnull(person.LastName,'')+','+isnull(person.FirstName,'')  as name ,replace(isnull(person.ssn,''),'-','') as SSN_TIN,parti.CurrentRecordFlag -- into #insertPartytemp
from 
kypenrollment.pADM_Account acc inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner join kypenrollment.pAccount_BizProfile_Details prof on acc.AccountID=prof.AccountID and prof.ProfileID = @profileid
inner join KYPEnrollment.pAccount_BizProfile_Master BPM  ON prof.ProfileId	= BPM.ProfileId
inner join kypenrollment.pAccount_PDM_Party parti on acc.PartyID=parti.parentpartyid
left join kypenrollment.pAccount_PDM_Person person on parti.partyid=person.partyid
Join #Tempunique2 t2 on t2.SSN_TIN = replace(isnull(person.ssn,''),'-','')
WHERE acc.EIN = @taxid and
-- replace(isnull(acc.EIN,''),'-','')= t2.Taxid and
 -- replace(prof.ProfileID,'-','')=t2.profileid and 
 (OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
 (
 (t2.SSN_TIN<>'' AND  replace(isnull(person.ssn,''),'-','')=t2.SSN_TIN)   or
 (t2.SSN_TIN='' AND  RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(isnull(person.LastName,'')+','+isnull(person.FirstName,'') ,' ',''),'  ',''),',',''),'-',''),'_','')))=t2.name )
 )
 --and  type in ('Individual Ownership','SubcontractorIndividual','TransactionIndividual')
 and  type ='Individual Ownership'
 and acc.PackageName	in ('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP')
 AND ACC.IsDeleted	= 0 AND
 bpm.IsTempProfile	= 0 AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)
and IsPastOwner = 0
and acc.NPI  NOT LIKE '%[a-z]%'
and parti.currentrecordflag=1
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')
--union all

INSERT INTO #insertPartytemp(profileid,EIN,AccountID,AccountNumber,partyid_acc,PartyID,ParentPartyID,type,name,SSN_TIN,CurrentRecordFlag)
select replace(prof.profileid,'-','') as profileid,replace(acc.EIN,'-','') AS EIN,parti.AccountID,acc.accountnumber,acc.partyid as partyid_acc,parti.PartyID,ParentPartyID,type,isnull(orga.legalname,''),replace(isnull(orga.ein,''),'-',''),parti.CurrentRecordFlag
from  
kypenrollment.pADM_Account acc inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner join kypenrollment.pAccount_BizProfile_Details prof on acc.AccountID=prof.AccountID and prof.ProfileID = @profileid
inner join KYPEnrollment.pAccount_BizProfile_Master BPM  ON prof.ProfileId	= BPM.ProfileId
inner join kypenrollment.pAccount_PDM_Party parti on acc.PartyID=parti.parentpartyid
left join kypenrollment.pAccount_PDM_Organization orga on parti.PartyID=orga.PartyID 
Join #Tempunique2 t3 on t3.SSN_TIN = replace(isnull(acc.ein,''),'-','')
where acc.EIN = @taxid and
--replace(isnull(acc.EIN,''),'-','')=t3.taxid and 
 --replace(prof.ProfileID,'-','')=t3.profileid and
 (OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
 (
 (t3.ssn_TIN<>'' AND replace(isnull(orga.ein,''),'-','')=t3.ssn_TIN) OR
 (t3.ssn_TIN='' AND  RTRIM(LTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(isnull(orga.legalname,''),' ',''),'  ',''),',',''),'-',''),'_','')))=t3.name ) 
 )
 --AND  type in ('Entity Ownership','SubcontractorEntity','TransactionEntity')  
 and  type ='Individual Ownership'
 and  acc.PackageName	in ('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP')
  AND ACC.IsDeleted	= 0 AND
 BPM.IsTempProfile	= 0 AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)
and IsPastOwner = 0
and acc.NPI  NOT LIKE '%[a-z]%'
and parti.currentrecordflag=1
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')
order by accountid


insert into kypenrollment.pAccount_TaxID_Associate(AccountID,PartyID,EntityID,TaxID,CurrentRecordFlag ) 
select AccountID,partyid_acc,AccountNumber ,ein,1 from #insertPartytemp except
select ass.AccountID,PartyID,EntityID,ass.taxid,1 from kypenrollment.pAccount_TaxID_Associate ass inner join kypenrollment.paccount_bizprofile_details prof
on ass.AccountID=prof.AccountID 
 Join #tempunique2 tu2 
on ass.TaxID=tu2.taxid and replace(prof.ProfileID,'-','')=tu2.profileid 
 
declare @mainparty int 
select top 1 @mainparty=MainPartyID from kypenrollment.pAccount_Party_Associate where PartyID in (select PartyID from #insertPartytemp)
-- print @mainparty
if @mainparty is null
 select top 1 @mainparty=partyid from #insertPartytemp 
if @mainparty is not null
begin 
--insert to party_associate
insert into kypenrollment.pAccount_Party_Associate (MainPartyID, PartyID,AccountID,Type )
select @mainparty,partyid,accountid,TYPE from #insertPartytemp except
select mainpartyid,partyid, accountid,type from kypenrollment.pAccount_Party_Associate 
--update status of currentrecordflag in party_associate
update asoc set CurrentRecordFlag = temp.currentrecordflag 
from  kypenrollment.pAccount_Party_Associate asoc inner join #insertPartytemp temp on asoc.PartyID=temp.partyid 
end

drop table #TempUnique
drop table #Tempunique2
Drop Table #insertPartytemp

--recovery all taxid, accountid of accounts that not have mocas
SELECT	ACC.ACCOUNTID,BPM.ProfileID,ACC.EIN AS TaxID,acc.AccountNumber,acc.PartyID as Partyid_account
into #Tempacc
FROM KYPEnrollment.pADM_Account ACC
inner join KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner JOIN KYPEnrollment.pAccount_BizProfile_Details BPD 	ON ACC.AccountID	= BPD.AccountID
inner join KYPEnrollment.pAccount_BizProfile_Master BPM 	ON BPD.ProfileId	= BPM.ProfileId
left JOIN KYPEnrollment.pAccount_PDM_Party P ON ACC.PartyID		= P.ParentPartyID and P.Type IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity','Individual Ownership','Entity Ownership') and
p.CurrentRecordFlag = 1

WHERE	ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND 
(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
BPM.ProfileID		=@profileid AND
ACC.EIN				=@taxid	AND
ACC.IsDeleted		= 0			AND
IsTempProfile		= 0			AND
IsPastOwner=0 and 
p.PartyID is null 
and acc.NPI  NOT LIKE '%[a-z]%'
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')

--insert into paccount_Taxid_associate
insert into kypenrollment.pAccount_TaxID_Associate(AccountID,PartyID,EntityID,TaxID,CurrentRecordFlag ) 
select AccountID,partyid_account,AccountNumber ,taxid,1 from #Tempacc  except
select ass.AccountID,PartyID,EntityID,taxid,1 from kypenrollment.pAccount_TaxID_Associate ass
inner join kypenrollment.paccount_bizprofile_details prof 
on ass.AccountID=prof.AccountID 
where TaxID=@taxid and prof.ProfileID=@profileid 

drop table #Tempacc

end


GO

