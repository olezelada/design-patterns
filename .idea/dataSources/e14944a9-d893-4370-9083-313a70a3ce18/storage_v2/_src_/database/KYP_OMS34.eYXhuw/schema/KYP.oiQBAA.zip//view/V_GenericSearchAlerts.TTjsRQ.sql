
CREATE VIEW [KYP].[V_GenericSearchAlerts]
AS
SELECT A.AlertNo
	,A.AlertID
	,A.CreatedDate
	,A.WatchlistName
	,A.Priority
	,A.Relevance
	,A.MatchStatusIndicatorDesc
	,A.WatchedPartyName
	,NULL AS ProviderName
	,A.ProviderType
	,A.MedicaidID
	,A.NPI
	,A.SSN
	,A.TAXID
	,CASE 
		WHEN A.IsMerged = 'Y'
			THEN 'Yes'
		ELSE 'No'
		END AS 'IsMerged'
	,A.WFMinorDisposition AS 'WFStatus'
	,A.Assignee
	,A.AssignedToUserID
	,CASE 
		WHEN A.WFStatus = 'Completed'
			THEN 'Closed'
		ELSE 'Open'
		END AS 'AlertStatus'
	,NULL AS ResolutionID
	,ISNULL(ResolutionType, ' ') AS 'ResolutionType'
	,ISNULL(ResolutionDate, ' ') AS 'ResolutionDate'
	,CASE 
		WHEN A.WatchedPartyID IN (
				SELECT PartyID
				FROM KYP.PDM_Owner
				)
			THEN 'Owner'
		WHEN A.WatchedPartyID IN (
				SELECT PartyID
				FROM KYP.PDM_Employee
				)
			THEN 'Employee'
		WHEN A.WatchedPartyID IN (
				SELECT PartyID
				FROM KYP.PDM_Provider
				)
			THEN 'Provider'
		END RelationType
FROM KYP.MDM_Alert AS A
LEFT JOIN (
	SELECT AlertID
		,LTRIM(STUFF((
					SELECT ', ' + CAST(ResolutionType AS VARCHAR(50)) [text()]
					FROM KYP.MDM_AlertResolution C
					WHERE AlertID = T.AlertID
					AND 
					(C.IsDeleted <> 1 AND C.IsDeleted IS NOT NULL)
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 2, ' ')) AS ResolutionType
	FROM KYP.MDM_AlertResolution T
	WHERE (T.IsDeleted <> 1 AND T.IsDeleted IS NOT NULL)
	GROUP BY T.AlertID
	) Q ON A.AlertID = Q.AlertID
LEFT JOIN (
	SELECT AlertID
		,LTRIM(STUFF((
					SELECT ', ' + CAST(CONVERT(VARCHAR(20), ResolutionDate, 101) AS VARCHAR(50)) [text()]
					FROM KYP.MDM_AlertResolution C
					WHERE AlertID = T.AlertID
					AND 
					(C.IsDeleted <> 1 AND C.IsDeleted IS NOT NULL)
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 2, ' ')) AS ResolutionDate
	FROM KYP.MDM_AlertResolution T
	WHERE (T.IsDeleted <> 1 AND T.IsDeleted IS NOT NULL)
	GROUP BY T.AlertID
	) Q1 ON A.AlertID = Q1.AlertID


GO

