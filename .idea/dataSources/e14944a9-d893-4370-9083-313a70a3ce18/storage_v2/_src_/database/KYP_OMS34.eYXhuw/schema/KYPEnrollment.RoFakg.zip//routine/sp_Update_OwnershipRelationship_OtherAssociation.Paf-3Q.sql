-- =============================================
-- Author:		<ohuanca>
-- Create date: <10-07-18>
-- Description:	update otherAssociation from newValueText of tracking
-- Params:
-- @lastAction: character of action on entity
-- @applicationId: identify of application
-- @fieldCode: value bind on field
-- @tableCode: identifier of table significant
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_OwnershipRelationship_OtherAssociation]
	@lastAction VARCHAR(1),
	@applicationId INT,
  @fieldCode VARCHAR(100),
  @tableCode VARCHAR(20)
AS
BEGIN

	print 'sp_Update_OwnershipRelationship_OtherAssociation :'+ convert(varchar,@applicationId)

    select FieldCode, AccPKValue, AccPK, AccTableName, NewValueText into #fieldValuesTracking
    from KYPPORTAL.PortalKYP.FieldValuesTracking
    where AccTableName IS NOT NULL
    and AccPKValue IS NOT NULL
    and AccPK IS NOT NULL
    and CurrentValueText IS NOT NULL
    and NewValueText IS NOT NULL
    and applicationid = @applicationId
    and TableCode = @tableCode
    and FieldCode = @fieldCode
    order by FieldValueID desc

    if exists(select FieldCode from #fieldValuesTracking)
    begin
      update ownershipRelationshipAccount
      set ownershipRelationshipAccount.OtherAssociation = #fieldValuesTracking.NewValueText,
      ownershipRelationshipAccount.LastAction = @lastAction
      from KYPEnrollment.pAccount_PDM_OwnershipRelationship ownershipRelationshipAccount
      inner join #fieldValuesTracking
      on ownershipRelationshipAccount.OwnerRelationID = #fieldValuesTracking.AccPKValue
    end

    drop table #fieldValuesTracking
END


GO

