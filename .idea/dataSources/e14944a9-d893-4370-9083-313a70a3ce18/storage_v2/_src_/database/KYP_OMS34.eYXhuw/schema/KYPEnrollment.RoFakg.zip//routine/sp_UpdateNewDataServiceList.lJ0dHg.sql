-- =============================================
-- Author:		<clopez>
-- Create date: <03/21/2018 15:00:00>
-- Description:	<This procedure update new data only for portable imaging package(CAMMIS and CrossToFull)>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_UpdateNewDataServiceList]
	@section_code VARCHAR(50),
	@field_code VARCHAR(100),
	@party_id_provider INT,
	@acc_party_id INT,
	@last_Action_User_ID VARCHAR(100)

AS
BEGIN
  IF NOT EXISTS (
          SELECT Section_code
          FROM   #Control_FieldCode
          WHERE  Section_code = @section_code
          AND    Field_code = @field_code)
  BEGIN
    EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_id_provider, @acc_party_id, 'ServiceList';
    EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_id_provider, @acc_party_id, 'ultrasoundUsed';
    EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_id_provider, @acc_party_id, 'mammographyUsed';

    EXEC [KYPEnrollment].[Copy_Twin_Number] @acc_party_id, @party_id_provider, @last_action_user_id, 'numberRay';
    EXEC [KYPEnrollment].[Copy_Twin_Number] @acc_party_id, @party_id_provider, @last_action_user_id, 'numberMammography';
    EXEC [KYPEnrollment].[Copy_Twin_Number] @acc_party_id, @party_id_provider, @last_action_user_id, 'numberUltrasound';
    INSERT INTO #Control_FieldCode (Section_code, Field_code)
    VALUES  ('3.2.1', 'rayCode'),
            ('3.2.1', 'mammographyCode'),
            ('3.2.1', 'ultrasoundCode'),
            ('3.2.1', 'otherCode');
  END
END


GO

