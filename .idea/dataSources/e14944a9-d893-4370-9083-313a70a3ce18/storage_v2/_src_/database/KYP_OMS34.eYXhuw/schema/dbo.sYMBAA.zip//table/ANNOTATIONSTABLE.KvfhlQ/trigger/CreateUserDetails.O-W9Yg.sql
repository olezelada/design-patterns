

CREATE TRIGGER [dbo].[CreateUserDetails] ON [dbo].[ANNOTATIONSTABLE]
AFTER INSERT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @person_user_id VARCHAR(255)
		,@password VARCHAR(255)
		,@personID INT
		,@email VARCHAR(255)
		,@userID VARCHAR(50)
		,@annotation_name VARCHAR(100)
		,@annotation_value VARCHAR(100)
		,@roleID INT
		,@Person VARCHAR(100)
		,@User VARCHAR(100)
		,@firstName VARCHAR(100) = NULL
		,@lastName VARCHAR(100) = NULL
		,@middleName VARCHAR(100) = NULL
		,@UserNameExists VARCHAR(100)
		,@department VARCHAR(20)
		,@fullName VARCHAR(100)
		,@active VARCHAR(5);

	SELECT @userID = (
			SELECT [user_name]
			FROM INSERTED
			);

	SELECT @annotation_name = (
			SELECT annotation_name
			FROM INSERTED
			);

	SELECT @annotation_value = (
			SELECT annotation_value
			FROM INSERTED
			);

	--ALTER TABLE KYP.OIS_User DISABLE TRIGGER UpdateUserDetails

	--EXEC KYP.insertUserfullname
	SET @UserNameExists = (
			SELECT userid
			FROM KYP.OIS_User WITH (NOLOCK)
			WHERE userid = @userID
			)

	IF ISNULL(@UserNameExists, '') = ''
	BEGIN
		IF @annotation_name = 'mail'
		BEGIN
			SET @email = @annotation_value;
		END

		SELECT @firstName = (
				SELECT ANNOTATION_VALUE
				FROM dbo.ANNOTATIONSTABLE
				WHERE ANNOTATION_NAME = 'fn'
					AND [user_name] = @userID
				);

		SELECT @middleName = (
				SELECT annotation_value
				FROM dbo.ANNOTATIONSTABLE
				WHERE annotation_name = 'mi'
					AND [user_name] = @userID
				);

		SELECT @lastName = (
				SELECT annotation_value
				FROM dbo.ANNOTATIONSTABLE
				WHERE annotation_name = 'ln'
					AND [user_name] = @userID
				);

		IF (@firstName IS NOT NULL)
			AND (@lastName IS NOT NULL)
		BEGIN
			SET @email = (
					SELECT annotation_value
					FROM dbo.ANNOTATIONSTABLE
					WHERE annotation_name = 'mail'
						AND [user_name] = @userID
					);
			SET @department = (
					SELECT annotation_value
					FROM dbo.ANNOTATIONSTABLE
					WHERE annotation_name = 'department'
						AND [user_name] = @userID
					);
					
		   SET @active = (
					SELECT annotation_value
					FROM dbo.ANNOTATIONSTABLE
					WHERE annotation_name = 'locked'
						AND [user_name] = @userID
					);	
					
			IF (@active = 'true')
			BEGIN
				SET @active = 0
			END
			ELSE
			BEGIN
				SET @active = 1
			END		

			IF (@middleName IS NOT NULL)
			BEGIN
				SELECT @fullName = @lastName + ',' + @firstName + ' ' + @middleName;
			END
			ELSE
			BEGIN
				SELECT @fullName = @lastName + ' ' + @firstName
			END

			INSERT [KYP].[OIS_Person] (
				LastName
				,FirstName
				,MiddleName
				,DOB
				,Age
				,Gender
				,FullName
				)
			VALUES (
				@lastName
				,@firstName
				,@middleName
				,''
				,30
				,'Male'
				,@fullName
				);

			SET @personID = @@IDENTITY;
			SET @password = (
					SELECT password
					FROM dbo.person
					WHERE person_user_id = @userID
					);
			SET @roleID = (
					SELECT RoleID
					FROM KYP.OIS_Role
					WHERE RoleName = 'Clerk'
					);
			SET @Person = 'OMS_GC|OMSDB|PersonID:' + CONVERT(VARCHAR, @personID) + '|OIS_Person';
			SET @User = 'OMS_GC|OMSDB|UserID:' + @userID + '|OIS_User';

			INSERT [KYP].[OIS_User] (
				EmailID
				,UserID
				,PersonID
				,Password
				,FullName
				,Active
				,ExpirationDate
				,CurrentAlertsCount
				,CurrentCasesCount
				,LastAlertsCount
				,LastCasesCount
				,MessageFullName
				,Department
				)
			VALUES (
				@email
				,@userID
				,@personID
				,'password'
				,@fullName
				,@active
				,'2050-12-08 00:00:00'
				,0
				,0
				,0
				,0
				,@firstName + ' ' + @middleName + ' ' + @lastName
				,@department
				)

			INSERT KYP.OIS_JT_UserRole (
				UserID
				,RoleID
				)
			VALUES (
				@userID
				,@roleID
				);

			INSERT INTO KYP.OIS_JT_UserRole (
				UserID
				,RoleID
				)
			SELECT @userID
				,a_r.RoleId
			FROM USERROLETABLE p_ur
				,KYP.OIS_role a_r
			WHERE p_ur.USER_NAME = @userID
				AND p_ur.ROLE_NAME = a_r.RoleName

			INSERT INTO dbo.ER_PERSON_HAS_ONE_USER
			VALUES (
				@Person
				,@User
				);

			INSERT INTO dbo.ER_USER_HAS_ONE_PERSON
			VALUES (
				@User
				,@Person
				);
		END
	END
	ELSE
	BEGIN
		IF @ANNOTATION_NAME = 'mail'
		BEGIN
			SET @email = @ANNOTATION_VALUE;
			SET @userID = (
					SELECT [USER_NAME]
					FROM inserted
					);

			UPDATE KYP.OIS_User
			SET EmailID = @email
			,Row_Updation_Source = 'dbo.ANNOTATIONSTABLE.CreateUserDetails' 
			WHERE UserID = @userID;
		END
		
		IF @ANNOTATION_NAME = 'locked'
		BEGIN
			SET @active = @ANNOTATION_VALUE;
			IF (@active = 'true')
			BEGIN
				SET @active = 0
			END
			ELSE
			BEGIN
				SET @active = 1
			END
			SET @userID = (
					SELECT [USER_NAME]
					FROM inserted
					);

			UPDATE KYP.OIS_User
			SET Active = @active
			,Row_Updation_Source = 'dbo.ANNOTATIONSTABLE.CreateUserDetails' 
			WHERE UserID = @userID;
		END
	END

	--ALTER TABLE KYP.OIS_User ENABLE TRIGGER UpdateUserDetails
END


GO

