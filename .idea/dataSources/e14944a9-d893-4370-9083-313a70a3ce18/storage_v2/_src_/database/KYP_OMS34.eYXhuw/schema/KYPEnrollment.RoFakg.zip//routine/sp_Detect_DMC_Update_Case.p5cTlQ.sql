
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <20/11/2017>
-- Description:	<This sp look for a change on the mode of transportation to create a clone account with the respective transportation mode>
-- =============================================

CREATE PROCEDURE [KYPEnrollment].[sp_Detect_DMC_Update_Case]

@account_id int,
@application_no varchar(20),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@composite_risk INT,
@case_id INT,
@risk VARCHAR(15),
@application_type VARCHAR(30),
@main_app_number varchar(100),
@pack varchar(20)

AS
BEGIN
declare @cont_modHDP int,@cont_acc051 int,
@cont_modOthers int,@cont_acc076 int,@npi varchar(100), @serviceAddress VARCHAR(250), @newAccountNumber VARCHAR(20)
,@acc_aux int,@app_id int,@account_internal_use_id int,@LastActionComments varchar(200)

  DECLARE @serviceLocationNo VARCHAR(10);

	SET NOCOUNT ON;

	select @app_id = ApplicationID from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo=@application_no

	select @cont_modHDP = count(*) from KYPPORTAL.PortalKYP.pADM_Application a INNER JOIN
	KYPPORTAL.PortalKYP.pPDM_Party p ON a.PartyID=p.ParentPartyID INNER JOIN
	KYPPORTAL.PortalKYP.pPDM_Modalities m ON p.PartyID=m.PartyId
	where p.Type='Modality' and m.ModlityCode='HDP' and a.IsDeleted=0 and p.IsDeleted=0 and m.Approved=1
	and m.Deleted=0 and a.ApplicationNo = @application_no


	select @cont_modOthers = count(*) from KYPPORTAL.PortalKYP.pADM_Application a INNER JOIN
	KYPPORTAL.PortalKYP.pPDM_Party p ON a.PartyID=p.ParentPartyID INNER JOIN
	KYPPORTAL.PortalKYP.pPDM_Modalities m ON p.PartyID=m.PartyId
	where p.Type='Modality' and m.ModlityCode<>'HDP' and a.IsDeleted=0 and p.IsDeleted=0 and m.Approved=1
	and m.Deleted=0 and a.ApplicationNo = @application_no


	SELECT @serviceAddress = PracticeAddress, @npi = NPI,@pack = PackageName, @serviceLocationNo = ServiceLocationNo  FROM KYPEnrollment.pADM_Account WHERE AccountID = @account_id


	select @cont_acc076 = COUNT(*) from KYPEnrollment.pADM_Account a
	where ProviderTypeCode='076'
        and IsDeleted=0
        AND (IsPastOwner=0 or IsPastOwner is null)
        AND StatusAcc like '7%'
        AND NPI=@npi
        AND PackageName=@pack
        AND ServiceLocationNo = @serviceLocationNo


	select @cont_acc051 = COUNT(*) from KYPEnrollment.pADM_Account a
	where ProviderTypeCode='051'
        and IsDeleted=0
        AND (IsPastOwner=0 or IsPastOwner is null)
        AND StatusAcc like '1%'
        AND NPI=@npi
        AND PackageName=@pack
        AND ServiceLocationNo = @serviceLocationNo

/*  PRINT '--------------------------- Service Address'
  PRINT @serviceAddress
  PRINT '--------------------------- NPI'
  PRINT @npi
  PRINT '--------------------------- HDP Accounts'
  PRINT @cont_acc051
  PRINT '--------------------------- Non HDP Accounts'
  PRINT @cont_acc076
  PRINT '--------------------------- HDO modalities'
  PRINT @cont_modHDP
  PRINT '--------------------------- Other modalities'
  PRINT @cont_modOthers*/


	
	BEGIN TRY


	IF coalesce(@cont_modHDP,0) > 0 and coalesce(@cont_acc051,0)<1
	BEGIN
       PRINT 'NEW 051'

    SET @newAccountNumber = CONVERT(VARCHAR(20), CONVERT(INT, 180000000+@case_id))
		    EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no,
														 @last_Action_User_ID, @priority, @risk,
														 @composite_risk,
														 @case_id,
														 @application_type,
														 '051',
                              @newAccountNumber
                              
     

     
                              
	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	print @acc_aux
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @newAccountNumber
            , @app_id
            , @application_no
            , @application_type)




    END

   	IF coalesce(@cont_modOthers,0) > 0 and coalesce(@cont_acc076,0)<1
	BEGIN
      PRINT  'NEW 076'

      SET @newAccountNumber = CONVERT(VARCHAR(20), CONVERT(INT, 170000000+@case_id))
    PRINT @newAccountNumber

		    EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no,
														 @last_Action_User_ID, @priority, @risk,
														 @composite_risk,
														 @case_id,
														 @application_type,
														 '076',
                              @newAccountNumber


	IF EXISTS(SELECT AffiliatedAccountID from KYPEnrollment.[pAccount_RenderingAffiliation] where AccountID=@account_id and isDeleted=0 and CurrentRecordFlag=1)
	BEGIN

		declare @new_acc2 int
		SELECT top 1 @new_acc2= AccountID FROM KYPEnrollment.pADM_Account where AccountNumber=@newAccountNumber  and IsDeleted=0

		INSERT INTO KYPEnrollment.[pAccount_RenderingAffiliation]
		(AccountID,AffiliatedAccountID,TypeAffiliation,AffiliationStartDate,AffiliationEndDate,LastActionDate,LastActorUserID,LastActionComments,
		LastActionReason,LastActionApprovedBy,CurrentRecordFlag,TempAffiliation,LastAction,LastUpdatedBy,groupEmail,rendering_email,AffiliatedAccountProvTypeCode,AcHistoryID,isDeleted)
		select @new_acc2,AffiliatedAccountID,TypeAffiliation,AffiliationStartDate,AffiliationEndDate,LastActionDate,LastActorUserID,LastActionComments,
		LastActionReason,LastActionApprovedBy,CurrentRecordFlag,TempAffiliation,LastAction,LastUpdatedBy,groupEmail,rendering_email,AffiliatedAccountProvTypeCode,AcHistoryID,isDeleted
		from KYPEnrollment.[pAccount_RenderingAffiliation] where AccountID=@account_id and isDeleted=0 and CurrentRecordFlag=1
	END     


	SELECT @acc_aux = IDENT_CURRENT ('KYPEnrollment.pADM_Account')
	print @acc_aux
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@acc_aux
            , @newAccountNumber
            , @app_id
            , @application_no
            , @application_type)

	IF EXISTS(SELECT AffiliatedAccountID from KYPEnrollment.[pAccount_RenderingAffiliation] where AccountID=@account_id and isDeleted=0 and CurrentRecordFlag=1)
	BEGIN
		update KYPEnrollment.[pAccount_RenderingAffiliation]
		set CurrentRecordFlag=0,isDeleted=1
		where AccountID=@account_id
	END

    END



END TRY

BEGIN CATCH
    
	DECLARE    @error_message NVARCHAR(4000),@error_severity INT;
	SELECT     @error_message = ERROR_MESSAGE()
		      ,@error_severity = ERROR_SEVERITY();
	RAISERROR (@error_message
              ,@error_severity
              ,1);
              
	EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @app_id           
	
END CATCH

END
GO

