






CREATE VIEW [KYP].[v_MD_WorkFlow]
AS
Select *,ROW_NUMBER() over(order by ProcessName,ResolutionType,Status) iMID
from (
select B.ProcessName,C.ResolutionType,C.Status,D.Value--,D.displayValues
--,D.Agree,D.AssignToAuto,D.AssignToUser,D.DisAgree,D.Cancel,D.CloseApplication,D.[Return],D.[Save]
from KYP.WF_MainWFMasterTable A
inner join KYP.WF_ProcessName B on A.ProcessID=B.ProcessID
inner join KYP.Screening_Resolution C on C.ResolutionId=A.ResolutionId
inner join KYP.WF_SubmitMasterTable D on D.SubmitPopUpID=A.SubmitPopUpID ) Src
		Pivot(count( Value) for Value in ([Agree],
		[DisAgree],
		[CloseApplication],
		[AssignToUser],
		[AssignToAuto],
		[ReturnMaster],
		[SaveMaster],
		[Cancel],
		[DefaultselectionAuto],
	[DefaultselectionUser],
	[DefaultselectionAgree],
	[DefaultselectionDisAgree],
	[DefaultselectionCloseApplication]
	)) as P


GO

