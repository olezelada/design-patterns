
-- =============================================
-- Author:		<Author,,Lperez>
-- PROCEDURE que relaciona los accounts con un solo unique party id
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Create_UniquePartyAccount]
	@accountId int,
	@uniquePartyID int,
	@currentFlag bit
AS
BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
	([AccountID]
	,[UniquePartyID]
	,[CurrentRecordFlag])
	VALUES
	(@accountId
	,@uniquePartyID
	,@currentFlag)
END


GO

