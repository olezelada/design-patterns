



CREATE View [KYP].[View_GroupNpi] as


SELECT X.* from (	

select A1.CaseID,A2.Provider_NPI,A1.Number,A1.ApplnType,1 as Sortorder
from KYP.ADM_Case A1
Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A1.Number
Join kyp.ADM_Case A2 on A2.Number=r.group_providerNumber
Where LEN(R.group_providerNumber)=8

Union All

select A1.CaseID,A2.NPI as Provider_NPI,A2.AccountNumber as Number ,A1.ApplnType,2
from KYP.ADM_Case A1 
Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A1.Number
Join KYPEnrollment.pADM_Account A2 on R.group_providerNumber=A2.Accountnumber
Left Join kypenrollment.padm_Account A3 on A1.Accountno = A3.AccountNumber and A3.AccountType<>'I'
Where LEN(R.group_providerNumber)>8

Union All

select a.CaseID,d.NPI as Provider_NPI,d.AccountNumber as Number,a.ApplnType,3
from KYP.ADM_Case A
Join KYPEnrollment.padm_account b on b.AccountNumber = a.AccountNo
Join KYPEnrollment.pAccount_RenderingAffiliation c on c.AffiliatedAccountID=b.AccountID
Join KYPEnrollment.padm_account d on c.AccountID=d.AccountID
Left Join KYPPORTAL.PortalKYP.pRenderingAffiliation e on e.rendering_providerNumber=A.Number
Where a.Applntype in ('Supplemental','CHOA','CHOW','Revalidation','Reenrollment','Disaffiliation','Disenrollment')
and b.AccountType <> 'I'
and E.rendering_providerNumber is null)X

GO

