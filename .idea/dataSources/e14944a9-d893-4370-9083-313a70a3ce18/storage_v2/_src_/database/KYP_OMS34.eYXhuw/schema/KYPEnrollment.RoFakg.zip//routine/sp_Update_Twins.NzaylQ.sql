
-- =============================================  
-- Author:  <Lacunza, Giresse>  
-- Create date: <07/11/2017>  
-- Description: <This procedure copy all the changes to other siamese accounts, works by section, doesn't copy to the own account that was parameter on the call to create_update_account>  
-- =============================================  
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Twins]   
	@main_app_number varchar(10),  
	@main_app_npi varchar(10),  
	@application_no varchar (10),  
	@party_id int,  
	@last_Action_User_ID VARCHAR(100),  
	@account_id int  
AS  
BEGIN  
  
	DECLARE @new_Account_Id int,@new_Party_Id int, @tot int,@cont int,@add int,  
			@npi_Type VARCHAR(20),@sectionCode varchar(10),@proc_copy varchar(300),@proc_delete varchar(300),  
			@provider_type_code varchar(10),@pack varchar(20),@serviceAddress varchar (250),@ownerNo varchar(10),@serviceLocationNo varchar(10)  

	DECLARE @accounts table (pk int identity(1,1),accID int,package varchar(20))  
	DECLARE @track_section table (pk int identity(1,1),sect varchar(10))  
	DECLARE @count_sect int,@add_sect int, @tot_sect int  

	SELECT @pack = PackageName, @serviceAddress = PracticeAddress, @ownerNo = OwnerNo, @serviceLocationNo = ServiceLocationNo  
	from KYPEnrollment.pADM_Account where AccountID = @account_id  

	IF @pack = 'F_OOS_OE'  
	BEGIN  
		INSERT INTO @accounts (accID, package)  
		SELECT  
		 AccountID,  
		 PackageName  
		FROM KYPEnrollment.pADM_Account  
		WHERE (ApplicationNumber = @main_app_number OR NPI = @main_app_npi) AND IsPastOwner = 0 AND  
		   OwnerNo = @ownerNo AND AccountID NOT IN (@account_id) AND (StatusAcc LIKE '1%' OR StatusAcc LIKE '7%')  
		ORDER BY AccountID  
	END  

	IF @pack IN ('FSP_DMC_IN', 'FSP_DMC_SP', 'FSP_MDT_IN', 'FSP_MDT_SP')  
	BEGIN  
		INSERT INTO @accounts (accID, package)  
		SELECT DISTINCT  
		 AccountID,  
		 PackageName  
		FROM KYPEnrollment.pADM_Account  
		WHERE  
		 (ApplicationNumber = @main_app_number OR NPI = @main_app_npi) AND PackageName = @pack AND @serviceLocationNo = ServiceLocationNo  
		 AND IsPastOwner = 0 AND AccountID NOT IN (@account_id) AND (StatusAcc LIKE '1%' OR StatusAcc LIKE '7%')  
		ORDER BY AccountID  
	END  

	BEGIN TRY  

		--Added the below update statement by Sundar for KEN-21574 on 11-April-2019
		Update t2
		Set T2.IsProvOwnedData = 1,
			T2.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
		From @accounts t1
		Join kypenrollment.padm_Account T2 on t1.accID = T2.AccountID
		Where t2.IsDeleted=0

		select @tot =MAX(pk) from @accounts  
		set @cont=1;  

		WHILE @cont<=@tot  
		BEGIN  

			select @new_Account_Id = accID from @accounts where pk=@cont  
			--  
			PRINT 'UPDATE TWINS ACCOUNT TO MODIFY: '   
			PRINT @new_Account_Id  
			--  
			select @new_Party_Id = PartyID from KYPEnrollment.pADM_Account where AccountID = @new_Account_Id  
			 
			------------------------------------------------------------------------------------------------------------    

			IF NOT EXISTS (SELECT TOP 1 * FROM KYPEnrollment.section_sp)  
			BEGIN  

				EXEC [KYPEnrollment].sp_Fill_Section_Table  

			END  


			INSERT INTO @track_section (sect)  
			select t.sectionCode from KYPPORTAL.PortalKYP.FieldValuesTracking t INNER JOIN KYPPORTAL.PortalKYP.pADM_Application a ON t.ApplicationID=a.ApplicationID   
			where a.ApplicationNo=@application_no and a.ApplicationID=t.ApplicationID and a.IsDeleted=0 group by t.sectionCode  

			select @tot_sect = MAX(pk) from @track_section  

			SET @count_sect = 1  

			WHILE @count_sect <= @tot_sect  
			begin  

				select @sectionCode = sect from @track_section where pk = @count_sect  

				------------------------------------------------------------------------------------------------------------  
				IF EXISTS (select section_code from KYPEnrollment.section_sp where section_code = @sectionCode)  
				BEGIN  
					print 'Update in section: '  
					PRINT @sectionCode  

					select @proc_delete = sp_delete, @proc_copy = sp_copy from KYPEnrollment.section_sp where section_code = @sectionCode and IsDeleted=0  

					--delete section  
					 
					 
					SET @proc_delete =  REPLACE(@proc_delete, '@new_Account_Id', @new_Account_Id)   
					SET @proc_delete =  REPLACE(@proc_delete, '@party_id', @party_id)   
					SET @proc_delete =  REPLACE(@proc_delete, '@last_Action_User_ID', @last_Action_User_ID)  
					 
					print 'Execute delete procedure:'  
					print @proc_delete  
					 
					EXEC (@proc_delete)  
					 
					--copy section  
					SET @proc_copy =  REPLACE(@proc_copy, '@new_Account_Id', @new_Account_Id)  
					SET @proc_copy =  REPLACE(@proc_copy, '@new_Party_Id', @new_Party_Id)   
					SET @proc_copy =  REPLACE(@proc_copy, '@party_id', @party_id)  
					SET @proc_copy =  REPLACE(@proc_copy, '@last_Action_User_ID', char(39) + @last_Action_User_ID +  char(39))  
					SET @proc_copy =  REPLACE(@proc_copy, '@application_no',char(39) + '@application_no' + char(39))  
					SET @proc_copy =  REPLACE(@proc_copy, '@application_no', @application_no)  
					IF (@provider_type_code IS NOT NULL AND @provider_type_code != '')  
					BEGIN  
					 SET @proc_copy =  REPLACE(@proc_copy, '@provider_type_code', @provider_type_code)  
					END  

					print 'Execute copy procedure:'  
					print @proc_copy  
					 
					EXEC (@proc_copy)  
				 
				END  


				SET @count_sect = @count_sect + 1  
			 
			end  

			set @cont= @cont + 1  

			--Update providerName for 'F_OOS_OE' package  
			EXEC [KYPEnrollment].[sp_Update_ProviderName_Account] @application_no, @new_Account_Id, @last_Action_User_ID, @pack;  

		END  

		--update modeOfTransportation table  
		EXEC [KYPEnrollment].[sp_UpdateCreateModeTransportation] @account_id, @pack, @main_app_number,@main_app_npi, @last_Action_User_ID;  

	END TRY  

	BEGIN CATCH  

		DECLARE    @error_message NVARCHAR(4000),@error_severity INT;  
		SELECT     @error_message = ERROR_MESSAGE()  
			,@error_severity = ERROR_SEVERITY();  
		RAISERROR (@error_message  
				  ,@error_severity  
				  ,1);  
		            
		EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationNo',@KeyValue = @application_no  
	            
	END CATCH  
  
END
GO

