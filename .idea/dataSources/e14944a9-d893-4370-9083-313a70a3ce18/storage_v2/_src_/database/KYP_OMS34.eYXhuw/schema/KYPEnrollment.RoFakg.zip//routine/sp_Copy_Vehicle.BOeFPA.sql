-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <19/09/2017>
-- Description:	<This procedure copy data of vehicles from Portal to Enrollment>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Vehicle]
	@new_Party_Id INT,
	@vehicle_id int,
	@last_Action_User_ID VARCHAR(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @date_created DATE,
	@NEW_ID int;
	SET @date_created =  GETDATE();
	
	IF EXISTS (SELECT  TABLE_NAME from	INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'pAccount_PDM_Vehicle')
	
	begin
	INSERT INTO KYPEnrollment.pAccount_PDM_Vehicle (
	PartyId,
	VehicleType,
	VehicleSubType,
	CertificationNumber,
	CertificationType,
	IssueDate,
	Vin,
	VehicleYear,
	Plate,
	MakeModel,
	IsDeleted,
	Approved,

	LastAction,
	LastActionDate,
	LastActorUserID,
	
	DateCreated,
	CurrentRecordFlag,
		EffectiveDate
	
	)
	
	SELECT
	@new_Party_Id,
	VehicleType,
	VehicleSubType,
	CertificationNumber,
	CertificationType,
	IssueDate,
	Vin,
	VehicleYear,
	Plate,
	MakeModel,
	0,
	1,
	'C',
	@date_created,
	@last_Action_User_ID,

	@date_created,
	1,
	EffectiveDate
	FROM KYPPORTAL.PortalKYP.pPDM_Vehicle WHERE VehicleId=@vehicle_id and Approved=1 and IsDeleted=0
	
	SELECT @NEW_ID = Scope_Identity()
	
	RETURN @NEW_ID;
	
	end	
	
END


GO

