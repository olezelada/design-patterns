
CREATE FUNCTION [KYP].[getCheckistTemplateID] (@applnType varchar(50),
											 @supUpdateFlag varchar(20)
)
RETURNS int
AS
BEGIN
	Declare @TemplateID int;
    Set @TemplateID  = 1;
    
            IF(@applnType = 'Rendering-S' or (@applnType = 'Supplemental' and (@supUpdateFlag = 'MR' OR @supUpdateFlag = '5B')))
            BEGIN
                Set @TemplateID  =  2
            END
            ELSE     	IF(@applnType = 'Supplemental' and (@supUpdateFlag = 'SR' OR @supUpdateFlag = '5C'))
            BEGIN
                Set @TemplateID  =  3
            END
            ELSE     	IF(@applnType = 'Supplemental' and (@supUpdateFlag = 'NR' OR @supUpdateFlag = '5A'))
            BEGIN
                Set @TemplateID  = 4
            END
            ELSE		IF(@applnType = 'Disenrollment' or @applnType = 'Disaffiliation')
            BEGIN
                Set @TemplateID  = 5
            END

    return @TemplateID;
END


GO

