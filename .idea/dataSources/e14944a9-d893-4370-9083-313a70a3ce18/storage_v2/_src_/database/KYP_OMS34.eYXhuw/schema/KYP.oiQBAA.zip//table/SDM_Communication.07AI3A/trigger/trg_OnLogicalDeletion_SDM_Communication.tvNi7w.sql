-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle communication count in the table KYP.FrameworkCount
--				On logical delete in the table KYP.SDM_Communication
--				The trigger is written with the assumption that logical deletion on table KYP.SDM_Communication
--				means setting the deleted flag in the table to 1
-- =============================================
CREATE TRIGGER [KYP].[trg_OnLogicalDeletion_SDM_Communication]
   ON  [KYP].[SDM_Communication]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (
			SELECT 1 
			FROM INSERTED A 
				INNER JOIN KYP.CommunicationEntity B 
					ON A.CommID = B.CommID
						AND A.IsDeleted=1
				INNER JOIN KYP.FrameworkCount C
					ON B.CommEntityType = C.FrameworkEntityType
						AND B.CommEntityTypeID = C.FrameworkEntityTypeID
		)
	UPDATE A 
		SET A.CommunicationCount = case 
									when A.CommunicationCount>1 then A.CommunicationCount -1 
									else 0  
								end ,
			A.ModifiedDate = getdate(),
			A.ModifiedBy = 'Communication Decreased'	
	FROM KYP.FrameworkCount A	
	INNER JOIN KYP.CommunicationEntity B 
		ON A.FrameworkEntityType = B.CommEntityType
			AND A.FrameworkEntityTypeID = B.CommEntityTypeID
	INNER JOIN INSERTED C
		ON B.CommID = C.CommID
			AND C.IsDeleted=1


    -- Insert statements for trigger here

END


GO

