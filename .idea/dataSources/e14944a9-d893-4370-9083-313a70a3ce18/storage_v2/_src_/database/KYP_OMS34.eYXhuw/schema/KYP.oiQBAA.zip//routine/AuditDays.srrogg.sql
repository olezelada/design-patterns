CREATE FUNCTION [KYP].[AuditDays] (@dateInitiated smalldatetime)
returns varchar(10)
as
begin
     DECLARE @days int;
	 DECLARE @res varchar(10);
     set @days = ABS(DATEDIFF(d, @dateInitiated, GETDATE()))
     if(@days >= 0 and @days <= 3)
     begin
          Set @res = '0-3 days';
     end
     else if(@days > 3 and @days <= 10)
     begin
          Set @res = '4-10 days';
     end
     else if(@days > 10 and @days <= 15)
     begin
          Set @res = '11-15 days';
     end
     else if (@days > 15)
     begin
          Set @res = '15+ days';
     end

     return @res
end


GO

