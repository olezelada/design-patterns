/* ==========================================================  
-- Author:  <Ralba,TJaldin,JHuanca>  
-- PROCEDURE: create Affiliaction to Group Account with Rendering Account.     
-- PARAMETERS:    
-- @last_action_user_id : this is the user Enrollment.  
-- @application_no : ApplicationID that will be Account.  
-- ============================================================*/  
--Change History  
---------------------------------------------------------------------------------------  
-- Sl.No. JIRA No.   Author		Date			Description  
---------------------------------------------------------------------------------------  
--	1	KEN-20824	Sundar		19-May-2019		Added statement to avoid duplicate rendering in pAccount_renderingAffiliation table

CREATE PROCEDURE [KYPEnrollment].[sp_Create_Affiliation_Account]   
			@last_action_user_id VARCHAR(100),  
			@application_no VARCHAR(100),  
			@application_Id int,  
			@account_no varchar(20)  
AS  
BEGIN  
	SET NOCOUNT ON  
	DECLARE @affiliation_id INT,
			@date_create DATE,
			@affiliation_group_id INT,
			@affiliation_rendering_id INT,
			@account_no_group VARCHAR(100),
			@application_no_group VARCHAR(100),  
			@account_group_id INT,
			@type_affiliation VARCHAR(200),
			@rendering_affiliation_id_mid INT,
			@account_id_group INT,
			@has_addresses BIT,  
			@new_party_id_account int ,
			@party_Id int,
			@FBPApp bit,
			@Account_Id INT  

	SET @date_create= GETDATE();  

	SELECT @affiliation_id = rendering_affiliation_id,
			@affiliation_group_id = group_instance_id ,
			@affiliation_rendering_id = rendering_instance_id,
			@application_no_group = group_providerNumber,  
			@type_affiliation = type_affiliation,
			@has_addresses = hasAddresses   
	FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] 
	WHERE rendering_providerNumber = @application_no AND isDeleted=0;  

	SELECT @account_no_group = AccountNumber,
			@FBPApp = FBPApp   
	FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationNo  = @application_no_group;  

	print 'Geethareddy'  

	print 'Geethareddy1'  

	SELECT @Account_Id = AccountID 
	FROM KYPEnrollment.pADM_Account 
	WHERE AccountNumber = @account_no and IsDeleted=0 and IsPastOwner=0  

	IF(EXISTS(SELECT ApplicationID FROM KYPPORTAL.PortalKYP.pADM_Application WHERE ApplicationID = @application_Id AND ApplicationType = 'SUDMD/SUDTP Simplified Package'))  
	BEGIN  
		PRINT 'RENDERING-S WITH DMC AND SUDTP/SUDMD'      

		EXEC KYPEnrollment.sp_Create_SUDMD_SUDTP_affiliations @Account_Id, @last_action_user_id, @application_no  
		RETURN  
	END  

	IF @FBPApp=1 OR EXISTS(SELECT AccountID FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @application_no_group AND ProvLocTypeCd = 'F' and IsDeleted=0)  
	BEGIN  
		EXEC [KYPEnrollment].[sp_RenderingS_FBPAffiliations] @application_no,  
							@Account_Id,  
							@application_Id,  
							@last_action_user_id,  
							@account_no  
	END    
	ELSE  
	BEGIN  
		SELECT @party_Id =  PartyID FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationNo=@application_no;  
		print @party_Id  

		EXEC @new_party_id_account = [KYPEnrollment].[sp_Copy_Party] @party_Id, NULL,NULL,@last_Action_User_ID;   

		print @new_party_id_account  
		print @party_Id  
		print @last_action_user_id  

		EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_Id, 'Individual Profile', @last_action_user_id;  

		/*Address*/  
		EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_Id, 'Servicing', @last_action_user_id;  
		EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_Id, 'Pay-to', @last_action_user_id;  
		EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_Id, 'Mailing', @last_action_user_id;  


		IF @has_addresses = 1  
		BEGIN  
			--Changed IsDeleted=0 and CurrentRecordflag=1 for CAPAVE-2781  
			INSERT INTO  [KYPEnrollment].[pAccount_RenderingAffiliation]  
					([AccountID]  
					,[AffiliatedAccountID]  
					,[TypeAffiliation]  
					,[LastActionDate]  
					,[LastActorUserID]  
					,[LastActionApprovedBy]  
					,[CurrentRecordFlag]  
					,[LastAction]  
					,[AffiliationStartDate]  
					,[LastUpdatedBy]  
					,[groupEmail]  
					,[rendering_email]  
					,[isDeleted])  
			SELECT A.[accountId]  
					,@affiliation_rendering_id  
					,@type_affiliation  
					,@date_create  
					,@last_action_user_id  
					,@last_action_user_id  
					,1  
					,'C'  
					,B.DateCreated  
					,'P'  
					,A.[groupEmail]  
					,[renderingEmail]  
					,0  
			FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] A 
			Inner join kyp.adm_case B on A.applicationNumber=B.Number
			Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = A.accountId and C.AffiliatedAccountID = @affiliation_rendering_id and C.isDeleted=0 --Added for #1 KEN-20824
			WHERE rendering_affiliation_id = @affiliation_id
				and C.RenderingAffiliationID is null  --Added for #1 KEN-20824             
		END  

		IF @account_no_group IS NOT NULL  
		BEGIN  
			PRINT 'B'  
			SELECT @account_group_id = AccountID FROM [KYPEnrollment].[pADM_Account] WHERE AccountNumber = @account_no_group AND IsDeleted = 0;  

			--Changed IsDeleted=0 and CurrentRecordflag=1 for CAPAVE-2781  
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
			([AccountID]  
			,[AffiliatedAccountID]  
			,[TypeAffiliation]  
			,[LastActionDate]  
			,[LastActorUserID]  
			,[LastActionApprovedBy]  
			,[CurrentRecordFlag]  
			,[LastAction]  
			,[AffiliationStartDate]  
			,[LastUpdatedBy]  
			,[groupEmail]  
			,[rendering_email]  
			,[isDeleted])  
			SELECT @account_group_id,  
			A.[rendering_instance_id],  
			A.[type_affiliation],  
			@date_create,  
			@last_action_user_id,  
			@last_action_user_id,  
			1,  
			'C',  
			B.dateCreated,  
			'P'  
			,A.[groupEmail]  
			,A.[rendering_email]  
			,0  
			FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] A  
			Inner join kyp.adm_case B on A.rendering_providerNumber=B.Number 
			Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = @account_group_id and C.AffiliatedAccountID = A.[rendering_instance_id] and C.isDeleted=0 --Added for #1 KEN-20824
			WHERE A.rendering_providerNumber = @application_no
				and C.RenderingAffiliationID is null --Added for #1 KEN-20824  

			IF @type_affiliation LIKE '%MIDLEVEL%'  
			BEGIN  
				print 'sp_Copy_Rendering_Supervisor1'  
				PRINT 'C'  
				SELECT @rendering_affiliation_id_mid = SCOPE_IDENTITY();  
				EXEC [KYPEnrollment].[sp_Copy_Rendering_Supervisor]@application_no,@rendering_affiliation_id_mid,@affiliation_id;  
			END  
		END  
		ELSE  
		BEGIN  
			IF @type_affiliation NOT LIKE '%ACCOUNT%'  
			BEGIN  
				PRINT 'D'  
				IF NOT EXISTS(SELECT AccountID FROM KYPEnrollment.pADM_Account WHERE ApplicationNumber = @application_no_group AND IsDeleted=0)  
				BEGIN  
					--Changed IsDeleted=0 and CurrentRecordflag=1 for CAPAVE-2781  
					INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
					([AffiliatedAccountID]  
					,[TypeAffiliation]  
					,[LastActionDate]  
					,[LastActorUserID]  
					,[LastActionApprovedBy]  
					,[CurrentRecordFlag]  
					,[LastAction]  
					,[TempAffiliation]  
					,[AffiliationStartDate]  
					,[LastUpdatedBy]  
					,[groupEmail]  
					,[rendering_email]  
					,[isDeleted])  
					SELECT @affiliation_rendering_id,  
					A.[type_affiliation],  
					@date_create,  
					@last_action_user_id,  
					@last_action_user_id,  
					1,  
					'C',  
					[group_instance_id],  
					B.DateCreated,  
					'P'  
					,[groupEmail]  
					,[rendering_email]  
					,0  
					FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  A 
					Inner join kyp.adm_case B on A.rendering_providerNumber=B.Number  
					WHERE rendering_providerNumber = @application_no;  

					IF @type_affiliation LIKE '%MIDLEVEL%'  
					BEGIN  
						PRINT 'E'  
						PRINT 'RENDERING - S MIDLEVEL SUPERVIDOR'  
						SELECT @rendering_affiliation_id_mid = SCOPE_IDENTITY();  
						EXEC [KYPEnrollment].[sp_Copy_Rendering_Supervisor]@application_no,@rendering_affiliation_id_mid,@affiliation_id;  
					END   
				END  
				ELSE  
				BEGIN  
					PRINT 'F'  
					
					SELECT @account_id_group = AccountID FROM [KYPEnrollment].[pADM_Account] WHERE ApplicationNumber = @application_no_group AND IsDeleted=0;  

					--Changed IsDeleted=0 and CurrentRecordflag=1 for CAPAVE-2781  
					INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
					([AffiliatedAccountID]  
					,[TypeAffiliation]  
					,[LastActionDate]  
					,[LastActorUserID]  
					,[LastActionApprovedBy]  
					,[CurrentRecordFlag]  
					,[LastAction]  
					,[AccountID]  
					,[AffiliationStartDate]  
					,[LastUpdatedBy]  
					,[groupEmail]  
					,[rendering_email]  
					,[isDeleted])  
					SELECT @affiliation_rendering_id,  
					A.[type_affiliation],  
					@date_create,  
					@last_action_user_id,  
					@last_action_user_id,  
					1,  
					'C',  
					@account_id_group,  
					B.DateCreated,  
					'P'  
					,A.[groupEmail]  
					,A.[rendering_email]  
					,0  
					FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  A 
					Inner join kyp.adm_case B on A.rendering_providerNumber=B.Number  
					Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = @account_id_group and C.AffiliatedAccountID = @affiliation_rendering_id and C.isDeleted=0 --Added for #1 KEN-20824
					WHERE rendering_providerNumber = @application_no
					and C.RenderingAffiliationID is null; --Added for #1 KEN-20824  

					IF @type_affiliation LIKE '%MIDLEVEL%'  
					BEGIN  
						print 'sp_Copy_Rendering_Supervisor12222222222'  
						PRINT 'G'  
						SELECT @rendering_affiliation_id_mid = SCOPE_IDENTITY();  
						EXEC [KYPEnrollment].[sp_Copy_Rendering_Supervisor]@application_no,@rendering_affiliation_id_mid,@affiliation_id;  
					END  
				END    
			END  
			ELSE  
			BEGIN  
				IF EXISTS(SELECT AccountID FROM [KYPEnrollment].[pADM_Account] WHERE AccountID=@affiliation_group_id) AND EXISTS(SELECT AccountID FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @affiliation_rendering_id)
				BEGIN  
					PRINT 'H'  
					--Changed IsDeleted=0 and CurrentRecordflag=1 for CAPAVE-2781  
					INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
					([AffiliatedAccountID]  
					,[TypeAffiliation]  
					,[LastActionDate]  
					,[LastActorUserID]  
					,[LastActionApprovedBy]  
					,[CurrentRecordFlag]  
					,[LastAction]  
					,[AccountID]  
					,[AffiliationStartDate]  
					,[LastUpdatedBy]  
					,[groupEmail]  
					,[rendering_email]  
					,[isDeleted])  
					SELECT A.[rendering_instance_id],  
					A.[type_affiliation],  
					@date_create,   
					@last_action_user_id,  
					@last_action_user_id,  
					1,  
					'C',  
					A.[group_instance_id],  
					B.DateCreated,  
					'P'  
					,A.[groupEmail]  
					,A.[rendering_email]  
					,0  
					FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  A  
					Inner join kyp.adm_case B on A.rendering_providerNumber=B.Number 
					Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = A.[group_instance_id] and C.AffiliatedAccountID = A.[rendering_instance_id] and C.isDeleted=0 --Added for #1 KEN-20824
					WHERE rendering_providerNumber = @application_no
						AND C.RenderingAffiliationID is null;  --Added for #1 KEN-20824

					IF @type_affiliation LIKE '%MIDLEVEL%'  
					BEGIN  
						SELECT @rendering_affiliation_id_mid = SCOPE_IDENTITY();  
						EXEC [KYPEnrollment].[sp_Copy_Rendering_Supervisor]@application_no,@rendering_affiliation_id_mid,@affiliation_id;  
					END  
				END   
			END  
		END  
	END  
END

GO

