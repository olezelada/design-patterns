-- =============================================
-- Author:		<DH-BOL>
-- Create date: <12/14/2017>
-- Description:	<This procedure puts in delete mode rows related to the reasonEnrollment of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_ApplicationFee]
@new_Account_Id int

AS
BEGIN
Declare @appFeeId int
	SET NOCOUNT ON;

select @appFeeId = r.AppFeeID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_ApplicationFee r ON a.PartyID=r.PartyID
where r.IsDeleted=0 and r.CurrentRecordFlag=1 and a.IsDeleted=0 and a.AccountID=@new_Account_Id

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_ApplicationFee','AppFeeID',@appFeeId

END


GO

