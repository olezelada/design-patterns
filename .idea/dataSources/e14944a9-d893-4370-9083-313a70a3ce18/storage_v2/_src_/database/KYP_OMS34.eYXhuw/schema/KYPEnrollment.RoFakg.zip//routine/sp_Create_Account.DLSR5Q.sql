






CREATE PROCEDURE [KYPEnrollment].[sp_Create_Account]
   @party_account_id       INT,
   @application_id         INT,
   @last_action_user_id    VARCHAR (100),
   @priority               VARCHAR (3),
   @risk                   VARCHAR (15),
   @composite_risk         INT,
   @case_id                INT,
   @is_group               BIT,
   ------------------------------------------
   @provider_type_code     VARCHAR (50),
   @new_account_number     VARCHAR (20),
   @newPackage             VARCHAR (20) = null,
   @application_type       VARCHAR (30) = null
   ------------------------------------------

AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @account_id          INT,
      @date_created        DATE,
      @account_number      INT,
      @party_application   INT,
      @EIN VARCHAR(20)
      
       BEGIN TRY
	--/*Ken-12586 Start*/
	DECLARE @PARTY_ID INT,@NPI VARCHAR(10),@ATYPICAL_NPI varchar(20),@ApplicationNo VARCHAR(15), @packageName VARCHAR(15);

	
		SELECT @NPI = [NPI], @PARTY_ID = [PartyID], @ApplicationNo=ApplicationNo, @packageName = PackagesName FROM [KYPPORTAL].[PortalKYP].[pADM_Application] 
		WHERE ApplicationID = @application_id;
		
		
		SELECT @EIN = Provider_TIN FROM KYP.ADM_Case where Number = @ApplicationNo;
		
		IF (@provider_type_code = '004' AND @NPI IS NULL)
			BEGIN
				PRINT 'GENERATING ATYPICAL NPI FOR BLOOD BANK WITHOUT NPI';
				
				EXEC dbo.GenerateAtypicalNPIValue 'NPI',@ApplicationNo, @ATYPICAL_NPI OUTPUT
				UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application] SET [NPI] = @ATYPICAL_NPI WHERE ApplicationID = @application_id;
				UPDATE [KYPPORTAL].[PortalKYP].[pPDM_Provider] SET [NPI] = @ATYPICAL_NPI WHERE PartyID = @PARTY_ID;
				
				PRINT 'GENERATED ATYPICAL NPI FOR BLOOD BANK WITHOUT NPI';
		END
		ELSE IF (@provider_type_code IN ('40','43','47','51','62','72','76','81','86','90') AND @NPI IS NULL)
		BEGIN
				EXEC dbo.GenerateAtypicalNPIValue 'NPI',@ApplicationNo, @ATYPICAL_NPI OUTPUT
				UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application] SET [NPI] = @ATYPICAL_NPI WHERE ApplicationID = @application_id;
				UPDATE [KYPPORTAL].[PortalKYP].[pPDM_Provider] SET [NPI] = @ATYPICAL_NPI WHERE PartyID = @PARTY_ID;
		END

	--/*Ken-12586 End*/
      
   SET @date_created = GETDATE ();
   SET @account_number = 100000000 + @case_id
   
   IF (@packageName IN ('F_THS_OE', 'F_THS_SP') AND ISNULL(@newPackage,'') IN ('F_DPP_OE', 'F_DPP_SP') )
	BEGIN

	  EXEC @account_id =  [KYPEnrollment].[sp_Create_Account_DPP] @application_id
												  , @party_account_id
												  , @application_type
												  , @new_account_number
												  , @newPackage
												  , @provider_type_code
												  , @risk
												  , @priority
												  , @composite_risk
												  , @last_action_user_id
												  , @EIN;
	END
   ELSE
	BEGIN
		INSERT INTO [KYPEnrollment].[pADM_Account]
		  ([portaluserid]
		  ,[ProviderType]
		  ,[NPI]
		  ,[NPIType]
		  ,[ApplicationNumber]
		  --,[StatusAcc]
		  ,[PartyID]
		  ,[AccountNumber]
		  ,[IsDeleted]
		  ,[profile_id]
		  ,[PackageName]
		  ,[ProviderTypeCode]
		
		  ,[RiskDescriptor]
		  ,[OwnerNo]
		  ,[Risk]
		  ,[RiskScore]
		  --,[StatusBeginDate]
		  ,[IncorporatedDate]
		  ,[ActivationDate]
		  ,[DateCreated]
		  --,[LastActionDate]
		  ,[LastAction]
		  --,[LastActorUserID]
		  ,[LastActionApprovedBy]
		  ,[AccountUpdatedBy]
		  ,[ProvTypeUpdateDate]
		  ,[CreatedBy]
		  ,[AccProcessing]-- KEN-7045
		  ,[IsProvOwnedData]
		  ,[ApplicationDate]
		  ,[DateModified]--KPP-6612
		  ,[ProvLocTypeCd]
		  ,ReenrollmentDate --KEN-17331
		  ,EIN
		  )
      
		SELECT  [portaluserid]
				,coalesce((select d.ProviderTypeDescription from kyp.pdm_providertypecode d where d.ProviderTypeCode=@provider_type_code and ProviderTypeDescription NOT IN ('Out of State Hospital')),Type)
				,[NPI]
				,[NpiType]
				,[ApplicationNo]
				--,'3 - Pending'--change '1 - Active'
				,@party_account_id
				, @new_account_number
				,0
				,[profile_id]
				,[ApplicationCode]
				-------------------------------------------------------------
				,@provider_type_code
				-------------------------------------------------------------
				,@risk
				,'01'
				,@priority
				,@composite_risk
				--,@date_created
				,@date_created
				,@date_created
				,@date_created
				--,@date_created
				,'C'
				--,@last_action_user_id
				,@last_action_user_id
				,'P'
				,@date_created
				,@last_action_user_id
				,1
				,1
				,[DateCreated]
				,getdate()
				,CASE WHEN (EXISTS(select partyAddressId from #tempProviderType where appName=ApplicationNo and IsDeleted=0 and partyAddressId IS NOT NULL)
				 OR EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p  
				 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioFacility' and p.IsDeleted=0))
				 THEN 'F' ELSE CASE WHEN EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p  
				 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioHospital' and p.IsDeleted=0)
				 THEN 'H' ELSE CASE WHEN EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p  
				 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioClinic' and p.IsDeleted=0)
				 THEN 'C' END END END
				 ,kypenrollment.ScheduleAccDate()--KEN-17331
				 ,@EIN
				
		FROM [KYPPORTAL].[PortalKYP].[pADM_Application] 
		WHERE ApplicationID = @application_id;

		SELECT @account_id = SCOPE_IDENTITY();
		PRINT 'Create New AccountID: '+ CONVERT(VARCHAR(10),@account_id);
	END

INSERT INTO [KYPEnrollment].[pADM_AccProvMapping](
               [AccountNumber]
			  ,[CurrentRecordFlag]
			  ,[LastAction]
			  ,[LastActionApprovedBy]
			  ,[LastActionDate]
			  ,[LastActorUserID])
      
VALUES (@account_number
        ,1
        ,'C'
        ,@last_action_user_id
        ,@date_created
        ,@last_action_user_id)
          
 PRINT 'Create Account Provider Mapping';           
        
SELECT @party_application = PartyID FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationID = @application_id;
INSERT INTO [KYPEnrollment].[pAccount_PDM_PracticeLanguage](
			 [PartyID]
			,[Language]
			,[IsDeleted]
			,[CurrentRecordFlag]
			,[LastAction]
			,[LastActionApprovedBy]
			,[LastActionDate]
			,[LastActorUserID]
)
SELECT @party_account_id
	   ,[Language]
	   ,0
	   ,1
	   ,'C'
	   ,@last_action_user_id
       ,@date_created
       ,@last_action_user_id
 FROM [KYPPORTAL].[PortalKYP].[pPDM_PracticeLanguage] WHERE PartyID=@party_application;
 PRINT 'Create Account Practice Language';     
 
 DECLARE @package_name VARCHAR(30)
 SELECT @package_name=PackageName FROM [KYPEnrollment].[pADM_Account] WHERE AccountID=@account_id;
 
 /*
 IF @is_group=1
 BEGIN
  EXEC [KYPEnrollment].[Create_TaxID_Associate]@account_id,@party_account_id,@account_number,@date_created;
 END
 */
 
 EXEC [KYPEnrollment].[sp_Copy_Provider] @party_account_id,@party_application,@last_action_user_id;
 EXEC [KYPEnrollment].[sp_Store_Attachments_Plain_Forms_References]
                                                            @accountId = @account_id
                                                            , @applicationId = @application_id;
 RETURN  @account_id;

 END TRY	
BEGIN CATCH
	 IF @@TRANCOUNT > 0
	 ROLLBACK TRANSACTION 
	  
	 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'Case_id',@KeyValue = @case_id; 
	 
END CATCH

END


GO

