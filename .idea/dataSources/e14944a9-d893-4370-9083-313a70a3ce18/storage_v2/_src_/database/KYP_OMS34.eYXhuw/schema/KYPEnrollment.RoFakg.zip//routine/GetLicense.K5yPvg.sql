
CREATE FUNCTION [KYPEnrollment].[GetLicense](@PartyID int)
RETURNS varchar(500)
AS 
BEGIN
  DECLARE @AccInterID int
  DECLARE @license varchar(500),@number varchar(100),@des varchar(100),@con varchar(10),@current varchar(100)
  DECLARE @next varchar(500)
  
  
  SET @license=''
  SET @next=''
  
    
  SET @current=''
  SET @con=''

   DECLARE  cur  CURSOR FOR
   SELECT p.Number FROM [KYPEnrollment].[pAccount_PDM_Number] p
   WHERE p.PartyID = @PartyID
   
      OPEN cur
      
	  FETCH cur INTO @number
	  WHILE (@@FETCH_STATUS = 0)
	   BEGIN	
	     SET @next =@number 
	     IF @next<>@current 
	     BEGIN
			 SET @license=@license + @con + @next
			 SET @con = ', ' 
			SET @current=@next
		 END 
		 FETCH cur INTO @number
	   END 
	  CLOSE cur
	  DEALLOCATE cur
   
--  

   RETURN @license
END;


GO

