CREATE PROCEDURE [KYP].[p_InsertMDMAlert] (
	@AlertNo VARCHAR(15) = NULL
	,@AssignedToUserID INT = NULL
	,@AssignedByUserID INT = NULL
	,@AssignedDate DATETIME = NULL
	,@StatusCodeNumber INT = 0
	,@GenNo VARCHAR(5) = NULL
	,@WorkFlowStepID INT = NULL
	,@CurrentMajorDisposition VARCHAR(50) = 'Initial Assignment'
	,@CurrentMinorDisposition VARCHAR(50) = 'Unassigned'
	,@CurrentWFMinorStatus VARCHAR(50) = 'Assign Alert'
	,@CurrentWFStatus VARCHAR(50) = 'AssignAlert'
	,@DateInitiated DATETIME = NULL
	,@DateLastOpened DATETIME = NULL
	,@DateClosed DATETIME = NULL
	,@WatchlistName VARCHAR(100) = NULL
	,@MatchPercent INT = NULL
	,@WatchedPartyID INT = NULL
	,@WatchedPartyName VARCHAR(500) = NULL
	,@WatchedPartyRole VARCHAR(50) = NULL
	,@WatchedPartyType VARCHAR(50) = NULL
	,@Priority VARCHAR(15) = NULL
	,@IsMerged VARCHAR(1) = 'N'
	,@IsInterestOf BIT = NULL
	,@NoOfMergedAlerts INT = 0
	,@MatchStatusIndicator VARCHAR(1) = 'U'
	,@MatchStatusIndicatorDescription VARCHAR(25) = 'Unconfirmed'
	,@ConfirmationNoteID INT = NULL
	,@NextProcessStep VARCHAR(20) = NULL
	,@ActivityStatus VARCHAR(20) = 'Not Started'
	,@CreatedDate DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@ModifiedDate SMALLDATETIME = NULL
	,@DeletedBy INT = NULL
	,@DeletedDate SMALLDATETIME = NULL
	,@IsDeleted BIT = 0
	,@CreatedBy INT = NULL
	,@MedicaidID VARCHAR(50) = NULL
	,@isTwoWayMatch BIT = NULL
	,@NPIAlertType VARCHAR(50) = NULL
	,@WFStatus VARCHAR(100) = NULL
	,@WFMajorDisposition VARCHAR(100) = NULL
	,@WFMinorDisposition VARCHAR(100) = NULL
	,@GK_WL_Id INT = NULL
	)
AS
BEGIN
	INSERT INTO [KYP].[MDM_Alert] (
		[AlertNo]
		,[AssignedToUserID]
		,[AssignedByUserID]
		,[AssignedDate]
		,[StatusCodeNumber]
		,[GenNo]
		,[WorkFlowStepID]
		,[CurrentMajorDisposition]
		,[CurrentMinorDisposition]
		,[CurrentWFMinorStatus]
		,[CurrentWFStatus]
		,[DateInitiated]
		,[DateLastOpened]
		,[DateClosed]
		,[WatchlistName]
		,[MatchPercent]
		,[WatchedPartyID]
		,[WatchedPartyName]
		,[WatchedPartyRole]
		,[WatchedPartyType]
		,[Priority]
		,[IsMerged]
		,[IsInterestOf]
		,[NoOfMergedAlerts]
		,[MatchStatusIndicator]
		,[MatchStatusIndicatorDesc]
		,[ConfirmationNoteID]
		,[NextProcessStep]
		,[ActivityStatus]
		,[CreatedDate]
		,[CreatedBy]
		,[ModifiedDate]
		,[ModifiedBy]
		,[DeletedDate]
		,[DeletedBy]
		,[IsDeleted]
		,[MedicaidID]
		,[istwoWayMatch]
		,[NPIAlertType]
		,[WFStatus]
		,[WFMajorDisposition]
		,[WFMinorDisposition]
		,[Relevance]
		,[GK_WL_Id]
		,[WFAlertStatus]
		)
	VALUES (
		@AlertNo
		,@AssignedToUserID
		,@AssignedByUserID
		,@AssignedDate
		,@StatusCodeNumber
		,@GenNo
		,1
		,@CurrentMajorDisposition
		,@CurrentMinorDisposition
		,@CurrentWFMinorStatus
		,@CurrentWFStatus
		,@DateInitiated
		,@DateLastOpened
		,@DateClosed
		,@WatchlistName
		,@MatchPercent
		,@WatchedPartyID
		,@WatchedPartyName
		,@WatchedPartyRole
		,@WatchedPartyType
		,CASE @MatchPercent
			WHEN '90'
				THEN 'High'
			WHEN '80'
				THEN 'Medium'
			WHEN '70'
				THEN 'Low'
			WHEN '60'
				THEN 'Low'
			END
		,@IsMerged
		,@IsInterestOf
		,@NoOfMergedAlerts
		,@MatchStatusIndicator
		,@MatchStatusIndicatorDescription
		,@ConfirmationNoteID
		,@NextProcessStep
		,@ActivityStatus
		,@CreatedDate
		,@CreatedBy
		,@ModifiedDate
		,@ModifiedBy
		,@DeletedDate
		,@DeletedBy
		,@IsDeleted
		,@MedicaidID
		,@isTwoWayMatch
		,@NPIAlertType
		,@WFStatus
		,@WFMajorDisposition
		,@WFMinorDisposition
		,CASE @MatchPercent
			WHEN '90'
				THEN 3
			WHEN '80'
				THEN 2
			WHEN '70'
				THEN 1
			WHEN '60'
				THEN 1
			END
		,@GK_WL_Id
		,'Unassigned'
		)

	RETURN IDENT_CURRENT('[KYP].[MDM_Alert]')
END
GO

