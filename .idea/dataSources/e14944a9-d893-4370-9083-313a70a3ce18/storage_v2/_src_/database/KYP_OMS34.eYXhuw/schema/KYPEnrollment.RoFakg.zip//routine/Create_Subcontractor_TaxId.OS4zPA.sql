
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: 
-- PARAMETERS: 

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Create_Subcontractor_TaxId]
@party_id INT,
@Type VARCHAR(20),
@subcontractorName VARCHAR(150),
@party_provider_id INT

AS
BEGIN
SET NOCOUNT ON 
PRINT'[Create_Subcontractor_TaxID_Associate]'
INSERT INTO [KYPEnrollment].[pAccount_Subcontractor_TaxID_Associate]
           ([PartyID],
			 [SubcontractorName],
			 [Type],
			 [IdentityTaxID],
			 [CurrentRecordFlag])
     VALUES
           (@party_id
           ,@subcontractorName
           ,@Type
           ,@party_provider_id
           ,1)

END


GO

