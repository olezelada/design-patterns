
CREATE VIEW [KYP].[V_CONCATSUMMARYREPORTDATA] AS
SELECT  row_number() OVER (ORDER BY Q.ScreeningID ASC) AS ID, *
FROM         
(
 select 'Name:' as NameText,z.Name, y.ScreeningID,X.Attribute,X.AttributeValue,X.DisplayName,y.PartyType
			from KYP.PDM_Party as Z 
			right Join KYP.SDM_ApplicationParty as y on Z.PartyID=y.PartyID  
			right join  KYP.v_RedFlagsSummary AS X ON y.ScreeningID = X.ScreeningID
)Q


GO

