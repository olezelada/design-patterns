

-- =============================================
-- Author:		<Palomino, Ruth>
-- Create date: <24/05/2019>
-- Description:	<Copy other name>
-- =============================================

CREATE  PROCEDURE [KYPEnrollment].[sp_Copy_OtherName] 
	@other_Name_ID int,
	@last_action_user_id VARCHAR(100),
	@acc_person_id INT
AS
BEGIN

	DECLARE @date_created DATE; 

	SET NOCOUNT ON;

	IF EXISTS (SELECT PesonONID FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] WHERE PesonONID=@other_Name_ID)
	BEGIN
		
		PRINT 'EXIST'	
		SET @date_created =  GETDATE();
			
						INSERT INTO [KYPEnrollment].[pAccount_PDM_Person_OtherName]

								   ([PersonID]
								   ,[FirstName]
								   ,[LastName]
								   ,[MiddleName]
								   ,[CreatedBy]
								   ,[DateCreated]
								   ,[IsDeleted]
								   ,[LastAction]
								   ,[LastActionDate]
								   ,[LastActorUserID]
								   ,[LastActionApprovedBy]
								   ,[CurrentRecordFlag])
	           
						SELECT	@acc_person_id,
								[FirstName],
								[LastName],
								[MiddleName],
								[CreatedBy],
								@date_created,
								[IsDeleted],
								'C',
								@date_created,
								@last_action_user_id,
								@last_action_user_id,
								1
						FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] 
						WHERE PesonONID=@other_Name_ID AND IsDeleted=0;

		PRINT 'New Only Other Name';				
    END
END


GO

