
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Select Package that will be create by Application code.
-- PARAMETERS:
-- @new_account_id : AccountID to new Account that will be create.
-- @new_Party_Id : partyID to new Account that will be create.
-- @party_Id : partyID Application that will be Account.
-- @application_Code : ApplicationCode that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @application_no : Application Number that will be Account.
-- @application_Id : ApplicationID that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Application]
   @new_Account_Id         INT,
   @new_Party_Id           INT,
   @party_Id               INT,
   @application_Code       VARCHAR (100),
   @last_Action_User_ID    VARCHAR (100),
   @application_no         VARCHAR (100),
   @application_Id         INT,
   @account_type           VARCHAR (10),
   @application_type       VARCHAR (30) = NULL,
   ------------------------------------------
   @provider_type_code varchar(50) = NULL
   ------------------------------------------
AS
BEGIN
   --mvc
   CREATE TABLE #subcontractors
   (
      pk               INT IDENTITY (1, 1),
      PartyID_Portal   INT,
      Type_sub         VARCHAR (50),
      PartyID_Enroll   INT
   )

  DECLARE @crossoverIndicator BIT = 1
   --

   IF @application_Code = 'ISP_P_DM'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_P_DM] @new_Account_Id,
                                                 @new_Party_Id,
                                                 @party_Id,
                                                 @last_Action_User_ID,
                                                 @application_no,
                                                 @application_Id,
                                                 @account_type,
                                                 @application_type;
      END

   IF    @application_Code = 'GSP_P_DM'
      OR @application_Code = 'GSP_AL_BL'
      OR @application_Code = 'IGSP_NP_AP'
      OR @application_Code = 'IGSP_P_DM'
      OR @application_Code = 'GSP_OAP_BL'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_GSP_P_DM] @new_Account_Id,
                                                 @new_Party_Id,
                                                 @party_Id,
                                                 @last_Action_User_ID,
                                                 @application_no,
                                                 @application_Id,
                                                 @account_type,
                                                 @application_type;
      END

   IF @application_Code = 'GISP_P_DM' OR @application_Code = 'GISP_NP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_GISP_AL_BL] @new_Account_Id,
                                                   @new_Party_Id,
                                                   @party_Id,
                                                   @last_Action_User_ID,
                                                   @application_no,
                                                   @application_Id,
                                                   @account_type,
                                                   @application_type;
      END

   IF @application_Code = 'ISP_RP_P_DM'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_RP_P_DM] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @account_type,
                                                    @application_type;
      END

   IF (   @application_Code = 'ISP_RP_U_RA'
       OR @application_Code = 'ISP_RP_O_RA'
       OR @application_Code = 'ISP_RP_P_RA'
       OR @application_Code = 'ISP_RP_OAP_RA')
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_RP_U_RA] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @account_type,
                                                    @application_type;
      END

   IF @application_Code = 'ISP_RP_S_RM'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_RP_S_RM] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @application_type;
      END

   IF @application_Code = 'ISP_NP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_NP_AP] @new_Account_Id,
                                                  @new_Party_Id,
                                                  @party_Id,
                                                  @last_Action_User_ID,
                                                  @application_no,
                                                  @application_Id,
                                                  @account_type,
                                                  @application_type;
      END

   IF @application_Code = 'ISP_P_ORP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_P_ORP] @new_Account_Id,
                                                  @new_Party_Id,
                                                  @party_Id,
                                                  @last_Action_User_ID,
                                                  @application_Id,
                                                  @application_type;
      END

   -- New SP�s for new Packages MD.

   IF @application_Code = 'ISP_MDH'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_MDH] @new_Account_Id,
                                                @new_Party_Id,
                                                @party_Id,
                                                @last_Action_User_ID,
                                                @application_no,
                                                @application_Id,
                                                @account_type,
                                                @application_type;
      END

   IF @application_Code = 'GSP_MDH'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_GSP_MDH] @new_Account_Id,
                                                @new_Party_Id,
                                                @party_Id,
                                                @last_Action_User_ID,
                                                @application_no,
                                                @application_Id,
                                                @account_type,
                                                @application_type;
      END

   IF @application_Code = 'RP_MDH'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_RP_MDH] @new_Account_Id,
                                               @new_Party_Id,
                                               @party_Id,
                                               @last_Action_User_ID,
                                               @application_no,
                                               @application_Id,
                                               @account_type,
                                               @application_type;
      END

   -- Sole Proprietor Crossover Only Provider
   IF    @application_Code = 'ISP_ISP_COP_AP'
      OR @application_Code = 'GISP_GSP_COP_AP'
      OR @application_Code = 'ISP_FSP_COP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_ISP_COP_AP] @new_Account_Id,
                                                       @new_Party_Id,
                                                       @party_Id,
                                                       @last_Action_User_ID,
                                                       @application_no,
                                                       @application_Id,
                                                       @account_type,
                                                       @application_type;

        EXEC [KYPEnrollment].[Update_Crossover_Indicator] @new_Account_Id,
                                                          @crossoverIndicator

      END

   -- Incorporated Crossover Only Provider
   IF    @application_Code = 'IGSP_ISP_COP_AP'
      OR @application_Code = 'IGSP_GSP_COP_AP'
      OR @application_Code = 'IGSP_FSP_COP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_IGSP_ISP_COP_AP] @new_Account_Id,
                                                        @new_Party_Id,
                                                        @party_Id,
                                                        @last_Action_User_ID,
                                                        @application_no,
                                                        @application_Id,
                                                        @account_type,
                                                        @application_type;

        EXEC [KYPEnrollment].[Update_Crossover_Indicator] @new_Account_Id,
                                                          @crossoverIndicator
      END

   ---Changes Orthotist and Prosthetist to reviewer
   IF    @application_Code = 'ISP_OP_AP'
      OR @application_Code = 'ISP_PP_AP'
      OR @application_Code = 'ISP_OAP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_OP_AP] @new_Account_Id,
                                                  @new_Party_Id,
                                                  @party_Id,
                                                  @last_Action_User_ID,
                                                  @application_no,
                                                  @application_Id,
                                                  @account_type,
                                                  @application_type;
      END

   IF @application_Code = 'IGSP_OP_AP'
      OR @application_Code = 'IGSP_PP_AP'
      OR @application_Code = 'IGSP_OAP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_GSP_OAP_BL] @new_Account_Id,
                                                   @new_Party_Id,
                                                   @party_Id,
                                                   @last_Action_User_ID,
                                                   @application_no,
                                                   @application_Id,
                                                   @account_type,
                                                   @application_type;
      END

   IF @application_Code = 'GISP_OAP_AP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_GISP_OAP_AP] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @account_type,
                                                    @application_type;
      END
	-- Ambulatory Surgical Clinic Sole Proprietor --> ISP_FSO_ASC_SP  -- Clinical Laboratory Sole Proprietor -->  ISP_FSP_CLP_SP
   IF (@application_Code = 'ISP_FSP_ASC_SP'  OR @application_Code = 'ISP_FSP_CLP_SP')
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_ISP_FSP_ASC_SP] @new_Account_Id,
                                                       @new_Party_Id,
                                                       @party_Id,
                                                       @last_Action_User_ID,
                                                       @application_no,
                                                       @application_Id,
                                                       @account_type,
                                                       @application_type;
      END

	-- Ambulatory Surgical Clinic Incorporated --> IGSP_FSP_ASC_IN -- Clinical Laboratory Sole Proprietor -->  IGSP_FSP_CLP_IN
   IF (@application_Code = 'IGSP_FSP_ASC_IN' OR  @application_Code = 'IGSP_FSP_CLP_IN')
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_IGSP_FSP_ASC_IN] @new_Account_Id,
                                                        @new_Party_Id,
                                                        @party_Id,
                                                        @last_Action_User_ID,
                                                        @application_no,
                                                        @application_Id,
                                                        @account_type,
                                                        @application_type;
      END

  --Facility Exempt from Licensure Clinic Sole Proprietor
  IF @application_Code = 'F_CAEL_SP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_CAEL_SP] @new_Account_Id,
                                                       @new_Party_Id,
                                                       @party_Id,
                                                       @last_Action_User_ID,
                                                       @application_no,
                                                       @application_Id,
                                                       @account_type,
                                                       @application_type;
      END
  --Facility Exempt from Licensure Clinic Other Entity
   IF @application_Code = 'F_CAEL_OE'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_CAEL_OE] @new_Account_Id,
                                                        @new_Party_Id,
                                                        @party_Id,
                                                        @last_Action_User_ID,
                                                        @application_no,
                                                        @application_Id,
                                                        @account_type,
                                                        @application_type;
      END
  --Facility County Clinics not Associated with Hospital Exempt from Licensure Sole Proprietor
  IF @application_Code = 'F_CNAEL_SP'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_CNAEL_SP] @new_Account_Id,
                                               @new_Party_Id,
                                               @party_Id,
                                               @last_Action_User_ID,
                                               @application_no,
                                               @application_Id,
                                               @account_type,
                                               @application_type;
    END
  --Facility County Clinics not Associated with Hospital Exempt from Licensure Other Entity
  IF @application_Code='F_CNAEL_OE'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_CNAEL_OE] @new_Account_Id,
                                               @new_Party_Id,
                                               @party_Id,
                                               @last_Action_User_ID,
                                               @application_no,
                                               @application_Id,
                                               @account_type,
                                               @application_type;
    END
	
	IF @application_Code='FSP_DMC_SP'
	BEGIN
		PRINT @application_Code;
		EXEC [KYPEnrollment].[sp_copy_FC_DMC_SP] @new_Account_Id,@new_Party_Id,@party_Id,@last_Action_User_ID,@application_no,@application_Id,@application_type, @provider_type_code;
	END
	

	IF @application_Code='FSP_DMC_IN'
	BEGIN
		PRINT @application_Code;
		EXEC [KYPEnrollment].[sp_copy_FC_DMC_IN] @new_Account_Id,@new_Party_Id,@party_Id,@last_Action_User_ID,@application_no,@application_Id,@application_type, @provider_type_code;
	END

  IF @application_Code = 'ISP_DMC_SUDTP'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_ISP_DMC_SUDTP] @new_Account_Id,
                                                 @new_Party_Id,
                                                 @party_Id,
                                                 @last_Action_User_ID,
                                                 @application_no,
                                                 @application_Id,
                                                 @account_type,
                                                 @application_type;
    END
	
	--new transportation by Giresse
	IF @application_Code='FSP_MDT_SP'
	BEGIN
		PRINT @application_Code;
		EXEC [KYPEnrollment].[sp_copy_FSP_MDT_SP] @new_Account_Id,@new_Party_Id,@party_Id,@last_Action_User_ID,@application_no,@application_Id,@application_type,@provider_type_code;
	END

	IF @application_Code='FSP_MDT_IN'
	BEGIN
		PRINT @application_Code;
		EXEC [KYPEnrollment].[sp_copy_FSP_MDT_IN] @new_Account_Id,@new_Party_Id,@party_Id,@last_Action_User_ID,@application_no,@application_Id,@application_type,@provider_type_code;
	END
	
	-- Pharmacy Sole Proprietor --> F_PHA_SP
	IF @application_Code = 'F_PHA_SP'
		BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_PHA_SP] @new_Account_Id,
                                                       @new_Party_Id,
                                                       @party_Id,
                                                       @last_Action_User_ID,
                                                       @application_no,
                                                       @application_Id,
                                                       @account_type,
                                                       @application_type;
		END
	-- Pharmacy Other Entity --> F_PHA_OE
	IF @application_Code = 'F_PHA_OE'
		    BEGIN
			    PRINT @application_Code;
			    EXEC [KYPEnrollment].[sp_Copy_F_PHA_OE] @new_Account_Id,
														@new_Party_Id,
														@party_Id,
														@last_Action_User_ID,
														@application_no,
														@application_Id,
														@account_type,
														@application_type;
	END

  --Durable Medical Equipment Sole Proprietor
  IF @application_Code = 'ISP_FSP_DME_SP'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_ISP_FSP_DME_SP] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @account_type,
                                                    @application_type;
    END
  --Durable Medical Equipment Incorporate
  IF @application_Code = 'IGSP_FSP_DME_IN'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_IGSP_FSP_DME_IN] @new_Account_Id,
                                                     @new_Party_Id,
                                                     @party_Id,
                                                     @last_Action_User_ID,
                                                     @application_no,
                                                     @application_Id,
                                                     @account_type,
                                                     @application_type;
    END
    
    
	-- Tribal Health Service Sole Proprietor --> F_THS_SP
   IF @application_Code='F_THS_SP'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_THS_SP] @new_Account_Id,
                                                 @new_Party_Id,
                                                 @party_Id,
												 @last_Action_User_ID,
												 @application_no,
												 @application_Id,
												 @account_type,
												 @application_type;
      END

	
	-- Tribal Health Service Other Entity --> F_THS_OE
   IF @application_Code='F_THS_OE'
      BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_THS_OE] @new_Account_Id,
                                                        @new_Party_Id,
                                                        @party_Id,
                                                        @last_Action_User_ID,
                                                        @application_no,
                                                        @application_Id,
                                                        @account_type,
                                                        @application_type;
      END

  -- Blood Bank Sole Proprietor --> F_BB_SP
	IF @application_Code = 'F_BB_SP'
		  BEGIN
         PRINT @application_Code;
         EXEC [KYPEnrollment].[sp_Copy_F_BB_SP] @new_Account_Id,
                                                       @new_Party_Id,
                                                       @party_Id,
                                                       @last_Action_User_ID,
                                                       @application_no,
                                                       @application_Id,
                                                       @account_type,
                                                       @application_type;
		  END
	-- Blood Bank Other Entity --> F_BB_OE
	IF @application_Code = 'F_BB_OE'
		  BEGIN
			    PRINT @application_Code;
			    EXEC [KYPEnrollment].[sp_Copy_F_BB_OE] @new_Account_Id,
														@new_Party_Id,
														@party_Id,
														@last_Action_User_ID,
														@application_no,
														@application_Id,
														@account_type,
														@application_type;
	    END

	      IF @application_Code='F_OOS_OE'
        BEGIN
          PRINT @application_Code;
          EXEC [KYPEnrollment].[sp_copy_F_OOS_OE]
          @new_Account_Id,
          @new_Party_Id,
          @party_Id,
          @last_Action_User_ID,
          @application_no,
          @application_Id,
          @account_type,
          @application_type;

        END
    --Portal Imaging Sole Proprietor
  IF @application_Code = 'F_PI_SP'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_PI_SP] @new_Account_Id,
                                                    @new_Party_Id,
                                                    @party_Id,
                                                    @last_Action_User_ID,
                                                    @application_no,
                                                    @application_Id,
                                                    @account_type,
                                                    @application_type;
    END
  --Portable Imaging Other Entity
  IF @application_Code = 'F_PI_OE'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_PI_OE] @new_Account_Id,
                                                     @new_Party_Id,
                                                     @party_Id,
                                                     @last_Action_User_ID,
                                                     @application_no,
                                                     @application_Id,
                                                     @account_type,
                                                     @application_type;
    END
	
  -- New DPP Sole proprietor
  IF @application_Code = 'F_DPP_SP'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_DPP_SP] @new_Account_Id,
                                                     @new_Party_Id,
                                                     @party_Id,
                                                     @last_Action_User_ID,
                                                     @application_no,
                                                     @application_Id,
                                                     @account_type,
                                                     @application_type,
                                                     @application_Code;
    END

  -- New DPP Incorporate
  IF @application_Code = 'F_DPP_OE'
    BEGIN
      PRINT @application_Code;
      EXEC [KYPEnrollment].[sp_Copy_F_DPP_OE] @new_Account_Id,
                                                     @new_Party_Id,
                                                     @party_Id,
                                                     @last_Action_User_ID,
                                                     @application_no,
                                                     @application_Id,
                                                     @account_type,
                                                     @application_type,
                                                     @application_Code;
    END

END
GO

