



CREATE PROCedure [KYP].[p_InsertADMCase]
(
 @Number varchar(15)= NULL
 ,@Type int =NULL
 ,@EnrollmentType varchar(50) = NULL
 ,@SubType varchar(25)=NULL
 ,@Status varchar(25)=NULL
 ,@StatusCodeNumber int=NULL
 ,@CurrentMajorDisposition varchar(100)=NULL
 ,@CurrentMinorDisposition varchar(100)=NULL
 ,@ActivityStatus varchar(25)=NULL
 ,@InvestigationAge int=NULL
 ,@GenNo varchar(5)=NULL
 ,@CaseOwnerID int=NULL
 ,@AssignedFromID int=NULL
 ,@CurrentlyAssignedToID int=NULL
 ,@CurrentlyAssignedToName varchar(50)=NULL
 ,@ResolutionStatus varchar(25)=NULL
 ,@DateResolved smalldatetime=NULL
 ,@DateAssigned smalldatetime=NULL
 ,@DateReceived smalldatetime=NULL
 ,@DateInitiated smalldatetime=NULL
 ,@DueDate smalldatetime=NULL
 ,@EndDate smalldatetime =NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@ProviderName varchar(150)=NULL
 ,@ProcessModule varchar(100)=NULL
 ,@Description varchar(500)=NULL
 ,@Priority int=NULL
 ,@TypeDescription varchar(255)=NULL
 ,@StatusCodeName varchar(100)=NULL
 ,@Risk varchar(10)=NULL
 ,@StatusName varchar(20)=NULL
 ,@IsPPURequired bit = 1 
 ,@CaseAge varchar(10)= NULL
  ,@Provider_NPI int=Null
/*,@Provider_NPI varchar(10)=Null linu: integer NPI into to varchar*/	
 ,@Provider_SSN varchar(15)=Null
 ,@Provider_TIN varchar(15)=NULL
 ,@Provider_MID varchar(15)=NULL
 ,@UserFullName varchar(100)=Null
 ,@StatusSubName  varchar(25)=Null
 ,@Resubmitted varchar(2)=Null
 ,@PrevStatusCodeNumber int=Null
 ,@CaseSource varchar(6)=Null
 ,@CompositeRisk  int=Null
 ,@InternalAppStatus bit=1
 ,@ReviewStatus varchar(100)=Null
 ,@WFMajorStep varchar(150)=Null
 ,@WFMinorStep varchar(150)=Null
 ,@WFStatus varchar(100)=Null
 ,@PAN varchar(7)=Null
 ,@ApplnType varchar(50)=Null
 ,@AccountID int=NULL
 -- Adding practice type code to adm_case
 ,@P_PRACT_TY_CD VARCHAR(50) = Null
 ,@Sup_Update varchar(20)=NULL
 ,@LastUpdateAppID int=NULL
 ,@Account_No varchar(20)=NULL
 ,@Group_NPI int=Null
 ,@Group_AccountNumber varchar(20)= NULL
 ,@Preffered varchar(50) = NULL
 ,@Group_DisaffiliateAcNo varchar(50) = NULL
 ,@Rendered_DisaffiliateAcNo varchar(50) = NULL
 ,@ProviderTypeCode varchar(20) = NULL
 ,@IsMoratoria bit = NULL
 ,@HDProgram bit = NULL
 ,@NHDProgram bit = NULL
 ,@CrossOverApp NVARCHAR(5) = NULL
 ,@FeeRequired bit = NULL
 ,@FeePaid bit = NULL
 ,@FeeExempted bit = NULL
 ,@MDCToMDL bit = NULL
 ,@MDLToMDC bit = NULL
 ,@FeeConfirmation NVARCHAR(50) = NULL
 ,@ProvTypeDesc NVARCHAR(150) = NULL
 ,@IsTribalAppln bit = NULL
 ,@OrtProsthetic VARCHAR(50) = NULL
 )
 

as begin 


INSERT INTO [KYP].[ADM_Case]
           ([Number]
           ,[Type]
           ,[EnrollmentType]
           ,[SubType]
           ,[Status]
           ,[StatusCodeNumber]
           ,[CurrentMajorDisposition]
           ,[CurrentMinorDisposition]
           ,[ActivityStatus]
           ,[InvestigationAge]
           ,[GenNo]
           ,[CaseOwnerID]
           ,[AssignedFromID]
           ,[CurrentlyAssignedToID]
           ,[CurrentlyAssignedToName]
           ,[ResolutionStatus]
           ,[DateResolved]
           ,[DateAssigned]
           ,[DateReceived]
           ,[DateInitiated]
           ,[DueDate]
           ,[EndDate]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[ProviderName]
           ,[ProcessModule]
           ,[Description]
           ,[Priority]
           ,[TypeDescription]
           ,[StatusCodeName]
           ,[Risk]
           ,[StatusName]
           ,[IsPPURequired]
           ,[CaseAge]
           ,[Provider_NPI]
           ,[Provider_SSN]
           ,[Provider_TIN]
           ,[Provider_MID]
           ,[UserFullName]
           ,[StatusSubName]
           ,[Resubmitted]
           ,[PrevStatusCodeNumber]
           ,[CaseSource]
           ,[CompositeRisk]
           ,[InternalAppStatus]
           ,[ReviewStatus]
           ,[WFMajorStep]
           ,[WFMinorStep]
           ,[WFStatus]
           ,[PAN]
           ,[ApplnType]
           ,[AccountID]
           -- Adding practice type code
           ,[P_PRACT_TY_CD]
           ,[SupUpdateFlag]
           ,[AccountNo]
           ,[LSAppID]
           ,[Group_NPI]
           ,[Group_AccountNumber]
           ,[PrefferedProvider]
           ,[Group_DisaffiliateAcNo]
           ,[Rendered_DisaffiliateAcNo]
           ,[ProviderTypeCode]
           ,[IsMoratoria]
           ,[HDProgram]
           ,[NHDProgram]  
           ,[CrossOverApp]
		   ,[FeeRequired]
		   ,[FeePaid]
		   ,[FeeExempted]
		   ,[MDCToMDL]
		   ,[MDLToMDC]
		   ,[FeeConfirmation]
		   ,[ProvTypeDesc]   
		   ,[IsTribalAppln]     
		   ,[OrtProsthetic]
               
           )

     VALUES
          (@Number
           ,@Type
           ,@EnrollmentType
           ,@SubType
           ,@Status
           ,@StatusCodeNumber
           ,@CurrentMajorDisposition
           ,@CurrentMinorDisposition
           ,@ActivityStatus
           ,@InvestigationAge
           ,@GenNo
           ,@CaseOwnerID
           ,@AssignedFromID
           ,@CurrentlyAssignedToID
           ,@CurrentlyAssignedToName
           ,@ResolutionStatus
           ,@DateResolved
           ,@DateAssigned
           ,@DateReceived
           ,@DateInitiated
           ,@DueDate
           ,@EndDate
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@ProviderName
           ,@ProcessModule
           ,@Description
           ,@Priority
           ,@TypeDescription
           ,@StatusCodeName
           ,@Risk
           ,@StatusName
           ,@IsPPURequired
           ,@CaseAge 
           ,@Provider_NPI
           ,@Provider_SSN 
           ,@Provider_TIN 
           ,@Provider_MID 
			,@UserFullName
           ,@StatusSubName
			,@Resubmitted
           ,@PrevStatusCodeNumber
           ,@CaseSource
           ,@CompositeRisk
           ,@InternalAppStatus
           ,@ReviewStatus
           ,@WFMajorStep
           ,@WFMinorStep
           ,@WFStatus
           ,@PAN
           ,@ApplnType
           ,@AccountID
           -- Adding practice type code
           ,@P_PRACT_TY_CD
           ,@Sup_Update
           ,@Account_No
           ,@LastUpdateAppID
           ,@Group_NPI
           ,@Group_AccountNumber
           ,@Preffered
		   ,SUBSTRING(@Group_DisaffiliateAcNo,0,10)
           ,SUBSTRING(@Rendered_DisaffiliateAcNo,0,10)
           ,@ProviderTypeCode
           ,@IsMoratoria
           ,@HDProgram
           ,@NHDProgram
           ,@CrossOverApp
		   ,@FeeRequired
		   ,@FeePaid
		   ,@FeeExempted
		   ,@MDCToMDL
		   ,@MDLToMDC
		   ,@FeeConfirmation
		   ,@ProvTypeDesc
		   ,@IsTribalAppln
		   ,@OrtProsthetic
           
)

	return IDENT_CURRENT('[KYP].[ADM_Case]')


end


GO

