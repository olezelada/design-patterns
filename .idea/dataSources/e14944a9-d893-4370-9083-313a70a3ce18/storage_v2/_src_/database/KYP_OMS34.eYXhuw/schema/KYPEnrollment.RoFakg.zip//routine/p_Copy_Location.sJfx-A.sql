
-- =============================================
-- Author:		<Author,,Lperez>
-- Copiar Location recive 6 parametros 
-- location ID, New Address, new Party id, new Provider id, new person id,nombre del usuario que realiza la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Location]
	@locationId INT,
	@newAddressId INT,
	@newPartyId INT,
	@newProviderID INT,
	@newPersonID INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@sql NVARCHAR(1000),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
	([AddressID] ,
	[PartyID] ,
	[ProviderID] ,
	[PersonID] ,
	[Type] ,
	[WorkingDays] ,
	[WorkingHours] ,
	[Phone1] ,
	[Phone2] ,
	[Fax] ,
	[Remarks] ,
	[LastAction] ,	
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy] ,
	[InActive] ,
	[CurrentRecordFlag] ,
	[Email] ,
	[IsLicensed] ,
	[IsRented] ,
	[Status] ,
	[Name])
	SELECT @newAddressId
	,@newPartyId
	,@newProviderID
	,@newPersonID
	,[Type]
	,[WorkingDays]
	,[WorkingHours]
	,[Phone1]
	,[Phone2]
	,[Fax]
	,[Remarks]	
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,[InActive]
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[Email]
	,[IsLicensed]
	,[IsRented]
	,[Status]
	,[Name]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] WHERE [LocationID] = @locationId
		
	SELECT @message = '[pPDM_Location] Inset ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT				
END


GO

