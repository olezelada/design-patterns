
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Entity Ownership forms.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create.
-- ============================================================*/
--Change History
---------------------------------------------------------------------------------------
-- Sl.No. JIRA No.  Author  Date   Description
---------------------------------------------------------------------------------------
-- 1  CAPAVE-1742  Sundar  4-Jul-2017  Commented the SP call (kyp.usp_MocaInputDoc) since, it is added in sp_Update_Account SP

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Entity_Owner]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @account_id             INT,
   @is_prepopulated        BIT,
   @party_provider_id      INT,
   @is_group               BIT,
   @target_path            VARCHAR (200)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @date_created       DATE,
      @is_corporation     BIT,
      @full_name_entity   VARCHAR (100),
      @org_id             INT,
      @main_party_id      INT;
   SET @date_created = GETDATE ();
   SELECT @is_corporation = IsCorporation
   FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization]
   WHERE PartyID = @party_app_id

   /*Entity Information*/
   EXEC
       @org_id =
          [KYPEnrollment].[sp_Copy_Organization] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id;
   SELECT @full_name_entity = LegalName
   FROM [KYPEnrollment].[pAccount_PDM_Organization]
   WHERE OrgID = @org_id

   IF @is_corporation = 1
      BEGIN
         EXEC [KYPEnrollment].[sp_Copy_Address_Owner] @party_account_id,
                                                      @party_app_id,
                                                      @last_action_user_id;
      END
   ELSE
      BEGIN
         EXEC [KYPEnrollment].[sp_Copy_Address] @party_account_id,
                                                @party_app_id,
                                                NULL,
                                                @last_action_user_id;
      END

   EXEC [KYPEnrollment].[sp_Copy_Program_Participation] @party_account_id,
                                                        @party_app_id,
                                                        @last_action_user_id,
                                                        'EntityAdvAction',
                                                        NULL,
                                                        @account_id;

   /*Owner Interest*/
   EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @party_account_id,
                                             @party_app_id,
                                             @last_action_user_id,
                                             NULL,
                                             NULL;

   /*Association*/
   /*other association*/
   EXEC [KYPEnrollment].[sp_Copy_Others_Associations] @party_account_id,
                                                      @party_app_id,
                                                      @account_id,
                                                      @last_action_user_id,
                                                      NULL;

   /*Adverse Action*/
   EXEC [KYPEnrollment].[sp_Copy_Program_Suspension] @party_account_id,
                                                     @party_app_id,
                                                     @last_action_user_id,
                                                     'EntityQuestion',
                                                     NULL,
                                                     @account_id;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'EntityActionConviction',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'EntityActionLiability',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'EntityActionSettlement',
                                                 NULL;
   -- Added for new packages MD.
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'EntityActionPending',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'EntityActionSuspendedSurrendered',
                                                 NULL;

   /* Entity Individual */

   EXEC [KYPEnrollment].[sp_Copy_Assocoation_Ind_Ent] @party_account_id,
                                                      @party_app_id,
                                                      @last_action_user_id,
                                                      'OwnershipIndividualAssociation',
                                                      'OwnershipEntityAssociation';

   IF (@is_group = 1)
      BEGIN
         IF (@is_prepopulated IS NULL OR @is_prepopulated = 0)
            BEGIN
               --EXEC [KYPEnrollment].[Create_Moca_TaxId] @party_account_id,'Entity',@full_name_entity, @party_provider_id;
               EXEC [KYPEnrollment].[Create_Party_Associate] @party_account_id,
                                                             @party_account_id,
                                                             @account_id,
                                                             'Entity Ownership',
                                                             @party_app_id;
            END
         ELSE
            BEGIN
               SELECT TOP 1
                      @main_party_id = Item
                 FROM [KYPEnrollment].[SplitString] (@target_path, '|')
               ORDER BY item;
               SELECT TOP 1
                      @main_party_id = MainPartyID
               FROM [KYPEnrollment].[pAccount_Party_Associate]
               WHERE PartyID = @main_party_id;
               EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                             @party_account_id,
                                                             @account_id,
                                                             'Entity Ownership',
                                                             @party_app_id;
            END
      END
--Commented for Input Doc Moca changes (CAPAVE-1742) on 4-Jul-2017
--EXEC KYPEnrollment.usp_MocaInputDoc @account_id  --Added for MOCA Color changes.
END


GO

