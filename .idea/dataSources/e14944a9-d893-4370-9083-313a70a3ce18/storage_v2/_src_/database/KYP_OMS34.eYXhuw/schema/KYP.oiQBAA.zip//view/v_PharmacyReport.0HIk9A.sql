

CREATE VIEW [KYP].[v_PharmacyReport] as
SELECT ROW_NUMBER() OVER (ORDER BY Number) AS RID,ILV.Application,ILV.ApplicationType,
ILV.ProviderName,ILV.NPI,ILV.DateReceived,ILV.DateResolved,
ILV.IsPPURequired,ILV.CurrentlyAssignedToName,ILV.CurrentlyAssignedToRole,ILV.UserFullName,
ILV.PlaceofBusiness,ILV.MileStone,ILV.ServiceAddress,ILV.Number,ILV.CaseID,ILV.SpecPharmacy,ILV.DateReceivedRange, ILV.DateResolvedRange
	FROM (SELECT DISTINCT 
	a.Number as Application,
	a.ApplnTypeAlias AS ApplicationType,a.ProviderName,a.Provider_NPI as NPI, a.DateReceived AS DateReceivedRange, a.DateResolved AS DateResolvedRange,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(A.DateReceived as date), 101),''))),'NA') As DateReceived,a.CurrentlyAssignedToName,a.UserFullName,a.CurrentlyAssignedToRole,
	COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(a.DateResolved as date), 101),''))),'NA')As DateResolved,a.MileStone as MileStone,addr.AddressLine1 as ServiceAddress,
	CASE rent.PrimaryAnswer 
		 WHEN 'RadioOne' THEN 'Lease/Rent'
		 WHEN 'RadioTwo' THEN 'Own'
		 END AS PlaceofBusiness,a.Number,a.CaseID,a.SpecPharmacy,a.IsPPURequired--,role.RoleName,
	FROM KYP.ADM_Case a
	--INNER JOIN (Select CaseID,Max(CaseDetailID) CaseDetailID from KYP.Milestone_CaseDetail
	--			Group by CaseID) b ON a.CaseID=b.CaseID
	--JOIN KYP.Milestone_CaseDetail c on B.CaseDetailID = C.CaseDetailID
	INNER JOIN (SELECT Description FROM KYP.LK_Screening WHERE TypeID=115  AND Description!='Accepted' ) AS Mi
	on A.MILESTONE=mi.Description
	
	LEFT JOIN (SELECT EnrollCaseID,MAX(AID) AID FROM KYPEnrollment.PortalAddress ad
					INNER JOIN KYP.ADM_Case a
					ON ad.EnrollCaseID=a.CaseID WHERE ad.Type='Servicing'
					Group by EnrollCaseID) addr1 ON addr1.EnrollCaseID=a.CaseID
	LEFT JOIN KYPEnrollment.PortalAddress addr ON addr1.AID=addr.AID
	LEFT JOIN 
	(SELECT pl.PrimaryAnswer,c.Number  FROM KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pl
	INNER JOIN KYPPORTAL.PortalKYP.pADM_Application app 
	on pl.PartyId=app.PartyID
	INNER JOIN KYPPORTAL.PortalKYP.pADM_Case c
	on c.CaseID=app.CaseID)rent
	on rent.Number=a.Number
	--INNER JOIN 
	--(SELECT ur.UserID,r.RoleName FROM KYP.OIS_JT_UserRole ur, KYP.OIS_Role r
	-- WHERE ur.RoleID=r.RoleID )role
	-- ON role.UserID=a.CurrentlyAssignedToName
	WHERE A.ProviderTypeCode='024'  AND A.SpecPharmacy='yes' AND A.WFProcessing IS NOT NULL) ILV


GO

