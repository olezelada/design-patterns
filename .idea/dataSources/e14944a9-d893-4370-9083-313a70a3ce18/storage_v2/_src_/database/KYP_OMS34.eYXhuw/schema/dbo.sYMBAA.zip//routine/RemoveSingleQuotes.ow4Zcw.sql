-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RemoveSingleQuotes] 
(
	@NameValue varchar(250)
)
RETURNS varchar(250)
AS
BEGIN
	--declare 
--@MyStr varchar(50)




select @NameValue =
case 

when (charindex('''',@NameValue) = 1 and charindex('''',@NameValue,LEN(@NameValue)-1) = LEN(@NameValue))
      then substring(substring(@NameValue, 2, LEN(@NameValue)-1 ), 1, LEN(@NameValue)-2)
when charindex('''',@NameValue) = 1
      then substring(@NameValue, 2, LEN(@NameValue)-1)
when charindex('''',@NameValue,LEN(@NameValue)-1) = LEN(@NameValue)
      then substring(@NameValue, 1, LEN(@NameValue)-1)
else 
      @NameValue      
end   


return @NameValue


END


GO

