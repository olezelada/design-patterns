
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_AdverseActionPharmacy]
    @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @account_id             INT
AS
BEGIN
 
 EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_app_id, @party_account_id, 'pharmacyAdverseActions'
 
     EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'suspensionRevokedAdverseActions',
                                                  NULL;
                                                 
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'disciplineHearingAdverseActions',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'licenseAuthorityAdverseActions',
                                                 NULL;
  

   PRINT 'New Adverse Action Pharmacy';
END


GO

