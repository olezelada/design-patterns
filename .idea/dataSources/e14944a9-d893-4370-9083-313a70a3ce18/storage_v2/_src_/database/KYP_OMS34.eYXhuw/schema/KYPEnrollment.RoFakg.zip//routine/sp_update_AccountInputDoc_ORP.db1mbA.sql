

CREATE PROCEDURE [KYPEnrollment].[sp_update_AccountInputDoc_ORP]
@acc_party_id INT,
@Username varchar(100),
@UserDate date

AS
Declare @party_id int

BEGIN
set @party_id=(select PartyID from KYPEnrollment.pADM_Account where AccountID=@acc_party_id )

--truncate table [KYPEnrollment].[AccountInputDocORP]

INSERT INTO [KYPEnrollment].[AccountInputDocORP]
               ([AccountID]
               
           ,[PartyID]
           ,[ProvNameScan]
           ,[Analyst]
           ,[AnalystDT]
           ,[Reviewer]
           ,[ReviewerDT]
           ,[Supervisor]
           ,[SupervisorDT]
           ,[NPI]
           ,[OwnerNo]
           ,[SerLocNo]
           ,[ProviderType]
           ,[LegalName]
           ,[SSN]
           ,[EffBDT]
           ,[EffEDT]
           ,[EIN]
           ,[TINUpdDate]
           ,[TINUpdType]
           ,[facility]
           ,[AccountType]
           ,[ProvLocTypeCd]
           ,[DBAName]
           ,[Phone1]
           ,[MAdsL1]
           ,[MAdsL2]
           ,[MCity]
           ,[MState]
           ,[MZipPlus4]
           ,[SAdsL1]
           ,[SAdsL2]
           ,[SCity]
           ,[SState]
           ,[SZipPlus4]
           ,[OutOfStateInd]
           ,[AppDT]
           ,[ProvTypeDetail]
           ,[PracticeCode]
           ,[StatusAcc]
           ,[StatusBgnDt]
           ,[RejResCode]
           ,[Number]
           ,[EffDT]
           ,[CliaNumber]
           ,[SpecProcTypeCode]
            ,[CHDPCode]
           ,[ProvCode]
           ,[ProvCodeDT]
           ,[ReEnrollIn]
           ,ReEnrollDate
           ,[ScodeIdty1]
           ,[ScodeIdty2]
           ,[ScodeIdty3]
           ,[ScodeIdty4]
           ,[ScodeIdty5]
           ,[ScodeIdty6]
           ,[ScodeIdty7]
           ,[ScodeIdty8]
           ,[Spec_C1]
           ,[SpecCertDT1]
           ,[Spec_C2]
           ,[SpecCertDT2]
           ,[Spec_C3]
           ,[SpecCertDT3],
           [GRPIDTY]  ,
           [LABStat]  ,
           [LABEFFDT]  ,
           [DOCNO]   
           ,ProfileID
           ,[userName]
           )
 select  DISTINCT x.AccountID,x.PartyID, x.ProvNameScan,
 Analyst,
 CONVERT( varchar(10), x.AnalystDate, 101) AS AnalystDT,
 Reviewer,
 CONVERT( varchar(10), x.ReviewerDate, 101) AS ReviewerDT,
 Supervisor,
 CONVERT( varchar(10), x.SupervisorDate, 101) AS SupervisorDT,
NPI,OwnerNo,ServiceLocationNo as SerLocNo ,ProviderTypeCode AS ProviderType,LegalName,

SSN,
CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffectiveBeingDate,
CASE CONVERT(varchar(10),x.EffectiveEndDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT,


EIN,
CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdateDate,

TINUpdateType,x.facility,x.AccountType,
 ProvLocTypeCd,BusinessName as DBAName,Phone1,MAddressLine1 AS MAdsL1,MAddressLine2 as MAdsL2,MCity,MState,MZipPlus4,
SAddressLine1 as SAdsL1 ,SAddressLine2 as SAdsL2,SCity,SState,SZipPlus4,OutOfStateInd,--PSS055 PROVIDER DETAIL SCREEN
CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail, PracticeCode,StatusAcc,
CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt,RejectReasonCode AS RejResCode,--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
 --CodeIdentificationCateg,
--CodeDateEffDate,
--CodeDateExpDate,
Number,
CASE CONVERT(varchar(10),x.EffectiveDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT,


x.CliaNumber,x.SpecProcTypeCode,x.CHDPCode,x.ProvisionalCode as ProvCode,

CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT,

ReenrollmentIndicator as ReEnrollIn,ReEnrollDate,
--PSS038 PHYSICIAN CERTIFICATION Speciality_Code,
 SCodeIdentification1 as ScodeIdty1,SCodeIdentification2 as ScodeIdty2 ,SCodeIdentification3  as ScodeIdty3,SCodeIdentification4  as ScodeIdty4,SCodeIdentification5  as ScodeIdty5,
 SCodeIdentification6 as  ScodeIdty6,SCodeIdentification7 as ScodeIdty7 ,SCodeIdentification8 as ScodeIdty8,
  
 Speciality_Code1 AS Spec_C1,CONVERT( varchar(10), CAST(SpecCertDate1 AS DATE), 101) AS SpecCertDT1
,Speciality_Code2 AS Spec_C2,CONVERT( varchar(10), CAST(SpecCertDate2 AS DATE), 101) AS SpecCertDT2
,Speciality_Code3 AS Spec_C3,CONVERT( varchar(10), CAST(SpecCertDate3 AS DATE), 101) AS SpecCertDT3 
 ,GRPIDTY,
 LABStat,LABEFFDT,
 AccountNumber AS ACCNo
 ,ProfileID
,@Username
 from (


SELECT 
A.AccountID As AccountID,
U1.FullName AS Analyst,
U1.LastActionDate AS AnalystDate,
u2.FullName AS Supervisor ,
U2.LastActionDate AS SupervisorDate,
U3.FullName AS Reviewer,
U3.LastActionDate AS ReviewerDate,
A.LastActionDate,
A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
A.PartyID ,
--PED PROVIDER MASTER FILE INPUT DOCUMENT
A.LegalName AS ProvNameScan,
--Document Review and Approve Signatures
--PMF Transaction Signatures
A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
A.ProviderType,
--PSS059 OWNER SCREEN
A.LegalName,
A.SSN,
isnull(B.EffectiveBeingDate,C.BillingBeginDate) as EffectiveBeingDate,
---B.EffectiveBeingDate,

isnull(B.EffectiveEndDate,isnull(C.BillingEndDate,'12/31/2069')) as EffectiveEndDate,

--B.EffectiveEndDate,
A.EIN,
C.TINUpdateDate,
C.TINUpdateType,
A.ProvLocTypeCd as facility,
A.AccountType as AccountType,
c.ProvisionalCode AS ProvLocTypeCd,
D.CodeIdentification,
--PSS070 LOCATION SCREEN 
A.BusinessName,
--Case when(R.Type='Individual Ownership') then 
-- ELSE
--Q.Phone1
--END
 E.Phone1 AS Phone1,

--MAILING ADDRESS
--G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.State AS MState,G.Zip+'-'+G.ZipPlus4 AS MZipPlus4,Changed the zip format PI-350
G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.Abreviation AS MState,G.ZipPlus4 AS MZipPlus4,
--SERVICE ADDRESS
--H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.State AS SState,H.Zip+'-'+H.ZipPlus4 AS SZipPlus4,Changed the zip format PI-350
H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.Abreviation AS SState,H.ZipPlus4 AS SZipPlus4,
C.OutOfStateInd,
--PSS055 PROVIDER DETAIL SCREEN
A.ApplicationDate,
A.ProviderType AS ProviderTypeDETAIL,
C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,


A.StatusAcc,
A.StatusBeginDate,
C.RejectReasonCode,
--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
--I.CodeIdentification AS CodeIdentificationCateg,
--I.CodeDateEffDate,
--I.CodeDateExpDate,
J.Number,
J.EffectiveDate, --as LIC_EFF_DT,
K.CliaNumber, --as CLIA_NO,
C.SpecProcTypeCode, --as SPEC_PROC_TYP,
C.CHDPCode as CHDPCode, /*Added for CHDP Code*/
C.ProvisionalCode,
C.ProvisionalCodeDate,
A.ReenrollmentIndicator,
CONVERT(varchar(10),A.ReenrollmentDate,101) as ReEnrollDate,
--PSS038 PHYSICIAN CERTIFICATION
L.Speciality_Code,
Case when(A.AccountType='G') then
'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
ELSE 
'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
END AS GRPIDTY,

--C.LabSpecCode+ '-'+C.LabSpecCodeDesc AS LABStat, Since we are storing data in LabStatusCode not in LabSpecCode hence chaged.
C.LabStatusCode AS LABStat,

--C.LabSpecCodeEfDate as LABEFFDT,Since we are storing data in LabStatusCodeDate not in LabStatusCodeDate hence chaged.
convert(varchar(10),C.LabStatusCodeDate,101) as LABEFFDT,
A.AccountNumber
,Z.ProfileID As ProfileID
 






 from KYPEnrollment.pADM_Account A 
  left join
  (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('ReviewerS','Reviewer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U1 on U1.AccountID=A.AccountID 
   
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('SupervisorR','SupervisorS'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U2 on U2.AccountID=A.AccountID
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('ConfirmerS','Confirmer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U3 on U3.AccountID=A.AccountID
 
LEFT OUTER JOIN 
KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
LEFT OUTER JOIN
KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID --and C.CurrentRecordFlag = 1 Reomved since protal data was not setting.
LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 

--This is for Service Address Details	 
left outer join 	 
	(select H.AddressLine1,H.AddressLine2,H.City,LS.Abreviation,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County  from KYPEnrollment.pAccount_PDM_Address H 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on H.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1
	 Left join kyp.LK_Screening LS on H.State=LS.Description
	 )H
	 on H.PartyID = a.PartyID 
--This is for Mailing Address Details
left outer join(select G.AddressLine1,G.AddressLine2,G.City,LS.Abreviation,G.Zip,G.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address G
inner join KYPEnrollment.pAccount_PDM_Location X
	 on G.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1
	 Left join kyp.LK_Screening LS on G.State=LS.Description
	 )G
	 on G.PartyID = a.PartyID	 
	 
	 
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address F ON F.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Pay-to' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address G ON G.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Mailing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address H ON H.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Servicing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.EDM_AccountInternalMany I ON I.AccountInternalUseID=C.AccountInternalUseID AND C.AccountID=A.AccountID AND I.CodeType = 'Category'

--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Number J ON J.PartyID=A.PartyID AND J.Type='Professional License' AND J.CurrentRecordFlag=1
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
/*Added to fix 2 license problem for one account*/

LEFT  OUTER JOIN (select T1.PartyID,T1.Number,T1.EffectiveDate
					FROM KYPEnrollment.pAccount_PDM_Number T1
					Join (select MAX(NumberID) NumberID
						from KYPEnrollment.pAccount_PDM_Number
						where Type='Professional License' AND CurrentRecordFlag=1
						group by PartyID) T2 on T1.NumberID=T2.NumberID) J ON J.PartyID=A.PartyID 
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
/*Added to fix 2 license problem for one account*/




LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Speciality L ON L.PartyID=A.PartyID and  L.IsPrimary=NULL and L.CurrentRecordFlag=1
--LEFT  OUTER JOIN KYPEnrollment.pAccount_RenderingAffiliation M ON M.AccountID=A.AccountID and A.AccountType='NMP'
LEFT  OUTER JOIN KYPEnrollment.pADM_AccountStatus N ON N.AccountID=A.AccountID and N.CurrentRecordFlag=1
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID

)x
left join (
select AccountID, SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3

  from(    
   
   -- DH-SANCTION-TXT-2019 occurs 8 times
                -- 8 Occurance for 'CodeIdentification' from "KYPEnrollment.EDM_AccountInternalMany" table where CodeType = 'Sanction'
      --SELECT C.AccountId, CONVERT(varchar(20),(case when CodeIdentification = 'other' then left(CodeDescription,5) end)) as CodeIdentification /*Changed for (Sanctions)Others as per new logic*/
      SELECT C.AccountId, CONVERT(varchar(20),(case when CodeIdentification = 'other' then left(UPPER(CodeDescription),5) else CodeIdentification end)) as CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
    inner join KYPEnrollment.EDM_AccountInternalUse C 
    on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
    where AccountID=@acc_party_id
    
    
      UNION All	
	SELECT A.Accountid,CONVERT(varchar(20), P.PhyCertCode)
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by PhyCertCode  desc  ) ) 
	seq
	FROM KYPEnrollment.EDM_AccountInternalUse P 
	inner join KYPEnrollment.pADM_Account A  on P.AccountID=A.AccountID --And P.Type='Specialty Code'
	 where A.AccountID=@acc_party_id
	UNION ALL 
	
	SELECT A.Accountid,CONVERT(varchar(20), P.PhyCertCodeEfDate)
	,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  PhyCertCodeEfDate desc) ) seq
	FROM KYPEnrollment.EDM_AccountInternalUse P 
	inner join KYPEnrollment.pADM_Account A  on P.AccountID=A.AccountID 
	where A.AccountID=@acc_party_id
	
	
		
       )ML(AccountId,StatusValue,seq)

PIVOT (max(ml.StatusValue)  
	 FOR ml.seq IN (SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
)) pvt 

where AccountId=@acc_party_id
  )y
on x.AccountID= y.AccountId
where x.AccountID=@acc_party_id

End


GO

