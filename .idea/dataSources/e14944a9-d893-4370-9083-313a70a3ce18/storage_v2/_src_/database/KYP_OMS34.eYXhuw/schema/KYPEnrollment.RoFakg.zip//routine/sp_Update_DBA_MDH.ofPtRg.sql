
/* ==========================================================
-- Author	:	rolguin
-- DATE		:	5/3/2018
-- PROCEDURE: 	update the pAccount_PDM_ProviderQuestionnarie table within to the DBA radio button
-- 				this procedure used will fix about the Legacy account that manage the DBA field
-- PARAMETERS:
-- @portal_party_id 	: partyID that from application Portal MD
-- @acc_party_Id 		: partyID to new Account that will be create.
-- @application_Id 		: ApplicationID that will be Account.
-- RELEASE: 2.0
--
-- IMPORTANT NOTE	: 	you need execute again the procedures 
-- 						because was added within that file
-- ============================================================*/
CREATE PROCEDURE [KYPEnrollment].[sp_Update_DBA_MDH]
    @portal_party_id  INT,
    @acc_party_Id     INT,
	@application_Id     INT
AS
  BEGIN

    DECLARE @npiType VARCHAR(200);
    DECLARE @new_value_text VARCHAR(20);
    DECLARE @isOrganization INT;
	
	SELECT @npiType = NpiType FROM KYPPORTAL.PortalKYP.pADM_Application WHERE  ApplicationID = @application_Id;
	
	
	SELECT @isOrganization = CASE 
		WHEN @npiType = 'Organization' THEN 1
		ELSE 0
	END	

	IF @isOrganization = 1                                             
	BEGIN
		IF NOT EXISTS (SELECT * FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] WHERE PartyID = @acc_party_Id and Name = 'hasFictBusinessName' and Type = 'radio')
		BEGIN 
			INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] ( [PartyID],[Type],[Name],[Value],[CurrentRecordFlag],[IsDeleted])
			SELECT @acc_party_Id,[Type],[Name],[Value],1,[IsDeleted]
			FROM KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie WHERE PartyID = @portal_party_id and name = 'hasFictBusinessName' and Type = 'radio'
		END	
		ELSE
		BEGIN	
			IF EXISTS (SELECT * FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] WHERE PartyID = @acc_party_Id and Name = 'hasFictBusinessName' and Type = 'radio')
			BEGIN 
				SELECT @new_value_text = Value
				FROM KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie 
				WHERE PartyID = @portal_party_id and name = 'hasFictBusinessName' and Type = 'radio'
				
				UPDATE [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie]
				SET value = @new_value_text
				WHERE PartyID = @acc_party_Id and Name = 'hasFictBusinessName' and Type = 'radio'
			END	
		END
	END 
END


GO

