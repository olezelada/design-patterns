

CREATE PROCEDURE [KYP].[p_UpdatePDMPerson] (
	@PartyID INT
	,@PersonNumber VARCHAR(25) = NULL
	,@PersonCategory VARCHAR(25) = NULL
	,@SSN VARCHAR(11) = NULL
	,@Salunation VARCHAR(25) = NULL
	,@FirstName VARCHAR(25) = NULL
	,@LastName VARCHAR(25) = NULL
	,@MiddleName VARCHAR(25) = NULL
	,@Gender VARCHAR(11) = NULL
	,@DoB VARCHAR(10) = NULL
	,@DoD DATETIME = NULL
	,@NPI INT = NULL
	,@Email1 VARCHAR(50) = NULL
	,@Phone1 VARCHAR(15) = NULL
	,@Email2 VARCHAR(50) = NULL
	,@Phone2 VARCHAR(50) = NULL
	,@Alias1 VARCHAR(15) = NULL
	,@Alias2 VARCHAR(15) = NULL
	,@CityofBirth VARCHAR(25) = NULL
	,@StateofBirth VARCHAR(25) = NULL
	,@CountyofBirth VARCHAR(25) = NULL
	,@Ethnicity VARCHAR(50) = NULL
	,@Remark VARCHAR(250) = NULL
	,@CurrentModule SMALLINT = NULL
	,@DateCreated DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified DATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted DATETIME = NULL
	,@TaxId varchar(9)=NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF ISNULL(@DoD, '') = ''
	BEGIN
		SET @DoD = NULL;
	END

	IF ISNULL(@NPI, '') = ''
	BEGIN
		SET @NPI = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@PersonNumber, '')))) = ''
	BEGIN
		SET @PersonNumber = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@PersonCategory, '')))) = ''
	BEGIN
		SET @PersonCategory = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@SSN, '')))) = ''
	BEGIN
		SET @SSN = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Salunation, '')))) = ''
	BEGIN
		SET @Salunation = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@FirstName, '')))) = ''
	BEGIN
		SET @FirstName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@LastName, '')))) = ''
	BEGIN
		SET @LastName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@MiddleName, '')))) = ''
	BEGIN
		SET @MiddleName = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Gender, '')))) = ''
	BEGIN
		SET @Gender = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@DoB, '')))) = ''
	BEGIN
		SET @DoB = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Email1, '')))) = ''
	BEGIN
		SET @Email1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone1, '')))) = ''
	BEGIN
		SET @Phone1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Email2, '')))) = ''
	BEGIN
		SET @Email2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Phone2, '')))) = ''
	BEGIN
		SET @Phone2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Alias1, '')))) = ''
	BEGIN
		SET @Alias1 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Alias2, '')))) = ''
	BEGIN
		SET @Alias2 = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@CityofBirth, '')))) = ''
	BEGIN
		SET @CityofBirth = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@StateofBirth, '')))) = ''
	BEGIN
		SET @StateofBirth = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@CountyofBirth, '')))) = ''
	BEGIN
		SET @CountyofBirth = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Ethnicity, '')))) = ''
	BEGIN
		SET @Ethnicity = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remark, '')))) = ''
	BEGIN
		SET @Remark = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END
	
	IF ISNULL(@TaxId, '') = ''
	BEGIN
		SET @TaxId = NULL;
	END
	
	

	DECLARE @DoBCorrected DATETIME

	BEGIN TRY
		SELECT @DoBCorrected = convert(DATETIME, @DoB, 121)
	END TRY

	BEGIN CATCH
		SELECT @DoBCorrected = NULL
	END CATCH

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_Person] Set '

	IF @PersonNumber IS NOT NULL
		SET @updatelist = '[PersonNumber] = ''' + @PersonNumber + ''''

	IF @PersonCategory IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PersonCategory] = ''' + replace(@PersonCategory, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[PersonCategory] = ''' + replace(@PersonCategory, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @SSN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[SSN] = ''' + replace(@SSN, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[SSN] = ''' + replace(@SSN, '''', CHAR(39) + CHAR(39)) + ''''
	END
	
	IF @TaxId IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[TaxId] = ''' + replace(@TaxId, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[TaxId] = ''' + replace(@TaxId, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Salunation IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Salunation] = ''' + replace(@Salunation, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Salunation] = ''' + replace(@Salunation, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @FirstName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[FirstName] = ''' + replace(@FirstName, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[FirstName] = ''' + replace(@FirstName, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @LastName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LastName] = ''' + replace(@LastName, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LastName] = ''' + replace(@LastName, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @MiddleName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[MiddleName] = ''' + replace(@MiddleName, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[MiddleName] = ''' + replace(@MiddleName, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Gender IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Gender] = ''' + replace(@Gender, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Gender] = ''' + replace(@Gender, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DoBCorrected IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DoB] = ''' + convert(VARCHAR(25), @DoBCorrected, 110) + ''''
		ELSE
			SET @updatelist = '[DoB] = ''' + convert(VARCHAR(25), @DoBCorrected, 110) + ''''
	END

	IF @DoD IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DoD] = ''' + convert(VARCHAR(25), @DoD, 110) + ''''
		ELSE
			SET @updatelist = '[DoD] = ''' + convert(VARCHAR(25), @DoD, 110) + ''''
	END

	IF @NPI IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[NPI] = ' + Convert(VARCHAR(12), @NPI)
		ELSE
			SET @updatelist = '[NPI] = ' + Convert(VARCHAR(12), @NPI)
	END

	IF @Email1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Email1] = ''' + replace(@Email1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Email1] = ''' + replace(@Email1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone1] = ''' + replace(@Phone1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Email2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Email2] = ''' + replace(@Email2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Email2] = ''' + replace(@Email2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Phone2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Phone2] = ''' + replace(@Phone2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Phone2] = ''' + replace(@Phone2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Alias1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Alias1] = ''' + replace(@Alias1, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Alias1] = ''' + replace(@Alias1, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Alias2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Alias2] = ''' + replace(@Alias2, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Alias2] = ''' + replace(@Alias2, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @CityofBirth IS NOT NULL
	BEGIN
		IF @CityofBirth IS NOT NULL
			SET @updatelist = @updatelist + ',[CityofBirth] = ''' + replace(@CityofBirth, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[CityofBirth] = ''' + replace(@CityofBirth, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @StateofBirth IS NOT NULL
	BEGIN
		IF @StateofBirth IS NOT NULL
			SET @updatelist = @updatelist + ',[StateofBirth] = ''' + replace(@StateofBirth, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[StateofBirth] = ''' + replace(@StateofBirth, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @CountyofBirth IS NOT NULL
	BEGIN
		IF @CountyofBirth IS NOT NULL
			SET @updatelist = @updatelist + ',[CountyofBirth] = ''' + replace(@CountyofBirth, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[CountyofBirth] = ''' + replace(@CountyofBirth, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Ethnicity IS NOT NULL
	BEGIN
		IF @Ethnicity IS NOT NULL
			SET @updatelist = @updatelist + ',[Ethnicity] = ''' + replace(@Ethnicity, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Ethnicity] = ''' + replace(@Ethnicity, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Remark IS NOT NULL
	BEGIN
		IF @Remark IS NOT NULL
			SET @updatelist = @updatelist + ',[Remark] = ''' + replace(@Remark, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remark] = ''' + replace(@Remark, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

