

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[InsertUsers] ON [dbo].[USERTABLE]
AFTER INSERT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for trigger here
	DECLARE @UserID VARCHAR(200),
		@PersonID INT;

	SELECT @UserID = [USER_NAME]
	FROM inserted

	SELECT @PersonID = PersonID FROM KYP.OIS_User WITH(NOLOCK) WHERE UserID = @UserID	

	--ALTER TABLE KYP.OIS_User DISABLE TRIGGER UpdateUserDetails
	
	UPDATE KYP.OIS_User
	SET ACTIVE = 1
	,Row_Updation_Source = 'dbo.UserTable.InsertUsers'
	WHERE UserID = @UserID
	
	UPDATE KYP.OIS_Person
	SET Deleted = 0
	WHERE PersonID = @PersonID
	
	--ALTER TABLE KYP.OIS_User ENABLE TRIGGER UpdateUserDetails
END


GO

