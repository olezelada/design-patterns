

CREATE PROCEDURE [KYPEnrollment].[Update_All_Account_NewModel](
  @account_id INT,
  @party_id_account INT,
  @tax_id VARCHAR(100),
  @application_id INT,
  @party_id_app INT,
  @last_Action_User_ID VARCHAR(100),
  @accepted BIT,
  @application_type VARCHAR(50) = NULL
)
AS
BEGIN
	DECLARE @supUpdateFlag VARCHAR(10), @profId VARCHAR(100)
	SELECT @supUpdateFlag = cass.SupUpdateFlag FROM KYP.ADM_Case cass inner join KYPEnrollment.pADM_Account acc
	on cass.Number=acc.ApplicationNumber AND acc.AccountID = @account_id

	SELECT @profId = ProfileID FROM KYPEnrollment.pAccount_BizProfile_Details WHERE AccountID = @account_id
	
	DECLARE @date_Create DATE
	SET @date_Create = GETDATE()
	
--++
    -- date submitted
    declare @datesubmit smalldatetime
	SELECT  top 1 @datesubmit=tra.DateTracking 
	FROM KYPPORTAL.PortalKYP.pADM_Application ap
	INNER JOIN kypportal.PortalKYP.pApplicationHistoryTracking tra ON  ap.applicationNo = tra.applicationNumber  
	where 
	tra.applicationMilestone = 'Submitted'  and ap.PartyID = @party_id_app
	order by tra.DateTracking desc
	  
  --++
	CREATE TABLE #FieldTrakingByParty  (ID INT IDENTITY(1,1),
	FieldValueID INT,EntityID INT,TableCode VARCHAR(20),AccTableName VARCHAR(100),AccPK VARCHAR(100),AccPKValue INT,ActionTaken VARCHAR(50),
	EnDbColumn VARCHAR(100),TrackingTargetPath VARCHAR(200),CurrentValueInt INT, NewValueInt INT, TargetPath VARCHAR(200));
	 
	 IF (@application_type is not  NULL  AND (@application_type IN ('CHOA','CHOW','Disenrollment','Disaffiliation','Supplemental','Revalidation','Reenrollment')))
	  BEGIN
		set @accepted=1;
	  END
	  ELSE
	  BEGIN
		set @accepted=0;
	  END
	INSERT INTO #FieldTrakingByParty 
	SELECT tracking.FieldValueID,tracking.EntityID,tracking.TableCode,tracking.AccTableName,tracking.AccPK,tracking.AccPKValue,
	tracking.ActionTaken,tracking.EnDbColumn,tracking.TargetPath, tracking.CurrentValueInt, tracking.NewValueInt, tracking.TargetPath
	FROM [KYPPORTAL].PortalKYP.FieldValuesTracking tracking 
	WHERE tracking.ApplicationID=@application_id AND (tracking.TableCode IN ('subcontractorTable','ownerTable','sigTransTable',
	'licenseActions','settlementTable',
	'licenseActions','convictedTable','liableTable','suspendedTable','ownerSubAssocTable','individualSubTable',
	'otherAssocTable','otherEntAssocTable',
	'selfPartTable','subOwnerTable','entitySubTable','assoSubIndTable','assoSubOwnerTable','assoSubOwnerTable','significantSubTable','whollySuppliersTable','signOwnerTable'))  and sectionnanme<>'Disclosure Information' and sectionnanme<>'Disclosure Information' and
	sectionnanme<>'Contract/Program Actions' and sectionnanme<>'Medicaid/Medicare Participation'
	AND Accepted = @accepted
	
	 DECLARE @partyTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT,TableCode VARCHAR(20), TrackingTargetPath VARCHAR(200), AccTableName VARCHAR(200), AccPKValue INT)
	 
	 DECLARE @count_party_Id INT,@top_PartyId INT, @partyIdUpdate INT, @typedUpdate VARCHAR(20)
	 
		
	   INSERT INTO  @partyTraking SELECT DISTINCT PartyID,NULL,NULL,NULL,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath))  
	   FROM kypportal.portalkyp.pPDM_Party part WHERE (ParentPartyID= @party_id_app or 
		 ParentPartyID in (select PartyID from kypportal.portalkyp.pPDM_Party where ParentPartyID=@party_id_app) )
			AND Type IN ('SubcontractorEntity','SubcontractorIndividual','TransactionEntity','TransactionIndividual',
			'SubcontractorOwnerIndividual','SubcontractorOwnerEntity','OtherOwnershipIndividual','OtherOwnershipEntity','WhollyOwnedSupplied', 'SignificantOwnerIndividual', 'SignificantTransactionIndividual', 'SignificantTransactionEntity', 'SignificantOwnerEntity')
			and isnull(IsDeleted,0)=0 	and IsPrepopulated=1					
		
		INSERT INTO  @partyTraking SELECT DISTINCT case when tablecode='subOwnerTable' then NULL ELSE EntityID END, TableCode, TrackingTargetPath, AccTableName, AccPKValue FROM #FieldTrakingByParty 
		WHERE AccTableName='pAccount_PDM_Party'  and (ActionTaken ='Deleted') 
		AND (TableCode IN ('subcontractorTable','sigTransTable','subOwnerTable','whollySuppliersTable', 'signOwnerTable','significantSubTable'))
		
		--for delete			
		
		--delete party
		
		
BEGIN TRY		
		
		
		UPDATE KYPEnrollment.pAccount_PDM_Party SET CurrentRecordFlag=0,LastAction='D',MOCARelationshipEndDate=@datesubmit WHERE PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )
		AND Type in ('SubcontractorEntity','SubcontractorIndividual','TransactionEntity','TransactionIndividual','SubcontractorOwnerIndividual','SubcontractorOwnerEntity','WhollyOwnedSupplied', 'SignificantOwnerIndividual', 'SignificantTransactionIndividual', 'SignificantTransactionEntity', 'SignificantOwnerEntity')
	
	    --Delete Address/location
	
		UPDATE addr SET 
		CurrentRecordFlag = 0 ,LastAction='D'
		FROM 
		[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
		where
		loc.partyid in (select accpkvalue from  @partyTraking where EntityPartyID is null  )
	
		UPDATE loc SET 
		CurrentRecordFlag = 0 ,isdeleted=1,LastAction='D'
		FROM 
		[KYPEnrollment].[pAccount_PDM_Location] loc 
		where
		loc.partyid in (select accpkvalue from  @partyTraking where EntityPartyID is null  )
	
       --Delete Person
		
		UPDATE person SET
		CurrentRecordFlag = 0,LastAction='D'
		FROM [KYPEnrollment].[pAccount_PDM_Person] person 
		WHERE person.PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )
	  
	   --Delete Organization
		UPDATE org SET
		CurrentRecordFlag = 0, LastAction='D'
		FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
		WHERE org.PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )

		--Delete Owner Role
		UPDATE ownerRole SET
		CurrentRecordFlag = 0 , LastAction='D'
		FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole 
		WHERE ownerRole.PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )

		-- Delete Owner Transaction
		UPDATE ownerTransaction SET
		CurrentRecordFlag = 0, LastAction='D'
		FROM [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction] ownerTransaction 
		WHERE ownerTransaction.PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )

		--Delete provider Questionnaire

		UPDATE providerq SET
		CurrentRecordFlag = 0,LastAction='D'
		FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] providerq
		WHERE providerq.PartyID in (select accpkvalue from  @partyTraking where EntityPartyID is null  )
		
		--For update
		--Update address
		--select entitypartyid from @partyTraking where EntityPartyID is not null
		
		DECLARE @Address_Table TABLE (ID INT IDENTITY(1,1),MainPartyID INT, PartyID INT,AddressID INT,LocationID INT,AddressLine1 VARCHAR(250),AddressLine2 VARCHAR(50),County VARCHAR(25),City VARCHAR(25),ZipPlus4 VARCHAR(50),State VARCHAR(40), CurrentRecordFlag BIT)
	    INSERT INTO @Address_Table SELECT 
	    SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll,
	    loc.PartyID,addres.AddressID, loc.LocationID, addres.AddressLine1, addres.AddressLine2, addres.County, addres.City, addres.ZipPlus4, addres.State,1
	    FROM  kypportal.portalkyp.ppdm_Address addres, kypportal.portalkyp.pPDM_Location loc, kypportal.portalkyp.pPDM_Party part
	    WHERE addres.AddressID = loc.AddressID and loc.IsDeleted=0 and loc.PartyID = part.PartyID  and part.partyid in (select entitypartyid from @partyTraking where EntityPartyID is not null)
        
        UPDATE addr SET 
		AddressLine1 = addtable.AddressLine1, AddressLine2 = addTable.AddressLine2, City = addTable.City, County = addTable.County,
		State = addTable.State, ZipPlus4 = addTable.ZipPlus4, CurrentRecordFlag = 1 ,LastAction='U'
		FROM 
		[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
		LEFT JOIN @Address_Table addTable ON loc.PartyID = addTable.MainPartyID
	    WHERE loc.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )
		
		
		/*  Update Person	*/
		DECLARE @Person_Table TABLE(ID INT IDENTITY(1,1),PersonID INT,MainPartyID INT,PartyID INT,SSN VARCHAR(11),FirstName VARCHAR(25),LastName VARCHAR(25),MiddleName VARCHAR(25),DoB DATETIME, CurrentRecordFlag BIT,phone1 varchar(15))
		INSERT INTO @Person_Table SELECT person.PersonID,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll ,person.PartyID, person.SSN, person.FirstName, person.LastName, person.MiddleName, person.DoB, 1,phone1
		FROM kypportal.portalkyp.pPDM_Person person, kypportal.portalkyp.pPDM_Party part
		WHERE person.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partyTraking where EntityPartyID is not null)
		
		UPDATE person SET
		SSN = personTable.SSN, FirstName = personTable.FirstName, LastName = personTable.LastName, 
		MiddleName = personTable.MiddleName, DoB= personTable.DoB, CurrentRecordFlag = 1,LastAction='U',phone1=persontable.phone1
		FROM [KYPEnrollment].[pAccount_PDM_Person] person 
		LEFT JOIN @Person_Table personTable ON person.partyid = personTable.MainPartyID 
		WHERE person.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )

		/*  Update Organization	*/
		DECLARE @Organization_Table TABLE(ID INT IDENTITY(1,1),OrgID INT ,MainPartyID INT,PartyID INT,LegalName VARCHAR(100),DBAName1 VARCHAR(MAX),Phone1 VARCHAR(15),
		Remarks VARCHAR(25),NPI VARCHAR(10),EIN VARCHAR(30),IsCorporation BIT,Extension VARCHAR(12),BusinessName VARCHAR(200), CurrentRecordFlag BIT,orgnumber varchar(25))
		INSERT INTO @Organization_Table SELECT org.OrgID, SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll, org.PartyID, org.LegalName, org.DBAName1, org.Phone1, 
		org.Remarks, org.NPI, org.EIN, org.IsCorporation, org.Extension, org.BusinessName, 1,orgnumber
		FROM kypportal.portalkyp.pPDM_Organization org, kypportal.portalkyp.pPDM_Party part 
		WHERE org.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partyTraking where EntityPartyID is not null)
			
		UPDATE org SET
		LegalName = orgTable.LegalName, DBAName1 = orgTable.DBAName1, Phone1 = orgTable.Phone1, Remarks = orgTable.Remarks, NPI = orgTable.NPI,
		EIN = orgTable.EIN, IsCorporation = orgTable.IsCorporation, Extension = orgTable.Extension, BusinessName = orgTable.BusinessName, 
		CurrentRecordFlag = 1, LastAction='U',orgnumber=orgtable.orgnumber
		FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
		LEFT JOIN @Organization_Table orgTable ON ORG.PartyID = orgTable.MainPartyID
		WHERE org.PartyID IN (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )
	
		/*  Update Owner Role 	*/
		
		DECLARE @OwnerRole_Table TABLE(ID INT IDENTITY(1,1),PdmOwnerID INT,MainPartyID INT, PartyID INT ,TypeForm VARCHAR(100),PercentCheck BIT,PercentValue VARCHAR(150),
		Partner BIT,PartnerValue VARCHAR(150),Managing BIT,Director BIT,DirectorValue VARCHAR(150),Other BIT,OtherValue VARCHAR(150),
		PercentDate SMALLDATETIME,PartnerDate SMALLDATETIME,ManagingDate SMALLDATETIME,OtherDate SMALLDATETIME,Agent BIT,OwnerRelationID INT,SoleOwner BIT, CurrentRecordFlag BIT,
		OtherDateRole smalldatetime, LessPercent bit,  BoardMember bit, BoardMemberDate smalldatetime, IsOwner VARCHAR(10))
		
		INSERT INTO @OwnerRole_Table SELECT ownerRole.PdmOwnerID,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll , ownerRole.PartyID, ownerRole.TypeForm, ownerRole.PercentCheck, ownerRole.PercentValue,
		ownerRole.Partner, ownerRole.PartnerValue, ownerRole.Managing, ownerRole.Director, ownerRole.DirectorValue, ownerRole.Other,ownerRole.OtherValue,
		ownerRole.PercentDate, ownerRole.PartnerDate, ownerRole.ManagingDate, ownerRole.OtherDate, ownerRole.Agent, ownerRole.OwnerRelationID,ownerRole.SoleOwner, 1,OtherDateRole, LessPercent, BoardMember, BoardMemberDate, ownerRole.IsOwner
		FROM kypportal.portalkyp.pPDM_Owner_Role ownerRole, kypportal.portalkyp.pPDM_Party part 
		WHERE ownerRole.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partyTraking where EntityPartyID is not null)
	

		UPDATE ownerRole SET
		TypeForm = ownerTable.TypeForm, PercentCheck = ownerTable.PercentCheck, PercentValue = ownerTable.PercentValue, Partner = ownerTable.Partner,
		PartnerValue = ownerTable.PartnerValue, Managing = ownerTable.Managing, Director = ownerTable.Director, DirectorValue =ownerTable.DirectorValue,
		Other = ownerTable.Other, OtherValue = ownerTable.OtherValue,PercentDate = ownerTable.PercentDate, PartnerDate = ownerTable.PartnerDate, 
		ManagingDate = ownerTable.ManagingDate, OtherDate = ownerTable.OtherDate,Agent = ownerTable.Agent, OwnerRelationID = ownerTable.OwnerRelationID, 
		SoleOwner = ownerTable.SoleOwner,CurrentRecordFlag = 1 , LastAction='U',OtherDateRole=ownertable.otherdaterole, LessPercent=ownertable.lesspercent,
        BoardMember=ownertable.boardmember,  BoardMemberDate=ownertable.boardmemberdate, IsOwner = ownerTable.IsOwner
		FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole 
		LEFT JOIN @OwnerRole_Table ownerTable ON ownerrole.PartyID = ownerTable.MainPartyID
		WHERE ownerRole.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )


		/*  Update Owner Transaction	*/
		DECLARE @transaction_Table TABLE(ID INT IDENTITY(1,1),TransactionID INT,MainPartyID INT, PartyID INT,Description VARCHAR(150),Amount VARCHAR(10), CurrentRecordFlag BIT)
		INSERT INTO @transaction_Table SELECT ownerTransaction.TransactionID, SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll, ownerTransaction.PartyID, ownerTransaction.Description, ownerTransaction.Amount, 1
		FROM kypportal.portalkyp.ppdM_OwnerhipTransaction ownerTransaction, kypportal.portalkyp.pPDM_Party part 
		WHERE ownerTransaction.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partyTraking where EntityPartyID is not null)
		
		UPDATE ownerTransaction SET
		Description = transactionTable.Description, Amount = transactionTable.Amount,CurrentRecordFlag = 1, LastAction='U'
		FROM [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction] ownerTransaction 
		LEFT JOIN @transaction_Table transactionTable ON ownertransaction.partyid = transactionTable.MainPartyID
		WHERE ownerTransaction.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )


		/*  Update provider questionnaire	*/
		DECLARE @ProviderQuestionnarie_table TABLE(ID INT IDENTITY(1,1),QuestionID INT,MainPartyID INT,PartyID INT,Type VARCHAR(50),Name VARCHAR(100),Value VARCHAR(100),Description VARCHAR(500), CurrentRecordFlag BIT)
		INSERT INTO @ProviderQuestionnarie_table SELECT providerq.QuestionID, SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll ,providerq.PartyID, providerq.Type, providerq.Name, providerq.Value, providerq.Description, 1
		FROM KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie providerq, KYPPORTAL.PortalKYP.pPDM_Party part
		WHERE providerq.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partyTraking where EntityPartyID is not null)

		UPDATE providerq SET
		Type = privderqTable.Type, Name = privderqTable.Name, Value = privderqTable.Value,
		Description = privderqTable.Description, CurrentRecordFlag = 1, LastAction='U'
		FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] providerq
		LEFT JOIN @ProviderQuestionnarie_table privderqTable ON providerq.partyid = privderqTable.MainPartyID and providerq.Name = privderqTable.Name
		WHERE providerq.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )

    /*Here relationship of entity subcontractor are deleting when checkbox of subcontractor changed from by moca to by applicant*/
    UPDATE relation
		  SET relation.LastAction = 'D'
			   , relation.LastActionDate = GETDATE()
			   , relation.CurrentRecordFlag = 0
		FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] relation
			LEFT JOIN [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] providerq on providerq.PartyID = relation.PartyIDOwned AND providerq.Name LIKE '%ApplicantSubcontractor%' AND providerq.Value LIKE '%true%'
			LEFT JOIN @ProviderQuestionnarie_table privderqTable ON providerq.partyid = privderqTable.MainPartyID and providerq.Name = privderqTable.Name
		WHERE providerq.PartyID in (SELECT AccPKValue FROM @partyTraking where EntityPartyID is not null )
			AND relation.CurrentRecordFlag = 1
			AND relation.TypeAssociation = 'SubcontractorEntityAssociation'
			AND NOT EXISTS(SELECT *
							FROM [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie]
							WHERE Name LIKE '%OwnerSubcontractor%'
								AND Value LIKE '%true%'
								AND PartyID = providerq.PartyID)
			
		--********* ownerships *********
	 
	
	
	 DECLARE @partyMocaTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT,AccPKValue int )
     --mvc 3.0
     
       INSERT INTO  @partyMocaTraking SELECT DISTINCT partyid,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath))  
	   FROM kypportal.portalkyp.pPDM_Party part WHERE ParentPartyID= @party_id_app
			AND Type IN ('Entity Ownership','Individual Ownership')
			and isnull(IsDeleted,0)=0 	and IsPrepopulated=1	
			
	   
	 
	 -- For update ownerships 
	 print 'Update Ownerships'
	
	
	 --***
	DECLARE @Address_Table1 TABLE (ID INT IDENTITY(1,1),MainPartyID INT, PartyID INT,AddressID INT,LocationID INT,AddressLine1 VARCHAR(250),AddressLine2 VARCHAR(50),County VARCHAR(25),City VARCHAR(25),ZipPlus4 VARCHAR(50),State VARCHAR(40), CurrentRecordFlag BIT)
	INSERT INTO @Address_Table1 SELECT 
	SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll,
	loc.PartyID,addres.AddressID, loc.LocationID, addres.AddressLine1, addres.AddressLine2, addres.County, addres.City, addres.ZipPlus4, addres.State,1
	FROM  kypportal.portalkyp.ppdm_Address addres, kypportal.portalkyp.pPDM_Location loc, kypportal.portalkyp.pPDM_Party part
	WHERE addres.AddressID = loc.AddressID and loc.IsDeleted=0 and loc.PartyID = part.PartyID  and part.partyid in (select entitypartyid from @partymocaTraking )
        
    UPDATE addr SET 
	AddressLine1 = addtable.AddressLine1, AddressLine2 = addTable.AddressLine2, City = addTable.City, County = addTable.County,
	State = addTable.State, ZipPlus4 = addTable.ZipPlus4, CurrentRecordFlag = 1 ,LastAction='U'
	FROM 
	[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
	LEFT JOIN @Address_Table1 addTable ON loc.PartyID = addTable.MainPartyID
	 WHERE loc.PartyID in (SELECT AccPKValue FROM @partymocaTraking  )
	
	
	/*  
			Update Person
	*/
	
	DECLARE @Person_Table1 TABLE(ID INT IDENTITY(1,1),PersonID INT,MainPartyID INT,PartyID INT,SSN VARCHAR(11),FirstName VARCHAR(25),LastName VARCHAR(25),MiddleName VARCHAR(25),DoB DATETIME, CurrentRecordFlag BIT, phone1  varchar(15))
	INSERT INTO @Person_Table1 SELECT person.PersonID,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll ,person.PartyID, person.SSN, person.FirstName, person.LastName, person.MiddleName, person.DoB, 1,person.phone1
	FROM kypportal.portalkyp.pPDM_Person person, kypportal.portalkyp.pPDM_Party part
	WHERE person.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partymocaTraking )
		
	UPDATE person SET
	SSN = personTable.SSN, FirstName = personTable.FirstName, LastName = personTable.LastName, 
	MiddleName = personTable.MiddleName, DoB= personTable.DoB, CurrentRecordFlag = 1,LastAction='U',phone1=persontable.phone1
	FROM [KYPEnrollment].[pAccount_PDM_Person] person 
	LEFT JOIN @Person_Table1 personTable ON person.partyid = personTable.MainPartyID 
	WHERE person.PartyID in (SELECT AccPKValue FROM @partymocaTraking  )
	
	/*  
			Update Organization
	*/
	
	DECLARE @Organization_Table1 TABLE(ID INT IDENTITY(1,1),OrgID INT ,MainPartyID INT,PartyID INT,LegalName VARCHAR(100),DBAName1 VARCHAR(MAX),Phone1 VARCHAR(15),
	Remarks VARCHAR(25),NPI VARCHAR(10),EIN VARCHAR(30),IsCorporation BIT,Extension VARCHAR(12),BusinessName VARCHAR(200), CurrentRecordFlag BIT,orgnumber  varchar(25))
	INSERT INTO @Organization_Table1 SELECT org.OrgID, SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll, org.PartyID, org.LegalName, org.DBAName1, org.Phone1, 
	org.Remarks, org.NPI, org.EIN, org.IsCorporation, org.Extension, org.BusinessName, 1,org.orgnumber
	FROM kypportal.portalkyp.pPDM_Organization org, kypportal.portalkyp.pPDM_Party part 
	WHERE org.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partymocaTraking )
			
	UPDATE org SET
	LegalName = orgTable.LegalName, DBAName1 = orgTable.DBAName1, Phone1 = orgTable.Phone1, Remarks = orgTable.Remarks, NPI = orgTable.NPI,
	EIN = orgTable.EIN, IsCorporation = orgTable.IsCorporation, Extension = orgTable.Extension, BusinessName = orgTable.BusinessName, 
	CurrentRecordFlag = 1, LastAction='U',orgnumber=orgtable.orgnumber
	FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
	LEFT JOIN @Organization_Table1 orgTable ON ORG.PartyID = orgTable.MainPartyID
	WHERE org.PartyID IN (SELECT AccPKValue FROM @partymocaTraking  )

  -- update document

  DECLARE @documentTable TABLE(ID INT IDENTITY(1,1), DocumentID INT, MainPartyID INT, PartyID INT, TypeDoc VARCHAR(40), NumberDoc VARCHAR(16), IsStateIssued BIT, StateIssued VARCHAR(40))
  INSERT INTO @documentTable
  SELECT document.DocumentID, SUBSTRING ( party.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', party.TargetPath, 1) + 27, LEN (party.targetpath)) AS partyenroll,
  document.PartyID, document.TypeDoc, document.NumberDoc, document.IsStateIssued, document.StateIssued
  FROM kypportal.portalkyp.pPDM_Document document, kypportal.portalkyp.pPDM_Party party
  WHERE document.PartyID = party.PartyID AND party.IsDeleted = 0 AND party.PartyID IN (SELECT entitypartyid FROM @partymocaTraking)

  UPDATE documentEnrollment SET
  documentEnrollment.TypeDoc = documentTable.TypeDoc, documentEnrollment.NumberDoc = documentTable.NumberDoc, documentEnrollment.IsStateIssued = documentTable.IsStateIssued,
  documentEnrollment.StateIssued = documentTable.StateIssued, documentEnrollment.LastAction = 'U'
  FROM [KYPEnrollment].[pAccount_PDM_Document] documentEnrollment
  LEFT JOIN @documentTable documentTable ON documentEnrollment.PartyID = documentTable.MainPartyID
  WHERE documentEnrollment.PartyID IN (SELECT AccPKValue FROM @partymocaTraking)

  -- update provider

  DECLARE @providerTable TABLE(ID INT IDENTITY(1,1), ProvID INT, MainPartyID INT, PartyID INT, NPI VARCHAR(10), Category VARCHAR(150))
  INSERT INTO @providerTable
  SELECT provider.ProvID, SUBSTRING ( party.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', party.TargetPath, 1) + 27, LEN (party.targetpath)) AS partyenroll,
  provider.PartyID, provider.NPI, provider.Category
  FROM kypportal.portalkyp.pPDM_Provider provider, kypportal.portalkyp.pPDM_Party party
  WHERE provider.PartyID = party.PartyID AND party.IsDeleted = 0 AND party.PartyID IN (SELECT entitypartyid FROM @partymocaTraking)

  UPDATE providerEnrollment SET
  providerEnrollment.NPI = providerTable.NPI, providerEnrollment.Category = providerTable.Category, providerEnrollment.LastAction = 'U'
  FROM [KYPEnrollment].[pAccount_PDM_Provider] providerEnrollment
  LEFT JOIN @providerTable providerTable ON providerEnrollment.PartyID = providerTable.MainPartyID
  WHERE providerEnrollment.PartyID IN (SELECT AccPkValue FROM @partymocaTraking)

	/*  
			Update Owner Role
	*/	
	
	DECLARE @OwnerRole_Table1 TABLE(ID INT IDENTITY(1,1),PdmOwnerID INT,MainPartyID INT, PartyID INT ,TypeForm VARCHAR(100),PercentCheck BIT,PercentValue VARCHAR(150),
	Partner BIT,PartnerValue VARCHAR(150),Managing BIT,Director BIT,DirectorValue VARCHAR(150),Other BIT,OtherValue VARCHAR(150),
	PercentDate SMALLDATETIME,PartnerDate SMALLDATETIME,ManagingDate SMALLDATETIME,OtherDate SMALLDATETIME,Agent BIT,OwnerRelationID INT,SoleOwner BIT,  CurrentRecordFlag BIT,
	OtherDateRole smalldatetime,LessPercent bit, BoardMember bit, BoardMemberDate smalldatetime, IsOwner VARCHAR(10))
	
	INSERT INTO @OwnerRole_Table1 SELECT ownerRole.PdmOwnerID,SUBSTRING ( part.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', part.TargetPath, 1) + 27, LEN (part.targetpath)) AS partyenroll , ownerRole.PartyID, ownerRole.TypeForm, ownerRole.PercentCheck, ownerRole.PercentValue,
	ownerRole.Partner, ownerRole.PartnerValue, ownerRole.Managing, ownerRole.Director, ownerRole.DirectorValue, ownerRole.Other,ownerRole.OtherValue,
	ownerRole.PercentDate, ownerRole.PartnerDate, ownerRole.ManagingDate, ownerRole.OtherDate, ownerRole.Agent, ownerRole.OwnerRelationID,ownerRole.SoleOwner, 1,
	OtherDateRole, LessPercent,BoardMember, BoardMemberDate, ownerRole.IsOwner
	FROM kypportal.portalkyp.pPDM_Owner_Role ownerRole, kypportal.portalkyp.pPDM_Party part 
	WHERE ownerRole.PartyID = part.PartyID and part.IsDeleted=0 and part.PartyID in (select entitypartyid from @partymocaTraking )
	

	UPDATE ownerRole SET
	TypeForm = ownerTable.TypeForm, PercentCheck = ownerTable.PercentCheck, PercentValue = ownerTable.PercentValue, Partner = ownerTable.Partner,
	PartnerValue = ownerTable.PartnerValue, Managing = ownerTable.Managing, Director = ownerTable.Director, DirectorValue =ownerTable.DirectorValue,
	Other = ownerTable.Other, OtherValue = ownerTable.OtherValue,PercentDate = ownerTable.PercentDate, PartnerDate = ownerTable.PartnerDate, 
	ManagingDate = ownerTable.ManagingDate, OtherDate = ownerTable.OtherDate,Agent = ownerTable.Agent, OwnerRelationID = ownerTable.OwnerRelationID, 
	SoleOwner = ownerTable.SoleOwner,CurrentRecordFlag = 1 , LastAction='U',
	OtherDateRole=ownertable.otherdaterole, LessPercent=ownertable.LessPercent , BoardMember=ownertable.BoardMember , BoardMemberDate=ownertable.BoardMemberDate, IsOwner=ownerTable.IsOwner
	FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole 
	LEFT JOIN @OwnerRole_Table1 ownerTable ON ownerrole.PartyID = ownerTable.MainPartyID
	WHERE ownerRole.PartyID in (SELECT AccPKValue FROM @partymocaTraking )
	
	
		 		
	 --***
	 --for ownership deleted
	  
	 print '@DELETE MOCA'
	DECLARE @partyDeleteTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT)
	DECLARE @count_partyDelMoca_Id INT,@top_PartyDelMocaId INT, @partyMocaIdDelete INT, @typeMocaDelete VARCHAR(20)
	--using new table storedmocadeleted
	INSERT INTO @partyDeleteTraking
	SELECT StoreMocaPartyId   FROM [KYPPORTAL].[PortalKYP].[StoredMocaDeleted] where PartyId= @party_id_app and IsDeleted=0
  
	/*
	INSERT INTO @partyDeleteTraking SELECT  AccPKValue FROM #FieldTrakingByParty WHERE AccTableName='pAccount_PDM_Party'  and TableCode='ownerTable'
	and (ActionTaken ='Deleted')
	*/
	--***
	
	/*  
			Delete Party
	*/
	UPDATE KYPEnrollment.pAccount_PDM_Party SET CurrentRecordFlag=0,LastAction='D', MOCARelationshipEndDate=@datesubmit WHERE PartyID in (SELECT EntityPartyID FROM @partyDeleteTraking) 
	AND Type in ('Entity Ownership','Individual Ownership')
	
	
	/*  
			Delete Address
	*/
	
	UPDATE addr SET 
	CurrentRecordFlag = 0 ,LastAction='D'
	FROM 
	[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
	WHERE loc.PartyID in (SELECT EntityPartyID FROM @partyDeleteTraking) 
	
	UPDATE loc SET 
	CurrentRecordFlag = 0 ,isdeleted=1,LastAction='D'
	FROM 
	[KYPEnrollment].[pAccount_PDM_Location] loc 
	where
	loc.partyid in (SELECT EntityPartyID FROM @partyDeleteTraking)


	/*  
			Delete Person
	*/
	

	UPDATE person SET
	CurrentRecordFlag = 0,LastAction='D', Deleted=1
	FROM [KYPEnrollment].[pAccount_PDM_Person] person 
	WHERE person.PartyID in (SELECT EntityPartyID FROM @partyDeleteTraking)

	/*  
			Delete Organization
	*/
	
	UPDATE org SET
	CurrentRecordFlag = 0, LastAction='D', IsDeleted=1
	FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
	WHERE org.PartyID in (SELECT EntityPartyID FROM @partyDeleteTraking)


	/*  
			Delete Owner Role
	*/
	
	UPDATE ownerRole SET
	CurrentRecordFlag =0 , LastAction='D', IsDeleted=1
	FROM [KYPEnrollment].[pAccount_PDM_Owner_Role] ownerRole 
	WHERE ownerRole.PartyID in (SELECT EntityPartyID FROM @partyDeleteTraking)
   
 	
    --for update adverse action
    --include updates in pdm_owner_role table for associations
 declare @tabtempo table (pk int identity(1,1),FieldCode varchar(100),NewValueText text,NewValueInt int,NewValueDate datetime, NewValueBool bit ,NewValueLong bigint,
NewValueDouble float,IsTable bit,TableCode varchar(20),IsDeleted bit ,RowUUID varchar(100),AccTableName varchar(100),AccPK varchar(100),
AccPKValue int,ActionTaken varchar(50),Accepted bit ,EnDbColumn varchar(100),TargetPath varchar(200),EntityID int,StoredValue varchar(max),NewFieldsValues text,SectionNanme varchar(500),CurrentValueText VARCHAR(MAX))

insert into @tabtempo 
SELECT 
FieldCode,NewValueText,NewValueInt,NewValueDate, NewValueBool,NewValueLong,
NewValueDouble,IsTable,TableCode,IsDeleted,RowUUID,AccTableName,AccPK,
AccPKValue,ActionTaken,Accepted,EnDbColumn,TargetPath,EntityID,StoredValue,NewFieldsValues,SectionNanme,CurrentValueText
FROM [KYPPORTAL].PortalKYP.FieldValuesTracking tracking 
WHERE tracking.ApplicationID=@application_id  AND Accepted = @accepted and sectionnanme<>'Disclosure Information'  and 
	sectionnanme<>'Contract/Program Actions' and sectionnanme<>'Medicaid/Medicare Participation' and acctablename is not null  and entityid is not null and
(
(tracking.TableCode IN ('licenseActions','settlementTable',	'licenseActions','convictedTable','liableTable','suspendedTable',	'selfPartTable')  ) or
(tracking.TableCode IN ('ownerSubAssocTable','entitySubTable','assoSubIndTable','assoSubOwnerTable','individualSubTable','otherAssocTable','otherEntAssocTable')   and acctablename in ('pAccount_PDM_Owner_Role')  )
)  
	 

--
DECLARE @field_code VARCHAR(100),@new_value_text VARCHAR(MAX),@new_value_int INT,@new_value_date DATE,@new_value_bool BIT,
			@new_value_long BIGINT,@new_value_double FLOAT,@is_table BIT,@table_code VARCHAR(20),@is_deleted BIT,
			@row_uuid VARCHAR(100),@acc_table_name VARCHAR(100),@acc_PK VARCHAR(100),@acc_PK_value INT,@action_taken VARCHAR(50),
			@en_db_column VARCHAR(100),@target_path VARCHAR(200),@entity_id INT,@stored_value VARCHAR(MAX),@new_fields_values VARCHAR(MAX), @section_nanme VARCHAR(MAX),@current_value_text VARCHAR(MAX)
	
Declare @ParamDefinition AS NVarchar(2000), @accPKvalue varchar(100)
Set @ParamDefinition = '@accPKvalue INT'
set @accPKvalue = CONVERT(VARCHAR(100),@acc_PK_value); 

--
declare @totreg int,@cont int
select @totreg=max(pk) from @tabtempo 
set @cont=1
while @cont<= @totreg 
		BEGIN
		   
			SELECT   @field_code=FieldCode,@new_value_text=NewValueText,@new_value_int=NewValueInt,@new_value_date=NewValueDate, @new_value_bool=NewValueBool,@new_value_long=NewValueLong,
						@new_value_double=NewValueDouble,@is_table=IsTable,@table_code=TableCode,@is_deleted=IsDeleted,@row_uuid=RowUUID,@acc_table_name=AccTableName,@acc_PK=AccPK,
						@acc_PK_value=AccPKValue,@action_taken=ActionTaken,@accepted=Accepted,@en_db_column=EnDbColumn,@target_path=TargetPath,@entity_id=EntityID,@stored_value=StoredValue,@new_fields_values=NewFieldsValues,@section_nanme=SectionNanme,@current_value_text = CurrentValueText
			from @tabtempo 	where PK=@cont 
			
			DECLARE @update NVARCHAR(MAX), @data VARCHAR(MAX), @is_text_date CHAR(1), @data_real VARCHAR(100)
			SET @data = ISNULL(convert(varchar(MAX),@new_value_text), ISnull(case when CONVERT(varchar(100), @new_value_date)='1900-01-01' then '' else CONVERT(varchar(100), @new_value_date) end ,isnull(case when CONVERT(VARCHAR(100),@new_value_int)='0' then '' else CONVERT(VARCHAR(100),@new_value_int) end ,
			            isnull(case when CONVERT(VARCHAR(100),@new_value_bool)='0' then '0' else CONVERT(VARCHAR(100),@new_value_bool) end ,isnull(case when CONVERT(VARCHAR(100),@new_value_long)='0' then '' else CONVERT(VARCHAR(100),@new_value_long) end,'')))))
			
	     
	       IF (@new_value_text IS NOT NULL OR @new_value_date IS NOT NULL OR @new_value_double IS NOT NULL OR @new_value_long IS NOT NULL)
			 BEGIN
				SET @data_real = LTRIM(STR(@new_value_double, 10, 7))
				IF(@data_real<>'')
					SET @data = @data_real;						
				SET @is_text_date = '1' 
			 END
		     
			 ELSE
			 BEGIN
				SET @is_text_date = '0'	 
			 END
			 
			 IF @stored_value = 'radio' AND @section_nanme ='Place of Business'
				  BEGIN
				   SET @data = @new_fields_values;
				  END
			if @en_db_column	is not null  
				EXEC [KYPEnrollment].[sp_Update_Field]@acc_table_name, @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,@stored_value,@last_action_user_id,@action_taken;	
			else
			 if @Action_Taken='Deleted' and @Entity_ID is not null	 
			  begin
			   if  @acc_table_name not in('pAccount_PDM_Address','pAccount_PDM_Person')
			    SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+ ' SET isdeleted=1, currentrecordflag=0,lastaction=''D'' WHERE '+@acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);
               else
                if   @acc_table_name ='pAccount_PDM_Address'
                     SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+ ' SET currentrecordflag=0,lastaction=''D'' WHERE '+@acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);

                else
                     SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+ ' SET deleted=1, currentrecordflag=0,lastaction=''D'' WHERE '+@acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);

                 
                EXECUTE(@update)
			  end
	     
	      set @cont=@cont+1
	     end
  --end update adverse action
--for delete adverse action


	 --mvc
	 PRINT 'Update Association'
	 --when the association is updated
	 --when the partyidowned is changed in an associations
	
	EXECUTE [KYPEnrollment].[Update_Associations_NewModel] 'U', @party_id_app, @application_id, @account_id,@profId

	--when the association (ownership - subcontractor) are deleted
	-- significant entity
	EXECUTE [KYPEnrollment].[sp_Update_OwnershipRelationship_TransDescription] 'U', @application_id, 'transDescriptionEntity', 'significantSubTable'
	-- significant individual
	EXECUTE [KYPEnrollment].[sp_Update_OwnershipRelationship_TransDescription] 'U', @application_id, 'transDescriptionIndividual', 'significantSubTable'
	---***
	
	select accpkvalue as idrelation into #rrelation from #FieldTrakingByParty WHERE (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable'  or TableCode='significantSubTable'  or TableCode='SubOwnerTable' or TableCode='subcontratorTable' or TableCode='signOwnerTable')
	and actiontaken='deleted' and AccTableName ='pAccount_PDM_OwnershipRelationship' and EnDbColumn is null


	update kypenrollment.pAccount_PDM_OwnershipRelationship set  currentrecordflag =0, IsDeleted =1  where ownerrelationid in (select idrelation from #rrelation)
	update kypenrollment.pAccount_PDM_Owner_Role set CurrentRecordFlag =0 ,IsDeleted =1 where ownerrelationid in (select idrelation from #rrelation)

	--when the association (ownership-other) is deleted
    select accpkvalue as idrelation,rela.PartyIDOwned  into #rrelation1 from #FieldTrakingByParty 
    inner join kypenrollment.pAccount_PDM_OwnershipRelationship rela on #FieldTrakingByParty.AccPKValue =rela.OwnerRelationID 
    WHERE (TableCode='otherAssocTable' OR TableCode='otherEntAssocTable' )
	and actiontaken='deleted' and AccTableName ='pAccount_PDM_OwnershipRelationship'
	
	update kypenrollment.pAccount_PDM_OwnershipRelationship set  currentrecordflag =0, IsDeleted =1  where ownerrelationid in (select idrelation from #rrelation1)
    
    UPDATE KYPEnrollment.pAccount_PDM_Party SET CurrentRecordFlag=0,LastAction='D', isdeleted=1 WHERE PartyID in (SELECT partyidowned FROM #rrelation1)

	UPDATE addr SET 
	CurrentRecordFlag = 0 ,LastAction='D'
	FROM 
	[KYPEnrollment].[pAccount_PDM_Address] addr INNER JOIN [KYPEnrollment].[pAccount_PDM_Location] loc ON addr.AddressID = loc.AddressID
	WHERE loc.PartyID in (SELECT partyidowned FROM #rrelation1)
	
	UPDATE loc SET 
	CurrentRecordFlag = 0 ,isdeleted=1,LastAction='D'
	FROM 
	[KYPEnrollment].[pAccount_PDM_Location] loc 
	where
	loc.partyid in (SELECT partyidowned FROM #rrelation1)

	UPDATE person SET
	CurrentRecordFlag = 0,LastAction='D', Deleted=1
	FROM [KYPEnrollment].[pAccount_PDM_Person] person 
	WHERE person.PartyID in (SELECT partyidowned FROM #rrelation1)

	UPDATE org SET
	CurrentRecordFlag = 0, LastAction='D', IsDeleted=1
	FROM [KYPEnrollment].[pAccount_PDM_Organization] org 
	WHERE org.PartyID in (SELECT partyidowned FROM #rrelation1)

    
	 
	 DROP TABLE #FieldTrakingByParty
	 drop table #rrelation
	 drop table #rrelation1



END TRY

BEGIN CATCH

	DECLARE    @error_message NVARCHAR(4000),@error_severity INT;
	SELECT     @error_message = ERROR_MESSAGE()
		      ,@error_severity = ERROR_SEVERITY();
	RAISERROR (@error_message
              ,@error_severity
              ,1);
              
    EXEC KYPEnrollment.Usp_LogError @KeyField = 'ApplicationID',@KeyValue = @application_id
              
END CATCH

	
END

GO

