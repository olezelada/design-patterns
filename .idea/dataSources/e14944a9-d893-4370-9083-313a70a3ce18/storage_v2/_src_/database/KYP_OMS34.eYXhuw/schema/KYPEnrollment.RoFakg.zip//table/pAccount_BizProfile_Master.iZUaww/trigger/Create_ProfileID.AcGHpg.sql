
CREATE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
WITH EXECUTE AS CALLER
AFTER INSERT
AS 
BEGIN
 
 Declare @ID int
 Declare @ProfileID varchar(15)
 
 DECLARE @Row_Trigger_Source VARCHAR(100)
 SELECT top 1 @Row_Trigger_Source = INSERTED.Row_Trigger_Source FROM INSERTED 
 IF ISNULL(@Row_Trigger_Source, '') = 'KYPEnrollment.sp_Copy_BizProfile_Details'  or not exists (select * from inserted)
 BEGIN
	PRINT 'Going to return to prevent deadlock schema M locks'
	RETURN
 END
 
 SET @ID = (select ID from inserted); 
 SET @ProfileID = 1000+@ID
 
 UPDATE [KYPEnrollment].[pAccount_BizProfile_Master] SET [ProfileID] = @ProfileID
 WHERE ID=@ID
 
END


GO

