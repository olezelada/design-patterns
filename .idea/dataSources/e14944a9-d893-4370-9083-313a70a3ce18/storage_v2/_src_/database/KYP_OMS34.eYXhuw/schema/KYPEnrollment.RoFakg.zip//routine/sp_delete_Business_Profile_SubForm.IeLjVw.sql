-- =============================================
-- Author:		<DH-BOL>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to Business Profile of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Business_Profile_SubForm]
@new_Account_Id int

AS
BEGIN
Declare @org int,@ent int,@numb int, @partyId int
Declare @npi_Type varchar(100),@new_Address_Id int,@npi varchar(100),@provider_type_code varchar(20),
@account_number varchar(100),@accountType varchar(10),@application_Id INT,@application_type VARCHAR(50)
	SET NOCOUNT ON;

SELECT @partyId = party.PartyID, @org = organization.OrgID, @ent = entityType.EntityTypeID
FROM KYPEnrollment.pADM_Account account INNER JOIN KYPEnrollment.pAccount_PDM_Party party ON account.PartyID=party.PartyID
		INNER JOIN KYPEnrollment.pAccount_PDM_Organization organization ON party.PartyID=organization.PartyID
		INNER JOIN KYPEnrollment.pAccount_PDM_EntityType entityType ON organization.PartyID=entityType.PartyID
WHERE account.AccountID=@new_Account_Id AND party.CurrentRecordFlag=1 AND organization.CurrentRecordFlag=1

	EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Organization','OrgID',@org
	EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_EntityType','EntityTypeID',@ent

  UPDATE [KYPEnrollment].[pAccount_PDM_Number]
      SET  IsDeleted=0, CurrentRecordFlag = 0
    WHERE NumberID IN
			(SELECT NumberID
				FROM KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Number] n ON a.PartyID=n.PartyID
				WHERE a.IsDeleted=0 and n.CurrentRecordFlag=1	and n.IsDeleted =0  and a.AccountID=@new_Account_Id and n.Type IN ('BusinessEinLicenses'))

END


GO

