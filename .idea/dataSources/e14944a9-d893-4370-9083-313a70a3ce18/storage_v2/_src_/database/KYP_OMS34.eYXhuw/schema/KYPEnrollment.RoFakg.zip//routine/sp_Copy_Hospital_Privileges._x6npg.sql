
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Hospital Privileges form.   
-- PARAMETERS: 
-- @party_id : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Hospital_Privileges] 	
	@party_id INT,
	@new_party_id INT,
	@last_action_user_id VARCHAR(100),
	@account_id INT

AS
BEGIN
	DECLARE 
	@date_create DATE
	
	SET @date_create = GETDATE()

	EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org]@party_id, @new_party_id,@last_action_user_id, 'Hospital Privileges',NULL,@account_id;
	EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org]@party_id, @new_party_id,@last_action_user_id, 'Revoked Privileges',NULL,@account_id;
	EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org]@party_id, @new_party_id,@last_action_user_id, 'Resigned Privileges',NULL,@account_id;
END


GO

