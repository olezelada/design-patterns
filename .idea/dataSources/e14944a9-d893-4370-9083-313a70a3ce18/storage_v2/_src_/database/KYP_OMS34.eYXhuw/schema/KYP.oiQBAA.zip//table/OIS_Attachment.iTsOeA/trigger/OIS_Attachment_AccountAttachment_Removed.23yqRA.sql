


CREATE TRIGGER [KYP].[OIS_Attachment_AccountAttachment_Removed] ON [KYP].[OIS_Attachment]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
BEGIN
    Declare @AttachmentID 			varchar(100)
	Declare @AttachmentEntityDep 	varchar(100)
	Declare @IsDeleted 				varchar(4)
	Declare @OldIsDeleted 			varchar(4)
			,@Row_Updation_Source varchar(100)
			
	Select @Row_Updation_Source	= Row_Updation_Source From Inserted;
	
	If (@Row_Updation_Source = 'OIS_Attachment') and Update(Row_Updation_Source)
	Begin
		Print 'Skip OIS_Attachment Trigger Execution'
		Return;	
	End

    Set @AttachmentID 		= (Select AttachmentID from Inserted)
	Set @IsDeleted		 	= (Select isnull(deleted,0) from Inserted)
	Set @OldIsDeleted 		= (Select isnull(deleted,0) from Deleted)
	--Set @AttachmentEntityDep= (Select AttachmentEntityDep from KYP.AttachmentEntity where AttachmentEntityDep='pADM_Account' and AttachmentID = @AttachmentID)
    Select @AttachmentEntityDep = AttachmentEntityDep from KYP.AttachmentEntity where AttachmentEntityDep='pADM_Account' and AttachmentID = @AttachmentID
    
    if(@AttachmentEntityDep = 'pADM_Account')
    BEGIN
    	print 'Change in Account Attachment'
    	if update(deleted) and @IsDeleted<>@OldIsDeleted and @IsDeleted = 1
        Begin
        	   	print 'Account Attachment has been deleted'
          Declare @CreatedBy varchar(100)
          Declare @AttachmentNumber varchar(20)
          Declare @AccountID varchar(100)
          Declare @HistoryID int
          Declare @Title varchar(100)

          --Set @AccountID 		= (Select AttachmentEntityDepID from KYP.AttachmentEntity where AttachmentEntityDep='pADM_Account' and AttachmentID = @AttachmentID)
          Select @AccountID = AttachmentEntityDepID from KYP.AttachmentEntity where AttachmentEntityDep='pADM_Account' and AttachmentID = @AttachmentID       
          Set @CreatedBy 		= (Select ModifiedBy from Inserted)
          Set @Title			= (Select Title from Inserted)
          Set @AttachmentNumber	= (Select Number from Inserted)
      	
                  INSERT INTO 
                    KYPEnrollment.pAccount_History
                    (
                      AccountID,
                      ActionID,
                      DateCreated,
                      IsDeleted,
                      LastActorUserID,
                      LastActionDate
                    ) 
                    VALUES (
                       @AccountID,
                       48,
                      getdate(),
                      0,
                      @CreatedBy,
                      getdate()  
                    )
                    
                    
                    set @HistoryID = (SELECT SCOPE_IDENTITY());
                    print @HistoryID

                
                  INSERT INTO 
                      KYPEnrollment.HIS_Document
                    (
                      HistoryID,
                      DateCreate,
                      IsDeleted,
                      DocNumber,
                      DocTitle
                    ) 
                    VALUES (
                      @HistoryID,
                      getDate(),
                      0,
                      @AttachmentNumber,
                      @Title
                    );
        End
    	
    END
    
END


GO

