CREATE FUNCTION [KYPEnrollment].[AddressFull](@PartyID int)
RETURNS varchar(500)
AS 
BEGIN
  Declare @vResult varchar(500)
  Declare @vPartial varchar(500)

  DECLARE Cur_ESFS CURSOR FOR
  
  select (ISNULL(a.AddressLine1 ,'')+' '+ISNULL(a.City ,'')+' '+ISNULL(a.[State] ,'')+' '+ ISNULL(a.ZipPlus4 ,'') ) as NameA from  KYP.PDM_Location l INNER JOIN KYP.PDM_Address a on a.AddressID=l.AddressID where l.PartyID=@PartyID order by a.DateCreated desc
  
  OPEN Cur_ESFS  
  
  SET @vResult='';
  SET @vPartial='';
  FETCH Cur_ESFS INTO @vPartial
  WHILE (@@FETCH_STATUS = 0)
  BEGIN	
	IF @vPartial != ''
	begin
		SET @vResult = @vPartial
	end	
	FETCH Cur_ESFS INTO @vPartial
  END 
  CLOSE Cur_ESFS
  DEALLOCATE Cur_ESFS
  SET @vResult = @vResult 
  return @vResult
END;


GO

