

/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Update_Associations]
	@last_action VARCHAR(1),
	@party_id_app INT,
	@app_id INT,
	@account_id INT,
	@profId VARCHAR(100)

AS

BEGIN
    --not include otherassociations
	select *  into #FieldTrakingByParty1 from [KYPPORTAL].[PortalKYP].[FieldValuesTracking] 
	where AccTableName IS NOT NULL AND AccPKValue IS NOT NULL AND AccPK IS NOT NULL AND applicationid=@app_id and( TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable' )
	create table #partyRelation  (ID INT IDENTITY(1,1),CurrentValueInt INT , NewValueInt INT, TargetPath VARCHAR(200))
	insert into #partyRelation
	--update in associations with subcontractors or ownership
	select CurrentValueInt,NewValueInt, SUBSTRING(TargetPath,CHARINDEX('pAccount_PDM_OwnershipRelationship|OwnerRelationID|',TargetPath,1)+51, 
	LEN(TargetPath)) from #FieldTrakingByParty1 WHERE (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable')
	 and CurrentValueInt is not null 
	and NewValueInt is not null 

	
	CREATE TABLE #PartyPortal (PartyID INT,ParentPartyID INT,Type VARCHAR(50),IsPrepopulated BIT,TargetPath VARCHAR(200),Partyenroll VARCHAR(200))
	INSERT INTO #PartyPortal
	SELECT PartyID,ParentPartyID ,Type,IsPrepopulated,TargetPath,SUBSTRING(targetpath,CHARINDEX('pAccount_PDM_Party|PartyID|',TargetPath,1)+27,LEN(targetpath)) AS partyenroll 
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE ParentPartyID= @party_id_app or
	( ParentPartyID IN (SELECT PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE ParentPartyID = @party_id_app))
	OR PartyID = @party_id_app
	
	;WITH PartyLevels (partyidlevel,type,IsPrepopulated,partypadre,partyabuelo,partylevel,partyenroll,partyenrollmain) AS
	(
		SELECT PartyID,Type,IsPrepopulated,NULL,NULL,0 AS partylevel , partyenroll,null FROM #PartyPortal
		WHERE ParentPartyID  IS NULL UNION ALL
		SELECT p.PartyID,p.Type,p.IsPrepopulated,
		pe.partyidlevel, pe.partypadre ,
		partylevel+1 ,P.partyenroll,null
		FROM #PartyPortal AS p INNER JOIN PartyLevels pe ON p.ParentPartyID=pe.partyidlevel

	)
	select * into #PartiesLevelTable  from PartyLevels

	update pl set pl.partyenrollmain= partyAso.mainpartyid 
	FROM  #PartiesLevelTable pl 
	inner JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAso ON (ISNULL(pl.partyenroll,'') = CONVERT(VARCHAR(10),partyAso.PartyID)) where IsPrepopulated = @account_id
	

	SELECT pl.*,partyaso.MainPartyID,partyAso.PartyID AS partyIDEnrollment,partyAso.AccountID INTO #AssociationsTable FROM  #PartiesLevelTable pl 
	LEFT JOIN [KYPEnrollment].[pAccount_Party_Associate] partyAso ON (ISNULL(pl.partyenrollmain,'') = CONVERT(VARCHAR(10),partyAso.mainpartyID))
	inner join  [KYPEnrollment].[pAccount_BizProfile_Details] prof ON partyAso.AccountID = prof.AccountID and prof.ProfileID=@profId
	 
	--party Prepopulados
	update relation set partyidowned=asso1.partyIDEnrollment
	from 	#partyRelation 
	inner join #AssociationsTable on #partyRelation.CurrentValueInt =#AssociationsTable.partyidlevel  and #AssociationsTable.AccountID <> @account_id
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on #AssociationsTable.partyIDEnrollment=relation.PartyIDOwned
	inner join #AssociationsTable asso1 on #partyRelation.NewValueInt=asso1.partyidlevel and  #AssociationsTable.AccountID=asso1.AccountID 
	
	--se cambia la asociacion a un party nuevo
	update relation set partyidowned=party.PartyID
	from 	#partyRelation inner join #AssociationsTable on #partyRelation.CurrentValueInt =#AssociationsTable.partyidlevel  and #AssociationsTable.AccountID <> @account_id
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on partyIDEnrollment=relation.PartyIDOwned
	inner join KYPEnrollment.pAccount_PDM_Party party on #partyRelation.NewValueInt=party.TempPartyID and #AssociationsTable.AccountID=party.AccountID 
	
	--Update Owner Role and ownership relation
	CREATE TABLE #valueOwnerRole(ID INT IDENTITY(1,1),OwnerRoleId INT,OwnerRelationId INT,OwnerId INT,OwnedId INT)
	insert into #valueOwnerRole select distinct ownerrole.PdmOwnerID, relation.OwnerRelationID, relation.PartyIDOwner, relation.PartyIDOwned
	from #FieldTrakingByParty1 
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole on ownerrole.PdmOwnerID = #FieldTrakingByParty1.AccPKValue
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on relation.OwnerRelationID = ownerrole.OwnerRelationID
	where AccTableName='pAccount_PDM_Owner_Role' and (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable' or 
	TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode= 'assoSubOwnerTable')
	
	insert into #valueOwnerRole select distinct ownerrole.PdmOwnerID, relation.OwnerRelationID, relation.PartyIDOwner, relation.PartyIDOwned
	from #FieldTrakingByParty1 
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on relation.OwnerRelationID = #FieldTrakingByParty1.AccPKValue
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole on relation.OwnerRelationID = ownerrole.OwnerRelationID
	where AccTableName='pAccount_PDM_OwnershipRelationship' and (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or 
	TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode= 'assoSubOwnerTable')
	---------------------------------

	CREATE TABLE #OwnerRoleAssocation(ID INT IDENTITY(1,1),partyEnroll INT,partyIDEnrollment INT,OwnerId INT,OwnedId INT)
	insert into #OwnerRoleAssocation select ass.partyenroll, ass.partyIDEnrollment, rol.OwnerId, rol.OwnedId  from #AssociationsTable ass 
					inner join #valueOwnerRole rol on ass.partyenroll = rol.OwnerId  and ass.AccountID <> @account_id;
	insert into #OwnerRoleAssocation select ass.partyenroll, ass.partyIDEnrollment, rol.OwnerId, rol.OwnedId  from #AssociationsTable ass 
					inner join #valueOwnerRole rol on ass.partyenroll = rol.OwnedId  and ass.AccountID <> @account_id;
	
	update ownerrole set ownerrole.[PercentCheck] = ownerrole1.[PercentCheck]
			   ,ownerrole.[PercentValue] = ownerrole1.[PercentValue],ownerrole.[Partner] = ownerrole1.[Partner]
			   ,ownerrole.[PartnerValue] = ownerrole1.[PartnerValue],ownerrole.[Managing] = ownerrole1.[Managing]
			   ,ownerrole.[ManagingValue] = ownerrole1.[ManagingValue],ownerrole.[Director] = ownerrole1.[Director]
			   ,ownerrole.[DirectorValue] = ownerrole1.[DirectorValue],ownerrole.[Other] = ownerrole1.[Other]
			   ,ownerrole.[OtherValue] = ownerrole1.[OtherValue]		
			   ,ownerrole.[PercentDate] = ownerrole1.[PercentDate],ownerrole.[PartnerDate] = ownerrole1.[PartnerDate]
			   ,ownerrole.[ManagingDate] = ownerrole1.[ManagingDate],ownerrole.[OtherDate] = ownerrole1.[OtherDate]
			   ,ownerrole.[Agent] = ownerrole1.[Agent],ownerrole.[PartyID] = ownerrole1.[PartyID]
			   ,ownerrole.[LastAction] = @last_action
			   ,ownerrole.[SoleOwner] = ownerrole1.[SoleOwner]		
	from #valueOwnerRole newVal inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation1 on newVal.OwnerRelationId = relation1.OwnerRelationID 
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole1 on newVal.OwnerRoleId = ownerrole1.PdmOwnerID ,KYPEnrollment.pAccount_PDM_OwnershipRelationship relation 
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole on relation.OwnerRelationID = ownerrole.OwnerRelationID
	where relation.PartyIDOwner in (select partyIDEnrollment from #OwnerRoleAssocation  where partyEnroll = OwnerId)
	and relation.PartyIDOwned in (select partyIDEnrollment from #OwnerRoleAssocation  where partyEnroll = OwnedId)
	
	update relation set FamiliarRelationship = relation1.FamiliarRelationship, FamiliarRelationshipOther= relation1.FamiliarRelationshipOther		 
	from #valueOwnerRole newVal inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation1 on newVal.OwnerRelationId = relation1.OwnerRelationID 
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole1 on newVal.OwnerRoleId = ownerrole1.PdmOwnerID ,KYPEnrollment.pAccount_PDM_OwnershipRelationship relation 
	inner join KYPEnrollment.pAccount_PDM_Owner_Role ownerrole on relation.OwnerRelationID = ownerrole.OwnerRelationID
	where relation.PartyIDOwner in (select partyIDEnrollment from #OwnerRoleAssocation  where partyEnroll = OwnerId)
	and relation.PartyIDOwned in (select partyIDEnrollment from #OwnerRoleAssocation  where partyEnroll = OwnedId)
	--mvc
	/*
	--Update Other Association	

	CREATE TABLE #valuePerson(ID INT IDENTITY(1,1),PersonID INT,PartyId INT, ParentParty INT, AddressID INT, LocationID INT)
	insert into #valuePerson select distinct person.PersonID, person.PartyID, party.ParentPartyID, addr.AddressID, loc.LocationID
	from #FieldTrakingByParty1 tracking
	inner join KYPEnrollment.pAccount_PDM_Person person on person.PersonID = tracking.AccPKValue
	inner join KYPEnrollment.pAccount_PDM_Party party on party.PartyID = person.PartyID
	inner join KYPEnrollment.pAccount_PDM_Location loc on loc.PartyID = party.PartyID
	inner join KYPEnrollment.pAccount_PDM_Address addr on addr.AddressID = loc.AddressID
	where tracking.AccTableName='pAccount_PDM_Person' and tracking.TableCode='otherAssocTable'
	
	
	CREATE TABLE #valueOrganization(ID INT IDENTITY(1,1),OrganizationID INT,PartyId INT,ParentParty INT, AddressID INT, LocationID INT)
	insert into #valueOrganization select distinct org.OrgID, org.PartyID, party.ParentPartyID, addr.AddressID, loc.LocationID
	from #FieldTrakingByParty1 
	inner join KYPEnrollment.pAccount_PDM_Organization org on org.OrgID = #FieldTrakingByParty1.AccPKValue
	inner join KYPEnrollment.pAccount_PDM_Party party on party.PartyID = org.PartyID
	inner join KYPEnrollment.pAccount_PDM_Location loc on loc.PartyID = party.PartyID
	inner join KYPEnrollment.pAccount_PDM_Address addr on addr.AddressID = loc.AddressID
	where AccTableName='pAccount_PDM_Organization' and TableCode='otherEntAssocTable'
	
	
	
	DECLARE @partyAssocIndOrg TABLE (ID INT IDENTITY(1,1),PartyIDAss INT, PartyIDNew INT)
	INSERT INTO  @partyAssocIndOrg SELECT distinct ass.partyIDEnrollment, per.ParentParty from #AssociationsTable ass 
	inner join #valuePerson per on (ass.partyenroll = per.ParentParty or ass.partyenroll = per.ParentParty )
	inner join #valueOrganization org on (ass.partyenroll = org.ParentParty or ass.partyenroll = org.ParentParty ) and ass.AccountID <> 1
	
	 DECLARE @count_party_Id INT,@top_PartyId INT
	 SELECT @top_PartyId = MAX(ID) FROM @partyAssocIndOrg; 
	 SET @count_party_Id = 1
	 WHILE @count_party_Id <= @top_PartyId
	 BEGIN
		declare @partyAss int, @parentPartyID int 
		select @partyAss =PartyIDAss,@parentPartyID = PartyIDNew from @partyAssocIndOrg where ID=@count_party_Id
		execute [KYPEnrollment].[Update_Association_Per_Org] @partyAss,@parentPartyID,@last_action,@profId;
		SET @count_party_Id = @count_party_Id+1
	 END
	*/

	drop table #FieldTrakingByParty1
	drop table #partyRelation
	drop table #PartyPortal
	drop table #PartiesLevelTable
	drop table #AssociationsTable
	drop table #valueOwnerRole
	drop table #OwnerRoleAssocation
	--drop table #valueOrganization
	--drop table #valuePerson
END


GO

