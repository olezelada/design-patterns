
/* ==========================================================
-- Author:		<jvERA>
-- PROCEDURE: create address and location.   
-- PARAMETERS: 
-- @new_Party_Id : partyID to new Account that will be create. 
-- @party_Id : partyID Application that will be Account.
-- @address_type : this is the type locacion, it can be Null.  
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Address_Location] 
	@new_Party_Id INT
	,@party_Id INT
	,@address_type VARCHAR(100)
	,@last_action_user_id VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @date_created SMALLDATETIME
		,@new_address_id INT
		,@address_id INT
		,@location_id INT				
		,@AccountID INT

	BEGIN TRY		
		SET @date_created = CURRENT_TIMESTAMP;
			
		  IF (@address_type IS NULL )
		  BEGIN
				SELECT @address_id = [AddressID], @location_id = [LocationID] 
				FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  
				WHERE [PartyID] = @party_Id AND [IsDeleted] = 0
		  END
		  ELSE
		  BEGIN
				SELECT @address_id = [AddressID], @location_id = [LocationID] 
				FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  
				WHERE [PartyID] = @party_Id AND [Type] = @address_type AND [IsDeleted] = 0
		  END
	      
	      
	       ----------TABLE ADDRESS
		  INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
		  ([AddressLine1] ,
		  [AddressLine2] ,
		  [County] ,
		  [City] ,
		  [Zip] ,
		  [ZipPlus4] ,
		  [State] ,
		  [Country] ,
		  [Latitude] ,
		  [Longitude] ,
		  [GeographicArea], 
		  [LastAction],
		[LastActionDate],
		[LastActionUserID],
		[LastActionApprovedByUsedID],
		[CurrentRecordFlag])
		  SELECT [AddressLine1]
		  ,[AddressLine2]
		  ,[County]
		  ,[City]
		  ,[Zip]
		  ,[ZipPlus4]
		  ,[State]
		  ,[Country]
		  ,[Latitude]
		  ,[Longitude]
		  ,[GeographicArea]
		  ,'C'
		  ,@date_created
		,@last_action_user_id
		,@last_action_user_id
		,1
		  FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] WHERE AddressID = @address_id     
		  SELECT @new_address_id = SCOPE_IDENTITY();      
		  
		  
	      ----------TABLE LOCATION
		  INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
		  ([AddressID] ,
		  [PartyID] ,
		  [Type] ,
		  [WorkingDays] ,
		  [WorkingHours] ,
		  [Phone1] ,
		  [Phone2] ,
		  [Fax] ,
		  [Remarks] ,
		  [InActive] ,
		  [Email] ,
		  [IsLicensed] ,
		  [IsRented] ,
		  [Status] ,
		  [Name],
		  [IsDeleted],
		  [LastAction],
		[LastActionDate],
		[LastActorUserID],
		[LastActionApprovedBy],
		[CurrentRecordFlag])
		  SELECT @new_address_id
		  ,@new_Party_Id
		  ,[Type]
		  ,[WorkingDays]
		  ,[WorkingHours]
		  ,[Phone1]
		  ,[Phone2]
		  ,[Fax]
		  ,[Remarks]  
		  ,[InActive]
		  ,[Email]
		  ,[IsLicensed]
		  ,[IsRented]
		  ,[Status]
		  ,[Name]
		  ,[IsDeleted]
		  ,'C'
		  ,@date_created
		,@last_action_user_id
		,@last_action_user_id
		,1
		  FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] WHERE [LocationID] = @location_id
	      
		  PRINT 'new Location Stock is ' + CONVERT(char(10), @new_address_id);
		  RETURN @new_address_id
	      
	
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;
		
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'party_Id',@KeyValue = @party_Id;
	END CATCH	
END


GO

