





CREATE VIEW [KYPEnrollment].[Portable_Imaging_Supervisor]
AS
SELECT  organization.PersonID as SupervisingID, isnull(organization.FirstName,'')+' '+ISNULL(organization.MiddleName,'')+' '+ISNULL(organization.LastName,'') as Name, 
organization.NPI as NPI, A.AccountID as NumberID, number.Number as Number, 
number.State as State, number.Type as Type, number.EffectiveDate As EffectiveDate, number.ExpirationDate AS ExpirationDate, party.PartyID  as PartyID
FROM 
 KYPEnrollment.padm_account A
inner join  KYPEnrollment.pAccount_PDM_Party party on A.partyid=party.Parentpartyid 
inner join KYPEnrollment.pAccount_PDM_Person organization on party.PartyID=organization.PartyID
left join KYPEnrollment.pAccount_PDM_Number number on organization.partyid=number.partyid
where party.Type='supervisingPhysician'


GO

