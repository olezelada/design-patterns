
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Packages Rendering Allied.   
-- PARAMETERS: 
-- @new_account_id : AccountID to new Account that will be create. 
-- @new_party_id_account : partyID to new Account that will be create. 
-- @party_id_portal : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @application_no : Application Number that will be Account. 
-- @application_Id : ApplicationID that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ISP_RP_U_RA] (
	@new_account_id INT, 
	@new_party_id_account INT,
	@party_id_portal INT, 
	@last_action_user_id VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@account_type VARCHAR(10),
	@application_type VARCHAR(40))
AS
BEGIN
	DECLARE @new_person_id INT,
	@party_contact_id INT,
	@party_contact_id_portal INT, 
	@npi_type VARCHAR(25),
	@npi VARCHAR (10),
	@provider_type_code VARCHAR(5),
	@account_number VARCHAR(20),
	@isGroup BIT ;
	
	SELECT @npi_type = [NPIType], @npi = NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_account_id 
	/*Individual Profile*/
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Personal_Inf_Identification] @new_party_id_account, @party_id_portal,@last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Individual Profile', @last_action_user_id;

	select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id
	
	/*Addresses*/
	
	
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Servicing', @last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Pay-to', @last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_id_account, @party_id_portal, 'Mailing', @last_action_user_id;
	
	
	/*Contact Person*/
	EXEC [KYPEnrollment].[sp_Contact_Person] @party_id_portal, @new_party_id_account,@last_action_user_id,@new_account_id;
	
	/*Insurance*/
	EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_party_id_account, @party_id_portal,@last_action_user_id;
	
	/* Prof. Licenses Certificates*/
	EXEC [KYPEnrollment].[sp_Copy_Number] @new_party_id_account, @party_id_portal, @last_action_user_id, NULL; 
	
	/* Taxonomy Speciality */
	EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_party_id_account, @party_id_portal, @last_action_user_id, NULL;
	
	/*Program Participation*/
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id; 

	/*Adverse Action*/
	EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_party_id_account, @party_id_portal,@last_action_user_id,@new_account_id; 
		
	/* Fines and debts */
	EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_id_portal, @new_party_id_account, @last_action_user_id,NULL;
	
	/*Affiliation*/
	EXEC [KYPEnrollment].[sp_Copy_Affiliarion]@new_account_id,@party_id_portal,@last_action_user_id ,'rendering',@application_no,@application_Id;
	
	/*BizProfile Details*/
	-- DISABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_id_portal,@new_account_id,@new_party_id_account,@last_action_user_id, 'KYPEnrollment.sp_Copy_BizProfile_Details';
	-- ENABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON [KYPEnrollment].[pAccount_BizProfile_Master]
	
	/*Unique Party*/
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account]@new_party_id_account, @new_account_id, @npi_Type, @last_Action_User_ID,0;

	/*Update data Account and Linked*/
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, NULL, @npi_Type, @last_Action_User_ID, @npi,@new_party_id_account,@party_id_portal, 0, @provider_type_code, @account_number, NULL,@account_type, @application_Id, @isGroup, @application_type;
END


GO

