-- =============================================
-- Author:		Ashok Chelimilla
-- Create date: 07/11/2014
-- Description:	To insert the finding type level composite risk score in to SDM_CompositeriskScoreDet table.
-- =============================================
CREATE TRIGGER [KYP].[trg_SDM_RiskScoreOnInsert]  
   ON  [KYP].[SDM_RiskScoreUpdate] 
   AFTER insert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	declare @ScreeningID int
	,@ApplicationID int
	,@Auto varchar(4)
	,@ExternalYesNO varchar(4)
	
	SELECT @ScreeningID = ScreeningID, @ApplicationID = ApplicationID, @Auto = Auto, @ExternalYesNO = ExternalYesNO from inserted
  
  /* Commented - blocking sessions.
  IF ISNULL(@ExternalYesNO,'') <> 'Yes'
	BEGIN
		--EXEC [KYP].[p_insertCompositeRiskDetails]@ScreeningID,@ApplicationID,@Auto;
	END
    -- Insert statements for trigger here
  */

END


GO

