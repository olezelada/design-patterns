CREATE VIEW [KYP].[v_AlertResolutionNotes]
AS

SELECT     row_number() OVER (ORDER BY AlertID ASC) AS ID, *
FROM         
(

	SELECT		Z.AlertID, Z.ResolutionType, Z.ResolutionTypeID, Z.ProviderName, Z.CreatedDate, Z.ResolutionNoteID, Z.UnformattedContent
	FROM		(
							SELECT     A.AlertID, A.ResolutionType, A.ResolutionTypeID, A.ProviderName, A.CreatedDate, B.ResolutionNoteID, C.UnformattedContent
							FROM          KYP.MDM_AlertResolution AS A INNER JOIN
												  KYP.MDM_AlertPvdSuspension AS B ON B.ResolutionID = A.ResolutionID AND A.ResolutionTypeID NOT IN (5, 6) AND ISNULL(A.IsDeleted, 0) 
												  = 0 INNER JOIN
												  KYP.OIS_Note AS C ON C.NoteID = B.ResolutionNoteID 
							UNION ALL
							
							SELECT     A.AlertID, A.ResolutionType, A.ResolutionTypeID, A.ProviderName, A.CreatedDate, B.ResolutionNoteID, C.UnformattedContent
							FROM         KYP.MDM_AlertResolution AS A INNER JOIN
												 KYP.MDM_AlertOIGReferral AS B ON B.ResolutionID = A.ResolutionID AND A.ResolutionTypeID NOT IN (5, 6) AND ISNULL(A.IsDeleted, 0) = 0 INNER JOIN
												 KYP.OIS_Note AS C ON C.NoteID = B.ResolutionNoteID 
							UNION ALL
							
							SELECT     A.AlertID, A.ResolutionType, A.ResolutionTypeID, A.ProviderName, A.CreatedDate, B.ResolutionNoteID, C.UnformattedContent
							FROM         KYP.MDM_AlertResolution AS A INNER JOIN
												 KYP.MDM_AlertPIUReferral AS B ON B.ResolutionID = A.ResolutionID AND A.ResolutionTypeID NOT IN (5, 6) AND ISNULL(A.IsDeleted, 0) = 0 INNER JOIN
												 KYP.OIS_Note AS C ON C.NoteID = B.ResolutionNoteID 
							UNION ALL
							
							SELECT     A.AlertID, A.ResolutionType, A.ResolutionTypeID, A.ProviderName, A.CreatedDate, B.ResolutionNoteID, C.UnformattedContent
							FROM         KYP.MDM_AlertResolution AS A INNER JOIN
												 KYP.MDM_AlertNewResolutions AS B ON B.ResolutionID = A.ResolutionID AND A.ResolutionTypeID NOT IN (5, 6) AND ISNULL(A.IsDeleted, 0) 
												 = 0 INNER JOIN
												 KYP.OIS_Note AS C ON C.NoteID = B.ResolutionNoteID 
				) AS Z INNER JOIN
	KYP.MDM_Alert AS Q ON Q.AlertID = Z.AlertID
) S


GO

