



CREATE VIEW [KYP].[v_GenericSearchApplicationTemp] AS
SELECT DISTINCT A.CaseID,A.PAN As Application,A.Number As Provider,A.DateReceived,
CASE WHEN A.WFMINorStep = 'PendINg Approval' THEN 'Approved'
	WHEN A.WFMINorStep = 'PendINg Rejection' THEN 'Rejected'
END AS ApplicationStatus,
A.ApplnType ,
A.Risk,
B.NormalizedRisk As CompositeRisk,
A.TypeDescription, 
T.ProviderTypeCode,
A.ProviderName,
D.NPI As ProviderNPI,
LTRIM(RTRIM(
STUFF(( SELECT ', ' + ISNULL(N.LegalName,'') + ',' + ISNULL(N.DBAName1,'') AS [text()]
   FROM KYP.PDM_Organization N INNER JOIN KYP.SDM_ApplicationParty M ON M.PartyID = N.PartyID AND M.IsActive = 1
   WHERE M.ApplicationID = E.ApplicationID
   FOR XML PATH('')),1,1,''))) AS AKAName,
CAST(
LTRIM(RTRIM(STUFF ((SELECT ', ' + ISNULL(Z.NPI,'')  AS [text()] FROM(
		SELECT Y.ApplicationID,CONVERT(VARCHAR,Y.NPI) AS NPI FROM(
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.Provider_NPI,'') AS NPI FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType = 'Provider' 
		LEFT JOIN KYP.ADM_Case A3 ON A3.CaseID = A2.CaseID AND ISNULL(A3.Provider_NPI,'0') != ''
		UNION 
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.NPI,'') AS NPI FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType = 'Provider' 
		LEFT JOIN KYP.PDM_Provider A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.NPI,'0') != ''		
		UNION
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.NPI,'') AS SSN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType IN('Provider Organization','Owner Organization') 
		LEFT JOIN KYP.PDM_Organization A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.NPI,'0') != ''
		UNION
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.NPI,'') AS SSN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1
		LEFT JOIN KYP.PDM_SecondaryNPI A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.NPI,'0') != ''
		
		)Y
		)Z WHERE (Z.ApplicationID = C.ApplicationID OR Z.ApplicationID = G.ApplicationID OR Z.ApplicationID = E.ApplicationID )
	FOR XML PATH('')),1,1,''))) AS VARCHAR(MAX)) AS NPI,
LTRIM(RTRIM(
STUFF ((SELECT ', ' + ISNULL(Z.SSN,'')  AS [text()] FROM(
		SELECT Y.ApplicationID,Y.SSN FROM(
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.Provider_SSN,'') AS SSN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType = 'Provider' 
		LEFT JOIN KYP.ADM_Case A3 ON A3.CaseID = A2.CaseID AND ISNULL(A3.Provider_SSN,'') != ''
		UNION 		
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.SSN,'') AS SSN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType IN('Provider Person','Owner Person','ManagINg Control Person') 
		LEFT JOIN KYP.PDM_Person A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.SSN,'') != ''
		)Y
		)Z WHERE (Z.ApplicationID = C.ApplicationID OR Z.ApplicationID = G.ApplicationID OR Z.ApplicationID = E.ApplicationID )
	FOR XML PATH('')),1,1,''))) AS SSN,
LTRIM(RTRIM(
STUFF ((SELECT ', ' + ISNULL(Z.TIN,'')  AS [text()] FROM(
		SELECT Y.ApplicationID,Y.TIN FROM(
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.Provider_TIN,'') AS TIN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType = 'Provider' 
		LEFT JOIN KYP.ADM_Case A3 ON A3.CaseID = A2.CaseID AND ISNULL(A3.Provider_TIN,'') != ''
		UNION 
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.TIN,'') AS TIN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType IN ('Provider Organization','Owner Organization') 
		LEFT JOIN KYP.PDM_Organization A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.TIN,'') != ''		
		UNION 
		SELECT DISTINCT A1.ApplicationID,ISNULL(A3.TaxId,'') AS TIN FROM KYP.SDM_ApplicationParty A1 INner joIN KYP.ADM_Application A2 
		ON A1.ApplicationID = A2.ApplicationID AND A1.IsActive = 1 AND A1.PartyType IN('Provider Person','Owner Person','ManagINg Control Person') 
		LEFT JOIN KYP.PDM_Person A3 ON A3.PartyID = A1.PartyID AND ISNULL(A3.TaxId,'') != ''
		)Y
		)Z WHERE (Z.ApplicationID = C.ApplicationID OR Z.ApplicationID = G.ApplicationID OR Z.ApplicationID = E.ApplicationID )
	FOR XML PATH('')),1,1,''))) AS TIN,	
LTRIM(RTRIM(
STUFF (( SELECT ', ' + ISNULL(J.License,'') AS [text()]
   FROM KYPEnrollment.PortalLicense J
   WHERE J.EnrolCaseID = B.CaseID
   FOR XML PATH('')),1,1,''))) AS LicenseCode,
LTRIM(RTRIM(   
STUFF (( SELECT ', ' + K.AddressLINe1 + ISNULL(K.AddressLINe1,'') AS [text()]
   FROM KYPEnrollment.PortalAddress K 
   WHERE (K.EnrollCaseID = A.CaseID AND K.Type = 'ServicINg') 
   FOR XML PATH('')),1,1,''))) AS Addresses,

LTRIM(RTRIM(   
STUFF (( SELECT ', ' + K.State AS [text()]
   FROM KYPEnrollment.PortalAddress K 
   WHERE (K.EnrollCaseID = A.CaseID AND K.Type = 'ServicINg') 
   FOR XML PATH('')),1,1,''))) AS State,

LTRIM(RTRIM(   
STUFF (( SELECT ', ' + K.City AS [text()]
   FROM KYPEnrollment.PortalAddress K 
   WHERE (K.EnrollCaseID = A.CaseID AND K.Type = 'ServicINg') 
   FOR XML PATH('')),1,1,''))) AS City,
   

LTRIM(RTRIM(   
STUFF (( SELECT ', ' + ISNULL(K.Zip,'') + '-' + ISNULL(K.ZipPlus4,'') AS [text()]
   FROM KYPEnrollment.PortalAddress K 
   WHERE (K.EnrollCaseID = A.CaseID AND K.Type = 'ServicINg') 
   FOR XML PATH('')),1,1,''))) AS Zip,
   


A.WFStatus,
(SELECT U.FullName FROM KYP.OIS_Person U WHERE U.PersonID = A.CurrentlyAssignedToID ) As Assignee,
A.CurrentlyAssignedToName As UserID,
A.MILESTONE,
A.P_PRACT_TY_CD As PracticeType,
A.DAYS_REMAINING,
A.DueDate


FROM KYP.ADM_Case A 
INNER JOIN KYP.ADM_Application B ON A.CaseID = B.CaseID AND A.IsPPURequired = 'false'
INNER JOIN KYP.SDM_ApplicationParty C ON C.ApplicationID = B.ApplicationID 
AND C.IsActive = 1 AND C.PartyType = 'Provider' 
LEFT JOIN KYP.PDM_Provider D ON D.PartyID = C.PartyID 
LEFT JOIN KYP.SDM_ApplicationParty E ON E.ApplicationID = B.ApplicationID
AND E.IsActive = 1 AND E.PartyType IN ('Provider Organization','Owner Organization') 
LEFT JOIN KYP.PDM_Organization F ON F.PartyID = E.PartyID
LEFT JOIN KYP.SDM_ApplicationParty G ON G.ApplicationID = B.ApplicationID
AND G.IsActive = 1 AND G.PartyType IN('Provider Person','Owner Person','ManagINg Control Person') 
LEFT JOIN KYP.PDM_Person H ON H.PartyID = G.PartyID
LEFT JOIN KYP.v_PDMProviderType T ON T.ProviderTypeDescription = A.TypeDescription


GO

