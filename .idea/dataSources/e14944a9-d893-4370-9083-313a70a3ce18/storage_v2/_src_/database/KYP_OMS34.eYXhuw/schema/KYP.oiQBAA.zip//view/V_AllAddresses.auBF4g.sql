
CREATE VIEW [KYP].[V_AllAddresses]
AS

	SELECT pAA.ApplicationNo,pPA.AddressID,pPA.AddressLine1--,pPA.City,pPA.Zip,pPA.ZipPlus4,pPA.State
	FROM [KYPPORTAL].[PortalKYP].[pPDM_ADDRESS] pPA
	INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Location] pPL ON pPA.AddressID = pPL.AddressID
	INNER JOIN [KYPPORTAL].[PortalKYP].[pADM_Application] pAA ON pAA.PartyID = pPL.PartyID
	--WHERE pAA.ApplicationNo = '165IFJRB'
	
	UNION 
	
	SELECT distinct AA.ApplicationNo,PA.AddressID,PA.AddressLine1--,PA.City,PA.Zip,PA.ZipPlus4,PA.State
	FROM KYP.PDM_Address PA 
	INNER JOIN KYP.PDM_Location PL ON PA.AddressID = PL.AddressID
	INNER JOIN KYP.SDM_ApplicationParty SAP ON PL.PartyID = SAP.PartyID
	INNER JOIN KYP.ADM_Application AA ON AA.ApplicationID = SAP.ApplicationID 
	--WHERE AA.ApplicationNo = '165IFJRB'


GO

