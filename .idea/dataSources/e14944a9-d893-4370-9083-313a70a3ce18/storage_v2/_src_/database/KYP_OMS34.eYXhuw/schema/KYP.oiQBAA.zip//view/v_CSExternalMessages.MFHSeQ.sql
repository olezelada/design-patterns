

CREATE VIEW [KYP].[v_CSExternalMessages] As
Select COALESCE(U.FromFullName,'') + COALESCE(('/'+CONVERT(VARCHAR,U.CreatedOn,101) + ' ' + RIGHT(CONVERT(CHAR(20), U.CreatedOn, 22), 11)),'') + COALESCE(('/' + U.ToUser),'') As From_Date_To,
		U.Subject,
		CASE WHEN M.UnformattedContent LIKE '<html><body>%' THEN Content ELSE UnformattedContent END
		As Content,
		CONVERT(VARCHAR,A.EntityID) AS CaseID
from KYP.OIS_UserMessage U 
INNER JOIN KYP.OIS_Messages M ON M.MessageID = U.MessageID AND M.Type = 'ExternalMessage' AND U.IsHomeScreen = 'false'
INNER JOIN KYP.OIS_MessageAssociation A ON M.MessageID = A.MessageID AND A.EntityName = 'ADM_Case'


GO

