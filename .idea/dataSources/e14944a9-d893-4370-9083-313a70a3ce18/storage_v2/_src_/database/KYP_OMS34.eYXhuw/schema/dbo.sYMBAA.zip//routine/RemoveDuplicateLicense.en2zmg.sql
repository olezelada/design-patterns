
-- =============================================
-- Author:		Sheetal
-- Create date: 08/04/2013
-- Description:	Remove the duplicate license codes generated
-- =============================================
CREATE PROCEDURE [dbo].[RemoveDuplicateLicense]
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	
	-- Truncating data from license backup table
	IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[KYP].[LicenseBackup]') AND type in (N'U'))
	begin
	--Truncate table KYP.LicenseBackup
		Delete from  KYP.LicenseBackup; --Changed the Truncate stat. to Delete for DB Security issue by Sundar on 26Mar2019
    END
    -- Inserting distinct records in backup table which are duplicated in PDM_License table
      
	insert into  KYP.LicenseBackup
	select distinct A.LicenseState,A.LicenseCode,A.LicenseAuthority,A.ExpiryDate,A.PartyID,null,null   from
	(
	select s.LicenseID, t.* 
	from KYP.pdm_License  s
	join (
		select Licensestate, LicenseAuthority,LicenseCode,expirydate,PartyID, count(*) as qty
		from KYP.PDM_License  
		group by Licensestate, LicenseAuthority,LicenseCode,expirydate,PartyID 
		having count(*) > 1 
	) t on s.Licensestate = t.Licensestate and s.LicenseAuthority = t.LicenseAuthority
	  and s.LicenseCode=t.LicenseCode and s.ExpiryDate =t.ExpiryDate and s.PartyID =t.PartyID) A 
	  
	 -- select * from  KYP.LicenseBackup
	 
	  
	 
UPDATE
     A
SET
    A.Datecreated = (select Top 1 Datecreated from KYP.PDM_License 
    where Licensestate = A.Licensestate and LicenseAuthority=A.LicenseAuthority 
    and expirydate =A.ExpiryDate and PartyID=A.PartyID order by DateCreated desc)
FROM
    KYP.LicenseBackup A
    JOIN
    KYP.PDM_License B ON A.Licensestate = B.Licensestate and A.LicenseAuthority=B.LicenseAuthority 
    and A.expirydate =B.ExpiryDate and A.PartyID=B.PartyID 

	  
	  
  --------Deleting records from PDM_License which are duplicates
  
  
    
delete from KYP.PDM_License  
where LicenseID in
(
select s.LicenseID 
from KYP.pdm_License  s
join (
    select Licensestate, LicenseAuthority,LicenseCode,expirydate,PartyID, count(*) as qty
    from KYP.PDM_License  
    group by Licensestate, LicenseAuthority,LicenseCode,expirydate,PartyID 
    having count(*) > 1
) t on isnull(s.Licensestate,'') = isnull(t.Licensestate,'') and isnull(s.LicenseAuthority,'') = isnull(t.LicenseAuthority,'')
  and isnull(s.LicenseCode,'')=isnull(t.LicenseCode,'') and isnull(s.ExpiryDate,'') =isnull(t.ExpiryDate,'') and s.PartyID =t.PartyID 
 )   
     
 
 -------------Inserting distinct records from backup table
 
 INSERT INTO [KYP].[PDM_License]
           ([PartyID],[LicenseState],[LicenseAuthority],[ExpiryDate],[LicenseCode],[DateCreated])
           
     
           select partyID,LicenseState,LicenseAuthority,ExpiryDate,LicenseCode,DateCreated from
           KYP.LicenseBackup
 
 
 

    
END

GO

