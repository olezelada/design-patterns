
CREATE PROCEDURE [KYP].[p_UpdatePDMEmployee] (
	@PartyID INT
	,@ProviderID INT
	,@Designation VARCHAR(25) = NULL
	,@FromDate SMALLDATETIME = NULL
	,@ThroughDate SMALLDATETIME = NULL
	,@DateReported DATETIME = NULL
	,@InformationSource VARCHAR(50) = NULL
	,@MedicareIDNo VARCHAR(25) = NULL
	,@PercentageControl INT = NULL
	,@ProvideContractService VARCHAR(5) = NULL
	,@TypeOfService VARCHAR(25) = NULL
	,@Remarks VARCHAR(250) = NULL
	,@CurrentModule SMALLINT = NULL
	,@CreatedBy INT = NULL
	,@DateCreated SMALLDATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified SMALLDATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted SMALLDATETIME = NULL
	,@IsDeleted BIT = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	IF (LTRIM(RTRIM(ISNULL(@Designation, '')))) = ''
	BEGIN
		SET @Designation = NULL;
	END

	IF ISNULL(@FromDate, '') = ''
	BEGIN
		SET @FromDate = NULL;
	END

	IF ISNULL(@ThroughDate, '') = ''
	BEGIN
		SET @ThroughDate = NULL;
	END

	IF ISNULL(@DateReported, '') = ''
	BEGIN
		SET @DateReported = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@InformationSource, '')))) = ''
	BEGIN
		SET @InformationSource = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@MedicareIDNo, '')))) = ''
	BEGIN
		SET @MedicareIDNo = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@PercentageControl, '')))) = ''
	BEGIN
		SET @PercentageControl = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@ProvideContractService, '')))) = ''
	BEGIN
		SET @ProvideContractService = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@TypeOfService, '')))) = ''
	BEGIN
		SET @TypeOfService = NULL;
	END

	IF (LTRIM(RTRIM(ISNULL(@Remarks, '')))) = ''
	BEGIN
		SET @Remarks = NULL;
	END

	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END

	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END

	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END

	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END

	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END

	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END

	IF ISNULL(@IsDeleted, '') = ''
	BEGIN
		SET @IsDeleted = NULL;
	END
	
	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_Employee] Set '

	IF @Designation IS NOT NULL
		SET @updatelist = '[Designation] = ''' + replace(@Designation, '''', CHAR(39) + CHAR(39)) + ''''

	IF @FromDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[FromDate] = ''' + convert(VARCHAR(25), @FromDate, 121) + ''''
		ELSE
			SET @updatelist = '[FromDate] = ''' + convert(VARCHAR(25), @FromDate, 121) + ''''
	END

	IF @ThroughDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ThroughDate] = ''' + convert(VARCHAR(25), @ThroughDate, 121) + ''''
		ELSE
			SET @updatelist = '[ThroughDate] = ''' + convert(VARCHAR(25), @ThroughDate, 121) + ''''
	END

	IF @DateReported IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateReported] = ''' + convert(VARCHAR(25), @DateReported, 121) + ''''
		ELSE
			SET @updatelist = '[DateReported] = ''' + convert(VARCHAR(25), @DateReported, 121) + ''''
	END

	IF @InformationSource IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[InformationSource] = ''' + replace(@InformationSource, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[InformationSource] = ''' + replace(@InformationSource, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @MedicareIDNo IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[MedicareIDNo] = ''' + replace(@MedicareIDNo, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[MedicareIDNo] = ''' + replace(@MedicareIDNo, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @PercentageControl IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PercentageControl] = ' + Convert(VARCHAR(10), @PercentageControl)
		ELSE
			SET @updatelist = '[PercentageControl] = ' + Convert(VARCHAR(10), @PercentageControl)
	END

	IF @ProvideContractService IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProvideContractService] = ''' + replace(@ProvideContractService, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[ProvideContractService] = ''' + replace(@ProvideContractService, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @TypeOfService IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[TypeOfService] = ''' + replace(@TypeOfService, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[TypeOfService] = ''' + replace(@TypeOfService, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @Remarks IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Remarks] = ''' + replace(@Remarks, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID) + ' and  ProviderID=' + Convert(VARCHAR(10), @ProviderID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

