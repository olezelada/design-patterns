





CREATE TRIGGER [KYPEnrollment].[AccountHistory_MadeChange_Account] ON [KYPEnrollment].[pADM_Account]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
BEGIN


	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF @Row_Updation_Source IN ( 'KYP.p_UpdateAlertonAccount' ,'KYPEnrollment.SP_SuperUserHistory') AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	


Declare @changed 	varchar(500), 
 @oldValues 		varchar(500), 
 @newValues 		varchar(500), 
 @first 			bit,
 @oldValue 			varchar(500),
 @newValue  		varchar(500),
 @changeExists 		bit, 
 @connector 		varchar(1),
 @AccountID 		int,
 @HistoryID 		int,
 @LastActorUserID 	varchar(100),
 @ModifiedDate 		smalldatetime,
 @IsDeleted			bit;

Select @IsDeleted = IsDeleted, @ModifiedDate = LastActionDate, @LastActorUserID = LastActorUserID from inserted;

set @first = 1;
set @changed = '';
set @oldValues = '';
set @newValues = '';
set @connector = '';
--set @AccountID = (Select AccountID from inserted);
select @AccountID = AccountID from inserted;
if update(IsDeleted) and @isDeleted = 0 
--Change is considerated that Account is getting created.
--Created Account event.
	BEGIN
    		Declare @ApplicationNumber varchar(15)
                  , @IncorporatedDate  smalldatetime
                  , @StatusAcc varchar(25)
                  , @CreatedBy varchar(100);

					Select @ApplicationNumber = ApplicationNumber, @AccountID = AccountID,
                    	@IncorporatedDate = IncorporatedDate, @StatusAcc = StatusAcc,
                        @CreatedBy = CreatedBy from inserted;
                  
                  PRINT @ApplicationNumber +' '/*+@IncorporatedDate*/+' '+@StatusAcc

              INSERT INTO 
                KYPEnrollment.pAccount_History
              (
                AccountID,
                ActionID,
                DateCreated,
                IsDeleted,
                LastActorUserID,
                LastActionDate
              ) 
              VALUES (
                 @AccountID,
                 50,
                getdate(),
                0,
                @CreatedBy,
                getdate()  
              );
              set @HistoryID = (SELECT SCOPE_IDENTITY());
              print @HistoryID
              INSERT INTO 
                KYPEnrollment.HIS_ApplicationHistory
              (
                HistoryID,
                AccountStatus,
                DateCreate,
                AplicationNumber
              ) 
              VALUES (
                  @HistoryID,
                  @StatusAcc,
                  getdate(),
                  @ApplicationNumber
              );
	END
ELSE
--Change is considerated a Made Change
--Made Change event
	BEGIN
          	
      /*if update(StatusAcc )
              set @oldValue = (Select isnull(StatusAcc,'none') from deleted)
              set @newValue = (Select isnull(StatusAcc,'none') from inserted)
              if(@oldValue <> @newValue)
                  begin
                      set @changed 	= @changed+'Status'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector 	= '|';
                  end
     if update(ActivationDate)
          Begin
              set @oldValue = (Select isnull(left(convert(varchar,ActivationDate,103),10),'none') from deleted)
              set @newValue = (Select isnull(left(convert(varchar,ActivationDate,103),10),'none') from inserted)  
              if(@oldValue <> @newValue)
                  begin
                      set @changed = @changed+@connector+'Activation Date'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector = '|';
                  end
          End 
          
      if update(DeactivationDate)
          Begin
              set @oldValue = (Select isnull(left(convert(varchar,DeactivationDate,103),10),'none') from deleted)
              set @newValue = (Select isnull(left(convert(varchar,DeactivationDate,103),10),'none') from inserted)  
              if(@oldValue <> @newValue)
                  begin
                      set @changed = @changed+@connector+'Deactivation Date'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector = '|';
                  end
          End 
      if update(StatusReasonCode)
          Begin
              set @oldValue = (Select isnull(StatusReasonCode,'none') from deleted)
              set @newValue = (Select isnull(StatusReasonCode,'none') from inserted)  
              if(@oldValue <> @newValue)
                  begin
                      set @changed = @changed+@connector+'Status Reason Code'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector = '|';
                  end
          End
      if update(StatusBeginDate)
          Begin
              set @oldValue = (Select isnull(left(convert(varchar,StatusBeginDate,103),10),'none') from deleted)
              set @newValue = (Select isnull(left(convert(varchar,StatusBeginDate,103),10),'none') from inserted)  
              if(@oldValue <> @newValue)
                  begin
                      set @changed = @changed+@connector+'Status Code Begin Date'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector = '|';
                  end
          End
      /*
      if update(SpecProcTypeCodeDesc )
              set @oldValue = (Select isnull(SpecProcTypeCodeDesc,'none') from deleted)
              set @newValue = (Select isnull(SpecProcTypeCodeDesc,'none') from inserted)
              if(@oldValue <> @newValue)
                  begin
                      set @changed 	= @changed+'Specialty Processing Type Code'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector 	= '|';
                  end
      if update(ProvisionalCodeDate)
          Begin
              set @oldValue = (Select isnull(left(convert(varchar,ProvisionalCodeDate,103),10),'none') from deleted)
              set @newValue = (Select isnull(left(convert(varchar,ProvisionalCodeDate,103),10),'none') from inserted)  
              if(@oldValue <> @newValue)
                  begin
                      set @changed = @changed+@connector+'Provisional Code Begin Date'
                      set @oldValues 	= @oldValues+@connector+@oldValue
                      set @newValues 	= @newValues+@connector+@newValue
                      set @connector = '|';
                  end
          End 
      */
      */
      --Verify if Internal Use Data is happening on Account or not.
      if (@AccountID>0 and @changed<>'')
          BEGIN
          
          
                 
          print @changed
          print @oldValues
          print @newValues
          
            INSERT INTO 
              KYPEnrollment.pAccount_History
              (
                AccountID,
                ActionID,
                DateCreated,
                IsDeleted,
                LastActorUserID,
                LastActionDate
              ) 
              VALUES (
                 @AccountID,
                 43,
                getdate(),
                0,
                @LastActorUserID,
                getdate()  
              )
              
              
              set @HistoryID = (SELECT SCOPE_IDENTITY());
              print @HistoryID

          
          
          INSERT INTO 
              KYPEnrollment.HIS_MadeChange
            (
              HistoryID,
              Field,
              NewValue,
              DateCreate,
              OldValue
            ) 
            VALUES (
              @HistoryID,
              @changed,
              @newValues,
              getDate(),
              @oldValues
             )
          END
	END
END


GO

