
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar organization recive 3 para metros
-- id de la organizacion, el nuevo party id y el nombre del usuario
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Organization]
	@orgID INT,
	@newPartyId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
	(PartyID ,
	OrgNumber ,
	OrgCategory ,
	TIN ,
	PrimaryDUNS ,
	LegalName ,
	DBAName1 ,
	DBAName2 ,
	IncTyp ,
	IncState ,
	IncDate ,
	ForeginOwned ,
	Email1 ,
	Phone1 ,
	Email2 ,
	Phone2 ,
	Remarks ,
	[LastAction] ,	
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy] ,
	[CurrentRecordFlag] ,
	Fax ,
	NPI ,
	License ,
	EIN ,
	Medicaid ,
	DEA ,
	Sellers ,
	IsCorporation ,
	Extension)
	SELECT @newPartyId
	,[OrgNumber]
	,[OrgCategory]
	,[TIN]
	,[PrimaryDUNS]
	,[LegalName]
	,[DBAName1]
	,[DBAName2]
	,[IncTyp]
	,[IncState]
	,[IncDate]
	,[ForeginOwned]
	,[Email1]
	,[Phone1]
	,[Email2]
	,[Phone2]
	,[Remarks]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	,[Fax]
	,[NPI]
	,[License]
	,[EIN]
	,[Medicaid]
	,[DEA]
	,[Sellers]
	,[IsCorporation]
	,[Extension]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] WHERE OrgID = @orgID

	SELECT @message = '[pAccount_PDM_Organization] @newOrgID : ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT				
END


GO

