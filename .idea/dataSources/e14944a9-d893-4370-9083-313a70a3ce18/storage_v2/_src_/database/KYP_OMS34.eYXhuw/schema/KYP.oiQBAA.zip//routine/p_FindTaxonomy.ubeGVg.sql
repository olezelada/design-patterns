


-- =============================================
-- Author:		Nitish Gondkar
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[p_FindTaxonomy] 	
	@PartyID INT,
	@Taxonomy VARCHAR(20),
	@Taxonomy_NPI VARCHAR(10)
AS
BEGIN
SET NOCOUNT ON;
	DECLARE @TAXNID INT;
	
	IF EXISTS(SELECT 1 FROM KYP.PDM_Taxonomy WHERE PartyID = @PartyID AND Taxonomy = @Taxonomy)
	BEGIN
		SELECT @TAXNID = TaxonomyID FROM KYP.PDM_Taxonomy 
		WHERE PartyID = @PartyID 
		AND Taxonomy = @Taxonomy 
		AND NPI = @Taxonomy_NPI
		return @TAXNID
	END
	ELSE
	return -1
	
END


GO

