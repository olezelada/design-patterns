-- =============================================
-- Author:		<Author, hbustamante>
-- Create date: <02/28/2019>
-- Description:	<this procedure UPDATE or DELETED peer coaches records from app into account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Peer_Coach]
	-- Add the parameters for the stored procedure here
	@acc_party_id INT,
  @action_taken VARCHAR(50),
  @last_action_user_id VARCHAR(100),
  @target_path VARCHAR(200),
  @en_db_column VARCHAR(100),
  @data VARCHAR(MAX),
  @acc_PK VARCHAR(100),
  @acc_PK_value INT,
  @is_text_date CHAR(1),
  @acc_table_name varchar(100),
  @applicationId INT,
  @app_party_id INT
AS
BEGIN
SET NOCOUNT ON;
DECLARE @account_id INT, @app_coach_id INT,  @coach_party_id INT, @new_party_coach INT;
IF @action_taken='Added' AND @target_path NOT LIKE '%pAccount_PDM%'
BEGIN
  SELECT @app_coach_id = PersonID, @coach_party_id = PartyID FROM KYPPORTAL.PORTALKYP.pPDM_Person WHERE TargetPath = @target_path;

  IF not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_coach_id AND NameTable='pAccount_PDM_Person')
  BEGIN
    PRINT @action_taken;
    SELECT @account_id = AccountID FROM KYPEnrollment.pADM_Account WHERE PartyID = @acc_party_id;
    EXEC @new_party_coach = [KYPEnrollment].[sp_Copy_Party] @coach_party_id
															, @acc_party_id
															, @account_Id
															, @last_action_user_id;

		-- Creating new coach (Person) in account
		EXEC [KYPEnrollment].[sp_Copy_Person] @new_party_coach
											  , @coach_party_id
											  , @last_action_user_id
											  , 'C';

    --INSERT INTO [KYPEnrollment].[Control_Add_row](FiledID,NameTable)
    INSERT INTO #Control_Add_row(FiledID,NameTable)
    VALUES(@app_coach_id,'pAccount_PDM_Person');
  END
END

IF @action_taken='Updated' AND @target_path LIKE '%pAccount_PDM%'
BEGIN
  PRINT @action_taken;
  EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_Person',@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
END

IF @action_taken='Deleted'
BEGIN
  PRINT @action_taken;
  UPDATE [KYPEnrollment].[pAccount_PDM_Person] SET CurrentRecordFlag = 0 WHERE PersonID = @acc_PK_value;
END

END
GO

