

CREATE PROCEDURE [KYPEnrollment].[sp_Update_State_Hospital]
  @party_id_provider INT,
  @account_party_id INT,
  @last_action_user_id varchar(50),
  @en_db_column        VARCHAR(100),
  @new_value_text      VARCHAR(250),
  @section_name      VARCHAR(250)
AS
BEGIN

	 IF NOT EXISTS (SELECT NumberID FROM KYPEnrollment.pAccount_PDM_Number WHERE PartyID = @account_party_id AND Type='LabHospital' AND IsDeleted=0)
   BEGIN
      EXEC [KYPEnrollment].[Copy_Twin_Number] @account_party_id, @party_id_provider, @last_action_user_id, 'LabHospital';
   END

    EXEC [KYPEnrollment].[sp_Create_Update_Especial_Clia]
                                                @en_db_column
                                                ,@last_action_user_id
                                                ,@account_party_id
                                                ,@new_value_text
                                                ,@section_name

  IF NOT EXISTS (SELECT ReasonID FROM pAccount_PDM_ReasonEnrollment WHERE PartyID = @account_party_id AND CurrentRecordFlag=1 AND IsDeleted=0)
  BEGIN
    EXEC [KYPEnrollment].[sp_Copy_ReasonEnrollment] @account_party_id, @party_id_provider,@last_action_user_id;
  END

END


GO

