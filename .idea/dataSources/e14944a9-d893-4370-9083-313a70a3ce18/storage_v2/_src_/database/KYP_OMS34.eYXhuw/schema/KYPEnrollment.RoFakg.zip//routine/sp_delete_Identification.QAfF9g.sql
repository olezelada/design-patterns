
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to Identification section of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Identification] 
@new_Account_Id int

AS
BEGIN
Declare @person int,@document int,@othername int,
@tot int,@cont int,@add int
DECLARE @othernames table (pk int identity(1,1),oid int)
SET NOCOUNT ON;

update o set CurrentRecordFlag=0,IsDeleted=1
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON pe.PartyID=p.PartyID INNER JOIN KYPEnrollment.pAccount_PDM_Person_OtherName o ON o.PersonID=pe.PersonID
where a.AccountID=@new_Account_Id and pe.CurrentRecordFlag=1 and o.CurrentRecordFlag=1 and o.IsDeleted=0  

update pe set CurrentRecordFlag=0, Deleted=1
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON pe.PartyID=p.PartyID
where a.AccountID=@new_Account_Id and pe.CurrentRecordFlag=1


update d set CurrentRecordFlag=0,IsDeleted=1
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Document d ON d.PartyID=p.PartyID 
where a.AccountID=@new_Account_Id and d.CurrentRecordFlag=1 and d.IsDeleted=0




END
GO

