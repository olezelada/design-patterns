
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Person]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@lastAction VARCHAR(1)=NULL

AS
BEGIN
SET NOCOUNT ON 
DECLARE @person_id INT,@date_created DATE;
SET @date_created =  GETDATE();
INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
          ([PartyID]
           ,[SSN]
           ,[FirstName]
           ,[LastName]
           ,[MiddleName]
           ,[Gender]
           ,[DoB]
           ,[Email1]
           ,[Remark]
           ,[CreatedBy]
           ,[Prefix]
           ,[Sufix]
           ,[ProfessionalTitle]
           ,[DateCreated]
           ,[Position]
           ,[Extension]
           ,[Phone1]
           ,[Phone2]
           ,[FaxNumber]
           ,[Deleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[Salutation]
           ,[NPI]
           ,[Alias1])

SELECT @party_account_id,
	    [SSN],
		[FirstName],
		[LastName],
		[MiddleName],
		[Gender],
		[DoB],
		[Email1],
		[Remark],
		[CreatedBy],
		[Prefix],
		[Sufix],
		[ProfessionalTitle],
		@date_created,
		[Position],
		[Extension],
		[Phone1],
		[Phone2],
		[FaxNumber],
		[Deleted],
        @lastAction,
        @date_created,
        @last_action_user_id,
        @last_action_user_id,
		1,
		ProfessionalTitle,
		[NPI],
		[Alias1]

FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] WHERE PartyID=@party_app_id;

SELECT @person_id = SCOPE_IDENTITY();  
RETURN @person_id;
END

GO

