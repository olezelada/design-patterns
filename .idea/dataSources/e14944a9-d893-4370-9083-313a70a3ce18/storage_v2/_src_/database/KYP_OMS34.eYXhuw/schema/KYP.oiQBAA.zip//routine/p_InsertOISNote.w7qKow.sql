



	CREATE procedure [KYP].[p_InsertOISNote]
	(
	 @UserID varchar(100) ,
	 @Name varchar(8000),
	 @Type varchar(150),
	 @SubType varchar(100),
	 @ParentID int,
	 @DateCreated smalldatetime,
	 @Author varchar(150),
	 @RelatedEntityType varchar(150),
	 @Content varchar(MAX),
	 @UnformattedContent varchar(MAX),
	 @Number varchar(100),
	 @VersionNo int,
	 @isWorkpaper bit,
	 @isAcknowledged bit,
	 @WorkflowName varchar(100),
	 @isAdverse bit,
	 @Deleted bit,
	 @DeletedOn datetime,
	 @DeletedBy varchar(100),
	 @DeletedByUserID varchar(100),
	 @UpdatedOn datetime,
	 @UpdatedBy varchar(100),
	 @UpdatedByUserID varchar(100),
	 @IsImportant bit,
	 @IsLastVersion bit,
	 @IsSticky bit,
	 @IsReferenced bit,
	 @HasComments bit,
	 @HasDocuments bit,
	 @NumberSchemaInfo varchar(100),
	 @LastVersion varchar(50),
	 @AllowComments bit,
	 @RestoredBy varchar(100),
	 @RestoredByUserID varchar(100),
	 @CaseID int,
	 @AlertID int,
	 @IncidentID int,
	 @Tags varchar(100),
	 @FullDateCreated datetime,
	 @RelatedEntityID varchar(100),
	 @Importance varchar(50),
	 @Score int,
	 @DMSID varchar(200),
	 @DocumentCount int,
	 @MultipleCaseID varchar(500),
	 @MultipleTrackingNo varchar(500),
	 @PInID int /*App Review added @PInID*/

	 
	)
	as begin 
	BEGIN TRY
	PRINT 'Detect'
print @CaseID	
	

		INSERT INTO [KYP].[OIS_Note]
				   ([UserID],[Name],[Type],[SubType],[ParentID],[DateCreated],[Author],[RelatedEntityType]
				   ,[Content],[UnformattedContent],[Number],[VersionNo],[isWorkpaper],[isAcknowledged]
				   ,[WorkflowName],[isAdverse],[Deleted],[DeletedOn],[DeletedBy],[DeletedByUserID]
				   ,[UpdatedOn],[UpdatedBy],[UpdatedByUserID],[IsImportant],[IsLastVersion],[IsSticky]
				   ,[IsReferenced],[HasComments],[HasDocuments],[NumberSchemaInfo],[LastVersion],[AllowComments]
				   ,[RestoredBy],[RestoredByUserID],[CaseID],[AlertID],[IncidentID],[Tags],[FullDateCreated]
				   ,[RelatedEntityID],[Importance],[Score],[DMSID],[DocumentCount],[ReasonCode],[ExclusionYesNO]
				   ,[PInID],[LastActionDate],Row_Updation_Source  )/*App Review added @PInID*/
			 VALUES
				   (@UserID
				   ,@Name
				   ,@Type
				   ,@SubType
				   ,@ParentID
				   ,@DateCreated
				   ,@Author
				   ,@RelatedEntityType
				   ,@Content
				   ,@UnformattedContent
				   ,@Number
				   ,@VersionNo
				   ,@isWorkpaper
				   ,@isAcknowledged
				   ,@WorkflowName
				   ,@isAdverse
				   ,@Deleted
				   ,@DeletedOn
				   ,@DeletedBy
				   ,@DeletedByUserID
				   ,@UpdatedOn
				   ,@UpdatedBy
				   ,@UpdatedByUserID
				   ,@IsImportant
				   ,@IsLastVersion
				   ,@IsSticky
				   ,@IsReferenced
				   ,@HasComments
				   ,@HasDocuments
				   ,@NumberSchemaInfo
				   ,@LastVersion
				   ,@AllowComments
				   ,@RestoredBy
				   ,@RestoredByUserID
				   ,@CaseID
				   ,@AlertID
				   ,@IncidentID
				   ,@Tags
				   ,@FullDateCreated
				   ,@RelatedEntityID
				   ,@Importance
				   ,@Score
				   ,@DMSID
				   ,@DocumentCount,
				   @MultipleCaseID,
				   @MultipleTrackingNo,
				   @PInID,
				   GETDATE(),
				   'KYP.p_InsertOISNote'
				   
				   )/*App Review added @PInID*/

			--return IDENT_CURRENT('[KYP].[OIS_Note]')
			return SCOPE_IDENTITY()
		END TRY
	BEGIN CATCH
				IF @@TranCount>0
					Rollback Transaction;	
						
				Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'CaseID',@KeyValue = @CaseID;
		END CATCH
		
end


  GO

