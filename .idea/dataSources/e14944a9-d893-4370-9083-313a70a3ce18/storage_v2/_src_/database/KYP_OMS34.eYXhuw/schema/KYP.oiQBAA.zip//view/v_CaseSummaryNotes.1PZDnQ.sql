








CREATE VIEW [KYP].[v_CaseSummaryNotes] AS
SELECT Y.ID, Y.CaseID,Y.NOTE_TYPE,Y.Title,Y.RelatedEntityType,Y.AddedBy_On,Y.Description FROM(
	SELECT ROW_NUMBER() OVER(ORDER BY X.NoteID DESC) ID,X.* FROM( 
		SELECT DISTINCT CONVERT(VARCHAR,C.CaseID) AS CaseID,
		COALESCE(N.Number,'') + COALESCE(('/'+N.Type),'') AS NOTE_TYPE,
		N.Name AS Title,
		ISNULL(CONVERT(VARCHAR,N.UnformattedContent),N.Name) AS Description,RelatedEntityType,
		COALESCE(N.Author,'') + COALESCE(('/'+CONVERT(VARCHAR,N.DateCreated,101) + ' ' + RIGHT(CONVERT(CHAR(20), N.DateCreated, 22), 11)),'') AS AddedBy_On	
		,N.DateCreated
		,N.NoteID 
		FROM KYP.OIS_Note N INNER JOIN KYP.NoteEntity E ON N.Number = E.NoteNumber 
		INNER JOIN KYP.ADM_Case C ON C.CaseID = E.NoteEntityTypeID
		WHERE ISNULL(E.NoteNumber,'') <> '' AND N.Name NOT IN ('TempNoteForDocFW') AND N.Deleted = 'false' AND N.IsLastVersion = 'true'
		AND E.NoteEntityType = 'ADM_Case'
		AND E.NoteEntityType NOT IN ('MDM_Alert', 'MDM_AlertNewResolution', 'MDM_AlertOIGReferral', 'MDM_AlertPvdSuspension', 'MDM_AlertPIUReferral')
		
		
	)X
)Y


GO

