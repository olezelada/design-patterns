

CREATE VIEW [KYP].[v_CaseSummaryScreenResultAnnexure] AS

SELECT X.* FROM(
Select DISTINCT CONVERT(VARCHAR,P.ScreeningID)As ScreeningID, CONVERT(VARCHAR,P.PartyID) As PartyID,
 CONVERT(VARCHAR,A.CaseID) As CaseID, B.Name As PartyName,B.Type As PartyType,P.PartyType As Type,CONVERT(VARCHAR,ISNULL(P.NormalizedRisk,0)) As RiskScore,
	   ISNULL(CONVERT(VARCHAR,cNegative),'0') As NegCount
	   ,ISNULL(CONVERT(VARCHAR,cPositive),'0') As PosCount,
	   ISNULL(CONVERT(VARCHAR,RedFlag),'0') As RFCount,
	   convert(varchar(10),P.DateCreated,101) [ScreenedOn]
	   
FROM KYP.SDM_ApplicationParty P INNER JOIN KYP.ADM_Application A ON A.ApplicationID = P.ApplicationID AND IsActive = 1 AND ISNULL(CrossOverApp,'')<>'X'
			  INNER JOIN KYP.PDM_Party B ON P.PartyID = B.PartyID
			  LEFT JOIN KYP.[v_SumofPartyNegChkResult] N ON N.PartyID = P.PartyID AND N.ApplicationID = P.ApplicationID 
			  LEFT JOIN KYP.[v_SumofPartyTrueChkResult] T ON T.PartyID = P.PartyID AND T.ApplicationID = P.ApplicationID 
			  LEFT JOIN [KYP].[v_PartyTotalRedFlags] R ON R.PartyID = P.PartyID AND R.ApplicationID = P.ApplicationID  
			  --where P.Tag in ('New','Updated')
)X


GO

