/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Unique Party Account.   
-- PARAMETERS: 
-- @accountId : AccountID to new Account that will be create. 
-- @uniquePartyID : UniquePartyID to Account. 
-- @currentFlag : Flag for history,default values is true. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Create_UniquePartyAccount]
	@accountId INT,
	@uniquePartyID INT,
	@currentFlag BIT
AS
BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_Account]
	([AccountID]
	,[UniquePartyID]
	,[CurrentRecordFlag])
	VALUES
	(@accountId
	,@uniquePartyID
	,@currentFlag)
END


GO

