CREATE VIEW [KYP].[v_Inner_Alerts_MTD_Tracking]
AS

SELECT TOP (100) PERCENT

 row_number() OVER (ORDER BY A.YearNo ASC) AS ID,
 
A.YearNo, 
A.MonthNo,
A.Specialty,
A.ProvidersRecieved,
ISNull(B.Nbr,0) as TotalAlerts, 
ISNull(C.[ConfirmedAlerts],0) as [ConfirmedAlerts],
ISNull(C.[FalsePositives],0) as [FalsePositives], 
ISNull(C.[IgnoredAlerts],0) as [IgnoredAlerts],
ISNull(D.[SanctionAlerts],0) as [SanctionAlerts],
ISNull(D.[LicensureAlerts],0) as  [LicensureAlerts], 
ISNull(D.[DemographicAlerts],0) as [DemographicAlerts],
ISNull(E.Nbr,0) as [ActionTakenOn]


FROM


(
	select 
		  datepart(year, LastLoadDate) as YearNo
		  ,datepart(month, LastLoadDate) as MonthNo
		  ,Pvd.PrimarySpecialty as Specialty
		  ,count(distinct Pvd.PartyID) as ProvidersRecieved 
		  from 
		  KYP.PDM_Party Prty
		  INNER JOIN KYP.PDM_Provider Pvd ON  
				Prty.PartyID= Pvd.PartyID AND ISNULL(Prty.IsDeleted,0)=0 AND ISNULL(Pvd.IsDeleted,0)=0
				AND Prty.IsProvider=1 
				AND Prty.CurrentModule=2
		  Group By datepart(year, LastLoadDate), datepart(month, LastLoadDate),Pvd.PrimarySpecialty
)A

LEFT JOIN

(
	select 
		datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
		datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
		MDM_Alert_AllMonths.PrimarySpecialty as Specialty,
		count(distinct alertid) as Nbr
	from
	(

				select alertid, dateinitiated, PrimarySpecialty from 
					(
					select 
						A.alertid, 
						A.DateInitiated,
						A.MatchStatusIndicator,
						A.WatchlistName,
						COALESCE(C.ProvID,D.ProviderID, E.ProviderID,NULL) as ProviderID
					from KYP.MDM_Alert A
					INNER JOIN KYP.PDM_Party B
						ON A.WatchedPartyId=B.PartyId and B.CurrentModule=2 and ISNULL(A.IsDeleted,0) = 0  and ISNULL(B.IsDeleted,0) = 0 
					LEFT JOIN KYP.PDM_Provider C
						ON B.PartyID=C.PartyID and ISNULL(C.IsDeleted,0) = 0
					LEFT JOIN KYP.PDM_Employee D
						ON B.PartyID=D.PartyID and ISNULL(D.IsDeleted,0) = 0
					LEFT JOIN KYP.PDM_Owner E 
						ON B.PartyID=E.PartyID and ISNULL(E.IsDeleted,0) = 0
					)X 

					LEFT JOIN KYP.PDM_Provider Y
						ON X.ProviderID = Y.ProvID
							
				union
				select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty
	) MDM_Alert_AllMonths
	group by 
	datepart(year, MDM_Alert_AllMonths.DateInitiated), 
	datepart(month, MDM_Alert_AllMonths.DateInitiated),
	MDM_Alert_AllMonths.PrimarySpecialty
) B

ON A.YearNo= B.YearNo
AND A.MonthNo = B.MonthNo
AND A.Specialty = B.Specialty

LEFT JOIN

(
	SELECT YearNo,MonthNo,PrimarySpecialty as Specialty, [ConfirmedAlerts],[FalsePositives], [IgnoredAlerts]
	FROM
	(
		select YearNo,MonthNo,PrimarySpecialty, MatchStatusIndicator, Nbr from 
		(
			select 
				datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
				datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
				PrimarySpecialty,
				MDM_Alert_AllMonths.MatchStatusIndicator,
				count(distinct alertid) as Nbr
			from
			(
				select 
				alertid, 
				dateinitiated,
				PrimarySpecialty,
				case 
					when MatchStatusIndicator = 'C' 
					then 'ConfirmedAlerts'
					when MatchStatusIndicator = 'I' 
					then 'IgnoredAlerts'
					when MatchStatusIndicator = 'F' 
					then 'FalsePositives'
				end as MatchStatusIndicator

				from (						

						select alertid, dateinitiated,PrimarySpecialty,MatchStatusIndicator from 
											(
											select 
												A.alertid, 
												A.DateInitiated,
												A.MatchStatusIndicator,
												A.WatchlistName,
												COALESCE(C.ProvID,D.ProviderID, E.ProviderID,NULL) as ProviderID
											from KYP.MDM_Alert A
											INNER JOIN KYP.PDM_Party B
												ON A.WatchedPartyId=B.PartyId and B.CurrentModule=2 and ISNULL(A.IsDeleted,0) = 0  and ISNULL(B.IsDeleted,0) = 0 
											LEFT JOIN KYP.PDM_Provider C
												ON B.PartyID=C.PartyID and ISNULL(C.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Employee D
												ON B.PartyID=D.PartyID and ISNULL(D.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Owner E 
												ON B.PartyID=E.PartyID and ISNULL(E.IsDeleted,0) = 0
											)X 

											LEFT JOIN KYP.PDM_Provider Y
												ON X.ProviderID = Y.ProvID
							where MatchStatusIndicator in ('C','I','F')

						union
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'I' as MatchStatusIndicator
						union
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'F' as MatchStatusIndicator
				) MDM_Alert
			) MDM_Alert_AllMonths
			group by 
			datepart(year, MDM_Alert_AllMonths.DateInitiated), 
			datepart(month, MDM_Alert_AllMonths.DateInitiated),
			MDM_Alert_AllMonths.PrimarySpecialty ,
			MDM_Alert_AllMonths.MatchStatusIndicator
		) AlertMatch_Year_Mnth
	) AS SourceTable
	PIVOT
	(
	MAX(Nbr)
	FOR MatchStatusIndicator IN ([ConfirmedAlerts],[FalsePositives], [IgnoredAlerts])
	) AS PivotTable
)C

ON A.YearNo= C.YearNo
AND A.MonthNo = C.MonthNo
AND A.Specialty = C.Specialty

LEFT JOIN 


(
	SELECT YearNo,MonthNo,PrimarySpecialty as Specialty,[SanctionAlerts],[LicensureAlerts], [DemographicAlerts]
	FROM
	(
		select YearNo,MonthNo,PrimarySpecialty, WatchlistName, Nbr  from 
		(
			select 
				datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo,
				datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo,
				PrimarySpecialty,
				MDM_Alert_AllMonths.WatchlistName,
				count(distinct MDM_Alert_AllMonths.alertid) as Nbr
			from
			(
				select 
				alertid, 
				dateinitiated,
				PrimarySpecialty,
				case 
					when WatchListName in ('OIG LEIE', 'GSA EPLS', 'Individual Sanctions', 'Organization Sanctions','SanctionAlerts')
					then 'SanctionAlerts'
					when WatchListName in ('Licensure','Individual NPI','Individual DEA','Organization NPI','Organization DEA','LicensureAlerts')
					then 'LicensureAlerts'
					when WatchListName in ('SSN Fraud','SSA DMF','Sex Offenders','DemographicAlerts')
					then 'DemographicAlerts'
				end as WatchlistName

				from (

						select alertid, dateinitiated,PrimarySpecialty,WatchlistName from 
											(
											select 
												A.alertid, 
												A.DateInitiated,
												A.MatchStatusIndicator,
												A.WatchlistName,
												COALESCE(C.ProvID,D.ProviderID, E.ProviderID,NULL) as ProviderID
											from KYP.MDM_Alert A
											INNER JOIN KYP.PDM_Party B
												ON A.WatchedPartyId=B.PartyId and B.CurrentModule=2 and ISNULL(A.IsDeleted,0) = 0  and ISNULL(B.IsDeleted,0) = 0 
											LEFT JOIN KYP.PDM_Provider C
												ON B.PartyID=C.PartyID and ISNULL(C.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Employee D
												ON B.PartyID=D.PartyID and ISNULL(D.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Owner E 
												ON B.PartyID=E.PartyID and ISNULL(E.IsDeleted,0) = 0
											)X 

											LEFT JOIN KYP.PDM_Provider Y
												ON X.ProviderID = Y.ProvID

						union
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'SanctionAlerts' as WatchlistName
						union 
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'LicensureAlerts' as WatchlistName
						union
						select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty, 'DemographicAlerts' as WatchlistName
				) MDM_Alert
			) MDM_Alert_AllMonths
			group by 
			datepart(year, MDM_Alert_AllMonths.DateInitiated), 
			datepart(month, MDM_Alert_AllMonths.DateInitiated), 
			MDM_Alert_AllMonths.PrimarySpecialty,
			MDM_Alert_AllMonths.WatchlistName
		) AlertWatchlist_Year_Mnth
	) AS SourceTable
	PIVOT
	(
	MAX(Nbr)
	FOR WatchlistName IN ([SanctionAlerts],[LicensureAlerts], [DemographicAlerts])
	) AS PivotTable
) D

ON A.YearNo= D.YearNo
AND A.MonthNo = D.MonthNo
AND A.Specialty = D.Specialty


LEFT JOIN


(
	select 
		datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
		datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
		MDM_Alert_AllMonths.PrimarySpecialty as Specialty,
		count(distinct alertid) as Nbr
	from
	(

				select X.alertid, dateinitiated,PrimarySpecialty from 
											(
											select 
												A.alertid, 
												A.DateInitiated,
												A.MatchStatusIndicator,
												A.WatchlistName,
												COALESCE(C.ProvID,D.ProviderID, E.ProviderID,NULL) as ProviderID
											from KYP.MDM_Alert A
											INNER JOIN KYP.PDM_Party B
												ON A.WatchedPartyId=B.PartyId and B.CurrentModule=2 and ISNULL(A.IsDeleted,0) = 0  and ISNULL(B.IsDeleted,0) = 0 
											LEFT JOIN KYP.PDM_Provider C
												ON B.PartyID=C.PartyID and ISNULL(C.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Employee D
												ON B.PartyID=D.PartyID and ISNULL(D.IsDeleted,0) = 0
											LEFT JOIN KYP.PDM_Owner E 
												ON B.PartyID=E.PartyID and ISNULL(E.IsDeleted,0) = 0
											)X 

											INNER JOIN KYP.MDM_AlertResolution B
												ON X.alertid = B.alertid and ISNULL(B.IsDeleted,0)=0
											LEFT JOIN KYP.PDM_Provider Y
												ON X.ProviderID = Y.ProvID


				union
				select NULL as alertid, getdate() as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union 
				select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, NULL as PrimarySpecialty
				union
				select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, NULL as PrimarySpecialty
	) MDM_Alert_AllMonths
	group by 
	datepart(year, MDM_Alert_AllMonths.DateInitiated), 
	datepart(month, MDM_Alert_AllMonths.DateInitiated), 
	MDM_Alert_AllMonths.PrimarySpecialty
)E

ON A.YearNo= E.YearNo
AND A.MonthNo = E.MonthNo
AND A.Specialty = E.Specialty



WHERE A.YearNo=datepart(year,getdate()) AND A.MonthNo = datepart(month,getdate())
ORDER BY A.ProvidersRecieved DESC


GO

