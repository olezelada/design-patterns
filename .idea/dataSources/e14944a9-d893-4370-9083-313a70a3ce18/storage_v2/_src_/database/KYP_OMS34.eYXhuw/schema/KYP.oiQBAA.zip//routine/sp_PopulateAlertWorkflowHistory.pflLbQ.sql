
-- =============================================
-- Author:		Rajesh Kumar Singh
-- Create date: 08 Spetember 2015
-- Description:	Added Assignee Column for MDM_workflowhistory table to get user.
-- Reviewed By: Hareesha
-- =============================================
CREATE PROCEDURE [KYP].[sp_PopulateAlertWorkflowHistory]
	-- Add the parameters for the stored procedure here
	@AlertID INT
	,@WorkflowStepID INT
	,@ActivityStatus VARCHAR(50)
	,@UserID VARCHAR(100)
	,@Notes VARCHAR(MAX)
	,@ProcessType VARCHAR(1)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @D_MajorDispositionStatus VARCHAR(100)
		,@D_MinorDispositionStatus VARCHAR(100)
		,@D_DescriptionStatus VARCHAR(100)
		,@D_FullName VARCHAR(100)
		,@D_DateTime DATETIME
		,@D_SortDateTime DATETIME
		,@D_ExisingHistory INT
		,@D_StartDateTime DATETIME
		,@D_CheckSuspended VARCHAR(100)
		,@Assignee VARCHAR(100)
		,@AssignByUserName VARCHAR(100);
			
		 SELECT @AssignByUserName=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT AssignedByUserID FROM kyp.MDM_Alert WHERE AlertID=@AlertID);
		
		 SELECT @Assignee=FullName FROM KYP.OIS_User WHERE PersonID in 
		(SELECT AssignedToUserID FROM kyp.MDM_Alert WHERE AlertID=@AlertID);
	
	SELECT @D_FullName = FullName
	FROM KYP.OIS_User
	WHERE UserID = @UserID;

	SET @D_DateTime = GETDATE();
	SET @D_SortDateTime = DATEADD(SS, 2, @D_DateTime);
	

	IF @ProcessType = 2
	BEGIN
		SELECT @D_MajorDispositionStatus = MajorDisposition
			,@D_MinorDispositionStatus = MinorDisposition
			,@D_DescriptionStatus = [Description]
		FROM KYP.OIS_ProcessWorkFlow
		WHERE SortOrder = @WorkflowStepID

		IF @ActivityStatus IN (
				'Suspended'
				,'Resumed'
				)
		BEGIN
			IF @ActivityStatus = 'Suspended'
			BEGIN
				EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
					,@WorkflowStatus = '2'
					,@DateTime = @D_DateTime
					,@UserID = @UserID
					,@UserFullName = @D_FullName
					,@Notes = @Notes
					,@RoleName = NULL
					,@MajorStatus = @D_MajorDispositionStatus
					,@MinorStatus = @D_MinorDispositionStatus
					,@ActivityStatus = @ActivityStatus
					,@Description = NULL
					,@EndDateTime = NULL
					,@NoOfDays = NULL
					,@SortDateTime = @D_DateTime
					,@Assignee=@Assignee
			END
			ELSE IF @ActivityStatus = 'Resumed'
			BEGIN
				SELECT TOP 1 @D_ExisingHistory = ID
					,@D_StartDateTime = [DateTime]
				FROM KYP.MDM_WorkflowHistory
				WHERE AlertID = @AlertID
					AND ActivityStatus = 'Suspended'
				ORDER BY ID DESC
				OPTION (MAXDOP 1)

				EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
					,@WorkflowStatus = '2'
					,@DateTime = @D_DateTime
					,@UserID = @UserID
					,@UserFullName = @D_FullName
					,@Notes = @Notes
					,@RoleName = NULL
					,@MajorStatus = @D_MajorDispositionStatus
					,@MinorStatus = @D_MinorDispositionStatus
					,@ActivityStatus = @ActivityStatus
					,@Description = NULL
					,@EndDateTime = @D_DateTime
					,@NoOfDays = 0
					,@SortDateTime = @D_DateTime
					,@Assignee=@Assignee

				UPDATE KYP.MDM_WorkflowHistory
				SET EndDateTime = @D_DateTime
					,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
				WHERE ID = @D_ExisingHistory
			END
		END
		ELSE IF @ActivityStatus = 'Declined'
		BEGIN
			
			EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
				,@WorkflowStatus = '2'
				,@DateTime = @D_DateTime
				,@UserID = @UserID
				,@UserFullName = @D_FullName
				,@Notes = @Notes
				,@RoleName = NULL
				,@MajorStatus = @D_MajorDispositionStatus
				,@MinorStatus = @D_MinorDispositionStatus
				,@ActivityStatus = @ActivityStatus
				,@Description = NULL
				,@EndDateTime = @D_DateTime
				,@NoOfDays = 0
				,@SortDateTime = @D_DateTime
				,@Assignee=@AssignByUserName
				
		END

		ELSE
		BEGIN
			SELECT TOP 1 @D_ExisingHistory = ID
				,@D_StartDateTime = [DateTime]
				,@D_CheckSuspended = ActivityStatus
			FROM KYP.MDM_WorkflowHistory
			WHERE AlertID = @AlertID
			ORDER BY ID DESC
			OPTION (MAXDOP 1)

			IF @D_ExisingHistory IS NOT NULL
				AND @D_ExisingHistory <> ''
				AND @D_CheckSuspended = 'Suspended'
			BEGIN
				DECLARE @D_ResumeEndDateTime DATETIME

				SET @D_ResumeEndDateTime = DATEADD(SS, - 1, @D_DateTime);

				EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
					,@WorkflowStatus = '2'
					,@DateTime = @D_DateTime
					,@UserID = @UserID
					,@UserFullName = @D_FullName
					,@Notes = NULL
					,@RoleName = NULL
					,@MajorStatus = NULL
					,@MinorStatus = NULL
					,@ActivityStatus = 'Resumed'
					,@Description = NULL
					,@EndDateTime = @D_DateTime
					,@NoOfDays = 0
					,@SortDateTime = @D_ResumeEndDateTime
					,@Assignee=@Assignee

				UPDATE KYP.MDM_WorkflowHistory
				SET EndDateTime = @D_DateTime
					,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
				WHERE ID = @D_ExisingHistory
			END

			EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
				,@WorkflowStatus = '2'
				,@DateTime = @D_DateTime
				,@UserID = @UserID
				,@UserFullName = @D_FullName
				,@Notes = @Notes
				,@RoleName = NULL
				,@MajorStatus = @D_MajorDispositionStatus
				,@MinorStatus = @D_MinorDispositionStatus
				,@ActivityStatus = @ActivityStatus
				,@Description = NULL
				,@EndDateTime = @D_DateTime
				,@NoOfDays = 0
				,@SortDateTime = @D_DateTime
				,@Assignee=@Assignee
		END
		IF @ActivityStatus = 'Declined'
		BEGIN
			SELECT TOP 1 @D_ExisingHistory = ID
						,@D_StartDateTime = [DateTime]
			FROM KYP.MDM_WorkflowHistory
			WHERE AlertID = @AlertID
			AND ActivityStatus = 'In Progress'
			ORDER BY ID DESC
			OPTION (MAXDOP 1)

			SELECT @D_MajorDispositionStatus = MajorDisposition
					,@D_MinorDispositionStatus = MinorDisposition
					,@D_DescriptionStatus = [Description]
			FROM KYP.OIS_ProcessWorkFlow
			WHERE SortOrder = @WorkflowStepID

				IF ISNULL(@D_ExisingHistory, 0) <> 0
				BEGIN
					UPDATE KYP.MDM_WorkflowHistory
					SET ActivityStatus = 'In Progress'
						,SortDateTime = @D_SortDateTime
						,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
						,UserFullName=@D_FullName
						,Assignee=@AssignByUserName
					WHERE ID = @D_ExisingHistory
				END
		END
		ELSE
		BEGIN
			SELECT TOP 1 @D_ExisingHistory = ID
					,@D_StartDateTime = [DateTime]
			FROM KYP.MDM_WorkflowHistory
			WHERE AlertID = @AlertID
			AND ActivityStatus = 'In Progress'
			ORDER BY ID DESC
			OPTION (MAXDOP 1)

			SELECT @D_MajorDispositionStatus = MajorDisposition
			,@D_MinorDispositionStatus = MinorDisposition
			,@D_DescriptionStatus = [Description]
			FROM KYP.OIS_ProcessWorkFlow
			WHERE SortOrder = @WorkflowStepID

			IF ISNULL(@D_ExisingHistory, 0) <> 0
			BEGIN
				UPDATE KYP.MDM_WorkflowHistory
				SET ActivityStatus = 'In Progress'
				,SortDateTime = @D_SortDateTime
				,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
				,UserFullName=@D_FullName
				,Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
		END
	END
	ELSE IF @ProcessType = 1
	BEGIN
		SELECT TOP 1 @D_ExisingHistory = ID
			,@D_StartDateTime = [DateTime]
		FROM KYP.MDM_WorkflowHistory
		WHERE AlertID = @AlertID
			AND ActivityStatus = 'In Progress'
		ORDER BY ID DESC

		SELECT @D_MajorDispositionStatus = MajorDisposition
			,@D_MinorDispositionStatus = MinorDisposition
			,@D_DescriptionStatus = [Description]
		FROM KYP.OIS_ProcessWorkFlow
		WHERE SortOrder = @WorkflowStepID

		IF ISNULL(@D_ExisingHistory, 0) <> 0
		BEGIN
			IF @Notes IS NULL
				OR @Notes = ''
			BEGIN
				UPDATE KYP.MDM_WorkflowHistory
				SET ActivityStatus = 'Completed'
					,UserFullName = @D_FullName
					,EndDateTime = @D_DateTime
					,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
					,SortDateTime = @D_DateTime
					,Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
			ELSE
			BEGIN
				UPDATE KYP.MDM_WorkflowHistory
				SET ActivityStatus = 'Completed'
					,UserFullName = @D_FullName
					,Notes = @Notes
					,EndDateTime = @D_DateTime
					,NoOfDays = DATEDIFF(DD, ISNULL(@D_StartDateTime, GETDATE()), @D_DateTime)
					,SortDateTime = @D_DateTime
					,Assignee=@Assignee
				WHERE ID = @D_ExisingHistory
			END
		END
		ELSE
		BEGIN
			EXEC KYP.p_InsertMDMWorkflowHistory @AlertID = @AlertID
				,@WorkflowStatus = '1'
				,@DateTime = @D_DateTime
				,@UserID = @UserID
				,@UserFullName = @D_FullName
				,@Notes = @Notes
				,@RoleName = NULL
				,@MajorStatus = @D_MajorDispositionStatus
				,@MinorStatus = @D_MinorDispositionStatus
				,@ActivityStatus = 'In Progress'
				,@Description = @D_DescriptionStatus
				,@EndDateTime = NULL
				,@NoOfDays = NULL
				,@SortDateTime = @D_SortDateTime
				,@Assignee=@Assignee
		END
	END
END


GO

