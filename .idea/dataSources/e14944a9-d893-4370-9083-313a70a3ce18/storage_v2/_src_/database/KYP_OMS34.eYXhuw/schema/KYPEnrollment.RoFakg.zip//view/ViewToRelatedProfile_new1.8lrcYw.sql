





-- =============================================

-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================

CREATE VIEW [KYPEnrollment].[ViewToRelatedProfile_new1]
AS
select (row_number() over ( order by r.CaseID)) AS ViewID, r.*
from
-- for individual
(
	select 
	DISTINCT sap.PartyID,
	ca.CaseID,
	ca.IsPPURequired AS IsPPURequired,
	ISNULL(ca.WFStatus,'') As WFStatus,
	app.ApplicationID,
	app.Status,
	ca.Number as ApplicationNumber,
	ca.Number as ProviderNumber,
	ca.ProviderName as Name,
	ca.ApplnType as ApplicationType,
	ca.MILESTONE as Milestone, 
	pps.NPI, 
	ISNULL(ca.Provider_SSN,'') as SSN,
	ISNULL(ca.Provider_TIN,'') as TIN,
	(Select TOP 1 ISNULL(ad.AddressLine1 ,'')+' '+ISNULL(ad.City ,'')+' '+ISNULL(ad.[State] ,'')+' '+ ISNULL(ad.Zip ,'')+(CASE WHEN ad.ZipPlus4 is null THEN '' ELSE '-'+ad.ZipPlus4 END)  from (select * from KYP.PDM_Location where PartyID = sap.PartyID and InActive = 1 AND IsDeleted =0   ) lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID and ad.inactive=lo.inactive and ad.isdeleted=lo.isdeleted order by lo.locationid desc)	  as PracticeAddress, 
	ca.TypeDescription as ProviderType, 
	'' as StatusLinked,
	(ISNULL((Select Substring((Select ',' + CONVERT(VARCHAR(15), CaseIDA) From KYPEnrollment.Linked_ADM_Case where CaseIDM=cas.CaseID and StatusLinked='Link' For XML Path('')),2,8000) From KYP.ADM_Case as cas WHERE cas.CaseID = ca.CaseID),'A')) as CaseIDLinked,
	ca.WFStatus Filter
	
	from  KYP.SDM_ApplicationParty as sap inner join KYP.ADM_Application as app  on sap.applicationid=app.applicationid and isnull(app.IsDeleted,0) =0 
	inner join KYP.ADM_Case as ca on ca.CaseID=app.CaseID  and ca.IsPPURequired=0 AND ca.WFProcessing=0 and ISNULL(ca.WFStatus,'') <> ''
	inner join KYP.PDM_Provider as pps on pps.PartyID=sap.PartyID 
	where
	sap.PartyType='Provider' AND  isnull(sap.IsDeleted,0)=0 AND sap.isActive = 1 
	
	
) r


GO

