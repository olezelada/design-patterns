
Create view [KYPEnrollment].[Vw_SubContractorOwnerParty] as
select ROW_NUMBER() over(Order by PartyID,ParentPartyID) SubConOwnerID,* 
From (
	select PartyID,ParentPartyID 
	From kypenrollment.paccount_pdm_party 
	where TYPE in ('SubcontractorOwnerEntity','SubcontractorOwnerIndividual')
	and ParentPartyId is not null
	union all
	select PartyIDOwner, PartyIDOwned
	from KYPEnrollment.pAccount_PDM_OwnershipRelationship
	where TypeAssociation in ('SubcontractorIndividualAssociation','SubcontractorEntityAssociation')
	and PartyIDOwned is not null
	and PartyIDOwner is not null
) T
GO

