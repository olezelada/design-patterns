
CREATE PROCEDURE [KYPEnrollment].[sp_Update_OrthotistProsthetist]
      @app_party_Id     INT
    , @application_Code VARCHAR(100)
    , @account_party_id INT
    ,	@last_action_user_id VARCHAR(100)
AS
  BEGIN
    DECLARE @number_type VARCHAR(100), @number_id INT
    DECLARE @packageList TABLE(packageName VARCHAR(30) PRIMARY KEY)
    INSERT INTO @packageList (packageName)
    VALUES ('ISP_OP_AP'), ('ISP_PP_AP'), ('ISP_OAP_AP'), ('ISP_RP_O_RA'), ('ISP_RP_P_RA'), ('ISP_RP_OAP_RA'),
      ('IGSP_OP_AP'), ('IGSP_PP_AP'), ('IGSP_OAP_AP');

    IF EXISTS(SELECT *
              FROM @packageList
              WHERE packageName = @application_Code)
      BEGIN
        SELECT @number_type = number.Type
        FROM [KYPPORTAL].[PortalKYP].pPDM_Number number
          INNER JOIN [KYPPORTAL].[PortalKYP].pADM_App_Form appForm INNER JOIN [KYPPORTAL].[PortalKYP].pPDM_Party party
            ON party.PartyID = appForm.PartyID ON appForm.PartyID = number.PartyID
        WHERE
          party.PartyID = @app_party_Id AND appForm.Type = 'ProfCertificate' AND number.TypeForm = 'ProfCertificate'
          AND number.IsDeleted = 'false'

        SELECT @number_id = NumberID
        FROM KYPEnrollment.pAccount_PDM_Number
        WHERE PartyID = @account_party_id AND Type IN ('orthotistBOC', 'orthotistABCOP', 'prosthetistBOC',
                                                       'prosthetistABCOP', 'orthBOCprosthBOC', 'orthABCOPprosthABCOP',
                                                       'orthBOCprosthABCOP', 'orthABCOPprosthBOC', 'orthProsthABCOP', 'MFCertificate')
          IF (@number_id IS NOT NULL)
          BEGIN
            UPDATE KYPEnrollment.pAccount_PDM_Number
                  SET Type = @number_type
                  WHERE NumberID = @number_id
          END

          ELSE
          BEGIN
            EXEC [KYPEnrollment].[Copy_Twin_Number] @account_party_id, @app_party_Id, @last_action_user_id, @number_type;
          END


      END
  END

GO

