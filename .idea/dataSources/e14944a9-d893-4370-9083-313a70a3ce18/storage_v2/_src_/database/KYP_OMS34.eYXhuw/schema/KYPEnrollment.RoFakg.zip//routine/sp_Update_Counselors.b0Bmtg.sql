
/* ==========================================================
-- Author:		<Lacunza, Giresse>
-- PROCEDURE: Update Party Counselor by Traking.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name :
-- ============================================================*/
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Counselors]


@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100),
@data VARCHAR(MAX),
@acc_PK VARCHAR(100),
@acc_PK_value INT,
@is_text_date CHAR(1),
@acc_table_name varchar(100)


AS
BEGIN
SET NOCOUNT ON;
DECLARE @app_party_id INT,@acc_id int, @delete VARCHAR(MAX), @app_counselor_id int;

IF @action_taken='Added'
---------
  BEGIN
---------
	SELECT @app_counselor_id = PartyID FROM [KYPPORTAL].[PortalKYP].pPDM_Party WHERE TargetPath=@target_path;
	   if @target_path NOT LIKE '%|%' and NOT EXISTS(SELECT TargePath FROM #Control_Add_row WHERE TargePath = @target_path)
	begin
	 PRINT @action_taken

	 SELECT @app_party_id = p.PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] p WHERE TargetPath=@target_path;

	  SELECT @acc_id = AccountID FROM KYPEnrollment.pADM_Account WHERE PartyID=@acc_party_id
	 EXEC [KYPEnrollment].[sp_Insert_Counselor_Party]   @app_party_id, @acc_party_id, @acc_id,@last_action_user_id;

	 --INSERT INTO #Control_Add_row(FiledID,NameTable)
	 INSERT INTO #Control_Add_row(TargePath)
	 --VALUES(@target_path,'pAccount_PDM_Party');
	 VALUES(@target_path);
	 --END
	end

  ELSE
  begin
	PRINT @action_taken
	EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
  end

----------
  END
----------

IF @action_taken='Updated' AND (@acc_table_name in ('pAccount_PDM_Party','pAccount_PDM_Person','pAccount_PDM_Provider','pAccount_PDM_Number'))
		BEGIN
			PRINT @action_taken

			EXEC [KYPEnrollment].[sp_Update_Field] @acc_table_name,@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;

		END

IF NOT EXISTS (SELECT TargePath FROM #Control_Add_row WHERE TargePath = @target_path)
		BEGIN
  			IF @action_taken='Deleted' AND (@acc_table_name in ('pAccount_PDM_Party','pAccount_PDM_Person','pAccount_PDM_Provider','pAccount_PDM_Number'))
			BEGIN
				PRINT @action_taken
				SET @delete = 'UPDATE [KYPEnrollment].[' + @acc_table_name + '] SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + '=' +  CONVERT(VARCHAR(100),@acc_PK_value);
				EXECUTE (@delete);
				INSERT INTO #Control_Add_row(TargePath) VALUES(@target_path);
			END
		END

END
GO

