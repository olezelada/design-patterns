



CREATE PROCEDURE [KYPEnrollment].[Update_All_Account_new](
  @account_id INT,
  @party_id_account INT,
  @tax_id VARCHAR(10),
  @application_id INT,
  @party_id_app INT,
  @last_Action_User_ID VARCHAR(100),
  @accepted BIT,
  @application_type VARCHAR(50) = NULL
)
AS
BEGIN

	DECLARE @supUpdateFlag VARCHAR(10), @profId VARCHAR(100)
	SELECT @supUpdateFlag = cass.SupUpdateFlag FROM KYP.ADM_Case cass inner join KYPEnrollment.pADM_Account acc
	on cass.Number=acc.ApplicationNumber AND acc.AccountID = @account_id

	SELECT @profId = ProfileID FROM KYPEnrollment.pAccount_BizProfile_Details WHERE AccountID = @account_id
	
	DECLARE @date_Create DATE
	SET @date_Create = GETDATE()

	CREATE TABLE #FieldTrakingByParty  (ID INT IDENTITY(1,1),
	FieldValueID INT,EntityID INT,TableCode VARCHAR(20),AccTableName VARCHAR(100),AccPK VARCHAR(100),AccPKValue INT,ActionTaken VARCHAR(50),
	EnDbColumn VARCHAR(100),TrackingTargetPath VARCHAR(200),CurrentValueInt INT, NewValueInt INT, TargetPath VARCHAR(200));
	 IF (@application_type is not  NULL  AND (@application_type IN ('CHOA','CHOW','Disenrollment','Disaffiliation','Supplemental','Revalidation')))
	  BEGIN
		set @accepted=1;
	  END
	  ELSE
	  BEGIN
		set @accepted=0;
	  END
	INSERT INTO #FieldTrakingByParty 
	SELECT tracking.FieldValueID,tracking.EntityID,tracking.TableCode,tracking.AccTableName,tracking.AccPK,tracking.AccPKValue,
	tracking.ActionTaken,tracking.EnDbColumn,tracking.TargetPath, tracking.CurrentValueInt, tracking.NewValueInt, tracking.TargetPath
	FROM [KYPPORTAL].PortalKYP.FieldValuesTracking tracking 
	WHERE tracking.ApplicationID=@application_id AND (tracking.TableCode IN ('subcontractorTable','ownerTable','sigTransTable','licenseActions','settlementTable',
	'licenseActions','convictedTable','liableTable','suspendedTable','ownerSubAssocTable','individualSubTable','otherAssocTable','otherEntAssocTable',
	'selfPartTable','subOwnerTable','entitySubTable','assoSubIndTable','assoSubOwnerTable'))  and sectionnanme<>'Disclosure Information'
	AND Accepted = @accepted
	
	 DECLARE @partyTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT,TableCode VARCHAR(20), TrackingTargetPath VARCHAR(200), AccTableName VARCHAR(200), AccPKValue INT)
	 
	 DECLARE @count_party_Id INT,@top_PartyId INT, @partyIdUpdate INT, @typedUpdate VARCHAR(20)
	 
	 SELECT @partyIdUpdate = EntityPartyID, @typedUpdate = TableCode FROM @partyTraking WHERE ID=@count_party_Id;
	 ---mvc 3.0
		 INSERT INTO  @partyTraking SELECT DISTINCT PartyID,NULL,NULL,NULL,NULL  FROM KYPEnrollment.pAccount_PDM_Party WHERE (ParentPartyID= @party_id_account or 
		 ParentPartyID in (select PartyID from KYPEnrollment.pAccount_PDM_Party where ParentPartyID=@party_id_account) )
			AND Type IN ('SubcontractorEntity','SubcontractorIndividual','TransactionEntity','TransactionIndividual','SubcontractorOwnerIndividual','SubcontractorOwnerEntity')
		INSERT INTO  @partyTraking SELECT DISTINCT EntityID, TableCode, TrackingTargetPath, AccTableName, AccPKValue FROM #FieldTrakingByParty 
			WHERE AccTableName='pAccount_PDM_Party'  and (ActionTaken ='Deleted') AND (TableCode IN ('subcontractorTable','sigTransTable','subOwnerTable'))
		
	  
	 
	 SELECT @top_PartyId = MAX(ID) FROM @partyTraking; 
	 
	 SET @count_party_Id = 1
	 WHILE @count_party_Id <= @top_PartyId
	 BEGIN
		SELECT @partyIdUpdate = EntityPartyID, @typedUpdate = TableCode FROM @partyTraking WHERE ID=@count_party_Id;
		IF(@partyIdUpdate IS NULL)
		BEGIN    
			print '@DELETE'
			SELECT @partyIdUpdate = AccPKValue FROM @partyTraking WHERE ID=@count_party_Id AND AccTableName='pAccount_PDM_Party' 
			EXEC [KYPEnrollment].[Delete_by_TaxId] @partyIdUpdate, 'D',@typedUpdate, @profId ;
		END
		ELSE
		BEGIN
			print '@UPDATE'
			EXEC [KYPEnrollment].[Updated_by_TaxId] @partyIdUpdate, 'U',@typedUpdate, @profId ;
		END
	  SET @count_party_Id = @count_party_Id+1
	 END

	 DECLARE @partyMocaTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT)

	 IF (@application_type is not  NULL  AND (@application_type NOT IN ('CHOA','CHOW','Disenrollment','Disaffiliation','Supplemental')))
	  BEGIN
	  --mvc 3.0
	    INSERT INTO  @partyMocaTraking SELECT DISTINCT PartyID  FROM KYPEnrollment.pAccount_PDM_Party WHERE ParentPartyID= @party_id_account 
			AND Type IN ('Entity Ownership','Individual Ownership')
		
		INSERT INTO  @partyMocaTraking SELECT DISTINCT entityid FROM #FieldTrakingByParty 
			WHERE AccTableName='pAccount_PDM_Party' and (ActionTaken ='Deleted') AND (TableCode IN ('ownerTable'))
		
		INSERT INTO  @partyMocaTraking SELECT DISTINCT EntityID FROM #FieldTrakingByParty 
		WHERE (AccTableName IS NOT NULL AND AccPK IS NOT NULL AND AccPKValue IS NOT NULL) AND (TableCode = 'convictedTable' OR TableCode = 'liableTable' OR 
			TableCode = 'settlementTable' OR TableCode = 'suspendedTable' OR TableCode='suspendedTable'
			OR TableCode='ownerSubAssocTable' OR TableCode='individualSubTable' OR TableCode='otherAssocTable' OR TableCode='otherEntAssocTable'
			OR TableCode='selfPartTable' or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable') AND EntityID IS NOT NULL	and (ActionTaken ='Deleted')
		
	  END
	  ELSE
	 
	  BEGIN
	    INSERT INTO  @partyMocaTraking SELECT DISTINCT PartyID  FROM KYPEnrollment.pAccount_PDM_Party WHERE ParentPartyID= @party_id_account 
			AND Type IN ('Entity Ownership','Individual Ownership') and CurrentRecordFlag =1
		INSERT INTO  @partyMocaTraking SELECT DISTINCT entityid FROM #FieldTrakingByParty trac
		    WHERE (ActionTaken ='Deleted') AND (TableCode IN ('ownerTable')) and AccTableName='pAccount_PDM_Party' 
	  END
	 
	 DECLARE @count_partyMoca_Id INT,@top_PartyMocaId INT, @partyMocaIdUpdate INT, @typeMocaUpdate VARCHAR(20)
	 
	 SELECT @top_PartyMocaId = MAX(ID) FROM @partyMocaTraking; 
	 SET @count_partyMoca_Id = 1
	 WHILE @count_partyMoca_Id <= @top_PartyMocaId
	 BEGIN
		SELECT @partyMocaIdUpdate = EntityPartyID FROM @partyMocaTraking WHERE ID=@count_partyMoca_Id;
		
		IF(@partyMocaIdUpdate IS NULL)
		BEGIN    
			print '@DELETE MOCA'
			DECLARE @partyDeleteTraking TABLE (ID INT IDENTITY(1,1),EntityPartyID INT)
			DECLARE @count_partyDelMoca_Id INT,@top_PartyDelMocaId INT, @partyMocaIdDelete INT, @typeMocaDelete VARCHAR(20)
			INSERT INTO @partyDeleteTraking SELECT  AccPKValue FROM #FieldTrakingByParty WHERE AccTableName='pAccount_PDM_Party'  and TableCode='ownerTable'
			and (ActionTaken ='Deleted')
			
			 SELECT @top_PartyDelMocaId = MAX(ID) FROM @partyDeleteTraking; 
			 SET @count_partyDelMoca_Id = 1
			 WHILE @count_partyDelMoca_Id <= @top_PartyDelMocaId
			 BEGIN
				SELECT @partyMocaIdDelete = EntityPartyID FROM @partyDeleteTraking WHERE ID=@count_partyDelMoca_Id;
				EXEC [KYPEnrollment].[DeleteMoca_by_TaxId] @partyMocaIdDelete, 'D', @profId;
				SET @count_partyDelMoca_Id = @count_partyDelMoca_Id+1
			END
		END
		ELSE
		BEGIN
		
			print '@UPDATE MOCA_NOW' + convert(varchar(15),@partyMocaIdUpdate)
			
			EXEC [KYPEnrollment].[UpdatedMoca_by_TaxId] @partyMocaIdUpdate, 'U', @party_id_app,@application_id,@account_id, @profId ;
		END
	  SET @count_partyMoca_Id = @count_partyMoca_Id+1
	 END
	 
	 DROP TABLE #FieldTrakingByParty
END


GO

