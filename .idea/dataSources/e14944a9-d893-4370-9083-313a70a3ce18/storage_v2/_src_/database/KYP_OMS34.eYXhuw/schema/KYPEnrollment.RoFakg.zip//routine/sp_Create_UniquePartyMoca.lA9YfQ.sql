

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Unique Party MOCA.   
-- PARAMETERS: 
-- @unique_party_id : uniquePartyID to MOCA. 
-- @moca_party_id : partyID MOCA to Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @effective_being_date : date beging. 
-- @current_flag : Flag for history,default values is true. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Create_UniquePartyMoca]
	@unique_party_id INT,
	@moca_party_id INT,	
	@last_action_user_id VARCHAR(100),
	@effective_being_date SMALLDATETIME,
	@current_flag BIT
	with recompile
AS
BEGIN
    SET NOCOUNT ON
    DECLARE @date_created smalldatetime
	SET @date_created = cast(GETDATE() as smalldatetime)
				
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty_MOCAMapping]
	([UniquePartyID]
	,[MOCAPartyID]
	,[EffectiveBeingDate]
	,[LastAction]
	,[LastActionDate]
	,[LastActoryUserID]
	,[LastActionApprovedByUsedID]
	,[CurrentRecordFlag])
	VALUES
	(@unique_party_id
	,@moca_party_id
	,@effective_being_date
	,'C'
	,@date_created
	,@last_action_user_id
	,@last_action_user_id
	,@current_flag)	option (Recompile)			
END


GO

