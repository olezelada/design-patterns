

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYPEnrollment].[Trg_pAccount_BizProfile_Details_On_Update]
   ON [KYPEnrollment].[pAccount_BizProfile_Details]
   AFTER Update
AS 
BEGIN
	SET NOCOUNT ON;

	Update KYPEnrollment.pAccount_BizProfile_Master
	Set LastActionDate = Getdate()
	Where ProfileID in (Select ProfileID From Inserted)
	OPTION (MAXDOP 1);
	
	Update KYPEnrollment.pADM_Account
	Set LastActionDate = Getdate()
	Where AccountID in (Select AccountID From Inserted)
	OPTION (MAXDOP 1);
	
END

GO

