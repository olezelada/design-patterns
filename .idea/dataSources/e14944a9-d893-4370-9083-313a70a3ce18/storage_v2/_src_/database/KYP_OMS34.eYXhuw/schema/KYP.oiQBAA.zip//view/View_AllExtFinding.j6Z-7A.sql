

CREATE View [KYP].[View_AllExtFinding] as
With cte1
as
 (
    SELECT identificador as ViewID,addedon, titleFinding, findingDescription, pStatus,CaseIdFinding,findingid,
        row_number() over (partition by addedon,titleFinding,caseIDFinding,PStatus,findingDescription,findingid order by FindingId) as sortid
    FROM        
    (       
            SELECT CONVERT(varchar(15), a.noteid) + CONVERT(varchar(15), c.ID) + CONVERT(varchar(15), isnull(fe.infoid, 0)) AS identificador,
                a.DateCreated addedon,
                a.Name titleFinding,
                cast(fe.PCaseID + '' AS int) caseIDFinding,
                fe.PStatus AS PStatus,
                CAST(a.UnformattedContent AS varchar(max)) findingDescription
                ,a.NoteID findingID
            FROM  kyp.OIS_Note a
            JOIN KYP.Eventdates c ON a.Noteid = C.CFId
            LEFT JOIN kyp.MDM_JournalBasicInfo fe ON a.PInID = fe.infoid and fe.IsIgnored = '0'
            WHERE a.Type = 'Application Review' AND a.ReasonCode IS NOT NULL
            and (a.ExternalYesNO = '1' OR a.ExternalYesNO = 'Yes')
           
           
    )G
)
Select * from cte1
where sortid = 1

GO

