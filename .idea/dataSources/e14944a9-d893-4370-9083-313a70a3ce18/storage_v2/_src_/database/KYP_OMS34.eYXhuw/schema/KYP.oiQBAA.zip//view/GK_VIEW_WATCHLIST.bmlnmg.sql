
CREATE VIEW [KYP].[GK_VIEW_WATCHLIST]  as
WITH P 
AS (
select distinct GateKeeperID,FirstName,LastName,MiddleName,
CASE When Name Is Not Null Then Name
			WHEN LastName Is Not null then  
				LastName + ', '  +isnull(FirstName, '') + ' ' + isnull(MiddleName, '')
				else 
					isnull(FirstName, '') + ' ' + isnull(MiddleName, '')
				end AS Name,
AkaName,Status,
Notes,RequestBy,CreatedBy,CONVERT(varchar(24),CreatedOn,101)as CreatedOn,LastModifiedBy,CONVERT(varchar(24),lastModifiedOn,101)as lastModifiedOn,
ProviderType,StatusStartDate,StatusEndDate
from KYP.GK_Watchlist
WHERE (RequestBy != 'Temp' OR RequestBy is null) AND isDeleted = 0 
),
PH 
AS (
select distinct PhoneNo,GateKeeperID from KYP.GK_PhoneNoWatchlist where PhoneNo is not null AND PhoneNo != '' AND isDeleted = 0
),
N 
AS (
select distinct NPI,GateKeeperID from KYP.GK_NPIWatchlist where NPI is not null AND NPI != '' AND isDeleted = 0
),
PR 
AS (
select distinct ProviderNo,GateKeeperID from KYP.GK_ProviderNoWatchlist where ProviderNo is not null AND ProviderNo != '' AND isDeleted = 0
),
AD 
AS (
select distinct GateKeeperID,AddressLine1,AddressLine2 ,City,State,ZipCode,Zip4code,isnull(ZipCode,'')+isnull('-'+Zip4Code,'') as Zip
from KYP.GK_AddressWatchlist where isDeleted = 0
),
L 
AS (
select distinct License,GateKeeperID from KYP.GK_LicenseWatchlist where License is not null AND License != '' AND isDeleted = 0
)


SELECT RANK() OVER (partition by Y.GateKeeperID Order by  Y.ID) As rn, Y.* FROM(
	SELECT ROW_NUMBER() OVER(order by X.ProviderNo ASC) AS ID,X.* FROM(
select distinct
P.GateKeeperID,PR.ProviderNo,P.FirstName,P.LastName,P.MiddleName,
P.Name,
P.AkaName,P.Status,
P.Notes,P.RequestBy,P.CreatedBy,P.CreatedOn,P.LastModifiedBy,P.lastModifiedOn ,N.NPI,L.License,AD.AddressLine1,AD.AddressLine2 ,AD.City,AD.State,AD.ZipCode,AD.Zip4code
,AD.Zip,PH.PhoneNo,P.ProviderType,P.StatusStartDate,P.StatusEndDate
from P 
LEFT join PH ON
PH.GateKeeperID = P.GateKeeperID --AND PH.PhoneNo is not null AND PH.PhoneNo != '' AND PH.isDeleted = 0
LEFT join N ON 
N.GateKeeperID = P.GateKeeperID-- AND N.NPI is not null AND N.NPI != '' AND N.isDeleted = 0
  LEFT join PR ON 
  PR.GateKeeperID = P.GateKeeperID --AND PR.ProviderNo is not null AND PR.ProviderNo != '' AND PR.isDeleted = 0
   LEFT join AD ON 
   AD.GateKeeperID = P.GateKeeperID-- AND AD.isDeleted = 0
    LEFT join L 
ON L.GateKeeperID = P.GateKeeperID-- AND L.License is not null AND L.License != '' AND L.isDeleted = 0
		)X
	)Y

GO

