-- =============================================
-- Author:		<cLopez>
-- Create date: <05/28/2018>
-- Description:	<Assign a new AccountNumber to FBP account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Assign_AccountNumber]
	@cont INT,
	@case_id INT

AS
BEGIN
  DECLARE @accountNumber varchar(20), @longHead INT, @longFoot INT

  DECLARE @I INT=1;
  START:
    SET @accountNumber = '1' + cast((@cont) as varchar)
    SET @longHead = LEN(@accountNumber)
    SET @longFoot = LEN(@case_id)

    WHILE (@longHead + @longFoot) < 9
    BEGIN
      SET @accountNumber = @accountNumber + '0'
      SET @longHead = LEN(@accountNumber)
    END
    SET @accountNumber = @accountNumber + cast((@case_id) as varchar)

    SET @cont+=1;
  IF EXISTS (SELECT * FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @accountNumber) GOTO START;

	RETURN @accountNumber
END


GO

