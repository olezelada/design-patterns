
/* ==========================================================
-- Author:		<JVera>
-- PROCEDURE: create Business Activities form. Only copy Business activity Approved  
-- PARAMETERS:  
-- @party_id : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create.
-- @last_action_user_id : this is the user Enrollment.
-- @@app_activity_id : this is the ActivityID Application that will be Create in Update Account, it is Null when account is create.  
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Activity] 	
	@party_id INT,
	@new_party_id INT,
	@last_action_user_id VARCHAR(100),
	@app_activity_id INT

AS
BEGIN
    SET NOCOUNT ON
	DECLARE @date_create DATE
	SET @date_create = GETDATE();
	
	IF @app_activity_id IS NOT NULL
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_BusinessActivity]
			([PartyID] ,
			[Activity],		
			[ActivityCode],
			[Percentage],		
			[DescriptionActivity],
			[Approved],
			[EffectiveDate],
			[LastAction],
			[LastActionDate],
			[LastActorUserID]	,
			[LastActionApprovedBy],
			[CurrentRecordFlag],			
			[IsDeleted])
			
			SELECT @new_party_id
			,[Activity]		
			,[ActivityCode]
			,[Percentage]		
			,[DescriptionActivity]
			,[Approved] 
			,[EffectiveDate] 
			,'C'
			,@date_create
			,@last_action_user_id
			,@last_action_user_id
			,1			
			,[IsDeleted]
			FROM [KYPPORTAL].[PortalKYP].[pPDM_BusinessActivity] 
			WHERE	ActivityID = @app_activity_id
					AND Approved = 1
					AND IsDeleted = 0
			
	END
	ELSE
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_BusinessActivity]
		([PartyID] ,
		[Activity],		
		[ActivityCode],
		[Percentage],		
		[DescriptionActivity],
		[Approved],
		[EffectiveDate],
		[LastAction],
		[LastActionDate],
		[LastActorUserID]	,
		[LastActionApprovedBy],
		[CurrentRecordFlag],			
		[IsDeleted])
		SELECT @new_party_id
		,[Activity]		
		,[ActivityCode]
		,[Percentage]		
		,[DescriptionActivity]
		,[Approved] 
		,[EffectiveDate]
		,'C'
		,@date_create
		,@last_action_user_id
		,@last_action_user_id
		,1		
		,[IsDeleted]
		FROM	[KYPPORTAL].[PortalKYP].[pPDM_BusinessActivity] 
		WHERE	PartyID = @party_id
				AND Approved = 1
				AND IsDeleted = 0
    END
END


GO

