

/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDM_Organization]
(@PartyID int
 ,@OrgNumber varchar(25)= NULL
 ,@OrgCategory varchar(15) =NULL
 ,@TIN varchar(11) = NULL
 ,@PrimaryDUNS varchar(11)=NULL
 ,@LegalName varchar(100)=NULL
 ,@DBAName1 varchar(100)=NULL
 ,@DBAName2 varchar(100)=NULL
 ,@IncTyp varchar(15)=NULL
 ,@IncState varchar(2)=NULL
 ,@IncDate smalldatetime=NULL
 ,@ForeginOwned bit=0
 ,@Email1 varchar(50)=NULL
 ,@Phone1 varchar(15)=NULL
 ,@Email2 varchar(50)=NULL
 ,@Phone2 varchar(15)=NULL
 ,@Remarks varchar(25)=NULL
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@NPI int=NULL

)
as begin 

INSERT INTO [KYP].[PDM_Organization]
           ([PartyID]
           ,[OrgNumber]
           ,[OrgCategory]
           ,[TIN]
           ,[PrimaryDUNS]
           ,[LegalName]
           ,[DBAName1]
           ,[DBAName2]
           ,[IncTyp]
           ,[IncState]
           ,[IncDate]
           ,[ForeginOwned]
           ,[Email1]
           ,[Phone1]
           ,[Email2]
           ,[Phone2]
           ,[Remarks]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[NPI])
     VALUES
           (@PartyID
           ,@OrgNumber
           ,@OrgCategory
           ,@TIN
           ,@PrimaryDUNS
           ,@LegalName
           ,ISNULL(@DBAName1,@LegalName)
           ,@DBAName2
           ,@IncTyp
           ,@IncState
           ,@IncDate
           ,@ForeginOwned
           ,@Email1
           ,@Phone1
           ,@Email2
           ,@Phone2
           ,@Remarks
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@NPI)

	return IDENT_CURRENT('[KYP].[PDM_Organization]')

end


GO

