

CREATE TRIGGER [KYP].[trg_GK_WatchlistONUpd] on [KYP].[GK_Watchlist]
AFTER UPDATE
AS
BEGIN
	DECLARE @LastUpd DATETIME;
	SELECT @LastUpd=lastModifiedOn  FROM inserted
	UPDATE [KYP].[LatestUpdDbDetails] SET  LastLoadDate=GETDATE() WHERE DataSources='OMS' AND ExclusionList='Internal Watchlist'
	/**Added By Rahul for watchlist index**/
	UPDATE KYP.GK_Watchlist set LastActionDate=getdate() where GateKeeperID=(SELECT GateKeeperID FROM inserted)
END


GO

