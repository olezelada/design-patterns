 
 CREATE PROCEDURE [KYPEnrollment].[CloneAccountSearch]
   @old_account_id INT,
   @new_account_id INT
 
 AS
 BEGIN
 PRINT 'CLONE RE/RE SCHEDULED'
 DECLARE @new_acc_party_id INT,@legal_name VARCHAR(250),@npiType VARCHAR(25),@ssn NVARCHAR(11),@EIN NVARCHAR(10),@account_type VARCHAR(50)
 SELECT @npiType = [NPIType],@account_type = [AccountType], @new_acc_party_id = [PartyID] FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_account_id 
 
 IF(@npiType='Individual')
	BEGIN
		SELECT @legal_name = FirstName+' '+LastName,@ssn = SSN
		FROM [KYPEnrollment].[pAccount_PDM_Person]
		WHERE PartyID = @new_acc_party_id
		
		SET @ssn = replace(@ssn,'-','')
	END
	
	ELSE
	BEGIN
		IF(@npiType='Organization')
		BEGIN
			SELECT @legal_name = [LegalName],@EIN = [EIN]
			FROM [KYPEnrollment].[pAccount_PDM_Organization] WHERE PartyID = @new_acc_party_id
			
			SET @EIN = REPLACE(@EIN,'-','')
		END
	END
	
 DECLARE @addres_line1_service VARCHAR(250),@addres_line2_service VARCHAR(250),@state_service VARCHAR(40),@city_service VARCHAR(25),@zip_service VARCHAR(15),
 @addres_line1_pay_to VARCHAR(250),@addres_line2_pay_to VARCHAR(250),@state_pay_to VARCHAR(40),@city_pay_to VARCHAR(25),@zip_pay_to VARCHAR(15)
 
 SELECT @addres_line1_service = address.AddressLine1,@addres_line2_service = address.AddressLine2,@state_service = address.State,@city_service = address.City,@zip_service = ZipPlus4 
 FROM KYPEnrollment.pAccount_PDM_Location location INNER JOIN KYPEnrollment.pAccount_PDM_Address address ON (location.AddressID=address.AddressID) 
 WHERE location.Type='Servicing' AND location.PartyID=@new_acc_party_id;
 
 SELECT @addres_line1_pay_to = address.AddressLine1,@addres_line2_pay_to = address.AddressLine2,@state_service = address.State,@city_pay_to = address.City, @zip_pay_to = ZipPlus4 
 FROM KYPEnrollment.pAccount_PDM_Location location INNER JOIN KYPEnrollment.pAccount_PDM_Address address ON (location.AddressID=address.AddressID) 
 WHERE location.Type='Pay-to' AND location.PartyID=@new_acc_party_id;
 
DECLARE  @license_table TABLE (Number VARCHAR(MAX))
INSERT INTO @license_table (Number)SELECT [Number]
FROM [KYPEnrollment].[pAccount_PDM_Number] WHERE [IsDeleted]=0 AND [CurrentRecordFlag]=1 AND [Number] IS NOT NULL AND [PartyID]=@new_acc_party_id

DECLARE @license VARCHAR(MAX)
SELECT @license= COALESCE(@license + ', ', '') + Number FROM @license_table

 
 
 INSERT INTO [KYPEnrollment].[AccountSearch]
           ([AccountNumber]
           ,[EnrollmentStatus]
           ,[EnrolledOn]
           ,[ProviderType]
           ,[BillingStatus]
           ,[ScreeningLevel]
           ,[ServiceCity]
           ,[ServiceState]
           ,[ServiceZip]
           ,[PayCity]
           ,[PayState]
           ,[PayZip]
           ,[AccountName]
           ,[NPI]
           ,[SSN]
           ,[TAXID]
           ,[CategoryOfService]
           ,[ScheduledStatus]
           ,[StatusDate]
           ,[AccountID]
           ,[RiskScore]
           ,[ServiceAddressLine1]
           ,[ServiceAddressLine2]
           ,[PayAddressLine1]
           ,[PayAddressLine2]
           ,[StatusBeginDate]
           ,[AccountType]
           ,[AccountTypeDesc]
           ,[License]
           ,[InPortalDate]
           ,[CompletedInPortalDate]
           ,[AccountSearchEnabled])
  SELECT   [AccountNumber]
           ,[EnrollmentStatus]
           ,[EnrolledOn]
           ,[ProviderType]
           ,[BillingStatus]
           ,[ScreeningLevel]
           ,ISNULL(@city_service,NULL)
           ,ISNULL(@state_service,NULL)
           ,ISNULL(@zip_service,NULL)
           ,ISNULL(@city_pay_to,NULL)
           ,ISNULL(@state_service,NULL)
           ,ISNULL(@zip_pay_to,NULL)
           ,ISNULL(@legal_name,NULL)
           ,[NPI]
           ,ISNULL(@ssn,NULL)
           ,ISNULL(@EIN,NULL)
           ,[CategoryOfService]
           ,'Unscheduled'
           ,[StatusDate]
           ,@new_account_id
           ,[RiskScore]
           ,ISNULL(@addres_line1_service,NULL)
           ,ISNULL(@addres_line2_service,NULL)
           ,ISNULL(@addres_line1_pay_to,NULL)
           ,ISNULL(@addres_line2_pay_to,NULL)
           ,[StatusBeginDate]
           ,ISNULL(@account_type,NULL)
           ,[AccountTypeDesc]
           ,ISNULL(@license,NULL)
           ,[InPortalDate]
           ,[CompletedInPortalDate]
           ,1
  FROM [KYPEnrollment].[AccountSearch] WHERE [AccountID]=@old_account_id AND [ScheduledStatus] like '%Unscheduled%' AND [AccountSearchEnabled]=1  
  
  UPDATE [KYPEnrollment].[AccountSearch] SET [ScheduledStatus]='Completed',[AccountSearchEnabled]=0 WHERE [AccountID]=@old_account_id   
  END


 GO

