-- =============================================
-- Author:  <DHBO>
-- Create date: <11/12/2017>
-- Description: <This procedure generates package for the Transportation Mode Incorporated (Other Entities) >
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_F_OOS_OE] (
       @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT,
	@last_Action_User_ID VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@account_type VARCHAR(10),
	@application_type VARCHAR(30) = NULL)

AS
BEGIN
	DECLARE @new_Address_Id INT,
			@new_org_id INT,
			@party_contact_id INT,
			@party_contact_id_portal INT,
			@npi_Type VARCHAR(25),
			@npi VARCHAR (10),
			@provider_type_code VARCHAR(5),
	        @account_number VARCHAR(20),
	        @package varchar (10),
	        @isGroup BIT ;

	SELECT @npi_Type = [NPIType], @npi=NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber, @package = PackageName FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id
  select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id

	/*BizProfile Details*/
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,@new_Account_Id,@new_Party_Id,@last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';

	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id

	/*Business Profile*/
	EXEC @new_org_id = [KYPEnrollment].[sp_Copy_Business_Profile]@new_Party_Id, @party_Id,@last_Action_User_ID;

	/*Contact Person*/
	EXEC [KYPEnrollment].[sp_Contact_Person] @party_Id, @new_Party_Id,@last_Action_User_ID,@new_Account_Id;

	/*Address*/
	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Mailing', @last_Action_User_ID;

	/*Place Business*/
	EXEC [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;

	/*Insurance*/
	EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id, @party_Id,@last_Action_User_ID;

	/* Prof. Licenses Certificates*/
	EXEC [KYPEnrollment].[sp_Copy_Clia] @new_Party_Id, @party_Id, @last_action_user_id, NULL;

	/* Taxonomy Speciality */
	EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id, @party_Id, @last_Action_User_ID, NULL;

	/*Reason for enrollment*/
   EXEC [KYPEnrollment].[sp_Copy_ReasonEnrollment] @new_Party_Id, @party_Id,@last_Action_User_ID;

	/*Program Participation*/
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;

	/*Adverse Action*/
	EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;

	/* Fines and debts */
	EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_Id, @new_Party_Id, @last_Action_User_ID,NULL;

	--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
	IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
	BEGIN
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_Party_Id, null,@application_Id,@party_Id, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
		
	END

	/* PaymentDetail */
	EXEC [KYPEnrollment].[sp_Copy_PaymentDetail] @party_Id, @new_Party_Id, @last_Action_User_ID;

	/*ApplicationFee*/
	EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id, @party_Id,@last_Action_User_ID;

	/*Unique Party*/
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account]@new_Party_Id, @new_account_id, @npi_Type, @last_Action_User_ID,0;

	/*Update data Account and Linked*/
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_org_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id, @party_Id, 0, @provider_type_code, @account_number, NULL,@account_type,@application_Id,@isGroup ,@application_type;

END


GO

