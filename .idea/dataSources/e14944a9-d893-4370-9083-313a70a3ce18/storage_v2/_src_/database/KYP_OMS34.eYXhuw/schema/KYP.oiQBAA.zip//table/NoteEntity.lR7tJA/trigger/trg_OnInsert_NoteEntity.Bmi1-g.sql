



-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle attachment count in the table KYP.FrameworkCount
--				On insert in the table KYP.NoteEntity 
--				The trigger is written with the assumption that inserts on table KYP.NoteEntity
--				occur on a row by row basis and not bulk inserts to the table.
-- =============================================
CREATE TRIGGER [KYP].[trg_OnInsert_NoteEntity]
   ON  [KYP].[NoteEntity]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	IF EXISTS (
			SELECT 1 
			FROM KYP.FrameworkCount A INNER JOIN INSERTED B 
				ON A.FrameworkEntityType = B.NoteEntityType
				AND A.FrameworkEntityTypeID = B.NoteEntityTypeID
		)
		BEGIN
		
		UPDATE A 
			SET A.NoteCount = A.NoteCount + 1,
				A.ModifiedDate = getdate(), 
				A.ModifiedBy = 'Note Increased'
		FROM KYP.FrameworkCount A INNER JOIN inserted t on a.FrameworkEntityType=t.NoteEntityType and a.FrameworkEntityTypeID=t.NoteEntityTypeID
		OPTION(MAXDOP 1)
		
		END
		ELSE 
		INSERT INTO [KYP].[FrameworkCount]
			   ([FrameworkEntityType]
			   ,[FrameworkEntityTypeID]
			   ,[NoteCount] 
			   ,[DocumentCount]
			   ,[CommunicationCount]
			   ,[CreatedDate]
			   ,[CreatedBy]
			   ,[ModifiedDate]
			   ,[ModifiedBy]
			   ,[IsDeleted])
		 SELECT NoteEntityType
			   ,NoteEntityTypeID
			   ,1 as NoteCount
			   ,0 as DocumentCount
			   ,0 as CommunicationCount
			   ,getdate() as CreatedDate
			   ,'Note Created' as CreatedBy
			   ,NULL
			   ,NULL
			   ,0
		FROM INSERTED  
	

    

END


GO

