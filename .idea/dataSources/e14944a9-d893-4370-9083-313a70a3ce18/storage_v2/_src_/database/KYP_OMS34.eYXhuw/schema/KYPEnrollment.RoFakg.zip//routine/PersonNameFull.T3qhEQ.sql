CREATE FUNCTION [KYPEnrollment].[PersonNameFull](@PartyID int)
RETURNS varchar(500)
AS 
BEGIN
  Declare @vResult varchar(500)
  Declare @vPartial varchar(500)

  DECLARE Cur_ESFS CURSOR FOR
  
  select (p.FirstName+' '+ISNULL(p.MiddleName ,'')+' '+ISNULL(p.LastName ,'')) as Name from KYP.PDM_Person p where p.PartyID=@PartyID
  
  OPEN Cur_ESFS  
  
  SET @vResult='';
  SET @vPartial='';
  FETCH Cur_ESFS INTO @vPartial
  WHILE (@@FETCH_STATUS = 0)
  BEGIN	
	SET @vResult = @vPartial	
	FETCH Cur_ESFS INTO @vPartial
  END 
  CLOSE Cur_ESFS
  DEALLOCATE Cur_ESFS
  SET @vResult = @vResult 
  return @vResult
END;


GO

