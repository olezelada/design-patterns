



--July 07
----

--http://jira/browse/KYP-3044
--VIEWS TO MODIFY:
--1. [v_AssignedUnassignedCases]
--2. [v_TimeToFirstAssignment]
--3. [v_TurnAroundTime]
--4. [v_TurnAroundTimeCasesDetails]
--5. [v_ApplicationDetails]
--6. [v_TimeToFirstAssignmentCasesDetails] 
CREATE VIEW [KYP].[v_AssignedUnassignedCases]
AS
SELECT     row_number() OVER (ORDER BY FormattedDate ASC) AS ID, *
FROM         (

SELECT F.FormattedDate As FormattedDate,ISNULL(D.AssignedCount,0) As AssignedCount,ISNULL(D.UnassignedCount,0) As UnassignedCount,F.DateReceived AS DateReceived  FROM 
(
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -1), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 1)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -2), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 2)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -3), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 3)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -4), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 4)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -5), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 5)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -6), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 6)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -7), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 7)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -8), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 8)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -9), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 9)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -10), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 10)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -11), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 11)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -12), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 12)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -13), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 13)) As DateReceived UNION ALL
Select CONVERT(VARCHAR(5),DATEADD(DD, DATEDIFF(DD, 0, GETDATE()), -14), 101) AS FormattedDate , DATEADD(dd, 0, DATEDIFF(dd, 0, GETDATE() - 14)) As DateReceived) F

LEFT JOIN(

SELECT     CONVERT(VARCHAR(5), DateReceived, 101) AS FormattedDate, SUM(CASE WHEN StatusCodeNumber NOT IN (12, 14) THEN 1 ELSE 0 END) 
AS AssignedCount, SUM(CASE WHEN StatusCodeNumber IN (12, 14) THEN 1 ELSE 0 END) AS UnassignedCount, DATEADD(dd, 0, DATEDIFF(dd, 0, 
DateReceived)) AS DateReceived FROM KYP.ADM_Case
WHERE (CAST(DateReceived AS DATE) >= CAST(GETDATE() - 14 AS DATE)) AND IsPPURequired = 0
GROUP BY CONVERT(VARCHAR(5), DateReceived, 101), DATEADD(dd, 0, DATEDIFF(dd, 0, DateReceived))
)D ON F.FormattedDate = D.FormattedDate

) Z


GO

