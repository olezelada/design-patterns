
CREATE VIEW [KYP].[v_EDIScrFileForNM]
AS
SELECT row_number() OVER (ORDER BY APP_STATUS ASC) AS ID, *
FROM
(

/*********************************************************************************************************************************/
/* NEW APPLICATIONS */
/*********************************************************************************************************************************/

SELECT 
DISTINCT
RIGHT(REPLICATE('0', 8) + CAST(A.CaseID AS VARCHAR(8)), 8) AS APP_NUM,
D.ProvNumber AS 'PROV_NUM', 
D.NPI AS 'APPLICANT_NPI', 
'CASECreated' AS 'APP_STATUS',
A.DateCreated AS 'DATE_REC',
'' AS 'SENT_BY',
'' AS 'SP_REMARKS'
FROM KYP.ADM_Case A
INNER JOIN KYP.ADM_Application B 
	ON A.CaseID = B.CaseID
LEFT OUTER JOIN KYP.SDM_ApplicationParty C
	ON C.ApplicationID = B.ApplicationID
INNER JOIN KYP.PDM_Provider D
	ON D.PartyID = C.PartyID
WHERE A.StatusCodeNumber = 12
AND CurrentMinorDisposition = 'Provider Check'
AND ActivityStatus = 'In Progress'
AND WFMinorStep = 'Unassigned' /*KYP-17742*/
AND CONVERT(VARCHAR, A.DateCreated, 101) =  CONVERT(VARCHAR, GETDATE() - 1, 101)  

UNION ALL

/*********************************************************************************************************************************/
/* SEND TO STATE * SEND TO XEROX * APPROVED BY XEROX * APPROVED BY STATE * REJECTED BY XEROX * REJECTED BY STATE */
/*********************************************************************************************************************************/


SELECT 
DISTINCT
RIGHT(REPLICATE('0', 8) + CAST(A.CaseID AS VARCHAR(8)), 8) AS APP_NUM,
D.ProvNumber AS 'PROV_NUM', 
D.NPI AS 'APPLICANT_NPI', 
CASE
	WHEN E.MinorStatus	='Ignore Application' THEN 'Ignore Application'
	WHEN E.RoleName = 'Supervisor' OR E.RoleName='SupervisorS' THEN E.MinorStatus+'Sup'
	WHEN E.RoleName = 'Approver' OR E.RoleName='ApproverS' THEN E.MinorStatus+'Appr'
	WHEN E.RoleName = 'Reviewer' OR E.RoleName='ReviewerS' THEN E.MinorStatus+'Rev'
	WHEN E.RoleName = 'Confirmer' OR E.RoleName='ConfirmerS' THEN E.MinorStatus+'Con'
	WHEN E.ActivityStatus = 'Return' THEN 'Set ResolutionRev'
    END  AS 'APP_STATUS',
E.DateTime AS 'DATE_REC',
E.UserFullName AS 'SENT_BY',
REPLACE(REPLACE(CONVERT(VARCHAR(1000), E.Notes), CHAR(13), ' '), CHAR(10), ' ') AS 'SP_REMARKS'

FROM KYP.ADM_Case A
INNER JOIN KYP.ADM_Application B ON A.CaseID = B.CaseID
LEFT OUTER JOIN KYP.SDM_ApplicationParty C ON B.ApplicationID = C.ApplicationID AND C.PartyType = 'Provider'
LEFT OUTER JOIN KYP.PDM_Provider D ON D.PartyID = C.PartyID
INNER JOIN KYP.ADM_WorkflowHistory E ON E.CaseID = A.CaseID 
AND E.DateTime = 
(SELECT MAX(DateTime) FROM KYP.ADM_WorkflowHistory z 
	WHERE z.CaseID = a.CaseID 
	AND 
	(
		(z.MinorStatus IN ( 'Assign Application','Accept Assignment') AND z.RoleName IN ('Confirmer','Approver'))
		OR 
		(z.ActivityStatus = 'Return')
	)
)		
WHERE A.CurrentMajorDisposition = 'Screening' AND A.WFStatus <> 'Completed' 
AND WFMinorStep <> 'Unassigned'
AND CONVERT(VARCHAR, E.DateTime, 101) =  CONVERT(VARCHAR, GETDATE() - 1, 101)  

UNION ALL


/*********************************************************************************************************************************/
/* CLOSED APPLICATIONS */
/*********************************************************************************************************************************/

SELECT 
 distinct 
RIGHT(REPLICATE('0', 8) + CAST(A.CaseID AS VARCHAR(8)), 8) AS APP_NUM,
D.ProvNumber AS 'PROV_NUM', 
D.NPI AS 'APPLICANT_NPI', 
'CASEComplete' AS 'APP_STATUS',
A.DateResolved AS 'DATE_REC',
U.FullName AS 'SENT_BY',
REPLACE(REPLACE(CONVERT(VARCHAR(1000), E.Notes), CHAR(13), ' '), CHAR(10), ' ') AS 'SP_REMARKS'
FROM KYP.ADM_Case A
INNER JOIN KYP.ADM_Application B ON A.CaseID = B.CaseID
LEFT OUTER JOIN KYP.SDM_ApplicationParty C ON C.ApplicationID = B.ApplicationID
INNER JOIN KYP.PDM_Provider D ON D.PartyID = C.PartyID
INNER JOIN KYP.OIS_User U ON A.CurrentlyAssignedToName = U.UserID
INNER JOIN KYP.ADM_WorkflowHistory E ON E.CaseID = A.CaseID AND E.DateTime = (SELECT max(datetime) from KYP.ADM_WorkflowHistory z WHERE z.CaseID = a.CaseID AND z.MinorStatus IN ('Completed','Ignore Application') AND z.ActivityStatus='Completed')
WHERE CurrentMajorDisposition = 'Screening' AND WFStatus = 'Completed'  AND CONVERT(VARCHAR, A.DateResolved, 101) =  CONVERT(VARCHAR, GETDATE() - 1, 101)  
)Z


GO

