


/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMPerson]
(
@PartyID int
 ,@PersonNumber varchar(25)=NULL
 ,@PersonCategory varchar(25)= NULL
 ,@SSN varchar(11) =NULL
 ,@Salunation varchar(25) = NULL
 ,@FirstName varchar(25)=NULL
 ,@LastName varchar(25)=NULL
 ,@MiddleName varchar(25)=NULL
 ,@Gender varchar(11)=NULL
 ,@DoB varchar(20)=NULL
 ,@DoD Datetime=NULL
 --,@NPI int=NULL
 ,@NPI VARCHAR(10) = NULL
 ,@Email1 varchar(50)=NULL
 ,@Phone1 varchar(15)=NULL
 ,@Email2 varchar(50)=NULL
 ,@Phone2 varchar(50)=NULL
 ,@Alias1 varchar(15)=NULL
 ,@Alias2 varchar(15)=NULL
 ,@CityofBirth varchar(25)=NULL
 ,@StateofBirth varchar(25)=NULL
 ,@CountyofBirth varchar(25)=NULL
 ,@Ethnicity varchar(50)=NULL
,@Remark varchar(250)=NULL
,@CurrentModule smallint=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified datetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
 ,@TaxId varchar(9)=NULL /*KYP-16130*/
 ,@TypeOfParty varchar(50) = NULL
)
as begin 
declare @DoBCorrected datetime

begin try 
	select @DoBCorrected = convert(datetime,@DoB,121)
end try 
begin catch
	select @DoBCorrected = NULL
end catch 


INSERT INTO [KYP].[PDM_Person]
           ([PartyID]
           ,[PersonNumber]
           ,[PersonCategory]
           ,[SSN]
           ,[Salunation]
           ,[FirstName]
           ,[LastName]
           ,[MiddleName]
           ,[Gender]
           ,[DoB]
           ,[DoD]
           ,[NPI]
           ,[Email1]
           ,[Phone1]
           ,[Email2]
           ,[Phone2]
           ,[Alias1]
           ,[Alias2]
           ,[CityofBirth]
           ,[StateofBirth]
           ,[CountyofBirth]
           ,[Ethnicity]
           ,[Remark]
           ,[CurrentModule]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[TaxId]
           ,[TypeOfParty])/*KYP-16130*/
     VALUES
           (@PartyID
           ,@PersonNumber
           ,@PersonCategory
           ,@SSN
           ,@Salunation
           ,@FirstName
           ,@LastName
           ,@MiddleName
           ,@Gender
           ,@DoBCorrected
           ,@DoD
           ,@NPI
           ,@Email1
           ,@Phone1
           ,@Email2
           ,@Phone2
           ,@Alias1
           ,@Alias2
           ,@CityofBirth
           ,@StateofBirth
           ,@CountyofBirth
           ,@Ethnicity
           ,@Remark
           ,@CurrentModule
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@TaxId
           ,@TypeOfParty)/*KYP-16130*/

	return IDENT_CURRENT('[KYP].[PDM_Person]')

end


GO

