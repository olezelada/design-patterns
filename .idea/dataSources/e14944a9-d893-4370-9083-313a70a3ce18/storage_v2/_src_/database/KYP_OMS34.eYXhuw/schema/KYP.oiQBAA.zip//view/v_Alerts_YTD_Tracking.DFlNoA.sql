





CREATE VIEW [KYP].[v_Alerts_YTD_Tracking]
AS
SELECT row_number() OVER (
		ORDER BY A.id
		) AS ID
	,A.YearNo
	,A.MonthNo
	,A.ProvidersRecieved
	,A.TotalAlerts
	,B.ConfirmedAlerts
	,B.FalsePositives
	,B.IgnoredAlerts
	,C.ExclusionBasedAlerts
	,C.VerificationBasedAlerts
	,COALESCE(D.ActionTakenOn, 0) AS ActionTakenOn
FROM (
	SELECT x.ID
		,x.Year AS YearNo
		,DATENAME(month, '1900/' + CAST(x.month AS VARCHAR(2)) + '/01') AS MonthNo
		,x.ProvidersRecieved
		,count(y.alertid) AS TotalAlerts
	FROM KYP.MDM_MonthlyActiveProvider x
	INNER JOIN kyp.mdm_alert y ON DATENAME(month, '1900/' + CAST(x.month AS VARCHAR(2)) + '/01') = DATENAME(month, y.dateinitiated)
	and CAST(x.Year AS VARCHAR(4))  = DATENAME(YEAR, y.dateinitiated) /*PI-147*/
	GROUP BY x.ID
		,x.Year
		,x.month
		,x.ProvidersRecieved
	) A
LEFT JOIN (
	SELECT id
		,ConfirmedAlerts
		,FalsePositives
		,IgnoredAlerts
	FROM (
		SELECT x.id
			,y.alertid
			,CASE 
				WHEN y.MatchStatusIndicator = 'C'
					THEN 'ConfirmedAlerts'
				WHEN y.MatchStatusIndicator = 'F'
					THEN 'FalsePositives'
				WHEN y.MatchStatusIndicator = 'I'
					THEN 'IgnoredAlerts'
				END AS MatchStatusIndicator
		FROM KYP.MDM_MonthlyActiveProvider x
		INNER JOIN kyp.mdm_alert y ON DATENAME(month, '1900/' + CAST(x.month AS VARCHAR(2)) + '/01') = DATENAME(month, y.dateinitiated)
		and CAST(x.Year AS VARCHAR(4))  = DATENAME(YEAR, y.dateinitiated) /*PI-147*/
		) x
	pivot(count(alertid) FOR MatchStatusIndicator IN (
				[ConfirmedAlerts]
				,[FalsePositives]
				,[IgnoredAlerts]
				)) AS pivottable
	) B ON A.Id = B.ID
LEFT JOIN (
	SELECT id
		,ExclusionBasedAlerts
		,VerificationBasedAlerts
	FROM (
		SELECT x.id
			,y.alertid
			,CASE 
				WHEN y.WatchListName IN (
						'OIG LEIE'
						,'SAM'
						,'Sanction Status'
						,'Medicaid & Medicare Exclusion'
						,'Internal Watchlist'
						,'S&I Watchlist'
						)
					THEN 'ExclusionBasedAlerts'
				WHEN y.WatchListName IN (
						'SSA DMF'
						,'License Status'
						,'Licensure'
						,'NPI Issues'
						,'Individual NPI'
						,'Organization NPI'
						,'LicensureAlerts'
						)
					THEN 'VerificationBasedAlerts'
				END AS WatchlistName
		FROM KYP.MDM_MonthlyActiveProvider x
		INNER JOIN kyp.mdm_alert y ON DATENAME(month, '1900/' + CAST(x.month AS VARCHAR(2)) + '/01') = DATENAME(month, y.dateinitiated)
		and CAST(x.Year AS VARCHAR(4))  = DATENAME(YEAR, y.dateinitiated)/*PI-147*/
		) x
	pivot(count(alertid) FOR WatchListName IN (
				ExclusionBasedAlerts
				,VerificationBasedAlerts
				)) AS pivottable
	) C ON A.ID = C.ID
LEFT JOIN (
	SELECT x.id
		,count(DISTINCT y.alertid) AS ActionTakenOn
	FROM KYP.MDM_MonthlyActiveProvider x
	INNER JOIN kyp.mdm_alert y ON DATENAME(month, '1900/' + CAST(x.month AS VARCHAR(2)) + '/01') = DATENAME(month, y.dateinitiated)
	and CAST(x.Year AS VARCHAR(4))  = DATENAME(YEAR, y.dateinitiated) /*PI-147*/
	INNER JOIN kyp.mdm_alertresolution z ON y.alertid = z.alertid
	WHERE z.isdeleted <> 1 
	
	GROUP BY x.id
	) D ON A.Id = D.Id


GO

