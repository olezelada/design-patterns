
-- =============================================
-- Author:		Amita Karan
-- Create date: 09/16/2014
-- Description:	KYP3.3 Req#8 Maintain application history and maintain it by provider accounts and profile
-- =============================================
CREATE PROCEDURE [KYP].[p_createProviderAccount]
	-- Add the parameters for the stored procedure here
	@ProfileName VARCHAR(150)
	,@NPI INT
	,@TIN VARCHAR(11)
	,@SSN VARCHAR(11)
	,@PracticeType VARCHAR(50)
	,@DateCreated DATETIME
	,@DateDeleted DATETIME
	,@AccountNumber VARCHAR(15)
	,@ProviderName VARCHAR(150)
	,@PracticeAddress1 VARCHAR(250)
	,@PracticeAddress2 VARCHAR(250)
	,@City VARCHAR(25)
	,@State VARCHAR(25)
	,@Zip VARCHAR(5)
	,@ProviderStatus VARCHAR(50)
	,@ProfileID INT
	,@IsDeleted BIT
	,@Specialty VARCHAR(225)
	/** Newly Added parameters for Account Viewer related to Monitoring **/
	,@AccGenNumber VARCHAR(50)
	,@ProviderType VARCHAR(200)
	,@DBAName VARCHAR(200)
	,@DEA VARCHAR(20)
	,@DOB DATETIME
	,@CLIA VARCHAR(20)
	,@PhoneNumber VARCHAR(15)
	,@FileType VARCHAR(1)
	,@Account_Practice_Type varchar(500)
AS
BEGIN
	DECLARE	@PDM_FoundorNot INT
		,@PDM_ACID INT
		,@pro_ID INT
		,@PDM_PROVIDERProfile INT
		,@P_Account INT
		,@PDM_upAccount INT

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for procedure here    
	EXEC @PDM_FoundorNot = [KYP].[p_FindPDMProviderProfile] @NPI
		,@TIN
		,@SSN
		,@PracticeType

	IF @PDM_FoundorNot = - 1
	BEGIN
		IF @FileType = 'D'
		BEGIN
			EXEC @PDM_PROVIDERProfile = [KYP].[p_InsertPDMProviderProfile] @ProfileName
				,@NPI
				,@TIN
				,@SSN
				,@PracticeType
				,@DateCreated
				,@DateDeleted
				,@IsDeleted

			--PRINT 'Insert new record in the Provider Account'

			SELECT @pro_ID = ProfileID
			FROM kyp.PDM_ProviderProfile
			WHERE (NPI = @NPI)
				OR (
					SSN = @SSN
					AND PracticeType = @PracticeType
					)
				OR (
					TIN = @TIN
					AND PracticeType = @PracticeType
					);
		END

		EXEC @PDM_ACID = [KYP].[p_FindPDMProviderAccount] @AccountNumber, @AccGenNumber

		IF @PDM_ACID = - 1
		BEGIN
			EXEC @P_Account = [KYP].[p_InsertPDMProviderAccount] @AccountNumber = @AccountNumber
				,@ProviderName = @ProviderName
				,@NPI = @NPI
				,@PracticeAddress1 = @PracticeAddress1
				,@PracticeAddress2 = @PracticeAddress2
				,@City = @City
				,@State = @State
				,@Zip = @Zip
				,@ProviderStatus = @ProviderStatus
				,@ProfileID = @pro_ID
				,@DateCreated = @DateCreated
				,@DateDeleted = @DateDeleted
				,@IsDeleted = @IsDeleted
				,@Specialty = @Specialty
				,@SSN = @SSN
				,@TIN = @TIN
				,@AccGenNumber = @AccGenNumber
				,@ProviderType = @ProviderType
				,@DBAName  = @DBAName
				,@DEA = @DEA
				,@DOB = @DOB
				,@CLIA = @CLIA
				,@PhoneNumber = @PhoneNumber
				,@Account_Practice_Type=@Account_Practice_Type
		END
		ELSE
		BEGIN
			EXEC @PDM_upAccount = [KYP].[p_UpdatePDMAccount] @AccountNumber = @AccountNumber
				,@ProviderName = @ProviderName
				,@NPI = @NPI
				,@PracticeAddress1 = @PracticeAddress1
				,@PracticeAddress2 = @PracticeAddress2
				,@City = @City
				,@State = @State
				,@Zip = @Zip
				,@ProviderStatus = @ProviderStatus
				,@ProfileID = @pro_ID
				,@DateCreated = @DateCreated
				,@DateDeleted = @DateDeleted
				,@IsDeleted = @IsDeleted
				,@Specialty = @Specialty
				,@SSN = @SSN
				,@TIN = @TIN
				,@AccGenNumber = @AccGenNumber
				,@ProviderType = @ProviderType
				,@DBAName  = @DBAName
				,@DEA = @DEA
				,@DOB = @DOB
				,@CLIA = @CLIA
				,@PhoneNumber = @PhoneNumber
				,@Account_Practice_Type=@Account_Practice_Type
		END
	END
	ELSE
	BEGIN
		SELECT @pro_ID = ProfileID
		FROM KYP.PDM_ProviderProfile
		WHERE (NPI = @NPI)
			OR (
				SSN = @SSN
				AND PracticeType = @PracticeType
				)
			OR (
				TIN = @TIN
				AND PracticeType = @PracticeType
				);

		EXEC @PDM_ACID = [KYP].[p_FindPDMProviderAccount] @AccountNumber, @AccGenNumber

		IF @PDM_ACID = - 1
		BEGIN
			EXEC @P_Account = [kyp].[p_InsertPDMProviderAccount] @AccountNumber = @AccountNumber
				,@ProviderName = @ProviderName
				,@NPI = @NPI
				,@PracticeAddress1 = @PracticeAddress1
				,@PracticeAddress2 = @PracticeAddress2
				,@City = @City
				,@State = @State
				,@Zip = @Zip
				,@ProviderStatus = @ProviderStatus
				,@ProfileID = @pro_ID
				,@DateCreated = @DateCreated
				,@DateDeleted = @DateDeleted
				,@IsDeleted = @IsDeleted
				,@Specialty = @Specialty
				,@SSN = @SSN
				,@TIN = @TIN
				,@AccGenNumber = @AccGenNumber
				,@ProviderType = @ProviderType
				,@DBAName  = @DBAName
				,@DEA = @DEA
				,@DOB = @DOB
				,@CLIA = @CLIA
				,@PhoneNumber = @PhoneNumber
				,@Account_Practice_Type=@Account_Practice_Type
		END
		ELSE
		BEGIN
			--PRINT 'Update record in the Provider Account'

			EXEC @PDM_upAccount = [KYP].[p_UpdatePDMAccount] @AccountNumber = @AccountNumber
				,@ProviderName = @ProviderName
				,@NPI = @NPI
				,@PracticeAddress1 = @PracticeAddress1
				,@PracticeAddress2 = @PracticeAddress2
				,@City = @City
				,@State = @State
				,@Zip = @Zip
				,@ProviderStatus = @ProviderStatus
				,@ProfileID = @pro_ID
				,@DateCreated = @DateCreated
				,@DateDeleted = @DateDeleted
				,@IsDeleted = @IsDeleted
				,@Specialty = @Specialty
				,@SSN = @SSN
				,@TIN = @TIN
				,@AccGenNumber = @AccGenNumber
				,@ProviderType = @ProviderType
				,@DBAName  = @DBAName
				,@DEA = @DEA
				,@DOB = @DOB
				,@CLIA = @CLIA
				,@PhoneNumber = @PhoneNumber
				,@Account_Practice_Type=@Account_Practice_Type
		END
	END
END


GO

