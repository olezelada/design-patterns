-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Residential_Address] 

@new_Account_Id int
--,@acc_party_id int no es necesario

AS
BEGIN
Declare @address int,@location int
	SET NOCOUNT ON;

select @address = ad.AddressID, @location = l.LocationID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID 
INNER JOIN KYPEnrollment.pAccount_PDM_Location l ON l.PartyID=p.PartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Address ad ON l.AddressID=ad.AddressID
where a.AccountID=@new_Account_Id and l.Type='Individual Profile' and l.CurrentRecordFlag=1 and l.IsDeleted=0 and ad.CurrentRecordFlag=1

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Address','AddressID',@address

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Location','LocationID',@location

END


GO

