





-- =============================================
-- Authors:   <Rahul Raghavendra>
-- Script Date: 17/08/2017
-- =============================================

CREATE TRIGGER [KYPEnrollment].[CopyAffiliat] ON [KYPEnrollment].[MD_pAccountAffiliatDetail]
WITH EXECUTE AS CALLER
FOR insert 
AS
BEGIN	
SET NOCOUNT ON;
	--SET IMPLICIT_TRANSACTIONS ON
			DECLARE 			
			@account_id INT,
            @userID VARCHAR(50)
           		    
		    select @account_id = AccountID from inserted
		    select @userID = UserID from inserted
		    
		    delete from KYPEnrollment.pAccountAffiliatDetail where UserID=@userID AND ParentAccountID = @account_id;
		    	    
		    Execute [KYPEnrollment].[sp_AccountAffiliatDetail] @account_id,@userID
		
		   
						
	
END


GO

