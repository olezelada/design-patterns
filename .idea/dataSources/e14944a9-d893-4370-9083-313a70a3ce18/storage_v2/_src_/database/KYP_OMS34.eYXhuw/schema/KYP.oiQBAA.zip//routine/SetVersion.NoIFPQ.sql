CREATE FUNCTION [KYP].[SetVersion] (@NoteID int, @ParentID int)
RETURNS VARCHAR(100)
AS
BEGIN
  Declare @Count int;
  Set @Count   = (select count(ParentID) from OIS_Note where  ( ois_note.ParentID <> 0 ) and ois_note.ParentID = @ParentID and ois_note.NoteID <= @NoteID);

       IF ( @ParentID = 0 )
          BEGIN
              RETURN CONVERT(varchar(100), 1)
          END

 RETURN CONVERT(varchar(100), @Count + 1);

END


GO

