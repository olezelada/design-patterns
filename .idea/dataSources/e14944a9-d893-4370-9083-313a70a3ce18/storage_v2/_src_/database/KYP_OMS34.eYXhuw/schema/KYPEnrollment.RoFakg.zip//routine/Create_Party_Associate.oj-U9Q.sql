
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: 
-- PARAMETERS: 

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Create_Party_Associate]
@main_party_id INT,
@party_id INT,
@account_id INT,
@type VARCHAR(50),
@party_id_app INT

AS
BEGIN
SET NOCOUNT ON 
PRINT'[Create_Party_Associate]'

INSERT INTO [KYPEnrollment].[pAccount_Party_Associate]
           ([MainPartyID]
           ,[PartyID]
           ,[AccountID]
           ,[Type]
           ,[IdentityPartyID]
           ,[CurrentRecordFlag])
     VALUES
           (@main_party_id
           ,@party_id
           ,@account_id
           ,@type
           ,@party_id_app
           ,1)
END


GO

