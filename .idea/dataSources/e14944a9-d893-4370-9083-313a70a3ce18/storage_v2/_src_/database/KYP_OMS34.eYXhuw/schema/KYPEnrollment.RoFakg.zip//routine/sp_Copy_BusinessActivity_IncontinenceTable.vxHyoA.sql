
-- =============================================
-- Author:		<jvera>
-- Create date: <02/23/2018>
-- Description:	<This procedure copy Incontinence Tables>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_BusinessActivity_IncontinenceTable]
   @party_id               INT,
   @account_party_id           INT,
   @last_action_user_id    VARCHAR (100),  
   @app_party_row_id       INT,
   @account_id             INT,
   @isUpdateAccount          BIT = 0
AS
BEGIN
	
	IF (@isUpdateAccount = 1)
	BEGIN	
		print 'Update Account: clean information incontinence';
		update KYPEnrollment.pAccount_PDM_ProviderQuestionnarie set CurrentRecordFlag = 0 where PartyID = @account_party_id and Type= 'incontinence'
		update KYPEnrollment.pAccount_PDM_BusinessActivity set CurrentRecordFlag = 0 where PartyID = @account_party_id

		 DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT                       
                        )
                        
         INSERT INTO @party
            SELECT p.PartyID
                   
              FROM KYPEnrollment.pAccount_PDM_Party p
             WHERE     ParentPartyID = @account_party_id
                   AND p.type in ('lineCredit', 'manufacturer','capitalSource')
                   AND p.CurrentRecordFlag = 1
         DECLARE
            @cont   INT,
            @tot    INT
		/*	SELECT @tot = MAX (pk) FROM @party
			SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
			DECLARE
			@party_adr  INT,
			@addressId	INT;

			  SELECT @party_adr = PartyID FROM @party WHERE pk = @cont*/

			  UPDATE KYPEnrollment.pAccount_PDM_Party set CurrentRecordFlag = 0 where PartyID  in (SELECT  partyID FROM @party)

			  UPDATE KYPEnrollment.pAccount_PDM_Organization set CurrentRecordFlag = 0 where PartyID in (SELECT  partyID  FROM @party)

			  UPDATE KYPEnrollment.pAccount_PDM_Location set CurrentRecordFlag = 0 where PartyID in (SELECT  partyID  FROM @party)

			 -- select @addressId	= addressId from KYPEnrollment.pAccount_PDM_Location where PartyID = @party_adr;

			  UPDATE KYPEnrollment.pAccount_PDM_Address set CurrentRecordFlag = 0 
			  WHERE  AddressID  in ( select addressId from KYPEnrollment.pAccount_PDM_Location where PartyID in  (SELECT  partyID FROM @party))
				--**
		 /*	SET @cont = @cont + 1
         END*/
      --end while
      
	END
  -- copy business activity

	EXEC [KYPEnrollment].[sp_Copy_Business_Activity] @party_Id, @account_party_id, @last_Action_User_ID, NULL;

	-- Copy incontince tables
	IF EXISTS (
	SELECT *
		FROM	[KYPPORTAL].[PortalKYP].[pPDM_BusinessActivity] 
		WHERE	PartyID =  @party_id 
		AND	Activity = 'Incontinence Medical Supplies'
				AND Approved = 1
				AND IsDeleted = 0
				)
	BEGIN
		PRINT 'COPY INCONTINENCE INFORMATION';
		EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @account_party_id, 'incontinence'
		EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Incontinence]  @party_Id, @account_party_id, @last_action_user_id, NULL,  @account_id , NULL;	
	END
	else
	begin
		print 'NO COPY INCONTINENCE BECAUSE NOT APPROVED OR NOT EXIST BUSINESS ACTIVITY: INCONTINENCE MEDICAL SUPPLIES';
	end
END

GO

