-- =============================================
-- Author:		<DH-BOL>
-- Create date: <12/14/2017>
-- Description:	<This procedure puts in delete mode rows related to the reasonEnrollment of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Business_Permit_Section]
@new_Account_Id int

AS
BEGIN
UPDATE [KYPEnrollment].[pAccount_PDM_Number]
      SET  IsDeleted=0, CurrentRecordFlag = 0
    WHERE NumberID IN
			(SELECT NumberID
				FROM KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Number] n ON a.PartyID=n.PartyID
				WHERE a.IsDeleted=0 and n.CurrentRecordFlag=1	and n.IsDeleted =0  and a.AccountID=@new_Account_Id and n.Type IN ('Permit Local Number','BusinessPermits'))

END


GO

