
CREATE PROCEDURE [KYP].[ExportApplication]
AS
  BEGIN

    DECLARE @filename VARCHAR(200)
    SET @filename = 'Direct Portal Temporal table insertion'
    DECLARE @filecreationdate DATE
    SET @filecreationdate = convert(DATE, CURRENT_TIMESTAMP)
    BEGIN TRY
    
	Delete from dbo.ErroredProvidersForTheDay;   
    Delete From dbo.ErroredProvidersFromFile;

    --delete unwanted records from staging tables
    DELETE FROM dbo.ProviderLicense
    WHERE P_LIC_CERT_NUM IS NULL
    DELETE FROM dbo.ProviderSecondaryNPI
    WHERE P_ALT_ID IS NULL
    DELETE FROM dbo.ProviderMedicare
    WHERE P_MCARE_NUM IS NULL
    DELETE FROM dbo.ProviderCLIA
    WHERE P_CLIA_NUM IS NULL
    DELETE FROM dbo.ProviderIndOwner
    WHERE P_OWNER_LAST_NAM IS NULL AND P_OWNER_FST_NAM IS NULL
    DELETE FROM dbo.ProviderOrgOwner
    WHERE P_OWNER_BUSN_NAM IS NULL AND P_OWNER_DBA_NAM IS NULL
    DELETE FROM dbo.ProviderEmployee
    WHERE P_EMPL_LAST_NAM IS NULL AND P_EMPL_FST_NAM IS NULL
    DELETE FROM dbo.ProviderSpeciality
    WHERE P_SPECL_CD IS NULL
    DELETE FROM dbo.ProviderDEA
    WHERE P_DEA_NUM IS NULL
    --execute the loading proc
    EXEC dbo.p_LoadDailyMonthlyFile_Direct_DB
    --populate monthly active providers in MDM_MonthlyActiveProvider
    EXEC [dbo].[p_MonthlyActiveProviders]
    --delete duplicate license
    EXEC [dbo].[RemoveDuplicateLicense]
    --Email Rejected App
    --EXEC [dbo].[p_AutoApplnRejEmail] @filename, @filecreationdate

    --clear the staging tables
    --TRUNCATE TABLE dbo.ErroredProvidersForTheDay
    --TRUNCATE TABLE dbo.ErroredProvidersFromFile
 --   TRUNCATE TABLE dbo.ProviderStagingFull
 --   TRUNCATE TABLE dbo.ProvidersForTheDay
 --   TRUNCATE TABLE dbo.ProviderNameAddress
 --   TRUNCATE TABLE dbo.ProviderCLIA
 --   TRUNCATE TABLE dbo.ProviderMedicare
 --   TRUNCATE TABLE dbo.ProviderSecondaryNPI
 --   TRUNCATE TABLE dbo.ProviderLicense
 --   TRUNCATE TABLE dbo.ProviderEmployee
 --   TRUNCATE TABLE dbo.ProviderIndOwner
 --   TRUNCATE TABLE dbo.ProviderOrgOwner
 --   TRUNCATE TABLE dbo.ProviderSpeciality
 --   TRUNCATE TABLE dbo.ProviderTaxonomy
 --   TRUNCATE TABLE dbo.ProviderDEA
	--TRUNCATE TABLE dbo.AdditionalProviderParties
		Delete From dbo.ProviderStagingFull;    
		Delete From dbo.ProvidersForTheDay;    
		Delete From dbo.ProviderNameAddress; 
		Delete From dbo.ProviderCLIA;
		Delete From dbo.ProviderMedicare ;   
		Delete From dbo.ProviderSecondaryNPI ;   
		Delete From dbo.ProviderLicense  ;  
		Delete From dbo.ProviderEmployee ;   
		Delete From dbo.ProviderIndOwner  ;  
		Delete From dbo.ProviderOrgOwner ;   
		Delete From dbo.ProviderSpeciality ;   
		Delete From dbo.ProviderTaxonomy;    
		Delete From dbo.ProviderDEA; 
		Delete From dbo.AdditionalProviderParties ; 	

    END TRY
    BEGIN CATCH
    BEGIN

      DECLARE @error_message NVARCHAR(4000), @error_severity INT;
      SELECT
        @error_message = ERROR_MESSAGE(),
        @error_severity = ERROR_SEVERITY();
      RAISERROR (@error_message, @error_severity, 1);
    END
    END CATCH


  END

GO

