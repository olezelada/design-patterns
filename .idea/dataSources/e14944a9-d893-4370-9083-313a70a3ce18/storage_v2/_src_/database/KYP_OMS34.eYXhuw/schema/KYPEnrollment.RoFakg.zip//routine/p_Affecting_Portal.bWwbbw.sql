
-- =============================================
-- Author:		<Author,,Lperez>
-- update portal recive 2 parametros
-- @applicationNo numero de aplicacion(identificador de aplicacion), @resolutionStat resolucion del revisor valor posibles(Approved,Deficiency Notice Sen,Denied and active)
-- NOTA: antes de ejecutar este script debe de activar DTC de sql server y activar su servicio como automatico
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Affecting_Portal] @applicationNo VARCHAR(50)
	,@resolutionStatus VARCHAR(100)
AS
BEGIN
	--This procedure is partially replaced by KYP.ADM_Case.WFStatus change trigger
	IF @resolutionStatus = 'Deficiency Notice Sent'
	BEGIN
		UPDATE [KYPPORTAL].[PortalKYP].[pADM_Case]
		SET [Status] = 'Return to Provider'
			,Submitted = 'false'
		WHERE [Number] = @applicationNo;

		UPDATE [KYPPORTAL].[PortalKYP].[pADM_Application]
		SET [IsRTP] = 'true'
		WHERE [ApplicationNo] = @applicationNo;
	END
END


GO

