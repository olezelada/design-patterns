



CREATE VIEW [KYP].[v_Alerts_MTD_Tracking]
AS
SELECT *
FROM (
	SELECT TOP (100) PERCENT row_number() OVER (
			ORDER BY A.ProvidersRecieved DESC
			) AS ID
		,datepart(year, getdate()) AS YearNo
		,ISNULL(A.ProviderType, 'Unknown') AS ProviderType
		,A.ProvidersRecieved
		,ISNull(B.Nbr, 0) AS TotalAlerts
		,ISNull(C.[ConfirmedAlerts], 0) AS [ConfirmedAlerts]
		,ISNull(C.[FalsePositives], 0) AS [FalsePositives]
		,ISNull(C.[IgnoredAlerts], 0) AS [IgnoredAlerts]
		,ISNull(D.VerificationBasedAlerts, 0) AS VerificationBasedAlerts
		,ISNull(D.ExclusionBasedAlerts, 0) AS ExclusionBasedAlerts
		,ISNull(E.Nbr, 0) AS [ActionTakenOn]
	FROM (
		SELECT m.ProviderType AS ProviderType
					,count(DISTINCT p.partyid) AS ProvidersRecieved
				FROM  KYP.MDM_Alert m
				LEFT JOIN kyp.MDM_PartyDetail p ON p.partyid=m.WatchedPartyID 
		GROUP BY m.ProviderType
		) A
	LEFT HASH JOIN (
		SELECT MDM_Alert_AllMonths.ProviderType AS ProviderType
			,count(DISTINCT alertid) AS Nbr
		FROM (
			SELECT alertid
				,dateinitiated
				,X.ProviderType AS ProviderType
			FROM (
				SELECT A.alertid
					,A.DateInitiated
					,A.MatchStatusIndicator
					,A.WatchlistName
					,COALESCE((
							SELECT TOP 1 providerID
							FROM kyp.PDM_employee
							WHERE partyid = B.partyid
							), (
							SELECT TOP 1 providerID
							FROM kyp.PDM_Owner
							WHERE partyid = B.partyid
							), (
							SELECT TOP 1 provID
							FROM kyp.PDM_Provider
							WHERE partyid = B.partyid
							), NULL) AS ProviderID
					,D.Speciality
					,A.ProviderType
				FROM KYP.MDM_Alert A
				INNER JOIN KYP.PDM_Party B ON A.WatchedPartyId = B.PartyId
					AND B.CurrentModule = 2
					AND ISNULL(A.IsDeleted, 0) = 0
					AND ISNULL(B.IsDeleted, 0) = 0
				LEFT JOIN KYP.MDM_PartyDetail D ON D.PartyID = B.PartyID
				WHERE datepart(month, A.DateInitiated) = datepart(month, getdate())
				and datepart(YEAR, A.DateInitiated) = datepart(YEAR, getdate()) /*PI-147*/
				) X
			LEFT JOIN KYP.PDM_Provider Y ON X.ProviderID = Y.ProvID
			) MDM_Alert_AllMonths
		GROUP BY MDM_Alert_AllMonths.ProviderType
		) B ON ISNULL(A.ProviderType, '0') = ISNULL(B.ProviderType, '0')
	LEFT HASH JOIN (
		SELECT ProviderType AS ProviderType
			,[ConfirmedAlerts]
			,[FalsePositives]
			,[IgnoredAlerts]
		FROM (
			SELECT ProviderType
				,MatchStatusIndicator
				,Nbr
			FROM (
				SELECT ProviderType
					,MDM_Alert_AllMonths.MatchStatusIndicator
					,count(DISTINCT alertid) AS Nbr
				FROM (
					SELECT alertid
						,dateinitiated
						,ProviderType
						,CASE 
							WHEN MatchStatusIndicator = 'C'
								THEN 'ConfirmedAlerts'
							WHEN MatchStatusIndicator = 'I'
								THEN 'IgnoredAlerts'
							WHEN MatchStatusIndicator = 'F'
								THEN 'FalsePositives'
							END AS MatchStatusIndicator
					FROM (
						SELECT alertid
							,dateinitiated
							,X.ProviderType AS ProviderType
							,MatchStatusIndicator
						FROM (
							SELECT A.alertid
								,A.DateInitiated
								,A.MatchStatusIndicator
								,A.WatchlistName
								,COALESCE((
										SELECT TOP 1 providerID
										FROM kyp.PDM_employee
										WHERE partyid = B.partyid
										), (
										SELECT TOP 1 providerID
										FROM kyp.PDM_Owner
										WHERE partyid = B.partyid
										), (
										SELECT TOP 1 provID
										FROM kyp.PDM_Provider
										WHERE partyid = B.partyid
										), NULL) AS ProviderID
								,D.Speciality
								,A.ProviderType
							FROM KYP.MDM_Alert A
							INNER JOIN KYP.PDM_Party B ON A.WatchedPartyId = B.PartyId
								AND B.CurrentModule = 2
								AND ISNULL(A.IsDeleted, 0) = 0
								AND ISNULL(B.IsDeleted, 0) = 0
							LEFT JOIN KYP.MDM_PartyDetail D ON D.PartyID = B.PartyID
							WHERE datepart(month, A.DateInitiated) = datepart(month, getdate())
							and datepart(YEAR, A.DateInitiated) = datepart(YEAR, getdate()) /*PI-147*/
							) X
						LEFT JOIN KYP.PDM_Provider Y ON X.ProviderID = Y.ProvID
						WHERE MatchStatusIndicator IN (
								'C'
								,'I'
								,'F'
								)
						) MDM_Alert
					) MDM_Alert_AllMonths
				GROUP BY MDM_Alert_AllMonths.ProviderType
					,MDM_Alert_AllMonths.MatchStatusIndicator
				) AlertMatch_Year_Mnth
			) AS SourceTable
		PIVOT(MAX(Nbr) FOR MatchStatusIndicator IN (
					[ConfirmedAlerts]
					,[FalsePositives]
					,[IgnoredAlerts]
					)) AS PivotTable
		) C ON ISNULL(A.ProviderType, '0') = ISNULL(C.ProviderType, '0')
	LEFT HASH JOIN (
		SELECT ProviderType AS ProviderType
			,ExclusionBasedAlerts
			,VerificationBasedAlerts
		FROM (
			SELECT ProviderType
				,WatchlistName
				,Nbr
			FROM (
				SELECT ProviderType
					,MDM_Alert_AllMonths.WatchlistName
					,count(DISTINCT MDM_Alert_AllMonths.alertid) AS Nbr
				FROM (
					SELECT alertid
						,dateinitiated
						,ProviderType
						,CASE 
							WHEN WatchListName IN (
									'OIG LEIE'
									,'SAM'
									,'Sanction Status'
									,'Medicaid & Medicare Exclusion'
									,'Internal Watchlist'
									,'S&I Watchlist'
									)
								THEN 'ExclusionBasedAlerts'
							WHEN WatchListName IN (
									'SSA DMF'
									,'License Status'
									,'Licensure'
									,'NPI Issues'
									,'Individual NPI'
									,'Organization NPI'
									,'LicensureAlerts'
									)
								THEN 'VerificationBasedAlerts'
							END AS WatchlistName
					FROM (
						SELECT alertid
							,dateinitiated
							,x.ProviderType AS ProviderType
							,WatchlistName
						FROM (
							SELECT A.alertid
								,A.DateInitiated
								,A.MatchStatusIndicator
								,A.WatchlistName
								,COALESCE((
										SELECT TOP 1 providerID
										FROM kyp.PDM_employee
										WHERE partyid = B.partyid
										), (
										SELECT TOP 1 providerID
										FROM kyp.PDM_Owner
										WHERE partyid = B.partyid
										), (
										SELECT TOP 1 provID
										FROM kyp.PDM_Provider
										WHERE partyid = B.partyid
										), NULL) AS ProviderID
								,D.Speciality
								,A.ProviderType
							FROM KYP.MDM_Alert A
							INNER JOIN KYP.PDM_Party B ON A.WatchedPartyId = B.PartyId
								AND B.CurrentModule = 2
								AND ISNULL(A.IsDeleted, 0) = 0
								AND ISNULL(B.IsDeleted, 0) = 0
							LEFT JOIN KYP.MDM_PartyDetail D ON D.PartyID = B.PartyID
							WHERE datepart(month, A.DateInitiated) = datepart(month, getdate())
							and datepart(YEAR, A.DateInitiated) = datepart(YEAR, getdate()) /*PI-147*/
							) X
						LEFT JOIN KYP.PDM_Provider Y ON X.ProviderID = Y.ProvID
						) MDM_Alert
					) MDM_Alert_AllMonths
				GROUP BY MDM_Alert_AllMonths.ProviderType
					,MDM_Alert_AllMonths.WatchlistName
				) AlertWatchlist_Year_Mnth
			) AS SourceTable
		PIVOT(MAX(Nbr) FOR WatchlistName IN (
					ExclusionBasedAlerts
					,VerificationBasedAlerts
					)) AS PivotTable
		) D ON ISNULL(A.ProviderType, '0') = ISNULL(D.ProviderType, '0')
	LEFT HASH JOIN (
		SELECT MDM_Alert_AllMonths.ProviderType AS ProviderType
			,count(DISTINCT alertid) AS Nbr
		FROM (
			SELECT X.alertid
				,dateinitiated
				,x.ProviderType AS ProviderType
			FROM (
				SELECT A.alertid
					,A.DateInitiated
					,A.MatchStatusIndicator
					,A.WatchlistName
					,COALESCE((
							SELECT TOP 1 providerID
							FROM kyp.PDM_employee
							WHERE partyid = B.partyid
							), (
							SELECT TOP 1 providerID
							FROM kyp.PDM_Owner
							WHERE partyid = B.partyid
							), (
							SELECT TOP 1 provID
							FROM kyp.PDM_Provider
							WHERE partyid = B.partyid
							), NULL) AS ProviderID
					,D.Speciality
					,A.ProviderType
				FROM KYP.MDM_Alert A
				INNER JOIN KYP.PDM_Party B ON A.WatchedPartyId = B.PartyId
					AND B.CurrentModule = 2
					AND ISNULL(A.IsDeleted, 0) = 0
					AND ISNULL(B.IsDeleted, 0) = 0
				LEFT JOIN KYP.MDM_PartyDetail D ON D.PartyID = B.PartyID
				WHERE datepart(month, A.DateInitiated) = datepart(month, getdate())
				and datepart(YEAR, A.DateInitiated) = datepart(YEAR, getdate()) /*PI-147*/
				) X
			INNER JOIN KYP.MDM_AlertResolution B ON X.alertid = B.alertid
				AND ISNULL(B.IsDeleted, 0) = 0
			LEFT JOIN KYP.PDM_Provider Y ON X.ProviderID = Y.ProvID
			) MDM_Alert_AllMonths
		GROUP BY MDM_Alert_AllMonths.ProviderType
		) E ON ISNULL(A.ProviderType, '0') = ISNULL(E.ProviderType, '0')
	) PCNT
WHERE PCNT.TotalAlerts <> 0


GO

