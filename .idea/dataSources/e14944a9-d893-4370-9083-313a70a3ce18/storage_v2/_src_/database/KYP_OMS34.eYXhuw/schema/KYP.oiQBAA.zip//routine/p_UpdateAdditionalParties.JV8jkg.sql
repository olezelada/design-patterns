



/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_UpdateAdditionalParties]
(
	@CaseID int = NULL,
	@ApplicationID int = NULL,
	@PartyID int = NULL,
	@ApplicationNo [varchar](10) = NULL,
	@PartyType [varchar](50) = NULL,
	@FirstName [varchar](100)= NULL,
	@LastName [varchar](100) = NULL,
	@MiddleName [varchar](100) = NULL,
	@LegalName [varchar](100) = NULL,
	@SSN [varchar](20) = NULL,
	@TIN [varchar](20) = NULL,
	@License [varchar](20) = NULL,
	@ProviderTypeCode [varchar](6) = NULL,
	@ProviderTypeDescription [varchar](100) = NULL,
	@AddressType [varchar](50) = NULL,
	@AddressLine1 [varchar](200) = NULL,
	@AddressLine2 [varchar](100) = NULL,
	@City [varchar](50) = NULL,
	@State [varchar](50) = NULL,
	@ZipCode [varchar](10) = NULL,
	@Zip5 [varchar](5) = NULL,
	@Zip4 [varchar](4) = NULL,
	@IsActive [bit] = NULL,
	@IsDeleted [bit] = NULL,
	@FullAddress [VARCHAR] (1000) = NULL,
	@IsApproved [bit] = NULL,
	@IsParent [bit] = NULL,
	@LocationNumber int
)
as begin 

UPDATE KYP.PDM_AdditionalParties 
SET

FirstName = @FirstName,
LastName = @LastName,
MiddleName = @MiddleName,
LegalName = @LegalName,
SSN = @SSN,
TIN = @TIN,
License = @License,
ProviderTypeCode = @ProviderTypeCode,
ProviderTypeDescription = @ProviderTypeDescription,
AddressType = @AddressType,
AddressLine1 = @AddressLine1, 
AddressLine2 = @AddressLine2,
City = @City,
State = @State,
ZipCode = @ZipCode,
Zip5 = @Zip5,
Zip4 = @Zip4,
IsActive = @IsActive,
IsDeleted = @IsDeleted,
FullAddress = @FullAddress,
IsParent = @IsParent

WHERE CaseID = @CaseID AND PartyType = @PartyType AND LocationNo = @LocationNumber 




end


GO

