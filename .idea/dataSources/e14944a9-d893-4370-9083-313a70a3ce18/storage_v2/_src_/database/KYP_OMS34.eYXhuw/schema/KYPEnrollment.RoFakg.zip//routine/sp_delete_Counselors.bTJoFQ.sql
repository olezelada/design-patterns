
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <14/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Counselors] 
@new_Account_Id int

AS
BEGIN

declare @counselors table (pk int identity(1,1),party int,person int);
SET NOCOUNT ON;


INSERT INTO @counselors (party,person)
select p.PartyID, pe.PersonID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.ParentPartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON p.PartyID=pe.PartyID
where p.Type='Counselor' and a.IsDeleted=0 and p.IsDeleted=0 and p.CurrentRecordFlag=1 and pe.CurrentRecordFlag=1 and pe.Deleted=0
and a.AccountID=@new_Account_Id

update num set num.isdeleted=1, num.currentrecordflag=0
from @counselors cons inner join KYPEnrollment.pAccount_PDM_Number num on cons.party=num.partyid where num.isdeleted=0 and currentrecordflag=1

update prov set prov.isdeleted=1, prov.currentrecordflag=0
from @counselors cons inner join KYPEnrollment.pAccount_PDM_provider prov on cons.party=prov.partyid where prov.isdeleted=0 and currentrecordflag=1

update part set part.isdeleted=1, part.currentrecordflag=0
from @counselors cons inner join KYPEnrollment.pAccount_PDM_party part on cons.party=part.partyid 

update pers set pers.deleted=1, pers.currentrecordflag=0
from @counselors cons inner join KYPEnrollment.pAccount_PDM_person pers on cons.person=pers.PersonID  

update other set other.CurrentRecordFlag=0,other.IsDeleted=1 
from @counselors cons inner join KYPEnrollment.pAccount_PDM_Person_OtherName other on cons.person=other.personid where other.IsDeleted=0 and CurrentRecordFlag=1





END
GO

