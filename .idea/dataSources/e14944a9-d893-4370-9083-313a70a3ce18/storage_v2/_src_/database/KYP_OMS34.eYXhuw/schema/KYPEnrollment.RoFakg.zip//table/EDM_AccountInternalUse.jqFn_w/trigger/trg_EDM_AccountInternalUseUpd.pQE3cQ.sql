



CREATE TRIGGER [KYPEnrollment].[trg_EDM_AccountInternalUseUpd] ON [KYPEnrollment].[EDM_AccountInternalUse]
WITH EXECUTE AS CALLER
FOR UPDATE
AS
BEGIN
	Declare 
	@stateCode Varchar(10),
	@AccountInternalUseID int,
	@County Varchar(100),
	@PracTypeCode varchar(50),
	@ReEnrolDate smalldatetime,	
	@AccountID int ;	
	
	
	  
	Select @stateCode=Statecode from KYP.OIS_App_Version 
	IF(@stateCode = 'MD')
	BEGIN
	
	Select @AccountID=AccountID,  
	@County= County + ' - ' + CountyDesc,
	@PracTypeCode= PracTypeCode + ' - ' + PracTypeCode1Desc,
	@ReEnrolDate=ReEnrolDate
	from inserted
	
	UPDATE [KYPEnrollment].[AccountSearch]
      SET
			ReEnrollmentDate = @ReEnrolDate,
			ServiceCounty=@County,
			PracticeTypeCode=@PracTypeCode
      WHERE AccountID = @AccountID and AccountSearchEnabled=1;
	
	END
End


GO

