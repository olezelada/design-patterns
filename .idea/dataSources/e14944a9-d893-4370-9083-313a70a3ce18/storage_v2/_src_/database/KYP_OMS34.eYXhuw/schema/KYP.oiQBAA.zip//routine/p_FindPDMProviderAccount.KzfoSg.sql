
-- =============================================
-- Author:		Amita Karan
-- Create date: 10/14/2014
-- Description:	Finds if the Account Number is existing
-- =============================================
CREATE PROCEDURE [KYP].[p_FindPDMProviderAccount]
	-- Add the parameters for the stored procedure here
	@Ac_Num VARCHAR(11) = NULL,
	@AccGenNumber VARCHAR(50) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ac_ID INT

	/********Check if NPI exists**********/
	IF EXISTS (
			SELECT 1
			FROM KYP.PDM_ProviderAccount
			WHERE AccountNumber = @Ac_Num
			)
	BEGIN
		SELECT @ac_ID = AccountID
		FROM KYP.PDM_ProviderAccount
		WHERE AccountNumber = @Ac_Num

		RETURN @ac_ID
	END
	ELSE
		RETURN - 1
END


GO

