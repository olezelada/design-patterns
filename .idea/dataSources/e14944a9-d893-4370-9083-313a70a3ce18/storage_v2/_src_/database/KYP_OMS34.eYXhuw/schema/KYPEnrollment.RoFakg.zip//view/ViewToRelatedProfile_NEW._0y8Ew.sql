




-- =============================================

-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================

CREATE VIEW [KYPEnrollment].[ViewToRelatedProfile_NEW]
AS
select (row_number() over ( order by r.CaseID)) AS ViewID, r.*
from
-- for individual
(
	select 
	DISTINCT sap.PartyID,
	ca.CaseID,
	ca.IsPPURequired AS IsPPURequired,
	ISNULL(ca.WFStatus,'') As WFStatus,
	app.ApplicationID,
	app.Status,
	ca.Number as ApplicationNumber,
	ca.Number as ProviderNumber,
	ca.ProviderName as Name,
	ca.ApplnType as ApplicationType,
	ca.MILESTONE as Milestone, 
	pps.NPI, 
	ISNULL(ca.Provider_SSN,'') as SSN,
	ISNULL(ca.Provider_TIN,'') as TIN,
	SUBSTRING(aux,CHARINDEX(aux,'-')+1,LEN(aux)) as practice,
	--(Select MAX(CONVERT(varchar(20),locationid) + ISNULL(ad.AddressLine1 ,'')+' '+ISNULL(ad.City ,'')+' '+ISNULL(ad.[State] ,'')+' '+ ISNULL(ad.Zip ,'')+(CASE WHEN ad.ZipPlus4 is null THEN '' ELSE '-'+ad.ZipPlus4 END))  from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pp.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 AND ad.InActive = 1 AND ad.IsDeleted =0 group by partyid) as PracticeAddress, 
	ca.TypeDescription as ProviderType, 
	'' as StatusLinked,
	(ISNULL((Select Substring((Select ',' + CONVERT(VARCHAR(15), CaseIDA) From KYPEnrollment.Linked_ADM_Case where CaseIDM=cas.CaseID and StatusLinked='Link' For XML Path('')),2,8000) From KYP.ADM_Case as cas WHERE cas.CaseID = ca.CaseID),'A')) as CaseIDLinked,
	ca.WFStatus Filter
	from KYP.PDM_Party pp
	INNER JOIN KYP.PDM_Provider as pps ON pps.PartyID=pp.PartyID
	INNER JOIN (KYP.SDM_ApplicationParty as sap 
		INNER JOIN (KYP.ADM_Application as app 
			INNER JOIN KYP.ADM_Case as ca 
			ON ca.CaseID=app.CaseID) 
		ON app.ApplicationID=sap.ApplicationID and (app.IsDeleted is null or app.IsDeleted='false')) 
	ON sap.PartyID=pp.PartyID  and (sap.IsDeleted is null or sap.IsDeleted='false') AND sap.isActive = 1 
	INNER JOIN 
	(select  partyid,max(convert(varchar(20),locationid) +'-'+ISNULL(ad.AddressLine1 ,'')+' '+ISNULL(ad.City ,'')+' '+ISNULL(ad.[State] ,'')+' '+ ISNULL(ad.Zip ,'')+(CASE WHEN ad.ZipPlus4 is null THEN '' ELSE '-'+ad.ZipPlus4 END)) as aux from KYP.PDM_Location as lo  LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID group by partyid) a  on pp.PartyID=a.partyid
	where  sap.PartyType='Provider' AND ISNULL(ca.WFStatus,'') <> '' AND ca.IsPPURequired=0 AND ca.WFProcessing=0
) r


GO

