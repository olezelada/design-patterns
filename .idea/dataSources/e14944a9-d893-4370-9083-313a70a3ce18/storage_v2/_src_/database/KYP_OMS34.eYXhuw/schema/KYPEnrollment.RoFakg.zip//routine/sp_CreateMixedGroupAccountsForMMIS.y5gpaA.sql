CREATE PROCEDURE [KYPEnrollment].[sp_CreateMixedGroupAccountsForMMIS]
as 
begin


declare 
	@loopID int,
	@MaxID int,
	@MixedGroupClubbingID varchar(18),
	@MGPartyID int,
	@MGAccountID int,
	@MGAccountNumber varchar(20),
	@MGStatusAcc varchar(50),
	@MGBillingStatus varchar(50),
	@MGStatusBeginDate smalldatetime,
	@MGApplicationDate smalldatetime,
	@MGActivationDate smalldatetime, 
	@MGDeactivationDate smalldatetime,
	@MGCliaNumber varchar(30),
	@MGContactPersonPartyId int,
	@I						INT = 1,
	@MGOutOfStateInd		VARCHAR(1),
	@MGCHDPCode				VARCHAR(150),
	@MGReEnrolInd			VARCHAR(10),
	@MGReEnrolDate			SMALLDATETIME,
	@MGProvisionalCode		VARCHAR(2),
	@MGProvisionalCodeDate	SMALLDATETIME,
	@MGLabStatusCode		VARCHAR(30),
	@MGLabStatusCodeDate	SMALLDATETIME

declare @SubGroupAccountIDsAndPartyID TABLE(
	[SubGroupNPI] [varchar](10) NULL,
	[SubGroupServiceLocationNo] [varchar](3) NULL,
	[SubGroupOwnerNo] [varchar](3) NULL,
	[MixedGroupClubbingID] [varchar](18) NULL,
	[SubGroupAccountID] [int] NOT NULL,
	[SubGroupPartyID] [int] NULL,
	[SubGroupAccountNumber] [varchar](20) NULL,
	[SubGroupLegalName] [varchar](150) NULL,
	[SubGroupProviderTypeCode] [varchar](5) NULL,
	[SubGroupProviderDescription] [varchar](100) NULL,
	[SubGroupAccountType] [varchar](3) NULL,
	[SubGroupPackageName] [varchar](100) NULL,
	[SubGroupPracticeAddress] [varchar](250) NULL,
	PreviousOwnershipMGAccountNumber [varchar](20) NULL
)




declare @MGStatusAndDate TABLE(
	[NPI] [varchar](10) NULL,
	[ServiceLocationNo] [varchar](3) NULL,
	[OwnerNo] [varchar](3) NULL,
	[StatusAcc] [varchar](50) NULL,
	[EarliestStartDate] [smalldatetime] NULL,
	[LatestStartDate] [smalldatetime] NULL
)


declare @MG_CLIA_AuxTable table  
(
	[CliaNumber] [varchar](30) NULL,
	[MinCliaNumber] [varchar](30) NULL,
	[MaxCliaNumber] [varchar](30) NULL
)





/*
declare @personTemp1 table
(
	partyid int null,
	SSN varchar(11) null, 
	Salutation varchar(50) null, 
	FirstName varchar(25) null, 
	LastName varchar(25) null, 
	MiddleName varchar(25) null, 
	DoB datetime null, 
	NPI varchar(10) null,
	MOCARelationshipStartDate	SMALLDATETIME NULL
)



declare @OrgTemp1 table
(
	partyid int null,
	TIN varchar(11) null, 
	LegalName varchar(100) null, 
	EIN varchar(30) null, 
	NPI varchar(10) null,
	MOCARelationshipStartDate	SMALLDATETIME NULL
)
*/
declare @AccountNumberHistory table
(
	AccountID			INT,
	OldAccountNumber	VARCHAR(24),
	NewAccountNumber	VARCHAR(24)
)

DECLARE @TempMessage TABLE  
(
	MessageID	INT NOT NULL,
	UUID		VARCHAR(200) NULL,
	DateSent	DATETIME NULL
)

DECLARE @TempRecipient TABLE
(
	ID					INT PRIMARY KEY IDENTITY(1,1),
	MessageRecipientID	INT,
	Owner_User_ID		INT,
	Owner_Profile_ID	BIGINT,
	IsRead				BIT,
	IsDeleted			BIT,
	RecipientType		VARCHAR(50)
)
;

DISABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
DISABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
/*
DISABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
DISABLE TRIGGER  AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
DISABLE TRIGGER  pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
*/
-- DISABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;
 




	
select @loopID = 1
select @MaxID= MAX(id) from StageTableToLoopThroughMixedGroup




while @loopID<= @MaxID
begin

select @MixedGroupClubbingID=MixedGroupClubbingID from StageTableToLoopThroughMixedGroup where ID= @loopID

insert into @SubGroupAccountIDsAndPartyID 
([SubGroupNPI]
           ,[SubGroupServiceLocationNo]
           ,[SubGroupOwnerNo]
           ,[MixedGroupClubbingID]
           ,[SubGroupAccountID]
           ,[SubGroupPartyID]
           ,[SubGroupAccountNumber]
           ,[SubGroupLegalName]
           ,[SubGroupProviderTypeCode]
           ,[SubGroupProviderDescription]
           ,[SubGroupAccountType]
           ,[SubGroupPackageName]
           ,[SubGroupPracticeAddress]
           ,[PreviousOwnershipMGAccountNumber])
select [SubGroupNPI]
           ,[SubGroupServiceLocationNo]
           ,[SubGroupOwnerNo]
           ,[MixedGroupClubbingID]
           ,[SubGroupAccountID]
           ,[SubGroupPartyID]
           ,[SubGroupAccountNumber]
           ,[SubGroupLegalName]
           ,[SubGroupProviderTypeCode]
           ,[SubGroupProviderDescription]
           ,[SubGroupAccountType]
           ,[SubGroupPackageName]
           ,[SubGroupPracticeAddress]
           ,PreviousOwnershipMGAccountNumber
 from temp_StageSubGroups_ForComp_MGMapping where MixedGroupClubbingID= @MixedGroupClubbingID
 order by  SubGroupPartyID        

--select * from @SubGroupAccountIDsAndPartyID


--Create the Account Number to be used  for MG
SELECT @MGAccountNumber = CASE WHEN PreviousOwnershipMGAccountNumber IS NOT NULL AND PreviousOwnershipMGAccountNumber != '' THEN
								PreviousOwnershipMGAccountNumber
							ELSE
								'7' + RIGHT(SubGroupAccountNumber,8)
							END
	FROM @SubGroupAccountIDsAndPartyID
	WHERE SubGroupAccountID IN (SELECT MAX(SubGroupAccountID)
									FROM @SubGroupAccountIDsAndPartyID)

--========MG Account Creation Started===============

--Create MG Party ID

insert into KYPEnrollment.pAccount_PDM_Party (
[Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[ParentPartyID]
           ,[profile_id]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[LastMOCARelationshipUpdateBy]
           ,[LastMOCAUpdateBy]
           ,[MOCARelationshipStartDate]
           ,[MOCARelationshipEndDate]
           ,[CurrentRecordFlag]

)


select 
[Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[ParentPartyID]
           ,[profile_id]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[LastMOCARelationshipUpdateBy]
           ,[LastMOCAUpdateBy]
           ,[MOCARelationshipStartDate]
           ,[MOCARelationshipEndDate]
           ,[CurrentRecordFlag]
from KYPEnrollment.pAccount_PDM_Party where PartyID in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
)

select @MGPartyID = IDENT_CURRENT('[KYPEnrollment].[pAccount_PDM_Party]')


--Get the MG Status and Dates as below before inserting into pADM_Account

insert into @MGStatusAndDate 
(
	[NPI] ,
	[ServiceLocationNo] ,
	[OwnerNo],
	[StatusAcc] ,
	[EarliestStartDate] ,
	[LatestStartDate]
)
	
select NPI, ServiceLocationNo, OwnerNo,StatusAcc,
min(StatusBeginDate) as EarliestDate,
MAX(StatusBeginDate) as LatestDate
 from KYPEnrollment.pADM_Account where 
AccountID in (
select SubGroupAccountID from @SubGroupAccountIDsAndPartyID
)
group by NPI, ServiceLocationNo, OwnerNo, StatusAcc
order by NPI, ServiceLocationNo, OwnerNo, StatusAcc	
	




if exists (
select 1 from @MGStatusAndDate where StatusAcc = '1 - Active' 
)
begin

select @MGStatusAcc='1 - Active'
select @MGBillingStatus = '1 - Billing'
select @MGStatusBeginDate = EarliestStartDate from @MGStatusAndDate where StatusAcc = '1 - Active' 
select @MGActivationDate = EarliestStartDate from @MGStatusAndDate where StatusAcc = '1 - Active' 
select @MGDeactivationDate = null
end


if not exists (
select 1 from @MGStatusAndDate where StatusAcc = '1 - Active' 
)
begin

select @MGStatusAcc='2 - Inactive'
select @MGBillingStatus = NULL
select @MGStatusBeginDate = LatestStartDate from @MGStatusAndDate where StatusAcc <> '1 - Active' 
select @MGDeactivationDate = LatestStartDate from @MGStatusAndDate where StatusAcc <> '1 - Active' 
select @MGActivationDate = null

end



select 
@MGApplicationDate=MIN(ApplicationDate)
from KYPEnrollment.pADM_Account where 
AccountID in (
select SubGroupAccountID from @SubGroupAccountIDsAndPartyID
)





--Insert MG Account

INSERT INTO [KYPEnrollment].[pADM_Account]
           ([LegacyAccountNo]
           ,[P_SYS_ID]
           ,[portaluserid]
           ,[AccountType]
           ,[ServiceLocationNo]
           ,[ProvLocTypeCd]
           ,[RiskDescriptor]
           ,[OwnerNo]
           ,[ProviderType]
           ,[Risk]
           ,[EnrollmentRiskLevel]
           ,[PIN]
           ,[LegalName]
           ,[DBAName]
           ,[Prefix]
           ,[Gender]
           ,[Title]
           ,[NPI]
           ,[NPIType]
           ,[PracticeAddress]
           ,[StatusBeginDate]
           ,[DateDied]
           ,[IncorporatedDate]
           ,[OOBDate]
           ,[ProvTypeUpdateDate]
           ,[RiskScore]
           ,[ApplicationDate]
           ,[LastActionDate]
           ,[ActivationDate]
           ,[DeActivationDate]
           ,[LastAction]
           ,[DateCreated]
           ,[DateModified]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[AccountUpdateDate]
           ,[AccountUpdateUserID]
           ,[AccountUpdateReason]
           ,[AccountUpdateComments]
           ,[LastRevalidationDate]
           ,[LastRevalidationReason]
           ,[RevalidationDueDate]
           ,[LastApplicationType]
           ,[AccountUpdatedBy]
           ,[LastAlertedDate]
           ,[LastScreenedDate]
           ,[LastBilledDate]
           ,[LastRenderedDate]
           ,[LastDeltaLoadDate]
           ,[ReenrollmentDate]
           ,[ApplicationNumber]
           ,[StatusAcc]
           ,[SSN]
           ,[EIN]
           ,[Phone]
           ,[PartyID]
           ,[ReenrollmentIndicator]
           ,[AccountNumber]
           ,[IsDeleted]
           ,[BusinessName]
           ,[CreatedBy]
           ,[profile_id]
           ,[PackageName]
           ,[ProviderTypeCode]
           ,[FutureStatus]
           ,[FutureDate]
           ,[StatusReasonCode]
           ,[EnrollStatusComments]
           ,[FutureStatusReasonCode]
           ,[FutureEnrollComments]
           ,[ApplicationStatusAcc]
           ,[ApplicationBeginDate]
           ,[ApplicationReasonCode]
           ,[ApplicationComments]
           ,[SuppStatusAcc]
           ,[SuppBeginDate]
           ,[SuppReasonCode]
           ,[SuppComments]
           ,[SuppFutureStatusAcc]
           ,[SuppFutureDate]
           ,[SuppFutureReason]
           ,[SuppFutureComments]
           ,[SuppDeActivationDate]
           ,[IsPastOwner]
           ,[ScheduleType]
           ,[TIN]
           ,IsProvOwnedData
           ,AccProcessing)

select

			NPI + OwnerNo + ServiceLocationNo + '100' AS [LegacyAccountNo] 
           ,[P_SYS_ID]
           ,[portaluserid]
           ,'G' as [AccountType]
           ,[ServiceLocationNo]
           ,[ProvLocTypeCd]
           ,'Moderate' as [RiskDescriptor]
           ,[OwnerNo]
           ,'Mixed Group' as [ProviderType]
           ,'2' as [Risk]
           ,[EnrollmentRiskLevel]
           ,[PIN]
           ,[LegalName]
           ,[DBAName]
           ,[Prefix]
           ,[Gender]
           ,[Title]
           ,[NPI]
           ,[NPIType]
           ,[PracticeAddress]
           ,@MGStatusBeginDate
           ,[DateDied]
           ,[IncorporatedDate]
           ,[OOBDate]
           ,getdate() as [ProvTypeUpdateDate]
           ,[RiskScore]
           ,@MGApplicationDate as [ApplicationDate]
           ,getdate() as [LastActionDate]
           ,@MGActivationDate as [ActivationDate]
           ,@MGDeactivationDate as [DeActivationDate]
           ,'C' as [LastAction]
           ,[DateCreated]
           ,getdate() as [DateModified]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,getdate() as [AccountUpdateDate]
           ,[AccountUpdateUserID]
           ,[AccountUpdateReason]
           ,[AccountUpdateComments]
           ,[LastRevalidationDate]
           ,[LastRevalidationReason]
           ,[RevalidationDueDate]
           ,[LastApplicationType]
           ,[AccountUpdatedBy]
           ,[LastAlertedDate]
           ,[LastScreenedDate]
           ,[LastBilledDate]
           ,[LastRenderedDate]
           ,[LastDeltaLoadDate]
           ,[ReenrollmentDate]
           ,[ApplicationNumber]
           ,@MGStatusAcc as [StatusAcc]
           ,[SSN]
           ,[EIN]
           ,[Phone]
           ,@MGPartyID as [PartyID]
           ,[ReenrollmentIndicator]
           ,@MGAccountNumber as [AccountNumber] 
           ,[IsDeleted]
           ,[BusinessName]
           ,[CreatedBy]
           ,[profile_id]
           ,'GSP_P_DM' as [PackageName]
           ,'100' as [ProviderTypeCode]
           ,[FutureStatus]
           ,[FutureDate]
           ,[StatusReasonCode]
           ,[EnrollStatusComments]
           ,[FutureStatusReasonCode]
           ,[FutureEnrollComments]
           ,[ApplicationStatusAcc]
           ,[ApplicationBeginDate]
           ,[ApplicationReasonCode]
           ,[ApplicationComments]
           ,[SuppStatusAcc]
           ,[SuppBeginDate]
           ,[SuppReasonCode]
           ,[SuppComments]
           ,[SuppFutureStatusAcc]
           ,[SuppFutureDate]
           ,[SuppFutureReason]
           ,[SuppFutureComments]
           ,[SuppDeActivationDate]
           ,[IsPastOwner]
           ,[ScheduleType]
           ,[TIN]
           ,0
           ,0
from [KYPEnrollment].[pADM_Account]
where 
AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID
)





select @MGAccountID = IDENT_CURRENT('[KYPEnrollment].[pADM_Account]')
print 'Mixed Group Creation....Insert into Log table'
INSERT INTO KYPEnrollment.MixedGroupHistory(AccountID,GroupName,[Action],Attribute,OldValue,NewValue,IsFlag)
	SELECT @MGAccountID,'Account Created','CRT','Account Status','-',
		CASE WHEN (@MGStatusAcc IS NOT NULL AND @MGStatusAcc != '') AND (@MGStatusBeginDate IS NOT NULL AND @MGStatusBeginDate != '') THEN
					@MGStatusAcc + '~' + CONVERT(VARCHAR(32),@MGStatusBeginDate,105)
			 WHEN (@MGStatusAcc IS NULL OR @MGStatusAcc = '') AND (@MGStatusBeginDate IS NULL OR @MGStatusBeginDate = '') THEN
					''
			 WHEN (@MGStatusAcc IS NOT NULL AND @MGStatusAcc != '') AND (@MGStatusBeginDate IS NULL OR @MGStatusBeginDate = '') THEN
					@MGStatusAcc
			 WHEN (@MGStatusAcc IS NULL OR @MGStatusAcc = '') AND (@MGStatusBeginDate IS NOT NULL AND @MGStatusBeginDate != '') THEN
					ISNULL(CONVERT(VARCHAR(32),@MGStatusBeginDate,105),'')
			 ELSE
				ISNULL(@MGStatusAcc,'') + '~' + ISNULL(CONVERT(VARCHAR(32),@MGStatusBeginDate,105),'')
			 END,1
print 'Mixed Group Creation....After Insert into Log table'
---========================Updating AccountID in PDM_Party Table
update [KYPEnrollment].pAccount_PDM_Party  set AccountID=@MGAccountID where PartyID =@MGPartyID





---======================== Inserting into PDM_Organization Table

INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           ([PartyID]
           ,[OrgNumber]
           ,[OrgCategory]
           ,[TIN]
           ,[PrimaryDUNS]
           ,[LegalName]
           ,[DBAName1]
           ,[DBAName2]
           ,[BusinessName]
           ,[IncTyp]
           ,[IncState]
           ,[IncDate]
           ,[ForeginOwned]
           ,[Email1]
           ,[Phone1]
           ,[Email2]
           ,[Phone2]
           ,[Remarks]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[Fax]
           ,[NPI]
           ,[License]
           ,[EIN]
           ,[Medicaid]
           ,[DEA]
           ,[Sellers]
           ,[IsCorporation]
           ,[Extension]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
           
select 
@MGPartyID as [PartyID]
           ,[OrgNumber]
           ,[OrgCategory]
           ,[TIN]
           ,[PrimaryDUNS]
           ,[LegalName]
           ,[DBAName1]
           ,[DBAName2]
           ,[BusinessName]
           ,[IncTyp]
           ,[IncState]
           ,[IncDate]
           ,[ForeginOwned]
           ,[Email1]
           ,[Phone1]
           ,[Email2]
           ,[Phone2]
           ,[Remarks]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[Fax]
           ,[NPI]
           ,[License]
           ,[EIN]
           ,[Medicaid]
           ,[DEA]
           ,[Sellers]
           ,[IsCorporation]
           ,[Extension]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
 from            
[KYPEnrollment].[pAccount_PDM_Organization]     
where PartyID
in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
)


---===========>PDM_Person for Contact Person dummy entry ==========================

INSERT INTO [KYPEnrollment].[pAccount_PDM_Party] 
		   ([AccountID]
           ,[Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[ParentPartyID]
           ,[profile_id]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[LastMOCARelationshipUpdateBy]
           ,[LastMOCAUpdateBy]
           ,[MOCARelationshipStartDate]
           ,[MOCARelationshipEndDate]
           ,[CurrentRecordFlag] 
		)
 VALUES (
			@MGAccountID
           ,'Contact Person'
           ,'No Data'
           ,0
           ,1
           ,0
           ,1
           ,'DeltaAccLoad'
           ,CONVERT(VARCHAR(8), GETDATE(), 112) 
           ,getdate()
           ,null
           ,0
           ,null
           ,1
           ,getdate()
           ,null
           ,null
           ,null
           ,@MGPartyID
           ,null
           ,'C'
           ,getdate()
           ,'system'
           ,null
           ,null
           ,'system'
           ,null
           ,null
           ,null
           ,null
           ,1 
  )

select @MGContactPersonPartyId = partyid from kypenrollment.pAccount_PDM_Party 
 where AccountID = @MGAccountID and Type = 'Contact Person' ;

INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           ([PartyID]
           ,[LastName]
           ,[DateCreated]
           ,[CreatedBy]
           ,Deleted
           ,lastAction
           ,LastActionDate
           ,LastActorUserId
           ,LastActionApprovedBy
           ,CurrentRecordFlag
           )
select @MGContactPersonPartyId, 
		'No Data',         
		convert(date,GETDATE(),112) as DateCreated,
        1,
		0,
		'C',
		GetDate(),
		'system',
		'system',
		1     


---===========>PDM_Provider (Not much role of this table)==========================


INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID]
           ,[Category]
           ,[Type]
           ,[PrimarySpecialty]
           ,[SecondSpecialty]
           ,[UPIN]
           ,[CCN]
           ,[HIN]
           ,[Remarks]
           ,[IsEnrolled]
           ,[ProvNumber]
           ,[Mon_MedicaidID]
           ,[EnrolledSince]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[DEA]
           ,[NPI]
           ,[Medicare]
           ,[Medicaid]
           ,[ServiceProvEntity]
           ,[ProfLicense]
           ,[ProfLicEffDate]
           ,[ProfLicExpDate]
           ,[OtherPriSpecialty]
           ,[EIN]
           ,[EINH]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])

select 
@MGPartyID as [PartyID]
           ,[Category]
           ,'Mixed Group' as [Type]
           ,[PrimarySpecialty]
           ,[SecondSpecialty]
           ,[UPIN]
           ,[CCN]
           ,[HIN]
           ,[Remarks]
           ,[IsEnrolled]
           ,[ProvNumber]
           ,[Mon_MedicaidID]
           ,[EnrolledSince]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[DEA]
           ,[NPI]
           ,[Medicare]
           ,[Medicaid]
           ,[ServiceProvEntity]
           ,[ProfLicense]
           ,[ProfLicEffDate]
           ,[ProfLicExpDate]
           ,[OtherPriSpecialty]
           ,[EIN]
           ,[EINH]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
from [KYPEnrollment].[pAccount_PDM_Provider]
where PartyID
in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
)


---===========>PDM_Location (Reuse the addressid of smallest SubGroupAccount Partyid)==========================

INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
           ([AddressType]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[County]
           ,[City]
           ,[Zip]
           ,[ZipPlus4]
           ,[State]
           ,[Country]
           ,[Latitude]
           ,[Longitude]
           ,[GeographicArea]
           ,[ServiceLocationNo]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActionUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedByUsedID]
           ,[CurrentRecordFlag]
           ,[TempAddressID])
	SELECT [AddressType]
           ,[AddressLine1]
           ,[AddressLine2]
           ,[County]
           ,[City]
           ,[Zip]
           ,[ZipPlus4]
           ,[State]
           ,[Country]
           ,[Latitude]
           ,[Longitude]
           ,[GeographicArea]
           ,[ServiceLocationNo]
           ,ADR.[LastAction]
           ,ADR.[LastActionDate]
           ,[LastActionUserID]
           ,ADR.[LastActionReason]
           ,ADR.[LastActionComments]
           ,[LastActionApprovedByUsedID]
           ,ADR.[CurrentRecordFlag]
           ,@MGPartyID
		FROM [KYPEnrollment].[pAccount_PDM_Address] ADR
		JOIN [KYPEnrollment].[pAccount_PDM_Location] LOC
		ON ADR.AddressID = LOC.AddressID
		WHERE LOC.PartyID IN (SELECT MAX(SubGroupPartyID)
								FROM @SubGroupAccountIDsAndPartyID)

INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
           ([AddressID]
           ,[PartyID]
           ,[ProviderID]
           ,[PersonID]
           ,[Type]
           ,[WorkingDays]
           ,[WorkingHours]
           ,[Phone1]
           ,[Phone2]
           ,[Fax]
           ,[Remarks]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[InActive]
           ,[IsDeleted]
           ,[Email]
           ,[IsLicensed]
           ,[IsRented]
           ,[Status]
           ,[Name]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
select 
			NULL
           ,@MGPartyID as [PartyID]
           ,IDENT_CURRENT('[KYPEnrollment].[pAccount_PDM_Provider]') as [ProviderID]
           ,[PersonID]
           ,[Type]
           ,[WorkingDays]
           ,[WorkingHours]
           ,[Phone1]
           ,[Phone2]
           ,[Fax]
           ,[Remarks]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[InActive]
           ,[IsDeleted]
           ,[Email]
           ,[IsLicensed]
           ,[IsRented]
           ,[Status]
           ,[Name]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
		FROM [KYPEnrollment].[pAccount_PDM_Location] 
		WHERE PartyID IN (SELECT MAX(SubGroupPartyID)
							FROM @SubGroupAccountIDsAndPartyID)

UPDATE KYPEnrollment.pAccount_PDM_Location
	SET AddressID = ADR.AddressID
	FROM KYPEnrollment.pAccount_PDM_Location LOC
	JOIN KYPEnrollment.pAccount_PDM_Address ADR
	ON LOC.PartyID	= ADR.TempAddressID AND
	   LOC.[Type]	= ADR.AddressType
	WHERE TempAddressID	= @MGPartyID AND
		  LOC.AddressID	IS NULL
	
UPDATE [KYPEnrollment].[pAccount_PDM_Address]
	SET TempAddressID = NULL
	WHERE	TempAddressID = @MGPartyID;

---===========>License Number in the table called PDM_Number==========================

INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
           ([PartyID]
           ,[Number]
           ,[Type]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[Name]
           ,[State]
           ,[documentInstanceId]
           ,[LicenseBoardCode]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])

select           
@MGPartyID as [PartyID]
           ,[Number]
           ,[Type]
           ,[EffectiveDate]
           ,[ExpirationDate]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[Name]
           ,[State]
           ,[documentInstanceId]
           ,[LicenseBoardCode]
           ,[LastAction]
           ,GETDATE() as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]          
from [KYPEnrollment].[pAccount_PDM_Number] 
where PartyID
in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
)         







---===========>Specialty and Taxonomy in the table called PDM_Specialty (send all valid spec & taxonomy)==========================
--distinct clause along with exception of 99 and 00 would ensure that repitions are avoided

/****
KEN-6608 : Specialty 99 is getting duplicated due to IsPrimary Flag difference. Hence removing it from Distinct.
****/

INSERT INTO [KYPEnrollment].[pAccount_PDM_Speciality]
           ([PartyID]
           ,[TaxonomyCode]
--           ,[IsPrimary]
           ,[Speciality_Code]
           ,[Board]
           ,[DateModified]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[Type]
           ,[SpecCertDate])            

select distinct
@MGPartyID as [PartyID]
           ,[TaxonomyCode]
--           ,[IsPrimary]
           ,[Speciality_Code]
           ,[Board]
           ,[DateModified]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated] 
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[Type]
           ,[SpecCertDate]     
from [KYPEnrollment].[pAccount_PDM_Speciality]  
where PartyID in (
select SubGroupPartyID from @SubGroupAccountIDsAndPartyID
)    
           
-- Set primary Specialty           
Update [KYPEnrollment].[pAccount_PDM_Speciality]  
set IsPrimary = 1 
where PartyID = @MGPartyID
and Speciality_Code = (select top 1 [Speciality_Code] 
from [KYPEnrollment].[pAccount_PDM_Speciality]
where PartyID = @MGPartyID and type = 'Specialty Code' order by Speciality_Code Asc)

-- Set Primary Taxonomy
Update [KYPEnrollment].[pAccount_PDM_Speciality]  
set IsPrimary = 1 
where PartyID = @MGPartyID
and [Speciality_Code] = (select [Speciality_Code] from [KYPEnrollment].[pAccount_PDM_Speciality] 
where partyid = (select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID) 
and IsPrimary = 1 and type = 'Taxonomy Code')


---===========>PDM_CLIA==========================

insert into @MG_CLIA_AuxTable 
(
	[CliaNumber] ,
	[MinCliaNumber],
	[MaxCliaNumber]
)
	
select CliaNumber, min(CliaNumber) as MinCliaNumber, MAX(CliaNumber)  as MaxCliaNumber
from  [KYPEnrollment].[pAccount_PDM_Clia]
where PartyID in (
select SubGroupPartyID from @SubGroupAccountIDsAndPartyID
)
group by CliaNumber
order by CliaNumber desc
	

if exists (
select 1 from @MG_CLIA_AuxTable where CliaNumber is not null
)
begin
	SELECT @MGCliaNumber = MinCliaNumber FROM @MG_CLIA_AuxTable WHERE ISNULL(CliaNumber,'') != '' -- CliaNumber IS NOT NULL
end


if not exists (
select 1 from @MG_CLIA_AuxTable where CliaNumber is not null
)
begin
	select @MGCliaNumber = null
end


INSERT INTO [KYPEnrollment].[pAccount_PDM_Clia]
           ([LabType]
           ,[CertificateType]
           ,[LabName]
           ,[LabAddressLine1]
           ,[LabAddressLine2]
           ,[LabCity]
           ,[LabState]
           ,[LabZip9]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedByUsedID]
           ,[CurrentRecordFlag]
           ,[PartyID]
           ,[CliaNumber]
           ,[RegistrationNumber]
           ,[CertificationNumber])  
select distinct 
[LabType]
           ,[CertificateType]
           ,[LabName]
           ,[LabAddressLine1]
           ,[LabAddressLine2]
           ,[LabCity]
           ,[LabState]
           ,[LabZip9]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedByUsedID]
           ,[CurrentRecordFlag]
           ,@MGPartyID as[PartyID]
           ,@MGCliaNumber as [CliaNumber]
           ,[RegistrationNumber]
           ,[CertificationNumber]

from [KYPEnrollment].[pAccount_PDM_CLIA]  
where PartyID in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
)   


---===========>EntityType==========================      

INSERT INTO [KYPEnrollment].[pAccount_PDM_EntityType]
           ([PartyID]
           ,[NameEntityType]
           ,[TypeProfit]
           ,[CorporateNumber]
           ,[StateIncorporated]
           ,[LlcNumber]
           ,[StateRegistered]
           ,[TypeNonProfit]
           ,[Other]
           ,[DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[PracTypeCode])

select @MGPartyID as [PartyID]
           ,[NameEntityType]
           ,[TypeProfit]
           ,[CorporateNumber]
           ,[StateIncorporated]
           ,[LlcNumber]
           ,[StateRegistered]
           ,[TypeNonProfit]
           ,[Other]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[PracTypeCode]

 from KYPEnrollment.pAccount_PDM_EntityType 
where PartyID in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID
) 


---===========>DEA==========================      

INSERT INTO [KYPEnrollment].[pAccount_PDM_DEA]
           ([PartyID]
           ,[DEA]
           ,[DrugSchedules]
           ,[AllowedDrugCode]
           ,[LicenseNumber]
           ,[LicenseIssuingState]
           ,[CntrlSubstLicNo]
           ,[CntrlSubstLicSt]
           ,[BusinessActivity]
           ,[BusinessName]
           ,[Business_Tax_Type]
           ,[Business_TAXID]
           ,[BusinessAddressLine1]
           ,[BusinessAddressLine2]
           ,[BusinessCity]
           ,[BusinessState]
           ,[BusinessZip9]
           ,[BusinessPhoneNo]
           ,[IssuedDate]
           ,[LastRenewedDate]
           ,[ExpiryDate]
           ,[DispensingProvider]
           ,[EffectiveBeginDate]
           ,[EffectiveEndDate]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction]
           ,[ExpirationDate]
           ,[CertificateNumber])

select 
@MGPartyID as [PartyID]
           ,[DEA]
           ,[DrugSchedules]
           ,[AllowedDrugCode]
           ,[LicenseNumber]
           ,[LicenseIssuingState]
           ,[CntrlSubstLicNo]
           ,[CntrlSubstLicSt]
           ,[BusinessActivity]
           ,[BusinessName]
           ,[Business_Tax_Type]
           ,[Business_TAXID]
           ,[BusinessAddressLine1]
           ,[BusinessAddressLine2]
           ,[BusinessCity]
           ,[BusinessState]
           ,[BusinessZip9]
           ,[BusinessPhoneNo]
           ,[IssuedDate]
           ,[LastRenewedDate]
           ,[ExpiryDate]
           ,[DispensingProvider]
           ,[EffectiveBeginDate]
           ,[EffectiveEndDate]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction]
           ,[ExpirationDate]
           ,[CertificateNumber]
from [KYPEnrollment].[pAccount_PDM_DEA]  where PartyID in (     
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID    
)


---===========>Account History==========================      

INSERT INTO [KYPEnrollment].[pAccount_History]
           ([AccountID]
           ,[RelatedID]
           ,[ActionID]
           ,[Remarks]
           ,[DateCreated]
           ,[CreatedBy]
           ,[DeletedBy]
           ,[IsDeleted]
           ,[LastActorUserID]
           ,[ModificationSemanticDescription]
           ,[ModifiyingEvent]
           ,[LastActionDate]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction])

select 
@MGAccountID as [AccountID]
           ,[RelatedID]
           ,[ActionID]
           ,[Remarks]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[CreatedBy]
           ,[DeletedBy]
           ,[IsDeleted]
           ,[LastActorUserID]
           ,[ModificationSemanticDescription]
           ,[ModifiyingEvent]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[LastAction]     

from [KYPEnrollment].[pAccount_History]
where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID  
)


---===========>Account Name==========================   

INSERT INTO [KYPEnrollment].[pAccount_Name]
           ([AccountID]
           ,[Name]
           ,[NameType]
           ,[EffectiveBeginDate]
           ,[EffectiveEndDate]
           ,[Priority]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])

select 
@MGAccountID as [AccountID]
           ,[Name]
           ,[NameType]
           ,[EffectiveBeginDate]
           ,[EffectiveEndDate]
           ,[Priority]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
from [KYPEnrollment].[pAccount_Name]
where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID  
)



---===========>Account Owner========================== 


INSERT INTO [KYPEnrollment].[pAccount_Owner]
           ([AccountID]
           ,[OwnerNo]
           ,[PracticeType]
           ,[LegalName]
           ,[BusinessName]
           ,[DBAName]
           ,[TIN]
           ,[TINH]
           ,[EffectiveBeingDate]
           ,[EffectiveEndDate]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[SSN]
           ,[SSNH])

select 
@MGAccountID as [AccountID]
           ,[OwnerNo]
           ,[PracticeType]
           ,[LegalName]
           ,[BusinessName]
           ,[DBAName]
           ,[TIN]
           ,[TINH]
           ,[EffectiveBeingDate]
           ,[EffectiveEndDate]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[SSN]
           ,[SSNH]
from  [KYPEnrollment].[pAccount_Owner]
where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID 
)       

---===========>Account Status========================== 

INSERT INTO KYPEnrollment.pADM_AccountStatus
(
	AccountID,
	StatusType,
	StatusValue,
	EffectiveBeginDate,
	LastAction,
	LastActionDate,
	LastActionApprovedBy,
	CurrentRecordFlag
)
SELECT	@MGAccountID,
		'Enrollment',
		@MGStatusAcc,
		@MGStatusBeginDate,
		'C',
		GETDATE(),
		'System',
		1 

---===========>Account Internal use Data ========================== 

SELECT @MGOutOfStateInd = OutOfStateInd
	FROM (SELECT OutOfStateInd,ROW_NUMBER() OVER (ORDER BY OutOfStateInd) AS RN
			FROM [KYPEnrollment].EDM_AccountInternalUse
			WHERE	AccountID IN (SELECT SubGroupAccountID
									FROM @SubGroupAccountIDsAndPartyID) AND
					ISNULL(OutOfStateInd,'') != '') ILV
	WHERE ILV.RN = 1

SELECT @MGCHDPCode = CHDPCode
	FROM (SELECT CHDPCode,ROW_NUMBER() OVER (ORDER BY CHDPCode) AS RN
			FROM [KYPEnrollment].EDM_AccountInternalUse
			WHERE	AccountID IN (SELECT SubGroupAccountID
									FROM @SubGroupAccountIDsAndPartyID) AND
					ISNULL(CHDPCode,'') != '') ILV
	WHERE ILV.RN = 1

SELECT @MGReEnrolInd = ReEnrolInd,@MGReEnrolDate = ReEnrolDate
	FROM (SELECT ReEnrolInd,ReEnrolDate,ROW_NUMBER() OVER (ORDER BY ReEnrolDate DESC) AS RN
			FROM [KYPEnrollment].EDM_AccountInternalUse
			WHERE	AccountID IN (SELECT SubGroupAccountID
									FROM @SubGroupAccountIDsAndPartyID) /*AND
					ISNULL(ReEnrolDate,'') != ''*/) ILV
	WHERE ILV.RN = 1

SELECT @MGProvisionalCode = ProvisionalCode,@MGProvisionalCodeDate = ProvisionalCodeDate
	FROM (SELECT ProvisionalCode,ProvisionalCodeDate,ROW_NUMBER() OVER (ORDER BY ProvisionalCodeDate DESC) AS RN
			FROM [KYPEnrollment].EDM_AccountInternalUse
			WHERE	AccountID IN (SELECT SubGroupAccountID
									FROM @SubGroupAccountIDsAndPartyID) /*AND
					ISNULL(ProvisionalCodeDate,'') != ''*/) ILV
	WHERE ILV.RN = 1

SELECT @MGLabStatusCode = LabStatusCode,@MGLabStatusCodeDate = LabStatusCodeDate
	FROM (SELECT LabStatusCode,LabStatusCodeDate,ROW_NUMBER() OVER (ORDER BY LabStatusCodeDate DESC) AS RN
			FROM [KYPEnrollment].EDM_AccountInternalUse
			WHERE	AccountID IN (SELECT SubGroupAccountID
									FROM @SubGroupAccountIDsAndPartyID) AND
					ISNULL(LabStatusCode,'') != '') ILV
	WHERE ILV.RN = 1

UPDATE KYPEnrollment.pADM_Account
	SET IsCrossover = CASE WHEN @MGProvisionalCode = 'X' THEN
							1
						ELSE
							0
						END,
		LastActionDate = GETDATE()
	WHERE AccountID = @MGAccountID						

INSERT INTO [KYPEnrollment].[EDM_AccountInternalUse]
           ([AccountID]
			,BillingStatus
			,BillingBeginDate
			,OutOfStateInd			
			,CHDPCode				
			,ReEnrolInd				
			,ReEnrolDate			
			,ProvisionalCode		
			,ProvisionalCodeDate	
			,LabStatusCode			
			,LabStatusCodeDate		
			,[LastAction]
			,[LastActionDate]
			,[LastActorUserID]
			,[LastActionApprovedBy]
			,[CurrentRecordFlag])
select 
			@MGAccountID as [AccountID],
			@MGBillingStatus,
			@MGStatusBeginDate,
			@MGOutOfStateInd,
			@MGCHDPCode,
			@MGReEnrolInd,
			@MGReEnrolDate,
			@MGProvisionalCode,
			@MGProvisionalCodeDate,
			@MGLabStatusCode,
			@MGLabStatusCodeDate,			
			'C',
			convert(date,GETDATE(),112) as [LastActionDate],
			'system',
			'system',
			1
from  [KYPEnrollment].[EDM_AccountInternalUse]
where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID 
)       

---===========>PDM_Insurance========================== 

INSERT INTO [KYPEnrollment].[pAccount_PDM_Insurance]
           ([PartyID]
           ,[PolicyNumber]
           ,[Type]
           ,[IssuanceDate]
           ,[ExpirationDate]
           ,[MinimumOccurrence]
           ,[AnualAggregate]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
     
select
@MGPartyID as [PartyID]
           ,[PolicyNumber]
           ,[Type]
           ,[IssuanceDate]
           ,[ExpirationDate]
           ,[MinimumOccurrence]
           ,[AnualAggregate]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
from   [KYPEnrollment].[pAccount_PDM_Insurance]
where PartyID in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID 
)




---===========>PDM_Place Of Business========================== 



INSERT INTO [KYPEnrollment].[pAccount_PDM_PlaceBusiness]
           ([PartyId]
           ,[PrimaryAnswer]
           ,[SecondAnswer]
           ,[ThirdAnswer]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
select

@MGPartyID as [PartyId]
           ,[PrimaryAnswer]
           ,[SecondAnswer]
           ,[ThirdAnswer]
           ,[CreatedBy]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[DateModified]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]     
from [KYPEnrollment].[pAccount_PDM_PlaceBusiness]
where Partyid in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID 
)





---===========>PDM_Payment Detail========================== 

INSERT INTO [KYPEnrollment].[pAccount_PDM_PaymentDetail]
           ([PartyID]
           ,[TypeOfPayment]
           ,[CardNumber]
           ,[CCV]
           ,[NameOnCard]
           ,[ExpirationDate]
           ,[Branch]
           ,[BankpAccountNumber]
           ,[RoutingNumber]
           ,[BankName]
           ,[StreetName]
           ,[City]
           ,[ZipPlus4]
           ,[County]
           ,[StateTrans]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[FeeAmount]
           ,[isSameAppFee]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[EFT_Indicator]
           ,[EFT_OptOut]
           ,[ProviderName]
           ,[ProviderContact]
           ,[ReasonForSubmission])

select 
@MGPartyID as [PartyID]
           ,[TypeOfPayment]
           ,[CardNumber]
           ,[CCV]
           ,[NameOnCard]
           ,[ExpirationDate]
           ,[Branch]
           ,[BankpAccountNumber]
           ,[RoutingNumber]
           ,[BankName]
           ,[StreetName]
           ,[City]
           ,[ZipPlus4]
           ,[County]
           ,[StateTrans]
           ,[CreatedBy]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[FeeAmount]
           ,[isSameAppFee]
           ,[LastAction]
           ,convert(date,GETDATE(),112)
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[EFT_Indicator]
           ,[EFT_OptOut]
           ,[ProviderName]
           ,[ProviderContact]
           ,[ReasonForSubmission]
from [KYPEnrollment].[pAccount_PDM_PaymentDetail]
where PartyID in (
select MAX(SubGroupPartyID) from @SubGroupAccountIDsAndPartyID 
)           




---===========>Account Search========================== 

INSERT INTO [KYPEnrollment].[AccountSearch]
           ([AccountNumber]
           ,[EnrollmentStatus]
           ,[EnrolledOn]
           ,[ProviderType]
           ,[BillingStatus]
           ,[ScreeningLevel]
           ,[ServiceCity]
           ,[ServiceState]
           ,[ServiceZip]
           ,[PayCity]
           ,[PayState]
           ,[PayZip]
           ,[AccountName]
           ,[NPI]
           ,[SSN]
           ,[TAXID]
           ,[CategoryOfService]
           ,[ScheduledStatus]
           ,[StatusDate]
           ,[AccountID]
           ,[RiskScore]
           ,[ServiceAddressLine1]
           ,[ServiceAddressLine2]
           ,[PayAddressLine1]
           ,[PayAddressLine2]
           ,[License]
           ,[InPortalDate]
           ,[CompletedInPortalDate]
           ,[StatusBeginDate]
           ,[AccountType]
           ,[AccountTypeDesc]
		   ,MailCity -- KEN-18021
		   ,MailState
		   ,MailZip
		   ,MailAddressLine1
		   ,MailAddressLine2
		   ,ReEnrollmentDate)
Select            
@MGAccountNumber as [AccountNumber]
           ,@MGStatusAcc as [EnrollmentStatus]
           ,@MGStatusBeginDate as [EnrolledOn]
           ,'Mixed Group' as [ProviderType]
           ,@MGBillingStatus
           ,'Moderate' as [ScreeningLevel]
           ,[ServiceCity]
           ,[ServiceState]
           ,[ServiceZip]
           ,[PayCity]
           ,[PayState]
           ,[PayZip]
           ,[AccountName]
           ,[NPI]
           ,[SSN]
           ,[TAXID]
           ,null as [CategoryOfService]
           ,[ScheduledStatus]
           ,@MGStatusBeginDate as [StatusDate]
           ,@MGAccountID as [AccountID]
           ,[RiskScore]
           ,[ServiceAddressLine1]
           ,[ServiceAddressLine2]
           ,[PayAddressLine1]
           ,[PayAddressLine2]
           ,[License]
           ,[InPortalDate]
           ,[CompletedInPortalDate]
           ,@MGStatusBeginDate as [StatusBeginDate]
           ,'G' as [AccountType]
           ,'Group' as [AccountTypeDesc]
		   ,MailCity
		   ,MailState
		   ,MailZip
		   ,MailAddressLine1
		   ,MailAddressLine2
		   ,@MGReEnrolDate
from [KYPEnrollment].[AccountSearch] where AccountID in (
-- select AccountNumber from KYPEnrollment.pADM_Account where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID
) 
-- )           
           

---===========>Transforming affiliations through KYPEnrollment.pAccount_RenderingAffiliation==========================       

INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
           ([AccountID]
           ,[AffiliatedAccountID]
           ,[TypeAffiliation]
           ,[AffiliationStartDate]
           ,[AffiliationEndDate]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionComments]
           ,[LastActionReason]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[IsDeleted]
           ,[TempAffiliation]
           ,[LastAction]
           ,[LastUpdatedBy]
           ,[groupEmail]
           ,[rendering_email]
           ,[AffiliatedAccountProvTypeCode])
	SELECT @MGAccountID as [AccountID]
		   ,A.[AffiliatedAccountID]
		   ,[TypeAffiliation]
		   ,[AffiliationStartDate]
		   ,[AffiliationEndDate]
		   ,convert(date,GETDATE(),112) 
		   ,'system'
		   ,NULL
		   ,NULL
		   ,'system'
		   ,1
		   ,0
		   ,[TempAffiliation]
		   ,'C'
		   ,'M'
		   ,NULL
		   ,NULL
		   ,[AffiliatedAccountProvTypeCode]
	FROM (SELECT AffiliatedAccountID,AffiliationStartDate,MAX([TypeAffiliation]) AS TypeAffiliation,MAX(AffiliationEndDate) AS AffiliationEndDate,
				 MAX([AffiliatedAccountProvTypeCode]) AS [AffiliatedAccountProvTypeCode],MAX(TempAffiliation) As TempAffiliation
			FROM KYPEnrollment.pAccount_RenderingAffiliation RA
			JOIN @SubGroupAccountIDsAndPartyID Temp
			ON RA.AccountID = Temp.SubGroupAccountID
			WHERE TypeAffiliation	LIKE '%MIDLEVEL%' AND
				  CurrentRecordFlag = 1 AND
				  IsDeleted			= 0
			GROUP BY AffiliatedAccountID,AffiliationStartDate) A
	LEFT JOIN (SELECT AffiliatedAccountID,AccountID
					FROM KYPEnrollment.pAccount_RenderingAffiliation
					WHERE AccountID			= @MGAccountID AND
						  TypeAffiliation	LIKE '%MIDLEVEL%' AND
						  CurrentRecordFlag = 1 AND
						  IsDeleted			= 0) B
	ON A.AffiliatedAccountID	= B.AffiliatedAccountID
	WHERE TypeAffiliation		LIKE '%MIDLEVEL%' AND
		  B.AffiliatedAccountID	IS NULL;

INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]
           ([AccountID]
           ,[AffiliatedAccountID]
           ,[TypeAffiliation]
           ,[AffiliationStartDate]
           ,[AffiliationEndDate]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionComments]
           ,[LastActionReason]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[IsDeleted]
           ,[TempAffiliation]
           ,[LastAction]
           ,[LastUpdatedBy]
           ,[groupEmail]
           ,[rendering_email]
           ,[AffiliatedAccountProvTypeCode])
	SELECT @MGAccountID as [AccountID]
		   ,A.[AffiliatedAccountID]
		   ,[TypeAffiliation]
		   ,[AffiliationStartDate]
		   ,[AffiliationEndDate]
		   ,convert(date,GETDATE(),112) 
		   ,'system'
		   ,NULL
		   ,NULL
		   ,'system'
		   ,1
		   ,0
		   ,[TempAffiliation]
		   ,'C'
		   ,'M'
		   ,NULL
		   ,NULL
		   ,[AffiliatedAccountProvTypeCode]
	FROM (SELECT *
			FROM (SELECT AffiliatedAccountID,AffiliationStartDate,TypeAffiliation,AffiliationEndDate,AffiliatedAccountProvTypeCode,
						 TempAffiliation,ROW_NUMBER() OVER (PARTITION BY AffiliatedAccountID ORDER BY AffiliationStartDate DESC) AS RN
					FROM KYPEnrollment.pAccount_RenderingAffiliation RA
					JOIN @SubGroupAccountIDsAndPartyID Temp
					ON RA.AccountID = Temp.SubGroupAccountID
					WHERE TypeAffiliation	NOT LIKE '%MIDLEVEL%' AND
						  CurrentRecordFlag = 1 AND
						  IsDeleted			= 0) ILV
			-- GROUP BY AffiliatedAccountID,AffiliationStartDate
			WHERE ILV.RN = 1) A
	LEFT JOIN (SELECT AffiliatedAccountID,AccountID
					FROM KYPEnrollment.pAccount_RenderingAffiliation
					WHERE AccountID			= @MGAccountID AND
						  TypeAffiliation	NOT LIKE '%MIDLEVEL%' AND
						  CurrentRecordFlag = 1 AND
						  IsDeleted			= 0) B
	ON A.AffiliatedAccountID	= B.AffiliatedAccountID
	WHERE TypeAffiliation		NOT LIKE '%MIDLEVEL%' AND
		  B.AffiliatedAccountID	IS NULL;

/*select
@MGAccountID as [AccountID]
           ,[AffiliatedAccountID]
           ,[TypeAffiliation]
           ,[AffiliationStartDate]
           ,[AffiliationEndDate]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[LastActorUserID]
           ,[LastActionComments]
           ,[LastActionReason]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[TempAffiliation]
           ,[LastAction]
           ,[LastUpdatedBy]
           ,[groupEmail]
           ,[rendering_email]
           ,[AffiliatedAccountProvTypeCode]
 from KYPEnrollment.pAccount_RenderingAffiliation
where AccountID in (
select SubGroupAccountID from @SubGroupAccountIDsAndPartyID
)*/


---===========>Ensuring that Rendering Supervisor is inserted for the MG Affiliation===========       

MERGE [KYPEnrollment].[pAccount_RenderingSupervisor]  trgt
USING 
(  
	select * from [KYPEnrollment].[pAccount_RenderingAffiliation] 
	where accountid = @MGAccountID
)src ON (trgt.RenderingAffiliationId=src.RenderingAffiliationId )
WHEN NOT MATCHED THEN 
	INSERT ( 
	[RenderingAffiliationId]
           ,[InstanceId]
           ,[ProviderNumber]
           ,[Npi]
           ,[Name]
           ,[LicenseOrID]
           ,[LicenseOrIdNumber]
           ,[ProfessionalLicense]
           ,[LicenseExpirationDate]
           ,[isAccount]
           ,[dateCreated]
           ,[dateModified]
           ,[dateDeleted]
           ,[createdBy]
           ,[modifiedBy]
           ,[deletedBy]
           ,[isDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
	 )
 VALUES (
 src.[RenderingAffiliationId]
           ,NULL
           ,'No Data'
           ,'No Data'
           ,'No Data'
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,convert(date,GETDATE(),112) 
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,0
           ,'C'
           ,convert(date,GETDATE(),112) 
           ,'system'
           ,NULL
           ,NULL
           ,'system'
           ,1
 );

/*
Below code is commented by Anshu on 18th April, 2018. MOCA should not create for Mixed Group Account from Delta as Sub Account will create
MOCAs for MOCA linking. It was needed for MOCA spreading
*/

/*
---===========>Transforming Owners on to Mixed Group==========================       

--First Transform Individual Owners of Sub Groups

print 'Going to start Owner Transposition for Ind Owner==>' +  convert(varchar(10),@loopID )

/*
MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
select distinct null as PartyID, B.Name, B.MOCARelationshipStartDate, B.MOCARelationshipEndDate, 
C.SSN, C.Salutation,C.FirstName, C.LastName, C.MiddleName,C.DoB, C.NPI, E.NPI as ProviderNPI
from @SubGroupAccountIDsAndPartyID A
join KYPEnrollment.pAccount_PDM_Party B
on A.SubGroupAccountID=B.AccountID
and  B.Type in (
'Individual Ownership'
)
join KYPEnrollment.pAccount_PDM_Person C
on B.PartyID=C.PartyID
left join KYPEnrollment.pAccount_PDM_Provider E
on B.PartyID=E.PartyID
where B.CurrentRecordFlag=1 
  
)src ON (trgt.partyid=src.partyid)
WHEN NOT MATCHED THEN 
	INSERT (
			[AccountID]
           ,[Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[ParentPartyID]
           ,[profile_id]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[LastMOCARelationshipUpdateBy]
           ,[LastMOCAUpdateBy]
           ,[MOCARelationshipStartDate]
           ,[MOCARelationshipEndDate]
           ,[CurrentRecordFlag]	
	)
 VALUES (
 
 @MGAccountID
           ,'Individual Ownership'
           ,src.Name
           ,0
           ,1
           ,0
           ,1
           ,'MonthlyProvider'
           ,'MLOAD_' + CONVERT(VARCHAR(8), GETDATE(), 112)
           ,getdate()
           ,null
           ,0
           ,null
           ,null
           ,getdate()
           ,null
           ,null
           ,'2069-12-31 00:00:00'
           ,@MGPartyID
           ,null
           ,'C'
           ,getdate()
           ,'system'
           ,null
           ,null
           ,'system'
           ,'M'
           ,'M'
           ,src.MOCARelationshipStartDate
           ,src.MOCARelationshipEndDate
           ,1 
 
 )
output inserted.partyid,src.SSN, src.Salutation,src.FirstName, src.LastName, src.MiddleName,src.DoB, src.NPI
 into @personTemp1;
*/

MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
	SELECT DISTINCT NULL AS PartyID, MAX(B.Name) AS Name, MIN(B.MOCARelationshipStartDate) AS MOCARelationshipStartDate,
					MAX(B.MOCARelationshipEndDate) AS MOCARelationshipEndDate, C.SSN, MAX(C.Salutation) AS Salutation,
					MAX(C.FirstName) AS FirstName, MAX(C.LastName) AS LastName, MAX(C.MiddleName) AS MiddleName,MAX(C.DOB) AS DOB,
					MAX(C.NPI) AS NPI, MAX(E.NPI) AS ProviderNPI
		FROM @SubGroupAccountIDsAndPartyID A
		JOIN KYPEnrollment.pAccount_PDM_Party B
		ON A.SubGroupAccountID = B.AccountID
		AND B.Type IN ('Individual Ownership')
		JOIN KYPEnrollment.pAccount_PDM_Person C
		ON B.PartyID = C.PartyID
		LEFT JOIN KYPEnrollment.pAccount_PDM_Provider E
		ON B.PartyID = E.PartyID
		WHERE B.CurrentRecordFlag = 1
		GROUP BY C.SSN
)SRC ON (TRGT.PartyID = SRC.PartyID)
WHEN NOT MATCHED THEN 
INSERT
(
	[AccountID]
	,[Type]
	,[Name]
	,[IsProvider]
	,[IsEnrolled]
	,[IsTemp]
	,[IsActive]
	,[LoadType]
	,[LoadID]
	,[LastLoadDate]
	,[DateModified]
	,[IsDeleted]
	,[Source]
	,[CreatedBy]
	,[DateCreated]
	,[ModifiedBy]
	,[DeletedBy]
	,[DateDeleted]
	,[ParentPartyID]
	,[profile_id]
	,[LastAction]
	,[LastActionDate]
	,[LastActorUserID]
	,[LastActionReason]
	,[LastActionComments]
	,[LastActionApprovedBy]
	,[LastMOCARelationshipUpdateBy]
	,[LastMOCAUpdateBy]
	,[MOCARelationshipStartDate]
	,[MOCARelationshipEndDate]
	,[CurrentRecordFlag]	
)
VALUES
(
	@MGAccountID
	,'Individual Ownership'
	,src.Name
	,0
	,1
	,0
	,1
	,'MonthlyProvider'
	,'MLOAD_' + CONVERT(VARCHAR(8), GETDATE(), 112)
	,getdate()
	,null
	,0
	,null
	,null
	,getdate()
	,null
	,null
	,'2069-12-31 00:00:00'
	,@MGPartyID
	,null
	,'C'
	,getdate()
	,'system'
	,null
	,null
	,'system'
	,'M'
	,'M'
	,src.MOCARelationshipStartDate
	,src.MOCARelationshipEndDate
	,1 
)
OUTPUT inserted.partyid,src.SSN, src.Salutation,src.FirstName, src.LastName, src.MiddleName,src.DoB, src.NPI,SRC.MOCARelationshipStartDate
	INTO @personTemp1;
 
print 'Ind Owner Party Done==>' +  convert(varchar(10),@loopID ) 

INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           (PartyID,SSN,Salutation,FirstName,MiddleName,LastName,DoB,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag)
select partyid, SSN
,Salutation,FirstName,MiddleName,LastName,DoB,NPI,null,null,'C',GetDate(),'system','system',1  
from @personTemp1 


print 'Ind Owner Person Done==>' +  convert(varchar(10),@loopID ) 

INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID]
           ,[DateCreated]
           ,[IsDeleted]
           ,[NPI]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])

select 
[PartyID]
           ,convert(date,GETDATE(),112)
           ,0
           ,[NPI]
           ,'C'
           ,convert(date,GETDATE(),112)
           ,'system'
           ,'system'
           ,1
from @personTemp1 

print 'Ind Owner Provider Done==>' +  convert(varchar(10),@loopID ) 


INSERT  into [KYPEnrollment].[pAccount_PDM_Address] ( addressLine1 ,addressLine2,City ,State ,Zip,ZipPlus4,AddressType,lastAction,LastActionDate,
				LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo)
select partyid,null,null,null,Null,null,'Moca','C',GetDate(),'system','system',1,Null   from @personTemp1

 
INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
select	null,partyid,Null, GETDATE(),1,0,'No Data','C',GetDate(),'system','system',1 from @personTemp1

			
Update A  Set A.AddressID=B.AddressID from [KYPEnrollment].[pAccount_PDM_Location] A
 Inner Join [KYPEnrollment].[pAccount_PDM_Address] B on cast(A.partyid as Varchar(10))=B.addressLine1 
 where A.AddressID is null and B.AddressType='Moca'
 and A.PartyID in (
 select PartyID from @personTemp1
 )
 
Update [KYPEnrollment].[pAccount_PDM_Address] set addressLine1='No Data', AddressType=null where 
addressLine1 in (
 select cast(PartyID as Varchar(10)) from @personTemp1
)


insert into KYPEnrollment.pAccount_PDM_Owner_Role (TypeForm, IsDeleted, CurrentRecordFlag, Other, OtherValue,OtherDate,PartyID, DateCreated,
LastAction,LastActionDate,LastActionApprovedBy,LastActorUserID)
select 'OwnerControlInterestOwnerRole', 0, 1, 1,'No Data',MOCARelationshipStartDate,PartyID,GETDATE(),'C',null,'System','System'  
from @personTemp1



print 'Completed Owner Transposition for Ind Owner==>' +  convert(varchar(10),@loopID )




--Then Transform Entity Owners of Sub Groups

print 'Going to start Entity Transposition for Org Owner==>' +  convert(varchar(10),@loopID )

/*
MERGE [KYPEnrollment].[pAccount_PDM_Party]  trgt
USING 
(  
select distinct null as PartyID, B.Name, B.MOCARelationshipStartDate, B.MOCARelationshipEndDate, 
C.TIN, C.LegalName,C.EIN, C.NPI, E.NPI as ProviderNPI
from @SubGroupAccountIDsAndPartyID A
join KYPEnrollment.pAccount_PDM_Party B
on A.SubGroupAccountID=B.AccountID
and  B.Type in (
'Entity Ownership'
)
join KYPEnrollment.pAccount_PDM_Organization C
on B.PartyID=C.PartyID
left join KYPEnrollment.pAccount_PDM_Provider E
on B.PartyID=E.PartyID
where B.CurrentRecordFlag=1 
  
)src ON (trgt.partyid=src.partyid)
WHEN NOT MATCHED THEN 
	INSERT (
			[AccountID]
           ,[Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[ParentPartyID]
           ,[profile_id]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[LastMOCARelationshipUpdateBy]
           ,[LastMOCAUpdateBy]
           ,[MOCARelationshipStartDate]
           ,[MOCARelationshipEndDate]
           ,[CurrentRecordFlag]	
	)
 VALUES (
 
 @MGAccountID
           ,'Entity Ownership'
           ,src.Name
           ,0
           ,1
           ,0
           ,1
           ,'MonthlyProvider'
           ,'MLOAD_' + CONVERT(VARCHAR(8), GETDATE(), 112)
           ,getdate()
           ,null
           ,0
           ,null
           ,null
           ,getdate()
           ,null
           ,null
           ,'2069-12-31 00:00:00'
           ,@MGPartyID
           ,null
           ,'C'
           ,getdate()
           ,'system'
           ,null
           ,null
           ,'system'
           ,'M'
           ,'M'
           ,src.MOCARelationshipStartDate
           ,src.MOCARelationshipEndDate
           ,1 
 
 )
output inserted.partyid,src.TIN, src.LegalName,src.EIN,src.NPI
 into @OrgTemp1;
 */
 
MERGE [KYPEnrollment].[pAccount_PDM_Party] TRGT
USING 
(  
	SELECT DISTINCT NULL AS PartyID, MAX(B.Name) AS Name, MIN(B.MOCARelationshipStartDate) AS MOCARelationshipStartDate,
					MAX(B.MOCARelationshipEndDate) AS MOCARelationshipEndDate, MAX(C.TIN) AS TIN, MAX(C.LegalName) AS LegalName,
					C.EIN, MAX(C.NPI) AS NPI, MAX(E.NPI) AS ProviderNPI
		FROM @SubGroupAccountIDsAndPartyID A
		JOIN KYPEnrollment.pAccount_PDM_Party B
		ON A.SubGroupAccountID = B.AccountID
		AND B.Type IN ('Entity Ownership')
		JOIN KYPEnrollment.pAccount_PDM_Organization C
		ON B.PartyID = C.PartyID
		LEFT JOIN KYPEnrollment.pAccount_PDM_Provider E
		ON B.PartyID = E.PartyID
		WHERE B.CurrentRecordFlag = 1
		GROUP BY C.EIN
)SRC ON (TRGT.PartyID = SRC.PartyID)
WHEN NOT MATCHED THEN 
INSERT
(
	[AccountID]
	,[Type]
	,[Name]
	,[IsProvider]
	,[IsEnrolled]
	,[IsTemp]
	,[IsActive]
	,[LoadType]
	,[LoadID]
	,[LastLoadDate]
	,[DateModified]
	,[IsDeleted]
	,[Source]
	,[CreatedBy]
	,[DateCreated]
	,[ModifiedBy]
	,[DeletedBy]
	,[DateDeleted]
	,[ParentPartyID]
	,[profile_id]
	,[LastAction]
	,[LastActionDate]
	,[LastActorUserID]
	,[LastActionReason]
	,[LastActionComments]
	,[LastActionApprovedBy]
	,[LastMOCARelationshipUpdateBy]
	,[LastMOCAUpdateBy]
	,[MOCARelationshipStartDate]
	,[MOCARelationshipEndDate]
	,[CurrentRecordFlag]	
)
VALUES
(
	@MGAccountID
	,'Entity Ownership'
	,src.Name
	,0
	,1
	,0
	,1
	,'MonthlyProvider'
	,'MLOAD_' + CONVERT(VARCHAR(8), GETDATE(), 112)
	,getdate()
	,null
	,0
	,null
	,null
	,getdate()
	,null
	,null
	,'2069-12-31 00:00:00'
	,@MGPartyID
	,null
	,'C'
	,getdate()
	,'system'
	,null
	,null
	,'system'
	,'M'
	,'M'
	,src.MOCARelationshipStartDate
	,src.MOCARelationshipEndDate
	,1 
)
OUTPUT inserted.PartyID,src.TIN, src.LegalName,src.EIN,src.NPI,SRC.MOCARelationshipStartDate
	INTO @OrgTemp1;
 
PRINT 'Org Owner Party Done==>' +  convert(varchar(10),@loopID ) 
 

INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           (PartyID,LegalName,DBAName1,TIN,NPI,DateCreated,DateDeleted,lastAction,LastActionDate,LastActorUserId,LastActionApprovedBy,CurrentRecordFlag,EIN)
	SELECT PartyID, LegalName,null,TIN,NPI,null,null,'C',GetDate(),'system','system',1,EIN 
		FROM @OrgTemp1 


PRINT 'Org Owner Organization Done==>' +  convert(varchar(10),@loopID ) 

INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID]
           ,[DateCreated]
           ,[IsDeleted]
           ,[NPI]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])

select 
[PartyID]
           ,convert(date,GETDATE(),112)
           ,0
           ,[NPI]
           ,'C'
           ,convert(date,GETDATE(),112)
           ,'system'
           ,'system'
           ,1
from @OrgTemp1 


PRINT 'Org Owner Provider Done==>' +  convert(varchar(10),@loopID ) 



INSERT  into [KYPEnrollment].[pAccount_PDM_Address] ( addressLine1 ,addressLine2,City ,State ,Zip,ZipPlus4,AddressType,lastAction,LastActionDate,
				LastActionUserId,LastActionApprovedByUsedID, CurrentRecordFlag,ServiceLocationNo)
select partyid,null,null,null,Null,null,'Moca','C',GetDate(),'system','system',1,Null   from @OrgTemp1

 
INSERT INTO [KYPEnrollment].[pAccount_PDM_Location](AddressID,PartyID,ProviderID,DateCreated,[InActive],[IsDeleted],Type,lastAction,LastActionDate,LastActorUserID,LastActionApprovedBy, CurrentRecordFlag)
select	null,partyid,Null, GETDATE(),1,0,'No Data','C',GetDate(),'system','system',1 from @OrgTemp1

			
Update A  Set A.AddressID=B.AddressID from [KYPEnrollment].[pAccount_PDM_Location] A
 Inner Join [KYPEnrollment].[pAccount_PDM_Address] B on cast(A.partyid as Varchar(10))=B.addressLine1 
 where A.AddressID is null and B.AddressType='Moca'
 and A.PartyID in (
 select PartyID from @OrgTemp1
 )
 
Update [KYPEnrollment].[pAccount_PDM_Address] set addressLine1='No Data', AddressType=null where 
addressLine1 in (
 select cast(PartyID as Varchar(10)) from @OrgTemp1
)




insert into KYPEnrollment.pAccount_PDM_Owner_Role (TypeForm, IsDeleted, CurrentRecordFlag, Other, OtherValue,OtherDate,PartyID, DateCreated,
LastAction,LastActionDate,LastActionApprovedBy,LastActorUserID)
select 'OwnerControlInterestOwnerRole', 0, 1, 1,'No Data',MOCARelationshipStartDate,PartyID,GETDATE(),'C',null,'System','System'  
from @OrgTemp1

print 'Completed Owner Transposition for Org Owner==>' +  convert(varchar(10),@loopID )
*/
/*Commented by Anshuman on 23 Feb, 2017: Whenever an application raised to any Group Account and that Group Account now changed into the Subgroup 
then will send a notification to the Provider that "Group Account changed into the Mixed Group Account". For that we need to insert records in 
three tables KYPPORTAL.PortalKYP.Message, KYPPORTAL.PortalKYP.MessageRecipient and KYPPORTAL.PortalKYP.Recipient*/

SELECT SubGroupAccountID,AccountNumber,CONVERT(DATE,GETDATE(),105) AS DateSent,NEWID() AS UUID
	INTO #TempGroupAccountChangedintoMixedGroupAccount
	FROM @SubGroupAccountIDsAndPartyID Temp
	JOIN KYPEnrollment.pADM_Account ACC
	ON Temp.SubGroupAccountID	= ACC.AccountID
	JOIN KYPPORTAL.PortalKYP.pRenderingAffiliation RA -- Account should be exist in this table then only it will convert into Mixed Group
	ON Temp.SubGroupAccountID	= RA.Group_Instance_ID
	GROUP BY SubGroupAccountID,AccountNumber

INSERT INTO KYPPORTAL.PortalKYP.Message
(
	FromGroupName,
	BodyMessage,
	Subject,
	IsDeleted,
	UUID,
	DateSent,
	NotifiedByPublic,
	IsMailSent,
	TotalAttachments
)
OUTPUT INSERTED.MessageID,INSERTED.UUID,INSERTED.DateSent
	INTO @TempMessage
SELECT 'DHCS Provider Enrollment Department','<HTML><BODY>This message is for informational purposes only. DHCS Medi-Cal has approved one or more Rendering Provider type affiliations, which provider type(s) are different from your original group&rsquo;s type. The follow changes were made to your group&rsquo;s account.<br><br>
Old Account ID: <b>' + AccountNumber + '</b><br><br>
Group Type: <b>Mixed Group</b><br>
New Account ID:<b>' + @MGAccountNumber + '</b><br><br>
If you have any questions or concerns, please send a message to <b><a href="#" onclick="messageCenterWidget.writeNewMessage();inboxDialog.close();">DHCS Provider Enrollment Division</a></b><br><br>
Sincerely,<br>
DHCS Medi-Cal<br>
Provider Enrollment Division<br>
</BODY></HTML>','Account ID: ' + AccountNumber + ' Changed to Mixed Group',0,UUID,DateSent,1,0,0	--,SubGroupAccountID
	FROM #TempGroupAccountChangedintoMixedGroupAccount	

INSERT INTO KYPPORTAL.PortalKYP.MessageRecipient(MessageID,Type)
	SELECT MessageID,'new'
		FROM @TempMessage

INSERT INTO	@TempRecipient		
	SELECT MR.MessageRecipientID,ILV.Owner_User_ID,ILV.Owner_Profile_ID,0,0,'PortalUser'
		FROM @TempMessage Temp
		JOIN KYPPORTAL.PortalKYP.MessageRecipient MR
		ON Temp.MessageID = MR.MessageID
		JOIN (SELECT DISTINCT Owner_User_ID,Owner_Profile_ID,UUID,DateSent
				FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
				JOIN #TempGroupAccountChangedintoMixedGroupAccount Temp
				ON RA.Group_Instance_ID = Temp.SubGroupAccountID) ILV
		ON	Temp.UUID		= ILV.UUID AND
			Temp.DateSent	= ILV.DateSent

	UNION

	SELECT MR.MessageRecipientID,ILV.Associate_User_ID,ILV.Associate_Profile_ID,0,0,'PortalUser'
		FROM @TempMessage Temp
		JOIN KYPPORTAL.PortalKYP.MessageRecipient MR
		ON Temp.MessageID = MR.MessageID
		JOIN (SELECT DISTINCT Associate_User_ID,Associate_Profile_ID,UUID,DateSent
				FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
				JOIN #TempGroupAccountChangedintoMixedGroupAccount Temp
				ON RA.Group_Instance_ID = Temp.SubGroupAccountID
				WHERE Associate_User_ID		IS NOT NULL AND
					  Associate_Profile_ID	IS NOT NULL) ILV
		ON	Temp.UUID		= ILV.UUID AND
			Temp.DateSent	= ILV.DateSent

WHILE @I <= (SELECT COUNT(1)
				FROM @TempRecipient)
				
BEGIN

	INSERT INTO KYPPORTAL.PortalKYP.Recipient
	(
		MessageRecipientID,
		PortalUserID,
		ProfileID,
		IsRead,
		IsDeleted,
		RecipientType
	)
	SELECT	MessageRecipientID,
			Owner_User_ID,
			Owner_Profile_ID,
			IsRead,
			IsDeleted,
			RecipientType
		FROM @TempRecipient
		WHERE ID = @I

	SET @I = @I + 1
	
END

---===========>Do Account Numbering Change (Account and Account Search) and Flagging of subgroups==========================      

UPDATE A 
	SET A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode,
		A.IsPastOwner	= 1,
		A.LastActionDate = GETDATE()
	OUTPUT INSERTED.AccountID,DELETED.AccountNumber,INSERTED.AccountNumber
		INTO @AccountNumberHistory
	FROM [KYPEnrollment].[pADM_Account] A
	JOIN @SubGroupAccountIDsAndPartyID B
	ON A.AccountID = B.SubGroupAccountID

INSERT INTO KYPEnrollment.MixedGroupHistory(AccountID,GroupName,[Action],Attribute,OldValue,NewValue,IsFlag)
	SELECT AccountID,'Mixed Group Created','UPD','Account Number',OldAccountNumber,NewAccountNumber,0
		FROM @AccountNumberHistory

UPDATE A
	SET A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode
	FROM KYPEnrollment.AccountSearch A
	JOIN @SubGroupAccountIDsAndPartyID B
	ON A.AccountID = B.SubGroupAccountID

UPDATE A
	SET A.AccountNumber = @MGAccountNumber + '-' + SubGroupProviderTypeCode
	FROM KYPEnrollment.pAccount_BizProfile_Details A
	JOIN @SubGroupAccountIDsAndPartyID B
	ON A.AccountID = B.SubGroupAccountID

/*Commented by Anshuman on 23 Feb, 2017: Whenever an application raised to any Group Account and that Group Account now changed into the Subgroup 
then Group Account ID will changed into MG AccountID in Portal tables and will track the history also*/

UPDATE KYPPORTAL.PortalKYP.pRenderingAffiliation
	SET Old_Group_Instance_ID	 = Group_Instance_ID,
		Old_Group_ProviderNumber = Group_ProviderNumber,
		Account_Changed_to_SubGroup_Account_Date = GETDATE()
	FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON RA.Group_Instance_ID	= B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.pRenderingAffiliation
	SET Group_Instance_ID	 = @MGAccountID,
		Group_ProviderNumber = @MGAccountNumber
	FROM KYPPORTAL.PortalKYP.pRenderingAffiliation RA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON RA.Group_Instance_ID	= B.SubGroupAccountID	

UPDATE KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation
	SET Old_GroupAccountID	= GroupAccountID,
		Account_Changed_to_SubGroup_Account_Date = GETDATE()
	FROM KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation RA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON RA.GroupAccountID = B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation
	SET GroupAccountID	 = @MGAccountID
	FROM KYPPORTAL.PortalKYP.pPDM_CurrentAffiliation RA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON RA.GroupAccountID = B.SubGroupAccountID

/* For Group Service address tab*/
UPDATE KYPPORTAL.PortalKYP.pServiceAddressRendering
	SET Old_AccountID								= AccountID,
		Old_AccountNumber							= AccountNumber,
		Account_Changed_to_SubGroup_Account_Date	= GETDATE()
	FROM KYPPORTAL.PortalKYP.pServiceAddressRendering SA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON SA.AccountID	= B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.pServiceAddressRendering
	SET AccountID		= @MGAccountID,
		AccountNumber	= @MGAccountNumber
	FROM KYPPORTAL.PortalKYP.pServiceAddressRendering SA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON SA.AccountID	= B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.pAffiliationServiceAddress
	SET Old_AccountID	= AccountID,
		Account_Changed_to_SubGroup_Account_Date = GETDATE()
	FROM KYPPORTAL.PortalKYP.pAffiliationServiceAddress ASA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON ASA.AccountID = B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.pAffiliationServiceAddress
	SET AccountID	= @MGAccountID
	FROM KYPPORTAL.PortalKYP.pAffiliationServiceAddress ASA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON ASA.AccountID = B.SubGroupAccountID

/*Application*/
UPDATE KYP.ADM_Case
	SET AccountNumberBeforeConvertingToSubgroup	= Group_AccountNumber,
		AccountChangedToSubgroupDate			= GETDATE()
	FROM KYP.ADM_Case AC
	JOIN @SubGroupAccountIDsAndPartyID B
	ON AC.Group_AccountNumber = B.SubGroupAccountNumber
	WHERE ApplnType IN('Rendering-S','New Rendering')

UPDATE KYP.ADM_Case
	SET Group_AccountNumber = @MGAccountNumber
	FROM KYP.ADM_Case AC
	JOIN @SubGroupAccountIDsAndPartyID B
	ON AC.Group_AccountNumber = B.SubGroupAccountNumber
	WHERE ApplnType IN('Rendering-S','New Rendering')

UPDATE KYP.ADM_Case
	SET AccountNumberBeforeConvertingToSubgroup	= Group_DisaffiliateAcNo,
		AccountChangedToSubgroupDate			= GETDATE()
	FROM KYP.ADM_Case AC
	JOIN @SubGroupAccountIDsAndPartyID B
	ON AC.Group_DisaffiliateAcNo = B.SubGroupAccountNumber
	WHERE ApplnType IN('Disaffiliation')
	
UPDATE KYP.ADM_Case
	SET Group_DisaffiliateAcNo	= @MGAccountNumber,
		AccountNo				= @MGAccountNumber
	FROM KYP.ADM_Case AC
	JOIN @SubGroupAccountIDsAndPartyID B
	ON AC.Group_DisaffiliateAcNo = B.SubGroupAccountNumber
	WHERE ApplnType IN('Disaffiliation')

/*Linked application*/
UPDATE KYP.OIS_UserLinkedAppDetail
	SET GroupApplicationNumberBeforeConvertingToSubgroup = GroupApplicationNo,
		AccountChangedToSubgroupDate					 = GETDATE()
	FROM KYP.OIS_UserLinkedAppDetail L
	JOIN @SubGroupAccountIDsAndPartyID B
	ON L.GroupApplicationNo = B.SubGroupAccountNumber

UPDATE KYP.OIS_UserLinkedAppDetail
	SET GroupApplicationNo = @MGAccountNumber
	FROM KYP.OIS_UserLinkedAppDetail L
	JOIN @SubGroupAccountIDsAndPartyID B
	ON L.GroupApplicationNo = B.SubGroupAccountNumber

/*Account Section in Portal*/
UPDATE KYPPORTAL.PortalKYP.AccountSectionChange
	SET Old_AccountID								= AccountID,
		Old_AccountNumber							= AccountNumber,
		Account_Changed_to_SubGroup_Account_Date	= GETDATE()
	FROM KYPPORTAL.PortalKYP.AccountSectionChange AC
	JOIN @SubGroupAccountIDsAndPartyID B
	ON AC.AccountID = B.SubGroupAccountID

UPDATE KYPPORTAL.PortalKYP.AccountSectionChange
	SET AccountID		= @MGAccountID,
		AccountNumber	= @MGAccountNumber
	FROM KYPPORTAL.PortalKYP.AccountSectionChange RA
	JOIN @SubGroupAccountIDsAndPartyID B
	ON RA.AccountID	= B.SubGroupAccountID

---===========>BizProfileDetail==========================      
 
 
INSERT INTO [KYPEnrollment].[pAccount_BizProfile_Details]
           ([ProfileID]
           ,[AccountID]
           ,[AccountTypeID]
           ,[AccountEnrollmentStatus]
           ,[AccountBillingStatus]
           ,[AccountLegalName]
           ,[AccountDBAName]
           ,[AccountProviderType]
           ,[AccountNPI]
           ,[AccountSSN]
           ,[AccountEIN]
           ,[AccountAddressType]
           ,[AccountAddressLine1]
           ,[AccountAddressLine2]
           ,[AccountAdrCity]
           ,[AccountAdrState]
           ,[AccountAdrZip9]
           ,[AccountLicenseType]
           ,[AccountLicenseNo]
           ,[AccountPhone]
           ,[AccountPIN]
           ,[UserRemark]
           ,[EffectiveBeginDate]
           ,[EffectiveEndDate]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[AccountNumber]
           ,[PayAccountAddressLine1]
           ,[PayAccountAddressLine2]
           ,[PayAccountAdrCity]
           ,[PayAccountAdrState]
           ,[PayAccountAdrZip9]) 
           
select 
[ProfileID]
           ,@MGAccountID as [AccountID]
           ,[AccountTypeID]
           ,@MGStatusAcc
           ,@MGBillingStatus
           ,[AccountLegalName]
           ,[AccountDBAName]
           ,'100'
           ,[AccountNPI]
           ,[AccountSSN]
           ,[AccountEIN]
           ,[AccountAddressType]
           ,[AccountAddressLine1]
           ,[AccountAddressLine2]
           ,[AccountAdrCity]
           ,[AccountAdrState]
           ,[AccountAdrZip9]
           ,[AccountLicenseType]
           ,[AccountLicenseNo]
           ,[AccountPhone]
           ,[AccountPIN]
           ,[UserRemark]
           ,@MGStatusBeginDate
           ,@MGDeactivationDate
           ,[LastAction]
           ,convert(date,GETDATE(),112) as [DateCreated]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,@MGAccountNumber as [AccountNumber]
           ,[PayAccountAddressLine1]
           ,[PayAccountAddressLine2]
           ,[PayAccountAdrCity]
           ,[PayAccountAdrState]
           ,[PayAccountAdrZip9]           
from [KYPEnrollment].[pAccount_BizProfile_Details] 
where AccountID in (
select MAX(SubGroupAccountID) from @SubGroupAccountIDsAndPartyID
)


--print @MixedGroupClubbingID
DELETE FROM @SubGroupAccountIDsAndPartyID 
DELETE FROM @MGStatusAndDate
DELETE FROM @MG_CLIA_AuxTable
-- DELETE FROM @personTemp1
-- DELETE FROM @OrgTemp1
DELETE FROM @AccountNumberHistory
DELETE FROM @TempMessage
DROP TABLE #TempGroupAccountChangedintoMixedGroupAccount

select @loopID= MIN (ID)from StageTableToLoopThroughMixedGroup where ID>@loopID

SET @MGAccountNumber		= NULL
SET @MGPartyID				= NULL
SET @MGAccountID			= NULL
SET @MGReEnrolInd			= NULL
SET @MGReEnrolDate			= NULL
SET @MGOutOfStateInd		= NULL
SET @MGCHDPCode				= NULL
SET @MGProvisionalCode		= NULL
SET @MGProvisionalCodeDate	= NULL
SET @MGLabStatusCode		= NULL
SET @MGLabStatusCodeDate	= NULL
SET @MixedGroupClubbingID	= NULL
SET @MGStatusAcc 			= NULL
SET @MGBillingStatus		= NULL
SET @MGStatusBeginDate 		= NULL
SET @MGApplicationDate 		= NULL
SET @MGActivationDate 		= NULL
SET @MGDeactivationDate 	= NULL
SET @MGCliaNumber 			= NULL
SET @MGContactPersonPartyId = NULL

end


--============>>>>>Don't miss to Enable the Triggers Again
;
ENABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
ENABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
/*
ENABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
ENABLE TRIGGER  AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
ENABLE TRIGGER  pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
*/
-- ENABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;


end
GO

