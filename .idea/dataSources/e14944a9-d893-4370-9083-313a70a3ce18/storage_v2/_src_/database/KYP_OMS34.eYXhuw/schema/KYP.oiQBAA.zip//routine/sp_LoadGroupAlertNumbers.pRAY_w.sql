



-- =============================================
-- Author:		Ashok Chelimilla
-- Create date: March 26, 2015
-- Description:	<Description,,>
-- Last modified on 30Aug2018 by (DA team)
--detail: commented not used table join "KYP.PDM_ProviderAccount"
-- =============================================
CREATE PROCEDURE [KYP].[sp_LoadGroupAlertNumbers] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @AlertNo VARCHAR(50),
		@WatchedPartyID INT,
		@NPI VARCHAR(10),
		@PartyType VARCHAR(50),
		@IsProvider BIT,
		@RelatedCount INT,
		@MemberNPICount INT,
		@ProviderNo varchar(20),
		@AccID varchar(50),
		@AccGenID varchar(50);
		
	SET @RelatedCount = 0;
	SET @MemberNPICount = 0;
	
	TRUNCATE TABLE KYP.MDM_GroupAlert
	
	IF OBJECT_ID(N'tempdb..#tmp_RelatedMembersDetails') IS NOT NULL
		BEGIN
			DROP TABLE #tmp_RelatedMembersDetails
		END
	
	IF OBJECT_ID(N'tempdb..#tmp_RelatedProviders') IS NOT NULL
		BEGIN
			DROP TABLE #tmp_RelatedProviders
		END							
	
	IF OBJECT_ID(N'tempdb..#tmp_RelatedProvidersNPICount') IS NOT NULL
		BEGIN
			DROP TABLE #tmp_RelatedProvidersNPICount
		END
	
	CREATE TABLE #tmp_RelatedProviders([ID] INT IDENTITY(1,1), T_Group_ProviderNO varchar(20), T_Member_ProviderNO varchar(20), T_Type VARCHAR(20))
	CREATE TABLE #tmp_RelatedMembersDetails([ID] INT IDENTITY(1,1), [PartyID] INT, [ProvNum] VARCHAR(20), [AlertNo] VARCHAR(10),T_AccountID VARCHAR(50), T_GenAccountID VARCHAR(50))
	CREATE TABLE #tmp_RelatedProvidersNPICount([ID] INT IDENTITY(1,1), [provNum] VARCHAR(20))
							
	INSERT INTO #tmp_RelatedMembersDetails
		SELECT DISTINCT A.WatchedPartyID, B.ProvNumber, A.AlertNo,B.ProvNumber as AccountNumber,(B.ProvNumber+B.ProvNumber) as AccGenNumber FROM KYP.MDM_Alert A 
		INNER JOIN KYP.PDM_Provider B ON A.WatchedPartyID = B.PartyID
		--INNER JOIN KYP.PDM_ProviderAccount C ON B.ProvNumber = C.AccountNumber ---This table contains old data so commented this join and used same way as MD
			WHERE B.ProvNumber IS NOT NULL --and C.AccountNumber IS NOT NULL
		ORDER BY A.AlertNo
								
	DECLARE grpAlertCursor CURSOR FOR 
	
		SELECT DISTINCT A.WatchedPartyID, B.ProvNumber, A.AlertNo,B.ProvNumber as AccountNumber,(B.ProvNumber+B.ProvNumber) as AccGenNumber FROM KYP.MDM_Alert A 
		INNER JOIN KYP.PDM_Provider B ON A.WatchedPartyID = B.PartyID
		--INNER JOIN KYP.PDM_ProviderAccount C ON B.ProvNumber = C.AccountNumber ---This table contains old data so commented this join and used same way as MD
			WHERE B.ProvNumber IS NOT NULL --and C.AccountNumber IS NOT NULL
		ORDER BY A.AlertNo
		
	OPEN grpAlertCursor 
	FETCH NEXT FROM grpAlertCursor INTO @WatchedPartyID, @ProviderNo, @AlertNo, @AccID, @AccGenID
 
		WHILE @@Fetch_Status = 0 
		BEGIN

			--SELECT ProvNumber FROM KYP.PDM_Provider WHERE PartyID = 127585

			IF @ProviderNo IS NOT NULL OR @ProviderNo <> ''
				BEGIN
				
				SELECT  @RelatedCount=COUNT(Group_ProviderNO) FROM KYP.PDM_MasterGroupProvider WHERE Group_ProviderNO = @ProviderNo  

					IF @RelatedCount > 0
						BEGIN
											
							INSERT INTO #tmp_RelatedProviders 
							select x.* from (SELECT Group_ProviderNO, Group_ProviderNO as Member_ProviderNO, [Type] FROM KYP.PDM_MasterGroupProvider 
								WHERE Group_ProviderNO = @ProviderNo
								union
								SELECT Group_ProviderNO, Member_ProviderNO, [Type] FROM KYP.PDM_MasterGroupProvider 
								WHERE Group_ProviderNO = @ProviderNo)x
								
							INSERT INTO #tmp_RelatedProvidersNPICount
								SELECT DISTINCT C.ProvNum FROM #tmp_RelatedMembersDetails C 
								INNER JOIN #tmp_RelatedProviders D ON C.ProvNum = D.T_Member_ProviderNO
							
							INSERT INTO KYP.MDM_GroupAlert (Group_AlertNO, Member_AlertNO, Type,GroupAccountID,GroupGenAccountID,GroupMemberAccountID,GroupGenMemberAccountID)
								SELECT @AlertNo, C.AlertNo, D.T_Type ,@AccID,@AccGenID, T_AccountID, T_GenAccountID FROM #tmp_RelatedMembersDetails C 
								INNER JOIN #tmp_RelatedProviders D ON C.ProvNum = D.T_Member_ProviderNO
							
							TRUNCATE TABLE #tmp_RelatedProviders
							TRUNCATE TABLE #tmp_RelatedProvidersNPICount
							
						END
						
				END
			
			FETCH NEXT FROM grpAlertCursor INTO @WatchedPartyID, @ProviderNo, @AlertNo, @AccID, @AccGenID

		END -- End of Fetch
				
	CLOSE grpAlertCursor
	DEALLOCATE grpAlertCursor
	
delete x from (select *, ROW_NUMBER()over (partition by Group_AlertNO,Member_AlertNO order by id )as row 
from KYP.MDM_GroupAlert )x
where x.row>1

update x 
set x.MembersCount = y.membCount
, Type='Group'
from KYP.MDM_GroupAlert x
inner join 
(select y.Group_AlertNO , membCount from
(SELECT  distinct Group_ProviderNO, count(Group_ProviderNO)as membCount 
FROM KYP.PDM_MasterGroupProvider 
 group by Group_ProviderNO )x
inner join 
(select distinct x.*, y.MedicaidID from KYP.MDM_GroupAlert x
inner join kyp.mdm_alert y
on x.Group_AlertNO = y.alertno
and x.Member_AlertNO = y.alertno)y
on x.Group_ProviderNO=y.MedicaidID)y
on x.Group_AlertNO = y.Group_AlertNO
and x.Member_AlertNO = y.Group_AlertNO
	
update x
set x.MemberwithAltCount = y.cnt
,Type='Group'
from KYP.MDM_GroupAlert x
inner join 
(select  Group_AlertNO,COUNT(*)-1 as cnt
from KYP.MDM_GroupAlert
group by Group_AlertNO)y
on x.Group_AlertNO = y.Group_AlertNO
and x.Member_AlertNO = y.Group_AlertNO


							
END
PRINT 'db_objects/03_STORED_PROCEDURES/009_DDL_sp_sp_UpdateBulkNotes.sql'


GO

