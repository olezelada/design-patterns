
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <14/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Counselor_Information]
@new_Account_Id int

AS
BEGIN

SET NOCOUNT ON;


update o set o.CurrentRecordFlag=0,o.IsDeleted=1
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.ParentPartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON p.PartyID=pe.PartyID INNER JOIN KYPEnrollment.pAccount_PDM_Person_OtherName o ON o.PersonID=pe.PersonID
where a.AccountID=@new_Account_Id and p.Type='Counselor' and a.IsDeleted=0 and p.IsDeleted=0 and p.CurrentRecordFlag=1 and pe.CurrentRecordFlag=1 and pe.Deleted=0



END
GO

