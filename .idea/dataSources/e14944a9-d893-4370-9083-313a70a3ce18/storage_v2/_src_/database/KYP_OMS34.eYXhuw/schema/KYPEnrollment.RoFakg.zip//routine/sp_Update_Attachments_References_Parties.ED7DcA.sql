-- =============================================
-- Author:		<Rloayza>
-- Create date: <08/02/2018>
-- Description:	<Store application account attachment references>
-- =============================================
CREATE PROCedure [KYPEnrollment].[sp_Update_Attachments_References_Parties]
  (
    @accountId INT,
    @applicationPartyId INT,
    @accountPartyId INT
  )

AS

  BEGIN

    BEGIN TRY

    IF @applicationPartyId IS NOT NULL AND @accountPartyId IS NOT NULL
      BEGIN

        UPDATE KYPEnrollment.pAccount_Attachments SET IsDeleted = 1 WHERE AccountPartyId = @accountPartyId
        EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @accountId, @applicationPartyId, @accountPartyId
      END

    END TRY

    BEGIN CATCH

    Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'PartyID',@KeyValue = @accountPartyId

    END CATCH;

  END


GO

