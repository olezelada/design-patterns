-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [KYP].[RemovebackslashAdd] 
(
	
	@NameValue varchar(500)
)
RETURNS varchar(500)
AS
BEGIN 
	
select @NameValue =
case 

when (charindex('/',@NameValue) = 1 and charindex('/',@NameValue,LEN(@NameValue)-1) = LEN(@NameValue))
      then substring(substring(@NameValue, 2, LEN(@NameValue)-1 ), 1, LEN(@NameValue)-2)
when charindex('/',@NameValue) = 1
      then substring(@NameValue, 2, LEN(@NameValue)-1)
when charindex('/',@NameValue,LEN(@NameValue)-1) = LEN(@NameValue)
      then substring(@NameValue, 1, LEN(@NameValue)-1)
else 
      @NameValue      
end 


return @NameValue
END


GO

