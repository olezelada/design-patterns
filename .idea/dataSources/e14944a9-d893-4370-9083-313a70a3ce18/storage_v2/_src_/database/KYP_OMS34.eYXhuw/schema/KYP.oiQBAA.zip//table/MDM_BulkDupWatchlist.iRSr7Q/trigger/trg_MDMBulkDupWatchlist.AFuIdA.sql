

-- =============================================
-- Author:		MANIKANTA DONTHU
-- Create date: 7/10/2014
-- Description:	IT WILL CALL THE STORED PROCEDURE
-- =============================================
CREATE TRIGGER [KYP].[trg_MDMBulkDupWatchlist] ON [KYP].[MDM_BulkDupWatchlist]
AFTER INSERT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @PARTYID INT
		,@NPI VARCHAR(50)
		,@Name VARCHAR(175)
		,@DBANAME VARCHAR(175)
		,@ADDRESSLINE1 VARCHAR(175)
		,@CITY VARCHAR(175)
		,@WatchedPartyType VARCHAR(175)
		,@STATE VARCHAR(175)
		,@ZIP VARCHAR(175)
		,@ADDRESSID INT
		,@MedicaidID bigint /*PI-449*/
		,@temp INT = 0
		,@V_min INT
		,@V_max INT
		,@min INT
		,@max INT
	DECLARE @INSERTED TABLE (
		V_id INT PRIMARY KEY identity(1, 1)
		,V_MedicaidID VARCHAR(1000)
		)

	INSERT INTO @inserted (V_MedicaidID)
	SELECT MedicaidID
	FROM INSERTED

	SELECT @V_min = MIN(V_id)
		,@V_max = MAX(V_id)
	FROM @INSERTED

	WHILE (@V_min < = @V_max)
	BEGIN
		SELECT @MEDICAIDID = V_MedicaidID
		FROM @INSERTED
		WHERE V_id = @V_min

		SELECT @PARTYID = PartyID
			,@WatchedPartyType = type
		FROM KYP.PDM_Party
		WHERE PartyID = @MEDICAIDID

		SELECT @NPI = NPI
		FROM KYP.PDM_Provider
		WHERE PartyID = @PARTYID

		SELECT @ADDRESSID = ADDRESSID
		FROM KYP.PDM_LOCATION
		WHERE PARTYID = @PARTYID

		SELECT @ADDRESSLINE1 = ADDRESSLINE1
			,@CITY = CITY
			,@STATE = STATE
			,@ZIP = ZIP
		FROM KYP.PDM_Address
		WHERE ADDRESSID = @ADDRESSID

		IF @WatchedPartyType = 'Person'
		BEGIN
			SELECT @Name = NAME
			FROM KYP.PDM_PARTY
			WHERE PARTYID = @PARTYID

			IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_NPIWatchlist AS S ON N.GateKeeperID = S.GateKeeperID
						AND N.ISAPPROVED = 1
					WHERE S.NPI = @NPI
					)
			BEGIN
				SET @temp = 1
			END
			ELSE IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_LicenseWatchlist AS L ON N.GateKeeperID = L.GateKeeperID
						AND N.ISAPPROVED = 1
					WHERE L.LICENSE IN (
							SELECT LICENSECODE
							FROM KYP.PDM_LICENSE
							WHERE PARTYID = @PARTYID
							)
					)
			BEGIN
				SET @temp = 1
			END
			ELSE IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_AddressWatchlist AS A ON N.GateKeeperID = A.GateKeeperID
						AND N.isApproved = 1
					WHERE (
							N.LastName + ', ' + N.FirstName + ' ' + N.MiddleName = @Name
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
						OR (
							N.AkaName = @Name
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
					)
			BEGIN
				SET @temp = 1
			END
			ELSE
			BEGIN
				SET @temp = 0
			END
		END
		ELSE
		BEGIN
			SELECT @Name = LEGALNAME
				,@DBANAME = DBANAME1
			FROM KYP.PDM_ORGANIZATION
			WHERE PARTYID = @PARTYID

			IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_NPIWatchlist AS S ON N.GateKeeperID = S.GateKeeperID
						AND N.ISAPPROVED = 1
					WHERE S.NPI = @NPI
					)
			BEGIN
				SET @temp = 1
			END
			ELSE IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_LicenseWatchlist AS L ON N.GateKeeperID = L.GateKeeperID
						AND N.ISAPPROVED = 1
					WHERE L.LICENSE IN (
							SELECT LICENSECODE
							FROM KYP.PDM_LICENSE
							WHERE PARTYID = @PARTYID
							)
					)
			BEGIN
				SET @temp = 1
			END
			ELSE IF EXISTS (
					SELECT TOP 1 N.GateKeeperID
					FROM KYP.GK_Watchlist AS N
					INNER JOIN KYP.GK_AddressWatchlist AS A ON N.GateKeeperID = A.GateKeeperID
						AND N.isApproved = 1
					WHERE (
							N.NAME = @Name
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
						OR (
							N.NAME = @DBANAME
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
						OR (
							N.AkaName = @DBANAME
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
						OR (
							N.AkaName = @NAME
							AND A.AddressLine1 = @ADDRESSLINE1
							AND A.City = @CITY
							AND A.STATE = @STATE
							AND A.ZipCode = @ZIP
							)
					)
			BEGIN
				SET @temp = 1
			END
			ELSE
			BEGIN
				SET @temp = 0
			END
		END

		IF (@temp = 1)
		BEGIN
			SELECT @min = MIN(ID)
				,@max = MAX(ID)
			FROM KYP.MDM_BulkDupWatchlist
			WHERE MedicaidID = @MEDICAIDID
			GROUP BY MedicaidID

			WHILE (@min < = @max)
			BEGIN
				UPDATE A
				SET DummyStatus = 'T'
				FROM KYP.MDM_BulkDupWatchlist A
				WHERE MEDICAIDID = @MEDICAIDID
					AND A.ID = @min
					AND (
						DummyStatus IS NULL
						OR DummyStatus = 'F'
						)

				IF (@min = @max)
				BEGIN
					SET @max = 0
				END

				SELECT @min = min(id)
				FROM KYP.MDM_BulkDupWatchlist
				WHERE id > @min
					AND MedicaidID = @MEDICAIDID
				GROUP BY MedicaidID
			END
		END
		ELSE
		BEGIN
			SELECT @min = MIN(ID)
				,@max = MAX(ID)
			FROM KYP.MDM_BulkDupWatchlist
			WHERE MedicaidID = @MEDICAIDID
			GROUP BY MedicaidID

			WHILE (@min < = @max)
			BEGIN
				UPDATE A
				SET DummyStatus = 'F'
				FROM KYP.MDM_BulkDupWatchlist A
				WHERE MEDICAIDID = @MEDICAIDID
					AND A.ID = @min
					AND (
						DummyStatus IS NULL
						OR DummyStatus = 'T'
						)

				IF (@min = @max)
				BEGIN
					SET @max = 0
				END

				SELECT @min = min(id)
				FROM KYP.MDM_BulkDupWatchlist
				WHERE id > @min
					AND MedicaidID = @MEDICAIDID
				GROUP BY MedicaidID
			END
		END

		SET @V_min = @V_min + 1
	END
END


GO

