/******Script for insert procedure************/
CREATE PROCEDURE [KYP].[p_InsertMDMAlertExtnAddress]
(@AlertID int
 ,@AddressLine1 varchar(250)= NULL
 ,@AddressLine2 varchar(250)=NULL
 ,@County varchar(25) = NULL
 ,@City varchar(50)=NULL
 ,@Zip varchar(5)=NULL
 ,@ZipPlus4 varchar(4)=NULL
 ,@State varchar(25)=NULL
 ,@Country varchar(25)=NULL
 ,@Latitude varchar(7)=NULL
 ,@Longitude varchar(7)=NULL
 ,@USPSFlag bit=NULL
 ,@CreatedDate datetime=NULL
 ,@CreatedBy int=NULL
 ,@ModifiedDate datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedDate datetime=NULL
 ,@DeletedBy int=NULL
 ,@IsDeleted bit=NULL
)
as begin 

INSERT INTO [KYP].[MDM_AlertExtnAddress]
           ([AddressLine1]
           ,[AddressLine2]
           ,[County]
           ,[City]
           ,[Zip]
           ,[ZipPlus4]
           ,[State]
           ,[Country]
           ,[Latitude]
           ,[Longitude]
           ,[USPSFlag]
           ,[CreatedDate]
           ,[CreatedBy]
           ,[ModifiedDate]
           ,[ModifiedBy]
           ,[DeletedDate]
           ,[DeletedBy]
           ,[IsDeleted])
     VALUES
           (@AddressLine1
           ,@AddressLine2
           ,@County
           ,@City
           ,@Zip
           ,@ZipPlus4
           ,@State
           ,@Country
           ,@Latitude
           ,@Longitude
           ,@USPSFlag
           ,@CreatedDate
           ,@CreatedBy
           ,@ModifiedDate
           ,@ModifiedBy
           ,@DeletedDate
           ,@DeletedBy
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[MDM_AlertExtnAddress]')

end


GO

