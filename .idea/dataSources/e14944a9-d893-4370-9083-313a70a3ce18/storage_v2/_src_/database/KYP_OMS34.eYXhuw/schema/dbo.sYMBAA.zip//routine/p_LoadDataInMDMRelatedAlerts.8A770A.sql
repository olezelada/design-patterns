
--Change History
--------------------------------------------------------------------------------------------------------
--Sl.No.	Date			Author		JIRA Ticket				Description
--------------------------------------------------------------------------------------------------------
-- 1		27-Dec-2016		Sundar		CAPAVE-998				Fix for Alert Gen. Issue
-- 2		11-Jan-2017		Sundar		-						Fix on the StatuscodeNumber set to 0 for already created alerts
-- 3		29-Mar-2017		Sundar		PI-716					Fix applied to prevent Proces Entry deletion
-- 4		08-jan-2019	    Mvillarroel DBAB-990				Commented the sentence disable/enabled triggers for MDM.Alert table for prevent the deadlocks

CREATE PROCEDURE [dbo].[p_LoadDataInMDMRelatedAlerts]
AS
BEGIN

--ALTER TABLE KYP.MDM_Alert DISABLE TRIGGER trg_MDM_AlertOnUpdate

	/********************************Declare variables for Alert********/
	DECLARE @LastID INT
		,@CurrentID INT
		,@PartyID INT
		,@now DATETIME
		,@ChildAlertCNT INT
		,@CurrentAlertCount INT
		,@AssignedAlertCount INT
		,@UnAssignedAlertCount INT
		,@ParentAlertID INT
		,@CurrentAlertID INT
		,@i int = 0 --Added for #1
	--DECLARE @WFStatusAssignedAlert VARCHAR(100)
	--	,@WFStatusReadyForAcceptance VARCHAR(100)
	--	,@WFStatusUnassignedAlert VARCHAR(50)
	--DECLARE @WFMinorStatusAssignedAlert VARCHAR(100)
	--	,@WFMinorStatusReadyForAcceptance VARCHAR(100)
	--	,@WFMinorStatusUnassignedAlert VARCHAR(50)

	DECLARE @CheckIfChildAlertsExists INT = 0
		,@ParentAlertNo VARCHAR(10)
		,@CurrParentAlertID INT;

	/*************** Creating a temporary table to hold distinct records (Combination of PartyID+Watchlistname)****************/
	CREATE TABLE #tmp_DistinctParty (
		[id] INT identity(1, 1)
		,[PartyID] INT
		)

	/**************Create a temporary table for holding Related Alerts*******************************/
	CREATE TABLE #tmp_RelatedAlerts (
		[id] INT identity(1, 1)
		,[AlertNo] VARCHAR(10)
		,[AlertID] INT
		,[WatchlistName] VARCHAR(100)
		,[Priority] VARCHAR(10)
		,[AlType] VARCHAR(200)
		,[SortOrder] INT
		,[WorkFlowStatus] VARCHAR(200)
		,[MergedFlag] VARCHAR(2)
		,[AssignedToUserID] int --#1
		)

	/**************Create a temporary table for CURRENT Related Alerts*******************************/
	CREATE TABLE #tmp_CurrentRelatedAlerts (
		[id] INT identity(1, 1)
		,[AlertID] INT
		)

	/*GET MAJOR AND MINOR DISPOSITION VALUES*/
	--SELECT @WFStatusAssignedAlert = MajorDisposition
	--	,@WFMinorStatusAssignedAlert = MinorDisposition
	--FROM KYP.OIS_ProcessWorkFlow
	--WHERE ProcessName = 'StatusOfAlert'

	--SELECT @WFStatusReadyForAcceptance = MajorDisposition
	--	,@WFMinorStatusReadyForAcceptance = MinorDisposition
	--FROM KYP.OIS_ProcessWorkFlow
	--WHERE ProcessName = 'AcceptRejectAlert'

	--SELECT @WFStatusUnassignedAlert = MajorDisposition
	--	,@WFMinorStatusUnassignedAlert = MinorDisposition
	--FROM KYP.OIS_ProcessWorkFlow
	--WHERE ProcessName = 'UnassignAlert'

	/***************** Insert PartyID and WatchlistName in temporary table having count(PartyID)>1************/
	SET NOCOUNT ON;

	--Changed the Insert Statement for #1
	/*INSERT INTO #tmp_DistinctParty (PartyID)
	SELECT WatchedPartyID
	FROM KYP.MDM_Alert
	WHERE WFStatus IN ( --
			@WFStatusAssignedAlert
			,@WFStatusUnassignedAlert
			,@WFStatusReadyForAcceptance
			)
		AND WFMinorDisposition IN (
			@WFMinorStatusAssignedAlert
			,@WFMinorStatusUnassignedAlert
			,@WFMinorStatusReadyForAcceptance
			)
	AND AssignedToUserID is null --#1
	--AND WatchedPartyID = 23313
	GROUP BY WatchedPartyID
	HAVING COUNT(WatchedPartyID) > 1*/
	
	INSERT INTO #tmp_DistinctParty (PartyID)
	SELECT A.WatchedPartyID
	FROM KYP.MDM_Alert A
	WHERE (A.AssignedToUserID is null 
			OR (A.ActivityStatus<>'Completed'				
				AND Not Exists (Select AR.AlertID From kyp.MDM_AlertResolution AR Where A.Alertid=AR.Alertid) )
			)
	GROUP BY A.WatchedPartyID
	HAVING COUNT(A.WatchedPartyID) > 1	
	Intersect/*#3 PI-716 Start*/
	Select Distinct WatchedPartyID
		From kyp.MDM_Alert
		Where DateInitiated = (Select MAX(DateInitiated)
								From KYP.MDM_Alert);
	/*#3 PI-716 Start*/	
	
	/****** Get the Looping ID*********/
	SELECT @LastID = MAX(ID)
		,@CurrentID = MIN(ID)
	FROM #tmp_DistinctParty

	--ALTER TABLE KYP.MDM_ALERT DISABLE TRIGGER trg_MDM_AlertOnUpdate
	/********************** Get the first PartyID and WatchlistName ***************************/
	SELECT @now = GETDATE()

	/*****************1st Loop for distinct Party ID*******************/
	WHILE (@CurrentID <= @LastID)
	BEGIN
		SELECT @PartyID = [PartyID]
		FROM #tmp_DistinctParty
		WHERE id = @CurrentID

		--PRINT 'PartyID AlertID	: ' + CONVERT(VARCHAR(100), @PartyID)
		TRUNCATE TABLE #tmp_RelatedAlerts

		SET @AssignedAlertCount = 0;
		SET @UnAssignedAlertCount = 0;		

		/**********Insert related alerts in temporary table*********/
		INSERT INTO #tmp_RelatedAlerts (
			AlertNo
			,AlertID
			,WatchlistName
			,Priority
			,AlType
			,SortOrder
			,WorkFlowStatus
			,MergedFlag
			,AssignedToUserID
			)
		SELECT A.AlertNo
			,A.AlertID
			,A.WatchlistName
			,A.Priority
			,A.NPIAlertType
			,NULL
			,A.WFStatus
			,A.IsMerged
			,A.AssignedToUserID
		FROM KYP.MDM_Alert A
		INNER JOIN #tmp_DistinctParty B ON A.WatchedPartyID = B.PartyID	
		--Commented for #1	
			--AND A.WFStatus IN (
			--	@WFStatusAssignedAlert
			--	,@WFStatusUnassignedAlert
			--	,@WFStatusReadyForAcceptance
			--	)
			--AND A.WFMinorDisposition IN (
			--	@WFMinorStatusAssignedAlert
			--	,@WFMinorStatusUnassignedAlert
			--	,@WFMinorStatusReadyForAcceptance
			--	)	
		WHERE A.WatchedPartyID = @PartyID
			--AND A.WFStatus IN (
			--	@WFStatusAssignedAlert
			--	,@WFStatusUnassignedAlert
			--	,@WFStatusReadyForAcceptance
			--	)
			--AND A.WFMinorDisposition IN (
			--	@WFMinorStatusAssignedAlert
			--	,@WFMinorStatusUnassignedAlert
			--	,@WFMinorStatusReadyForAcceptance
			--	)
			AND NOT(A.AssignedToUserID IS NOT NULL	--#1
					AND A.ActivityStatus='Completed') --#1				

		SELECT @CurrentAlertCount = (COUNT(1) - 1)
		FROM #tmp_RelatedAlerts

		/*
		 *	Monitoring 3.4 (MON-3)	- Merge Hierarchy
		 *	Requirement Details		- https://10.31.10.12:8443/browse/MON-3
		 */
		--PRINT 'Total Merged		: ' + CONVERT(VARCHAR(100), @CurrentAlertCount)
		SELECT @AssignedAlertCount = COUNT(AlertID)
		FROM #tmp_RelatedAlerts
		WHERE 
		--Commented for #1
		--WorkFlowStatus IN (
		--		@WFStatusAssignedAlert
		--		,@WFStatusReadyForAcceptance
		--		)
		AssignedToUserID is not null --Added for #1
		
		--Print '@AssignedAlertCount:'+convert(varchar(10),@AssignedAlertCount);
		
		--Added for #1
		SELECT @UnAssignedAlertCount = COUNT(AlertID)
		FROM #tmp_RelatedAlerts
		WHERE AssignedToUserID is null		

		SET @ParentAlertNo = ''
		SET @CurrParentAlertID = 0

		--For checking already assigned alerts
		IF @AssignedAlertCount = 0
		BEGIN
			SET @CheckIfChildAlertsExists = 0
			
			SELECT @CheckIfChildAlertsExists = COUNT(Q.AlertID)
			FROM #tmp_RelatedAlerts Q
			WHERE Q.MergedFlag = 'Y'

			--Print '@CheckIfChildAlertsExists:'+convert(varchar(10),@CheckIfChildAlertsExists);

			--Swapping the parent if unassigned alert is existing
			IF @CheckIfChildAlertsExists <> 0
			BEGIN
				SELECT @ParentAlertNo = Q.AlertNo
					,@CurrParentAlertID = Q.AlertID
				FROM #tmp_RelatedAlerts Q
				WHERE Q.MergedFlag = 'N'
				--Print '@ParentAlertNo,@CurrParentAlertID:'+@ParentAlertNo+','+convert(varchar(15),@CurrParentAlertID)

				DELETE
				FROM KYP.MDM_RelatedAlerts
				WHERE ParentAlertID = @CurrParentAlertID

				UPDATE KYP.MDM_Alert
				SET 
				    Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
					IsMerged = 'N'
					,NoOfMergedAlerts = 0
					--,StatusCodeNumber = 0 --#2
					,GenNo = NULL
					,NextProcessStep = NULL
				From KYP.MDM_Alert 
				WHERE WatchedPartyID = @PartyID
				AND AssignedToUserID IS NULL --#1

				--EXEC [KYP].[p_RemoveProcessForAlert] @ParentAlertNo
			END

			UPDATE X
			SET X.SortOrder = Y.MergeHierarchy
			FROM #tmp_RelatedAlerts X
			INNER JOIN KYP.MDM_MergeHierarchyOrder Y ON X.WatchlistName = Y.WatchlistName
				AND X.Priority = Y.Priority
				AND ISNULL(X.AlType, '') = ISNULL(Y.SubType, '')

			/********* Get the Parent AlertID for Related ALert*************************************/
			SELECT TOP 1 @ParentAlertID = Q.AlertID
			FROM #tmp_RelatedAlerts Q
			ORDER BY Q.SortOrder
				,Q.AlertID ASC

			/*********Get the looping ID***************************/
			SELECT @CurrentAlertID = Q.AlertID
			FROM #tmp_RelatedAlerts Q
			WHERE Q.AlertID NOT IN (@ParentAlertID)
			ORDER BY Q.SortOrder
				,Q.AlertID ASC
				--SELECT * FROM #tmp_RelatedAlerts
				
			SET @UnAssignedAlertCount = @UnAssignedAlertCount-1 --#1
		END
				--Only merging if parent is already assigned
		ELSE
		BEGIN
			SELECT TOP 1 @ParentAlertID = Q.AlertID
			FROM #tmp_RelatedAlerts Q
			Left Join KYP.MDM_AlertResolution AR on Q.AlertID=AR.AlertID
			WHERE AR.AlertID is null
			AND Q.MergedFlag = 'N'
			ORDER BY Q.AlertID ASC

			PRINT @ParentAlertID 
			SELECT @CurrentAlertID = Q.AlertID
			FROM #tmp_RelatedAlerts Q
			WHERE AlertID NOT IN (@ParentAlertID)
			AND AssignedToUserID is null --Added for #1
			ORDER BY Q.AlertID ASC
		END

		INSERT INTO #tmp_CurrentRelatedAlerts (AlertID)
		VALUES (@ParentAlertID)

		SET @ChildAlertCNT = 0
		
		Set @i =0

		--WHILE (@ChildAlertCNT < @CurrentAlertCount) --Commented for #1
		WHILE (@i < @UnAssignedAlertCount)			
		BEGIN
			--PRINT 'Parent AlertID	: ' + CONVERT(VARCHAR(100), @ParentAlertID)
			--PRINT 'Current AlertID	: ' + CONVERT(VARCHAR(100), @CurrentAlertID)
			--PRINT ''
			INSERT INTO #tmp_CurrentRelatedAlerts (AlertID)
			VALUES (@CurrentAlertID)

			DECLARE @ChildAlertCount INT

			SET @ChildAlertCount = 0

			SELECT @ChildAlertCount = count(ChildAlertID)
			FROM [KYP].[MDM_RelatedAlerts]
			WHERE ChildAlertID = @CurrentAlertID
				AND ParentAlertID = @ParentAlertID

			IF @ChildAlertCount = 0
			BEGIN
				/***********Insert related alert*********/
				INSERT INTO [KYP].[MDM_RelatedAlerts] (
					[ChildAlertID]
					,[ParentAlertID]
					,[RelationshipType]
					,[MergedByUserID]
					,[MergedDate]
					,[CreatedDate]
					,[CreatedBy]
					,[IsDeleted]
					)
				VALUES (
					@CurrentAlertID
					,@ParentAlertID
					,'Merged'
					,1
					,@now
					,@now
					,1
					,0
					)

				/*Added for #1 - Increment the ChildAlert Count*/
				SET @ChildAlertCNT = @ChildAlertCNT + 1					
			END

			/**************Update MDM_Alert for IsMerged flag*******************/
			UPDATE x
			SET 
			     x.Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
			     x.IsMerged = y.IsMerged
				,x.AssignedToUserID = y.AssignedToUserID
				,x.AssignedByUserID = y.AssignedByUserID
				,x.AssignedDate = y.AssignedDate
				,x.StatusCodeNumber = case when x.StatusCodeNumber = 0 then y.StatusCodeNumber else x.StatusCodeNumber end --#2
				,x.GenNo = y.GenNo
				,x.WorkFlowStepID = y.WorkFlowStepID
				,x.ActivityStatus = y.ActivityStatus
				,x.Assignee = y.Assignee
				,x.WFMajorDisposition = y.WFMajorDisposition
				,x.WFMinorDisposition = y.WFMinorDisposition
				,x.WFStatus = y.WFStatus
				,x.WFAlertStatus = y.WFAlertStatus
				,x.WFUserID = y.WFUserID
			FROM KYP.MDM_Alert x
			INNER JOIN (
				SELECT 'Y' AS IsMerged
					,AssignedToUserID
					,AssignedByUserID
					,CASE 
						WHEN StatusCodeNumber IN (12, 0)
							THEN AssignedDate
						WHEN StatusCodeNumber <> 12
							THEN GETDATE()
						END AS 'AssignedDate'
					,StatusCodeNumber
					,GenNo
					,WorkFlowStepID
					,ActivityStatus
					,Assignee
					,WFMajorDisposition
					,WFMinorDisposition
					,WFStatus
					,WFAlertStatus
					,WFUserID
				FROM kyp.MDM_Alert
				WHERE AlertID = @ParentAlertID
					AND IsMerged = 'N'
					AND NOT(AssignedToUserID IS NOT NULL	--#1
							AND ActivityStatus='Completed') --#1					
				) y ON x.AlertID = @CurrentAlertID
			WHERE x.IsMerged = 'N'
			AND NOT(x.AssignedToUserID IS NOT NULL	--#1
					AND x.ActivityStatus='Completed') --#1
			
			--Update the parent values to the child
			UPDATE x
			SET 
			     x.Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
			    x.AssignedToUserID = y.AssignedToUserID
				,x.AssignedByUserID = y.AssignedByUserID
				,x.AssignedDate = y.AssignedDate
				,x.StatusCodeNumber = case when x.StatusCodeNumber = 0 then y.StatusCodeNumber else x.StatusCodeNumber end --#2
				,x.GenNo = y.GenNo
				,x.WorkFlowStepID = y.WorkFlowStepID
				,x.ActivityStatus = y.ActivityStatus
				,x.Assignee = y.Assignee
				,x.WFMajorDisposition = y.WFMajorDisposition
				,x.WFMinorDisposition = y.WFMinorDisposition
				,x.WFStatus = y.WFStatus
				,x.WFAlertStatus = y.WFAlertStatus
				,x.WFUserID = y.WFUserID
			FROM KYP.MDM_Alert x
			INNER JOIN (
				SELECT AssignedToUserID
					,AssignedByUserID
					,CASE 
						WHEN StatusCodeNumber IN (12, 0)
							THEN AssignedDate
						WHEN StatusCodeNumber <> 12
							THEN GETDATE()
						END AS 'AssignedDate'
					,StatusCodeNumber
					,GenNo
					,WorkFlowStepID
					,ActivityStatus
					,Assignee
					,WFMajorDisposition
					,WFMinorDisposition
					,WFStatus
					,WFAlertStatus
					,WFUserID
				FROM kyp.MDM_Alert
				WHERE AlertID = @ParentAlertID
					AND IsMerged = 'N'
					AND NOT(AssignedToUserID IS NOT NULL	--#1
							AND ActivityStatus='Completed') --#1					
				) y ON x.AlertID = @CurrentAlertID
			WHERE x.IsMerged = 'Y'
			AND x.AssignedToUserID IS NULL		

			--/********Increment the ChildAlert Count*********************/
			--SET @ChildAlertCNT = @ChildAlertCNT + 1
			
			SET @i = @i+1;
			
			SELECT @CurrentAlertID = A.AlertID
			FROM #tmp_RelatedAlerts A
			WHERE A.AlertID NOT IN (
					SELECT AlertID
					FROM #tmp_CurrentRelatedAlerts
					)
			AND A.AssignedToUserID is null --Added for #1
			ORDER BY A.SortOrder
				,A.AlertID ASC
				--PRINT 'Current AlertID	: ' + CONVERT(VARCHAR(100), @CurrentAlertID)
				--PRINT ''
								
		END

		--#3 PI-716 Start
		IF EXISTS (SELECT AlertID
						FROM KYP.MDM_Alert
						Where AlertID = @CurrParentAlertID
						AND IsMerged = 'Y')
		Begin
	Print 'Inside Loop:'+Convert(varchar(15),@CurrParentAlertID);
			EXEC [KYP].[p_RemoveProcessForAlert] @ParentAlertNo
		End					
		--#3 PI-716 End

		/**********Update MDM_Alert for the NoofMerged for Parent ALert**********/
		UPDATE A
		SET 
		A.Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
		A.NoOfMergedAlerts = A.NoOfMergedAlerts+@ChildAlertCNT
		FROM KYP.MDM_Alert A
		WHERE A.AlertID = @ParentAlertID
		AND NOT(A.AssignedToUserID IS NOT NULL	--#1
				AND A.ActivityStatus='Completed') --#1

		SELECT @CurrentID = MIN(id)
		FROM #tmp_DistinctParty
		WHERE id > @CurrentID
	END

	--Updating the sortorder for all the alerts in the MDM_Alert based on the hierarchy order
	UPDATE X
	SET 
	X.Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
	X.levels = Y.MergeHierarchy
	FROM KYP.MDM_Alert X
	INNER JOIN KYP.MDM_MergeHierarchyOrder Y ON X.WatchlistName = Y.WatchlistName
		AND X.Priority = Y.Priority
		AND ISNULL(X.NPIAlertType, '') = ISNULL(Y.SubType, '')
		AND X.AssignedToUserID is null --#1		


	/*Start for #1 */
	Delete from KYP.MDM_RelatedAlerts
	where ParentAlertID in (Select AlertID
								From KYP.MDM_Alert
								WHERE IsMerged='Y'
								AND NoOfMergedAlerts>0
								AND NOT(AssignedToUserID IS NOT NULL	
										AND ActivityStatus='Completed'));
	
	--Update MDM_Alert for the NoofMerged for Child ALert
	UPDATE KYP.MDM_Alert
	SET 
	Row_Updation_Source='p_LoadDataInMDMRelatedAlerts',
	NoOfMergedAlerts = 0
	WHERE IsMerged='Y'
	AND NoOfMergedAlerts>0
	AND NOT(AssignedToUserID IS NOT NULL	
			AND ActivityStatus='Completed') 
	/*End for #1 */
		
	--ALTER TABLE KYP.MDM_ALERT ENABLE TRIGGER trg_MDM_AlertOnUpdate
END
GO

