









CREATE VIEW [KYPEnrollment].[v_OutEDIMainFile]
AS
SELECT     row_number() OVER (ORDER BY AccountID ASC) AS ID, *
FROM         
(
Select x.AccountID,AccountType,IsDeleted ,AccountUpdatedBy
,RequestType,TransactionType,NPI,OwnerNo,ServiceLocationNo,OwnerEffectiveBeingDate,OwnerEffectiveEndDate,SUBSTRING(LegalName,1,28) AS LegalName,EIN,SSN,PIN
,TINUpdateType,TINUpdateDate
,SUBSTRING(AddressLine1,1,100) AS AddressLine1,SUBSTRING(AddressLine2,1,100) AS AddressLine2,SUBSTRING(City,1,50) AS City
,(SELECT Abreviation FROM [KYP].[LK_Screening] where TypeID=4 and Description=State) AS State,SUBSTRING(ZipPlus4,1,5) AS Zip,SUBSTRING(ZipPlus4,7,10) AS ZipPlus4
,AccountDateCreated,AccountUpdateDate --here 1 field no data leave it blanck

,SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4
,SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8
,ProvLocTypeCd,DBAName --here 1 field no data leave it blanck
,SUBSTRING(SAddressLine1,1,100) AS SAddressLine1,SUBSTRING(SAddressLine2,1,100) AS SAddressLine2,SUBSTRING(SCity,1,50) AS SCity
,(SELECT Abreviation FROM [KYP].[LK_Screening] where TypeID=4 and Description=SState) AS SState,SUBSTRING(SZipPlus4,1,5) AS SZip
,SUBSTRING(SZipPlus4,7,10) AS SZipPlus4,(Select Abreviation from KYP.LK_Screening where TypeID=40 AND Description=County) AS SCountyCode   
,Phone1,NameOfFacAdmin --here 1 field no data leave it blanck
,SUBSTRING(MAddressLine1,1,100) AS MAddressLine1,SUBSTRING(MAddressLine2,1,100) AS MAddressLine2,SUBSTRING(MCity,1,50) AS MCity
,(SELECT Abreviation FROM [KYP].[LK_Screening] where TypeID=4 and Description=MState) AS MState,SUBSTRING(MZipPlus4,1,5) AS MZip,SUBSTRING(MZipPlus4,7,10) AS MZipPlus4  
,OutOfStateInd,ProviderTypeCode

,AccStatusValue1,CONVERT(datetime,AccEffectiveBeginDate1) AS AccEffectiveBeginDate1 ,CONVERT(datetime,AccEffectiveEndDate1) AS AccEffectiveEndDate1 
,AccStatusValue2,CONVERT(datetime,AccEffectiveBeginDate1) AS AccEffectiveBeginDate2 ,CONVERT(datetime,AccEffectiveEndDate2) AS AccEffectiveEndDate2
,AccStatusValue3,CONVERT(datetime,AccEffectiveBeginDate1) AS AccEffectiveBeginDate3 ,CONVERT(datetime,AccEffectiveEndDate3) AS AccEffectiveEndDate3
,AccStatusValue4,CONVERT(datetime,AccEffectiveBeginDate1) AS AccEffectiveBeginDate4 ,CONVERT(datetime,AccEffectiveEndDate4) AS AccEffectiveEndDate4
,AccStatusValue5,CONVERT(datetime,AccEffectiveBeginDate1) AS AccEffectiveBeginDate5 ,CONVERT(datetime,AccEffectiveEndDate5) AS AccEffectiveEndDate5

,CCodeIdentification1,CONVERT(datetime,CCodeDateEffDate1) AS CCodeDateEffDate1 ,CONVERT(datetime,CCodeDateExpDate1) AS CCodeDateExpDate1
,CCodeIdentification2,CONVERT(datetime,CCodeDateEffDate2) AS CCodeDateEffDate2 ,CONVERT(datetime,CCodeDateExpDate2) AS CCodeDateExpDate2
,CCodeIdentification3,CONVERT(datetime,CCodeDateEffDate3) AS CCodeDateEffDate3 ,CONVERT(datetime,CCodeDateExpDate3) AS CCodeDateExpDate3
,CCodeIdentification4,CONVERT(datetime,CCodeDateEffDate4) AS CCodeDateEffDate4 ,CONVERT(datetime,CCodeDateExpDate4) AS CCodeDateExpDate4
,CCodeIdentification5,CONVERT(datetime,CCodeDateEffDate5) AS CCodeDateEffDate5 ,CONVERT(datetime,CCodeDateExpDate5) AS CCodeDateExpDate5
,CCodeIdentification6,CONVERT(datetime,CCodeDateEffDate6) AS CCodeDateEffDate6 ,CONVERT(datetime,CCodeDateExpDate6) AS CCodeDateExpDate6
,CCodeIdentification7,CONVERT(datetime,CCodeDateEffDate7) AS CCodeDateEffDate7 ,CONVERT(datetime,CCodeDateExpDate7) AS CCodeDateExpDate7
,CCodeIdentification8,CONVERT(datetime,CCodeDateEffDate8) AS CCodeDateEffDate8 ,CONVERT(datetime,CCodeDateExpDate8) AS CCodeDateExpDate8
,CCodeIdentification9,CONVERT(datetime,CCodeDateEffDate9) AS CCodeDateEffDate9 ,CONVERT(datetime,CCodeDateExpDate9) AS CCodeDateExpDate9
,CCodeIdentification10,CONVERT(datetime,CCodeDateEffDate10) AS CCodeDateEffDate10 ,CONVERT(datetime,CCodeDateExpDate10) AS CCodeDateExpDate10
 
,CCodeIdentification11,CONVERT(datetime,CCodeDateEffDate11) AS CCodeDateEffDate11 ,CONVERT(datetime,CCodeDateExpDate11) AS CCodeDateExpDate11
,CCodeIdentification12,CONVERT(datetime,CCodeDateEffDate12) AS CCodeDateEffDate12 ,CONVERT(datetime,CCodeDateExpDate12) AS CCodeDateExpDate12
,CCodeIdentification13,CONVERT(datetime,CCodeDateEffDate13) AS CCodeDateEffDate13 ,CONVERT(datetime,CCodeDateExpDate13) AS CCodeDateExpDate13
,CCodeIdentification14,CONVERT(datetime,CCodeDateEffDate14) AS CCodeDateEffDate14 ,CONVERT(datetime,CCodeDateExpDate14) AS CCodeDateExpDate14
,CCodeIdentification15,CONVERT(datetime,CCodeDateEffDate15) AS CCodeDateEffDate15 ,CONVERT(datetime,CCodeDateExpDate15) AS CCodeDateExpDate15
,CCodeIdentification16,CONVERT(datetime,CCodeDateEffDate16) AS CCodeDateEffDate16 ,CONVERT(datetime,CCodeDateExpDate16) AS CCodeDateExpDate16
,CCodeIdentification17,CONVERT(datetime,CCodeDateEffDate17) AS CCodeDateEffDate17 ,CONVERT(datetime,CCodeDateExpDate17) AS CCodeDateExpDate17
,CCodeIdentification18,CONVERT(datetime,CCodeDateEffDate18) AS CCodeDateEffDate18 ,CONVERT(datetime,CCodeDateExpDate18) AS CCodeDateExpDate18
,CCodeIdentification19,CONVERT(datetime,CCodeDateEffDate19) AS CCodeDateEffDate19 ,CONVERT(datetime,CCodeDateExpDate19) AS CCodeDateExpDate19
,CCodeIdentification20,CONVERT(datetime,CCodeDateEffDate20) AS CCodeDateEffDate20 ,CONVERT(datetime,CCodeDateExpDate20) AS CCodeDateExpDate20
 
,Speciality_Code1,CONVERT(datetime,SpecCertDate1) AS SpecCertDate1
,Speciality_Code2,CONVERT(datetime,SpecCertDate2) AS SpecCertDate2
,Speciality_Code3,CONVERT(datetime,SpecCertDate3) AS SpecCertDate3 
 
,SpecProcTypeCode,IMDFacilType
,PracTypeCode,ApplicationDate,RejectReasonCode,ExceptionIndicator,ProvisionalCode,ProvisionalCodeDate,ReenrollmentIndicator,ReenrollmentDate 
,LicenseNumber,LicenseBoardCode,License_EffectiveDate,CliaNumber,CliaCertificateType,ProvTypeUpdatedDate 
 
from( 
select Case When(CONVERT(VARCHAR, A.DateCreated , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)) then 'ADDP' else 'UPDP' END AS RequestType 
,'M' AS TransactionType	
 -- Field of pADM_Account 
 ,A.NPI,A.OwnerNo,A.ServiceLocationNo,A.LegalName,A.PIN,A.AccountID,A.DateCreated AS AccountDateCreated,A.AccountUpdateDate,A.IsDeleted ,A.AccountUpdatedBy--,A.LastUpdatedBy
 ,A.DBAName,A.StatusAcc,A.ApplicationDate,A.ReenrollmentIndicator,A.EIN,A.SSN,A.ProviderTypeCode,A.AccountType,'Column Not Found' AS ReenrollmentDate,'Column Not Found' AS ProvTypeUpdatedDate
 ,'Column Not Found' AS ProvLocTypeCd 
  -- Field of pAccount_Owner
 ,B.EffectiveBeingDate  AS OwnerEffectiveBeingDate 
 ,B.EffectiveEndDate AS OwnerEffectiveEndDate --OR Case when(B.EffectiveEndDate is NULL) then (Case When(A.LegacyAccountNo is NULL) then NULL Else '2069-12-31 00:00:00' END) Else B.EffectiveEndDate END  AS OwnerEffectiveEndDate
 -- Field of EDM_AccountInternalUse
 ,C.TINUpdateType,C.TINUpdateDate,C.OutOfStateInd,C.SpecProcTypeCode,C.ProvisionalCode,C.ProvisionalCodeDate,C.RejectReasonCode,C.ExceptionIndicator ,'Column Not Found' AS NameOfFacAdmin,'Column Not Found' AS IMDFacilType
 -- Field of pAccount_PDM_Address 
 ,D.AddressLine1,D.AddressLine2,D.City,D.State,D.ZipPlus4  
 ,E.AddressLine1 AS SAddressLine1,E.AddressLine2 AS SAddressLine2,E.City AS SCity,E.State AS SState,E.ZipPlus4 AS SZipPlus4,E.County
 ,F.AddressLine1 AS MAddressLine1,F.AddressLine2 AS MAddressLine2,F.City AS MCity,F.State AS MState,F.ZipPlus4 AS MZipPlus4
 ,(Select Phone1 from KYPEnrollment.pAccount_PDM_Location where Type='Servicing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1) AS Phone1
 
 -- Field of pAccount_PDM_Speciality
 ,H.Speciality_Code,H.SpecCertDate
  -- Field of pAccount_PDM_EntityType
 ,I.PracTypeCode
  -- Field of pAccount_PDM_Number
 ,J.LicenseBoardCode,J.Number AS LicenseNumber,J.EffectiveDate AS License_EffectiveDate
  -- Field of pAccount_PDM_Clia
 ,K.CliaNumber,K.CertificateType as CliaCertificateType
  
 --,K.DateCreated AS OwnerRoleDateCreated,K.DateDeleted AS OwnerRoleDateDeleted,K.DateModified as OwnerDateModified
 --,L.CodeIdentification,L.CodeDateEffDate,L.CodeDateExpDate
 --,G.DateCreated as PersonDateCreated,G.DateModified as PersonDateModified,G.DoB as PersonDOB
 

 
from KYPEnrollment.pADM_Account A 
left outer join KYPEnrollment.pAccount_Owner B on A.AccountID=B.AccountID AND A.OwnerNo=B.OwnerNo AND B.CurrentRecordFlag=1

left outer join KYPEnrollment.EDM_AccountInternalUse C on C.AccountInternalUseID=(select AccountInternalUseID from KYPEnrollment.EDM_AccountInternalUse where AccountID=A.AccountID and CurrentRecordFlag = 1 )
--This is for Pay-to Address Details
left outer join 
(select D.AddressLine1,D.AddressLine2,D.City,D.State,D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Pay-to'
	 and X.CurrentRecordFlag=1)D
	 on d.PartyID = a.PartyID
--This is for Service Address Details
left outer join 
(select D.AddressLine1,D.AddressLine2,D.City,D.State,D.ZipPlus4,x.PartyID,x.Phone1,d.County  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)E
	 on E.PartyID = a.PartyID
--This is for Mailing Address Details
left outer join(select D.AddressLine1,D.AddressLine2,D.City,D.State,D.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = a.PartyID
left outer join KYPEnrollment.pAccount_PDM_Speciality H on H.PartyID=A.PartyID AND H.IsPrimary=NULL AND H.CurrentRecordFlag=1

left outer join KYPEnrollment.pAccount_PDM_EntityType I on I.PartyID=A.PartyID AND H.IsPrimary=NULL AND I.CurrentRecordFlag=1
left outer join KYPEnrollment.pAccount_PDM_Number J on J.PartyID=A.PartyID AND J.Type='Professional License' AND J.CurrentRecordFlag=1
left outer join KYPEnrollment.pAccount_PDM_Clia K on K.PartyID=A.PartyID AND K.CurrentRecordFlag=1

where A.IsDeleted=0  AND A.AccountType NOT IN ('NMP','ORP') AND (A.AccountUpdatedBy != 'M' or A.AccountUpdatedBy is not null)
		AND CONVERT(VARCHAR,A.LastActionDate, 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)
--		
) x  
left join 	 
  ( select AccountId, 
 SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
 SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,
 AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
 ,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
 from 
(   		
	-- DH-SANCTION-TXT-2019 occurs 8 times
     -- 8 Occurance for 'CodeIdentification' from "KYPEnrollment.EDM_AccountInternalMany" table where CodeType = 'Sanction'
     SELECT C.AccountId, CONVERT(varchar(20),CodeIdentification) as CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
    inner join KYPEnrollment.EDM_AccountInternalUse C 
    on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
    
    UNION ALL
    
    SELECT AccS.AccountId,CONVERT(varchar(20), AccS.StatusValue)as StatusValue
    ,'AccStatusValue'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by AccS.AccountStatusId desc  ) ) seq
    from KYPEnrollment.pADM_AccountStatus AccS 
                
	 
    UNION ALL	
    SELECT AccS.AccountId,CONVERT(varchar(20), AccS.EffectiveBeginDate)
    ,'AccEffectiveBeginDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by  AccS.AccountStatusId desc )) seq
    from KYPEnrollment.pADM_AccountStatus AccS 	
		
	
	UNION ALL  -- 3 Occurance for 'Speciality_Code' from "KYPEnrollment.pAccount_PDM_Speciality" table
	SELECT A.Accountid,CONVERT(varchar(20), P.Speciality_Code)
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc  ) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID  
	
	UNION ALL -- 3 Occurance for 'SpecCertDate' from "KYPEnrollment.pAccount_PDM_Speciality" table
     SELECT A.Accountid,CONVERT(varchar(20), P.SpecCertDate)
	,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc) ) seq
	FROM KYPEnrollment.pAccount_PDM_Speciality P 
	inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID  

			-- DH-CATSERV-DATA occurs 20 times
	UNION ALL	-- 20 Occurance for 'CodeIdentification' from "KYPEnrollment.AccountInternalUseID" table where CodeType = 'Category'
	SELECT C.AccountId,CONVERT(varchar(20),CodeIdentification)
	,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
                
     UNION ALL	-- 20 Occurance for 'CodeDateEffDate' from "KYPEnrollment.AccountInternalUseID" table where CodeType = 'Category'
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateEffDate)
	,'CCodeDateEffDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
	
    UNION ALL	-- 20 Occurance for 'CodeDateExpDate' from "KYPEnrollment.AccountInternalUseID" table where CodeType = 'Category'
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateExpDate)
	,'CCodeDateExpDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
	)ML(AccountId,StatusValue,seq)
PIVOT (max(ml.StatusValue) 
FOR ml.seq IN (
SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8, 
AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
)) pvt   )y on x.AccountID= y.AccountId
     

-------------------------------------------------------- Close of Main PMF Record -----------------------------------------------------------------------------------------------------------------------


)z


GO

