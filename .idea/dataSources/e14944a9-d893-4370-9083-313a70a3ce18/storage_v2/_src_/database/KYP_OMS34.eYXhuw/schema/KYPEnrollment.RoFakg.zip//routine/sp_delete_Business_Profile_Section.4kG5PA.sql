-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Business_Profile_Section] 
@new_Account_Id int

AS
BEGIN
Declare @org int,@ent int,@numb int
Declare @npi_Type varchar(100),@new_Address_Id int,@npi varchar(10),@provider_type_code varchar(10),
@account_number varchar(10),@accountType varchar(10),@application_Id INT,@application_type VARCHAR(40)
	SET NOCOUNT ON;

  IF EXISTS (SELECT a.AccountID FROM KYPEnrollment.pADM_Account a where a.AccountID =@new_Account_Id AND a.PackageName='F_OOS_OE')
    BEGIN
      EXEC [KYPEnrollment].[sp_delete_Business_Profile_SubForm] @new_Account_Id
    END
  ELSE
    BEGIN
      select @org = o.OrgID from KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Organization] o ON a.PartyID=o.PartyID where a.IsDeleted=0 and o.CurrentRecordFlag=1 and a.AccountID=@new_Account_Id
	    EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Organization','OrgID',@org

		select @ent = e.EntityTypeID from KYPEnrollment.pADM_Account acc inner join [KYPEnrollment].[pAccount_PDM_EntityType] e on acc.PartyID=e.PartyID where AccountID=@new_Account_Id and e.CurrentRecordFlag=1
		EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_EntityType','EntityTypeID',@ent

	    select @numb = o.NumberID from KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Number] o ON a.PartyID=o.PartyID where a.IsDeleted=0 and o.CurrentRecordFlag=1	and o.IsDeleted =0  and a.AccountID=@new_Account_Id
	    EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Number','NumberID',@numb
  END

END


GO

