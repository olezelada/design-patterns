
-- =============================================
-- Author:  <Lacunza,Giresse>
-- Create date: <2017-19-09>
-- Description: <Description, New Medical Transportation Package>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_FSP_MDT_SP] (
   @new_Account_Id         INT,
   @new_Party_Id           INT,
   @party_Id               INT,
   @last_Action_User_ID    VARCHAR (100),
   @application_no         VARCHAR (10),
   @application_Id         INT,
   @application_type 	   VARCHAR(40),
   @provider_type_code     varchar(10))




AS
BEGIN
   DECLARE
      @new_Address_Id            INT,
      @new_person_id             INT,
      @npi_Type                  VARCHAR (20),
      @npi                       VARCHAR (10),
      @account_number            VARCHAR (20),
      @package					 varchar(10),
      @isGroup BIT ;

      EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,
                                                        @new_Account_Id,
                                                        @new_Party_Id,
                                                        @last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';

	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id
   select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id
   SELECT @npi_Type = NPIType,@account_number = AccountNumber, @npi = NPI, @package = PackageName
   FROM [KYPEnrollment].[pADM_Account]
   WHERE AccountID = @new_Account_Id and IsDeleted=0

   --Social Form: Profile Information:

   --Personal Information
  	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Person] @new_Party_Id,
	                                                       @party_Id,
	                                                       @last_action_user_id,
	                                                       'C';

	EXEC [KYPEnrollment].[sp_Copy_Document] @new_Party_Id,
	                                          @party_Id,
	                                          @last_action_user_id;

    EXEC [KYPEnrollment].[sp_Copy_AllOtherNames]	@party_Id,
                                                  @last_Action_User_ID,
                                                  @new_Party_Id;



   --Residential Address
   EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id,
                                          @party_Id,
                                          'Individual Profile',
                                          @last_Action_User_ID;

   --Social Form: Business Information:

	 EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Main_Info] @new_Account_Id,
	                                                            @party_Id,
	                                                            @last_Action_User_ID,
	                                                            NULL;


	 EXEC [KYPEnrollment].[sp_Copy_GeoLocations]	@new_Account_Id,
	                                              @new_Party_Id,
	                                              @party_Id,
	                                              @last_Action_User_ID;

   --Logistics
   --Hours of Operation
   --Mode of Transportation

   EXEC [KYPEnrollment].[sp_Copy_All_transport] 	@new_Account_Id,
													@new_Party_Id,
													@party_Id,
													@application_Id,
													@application_type,
													@last_Action_User_ID,
													@provider_type_code;
													
													
   EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id,
											 @party_Id,
											 @last_Action_User_ID,
											  NULL;

   EXEC [KYPEnrollment].[sp_Copy_Business_Hours_CA] @new_Party_Id,@party_Id;
   
   EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id,@party_Id,@last_Action_User_ID;



	--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
	IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
	BEGIN
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_Party_Id, null,@application_Id,@party_Id, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
		
	END

   --Name address update

   
   EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, /*@new_org_id*/
                                                @new_person_id,
                                                @new_Address_Id,
                                                @npi_Type,
                                                @last_Action_User_ID,
                                                @npi,
                                                @new_Party_Id,
                                                @party_Id,
                                                0,
                                                @provider_type_code,
                                                @account_number,
                                                NULL,
                                                'F',
                                                @application_Id,
                                                @isGroup,
                                                @application_type;

END


GO

