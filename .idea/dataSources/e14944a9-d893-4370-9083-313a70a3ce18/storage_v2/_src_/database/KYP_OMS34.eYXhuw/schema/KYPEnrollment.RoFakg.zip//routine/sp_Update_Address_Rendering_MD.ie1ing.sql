
/* ==========================================================
-- Author:  <NRojas>
-- PROCEDURE: create address and location for Rendering aplication.
-- PARAMETERS:
-- @new_Party_Id : partyID to new Account that will be create.
-- @party_Id : partyID Application that will be Account.
-- @address_type : this is the type locacion, it can be Null.
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/


CREATE PROCEDURE [KYPEnrollment].[sp_Update_Address_Rendering_MD]
   @party_account_id INT, @last_action_user_id VARCHAR (100)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @date_created                 SMALLDATETIME,
      @AddressType                  VARCHAR (30),
      @AddressLine1                 VARCHAR (250),
      @AddressLine2                 VARCHAR (50),
      @County                       VARCHAR (25),
      @City                         VARCHAR (25),
      @Zip                          VARCHAR (5),
      @ZipPlus4                     VARCHAR (50),
      @State                        VARCHAR (40),
      @Country                      VARCHAR (40),
      @Latitude                     VARCHAR (8),
      @Longitude                    VARCHAR (7),
      @GeographicArea               VARCHAR (50),
      @ServiceLocationNo            VARCHAR (3),
      @LastAction                   VARCHAR (20),
      @LastActionDate               SMALLDATETIME,
      @LastActionUserID             VARCHAR (100),
      @LastActionReason             VARCHAR (100),
      @LastActionComments           VARCHAR (255),
      @LastActionApprovedByUsedID   VARCHAR (100),
      @CurrentRecordFlag            BIT,
      @TempAddressID                VARCHAR (30),
      @AdaAccessible                BIT,
      @TtyCapacity                  BIT,
      @TtyNumber                    VARCHAR (15);

   SET @date_created = CURRENT_TIMESTAMP;

   SELECT @AddressType = AddressType,
          @AddressLine1 = AddressLine1,
          @AddressLine2 = AddressLine2,
          @County = County,
          @City = City,
          @Zip = Zip,
          @ZipPlus4 = ZipPlus4,
          @State = State,
          @Country = Country,
          @Latitude = Latitude,
          @Longitude = Longitude,
          @GeographicArea = GeographicArea,
          @ServiceLocationNo = ServiceLocationNo,
          @LastAction = LastAction,
          @LastActionDate = LastActionDate,
          @LastActionUserID = LastActionUserID,
          @LastActionReason = LastActionReason,
          @LastActionComments = LastActionComments,
          @LastActionApprovedByUsedID = LastActionApprovedByUsedID,
          @CurrentRecordFlag = CurrentRecordFlag,
          @TempAddressID = TempAddressID,
          @AdaAccessible = AdaAccessible,
          @TtyCapacity = TtyCapacity,
          @TtyNumber = TtyNumber
     FROM KYPEnrollment.pAccount_PDM_Address
    WHERE AddressID IN
             (SELECT AddressID
                FROM KYPEnrollment.pAccount_PDM_Location
               WHERE     PartyID = @party_account_id
                     AND type = 'Individual Profile')

   UPDATE KYPEnrollment.pAccount_PDM_Address
      SET AddressType = @AddressType,
          AddressLine1 = @AddressLine1,
          AddressLine2 = @AddressLine2,
          County = @County,
          City = @City,
          Zip = @Zip,
          ZipPlus4 = @ZipPlus4,
          State = @State,
          Country = @Country,
          Latitude = @Latitude,
          Longitude = @Longitude,
          GeographicArea = @GeographicArea,
          ServiceLocationNo = @ServiceLocationNo,
          LastAction = @LastAction,
          LastActionDate = @LastActionDate,
          LastActionUserID = @LastActionUserID,
          LastActionReason = @LastActionReason,
          LastActionComments = @LastActionComments,
          LastActionApprovedByUsedID = @LastActionApprovedByUsedID,
          CurrentRecordFlag = @CurrentRecordFlag,
          TempAddressID = @TempAddressID,
          AdaAccessible = @AdaAccessible,
          TtyCapacity = @TtyCapacity,
          TtyNumber = @TtyNumber
    WHERE AddressID IN
             (SELECT AddressID
                FROM KYPEnrollment.pAccount_PDM_Location
               WHERE     PartyID = @party_account_id
                     AND type <> 'Individual Profile')
END


GO

