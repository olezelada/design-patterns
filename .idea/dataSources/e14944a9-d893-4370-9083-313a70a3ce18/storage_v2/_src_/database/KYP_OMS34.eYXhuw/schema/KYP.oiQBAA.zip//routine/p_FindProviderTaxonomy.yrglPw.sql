






-- =============================================
-- Author:  Sheetal
-- Create date: Aug 06 2012
-- Description: Find the MCAREID of Party if received
-- =============================================
CREATE PROCEDURE [KYP].[p_FindProviderTaxonomy]
 -- Add the parameters for the stored procedure here
 @PartyID int
 ,@Taxonomy_Code varchar(20)
 ,@CurrentModule INT
AS
BEGIN
 SET NOCOUNT ON;
 
 declare @TaxonomyID int
 /********Get the SecNPI ID based on PartyID**********/
 if exists (select 1 from KYP.PDM_Taxonomy B where B.PartyID = @PartyID and B.Taxonomy = @Taxonomy_Code)
 begin
	 select @TaxonomyID = B.TaxonomyID 
	 from  KYP.PDM_Taxonomy B where B.PartyID = @PartyID 
	 and B.Taxonomy = @Taxonomy_Code  
 
    return @TaxonomyID 
 end 
 else 
 return -1    
END


GO

