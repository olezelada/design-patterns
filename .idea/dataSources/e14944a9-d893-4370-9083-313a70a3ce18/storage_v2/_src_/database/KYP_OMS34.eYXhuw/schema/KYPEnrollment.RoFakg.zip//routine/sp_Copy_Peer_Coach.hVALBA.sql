-- =============================================
-- Author:		<Author, hbustamante>
-- Create date: <02/27/2019>
-- Description:	<this procedure copy all peer coaches records from app into account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Peer_Coach]
	-- Add the parameters for the stored procedure here
	@party_account_id INT
	, @party_app_id INT
	, @last_Action_User_ID VARCHAR(100)
	, @account_Id INT
AS
BEGIN

	DECLARE @tot_Coach INT, @count_Coach INT, @coach_id INT, @coach_party_id INT, @new_party_coach INT;
	DECLARE @temp_coach TABLE (pk_coach INT IDENTITY (1,1), coach_Id INT, partyId INT );

	SET NOCOUNT ON;

	INSERT INTO @temp_coach (coach_Id, partyId)
	SELECT p.PersonID , p.PartyID
	FROM KYPPORTAL.PortalKYP.pPDM_Person p
		INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party par ON par.PartyID = p.PartyID
	WHERE par.ParentPartyID = @party_app_id
		AND par.Type = 'PeerCoach'
		--AND par.TargetPath NOT LIKE '%pAccount_PDM%'
		AND par.IsDeleted = 0
		AND p.Deleted = 0

	SELECT @tot_Coach = MAX(pk_coach) FROM @temp_coach
	SET @count_Coach = 1;

	WHILE @count_Coach <= @tot_Coach
	BEGIN
		SELECT @coach_id = coach_Id
			, @coach_party_id = partyId
		FROM @temp_coach WHERE pk_coach = @count_Coach
		-- Creating new party for coach in account
		EXEC @new_party_coach = [KYPEnrollment].[sp_Copy_Party] @coach_party_id
															, @party_account_id
															, @account_Id
															, @last_action_user_id;

		-- Creating new coach (Person) in account
		EXEC [KYPEnrollment].[sp_Copy_Person] @new_party_coach
											  , @coach_party_id
											  , @last_action_user_id
											  , 'C';
		SET @count_Coach = @count_Coach + 1;

	END
END
GO

