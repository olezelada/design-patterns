



CREATE PROCEDURE [KYP].[p_FindFacilityParty]
		@CaseID bigint,
		@LocationID bigint,
		@PartyType varchar(250)
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @FacilityId int;
	
	-- CaseID,LocationNo,PartyType
	
	SELECT @FacilityId = ISNULL(ID,0) FROM KYP.PDM_AdditionalParties WHERE CaseID = @CaseID AND LocationNo = @LocationID AND PartyType = @PartyType;
	
	return @FacilityId;
	
END


GO

