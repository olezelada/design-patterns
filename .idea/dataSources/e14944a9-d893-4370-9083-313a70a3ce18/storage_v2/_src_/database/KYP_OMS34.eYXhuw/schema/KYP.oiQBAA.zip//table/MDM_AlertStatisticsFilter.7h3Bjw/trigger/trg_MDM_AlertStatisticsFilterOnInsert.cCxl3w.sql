

CREATE TRIGGER [KYP].[trg_MDM_AlertStatisticsFilterOnInsert]
   ON  [KYP].[MDM_AlertStatisticsFilter] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare
   @ID bigint,
   @FromDate datetime,
   @ToDate datetime,
   @FilterType varchar(50),
   @FilterSubType varchar(50);
   
select	
		@ID = ID ,
		@FromDate= FromDate ,
		@ToDate= ToDate, 
		@FilterType= FilterType ,
		@FilterSubType= FilterSubType 
from	Inserted   

    -- Insert statements for trigger here
 --execute KYP.p_insertMDM_AlertStatisticsReport @ID,@FromDate,@ToDate,@FilterType,@FilterSubType
 
begin   
SET NOCOUNT ON;
declare 
  @PID int,
  @openAlrtCount int,
  @closeAlrtCount int,
  @usertemp varchar(20),
  
  @UniqueIdValue bigint,
  @UserIdValue varchar(50),
  @TotalAlertsValue int,
  @CountOfOpenAlertsValue int,
  @CountOfClosedAlertsValue int,
  @FalsePositiveAlertsValue int,
  @IgnoredAlertsValue int,
  @ConfirmedAlertsValue int,
  @UnconfirmedAlertsValue int,
  @FalsePositivePercentageValue int,
  @IgnoredPercentageValue int,
  @ConfirmedPercentageValue int,
  @UnconfirmedPercentageValue int,
  @AverageCaseAgeValue int,
  @AverageOpenCaseAgeValue int,
  @AverageCloseCaseAgeValue int,
  @WatchlistValue varchar(50),
  @ProviderTypeValue varchar(200),
  @Months varchar(50),
  @AccountsImpactedValue int;
  set @ToDate=DATEADD(DAY,1,@ToDate);
  
 ----------------------------------------------------------------------------------------------
  -----Begin ---- 1) FilterType='PerformanceSummary' is used to get the Total No of alerts, Total Confirmed Alerts and Accounts Impacted
  --Filter Subtype - ALL - when current user is having supervisor role then count alerts assigned to all users 
  -- Filter subtype - !=ALL - when user not having supervisor role then count the alerts which are assigned to current user
  IF @FilterType='PerformanceSummary'
 BEGIN
 --Begin--------------------------1)When user click on drill down functionality and clicked on CloseAlert --------
IF @FilterSubType='ALL'
 BEGIN
insert into KYP.MDM_AlertStatisticsReport(UniqueId,TotalAlert,ConfirmedAlerts,AccountsImpacted)
select @ID,(select count(*) from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and wfstatus = 'Completed'),(select COUNT(*) from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and MatchStatusIndicator='C' and wfstatus = 'Completed'),(select COUNT(distinct providerid) from KYP.MDM_ImpProviders where Impacted='true' and isdeleted='false' and AlertID in(select alertid from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and wfstatus = 'Completed'))
  END
IF @FilterSubType<>'ALL'
 BEGIN
insert into KYP.MDM_AlertStatisticsReport(UniqueId,TotalAlert,ConfirmedAlerts,AccountsImpacted)
select @ID,(select count(*) from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and wfstatus = 'Completed' and AssignedToUserID in (select PersonID from KYP.OIS_User where UserID=@FilterSubType)),(select COUNT(*) from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and MatchStatusIndicator='C' and wfstatus = 'Completed' and AssignedToUserID in (select PersonID from KYP.OIS_User where UserID=@FilterSubType)),(select COUNT(distinct providerid) from KYP.MDM_ImpProviders where Impacted='true' and isdeleted='false' and AlertID in(select alertid from KYP.MDM_Alert where isMerged='N' and isdeleted='false' and wfstatus = 'Completed' and AssignedToUserID in (select PersonID from KYP.OIS_User where UserID=@FilterSubType)))
  END

 END
  ----------------------------------- View when FilterType - User -------------------------------
IF @FilterType='User'
 BEGIN

-------------------------------------------Change1---------------------------------------------------------------
 --Begin--------------------------1)When user click on drill down functionality and clicked on CloseAlert --------
IF @FilterSubType='CloseAlert'
  BEGIN
  WITH Alertstatistics as
(
	 select AssignedtoUserId,
			count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,
			COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,
			COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
			COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
			COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
			COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus,
			0 as OpenAlertAge1
	from KYP.MDM_Alert where WFStatus='Completed' AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' 
	AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL group by AssignedToUserID 
),
CloseAlertAge as
(
	select	assignedtoUserId,SUM(datediff(dd,AssignedDate,DateClosed))/count(*) as ClosedAlertAge1 
	from KYP.MDM_Alert where WFStatus='Completed' AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' 
	AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL and 
	DateClosed is not null group by assignedtoUserId
)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge)
select @ID,(select FullName from KYP.OIS_User where PersonID=A.AssignedToUserId AND (UserID <> 'supervisor' AND UserID <> 'reviewer')),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(A.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(A.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0) 
from Alertstatistics A
Left join CloseAlertAge C ON A.AssignedtoUserId=C.assignedtoUserId 
    
 END
---End-----------------------1)When user click on drill down functionality and clicked on CloseAlert --------


----- Begin ----------2) When user click on drill down functionality and clicked on Open alert count -------------------
IF @FilterSubType IS NOT NULL AND @FilterSubType<>'CloseAlert' AND @FilterSubType<>'F' AND @FilterSubType<>'U' AND @FilterSubType<>'I' AND @FilterSubType<>'C'
 BEGIN
   WITH Alertstatistics as
(
select AssignedtoUserId,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,
		COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus from KYP.MDM_Alert where WFStatus<>'Completed' AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL group by AssignedToUserID
 ),     
 OpenAlertAge as
 (select assignedtoUserId,SUM(datediff(dd,AssignedDate,getdate()))/count(*) as OpenAlertAge1 from KYP.MDM_Alert where WFStatus<>'Completed' AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL group by assignedtoUserId),
 CloseAlertAge as
 (select assignedtoUserId,0 as ClosedAlertAge1 from KYP.MDM_Alert where WFStatus<>'Completed' AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL and DateClosed is not null group by assignedtoUserId)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge)
select @ID,(select FullName from KYP.OIS_User where PersonID=A.AssignedToUserId AND (UserID <> 'supervisor' AND UserID <> 'reviewer')),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0) from Alertstatistics A
  left join
  OpenAlertAge B ON A.AssignedtoUserId=B.assignedtoUserId
    left join 
   CloseAlertAge C ON A.AssignedtoUserId=C.assignedtoUserId 
  
 END
------End---------------2) When user click on drill down functionality and clicked on Open alert count -------------------

----- Begin ----------3) When user click on drill down functionality and clicked on any activity status -------------------
IF @FilterSubType='F' OR @FilterSubType='U' OR @FilterSubType='I' OR @FilterSubType='C'
 BEGIN
   WITH Alertstatistics as
(
select AssignedtoUserId,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' 
      AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL group by AssignedToUserID
 ),     
 OpenAlertAge as
 (select assignedtoUserId,SUM(datediff(dd,AssignedDate,getdate()))/count(*) as OpenAlertAge1 
 from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' 
 AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL AND WFStatus<>'Completed' group by assignedtoUserId),
 CloseAlertAge as
 (select assignedtoUserId,SUM(datediff(dd,AssignedDate,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' 
 AND ISNULL(IsDeleted, 0) = 0 AND AssignedToUserID IS NOT NULL AND WFStatus='Completed' and DateClosed is not null group by assignedtoUserId)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge)
select @ID,(select FullName from KYP.OIS_User where PersonID=A.AssignedToUserId AND (UserID <> 'supervisor' AND UserID <> 'reviewer')),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0) from Alertstatistics A
  left join
  OpenAlertAge B ON A.AssignedtoUserId=B.assignedtoUserId
    left join 
   CloseAlertAge C ON A.AssignedtoUserId=C.assignedtoUserId 
  
 END
----- End ----------3) When user click on drill down functionality and clicked on any activity status -------------------

----- Begin ----------4)For getting all count without filter -------------------
 IF @FilterSubType IS NULL
 BEGIN
WITH Alertstatistics as
(
select AssignedtoUserId,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
      AND AssignedToUserID IS NOT NULL group by AssignedToUserID
 ),     
 OpenAlertAge as
 (select assignedtoUserId,SUM(datediff(dd,AssignedDate,getdate()))/count(*) as OpenAlertAge1 
 from KYP.MDM_Alert where (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 AND AssignedToUserID IS NOT NULL AND WFStatus<>'Completed' group by assignedtoUserId),
 CloseAlertAge as
 (select assignedtoUserId,SUM(datediff(dd,AssignedDate,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where (AssignedDate between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 AND AssignedToUserID IS NOT NULL AND WFStatus='Completed' and DateClosed is not null group by assignedtoUserId)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge)
select @ID,(select FullName from KYP.OIS_User where PersonID=A.AssignedToUserId AND (UserID <> 'supervisor' AND UserID <> 'reviewer')),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0) from Alertstatistics A
  left join
  OpenAlertAge B ON A.AssignedtoUserId=B.assignedtoUserId
    left join 
   CloseAlertAge C ON A.AssignedtoUserId=C.assignedtoUserId 
  END
----- End ----------4)For getting all count without filter -------------------
  END
  
 -------------------------------------------------------------------------------------------------------------------------------------------- 
  
  ----------------------------------------------------------- View when user FilterType=Watchlist -----------------------------------------------------
  IF @FilterType='Watchlist'
 BEGIN

 WITH Alertstatistics as
(
select WatchlistName,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where (DateInitiated between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0  
      group by WatchlistName
 ),     
 OpenAlertAge as
 (select WatchlistName,SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 
 from KYP.MDM_Alert where (DateInitiated between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 AND WFStatus<>'Completed' group by  WatchlistName),
 CloseAlertAge as
 (select WatchlistName,SUM(datediff(dd,DateInitiated,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where (DateInitiated between @FromDate AND @ToDate) AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 AND WFStatus='Completed' and DateClosed is not null group by  WatchlistName),
 AccountImpactedCount as
 (select ImpA.WatchlistName,count(distinct ImpB.ProviderID) as AccountsImpacted 
 from KYP.MDM_Alert ImpA inner join KYP.MDM_ImpProviders ImpB on ImpA.AlertID=ImpB.AlertID 
 inner join KYP.MDM_AlertResolution ImpC on ImpB.ProviderID=ImpC.ProviderID 
 where  (ImpA.DateInitiated between @FromDate AND @ToDate) AND ImpA.IsMerged = 'N' AND ISNULL(ImpA.IsDeleted, 0) = 0 
 AND ISNULL(ImpC.IsDeleted, 0) = 0 group by WatchlistName)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,AccountsImpacted,Watchlist)
select @ID,A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),ISNULL(D.AccountsImpacted,0),A.WatchlistName from Alertstatistics A
  left join
  OpenAlertAge B ON A.WatchlistName=B.WatchlistName
    left join 
   CloseAlertAge C ON A.WatchlistName=C.WatchlistName
   left join 
  AccountImpactedCount D ON A.WatchlistName=D.WatchlistName
 END
 
 
   ------------------------------------------------------------------Filter Type of Provider Type
   IF @FilterType='ProviderType'
 BEGIN

  WITH Alertstatistics as
(
select ProviderTypeCode,COUNT(MA.AlertID) as totalalerts,COUNT(CASE WHEN MA.WFStatus<>'Completed' THEN 1 END) as openalertscount, COUNT(CASE WHEN MA.WFStatus='Completed' THEN 1 END) as closelertcount,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert MA
	inner join
  KYP.PDM_Provider PP on MA.WatchedPartyID=PP.PartyID
    inner join
    KYP.PDM_ProviderTypeCode PPT on PP.Type=PPT.ProviderTypeCode where (MA.DateInitiated between @FromDate AND @ToDate) AND MA.IsMerged = 'N' AND ISNULL(MA.IsDeleted, 0) = 0 Group by PPT.ProviderTypeCode
 ),    
 OpenAlertAge as
 (select ProviderTypeCode,SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 from KYP.MDM_Alert MA
inner join
  KYP.PDM_Provider PP on MA.WatchedPartyID=PP.PartyID
    inner join
    KYP.PDM_ProviderTypeCode PPT on PP.Type=PPT.ProviderTypeCode where (MA.DateInitiated between @FromDate AND @ToDate) AND MA.IsMerged = 'N' AND ISNULL(MA.IsDeleted, 0) = 0  AND MA.WFStatus<>'Completed' group by PPT.ProviderTypeCode),
 CloseAlertAge as
 (select ProviderTypeCode,SUM(datediff(dd,DateInitiated,DateClosed))/count(*) as ClosedAlertAge1  from KYP.MDM_Alert MA
inner join
  KYP.PDM_Provider PP on MA.WatchedPartyID=PP.PartyID
    inner join
    KYP.PDM_ProviderTypeCode PPT on PP.Type=PPT.ProviderTypeCode where (MA.DateInitiated between @FromDate AND @ToDate) AND MA.IsMerged = 'N' AND ISNULL(MA.IsDeleted, 0) = 0  AND MA.WFStatus='Completed' group by PPT.ProviderTypeCode),
 AccountImpactedCount as
 (select ProviderTypeCode,count(distinct ImpB.ProviderID) as AccountsImpacted from KYP.MDM_Alert ImpA inner join KYP.MDM_ImpProviders ImpB on ImpA.AlertID=ImpB.AlertID inner join KYP.MDM_AlertResolution ImpC on ImpB.ProviderID=ImpC.ProviderID inner join
  KYP.PDM_Provider PP on ImpA.WatchedPartyID=PP.PartyID
    inner join
    KYP.PDM_ProviderTypeCode PPT on PP.Type=PPT.ProviderTypeCode where  (ImpA.DateInitiated between @FromDate AND @ToDate) AND ImpA.IsMerged = 'N' AND ISNULL(ImpA.IsDeleted, 0) = 0 AND ISNULL(ImpC.IsDeleted, 0) = 0  group by PPT.ProviderTypeCode)
insert into KYP.MDM_AlertStatisticsReport(UniqueId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,AccountsImpacted,ProviderType)
select @ID,A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),ISNULL(D.AccountsImpacted,0),(select ProviderTypeDescription from KYP.PDM_ProviderTypeCode where ProviderTypeCode=A.ProviderTypeCode) from Alertstatistics A
 inner join
  OpenAlertAge B ON A.ProviderTypeCode=B.ProviderTypeCode
 left join
   CloseAlertAge C ON A.ProviderTypeCode=C.ProviderTypeCode
   left join 
  AccountImpactedCount D ON A.ProviderTypeCode=D.ProviderTypeCode
 END
 
------------------------------------------------ Filter Type Month -------------------------------

 IF @FilterType='Month'
 BEGIN
 
 IF @FilterSubType='CloseAlert'
 BEGIN
 WITH Alertstatistics as
(
select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where WFStatus='Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
      group by DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)
 ),     
 OpenAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,0 as OpenAlertAge1 
 from KYP.MDM_Alert where WFStatus<>'Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)),
 CloseAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where WFStatus='Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 and DateClosed is not null group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated))
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,Months,Year)
select @ID,(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years)+'-'+(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years) from Alertstatistics A
  left join
  OpenAlertAge B ON A.months=B.months and A.years=B.years
    left join 
   CloseAlertAge C ON A.months=C.months and A.years=C.years
  ---End-----------------------1)When user click on drill down functionality and clicked on CloseAlert --------  
 END

-------------------------------------------Change2---------------------------------------------------------------
----- Begin ----------2) When user click on drill down functionality and clicked on Open alert count -------------------
IF @FilterSubType IS NOT NULL AND @FilterSubType<>'CloseAlert' AND @FilterSubType<>'F' AND @FilterSubType<>'U' AND @FilterSubType<>'I' AND @FilterSubType<>'C'
BEGIN
WITH Alertstatistics as
(
select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,
	  count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,
	  COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,
	  COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus,
      SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 
      from KYP.MDM_Alert where WFStatus<>'Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0  
      group by DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)
 ),     
 --OpenAlertAge as
 --(select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 
 --from KYP.MDM_Alert where WFStatus<>'Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 
 --group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)),
 CloseAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,0 as ClosedAlertAge1 
 from KYP.MDM_Alert where WFStatus='Completed' AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 and DateClosed is not null 
 group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated))
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,Months,Year)
select @ID,(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years)+'-'+(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(A.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(A.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years) from Alertstatistics A
  --left join
  --OpenAlertAge B ON A.months=B.months and A.years=B.years
    left join 
   CloseAlertAge C ON A.months=C.months and A.years=C.years
  
 END
------End---------------2) When user click on drill down functionality and clicked on Open alert count -------------------

----- Begin ----------3) When user click on drill down functionality and clicked on any activity status -------------------
IF @FilterSubType='F' OR @FilterSubType='U' OR @FilterSubType='I' OR @FilterSubType='C'
 BEGIN
  WITH Alertstatistics as
(
select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 group by DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)
 ),     
 OpenAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 
 from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0  AND WFStatus<>'Completed' group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)),
 CloseAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where MatchStatusIndicator=@FilterSubType AND IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0  AND WFStatus='Completed' and DateClosed is not null group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated))
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,Months,Year)
select @ID,(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years)+'-'+(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years) from Alertstatistics A
  left join
  OpenAlertAge B ON A.months=B.months and A.years=B.years
    left join 
   CloseAlertAge C ON A.months=C.months and A.years=C.years
 END
----- End ----------3) When user click on drill down functionality and clicked on any activity status -------------------

----- Begin ----------4)For getting all count without filter -------------------
 IF @FilterSubType IS NULL
 BEGIN
 
WITH Alertstatistics as
(
select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,count(AlertID) as totalalerts,COUNT(CASE WHEN WFStatus<>'Completed' THEN 1 END) as openalertscount,COUNT(CASE WHEN WFStatus='Completed' THEN 1 END) as closelertcount ,COUNT(CASE WHEN MatchStatusIndicator = 'F' THEN 1 END) AS FStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'I' THEN 1 END) AS IStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'C' THEN 1 END) AS CStatus,
      COUNT(CASE WHEN MatchStatusIndicator = 'U' THEN 1 END) AS UStatus 
      from KYP.MDM_Alert where IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 group by DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)
 ),     
 OpenAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,getdate()))/count(*) as OpenAlertAge1 
 from KYP.MDM_Alert where IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 AND WFStatus<>'Completed' group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated)),
 CloseAlertAge as
 (select DATEPART(MONTH,DateInitiated) as months,DATEPART(year,DateInitiated) as years,SUM(datediff(dd,DateInitiated,DateClosed))/count(*) as ClosedAlertAge1 
 from KYP.MDM_Alert where IsMerged = 'N' AND ISNULL(IsDeleted, 0) = 0 AND WFStatus='Completed' and DateClosed is not null group by  DATEPART(MONTH,DateInitiated),DATEPART(YEAR,DateInitiated))
insert into KYP.MDM_AlertStatisticsReport(UniqueId,UserId,TotalAlert,CountOfOpenAlerts,CountOfCloseAlerts,FalsePositiveAlerts,FalsePositivePercentage,IgnoredAlerts,IgnoredPercentage,ConfirmedAlerts,ConfirmedPercentage,UnConfirmedAlerts,UnConfirmedPercentage,AverageCaseAge,AverageOpenCaseAge,AverageCloseCaseAge,Months,Year)
select @ID,(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years)+'-'+(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),A.totalalerts,A.openalertscount,A.closelertcount,A.FStatus,convert(numeric(18,1), (convert(numeric(18,1),A.Fstatus)*100/A.totalalerts)) as Falsepositivepercentage,A.IStatus,convert(numeric(18,1), (convert(numeric(18,1),A.IStatus)*100/A.totalalerts)) as IgnorePercentage,A.CStatus,convert(numeric(18,1), (convert(numeric(18,1),A.CStatus)*100/A.totalalerts)),A.UStatus,convert(numeric(18,1), (convert(numeric(18,1),UStatus)*100/A.totalalerts)),(isNull(B.OpenAlertAge1,0)+isNull(C.ClosedAlertAge1,0))/2,isNull(B.OpenAlertAge1,0),isNull(C.ClosedAlertAge1,0),(select Description from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years),(select Abreviation from KYP.LK_Screening where TypeID=9 and SortOder=A.months and Abreviation=A.years) from Alertstatistics A
  left join
  OpenAlertAge B ON A.months=B.months and A.years=B.years
    left join 
   CloseAlertAge C ON A.months=C.months and A.years=C.years
  END
----- End ----------4)For getting all count without filter -------------------


 END
END

 
END


GO

