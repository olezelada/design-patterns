
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <07/09/2017>
-- Description:	<Copy Modalities from Portal to Enrollment where Approved=1 >
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Modalities]
    @new_Party_id       INT,
    @Party_id           INT,
    @LastActionUserID   VARCHAR(20),
    @provider_type_code VARCHAR(20)
AS
  BEGIN


    SET NOCOUNT ON;
    DECLARE @new_modality_id INT;
    DECLARE @Modality_ID INT;
    DECLARE @modalities_id TABLE(pk INT IDENTITY (1, 1), ModID INT);
    DECLARE @partys_id TABLE(pk INT IDENTITY (1, 1), PartID INT);
    DECLARE @tot INT, @cont INT, @add INT, @new_add INT, @loc INT
    DECLARE @tot_party INT, @cont_party INT, @add_party INT, @new_add_party INT, @loc_party INT, @newparty INT, @new_Account_Id INT
    SELECT @new_Account_Id = AccountID
    FROM KYPEnrollment.pADM_Account
    WHERE PartyID = @new_Party_id AND IsDeleted = 0

    IF EXISTS(SELECT ModalityId
              FROM KYPPORTAL.PortalKYP.pPDM_Modalities)
      BEGIN

        IF (@provider_type_code = '051')
          BEGIN

            INSERT INTO @modalities_id (ModID)
              SELECT ModalityId
              FROM KYPPORTAL.PortalKYP.pPDM_Modalities m
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON m.PartyId = p.PartyID
              WHERE P.ParentPartyID = @Party_id AND m.Approved = 1 AND m.ModlityCode = 'HDP' and p.IsDeleted=0;

            INSERT INTO @partys_id (PartID)
              SELECT p.PartyID
              FROM KYPPORTAL.PortalKYP.pPDM_Modalities m
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON m.PartyId = p.PartyID
              WHERE P.ParentPartyID = @Party_id AND m.Approved = 1 AND m.ModlityCode = 'HDP' and p.IsDeleted=0;

          END

        IF (@provider_type_code = '076')
          BEGIN

            INSERT INTO @modalities_id (ModID)
              SELECT ModalityId
              FROM KYPPORTAL.PortalKYP.pPDM_Modalities m
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON m.PartyId = p.PartyID
              WHERE P.ParentPartyID = @Party_id AND m.Approved = 1 AND m.ModlityCode <> 'HDP' and p.IsDeleted=0;

            INSERT INTO @partys_id (PartID)
              SELECT p.PartyID
              FROM KYPPORTAL.PortalKYP.pPDM_Modalities m
                INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON m.PartyId = p.PartyID
              WHERE P.ParentPartyID = @Party_id AND m.Approved = 1 AND m.ModlityCode <> 'HDP' and p.IsDeleted=0;

          END


        SELECT @tot = MAX(pk)
        FROM @modalities_id;

        SET @cont = 1;


        WHILE @cont <= @tot
          BEGIN


            SELECT @add_party = p.PartyID
            FROM KYPPORTAL.PortalKYP.pPDM_Party p
            WHERE p.PartyID = (SELECT PartID
                               FROM @partys_id
                               WHERE pk = @cont);

            EXEC @newparty = [KYPEnrollment].[sp_Copy_Party_Type] @add_party, @new_Party_Id, @new_Account_Id,
                                                                  @LastActionUserID, 'Modality';


            SELECT @add = ModalityId
            FROM [KYPPORTAL].[PortalKYP].pPDM_Modalities
            WHERE ModalityId = (SELECT ModID
                                FROM @modalities_id
                                WHERE pk = @cont) AND Approved = 1;


            INSERT INTO KYPEnrollment.pAccount_PDM_Modalities (

              ModlityCode,
              ModalityDocNumber,
              DocInstanceId,
              LicenseNumber,
              Explanation,
              ReqTreatmentComp,
              PartyId,
              Deleted,
              LastAction,
              LastActionDate,
              LastActionUserID,
              LastActionReason,
              LastActionComments,
              LastActionApprovedByUsedID,
              CurrentRecordFlag,
              EffectiveDate,
              IsMedicationUnit
            )
              SELECT

                ModlityCode,
                ModalityDocNumber,
                DocInstanceId,
                LicenseNumber,
                Explanation,
                ReqTreatmentComp,
                @newparty,
                0,
                LastAction,
                LastActionDate,
                @LastActionUserID,
                LastActionReason,
                LastActionComments,
                LastActionApprovedByUsedID,
                1,
                EffectiveDate,
                IsMedicationUnit

              FROM KYPPORTAL.PortalKYP.pPDM_Modalities
              WHERE Approved = 1 AND ModalityId = @add;

            EXEC [KYPEnrollment].[sp_Copy_ModalitiesAddressAndLocations]  @newparty, @add_party, @LastActionUserID;

            EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @new_Account_Id, @add_party, @newparty

            SET @cont = @cont + 1;


            PRINT 'New Modality';


          END
      END


  END


GO

