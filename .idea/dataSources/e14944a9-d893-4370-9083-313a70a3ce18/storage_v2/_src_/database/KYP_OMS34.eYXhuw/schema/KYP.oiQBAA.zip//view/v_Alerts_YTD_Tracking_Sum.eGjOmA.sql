


CREATE VIEW [KYP].[v_Alerts_YTD_Tracking_Sum]
AS
SELECT row_number() OVER (
		ORDER BY x.TotalProviders
		) AS ID
	,x.*
FROM (
	SELECT SUM(ProvidersRecieved) AS TotalProviders
		,SUM(TotalAlerts) AS TotalAlerts
		,SUM(ConfirmedAlerts) AS TotalConfirmedAlerts
		,SUM(FalsePositives) AS TotalFalsePositives
		,SUM(IgnoredAlerts) AS TotalIgnored
		,SUM(ExclusionBasedAlerts) AS TotalExclusion
		,SUM(VerificationBasedAlerts) AS TotalVerification
		,SUM(ActionTakenOn) AS TotalActionTaken
	FROM KYP.v_Alerts_YTD_Tracking
	) x


GO

