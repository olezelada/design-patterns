

CREATE VIEW [KYPEnrollment].[v_MOCAAdverseActions]
AS
SELECT AC.AccountID,D.PartyID,AD.ProgramType,P.NPI,AD.Date_x,AD.EffectiveDate
	FROM KYPEnrollment.pADM_Account AC
	LEFT JOIN KYPEnrollment.pAccount_PDM_Party D ON AC.AccountID = D.AccountID
	Left Join kypenrollment.PAccount_pdm_party D1 on D.ParentPartyid=D1.PArtyId /*1*/
	LEFT JOIN KYPEnrollment.pAccount_PDM_AdverseAction AD ON AD.PartyID = D.PartyID
		LEFT JOIN KYPEnrollment.pAccount_PDM_PROVIDER P ON P.PartyID = D.PartyID
	WHERE D.Type IN('InvActionQuestion','EntityActionQuestion','LiabilitiesActionProgramSuspension','EntityQuestion')
	and D1.Type <> 'Provider' /*1*/
GO

