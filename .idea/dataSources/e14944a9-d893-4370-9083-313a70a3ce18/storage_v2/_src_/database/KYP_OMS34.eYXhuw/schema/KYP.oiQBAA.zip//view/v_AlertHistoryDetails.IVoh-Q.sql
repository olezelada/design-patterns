CREATE VIEW [KYP].[v_AlertHistoryDetails]
AS
SELECT  row_number() OVER (ORDER BY Q.AlertID ASC) AS ID, * FROM (
	SELECT		A.AlertID, A.AlertNo, CONVERT(VARCHAR, A.AssignedDate, 101) AS 'AssignedDate', 
				CONVERT(VARCHAR, A.DateClosed, 101) AS 'ClosedDate', A.WatchedPartyName, A.WatchlistName, 
				B.ResolutionID, B.ResolutionType
	FROM		KYP.MDM_Alert AS A INNER JOIN
				KYP.MDM_AlertResolution AS B ON A.AlertID = B.AlertID 
				AND ISNULL(B.IsDeleted, 0) = 0 AND B.ResolutionTypeID NOT IN (5, 6)
) Q


GO

