-- =============================================
-- Author:		<GLacunza>
-- Create date: <15/02/2018>
-- Description:	<Calls sp's to fill rendering s affilliations in FBP cases>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_RenderingS_FBPAffiliations]
    @application_no      VARCHAR(10),
    @Account_Id          INT,
    @application_Id      INT,
    @last_action_user_id VARCHAR(100),
    @account_no varchar(20)

AS

  BEGIN
  DECLARE @date_create DATE,
  @rendering_app_affiliation_id int,
  @group_email varchar (100),
  @rendering_email varchar(100),
  @type_affiliation varchar(40),
  @group_app varchar(10)  
  
  select 
	  @account_id = rendering_instance_id,
      @rendering_app_affiliation_id = rendering_affiliation_id,
      @group_email = groupEmail,
      @rendering_email = rendering_email,
      @type_affiliation = type_affiliation,
      @group_app = group_providerNumber
  from [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] where isDeleted=0 and IsRenderingS=1 and rendering_providerNumber=@application_no

  IF(@Account_Id = 0)
  begin
	SET @Account_Id = null
  end
  
  IF EXISTS(SELECT ApplicationID FROM KYPPORTAL.PortalKYP.pADM_Application a 
  WHERE a.FBPApp = 1 AND a.ApplicationNo = @group_app AND a.IsDeleted = 0)
  BEGIN
   
   EXEC   [KYPEnrollment].[sp_Fill_FBPAffiliations]    @application_no,@group_app,@Account_Id,@application_Id,@last_action_user_id      
  END
  
  ELSE IF EXISTS(SELECT AccountID FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @group_app AND ProvLocTypeCd = 'F' and IsDeleted=0)
  BEGIN
		
        EXEC [KYPEnrollment].[sp_Fill_FBPAffiliationsWithAccount] @application_no, @account_id, @application_Id,@last_action_user_id;
                                                       
  END

 
		
END


GO

