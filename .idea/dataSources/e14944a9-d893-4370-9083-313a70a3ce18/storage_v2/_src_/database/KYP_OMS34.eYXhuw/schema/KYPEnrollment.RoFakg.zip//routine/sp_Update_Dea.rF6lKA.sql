
/* ==========================================================
-- Author:  <NRojas>
-- PROCEDURE: Update DEA by Traking.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Dea]
   @acc_party_id           INT,
   @action_taken           VARCHAR (50),
   @last_action_user_id    VARCHAR (100),
   @target_path            VARCHAR (200),
   @en_db_column           VARCHAR (100),
   @data                   VARCHAR (MAX),
   @acc_PK                 VARCHAR (100),
   @acc_PK_value           INT,
   @is_text_date           CHAR (1)
AS
BEGIN
   DECLARE
      @app_dea_id   INT,
      @new_dea_id   INT

   IF @action_taken = 'Added'
      BEGIN
         SELECT @app_dea_id = DeaID
         FROM [KYPPORTAL].[PortalKYP].[pPDM_Dea]
         WHERE TargetPath = @target_path;

         IF NOT EXISTS
               (SELECT FiledID
                  FROM #Control_Add_row
                 WHERE     FiledID = @app_dea_id
                       AND NameTable = 'pAccount_PDM_DEA')
            BEGIN
               PRINT @action_taken
               EXEC [KYPEnrollment].[sp_Copy_Dea] @acc_party_id,
                                                  NULL,
                                                  @last_action_user_id,
                                                  @app_dea_id;

               INSERT INTO #Control_Add_row (FiledID, NameTable)
               VALUES (@app_dea_id, 'pAccount_PDM_DEA');
            END
      END

   IF @action_taken = 'Updated'
      BEGIN
         PRINT @action_taken
         EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_DEA',
                                                @en_db_column,
                                                @data,
                                                @acc_PK,
                                                @acc_PK_value,
                                                @is_text_date,
                                                NULL,
                                                @last_action_user_id,
                                                @action_taken;
      END

   IF @action_taken = 'Deleted' AND @target_path LIKE '%pAccount_PDM_DEA%'
      BEGIN
         PRINT @action_taken

         UPDATE [KYPEnrollment].[pAccount_PDM_DEA]
            SET CurrentRecordFlag = 0
          WHERE DeaID = @acc_PK_value;
      END
END


GO

