


CREATE VIEW [KYPEnrollment].[Vw_AccountSearch]
AS
Select A.ID ViewId,A.AccountNumber,A.EnrollmentStatus,A.EnrolledOn,A.ProviderType,A.BillingStatus
	   ,A.ScreeningLevel,A.ServiceCity,A.ServiceState,A.ServiceZip,A.PayCity,A.PayState,A.PayZip
	   ,A.AccountName,A.NPI,A.SSN,A.TAXID,A.CategoryOfService,A.ScheduledStatus,A.StatusDate
	   ,A.AccountID,A.RiskScore,A.ServiceAddressLine1,A.ServiceAddressLine2,A.PayAddressLine1
	   ,A.PayAddressLine2,A.License,A.InPortalDate,A.CompletedInPortalDate,A.StatusBeginDate,A.AccountType
	   ,A.AccountTypeDesc,A.AccountSearchEnabled,A.ProvisionalCode,A.ProviderTypeCode,pAcc.LegacyAccountNo
	   ,pAcc.StateStatusAcc
from KYPEnrollment.AccountSearch A
inner join KYPEnrollment.pADM_Account pAcc on pAcc.AccountID = A.AccountID


GO

