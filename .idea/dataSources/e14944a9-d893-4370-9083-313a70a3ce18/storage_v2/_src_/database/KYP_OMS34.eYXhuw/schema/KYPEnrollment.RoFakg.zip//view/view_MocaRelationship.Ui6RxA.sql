
/*Defect: CAPAVE - 3901
  Modified: Sundar
  Description: 1. ParentPartyIdAssociation is made to null to avoid duplicates
  2. Added Union condition to remove data loss*/


CREATE VIEW [KYPEnrollment].[view_MocaRelationship] AS
With Q1 as
(Select Pa.PartyID
 FROM KYPEnrollment.pAccount_PDM_Party pa 
 WHERE pa.[Type] = 'Individual Ownership' AND pa.CurrentRecordFlag = 1
 UNION
 Select Pa.PartyID
 FROM KYPEnrollment.pAccount_PDM_Party pa 
 WHERE pa.[Type] = 'Entity Ownership' AND pa.CurrentRecordFlag = 1), 
Q2 as (SELECT Distinct * 
  FROM(SELECT LegalName AS FullName,
     TypeAssociation,  
     IsNull(
     CASE
      WHEN Relationship.FamiliarRelationship = 'Other'
       THEN Relationship.FamiliarRelationshipOther
      ELSE Relationship.FamiliarRelationship
      END  
      ,'NA') AS Relationship,
     Org.LegalName AS LegalName,
     Relationship.PartyIDOwned,
     MOCA.PartyID AS MocaPartyID  
    FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship AS Relationship
    JOIN KYPEnrollment.pAccount_PDM_Organization Org
      ON Org.PartyID = Relationship.PartyIDOwned 
    JOIN Q1 AS MOCA
      ON Relationship.PartyIDOwner = MOCA.PartyID    
    Where ISNULL(Org.IsDeleted,0) = 0 
    AND Relationship.ParentPartyIdAssociation is null /*Start CAPAVE- on CAPAVE - 3901*/
   Union all
   SELECT   
     --Person.LastName+ ISNULL(', '+Person.FirstName, '') + ISNULL(' '+Person.MiddleName, '') as FullName,
     ISNULL(Person.LastName, '') + ', ' + ISNULL(Person.FirstName, '')+ ' ' + ISNULL(Person.MiddleName, '') as FullName,
     TypeAssociation,  
     IsNull(
     CASE
      WHEN Relationship.FamiliarRelationship = 'Other'
       THEN Relationship.FamiliarRelationshipOther
      ELSE Relationship.FamiliarRelationship
      END  
     ,'NA') AS Relationship,
     'NA',
     Relationship.PartyIDOwned,
     MOCA.PartyID MocaPartyID  
    FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship AS Relationship
    JOIN KYPEnrollment.pAccount_PDM_Person Person
      ON Person.PartyID = Relationship.PartyIDOwned 
    JOIN Q1 AS MOCA
      ON Relationship.PartyIDOwner = MOCA.PartyID    
    Where ISNULL(Person.Deleted,0) = 0 
      AND Relationship.ParentPartyIdAssociation is null /*Start CAPAVE- on CAPAVE - 3901*/
    /*Start CAPAVE- on CAPAVE - 3901*/
    Union all
	SELECT Isnull(Org.LegalName,ISNULL(Person.LastName, '') + ', ' + ISNULL(Person.FirstName, '') + ' ' + ISNULL(Person.MiddleName, '')) AS FullName,
		 TypeAssociation,  
		 IsNull(
		 CASE
		  WHEN Relationship.FamiliarRelationship = 'Other'
		   THEN Relationship.FamiliarRelationshipOther
		  ELSE Relationship.FamiliarRelationship
		  END  
		  ,'NA') AS Relationship,
		 Isnull(Org.LegalName,ISNULL(Person.LastName, '') +', ' + ISNULL(Person.FirstName, '') + ' ' + ISNULL(Person.MiddleName, '')),--Org.LegalName AS LegalName,
		 Relationship.PartyIDOwned,
		 MOCA.PartyID AS MocaPartyID  
		FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship AS Relationship
		Left JOIN KYPEnrollment.pAccount_PDM_Person Person
		  ON Person.PartyID = Relationship.PartyIDOwned and ISNULL(Person.Deleted,0) = 0 
		Left JOIN KYPEnrollment.pAccount_PDM_Organization Org
		  ON Org.PartyID = Relationship.PartyIDOwned and ISNULL(Org.IsDeleted,0) = 0
		JOIN Q1 AS MOCA
		  ON Relationship.ParentPartyIdAssociation = MOCA.PartyID    

    /*Start CAPAVE- on CAPAVE - 3901*/
   )X)
Select ROW_NUMBER() OVER(ORDER BY MocaPartyID) As RelationID,*
From Q2;


GO

