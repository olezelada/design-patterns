





CREATE VIEW [KYP].[v_MoreValueDetail]
AS
SELECT  Z.MoreValueID,Z.ScreeningID,Z.HMSID,Z.AttributeName,Z.DisclosedData,Z.FoundData,Z.MatchResult, Z.Category, Z.SortOrder,CASE WHEN Z.MatchResult = 'T' OR Z.MatchResult = 'P' THEN 
	Z.FlagCount ELSE NULL END AS FlagCount,Z.DStateName,Z.FStateName,Z.DValidity,Z.FValidity FROM (
	SELECT MoreValueID,ScreeningID,HMSID,AttributeName,DisclosedData,FoundData,FlagCount,MatchResult, Category, SortOrder,DStateName, FStateName, DValidity, FValidity from(
		Select X.MoreValueID,X.ScreeningID,X.HMSID,X.AttributeName,X.DisclosedData,X.FoundData,X.FlagCount,X.MatchResult, X.Category, X.SortOrder,X.DetailAttributeName,X.DetailAttributeValue from(
			Select D.MoreValueID,M.ScreeningID,M.HMSID,M.AttributeName,M.DisclosedData,M.FoundData,M.FlagCount,M.MatchResult, M.Category, M.SortOrder,
			D.DetailAttributeName,D.DetailAttributeValue
				from KYP.SDM_MoreValue M inner join KYP.SDM_MoreValueDetail D 
				ON M.MoreValueID = D.MoreValueID 
		) X 
)Y PIVOT(max(DetailAttributeValue)
	for DetailAttributeName IN (DStateName, FStateName, DValidity, FValidity)
) patx
) Z where (LTRIM(RTRIM(ISNULL(Z.DisclosedData,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.FoundData,''))) != '' OR
		   LTRIM(RTRIM(ISNULL(Z.DStateName,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.DValidity,''))) != '' OR
		   LTRIM(RTRIM(ISNULL(Z.FStateName,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.FValidity,''))) != '' )


GO

