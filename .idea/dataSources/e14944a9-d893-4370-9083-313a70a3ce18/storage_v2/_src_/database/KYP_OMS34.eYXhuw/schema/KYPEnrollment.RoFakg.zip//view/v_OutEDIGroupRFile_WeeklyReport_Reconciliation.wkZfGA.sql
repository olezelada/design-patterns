



CREATE VIEW [KYPEnrollment].[v_OutEDIGroupRFile_WeeklyReport_Reconciliation]
AS
SELECT distinct
ac.npi BallingNPI,ac.OwnerNo,ac.ServiceLocationNo,ac.ProviderTypeCode
,A.NPI GroupRenderingNPI
from KYPEnrollment.pAccount_RenderingAffiliation RAff
join KYPEnrollment.pADM_Account Ac on raff.AccountID=ac.AccountID
join KYPEnrollment.pADM_Account A on isnull(raff.AffiliatedAccountID,0)=a.AccountID
where raff.AffiliatedAccountID is not null
and raff.TypeAffiliation not like '%MIDLEVEL%'
and Ac.IsDeleted=0
and A.IsDeleted=0
and AC.ProviderTypeCode<>'100' --Added to eliminate Mixed Group records
and RAFF.IsDeleted = 0 --Added for CAPAVE-1416 on 9 Nov 2017


GO

