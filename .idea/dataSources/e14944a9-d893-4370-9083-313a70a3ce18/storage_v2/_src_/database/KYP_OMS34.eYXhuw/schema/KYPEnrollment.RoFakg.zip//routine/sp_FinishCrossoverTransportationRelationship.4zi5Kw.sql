CREATE PROCEDURE [KYPEnrollment].[sp_FinishCrossoverTransportationRelationship]
  @account_id INT

AS
BEGIN

	PRINT 'Finish crossover transportation relationship vehicles-operators'

		 UPDATE KYPEnrollment.pAccount_PDM_Vehicle set Approved = 0, CurrentRecordFlag = 0 WHERE VehicleId IN (
                  SELECT vehicle.VehicleId
                  FROM KYPEnrollment.pAccount_PDM_Party AS party
                  INNER JOIN KYPEnrollment.pAccount_PDM_Vehicle AS vehicle ON party.PartyID = vehicle.PartyId
                  INNER JOIN KYPEnrollment.pADM_Account AS account ON account.PartyID = party.ParentPartyID
                  WHERE  party.CurrentRecordFlag = 1 AND vehicle.CurrentRecordFlag = 1 AND account.AccountID = @account_id
                )

    UPDATE KYPEnrollment.pAccount_PDM_Operator set Approved = 0, CurrentRecordFlag = 0 WHERE OperatorId IN (
                  SELECT operator.OperatorId
                  FROM KYPEnrollment.pAccount_PDM_Party AS party
                  INNER JOIN KYPEnrollment.pAccount_PDM_Operator AS operator ON party.PartyID = operator.PartyId
                  INNER JOIN KYPEnrollment.pADM_Account AS account ON account.PartyID = party.ParentPartyID
                  WHERE  party.CurrentRecordFlag = 1 AND operator.CurrentRecordFlag = 1 AND account.AccountID = @account_id
                )

END


GO

