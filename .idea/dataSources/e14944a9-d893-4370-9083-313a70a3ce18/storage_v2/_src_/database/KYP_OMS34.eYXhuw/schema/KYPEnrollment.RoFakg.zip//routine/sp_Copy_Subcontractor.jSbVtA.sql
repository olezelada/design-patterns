
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Subcontractor form.   
-- PARAMETERS: 
-- @party_App_id : partyID Application that will be Account. 
-- @party_account_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Subcontractor]
@party_app_id INT,
@party_account_id INT,
@last_action_user_id VARCHAR(100),
@account_id INT,
@is_group BIT = 0 
AS
BEGIN 
	--EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Ind] @party_app_id,@party_account_id,@last_action_user_id,'SubcontractorIndividual',NULL,@account_id, @is_group;
	--EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org] @party_app_id,@party_account_id,@last_action_user_id,'SubcontractorEntity',NULL,@account_id,@is_group;
    EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Subcon] @party_app_id,@party_account_id,@last_action_user_id,NULL,@account_id,@is_group;
	PRINT 'New Subcontractor'
END


GO

