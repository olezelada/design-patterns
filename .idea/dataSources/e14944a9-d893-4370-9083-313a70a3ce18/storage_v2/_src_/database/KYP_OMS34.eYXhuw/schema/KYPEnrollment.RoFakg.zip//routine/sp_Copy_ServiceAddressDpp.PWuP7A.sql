-- =============================================
-- Author:		<hbustamante>
-- Create date: <04/5/2019>
-- Description:	<This procedure copy service address for DPP other entity package>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ServiceAddressDpp]
  @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT,
	@last_Action_User_ID VARCHAR(100),
	@partyLocationType VARCHAR (100)

AS
BEGIN
  SET NOCOUNT ON;
  DECLARE @temp TABLE (pk INT IDENTITY(1,1),PartyID INT,LocationID INT,AddressID INT)
  DECLARE @tot INT
  DECLARE @cont INT,@sub_party INT,@add_party INT,@add_location INT,@add_address INT,
  @loc INT,@new_sub_party INT,@new_address INT, @remarks VARCHAR(250)

	IF EXISTS (SELECT * FROM KYPPORTAL.PortalKYP.pPDM_Party WHERE ParentPartyID=@party_Id AND Type= @partyLocationType AND IsDeleted = 0)
	BEGIN

		INSERT INTO @temp (PartyID,LocationID,AddressID)
		SELECT      p.PartyID,l.LocationID,a.AddressID
		FROM        [KYPPORTAL].[PortalKYP].[pPDM_party] p
		INNER JOIN  [KYPPORTAL].[PortalKYP].[pPDM_location] l ON p.PartyID=l.PartyID
		INNER JOIN  [KYPPORTAL].[PortalKYP].pPDM_Address a ON l.AddressID=a.AddressID
		WHERE       p.ParentPartyID=@party_Id AND p.Type=@partyLocationType
		AND         p.IsDeleted=0 AND l.IsDeleted=0 AND a.IsDeleted=0
		AND         l.TargetPath NOT LIKE  '%|%' AND a.TargetPath NOT LIKE  '%|%'

		SELECT @tot =MAX(pk) FROM @temp
		set @cont=1;

		WHILE @cont<=@tot
		BEGIN

			SELECT @add_party=t.PartyID, @add_location=t.LocationID, @add_address = t.AddressID FROM @temp t WHERE t.pk=@cont
			EXEC @new_sub_party = [KYPEnrollment].[sp_Copy_Party] 	@add_party,	@new_Party_Id,	@new_Account_Id,	@last_action_user_id;
			EXEC @new_address = [KYPEnrollment].[sp_Copy_Address] 	@new_sub_party,	@add_party,	null,	@last_Action_User_ID;

			set @cont= @cont + 1

		END

	END
END
GO

