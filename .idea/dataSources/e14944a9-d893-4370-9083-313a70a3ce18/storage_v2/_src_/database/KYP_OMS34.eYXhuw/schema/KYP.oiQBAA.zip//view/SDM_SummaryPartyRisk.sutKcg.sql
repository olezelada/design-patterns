
CREATE VIEW [KYP].[SDM_SummaryPartyRisk]
AS
SELECT TOP 100 PERCENT row_number() OVER (ORDER BY A.ApplicationID ASC) AS ID, C.ApplicationID, D .PartyID, C.AppPartyID, D .Name, C.ScreeningID, 
C.PartyType AS PartyRole, C.CompositeRisk,C.NormalizedRisk
FROM  KYP.ADM_Application A INNER JOIN
               KYP.ADM_Case B ON A.CaseID = B.CaseID INNER JOIN
               KYP.SDM_ApplicationParty C ON C.ApplicationID = A.ApplicationID AND C.IsActive = 1 INNER JOIN
               KYP.PDM_Party D ON C.PartyID = D .PartyID
ORDER BY C.ApplicationID


GO

