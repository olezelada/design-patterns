




CREATE FUNCTION [dbo].[CaseIndicatorDescription](@MILESTONE varchar(100),@StatusCodeNumber INT,@CurrentMinorDisposition varchar(100),@Status varchar(25),@EnrollmentType varchar(50),@PracticeType varchar(50),@IsMoratoria Bit,@RevertStatus varchar (30))
RETURNS varchar(250)
AS
   BEGIN
   
   DECLARE 
	@CaseIndicatorDesc varchar(250),
		@CaseIndicatorDescMultiple varchar(250),
		@htmbegin varchar(50),
		@htmlend varchar(250),	
		@numOfIndicator int;
				
	SET @numOfIndicator =0;
	SET @CaseIndicatorDescMultiple='';
	SET @htmbegin= '<html>';
	SET @htmlend= '</html>';
	
	if(@CurrentMinorDisposition='Revert' AND @MILESTONE='Reverted' ) 
	begin
		SET @CaseIndicatorDesc = 'Reverted By Referrer';
	end
    
    if(@StatusCodeNumber=9) 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Pending Acceptance';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;	
	end
	
	if(@PracticeType='ConsultReverted') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Consult Reverted';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	if(@PracticeType='EscalateReverted') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Escalate Reverted';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	if((@MILESTONE='Return to provider'))
	begin
			SET @numOfIndicator =@numOfIndicator + 1;
			SET @CaseIndicatorDesc = 'Return to provider';
			if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
			else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	if((@MILESTONE='Re-Submitted' OR @MILESTONE='Resubmitted Application Review'))
	begin
			SET @numOfIndicator =@numOfIndicator + 1;
			SET @CaseIndicatorDesc = 'Re-Submitted';
			if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
			else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	 /*if(@Status='Withdrawal') 
	begin
		
		SET @CaseIndicatorDesc = 'Withdraw';
					
	end
	*/
	if(@Status='Withdrawal') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Withdraw';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	if(@CurrentMinorDisposition='Consult') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Consult';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Pending Account Update check for other values are there */
	if(@CurrentMinorDisposition='Pending Account Update') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Pending Account Update';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Pending Account Creation check for other values are there */
	if(@CurrentMinorDisposition='Pending Account Creation') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Pending Account Creation';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	if(@CurrentMinorDisposition='Escalate') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Escalate';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Consult check for other values are there */
	if(@CurrentMinorDisposition='Suspended') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Suspended';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	
	/*CurrentMinorDisposition is Return check for other values are there */
	if(@CurrentMinorDisposition='Returned' OR @EnrollmentType ='Returned') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Return';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
		
		
	end
	
	/* Status is decline check for other values are there */
	if(@Status='Decline') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Decline';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end

	/*CurrentMinorDisposition is Reassigned check for other values are there */
	if(@CurrentMinorDisposition='Reassigned' AND @MILESTONE ='Reverted') 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Reverted';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
		
		
	end
	
	/*To Display Moratoria Tag MO In Queues*/
	if(@IsMoratoria=1 AND (@RevertStatus<>'Moratoria Exempt' OR @RevertStatus is null)) 
	begin
		SET @numOfIndicator =@numOfIndicator + 1;
		SET @CaseIndicatorDesc = 'Moratoria';
		if(@numOfIndicator>1)
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDescMultiple+', <br>'+@CaseIndicatorDesc;
		else
			SET @CaseIndicatorDescMultiple=@CaseIndicatorDesc;
	end
	

	if(@numOfIndicator > 1) 
	begin
		SET @CaseIndicatorDesc=@CaseIndicatorDescMultiple;
	end
	
RETURN(@htmbegin+@CaseIndicatorDesc+@htmlend)
END


GO

