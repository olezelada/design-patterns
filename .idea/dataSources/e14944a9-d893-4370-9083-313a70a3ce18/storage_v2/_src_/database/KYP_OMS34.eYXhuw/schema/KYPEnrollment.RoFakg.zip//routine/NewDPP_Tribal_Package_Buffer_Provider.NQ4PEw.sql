
CREATE PROCEDURE [KYPEnrollment].[NewDPP_Tribal_Package_Buffer_Provider]

		@applicatioNo VARCHAR(50),
		@caseId INT

AS
	BEGIN
		DECLARE @total INT, @count INT, @accNumber VARCHAR(20);
		SET NOCOUNT ON;

    INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber)
          VALUES ('075', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 100000000+@caseId)));

		IF EXISTS(SELECT pq.QuestionID
				FROM KYPPORTAL.PortalKYP.pADM_Application a
					INNER JOIN KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie pq ON a.PartyID = pq.PartyId
				WHERE pq.IsDeleted = 0
					AND a.ApplicationNo = @applicatioNo
					AND ISNULL(pq.Value,'') = 'Yes'
					AND pq.Name = 'FormProfessionalLicenseCert')
			BEGIN
          INSERT INTO #tempProviderType (tempProviderType, appName, AccountNumber)
          VALUES ('102', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 130000000+@caseId)));


			END

	END
GO

