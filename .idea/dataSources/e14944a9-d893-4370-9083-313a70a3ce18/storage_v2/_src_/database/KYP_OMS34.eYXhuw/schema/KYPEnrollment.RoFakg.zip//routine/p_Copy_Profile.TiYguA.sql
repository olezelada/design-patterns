
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Profile]
		@applicatioNo varchar(15),
        @lastActionUserID varchar(100)
AS
BEGIN
							declare @ProfileID varchar(40),
                            	@ProfileName varchar(200);
							select top 1 @ProfileName = pro.profile_name, @ProfileID = pro.EnrollmentProfileId from [KYPPORTAL].[PortalKYP].[pADM_Application] app,	[KYPPORTAL].[PortalKYP].[pProfile] pro where app.profile_id = pro.profile_id and app.ApplicationNo = @applicatioNo
							
							Declare @TargetAccountID2 int,
								@LegalName	varchar(150),
								@DBAName	varchar(150),
								@ProviderType	varchar(50),
								@NPI			varchar(10),
								@SSN			varchar(10),
								@EIN			varchar(10),
								@PIN			varchar(10),
								@EnrollmentStatus varchar(30);
							print 'Getting Account Information'
                            select @PIN=PIN, @EIN=EIN, @SSN=SSN, @NPI=NPI,@ProviderType=ProviderType, @DBAName=DBAName, @LegalName=LegalName, @TargetAccountID2=AccountID, @EnrollmentStatus=StatusAcc from [KYPEnrollment].[pADM_Account] where [ApplicationNumber] = @applicatioNo
							
                            print @PIN;
                            
							--Getting service address information
							Declare @AddressLine1 	varchar(250),
								@AddressLine2		varchar(250),
								@City				varchar(25),
								@ZipPlus4			varchar(50),
								@AdrState 			varchar(40);
							print 'Getting Address Information'
							select @AdrState = ads.[State], @ZipPlus4 = ads.ZipPlus4, @City = ads.City, @AddressLine2 = ads.AddressLine2, @AddressLine1 = ads.AddressLine1 from KYPEnrollment.pAccount_PDM_Location loc,
									KYPEnrollment.pAccount_PDM_Party pa, 
									KYPEnrollment.pAccount_PDM_Address ads
								where loc.PartyID = pa.PartyID
									and loc.AddressID = ads.AddressID
									and loc.[Type] = 'Servicing'
									and pa.AccountID = @TargetAccountID2
									and pa.CurrentRecordFlag = 1
									and ads.CurrentRecordFlag = 1;

							--Getting License information							
							Declare @LicenseNo 	varchar(25),
								@LicenseType	varchar(100);
							print 'Getting License Information'	
							select @LicenseNo = num.Number, @LicenseType = num.[Type] from KYPEnrollment.pAccount_PDM_Number num,
									KYPEnrollment.pAccount_PDM_Party pa
								where num.PartyID = pa.PartyID
									and num.[Type] = 'Professional License'
									and pa.AccountID = @TargetAccountID2
									and pa.CurrentRecordFlag  = 1
                                    and num.CurrentRecordFlag = 1;
							
                            print 'Updating the existent records to be replaced by a new one'
                            
                            	UPDATE 
                                    KYPEnrollment.pAccount_BizProfile_Details  
                                  SET 
                                  
                                    EffectiveEndDate = getDate(),
                                    LastAction = 'D',
                                    LastActionDate = getDate(),
                                    CurrentRecordFlag = 0
                                  WHERE 
                                    ProfileID = @ProfileID
                                    and AccountID = @TargetAccountID2
                                    and (CurrentRecordFlag = 1 or CurrentRecordFlag is null) ;
                            
							print 'Inserting BizProfile AccountID: '+convert(varchar(10),@TargetAccountID2)+' ProfileID: '+@ProfileID;
                            
                            	if @ProfileID is not null and @TargetAccountID2>0
                                BEGIN
                                										INSERT INTO 
									  KYPEnrollment.pAccount_BizProfile_Details
									(
									  --BizProfileDetailsID,
									  ProfileID,
									  AccountID,
									  AccountTypeID,
									  AccountEnrollmentStatus,
									  AccountBillingStatus,
									  AccountLegalName,
									  AccountDBAName,
									  AccountProviderType,
									  AccountNPI,
									  AccountSSN,
									  AccountEIN,
									  AccountAddressType,
									  AccountAddressLine1,
									  AccountAddressLine2,
									  AccountAdrCity,
									  AccountAdrState,
									  AccountAdrZip9,
									  AccountLicenseType,
									  AccountLicenseNo,
									  AccountPhone,
									  AccountPIN,
									  UserRemark,
									  EffectiveBeginDate,
									  EffectiveEndDate,
									  LastAction,
									  LastActionDate,
									  LastActorUserID,
									  LastActionReason,
									  LastActionComments,
									  LastActionApprovedBy,
									  CurrentRecordFlag
									) 
									VALUES (
									  --:BizProfileDetailsID,
									  @ProfileID,--:ProfileID,
									  @TargetAccountID2,--:AccountID,
									  null,--:AccountTypeID,
									  @EnrollmentStatus,--:AccountEnrollmentStatus,
									  null,--:AccountBillingStatus,
									  @LegalName,-- :AccountLegalName,
									  @DBAName,--:AccountDBAName,
									  '',--:AccountProviderType,
									  @NPI,--:AccountNPI,
									  @SSN,--:AccountSSN,
									  @EIN,--:AccountEIN,
									  'Servicing Address',--:AccountAddressType,
									  @AddressLine1,--:AccountAddressLine1,
									  @AddressLine2,--:AccountAddressLine2,
									  @City,--:AccountAdrCity,
									  @AdrState,--:AccountAdrState,
									  @ZipPlus4,--:AccountAdrZip9,
									  @LicenseType,--:AccountLicenseType,
									  @LicenseNo,--:AccountLicenseNo,
									  null,--:AccountPhone,
									  @PIN,--:AccountPIN,
									  null,--:UserRemark,
									  getdate(),--:EffectiveBeginDate,
									  null,--:EffectiveEndDate,
									  'C',--:LastAction,
									  getdate(),--:LastActionDate,
									  @lastActionUserID,--:LastActorUserID,
									  null,--:LastActionReason,
									  null,--:LastActionComments,
									  null,--:LastActionApprovedBy,
									  1--:CurrentRecordFlag
									);
                                END
                                ELSE
                                BEGIN
                                	print 'Profile records does not exists'
                                END 

END


GO

