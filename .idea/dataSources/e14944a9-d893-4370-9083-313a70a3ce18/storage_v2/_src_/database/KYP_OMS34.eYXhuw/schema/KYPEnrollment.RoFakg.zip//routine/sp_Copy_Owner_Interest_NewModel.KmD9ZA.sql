

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Ownership Control Interest form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @@account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Owner_Interest_NewModel]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @party_owner_id         INT,
   @account_id             INT,
   @is_group               BIT = 0,
   @taxidprofileid         int

AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @party_app_owner_id   INT,
      @party_acc_owner_id   INT,
      @party_type           VARCHAR (50),
      @count_association    INT,
      @is_update            BIT,
      @is_prepopulated      BIT,
      @target_path          VARCHAR (200)
      
--DECLARE @SubmissionDate date ,@dateTaxid Date
--DECLARE @partID INT ,@targetp VARCHAR(50)
	
	/*
	this field is added in the sp_copy_party_newmodel
	-- get the Submission date 
	--KPP-10302
	SELECT  @SubmissionDate=trak.DateTracking 
	FROM KYPPORTAL.PortalKYP.pADM_Application ap
	INNER JOIN KYPPORTAL.PortalKYP.pApplicationHistoryTracking trak ON  ap.applicationNo = trak.applicationNumber 
	where 
	trak.applicationMilestone like 'Submitted' and ap.PartyID = @party_app_id
	
  --++
	
	IF @SubmissionDate is null set  @SubmissionDate = convert(date,'1900-01-01')
	
    */


   CREATE TABLE #Owner_Association
   (
      pk                   INT IDENTITY (1, 1),
      AssPartyAppID        INT,
      AssPartyAccID        INT,
      SubcontractorAccID   INT,
      TypeAsso             VARCHAR (50)
   )

   IF @party_owner_id IS NULL
      BEGIN
         DECLARE @owner TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           Type             VARCHAR (50),
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200)
                        )

         INSERT INTO @owner
            SELECT PartyID,
                   Type,
                   IsPrepopulated,
                   TargetPath
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
             WHERE     (   Type = 'Entity Ownership'
                        OR Type = 'Individual Ownership')
                   AND (IsDeleted IS NULL OR IsDeleted = 'false')
                   AND ParentPartyID = @party_app_id


         DECLARE
            @cont   INT,
            @tot    INT
         SELECT @tot = MAX (pk) FROM @owner
         SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
            SET @is_update = 0;
            SELECT @party_app_owner_id = partyid,
                   @party_type = type,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath
            FROM @owner
            WHERE pk = @cont

            EXEC @party_acc_owner_id =
                    [KYPEnrollment].[sp_Copy_Party_NewModel] @party_app_owner_id,
                                                    @party_account_id,
                                                    @account_id,
                                                    @last_action_user_id,
                                                    @taxidprofileid;

            

            -- UPDATE [KYPEnrollment].[pAccount_PDM_Party] 
            -- SET MOCARelationshipStartDate = @SubmissionDate
            -- WHERE PartyID = @party_acc_owner_id;
            
            
            UPDATE [KYPEnrollment].[pAccount_PDM_Party]
               SET LastMOCARelationshipUpdateBy = 'P'
             WHERE PartyID = @party_acc_owner_id;

            UPDATE [KYPEnrollment].[pAccount_PDM_Party]
               SET LastMOCAUpdateBy = 'P'
             WHERE PartyID = @party_acc_owner_id;

            IF @party_type = 'Entity Ownership'
               BEGIN
                  EXEC [KYPEnrollment].[sp_Copy_Entity_Owner] @party_acc_owner_id,
                                                              @party_app_owner_id,
                                                              @last_action_user_id,
                                                              @account_id,
                                                              @is_prepopulated,
                                                              @party_account_id,
                                                              @is_group,
                                                              @target_path;
                 
                  EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id,
                                                                     'Entity',
                                                                     @last_action_user_id,
                                                                     0;
               END
            ELSE
               BEGIN
                  EXEC [KYPEnrollment].[sp_Copy_Individual_Owner] @party_acc_owner_id,
                                                                  @party_app_owner_id,
                                                                  @last_action_user_id,
                                                                  @is_update,
                                                                  @account_id,
                                                                  @is_prepopulated,
                                                                  @party_account_id,
                                                                  @is_group,
                                                                  @target_path;
                  EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id,
                                                                     'Individual',
                                                                     @last_action_user_id,
                                                                     0;
               END

              EXEC [KYPEnrollment].[sp_Copy_Subcontractor_Ownership_newModel] @party_account_id,
                                                                   @party_acc_owner_id,
                                                                   @party_app_id,
                                                                   @party_app_owner_id,
                                                                   @last_action_user_id,
                                                                   @account_id;


            INSERT INTO #Owner_Association (AssPartyAppID, AssPartyAccID)
            VALUES (@party_app_owner_id, @party_acc_owner_id)

            SET @cont = @cont + 1
         END

		   UPDATE [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
               SET PartyIDOwned = AssPartyAccID, DeletedBy = NULL
             WHERE DeletedBy in (SELECT AssPartyAppID FROM #Owner_Association)

/*         DECLARE
            @ass_party_app_id   INT,
            @ass_party_acc_id   INT

         SELECT @tot = MAX (pk) FROM #Owner_Association
         SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
            SELECT @ass_party_app_id = AssPartyAppID,
                   @ass_party_acc_id = AssPartyAccID
            FROM #Owner_Association
            WHERE pk = @cont

            UPDATE [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
               SET PartyIDOwned = @ass_party_acc_id, DeletedBy = NULL
             WHERE DeletedBy = @ass_party_app_id

            SET @cont = @cont + 1
         END
*/
         DROP TABLE #Owner_Association;
      END
   
END

GO

