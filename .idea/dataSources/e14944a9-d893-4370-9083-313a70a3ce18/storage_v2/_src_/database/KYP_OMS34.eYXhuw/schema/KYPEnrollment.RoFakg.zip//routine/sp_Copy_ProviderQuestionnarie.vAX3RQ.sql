
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ProviderQuestionnarie]
   @party_account_id INT, @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @QuestionId     INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
                  [PartyID],
                  [Type],
                  [Name],
                  [Value],
                  [CurrentRecordFlag],
                  [IsDeleted])
      SELECT @party_account_id,
             form.type,
             field.name,
             field.value,
             1,
             0
        FROM [KYPPORTAL].[PortalKYP].[pADM_App_Form] form
             INNER JOIN [KYPPORTAL].[PortalKYP].[pADM_App_Field] field
                ON form.AppFormID = field.AppFormID
       WHERE                                         --form.type like '%Radio'
            form .Type IN ('SubcontractorRadio')
             AND field.Name IN ('subcontractorRadio', 'subcontractorRadio2')
             AND form.partyid = @party_app_id

   SELECT @Questionid = SCOPE_IDENTITY ();
   RETURN @Questionid
END


GO

