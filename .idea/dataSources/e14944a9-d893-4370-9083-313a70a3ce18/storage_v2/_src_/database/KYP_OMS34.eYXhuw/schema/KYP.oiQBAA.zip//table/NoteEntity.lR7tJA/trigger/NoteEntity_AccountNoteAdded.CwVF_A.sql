
CREATE TRIGGER [KYP].[NoteEntity_AccountNoteAdded] ON [KYP].[NoteEntity]
WITH EXECUTE AS CALLER
FOR INSERT
AS
BEGIN
	Declare @NoteEntityDep varchar(100)

	Set @NoteEntityDep = (Select NoteEntityDep from Inserted where NoteEntityDep = 'pADM_Account')
    
    if(@NoteEntityDep = 'pADM_Account')
    BEGIN
	    Declare @CreatedBy varchar(100)
        Declare @NoteNumber varchar(100)
        Declare @AccountID varchar(100)
        Declare @HistoryID int
        Declare @Title varchar(100)
        
        Set @AccountID = (Select NoteEntityDepID from Inserted where NoteEntityDep = 'pADM_Account')
        Set @NoteNumber = (Select NoteNumber from Inserted where NoteEntityDep = 'pADM_Account')
        Set @CreatedBy 	= (Select UserID from [KYP].[OIS_Note] where Number = @NoteNumber)
        Set @Title		= (Select Name from [KYP].[OIS_Note] where Number = @NoteNumber)
    	
                INSERT INTO 
                  KYPEnrollment.pAccount_History
                  (
                    AccountID,
                    ActionID,
                    DateCreated,
                    IsDeleted,
                    LastActorUserID,
                    LastActionDate
                  ) 
                  VALUES (
                     @AccountID,
                     44,
                    getdate(),
                    0,
                    @CreatedBy,
                    getdate()  
                  )
                  
                  
                  set @HistoryID = (SELECT SCOPE_IDENTITY());
                  print @HistoryID

              
                INSERT INTO 
                    KYPEnrollment.HIS_Note
                  (
                    HistoryID,
                    DateCreate,
                    IsDeleted,
                    NoteNumber,
                    NoteTitle
                  ) 
                  VALUES (
                    @HistoryID,
                    getDate(),
                    0,
                    @NoteNumber,
                    @Title
                  );
        
                
               -- print (SELECT SCOPE_IDENTITY())

    END
    
END


GO

