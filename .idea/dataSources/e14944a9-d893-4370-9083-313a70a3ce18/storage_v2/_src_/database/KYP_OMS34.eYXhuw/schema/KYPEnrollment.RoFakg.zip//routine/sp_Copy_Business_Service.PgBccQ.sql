
/* ==========================================================
-- Author:  <NRojas>
-- PROCEDURE: create BusinessService form.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Service]
   @party_account_id INT, @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[PADM_BusinessService] (
                  [AcceptsNewPatients],
                  [AgeRange],
                  [AgeFrom],
                  [AgeTo],
                  [CompetenceTraining],
                  [Languages],
                  [Url],
                  [IsMCO],
                  [EPSDTService],
                  [PartyID],
                  [FullHoursService],
                  [ProvideLanguage])
      SELECT [AcceptsNewPatients],
             [AgeRange],
             [AgeFrom],
             [AgeTo],
             [CompetenceTraining],
             [Languages],
             [Url],
             [IsMCO],
             [EPSDTService],
             @party_account_id,
             [FullHoursService],
             [ProvideLanguage]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_BusinessService]
       WHERE PartyID = @party_app_id

	IF EXISTS (SELECT 1 FROM [KYPEnrollment].[PADM_BusinessService] WHERE PartyID = @party_account_id AND FullHoursService = 'Opened 24/7')
	BEGIN
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Monday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Tuesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Wednesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Thursday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Friday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Saturday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Sunday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
	END

   PRINT 'New BusinessService'
END


GO

