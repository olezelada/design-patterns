

CREATE TRIGGER [KYP].[trg_GK_WatchlistONInset] on [KYP].[GK_Watchlist]
AFTER INSERT
AS
BEGIN
	DECLARE @LastCreated DATETIME;
	SELECT @LastCreated=CreatedOn  FROM inserted
	UPDATE [KYP].[LatestUpdDbDetails] SET  LastLoadDate=GETDATE() WHERE DataSources='OMS' AND ExclusionList='Internal Watchlist'
	/**Added By Rahul for watchlist index**/
	UPDATE KYP.GK_Watchlist set LastActionDate=getdate() where GateKeeperID=(SELECT GateKeeperID FROM inserted)

END

GO

