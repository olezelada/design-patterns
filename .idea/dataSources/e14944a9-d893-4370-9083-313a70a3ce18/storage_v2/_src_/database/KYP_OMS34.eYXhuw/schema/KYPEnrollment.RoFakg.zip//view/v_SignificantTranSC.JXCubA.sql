



CREATE VIEW [KYPEnrollment].[v_SignificantTranSC]
As




WITH Q1
AS (
	SELECT a.PartyIDOwner AS 'ParentPartyIDOwner'
		,a.PartyIDOwned AS 'ParentPartyIDOwned'
		,p.NAME AS NAME
	FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship a
	INNER JOIN KYPEnrollment.pAccount_PDM_OwnershipRelationship b ON a.PartyIDOwned = b.ParentPartyIdAssociation
	INNER JOIN (
		SELECT PartyID
			,isnull(LastName,'') + REPLACE(', ' + isnull(FirstName,''),', ','') NAME
		FROM KYPEnrollment.pAccount_PDM_Person
		where CurrentRecordFlag = '1'
		
		
		UNION ALL
		
		SELECT PartyID
			,LegalName
		FROM KYPEnrollment.pAccount_PDM_Organization
		where CurrentRecordFlag = '1'
		) p ON b.PartyIDOwned = p.PartyID
	WHERE a.TypeAssociation = 'ProviderSubcontractorAssociation'
		AND b.TypeAssociation = 'ProviderSubcontractorOwnerAssociation'
	)
	,Q2
AS (
	SELECT a.PartyIDOwner
		,a.PartyIDOwned
		,t5.FirstName AS NAME
		,a.TransDescription
		,a.OtherAssociation
		,t3.taxIDprofileID
	FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship a 
			Join kypenrollment.pADM_Account t1 on T1.PartyID = a.PartyIDOwner
			Join kypenrollment.pAccount_BizProfile_Details t2 on t1.AccountID=t2.AccountID
			Join kypenrollment.TaxIDProfile t3 on t3.taxID=t1.EIN and t3.profileID=t2.ProfileID
			join kypenrollment.pAccount_PDM_Party t4 on t3.taxIDprofileID=t4.TaxIDProfileID
			join kypenrollment.pAccount_PDM_Person t5 on t4.PartyID=t5.PartyID and a.PartyIDOwned = t4.PartyID
			Where --t4.Type in ('SubcontractorIndividual')
				t4.Type in ('SignificantTransactionIndividual')
				and a.TypeAssociation = 'ProviderSubcontractorAssociation'
				and t5.CurrentRecordFlag = '1'
				and a.CurrentRecordFlag = '1'
	Union
	SELECT a.PartyIDOwner
		,a.PartyIDOwned
		,t5.LegalName AS NAME
		,a.TransDescription
		,a.OtherAssociation
		,T3.taxIDprofileID
	FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship a 
			Join kypenrollment.pADM_Account t1 on T1.PartyID = a.PartyIDOwner
			Join kypenrollment.pAccount_BizProfile_Details t2 on t1.AccountID=t2.AccountID
			Join kypenrollment.TaxIDProfile t3 on t3.taxID=t1.EIN and t3.profileID=t2.ProfileID
			join kypenrollment.pAccount_PDM_Party t4 on t3.taxIDprofileID=t4.TaxIDProfileID
			join kypenrollment.pAccount_PDM_Organization t5 on t4.PartyID=t5.PartyID and a.PartyIDOwned = t4.PartyID
			Where --t4.Type in ('SubcontractorEntity')
				t4.Type in ('SignificantTransactionEntity')
				and a.TypeAssociation = 'ProviderSubcontractorAssociation'		
				and t5.CurrentRecordFlag = '1'
				and a.CurrentRecordFlag = '1'
	)
	,Q3
AS (
	SELECT T1.ParentPartyIDOwner
		,T1.ParentPartyIDOwned
		,STUFF((
				SELECT ';' + NAME AS 'data()'
				FROM Q1 T2
				WHERE T2.ParentPartyIDOwner = T1.ParentPartyIDOwner
					AND T2.ParentPartyIDOwned = T1.ParentPartyIDOwned
				FOR XML path('')
				), 1, 1, '') AS PersonName
	FROM Q1 T1
	GROUP BY T1.ParentPartyIDOwner
		,T1.ParentPartyIDOwned
	)
SELECT ROW_NUMBER() OVER (
		ORDER BY Q2.PartyIDOwned
		) AS RefID
	,Q2.*
	,Q3.PersonName
FROM Q2
LEFT JOIN Q3 ON Q2.PartyIDOwned = Q3.ParentPartyIDOwned


GO

