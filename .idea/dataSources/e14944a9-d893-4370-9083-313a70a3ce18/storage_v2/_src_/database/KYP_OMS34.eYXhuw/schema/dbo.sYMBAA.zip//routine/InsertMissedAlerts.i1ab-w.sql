-- =============================================
-- Author:		Sheetal
-- Create date: 19-Dec-2012
-- Description:	Procedure to insert Impacted
--				Providers with non-repeated values
-- =============================================
CREATE PROCEDURE [dbo].[InsertMissedAlerts] 
	
AS 
BEGIN
	DECLARE 
		@ParentOrChildAlertID INT
		
		
		-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
--SET NOCOUNT ON;
Declare @alertID INT,
        @UserID int,
        @CurrentlyAssignedToID varchar(50),
        @MajorDisposition varchar(50),
        @DateInitiated smalldatetime,
        @PartyName varchar(100),
        @AlertNumber varchar(15),
        @NoofDays int,
        @Rangename varchar(20),
        @WatchlistName varchar(100),       
        @Priority varchar(15),
        @DateResolved smalldatetime,
        @DaysCurrentStatus int,
        @StatuscodeNumber int,
        @Statuscode varchar(10),
		@CurrentWFMinorStatus varchar(50),
        @IsDeleted bit,
        @ExistAlertID int,
        @CurrentWFStatus varchar(100),
		@IsMerged varchar(10),
        @AlertStatusGroup varchar(25);
DECLARE mycursor CURSOR FOR 
Select AlertID, AssignedToUserID,CurrentMajorDisposition,WatchedPartyName,AlertNo,
WatchlistName,DateInitiated,Priority,DateClosed,StatusCodeNumber,IsDeleted,CurrentWFStatus,ISMERGED 
from kyp.MDM_Alert
OPEN mycursor 
FETCH NEXT FROM mycursor INTO @alertID, @UserID, @MajorDisposition, @PartyName,@AlertNumber,@WatchlistName,
@DateInitiated,@Priority,@DateResolved,@StatuscodeNumber,@IsDeleted,@CurrentWFStatus,@IsMerged
WHILE @@FETCH_STATUS = 0 
BEGIN 

SET @CurrentlyAssignedToID =(Select distinct UserID from KYP.OIS_User where PersonID=@UserID)
Set @NoofDays=abs(Datediff(d,@DateInitiated,getdate()))
set @Rangename=KYP.AuditDays(@DateInitiated)
set @DaysCurrentStatus= ABS(Datediff(d,@DateResolved,getdate()))
--Set @Statuscode=(select StatusCodeNumber from inserted);
set @Statuscode=( select Description from KYP.LK_Screening where TypeID=2 and SortOder=@StatuscodeNumber)
set @ExistAlertID =(Select AlertID from [KYP].[MDM_DashBoardTable] where AlertID=@alertID);



if @StatuscodeNumber = 9
begin
    set @AlertStatusGroup = 'Incoming Alert'
end
else if @StatuscodeNumber = 10 or @StatuscodeNumber = 11 or @StatuscodeNumber = 13
begin
    set @AlertStatusGroup = 'Working Alert'
end
else
begin
    set @AlertStatusGroup = ''
end

if @ExistAlertID is null
begin
 INSERT INTO [KYP].[MDM_DashBoardTable]
           ([AlertID]
           ,[AgeByDays]
           ,[Range]
           ,[AlertType]
           ,[CurrentlyAssignedToID]
           ,[CurrentWFStatus]
           ,[CurrentMajorDisposition]
           ,[DateInitiated]
           ,[DateResolved]
           ,[PartyName]
           ,[AlertNumber]
           ,[Statuscode]
           ,[StatuscodeNumber]
           ,[Month]
           ,[RiskRange]
           ,[NPI]
           ,[RiskScore]
           ,[Priority]
           ,[DaysCurrentStatus]
           ,[IsMerged]
           ,[AlertStatusGroup]
           )
     VALUES
           (@alertID
           ,@NoofDays
           ,@Rangename
           ,@WatchlistName
           ,@CurrentlyAssignedToID
           ,@CurrentWFStatus
           ,@MajorDisposition
           ,@DateInitiated
           ,@DateResolved
           ,@PartyName
           ,@AlertNumber
           ,@Statuscode
           ,@StatuscodeNumber
           ,NULL
           ,NULL
           ,NULL
           ,NULL
           ,@Priority
           ,@DaysCurrentStatus
           ,@IsMerged
           ,@AlertStatusGroup
           )
end
else
begin

   UPDATE [KYP].[MDM_DashBoardTable]
   SET 
      [AgeByDays] =abs(Datediff(d,B.DateInitiated ,getdate()))
      ,[Range]=KYP.AuditDays(B.DateInitiated) 
      ,[AlertType] = B.WatchlistName 
      ,[CurrentlyAssignedToID] =(Select distinct UserID from KYP.OIS_User where PersonID=B.AssignedToUserID) 
      ,[CurrentMajorDisposition] = B.CurrentMajorDisposition 
      ,[DateInitiated] = B.DateInitiated 
      ,[DateResolved] = B.DateClosed 
      ,[PartyName] = B.WatchedPartyName 
      ,[AlertNumber] = B.AlertNo     
      ,[StatuscodeNumber] = B.StatusCodeNumber 
      ,[Statuscode] =  (select Description from KYP.LK_Screening where TypeID=2 and SortOder=B.StatusCodeNumber) 
      ,[Priority] = B.Priority 
      ,[DaysCurrentStatus] = ABS(Datediff(d,B.DateClosed,getdate()))
      ,[CurrentWFStatus] = B.CurrentWFStatus 
      ,[IsMerged] = B.IsMerged 
      ,[AlertStatusGroup] = 
      case
      when B.StatusCodeNumber =9 then 'Incoming Alert'
      when B.StatuscodeNumber = 10 or B.StatuscodeNumber = 11 or B.StatuscodeNumber = 13 then 'Working Alert'
      else ''
      end
 
 from [KYP].[MDM_DashBoardTable] A
 join KYP.MDM_Alert B on A.AlertID =B.AlertID  and B.AlertID =@alertID
      
      
end


FETCH NEXT FROM mycursor INTO @alertID, @UserID, @MajorDisposition, @PartyName,@AlertNumber,@WatchlistName,
@DateInitiated,@Priority,@DateResolved,@StatuscodeNumber,@IsDeleted,@CurrentWFStatus,@IsMerged
END ---While
    CLOSE mycursor 
    DEALLOCATE mycursor 


END


GO

