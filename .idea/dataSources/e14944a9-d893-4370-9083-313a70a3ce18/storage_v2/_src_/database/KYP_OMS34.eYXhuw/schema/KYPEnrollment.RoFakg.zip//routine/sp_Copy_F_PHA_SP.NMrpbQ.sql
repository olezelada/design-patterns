
/* ==========================================================
-- Custom:	<ohuanca>
-- Ticket: KYPBO-1629
-- PROCEDURE: Sole Proprietor Pharmacy
-- PARAMETERS: 
-- @new_Party_Id : partyID to new Account that will be create. 
-- @party_Id : partyID Application that will be Account. 
-- @last_Action_User_ID : this is the user Enrollment.
-- @application_no : Application Number that will be Account. 
-- @application_Id : ApplicationID that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_F_PHA_SP]	(
    @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT, 
	@last_Action_User_ID VARCHAR(100),
	@application_no VARCHAR(100),
	@application_Id INT,
	@account_type VARCHAR(10),
	@application_type VARCHAR(40))

AS
BEGIN
	DECLARE @new_Address_Id INT,
	@new_person_id INT,
	@party_contact_id INT,
	@party_contact_id_portal INT,
	@npi_Type VARCHAR(25),
	@npi VARCHAR (10),
	@provider_type_code VARCHAR(5),
	@account_number VARCHAR(20),
	@isGroup BIT ;

	SELECT @npi_Type = [NPIType], @npi =NPI, @provider_type_code = ProviderTypeCode, @account_number = AccountNumber FROM [KYPEnrollment].[pADM_Account] WHERE AccountID = @new_Account_Id 
	
	select @isGroup = CASE WHEN(ISNULL(NpiType, '') = 'Organization') THEN 1 ELSE 0 END  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationID = @application_Id
	
	/*BizProfile Details*/
	EXEC [KYPEnrollment].[sp_Copy_BizProfile_Details] @party_Id,@new_Account_Id,@new_Party_Id,@last_Action_User_ID, 'KYPEnrollment.sp_Copy_BizProfile_Details';
	
	declare @profileid varchar(30)
	select @profileid = b.ProfileID from KYPEnrollment.pADM_Account a inner join KYPEnrollment.pAccount_BizProfile_Details b on a.AccountID=b.AccountID where a.AccountID=@new_Account_Id
	
	/*Individual Profile*/
	EXEC @new_person_id = [KYPEnrollment].[sp_Copy_Personal_Inf_Identification] @new_Party_Id, @party_Id, @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Individual Profile', @last_Action_User_ID;
	
	/*Business Profile*/
	EXEC [KYPEnrollment].[sp_Copy_Business_Profile] @new_Party_Id, @party_Id, @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'businessProfile'

	/* Contact Person */
	EXEC [KYPEnrollment].[sp_Contact_Person] @party_Id, @new_Party_Id, @last_Action_User_ID, @new_Account_Id;
	
	/*Address*/
	EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id, 'Mailing', @last_Action_User_ID;
	 
	/*Place Business*/
	EXEC [KYPEnrollment].[sp_Copy_Place_Business] @new_Party_Id, @party_Id, @last_Action_User_ID, @new_Account_Id;
	
	/*Insurance*/
	--Include mal practice for Insurance (malpracticeInsPharmacy)
	EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id, @party_Id, @last_Action_User_ID;
	
			
	/*Logistics*/
	--daily operations 
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'dailyOperation'
	
	--location stock
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'phLocationOfStock'
	EXEC [KYPEnrollment].[sp_Copy_Address_Location] @new_Party_Id, @party_Id, 'locationOfStock', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Location_Stock]  @party_Id, @new_Party_Id, @last_action_user_id, NULL, @new_Account_Id, NULL;
	
	-- Hours Operation
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'phHoursOfOperation'
	EXEC [KYPEnrollment].[sp_Copy_Business_Hours_CA] @new_Party_Id, @party_Id;
	
	/* Activity - Services*/
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'activity' 


	/* Acitvity - Business Activity Incontinence*/
	EXEC [KYPEnrollment].[sp_Copy_BusinessActivity_IncontinenceTable]@party_Id,  @new_Party_Id, @last_action_user_id, null, @new_Account_Id, false;
	
	/*Prof. Lab Services*/
	EXEC [KYPEnrollment].[sp_Copy_Dea] @new_Party_Id, @party_Id, @last_action_user_id, NULL;	
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]  @party_Id, @new_Party_Id, 'Professional License'
	
	/*Taxonomy Speciality*/
	EXEC [KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id, @party_Id, @last_Action_User_ID, NULL;
	
	/*Pharmacy in Charge*/
	-- pharmacy information
	EXEC [KYPEnrollment].[sp_Copy_Pharmacy_Information] @party_Id, @new_Party_Id, @last_action_user_id, NULL, @new_Account_Id, NULL;
	
	--insurance, it was include in sp_Copy_Insurance
	
	-- adverse actions
	EXEC [KYPEnrollment].[sp_Copy_AdverseActionPharmacy] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;
	
	
	/*Program Participation*/
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;

	/*Adverse Action*/
	EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id, @party_Id,@last_Action_User_ID,@new_Account_Id;
		
	/*Fines and debts*/
	EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_Id, @new_Party_Id, @last_Action_User_ID, NULL;
	
	--Insert/Update mocas with new model
		--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
	IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
		BEGIN
		IF NOT exists (select pk from #Control_Association_Tax_NewMod where npi = @npi and profileid = @profileid)
		BEGIN
			EXEC  [KYPEnrollment].[InsertUpdateMOCANewModel] @new_Account_Id,@new_Party_Id, null,@application_Id,@party_Id, @last_Action_User_ID,0,@application_type
		END
		INSERT INTO #Control_Association_Tax_NewMod (npi,profileid)		
		select @npi,@profileid
		
	END
	
	/*PaymentDetail*/
	EXEC [KYPEnrollment].[sp_Copy_PaymentDetail] @party_Id, @new_Party_Id, @last_Action_User_ID;
	
	/*ApplicationFee*/
	EXEC [KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id, @party_Id,@last_Action_User_ID;
	

	/*Unique Party*/
	EXEC [KYPEnrollment].[sp_Create_Unique_Party_Account] @new_Party_Id, @new_account_id, @npi_Type, @last_Action_User_ID, 0;
	
	/*Update data Account and Linked*/
	EXEC [KYPEnrollment].[sp_Legal_Name_Address] @new_Account_Id, @new_person_id, @new_Address_Id, @npi_Type, @last_Action_User_ID, @npi,@new_Party_Id,	@party_Id, 0, @provider_type_code, @account_number, NULL, @account_type, @application_Id, @isGroup , @application_type;
		
END


GO

