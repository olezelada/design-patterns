-- =============================================
-- Author:		<Author,,Lperez>
-- copiar account recive 4 parametros
-- @dateCreated fecha en la que se aprovo el account ,@priority prioridad o risgo del caso antes de ser aprovado ,@applicationId id de la aplicacion en kyp application ,@lastActionUserID nombre del usuario que realizo la aprobacion 
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Account]
	@dateCreated smalldatetime,
	@priority INT,
	@applicationId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),@newAccountId INT
		
	INSERT INTO [KYPEnrollment].[pADM_Account]
	([LegacyAccountNo]
	,[AccountNumber]
	,[P_SYS_ID]
	,[AccountType]
	,[ServiceLocationNo]
	,[OwnerNo]
	,[ProviderType]
	,[Risk]
	,[EnrollmentRiskLevel]
	,[PIN]
	,[LegalName]
	,[DBAName]
	,[Prefix]
	,[Gender]
	,[Title]
	,[DateDied]
	,[IncorporatedDate]
	,[OOBDate]
	,[RiskScore]
	,[ApplicationDate]
	,[LastActionDate]
	,[ActivationDate]
	,[DeActivationDate]
	,[LastAction]
	,[LastActionReason]
	,[LastActionComments]
	,[LastActorUserID]
	,[LastActionApprovedBy]
	,[AccountUpdateDate]
	,[AccountUpdateUserID]
	,[AccountUpdateReason]
	,[AccountUpdateComments]
	,[LastRevalidationDate]
	,[LastRevalidationReason]
	,[RevalidationDueDate]
	,[LastApplicationType]
	,[LastAlertedDate]
	,[LastScreenedDate]
	,[LastBilledDate]
	,[LastRenderedDate]
	,[LastDeltaLoadDate]
	--,[TIN]
	--,[TINH]
	,[ApplicationNumber]
	,[StatusAcc]
	,[SSN]
	--,[EIN]
	,[PartyID]
	,[ReenrollmentIndicator]
	,[NPI]
	,[IsDeleted]
	,[CreatedBy]
	,[profile_id]
	,[ProviderTypeCode]
	,[NPIType]
	,[PackageName]
	,[StatusBeginDate]
	,[portaluserid])
	SELECT null--[LegacyAccountNo]
	,''--[AccountNumber]
	,null--[P_SYS_ID]
	,null--[AccountType]
	,null--[ServiceLocationNo]
	,null--[OwnerNo]
	,ca.EnrollmentType --[ProviderType]
	,null--[Risk]
	,null--[EnrollmentRiskLevel]
	,null--[PIN]
	,''--[LegalName]
	,null--[DBAName]
	,null--[Prefix]
	,null--[Gender]
	,null--[Title]
	,null--[DateDied]
	,@dateCreated
	,null--[OOBDate]
	,@priority--[RiskScore]
	,@dateCreated--[ApplicationDate]
	,@dateCreated--[LastActionDate]
	,null--[ActivationDate]
	,null--[DeActivationDate]
	,'C'--[LastAction]
	,null--[LastActionReason]
	,null--[LastActionComments]
	,@lastActionUserID
	,@lastActionUserID
	,null--[AccountUpdateDate]
	,null--[AccountUpdateUserID]
	,null--[AccountUpdateReason]
	,null--[AccountUpdateComments]
	,null--[LastRevalidationDate]
	,null--[LastRevalidationReason]
	,null--[RevalidationDueDate]
	,null--[LastApplicationType]
	,null--[LastAlertedDate]
	,null--[LastScreenedDate]
	,null--[LastBilledDate]
	,null--[LastRenderedDate]
	,null--[LastDeltaLoadDate]
	--,null--[TIN]
	--,null--[TINH]
	,ca.[Number] --[ApplicationNumber]
	,'3 - Pending'
	,''--[SSN]
	--,''--[EIN]
	,null--[PartyID]
	,null--[ReenrollmentIndicator]
	,application.NPI 
	,0
	,''--ca.CreatedBy 
	,ca.profile_id
	,application.ProviderTypeCode 
	,application.NpiType 
	,application.PackagesName 
	,@dateCreated
	,ca.portaluserid 
	FROM [KYPPORTAL].[PortalKYP].[pADM_Application]  application INNER JOIN
		 [KYPPORTAL].[PortalKYP].[pADM_Case] ca ON application.[CaseID] = ca.[CaseID]
	WHERE [ApplicationID] = @applicationId
	
	SELECT @newAccountId = Scope_Identity()
	
	SELECT @message = 'New Account ' + CONVERT(char(10), @newAccountId)
	RAISERROR(@message, 0, 1) WITH NOWAIT 	
					
	return @newAccountId
END


GO

