
/* ==========================================================
-- Author:		<Digital Harbor>
-- PROCEDURE: sp_UpdateFieldNumberServiceAddress to change new
-- PARAMETERS:
--@en_db_column
--@last_action_user_id
--@action_taken
--@account_party_id
--@new_value_text
--@field_code
--@section_code
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_UpdateFieldNumberServiceAddress]
	@en_db_column VARCHAR(100),
	@last_action_user_id VARCHAR(100),
	@action_taken VARCHAR(50),
	@account_party_id INT,
	@new_value_text VARCHAR (250),
  @field_code VARCHAR(50),
  @section_code VARCHAR (30),
  @application_Code VARCHAR (30)
AS
BEGIN

  IF(@application_Code IN ('FSP_MDT_SP','FSP_MDT_IN') )
  BEGIN
    DECLARE @today_date DATE = GETDATE()
    DECLARE @is_deleted BIT = 0
    DECLARE @current_record_flag BIT = 1
    DECLARE @last_action VARCHAR(1) = 'C'
    DECLARE @numberId INT

    IF ( @section_code = '2.2.1' AND @en_db_column = 'Number' AND @field_code='businessLicenseNumber' AND @action_taken='Added' )
    BEGIN
      SELECT @numberId = NumberID
      FROM KYPEnrollment.pAccount_PDM_Number
      WHERE PartyID = @account_party_id AND Type IN ('ServAddrBusinesLic')

      IF (@numberId is null OR @numberId = 0)
        BEGIN
          INSERT INTO KYPEnrollment.pAccount_PDM_Number ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
          VALUES (@account_party_id,'ServAddrBusinesLic',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
          SET @numberId = SCOPE_IDENTITY()
        END

      IF @en_db_column = 'Number'
        BEGIN
           UPDATE KYPEnrollment.pAccount_PDM_Number set Number = @new_value_text WHERE NumberID = @numberId
        END
    END
  END

END

GO

