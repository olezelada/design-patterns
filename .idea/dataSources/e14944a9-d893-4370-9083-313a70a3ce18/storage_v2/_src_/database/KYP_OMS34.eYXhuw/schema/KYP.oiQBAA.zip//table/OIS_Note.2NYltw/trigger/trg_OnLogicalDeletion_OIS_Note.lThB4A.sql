


-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle note count in the table KYP.FrameworkCount
--				On logical delete in the table KYP.OIS_Note
--				The trigger is written with the assumption that logical deletion on table KYP.OIS_Note
--				means setting the deleted flag in the table to 1
-- =============================================
CREATE TRIGGER [KYP].[trg_OnLogicalDeletion_OIS_Note]
   ON  [KYP].[OIS_Note]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @Row_Updation_Source VARCHAR(100)

	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF isnull(@Row_Updation_Source,'') in ( 'KYP.p_InsertOISNote') AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END	
		
	--CAPAVE-133 , pd-95
	declare @Alertid int
	
	select  @Alertid = RelatedEntityID from inserted;
	
	select x.alertid INTO #alertsActivityDate 
	from(select alertid from kyp.MDM_Alert with(nolock) 
		where AlertID=@Alertid and @AlertID is not null
	union select alertid from kyp.MDM_Alert with(nolock) 
		where AlertNo=@Alertid and @AlertID is not null)x
    
 
	
	select alertid into #DatetoUpdate from (
	select alertid from #alertsActivityDate 
	union
	SELECT ChildAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ParentAlertID 
	in(	select alertid from #alertsActivityDate)
	UNION
	SELECT ParentAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ChildAlertID 
	in(select alertid from #alertsActivityDate))x
		
		
	Update kyp.MDM_Alert set LastActivityDate = GETDATE()
		where alertid in(select alertid from #DatetoUpdate)
	--CAPAVE-133 , pd-95	


	IF EXISTS (
			SELECT 1 
			FROM INSERTED A 
				INNER JOIN KYP.NoteEntity B 
					ON A.Number = B.NoteNumber
						AND A.deleted=1
				INNER JOIN KYP.FrameworkCount C
					ON B.NoteEntityType = C.FrameworkEntityType
						AND B.NoteEntityTypeID = C.FrameworkEntityTypeID
		)
	UPDATE A 
		SET A.NoteCount = case 
									when A.NoteCount>1 then A.NoteCount -1 
									else 0  
								end,
			A.ModifiedDate = getdate(),
			A.ModifiedBy = 'Note Decreased'	
	FROM KYP.FrameworkCount A	
	INNER JOIN KYP.NoteEntity B 
		ON A.FrameworkEntityType = B.NoteEntityType 
			AND A.FrameworkEntityTypeID = B.NoteEntityTypeID
	INNER JOIN INSERTED C
		ON B.NoteNumber = C.Number 
			AND C.deleted=1

END


GO

