/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMAppProvider]
(@PartyID int
 ,@Category varchar(20)= NULL
 ,@Type int =NULL
 ,@NPI int = NULL
 ,@UPIN varchar(6)=NULL
 ,@CCN varchar(6)=NULL
 ,@HIN varchar(9)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0

)
as begin 

INSERT INTO [KYP].[ADM_App_Provider]
           ([PartyID]
           ,[Category]
           ,[Type]
           ,[NPI]
           ,[UPIN]
           ,[CCN]
           ,[HIN]
           ,[Remarks]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@Category
           ,@Type
           ,@NPI
           ,@UPIN
           ,@CCN
           ,@HIN
           ,@Remarks
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[ADM_App_Provider]')

end


GO

