

CREATE VIEW [KYPEnrollment].[v_BusinessLicenceDetails]
AS

		select A.ParentPartyid,B.PartyID,C.AddressID,B.Number as Number,D.County,D.City,E.Abreviation as State
			from KYPEnrollment.pAccount_PDM_Party A 
			inner join KYPEnrollment.pAccount_PDM_Location C on A.PartyID=c.PartyID and C.IsDeleted=0 and C.CurrentRecordFlag=1  
			inner join KYPEnrollment.pAccount_PDM_Number B  on A.Partyid=B.PartyID and C.IsDeleted=0 and C.CurrentRecordFlag=1 
			inner join KYPEnrollment.pAccount_PDM_Address D on C.AddressID=D.AddressID and C.IsDeleted=0 and C.CurrentRecordFlag=1
			inner join KYP.LK_Screening E on E.Description=D.State and TypeID=4
			where
			A.type ='ServAddrGeoLocation'


GO

