
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Taxonomy and Speciality form.   
-- PARAMETERS:  
-- @party_Id : partyID Application that will be Account. 
-- @new_party_Id : partyID to new Account that will be create.
-- @last_Action_User_Id : this is the user Enrollment.
-- ============================================================*/


CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Taxonomy_Speciality] 	
	@party_Id INT,
	@new_party_Id INT,
	@last_Action_User_Id VARCHAR(100)

AS
BEGIN
	DECLARE 
	@date_create DATE
	
	SET @date_create = GETDATE()
	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Speciality]
	([PartyID]
	,[TaxonomyCode]
	,[IsPrimary]
	,[Speciality_Code]
	,[Board]
	,[LastAction] 
	,[LastActionDate] 
	,[LastActorUserID] 
	,[LastActionApprovedBy]
	,[CurrentRecordFlag]
	,[Type])
	SELECT @new_party_Id
	,[TaxonomyCode]
	,[IsPrimary]
	,[Speciality_Code]
	,[Board]
	,'C'
	,@date_create
	,@last_Action_User_Id
	,@last_Action_User_Id
	,1
	,[Type]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Speciality] WHERE [PartyID] = @party_Id AND ([IsDeleted] = 0 OR [IsDeleted] = NULL)
	

END


GO

