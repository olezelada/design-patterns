



CREATE VIEW [KYPEnrollment].[v_OutEDI_MOCA_D_File_WeeklyReport_Reconciliation]
AS
select SSN,TIN,NPI,LegalName,DateCreated,DateDeleted,DoB,LastActionDate
from (
select 
replace(P.SSN,'-','') AS SSN,
' ' AS TIN,
P.NPI,
rtrim(ISNULL(P.lastName,''))+', '+isnull(P.FirstName,'')+' '+isnull(P.MiddleName,'')+' '+ISNULL(P.Salutation,'') LegalName,
P.DateCreated,
P.DateDeleted,
P.DoB,
PRT.LastActionDate,
ROW_NUMBER() over(partition by P.SSN order by P.NPI desc,P.lastName desc,P.DateCreated desc,P.DateDeleted desc,P.DOB desc) R
from KYPEnrollment.pAccount_PDM_Party PRT
Join KYPENROLLMENT.pADM_Account A On PRT.AccountID=A.AccountID
JOIN KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
where PRT.IsProvider=0
AND PRT.TYPE in ('Individual Ownership')
and Prt.IsDeleted=0) T
where R=1
union all
Select SSN,TIN,NPI,LegalName,DateCreated,DateDeleted,DoB,LastActionDate
from (
select
' ' AS SSN,
O.TIN as TIN,
O.NPI,
O.LegalName,
O.DateCreated,
O.DateDeleted,
NULL as DoB,
PRT.LastActionDate,
ROW_NUMBER() over(partition by O.TIN order by O.NPI desc,O.legalName desc,O.DateCreated desc,O.DateDeleted desc) R
from KYPEnrollment.pAccount_PDM_Party PRT
Join KYPENROLLMENT.pADM_Account A On PRT.AccountID=A.AccountID
JOIN [KYPEnrollment].[pAccount_PDM_Organization] O on O.PartyID=PRT.PartyID
where PRT.IsProvider=0
AND PRT.TYPE in ('Entity Ownership')
and Prt.IsDeleted=0) T
where R=1


GO

