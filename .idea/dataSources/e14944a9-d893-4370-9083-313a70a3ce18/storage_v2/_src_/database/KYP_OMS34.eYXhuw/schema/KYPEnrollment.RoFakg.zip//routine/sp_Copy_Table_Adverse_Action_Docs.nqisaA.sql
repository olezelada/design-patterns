-- =============================================
-- Author:		<Zelada Olegario>
-- Create date: <08/31/2018>
-- Description:	<copy documents instances ID to the account tables>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Table_Adverse_Action_Docs]
@party_account_id int,
@account_table_name varchar (150),
@account_pk_name varchar(150)
AS
BEGIN


  DECLARE @tot INT
	DECLARE @cont INT
	DECLARE @documentInstanceId INT, @accountAdverseActionId INT
	DECLARE @temporal TABLE(id INT IDENTITY (1, 1), documentInstanceId INT, accountAdverseActionId INT)

	INSERT INTO @temporal (documentInstanceId, accountAdverseActionId)
		SELECT appAC.documentInstanceId, accAC.AdverseActionID FROM KYPEnrollment.pAccount_PDM_AdverseAction accAc
			INNER JOIN KYPPORTAL.PortalKYP.pPDM_AdverseAction appAC on appAC.AdverseActionID = accAc.AppAdverseActionID
		WHERE accAc.PartyID = @party_account_id


	SELECT @tot = MAX(id) FROM @temporal
	SET @cont = 1;

	WHILE @cont <= @tot
		BEGIN

			SELECT
				@documentInstanceId = t.documentInstanceId,
				@accountAdverseActionId = t.accountAdverseActionId
			FROM @temporal t
			WHERE t.id = @cont
			EXEC KYPEnrollment.sp_Store_Attachments_References NULL, @documentInstanceId, @accountAdverseActionId,
																												 @account_table_name, @account_pk_name

			SET @cont = @cont + 1

		END


  END
GO

