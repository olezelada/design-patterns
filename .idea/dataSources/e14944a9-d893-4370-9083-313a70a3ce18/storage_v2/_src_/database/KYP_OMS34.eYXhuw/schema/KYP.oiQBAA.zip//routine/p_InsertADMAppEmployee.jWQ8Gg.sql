/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMAppEmployee]
(@PartyID int
 ,@ApplicationID int= NULL
 ,@Designation varchar(25) =NULL
 ,@FromDate smalldatetime = NULL
 ,@ThroughDate smalldatetime=NULL
 ,@MedicareIDNo varchar(25)=NULL
 ,@PercentageControl int=NULL
 ,@ProvideContractService varchar(5)=NULL
 ,@TypeOfService varchar(25)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[ADM_App_Employee]
           ([PartyID]
           ,[ApplicationID]
           ,[Designation]
           ,[FromDate]
           ,[ThroughDate]
           ,[Medicare ID No]
           ,[PercentageControl]
           ,[Provide Contract Service]
           ,[Type Of Service]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@ApplicationID
           ,@Designation
           ,@FromDate
           ,@ThroughDate
           ,@MedicareIDNo
           ,@PercentageControl
           ,@ProvideContractService
           ,@TypeOfService
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[ADM_App_Employee]')

end


GO

