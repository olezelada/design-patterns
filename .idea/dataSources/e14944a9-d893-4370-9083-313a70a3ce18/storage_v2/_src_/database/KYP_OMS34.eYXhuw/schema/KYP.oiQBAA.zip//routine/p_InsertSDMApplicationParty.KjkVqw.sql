

CREATE procedure [KYP].[p_InsertSDMApplicationParty]
(@ApplicationID int=NULL
 ,@ScreeningID int= NULL
 ,@PartyID int
 ,@PartyType varchar(100) = NULL
 ,@VerificationNoteID int=NULL
 ,@IsVerified bit=0
 ,@IsActive bit=1
 ,@PartyRole varchar(25)=NULL
 ,@AutoRisk int=NULL
 ,@EDDRisk int=NULL
 ,@CompositeRisk int=NULL
 ,@CreatedBy int=0
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@TypeOfParty varchar(50) = NULL
 ,@Tag varchar(50) = NULL
 
)
as begin 

INSERT INTO [KYP].[SDM_ApplicationParty]
           ([ApplicationID]
           ,[ScreeningID]
           ,[PartyID]
           ,[PartyType]
           ,[VerificationNoteID]
           ,[IsVerified]
           ,[IsActive]
           ,[PartyRole]
           ,[AutoRisk]
           ,[EDDRisk]
           ,[CompositeRisk]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[TypeOfParty]
		   ,[Tag])
     VALUES
           (@ApplicationID
           ,@ScreeningID
           ,@PartyID
           ,@PartyType
           ,@VerificationNoteID
           ,@IsVerified
           ,@IsActive
           ,@PartyRole
           ,@AutoRisk
           ,@EDDRisk
           ,@CompositeRisk
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@TypeOfParty
		   ,@Tag)

	return IDENT_CURRENT('[KYP].[SDM_ApplicationParty]')

end


GO

