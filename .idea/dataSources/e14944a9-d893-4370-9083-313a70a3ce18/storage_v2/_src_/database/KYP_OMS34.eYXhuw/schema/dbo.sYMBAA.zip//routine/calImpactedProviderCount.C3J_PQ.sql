

-- =============================================
-- Author:		Vinoth
-- Create date: 12/03/2013
-- Description:	Calculates the related impacted provider count
-- =============================================
CREATE PROCEDURE [dbo].[calImpactedProviderCount]
	@alertID INT
	,@isMerged VARCHAR(2)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @relatedProviders INT;

	-- Insert statements for procedure here
	SELECT @relatedProviders = COUNT(AlertID)
	FROM KYP.MDM_SearchProviders
	WHERE AlertID IN (
			SELECT v_AlertID
			FROM (
				(
					SELECT ChildAlertID AS v_AlertID
					FROM KYP.MDM_RelatedAlerts
					WHERE ParentAlertID = @alertID
						AND RelationshipType = 'Merged'
						AND ISNULL(IsDeleted, 0) = 0
					)
				
				UNION
				
				(
					SELECT AlertID AS v_AlertID
					FROM KYP.MDM_Alert
					WHERE AlertID = @alertID
					)
				) Z
			)
		AND Impacted = 1
		AND ISNULL(IsDeleted, 0) = 0

	IF @relatedProviders IS NULL
	BEGIN
		SET @relatedProviders = 0;
	END

	UPDATE KYP.MDM_Alert
	SET RelatedProviders = @relatedProviders
	WHERE AlertID = @alertID
END


GO

