
CREATE PROCEDURE  [KYPEnrollment].[Copy_SupplementalNRData]
  @account_id INT,
  @Number varchar(255)
AS
BEGIN
SET NOCOUNT ON 

BEGIN
--DISABLE TRIGGER [KYPEnrollment].[CreateIUDAccountData] ON [KYPEnrollment].[EDM_SupplementalInternalUse]; 


INSERT INTO [KYPEnrollment].[EDM_SupplementalInternalUse]
           ([ProvisionalCode]
           ,[ProvisionalCodeDate]
           ,[SpecProcTypeCode]
           ,[LabSpecCode]
           ,[OutOfStateInd]
           ,[PhyCertCode]
           ,[AtypicalProviderNo]
           ,[PhyCertCodeEfDate]
           ,[LabSpecCodeEfDate]
           ,[TINUpdateType]
           ,[TINUpdateDate]
           ,[RejectReasonCode]
           ,[ExceptionIndicator]
           ,[ModifiedBy]
           ,[ModifiedDate]
           ,[AccountID]
           ,[ProvisionalCodeDesc]
           ,[SpecProcTypeCodeDesc]
           ,[LabSpecCodeDesc]
           ,[OutOfStateIndDesc]
           ,[PhyCertCodeDesc]
           ,[LabStatusCodeDate]
           ,[ProvCrossReferenceDesc]
           ,[ProvCrossReferenceValue]
           ,[PracTypeCode1]
           ,[PracTypeCode2]
           ,[CHDPCode]
           ,[LabStatusCode]
           ,[CurrentPage]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionReason]
           ,[LastActionComments]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[BillingStatus]
           ,[BillingBeginDate]
           ,[BillingEndDate]
           ,[BillingFutureDate]
           ,[BillingComments]
           ,[BillingFutureComments]
           ,[PracTypeCode1Desc]
           ,[PracTypeCode2Desc]
           ,[TINUpdateTypeDesc]
           ,[County]
           ,[CountyDesc]
           ,[PrevProviderNo]
           ,[AuditIndicator]
           ,[AuditDate]
           ,[PracTypeCode]
           ,[EPSDT]
           ,[StatusACC]
           ,[StatusReasonCode]
           ,[StatusBeginDate]
           ,[ProviderTypeCode]
           ,[BillingFutureStatus]
           ,[ProvCrossReferenceCode]
           ,[OwnerEffectiveDate]
		   ,[Row_Updation_Source])
     SELECT [ProvisionalCode]
           ,A.[ProvisionalCodeDate]
           ,A.[SpecProcTypeCode]
           ,A.[LabSpecCode]
           ,A.[OutOfStateInd]
           ,A.[PhyCertCode]
           ,A.[AtypicalProviderNo]
           ,A.[PhyCertCodeEfDate]
           ,A.[LabSpecCodeEfDate]
           ,A.[TINUpdateType]
           ,A.[TINUpdateDate]
           ,A.[RejectReasonCode]
           ,A.[ExceptionIndicator]
           ,A.[ModifiedBy]
           ,A.[ModifiedDate]
           ,@account_id
           ,A.[ProvisionalCodeDesc]
           ,A.[SpecProcTypeCodeDesc]
           ,A.[LabSpecCodeDesc]
           ,A.[OutOfStateIndDesc]
           ,A.[PhyCertCodeDesc]
           ,A.[LabStatusCodeDate]
           ,A.[ProvCrossReferenceDesc]
           ,A.[ProvCrossReferenceValue]
           ,A.[PracTypeCode1]
           ,A.[PracTypeCode2]
           ,A.[CHDPCode]
           ,A.[LabStatusCode]
           ,A.[CurrentPage]
           ,A.[LastAction]
           ,A.[LastActionDate]
           ,A.[LastActorUserID]
           ,A.[LastActionReason]
           ,@Number
           ,A.[LastActionApprovedBy]
           ,A.[CurrentRecordFlag]
           ,A.[BillingStatus]
           ,A.[BillingBeginDate]
           ,A.[BillingEndDate]
           ,A.[BillingFutureDate]
           ,A.[BillingComments]
           ,A.[BillingFutureComments]
           ,A.[PracTypeCode1Desc]
           ,A.[PracTypeCode2Desc]
           ,A.[TINUpdateTypeDesc]
           ,A.[County]
           ,A.[CountyDesc]
           ,A.[PrevProviderNo]
           ,A.[AuditIndicator]
           ,A.[AuditDate]
           ,A.[PracTypeCode]
           ,A.[EPSDT]
           ,B.[StatusAcc]
           ,B.[StatusReasonCode]
           ,B.[StatusBeginDate]
           ,B.[ProviderTypeCode]
           ,B.[ownerNo]
           ,B.[ServiceLocationNo]
           ,C.[EffectiveBeingDate]
		   ,Row_Updation_Source = 'Trigger_return'
           FROM [KYPEnrollment].[EDM_AccountInternalUse] A
           inner join [KYPEnrollment].[pADM_Account] B on A.AccountID=B.AccountID
           left join [KYPEnrollment].[pAccount_Owner] c on C.AccountID=B.AccountID
           WHERE A.AccountID= @account_id;

  --ENABLE TRIGGER [KYPEnrollment].[CreateIUDAccountData] ON [KYPEnrollment].[EDM_SupplementalInternalUse]; 

  END           
           DECLARE
           @AccInternalUseID int,
           @accManyUserID int,
           @AppCount int,
           @StatusAcc varchar(50),
           @StatusReasonCode varchar(max),
           @AccountInternalUseID int,
           @CodeIdentification varchar(10),
		   @CodeDescription varchar(250),
		   @CodeType varchar(10),
           @CreatedBy varchar(100),
           @CodeDateEffDate smalldatetime,
           @StatusBeginDate smalldatetime,
           @CodeDateExpDate smalldatetime,
           @StateStatusAcc varchar(250),
           @Partyid int,
           @ProviderTypeCode varchar(5);
           
           
           SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_SupplementalInternalUse] WHERE AccountID=@account_id AND LastActionComments = @Number;
           SELECT @AccountInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_AccountInternalUse] WHERE AccountID=@account_id;

           SELECT @StatusAcc=[StatusAcc], @StatusReasonCode=[StatusReasonCode],@StatusBeginDate=[StatusBeginDate],@StateStatusAcc=StateStatusAcc
           FROM pADM_Account where AccountID=@account_id
		
		
		UPDATE KYPEnrollment.pADM_Account set SuppStatusAcc= @StatusAcc,SuppBeginDate=@StatusBeginDate, SuppReasonCode=@StateStatusAcc 
		where AccountID=@account_id
		
		Select @Partyid= Partyid from [KYPEnrollment].pADM_Account where AccountID=@account_id	
		update [KYPEnrollment].[pAccount_PDM_Speciality] set ISUpdate=1 where PartyID=@Partyid
		
	    /*SELECT @AppCount = COUNT(AccInternalUseManyID) 
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID; 
	
	PRINT 'Before Loop'
	PRINT @AppCount
	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.AccInternalUseManyID FROM(
		SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
		FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID )X WHERE X.RowNumber = @AppCount
	
		SELECT @CodeIdentification =[CodeIdentification],@CodeDescription =[CodeDescription],@CodeType =[CodeType],
		@CodeDateEffDate =[CodeDateEffDate],@CodeDateExpDate =[CodeDateExpDate],@CreatedBy =[CreatedBy]
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID =@accManyUserID
		
		INSERT INTO [KYPEnrollment].[EDM_SupplementalInteranlMany]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[AccountInternalManyID]
		)
		VALUES(
		@AccInternalUseID,
		@CodeIdentification 
		,@CodeDescription 
		,@CodeType 
		,@CodeDateEffDate
		,@CodeDateExpDate
		,'System(Auto)'
		,@accManyUserID)
		
		SET @AppCount = @AppCount - 1
		PRINT 'Inside Loop'
		PRINT @AppCount
	
	END*/

	 IF OBJECT_ID('tempdb..#AccInternalUseManyIDtemp1') IS NOT NULL
     DROP TABLE #AccInternalUseManyIDtemp1;

	Select AccInternalUseManyID --,AccountInternalUseID
	into #AccInternalUseManyIDtemp1 
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID = @AccountInternalUseID

	INSERT INTO [KYPEnrollment].[EDM_SupplementalInteranlMany]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[AccountInternalManyID]
		)

		SELECT @AccInternalUseID,
		[CodeIdentification],
		[CodeDescription],
		[CodeType],
		[CodeDateEffDate],
		[CodeDateExpDate],
	     'System(Auto)',
		 AccInternalUseManyID
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID  in (Select AccInternalUseManyID from #AccInternalUseManyIDtemp1)
		
	
END

GO

