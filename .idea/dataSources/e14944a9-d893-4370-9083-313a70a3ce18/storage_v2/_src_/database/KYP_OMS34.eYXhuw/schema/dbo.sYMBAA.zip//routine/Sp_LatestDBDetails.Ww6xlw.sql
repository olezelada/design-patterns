CREATE PROCedure [dbo].[Sp_LatestDBDetails]
As
begin
declare @val1 datetime 
declare @val3 datetime 
declare @val4 datetime 

select @val1=Max(LastLoadDate) from [HMS].[dbo].HMS_Organization_NPI

select @val3=Max(LastUpdateDate) from [MCSIS_PECOS].[dbo].PEC_STATES_Details
select @val4=Max(CreateDate) from [SANDI].[dbo].[WatchListProviderDetails] 

Update [KYP].[LatestUpdDbDetails] set LastLoadDate=@val1 where DataSources='HMS' and ExclusionList='OIG Exclusion' and SortOrder=1

Update [KYP].[LatestUpdDbDetails] set LastLoadDate=@val1 where DataSources='HMS' and ExclusionList='SAM' and SortOrder=2

Update [KYP].[LatestUpdDbDetails] set LastLoadDate=@val1 where DataSources='HMS' and ExclusionList='SSA DMF' and SortOrder=3

Update [KYP].[LatestUpdDbDetails] set LastLoadDate=@val3 where DataSources='MCSIS_PECOS' and ExclusionList='MCSIS' and SortOrder=4

Update [KYP].[LatestUpdDbDetails] set LastLoadDate=@val4 where DataSources='SANDI' and ExclusionList='S&I' and SortOrder=5

end


GO

