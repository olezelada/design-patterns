
CREATE VIEW [KYP].[v_ApplicationFeeReport] As

SELECT A.CaseID, A.ApplicationNo
,COALESCE(LTRIM(RTRIM(NULLIF(C.ApplnTypeAlias,''))),'NA') As ApplicationType
,COALESCE(LTRIM(RTRIM(NULLIF(C.ProviderName,''))),'NA') As ProviderName
,COALESCE(LTRIM(RTRIM(NULLIF(C.Provider_NPI,''))),'NA') As NPI
,COALESCE(LTRIM(RTRIM(NULLIF(C.TypeDescription,''))),'NA') As ProviderType
,COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(C.DateCreated as date), 101),''))),'NA') As AppReceivedDate
,C.DateCreated As FeeReceivedDate
,COALESCE(LTRIM(RTRIM(NULLIF(C.FeeRequired,''))),'NA') As FeeRequired
,COALESCE(LTRIM(RTRIM(NULLIF(C.FeeExempted,''))),'NA') As FeeExempted
,COALESCE(LTRIM(RTRIM(NULLIF(C.FeePaid,''))),'NA') As FeePaid
,COALESCE(LTRIM(RTRIM(NULLIF(C.FeeConfirmation,''))),'NA') As FeeConfirmation
,COALESCE(LTRIM(RTRIM(NULLIF(C.MILESTONE,''))),'NA')As MILESTONE
,CASE WHEN LOWER(C.CurrentlyAssignedToName) IN (LOWER('UserA'),LOWER('UserC'),LOWER('UserR'),LOWER('UserRef'),LOWER('UserRefAudits'),LOWER('UserRefBenefits'),
			LOWER('UserRefLegal'),LOWER('UserRefLFS'),LOWER('UserRefLicensing'),LOWER('UserRefOther')) THEN 'System (Auto)'
	ELSE  COALESCE(LTRIM(RTRIM(NULLIF(U.FullName,''))),'NA')  END As FullName
,COALESCE(LTRIM(RTRIM(NULLIF(C.ReviewerFullName,''))),'NA') As ReviewerFullName
FROM 
KYP.ADM_Case C INNER JOIN KYP.ADM_Application A ON C.Number = A.ApplicationNo 
LEFT JOIN KYP.OIS_User U ON U.PersonID = C.CurrentlyAssignedToID
WHERE 
C.IsPPURequired = 0 AND C.WFProcessing = 0 
AND (C.FeePaid = 'true' OR C.FeeExempted = 'true' OR C.FeeRequired = 'true')


GO

