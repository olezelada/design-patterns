



-- =============================================
-- Author:		Manikanta Donthu
-- Create date: 9/12/2014
-- Description:	Update the taxonomy
-- =============================================
CREATE PROCEDURE [KYP].[p_UpdatePDMTaxonomy] 
	 @TaxonomyID INT
	,@PartyID INT
	,@Taxonomy VARCHAR(20)
	,@TaxonomyDesc varchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	IF (LTRIM(RTRIM(ISNULL(@Taxonomy, '')))) = ''
	BEGIN
		SET @Taxonomy = NULL;
	END

	IF (@Taxonomy IS NOT NULL)
	BEGIN
		UPDATE KYP.PDM_Taxonomy
		SET TaxonomyDesc = @TaxonomyDesc
			,PartyID = @PartyID
			,DateModified = CONVERT(DATETIME, GETDATE(), 121)
			,Taxonomy=@Taxonomy
		WHERE TaxonomyID = @TaxonomyID
	END
END


GO

