-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[UpdateAddressRisk] 
   ON  [KYP].[PDM_Location] 
   AFTER INSERT
AS 
BEGIN
	
Declare @PartyID INT,
        @CaseID INT,
        @AddressID INT,
        @ApplicationID INT,
        @AddressLine1 varchar(150),
        @Zip varchar(50),
        @Country varchar(50),
        @State varchar(50),
        @Rangename varchar(20),
        @City varchar(50)
        
        --@CaseType varchar(25)
        
 
SET @AddressID=(Select AddressID from inserted); 
SET @AddressLine1=(Select AddressLine1 from  KYP.PDM_Address where AddressID=@AddressID);
SET @State=(Select State from  KYP.PDM_Address where AddressID=@AddressID);
SET @Country=(Select Country from  KYP.PDM_Address where AddressID=@AddressID);
SET @Zip=(Select Zip from  KYP.PDM_Address where AddressID=@AddressID);
SET @City=(Select City from  KYP.PDM_Address where AddressID=@AddressID);

SET @PartyID = (select PartyID from inserted);
SET @ApplicationID=(Select max(ApplicationID) from KYP.SDM_ApplicationParty where PartyID=@PartyID)
SET @CaseID=(Select CaseID from ADM_Application where ApplicationID=@ApplicationID);

--Set @NoofDays=Datediff(d,@DateInitiated,getdate())
--set @Rangename=KYP.AuditDays(@DateInitiated)
if @PartyID is not Null
begin
update KYP.DSH_DashBoardTable set AddressLine1=@AddressLine1,State=@State,City=@City,Zip=@Zip,Country=@Country,AddressID=@AddressID where PartyID=@PartyID and CaseID=@CaseID 
end
END


GO

