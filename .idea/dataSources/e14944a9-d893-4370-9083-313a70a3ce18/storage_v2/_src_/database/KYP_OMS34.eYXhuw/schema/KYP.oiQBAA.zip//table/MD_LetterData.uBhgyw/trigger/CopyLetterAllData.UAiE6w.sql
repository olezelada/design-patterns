













-- =============================================
-- Authors:   <Rahul Raghavendra>
-- Script Date: 17/08/2017
-- =============================================

CREATE TRIGGER [KYP].[CopyLetterAllData] ON [KYP].[MD_LetterData]
WITH EXECUTE AS CALLER
FOR insert 
AS
BEGIN	
SET NOCOUNT ON;

			DECLARE 			
			@Number varchar(20),
            @userID VARCHAR(50),
            @P_PRACT_TY_CD varchar(50),
            @LetterName varchar(200)
           		    
		    select @Number= Number from inserted
		    select @userID = UserID from inserted
		    select @P_PRACT_TY_CD = AdditionalColumn from inserted
		    select @LetterName = LetterName from inserted
		    delete from KYP.MD_AllAddresses where userid=@userID
			delete from KYP.MD_LetterAllData where userid=@userID
		    delete from KYP.MD_ExternalFindingsForLetter where userid=@userID 
		    delete from KYP.MD_LegalNameForLetter where UserID=@userID 
		    if(@P_PRACT_TY_CD='Accounts')
		    begin
		    print 'test'
		   	Execute [KYP].[sp_MD_LegalNameForLetter] @Number,@userID,@P_PRACT_TY_CD
		    Execute KYP.sp_MD_Letter_AllData @Number,@userID,@P_PRACT_TY_CD,@LetterName
		    end
		    else
		    begin
		    if(@P_PRACT_TY_CD in('RS','Rendering','NMP'))
		    begin
		 	Execute [KYP].[sp_MD_LegalNameForLetter] @Number,@userID,@P_PRACT_TY_CD
		    --Execute KYP.sp_MD_AllAddresses @Number,@userID
		    end  
		  	Execute KYP.sp_MD_Letter_AllData @Number,@userID,@P_PRACT_TY_CD,@LetterName
		    Execute KYP.sp_MD_ExternalFindingsForLetter @Number,@userID
		    end
	   
						
	
END


GO

