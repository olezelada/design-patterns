-- =============================================
-- Author:  Sheetal
-- Create date: Aug 06 2012
-- Description: Find the CLIAID of Party if received
-- =============================================
CREATE PROCEDURE [KYP].[p_FindCLIARecord]
 -- Add the parameters for the stored procedure here
 @PartyID int
 ,@CLIA_NBR varchar(15)
 ,@CurrentModule smallint 
 
AS
BEGIN
 SET NOCOUNT ON;
 
 declare @CLIAID int
 /********Get the SecNPI ID based on PartyID**********/
 if exists ( 
 select 1
 from KYP.PDM_Party A
 inner join KYP.PDM_CLIA B
  on A.PartyID = B.PartyID   
  and ISNULL(A.IsDeleted,0) = 0  
 where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0) 
  and  A.PartyID = @PartyID
  and B.CLIA_NBR = @CLIA_NBR  
 )
 begin
 select @CLIAID = CLIAID
 from KYP.PDM_Party A
 inner join KYP.PDM_CLIA B
  on A.PartyID = B.PartyID   
  and ISNULL(A.IsDeleted,0) = 0  
 where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0) 
  and  A.PartyID = @PartyID
  and B.CLIA_NBR = @CLIA_NBR  
 
    return @CLIAID 
 end 
 else 
 return -1    
END


GO

