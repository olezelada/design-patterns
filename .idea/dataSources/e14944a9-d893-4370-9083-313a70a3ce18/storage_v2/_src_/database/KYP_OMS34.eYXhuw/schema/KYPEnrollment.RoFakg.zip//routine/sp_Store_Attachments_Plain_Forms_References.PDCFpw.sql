-- =============================================
-- Author:		<HBustamante>
-- Create date: <08/10/2018>
-- Description:	<Store plain forms application account attachment references>
-- =============================================
CREATE Procedure [KYPEnrollment].[sp_Store_Attachments_Plain_Forms_References]
  (
    @accountId INT
    , @applicationId INT
  )

AS

  BEGIN

    BEGIN TRY
    DECLARE @tempAppAttachment TABLE(id INT IDENTITY(1,1), attachmentCode VARCHAR(200), status VARCHAR(30), IsDeleted BIT, SectionCode VARCHAR(50));
    DECLARE @count INT, @total INT, @attachmentCode VARCHAR(200), @sectionCode VARCHAR(50);


    IF @accountId IS NOT NULL AND @applicationId IS NOT NULL
      BEGIN

		INSERT INTO @tempAppAttachment (
			attachmentCode
			, status
			, IsDeleted
			, SectionCode)
		SELECT docfile.attachmentCode
			, docfile.status
			, docfile.isDeleted
			, docfile.sectionCode
		FROM KYPPORTAL.PortalKYP.pApplicationDocumentFile docfile
		WHERE docfile.applicationId = @applicationId
		AND docfile.partyId IS NULL
		AND docfile.documentInstanceId IS NULL
		AND docfile.isDeleted = 0
		AND docfile.applicationDocumentFileId IN (SELECT MAX(lasDocRecord.applicationDocumentFileId)
												  FROM KYPPORTAL.PortalKYP.pApplicationDocumentFile lasDocRecord
												  WHERE lasDocRecord.applicationId = docfile.applicationId
													AND lasDocRecord.attachmentCode = docfile.attachmentCode
													AND lasDocRecord.sectionCode = docfile.sectionCode )
		SELECT @total = MAX(id) FROM @tempAppAttachment
		SET @count = 1;

		WHILE @count <= @total
			BEGIN

				SELECT
					@attachmentCode = t.attachmentCode
					, @sectionCode = t.SectionCode
				FROM @tempAppAttachment t
				WHERE t.id = @count
				IF NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_Attachments
							  WHERE AttachmentCode = @attachmentCode
								AND SectionCode = @sectionCode
								AND AccountID = @accountId
								AND IsDeleted = 0)
				BEGIN
					INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, AttachmentCode, SectionCode, IsDeleted)
					VALUES(@accountId, @attachmentCode, @sectionCode, 0);
				END

				SET @count = @count + 1;

			END


        RETURN
      END

    END TRY

    BEGIN CATCH

    Exec [KYPEnrollment].[Usp_LogError] @KeyField = @applicationId,@KeyValue =@accountId

    END CATCH;

  END

GO

