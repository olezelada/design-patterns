




CREATE VIEW [KYPEnrollment].[Portable_Imaging_Technician]
AS
SELECT organization.PersonID AS TechnicianID, isnull(organization.FirstName,'')+' '+ISNULL(organization.MiddleName,'')+' '+ISNULL(organization.LastName,'') as Name,
A.AccountID as NumberID, number.Number as Number,number.State as State, 
number.Type as Type, number.EffectiveDate as EffectiveDate,number.ExpirationDate as ExpirationDate,party.PartyID  as PartyId 
FROM 
 KYPEnrollment.padm_account A
inner join  KYPEnrollment.pAccount_PDM_Party party on A.partyid=party.Parentpartyid 
inner join KYPEnrollment.pAccount_PDM_Person organization on party.PartyID=organization.PartyID
left join KYPEnrollment.pAccount_PDM_Number number on organization.partyid=number.partyid
where party.Type='TechnicianLicense'


GO

