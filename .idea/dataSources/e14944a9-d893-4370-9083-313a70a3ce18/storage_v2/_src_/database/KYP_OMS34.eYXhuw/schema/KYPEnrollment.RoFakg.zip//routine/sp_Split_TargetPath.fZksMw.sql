/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Split Target Path by Traking.   
-- PARAMETERS: 
-- @target_path : target path to Traking. 
-- @last_data : last data. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Split_TargetPath]
	@target_path VARCHAR(200),
	@last_data INT OUTPUT
AS
SET NOCOUNT ON;
BEGIN
BEGIN TRY
	DECLARE @position INT
	
	IF @target_path IS NOT NULL
	BEGIN
		SET @position = PATINDEX('%|%', @target_path)
		WHILE @position <> 0
		BEGIN
			SET @target_path = STUFF(@target_path, 1, @position, NULL)
			SET @position = PATINDEX('%|%', @target_path)	
		END
		SET @last_data = CONVERT(INT, @target_path);
		PRINT @target_path
	END
	ELSE
		SET @last_data = NULL
END TRY
BEGIN CATCH
	SET @last_data = NULL
END CATCH;
END


GO

