
/* ==========================================================
-- Author:		<ozelada>
-- PROCEDURE: create Exempt from Licensure form.
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Exempt_Licensure]
                                      @party_account_id INT,
                                      @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @questionId     INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();


   INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
                  [PartyID],
                  [Type],
                  [Name],
                  [Value],
                  [CurrentRecordFlag],
                  [IsDeleted],
                  [Description])
      SELECT @party_account_id,
             [Type],
             [Name],
             [Value],
             1,
             [IsDeleted],
             [Description]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_ProviderQuestionnarie]
       WHERE PartyID = @party_app_id AND Value = 'true' AND Name like 'exemptCheck%'


   SELECT @questionId = SCOPE_IDENTITY ();
   PRINT 'Exempt from Licensure : '
   PRINT @questionId

END


GO

