
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Affiliation.   
-- PARAMETERS: 
-- @account_id : AccountID that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @type : type of affiliation will be create.
-- @application_no : ApplicationNo that will be Account. 
-- @application_Id : ApplicationID that will be Account. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Affiliarion_Old]
@account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@type VARCHAR(200),
@application_no VARCHAR(100),
@application_Id INT

AS
BEGIN
SET NOCOUNT ON 
DECLARE @date_create DATE,@count_affiliation INT,@rendering_affiliation_id INT,@affiliation_account INT,@affiliation_id INT,@count_account_group INT,
@application_no_group VARCHAR(100),@account_id_group INT,@application_r_type VARCHAR(100),@type_affiliation VARCHAR(100),@rendering_affiliation_id_mid INT,@has_addresses BIT,@rendering_app_affiliation_id INT,@group_account_no VARCHAR(100)
SET @date_create= GETDATE();
 IF @type='rendering'
	 BEGIN 
	  EXEC @rendering_affiliation_id = [KYPEnrollment].[sp_Copy_Affiliarion_Rendering] @account_id,@party_app_id,@last_action_user_id,@application_no,@application_Id;
	  EXEC [KYPEnrollment].[sp_Copy_Affiliation_RenderingGroup] @account_id, 'R' -- KEN-8764
	  RETURN @rendering_affiliation_id;
	 END
 ELSE
  BEGIN 
  
	IF @type='Affiliation' -- Group 
	 BEGIN 
	  EXEC [KYPEnrollment].[sp_Copy_Affiliation_RenderingGroup] @account_id, 'G' -- KEN-8764
	 END
	 ELSE
	  BEGIN
		 IF EXISTS(SELECT RenderingAffiliationID FROM [KYPEnrollment].[pAccount_RenderingAffiliation] 
		 WHERE TempAffiliation = @application_id AND CurrentRecordFlag = 1) AND 
		 EXISTS (SELECT AccountID FROM [KYPEnrollment].[pADM_Account] WHERE ApplicationNumber = @application_no AND IsDeleted = 0) 
		 BEGIN
		 
		  UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation] SET AccountID = @account_id WHERE TempAffiliation = @application_id;
		  UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation] SET AffiliationStartDate = @date_create WHERE TempAffiliation = @application_id;
		  UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation] SET TempAffiliation = NULL WHERE TempAffiliation = @application_id;
	  END
	 END
  END 
  
END


GO

