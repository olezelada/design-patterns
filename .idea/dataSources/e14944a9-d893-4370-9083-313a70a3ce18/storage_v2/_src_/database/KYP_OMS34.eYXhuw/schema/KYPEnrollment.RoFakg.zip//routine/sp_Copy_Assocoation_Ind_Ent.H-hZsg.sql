

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Associations between MOCAS.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @type_ind : type association Individual. 
-- @type_end : type association Entity. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Assocoation_Ind_Ent]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@type_ind VARCHAR(100),
@type_end VARCHAR(100)
AS
BEGIN
	SET  NOCOUNT ON

	DECLARE @owner_relation_app_id INT, @owner_relation_acc_id INT, @party_owned_id INT, @type_association VARCHAR(100)
	DECLARE @date_create DATE,@owner_relation_id INT
	SET @date_create = GETDATE();	

	declare @IDS table(id int,tempid int,TypeA varchar(100))

    INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
							   ([PartyIDOwner]
							   ,[DateCreated]
							   ,[CreatedBy]
							   ,[DeletedBy]				  
							   ,[IsDeleted]
							   ,[TypeAssociation]
							   ,[FamiliarRelationship]
							   ,[FamiliarRelationshipOther]
							   ,[LastAction]
							   ,[LastActionDate]
							   ,[LastActorUserID]
							   ,[LastActionApprovedBy]
							   ,[CurrentRecordFlag]
							   ,TempRelationshipID)
							 OUTPUT inserted.OwnerRelationID,inserted.TempRelationshipID INTO @IDs(id,tempid)
					  SELECT    @party_account_id
							   ,@date_create
							   ,[CreatedBy]
							   ,PartyIDOwned
							   ,[IsDeleted]
							   ,[TypeAssociation]
							   ,[FamiliarRelationship]
							   ,[FamiliarRelationshipOther]
							   ,'C'
							   ,@date_create
							   ,@last_action_user_id
							   ,@last_action_user_id
							   ,1
							   ,OwnerRelationID
					FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] 
					WHERE (PartyIDOwner=@party_app_id) AND IsDeleted = 0 AND (TypeAssociation= 'OwnershipIndividualAssociation' OR TypeAssociation='OwnershipEntityAssociation')


		--select top 7 * from [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
		--order by OwnerRelationID desc

		--select * from @IDS

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Owner_Role] (
                        [TypeForm],
                        [OwnerRelationID],
                        [PercentCheck],
                        [PercentValue],
                        [Partner],
                        [PartnerValue],
                        [Managing],
                        [ManagingValue],
                        [Director],
                        [DirectorValue],
                        [Other],
                        [OtherValue],
                        [CreatedBy],
                        [DateCreated],
                        [IsDeleted],
                        [PercentDate],
                        [PartnerDate],
                        [ManagingDate],
                        [OtherDate],
                        [Agent],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [SoleOwner],
                        [OtherDateRole],
                        [LessPercent],
                        [BoardMember],
                        [BoardMemberDate])
            SELECT [TypeForm],
                    --pr.OwnerRelationID,
				   pr.id,
                   [PercentCheck],
                   [PercentValue],
                   [Partner],
                   [PartnerValue],
                   [Managing],
                   [ManagingValue],
                   [Director],
                   [DirectorValue],
                   [Other],
                   [OtherValue],
                   ro.[CreatedBy],
                   @date_create,
                   ro.[IsDeleted],
                   [PercentDate],
                   [PartnerDate],
                   [ManagingDate],
                   [OtherDate],
                   [Agent],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [SoleOwner],
                   [OtherDateRole],
                   [LessPercent],
                   [BoardMember],
                   [BoardMemberDate]
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role] ro
			  INNER JOIN @IDs pr ON pr.tempid = OwnerRelationID AND ro.IsDeleted = 0 AND pr .TypeA= 'OwnershipEntityAssociation'
			  --INNER JOIN [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] pr ON pr.TempRelationshipID =ro.OwnerRelationID  AND ro.IsDeleted=0 AND pr.TypeAssociation = 'OwnershipEntityAssociation'
              --WHERE OwnerRelationID  in (SELECT tempid FROM @IDs) AND IsDeleted = 0

			--select top 7 * from [KYPEnrollment].[pAccount_PDM_Owner_Role]
			--order by OwnerRelationID desc

			UPDATE [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
			SET TempRelationshipID = NULL
			WHERE OwnerRelationID in (select id from @IDS)



END

GO

