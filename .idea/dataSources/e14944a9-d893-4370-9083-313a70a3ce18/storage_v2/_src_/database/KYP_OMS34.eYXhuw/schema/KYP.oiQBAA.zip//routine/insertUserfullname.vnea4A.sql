-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[insertUserfullname]
	-- Add the parameters for the stored procedure here
	
	


AS
BEGIN

Declare
@UserID varchar(100),
@FullName varchar(100),
@AnnotationUserName varchar(50)
,@Lastname varchar(150)
,@personid int
,@Firstname varchar(150)
,@Middlename varchar(150)
,@NameToInsert varchar(100)

DECLARE mycursor CURSOR FOR 
Select USER_NAME  from dbo.ANNOTATIONSTABLE

OPEN mycursor 
FETCH NEXT FROM mycursor INTO @AnnotationUserName
WHILE @@FETCH_STATUS = 0 
BEGIN
select @personid=personid,@NameToInsert =MessageFullName from KYP.OIS_User where UserID =@AnnotationUserName


select @Lastname =LastName,@Firstname=FirstName ,@Middlename=MiddleName from KYP.OIS_Person where PersonID = @personid

if @NameToInsert is null
begin

select @NameToInsert= @Firstname+' '+@middleName+' '+@lastName

 


UPDATE [KYP].[OIS_User] SET MessageFullName=@NameToInsert   
				WHERE UserID=@AnnotationUserName;

end
FETCH NEXT FROM mycursor INTO @AnnotationUserName
END ---While
    CLOSE mycursor 
    DEALLOCATE mycursor 

END


GO

