-- =============================================
-- Author:		<cBalderrama>
-- Create date: <12/19/2017>
-- Description:	<This procedure puts in delete Subcontractor form>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Subcontractor]
@new_Account_Id int

AS
BEGIN


declare @adverse_party table (pk int identity(1,1),party int);
declare @tot_adverse int, @cont_tot_adverse int,@add_party int, @temp varchar (500);
	SET NOCOUNT ON;



INSERT INTO @adverse_party (party)
select p.PartyID from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p
ON a.PartyID=p.ParentPartyID where a.AccountID=@new_Account_Id and a.IsDeleted=0 and p.CurrentRecordFlag=1
and p.Type in ('SubcontractorEntity', 'SubcontractorIndividual')


select @tot_adverse =MAX(pk) from @adverse_party;
print @tot_adverse
SET @cont_tot_adverse =1;

WHILE @cont_tot_adverse <= @tot_adverse
BEGIN
	select @add_party = party from @adverse_party where pk = @cont_tot_adverse
  SET @temp = 'update KYPEnrollment.pAccount_PDM_Party SET CurrentRecordFlag=0,IsDeleted=1 where PartyID = ' + convert(varchar,@add_party);
  EXEC (@temp)
	SET @cont_tot_adverse = @cont_tot_adverse + 1

END

END


GO

