


CREATE VIEW [KYPEnrollment].[v_OutEDIGroupRFile]
AS
SELECT row_number() OVER (ORDER BY RenderingAffiliationID ASC) AS ID, *
FROM         
(
Select DISTINCT x.TypeAffiliation,x.RenderingAffiliationID --,x.LastUpdatedBy
,x.LastActionDate --LastActionDate for fetch the data based on specific date
,x.RequestType,x.TransactionType,x.BallingNPI,x.OwnerNo,x.ServiceLocationNo,x.ProviderTypeCode,x.GroupRenderingNPI 

from( 
select Case When(RAff.AffiliationEndDate=CONVERT(VARCHAR, GETDATE()-1, 101)) then 'DELP' else 'ADDP' END AS RequestType
,'Y' AS TransactionType
,RAff.TypeAffiliation,RAff.RenderingAffiliationID,RAff.LastActionDate,RAff.LastUpdatedBy
-- Field of pADM_Account A (Billing)
,A.NPI AS BallingNPI,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode,A.IsDeleted
-- Field of pADM_Account AR (Group Rendring)
,AR.NPI AS GroupRenderingNPI
from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
-- This is for Group Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID


) x  where x.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')AND x.LastUpdatedBy != 'M'
	AND CONVERT(VARCHAR, x.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)
) z


GO

