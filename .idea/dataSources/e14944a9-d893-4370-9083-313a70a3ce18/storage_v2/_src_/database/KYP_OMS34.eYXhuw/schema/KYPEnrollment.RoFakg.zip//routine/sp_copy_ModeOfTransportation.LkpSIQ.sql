-- =============================================
-- Author:		<Lacunza,Giresse>
-- Create date: <19/09/2017>
-- Description:	<Procedure to copy the mode of transportation>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_copy_ModeOfTransportation]
    @new_Party_Id        INT,
    @party_Id            INT,
    @last_Action_User_ID VARCHAR(100),
    @air                 BIT, @ground BIT

AS
  BEGIN
    -- SET NOCOUNT ON added to prevent extra result sets from
    -- interfering with SELECT statements.
    SET NOCOUNT ON;
    DECLARE @date_created DATE,
    @NEW_ID INT;

    SET @date_created = GETDATE();

    IF EXISTS(SELECT TABLE_NAME
              FROM INFORMATION_SCHEMA.TABLES
              WHERE TABLE_NAME = 'pAccount_PDM_ModeOfTransportation')
      BEGIN
        --AIR
        IF 1 = @air
          BEGIN


            INSERT INTO KYPEnrollment.pAccount_PDM_ModeOfTransportation (
              TypeEmergency,
              Nonemergency,
              Air,
              Helicopter,
              Fixedwing,
              Ground,
              Ambulance,
              LittlerVan,
              PartyId,
              LastAction,
              LastActionDate,
              LastActionUserID,
              DateCreated,
              CurrentRecordFlag,
              Nonmedical
            )

              SELECT
                TypeEmergency,
                Nonemergency,
                1,
                Helicopter,
                Fixedwing,
                0,
                0,
                0,
                @new_Party_Id,
                'C',
                @date_created,
                @last_Action_User_ID,
                @date_created,
                1,
                0
              FROM [KYPPORTAL].PortalKYP.pPDM_ModeOfTransportation
              WHERE PartyId = @party_Id

          END

        ----------------------------------------------------------------------------------

        --GROUND
        IF 1 = @ground
          BEGIN

            INSERT INTO KYPEnrollment.pAccount_PDM_ModeOfTransportation (
              TypeEmergency,
              Nonemergency,
              Air,
              Helicopter,
              Fixedwing,
              Ground,
              WheelchairVan,
              LittlerVan,
              Ambulance,
              TargetPath,
              PartyId,
              LastAction,
              LastActionDate,
              LastActionUserID,
              DateCreated,
              CurrentRecordFlag,
              Nonmedical
            )

              SELECT
                TypeEmergency,
                Nonemergency,
                0,
                0,
                0,
                1,
                WheelchairVan,
                LittlerVan,
                Ambulance,
                TargetPath,
                @new_Party_Id,
                'C',
                @date_created,
                @last_Action_User_ID,
                @date_created,
                1,
                Nonmedical
              FROM [KYPPORTAL].PortalKYP.pPDM_ModeOfTransportation
              WHERE PartyId = @party_Id

          END


        SELECT @NEW_ID = Scope_Identity()

        RETURN @NEW_ID;

      END

  END
GO

