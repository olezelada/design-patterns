
CREATE VIEW [KYP].[v_CaseProcess] 
AS (
    SELECT  REPLACE(substring(a.INPUTVALUE,21,30),'|ADM_Case','') CaseID 
        ,b.PROCESS_TYPE   --b.GOAL,
        ,b.EXECUTIONSTATE
        ,b.PARENT
        ,b.ACTUALSTARTTIME
        ,b.ACTUALENDTIME  --,b.PLANNEDSTARTTIME
        ,b.PLANNEDDURATION
        ,b.DISPLAYNAME   --,b.ERRORMESSAGE
        ,b.PERCENTCOMPLETED
        ,a.INPUTNAME,a.INPUTTYPE,a.INPUTVALUE,a.PROCESS_TYPE as PROCESSTYPE
    FROM(
        SELECT INPUTNAME
            ,INPUTTYPE
            ,INPUTVALUE
            ,PROCESS_TYPE
            ,PROCESSID
        FROM dbo.PROCESS_INPUTS_TABLE
        where INPUTTYPE = 'ADM_Case' --and INPUTVALUE like '%|ADM_Case%'
    ) a
    INNER JOIN dbo.PROCESS_TABLE b
    ON a.PROCESSID = b.PROCESSID
);


GO

