


CREATE VIEW [KYPEnrollment].[v_SignificantTranWO]
As
SELECT 
	party.partyid
	,account.AccountID as AccountID
	,tax.taxIDprofileID as TaxProfileID
	,org.LegalName
	,ISNULL(addr.AddressLine1, '') + ', ' + ISNULL(addr.AddressLine2, '') + ', ' + ISNULL(addr.City, '') + ', ' + ISNULL(addr.STATE, '') + ', ' + ISNULL(addr.County, '') + ', ' + ISNULL(addr.ZipPlus4, '') AS Address
	,ISNULL(ISNULL(org.Phone1, org.Phone2), 'NA') AS 'Phone'
	,orgtxn.Description
FROM KYPEnrollment.pAccount_PDM_Party party
	,KYPEnrollment.pADM_Account account
	,KYPEnrollment.pAccount_PDM_Organization org
	,KYPEnrollment.pAccount_PDM_OwnerhipTransaction orgtxn
	,KYPEnrollment.pAccount_PDM_Location loc
	,KYPEnrollment.pAccount_PDM_Address addr
	,KYPEnrollment.pAccount_BizProfile_Details profileDetails
	,KYPEnrollment.TaxIDProfile tax
WHERE party.PartyID = org.PartyID
	AND account.AccountID = party.AccountID
	AND org.PartyID = orgtxn.PartyID
	AND party.PartyID = loc.PartyID
	AND addr.addressid = loc.addressid 
	AND profileDetails.AccountID = party.AccountID
	AND tax.profileID = profileDetails.ProfileID AND tax.taxID = ISNULL(account.EIN,account.SSN)
	AND party.Type = 'WhollyOwnedSupplied'
	AND party.CurrentRecordFlag = '1'


GO

