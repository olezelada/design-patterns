

/*
    Update the view OIS_RoleSubRole
*/
CREATE VIEW [KYP].[OIS_RoleSubRole] AS SELECT * FROM dbo.RoleSubRoleTable


GO

