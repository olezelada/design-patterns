CREATE PROCEDURE [dbo].[p_LoadPotentiallyRelatedAlerts]
as 
begin

DECLARE @pmfloaddate DATETIME

SELECT TOP 1 @pmfloaddate = fileloaddate
FROM KYP.MDM_MonthlyActiveProvider
ORDER BY id DESC

create table #AlertParties
(
AlertID int ,
WatchedPartyID int,
WatchedPartyType varchar(100),
FName varchar(50),
LName varchar(50),
MName varchar(50),
SSN varchar(15),
DOB datetime,
OrgName varchar(500),
TIN varchar(15),
AssignedToUserID int,
WFStatus varchar(150),
StatusCodeNumber int
)

create table #RelatedAlerts
(
XAlertID int ,
XWatchedPartyID int,
YAlertID int,
YWatchedPartyID int,
MatchCriteria varchar(500)
)



insert into #AlertParties (AlertID, WatchedPartyID,AssignedToUserID,WFStatus,StatusCodeNumber)
select distinct 
AlertID,
WatchedPartyID,AssignedToUserID,WFStatus,StatusCodeNumber
from KYP.MDM_Alert 
where DateInitiated > @pmfloaddate

--AssignedToUserID is null and WFStatus ='AssignAlert' and StatusCodeNumber =0
update A
set 
A.WatchedPartyType = B.Type
,A.FName = C.FirstName
,A.LName = C.LastName
,A.MName = C.MiddleName
,A.SSN = C.SSN
,A.DOB = C.DoB
from 
#AlertParties A
inner join KYP.PDM_Party B
on A.WatchedPartyID = B.PartyID and B.CurrentModule = 2 and B.IsDeleted <> 1
inner join KYP.PDM_Person C
on A.WatchedPartyID = C.PartyID 




update A
set 
A.WatchedPartyType = B.Type
,A.OrgName = C.LegalName
,A.TIN = C.TIN
from 
#AlertParties A
inner join KYP.PDM_Party B
on A.WatchedPartyID = B.PartyID and B.CurrentModule = 2 and B.IsDeleted <> 1
inner join KYP.PDM_Organization C
on A.WatchedPartyID = C.PartyID 

/*******Same SSN Match******/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'Same SSN' as MatchCriteria
 from 
#AlertParties A
inner join #AlertParties B 
on A.SSN = B.SSN 
where A.AlertID <> B.AlertID 
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0

/*****First Name, Last Name and Date of Birth are matching*******/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'First Name, Last Name and Date of Birth are matching' as MatchCriteria
from 
#AlertParties A
inner join #AlertParties B
on A.FName = B.FName and A.LName = B.LName 
	and datepart(year,A.DOB) = datepart(year,B.DOB) 
	and datepart(MONTH,A.DOB) = datepart(MONTH,B.DOB) 
	and datepart(DAY,A.DOB) = datepart(DAY,B.DOB) 
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0



/*****First Name and Last Name are matching*******/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'First Name and Last Name are matching' as MatchCriteria
from 
#AlertParties A
inner join #AlertParties B
on A.FName = B.FName and A.LName = B.LName 	
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0




/*******Last Name and the first alphabet of First Name is matching********/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'Last Name and the first alphabet of First Name is matching' as MatchCriteria
from 
#AlertParties A
inner join #AlertParties B
on A.LName = B.LName and LEFT(A.FName, 1) =  LEFT(B.FName, 1)
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0


/*******First Name and the first alphabet of Last Name is matching******/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'First Name and the first alphabet of Last Name is matching' as MatchCriteria
from 
#AlertParties A
inner join #AlertParties B
on A.FName = B.FName and LEFT(A.LName, 1) =  LEFT(B.LName, 1)
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0



/*********Last Name and last 4 digits of SSN are matching***********/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'Last Name and last 4 digits of SSN are matching' as MatchCriteria
from 
#AlertParties A
inner join #AlertParties B
on A.LName = B.LName and RIGHT(A.SSN, 4) =  RIGHT(B.SSN, 4)
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0




/*******Tax ID is matching******/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'Tax ID is matching' as MatchCriteria
 from 
#AlertParties A
inner join #AlertParties B
on A.TIN = B.TIN
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0



/********Name is matching*************/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'Name is matching' as MatchCriteria
 from 
#AlertParties A
inner join #AlertParties B
on A.OrgName = B.OrgName
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0




/******First 15 characters of Name and last 4 digits of Tax-ID are matching*****/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'First 15 characters of Name and last 4 digits of Tax-ID are matching' as MatchCriteria
 from 
#AlertParties A
inner join #AlertParties B
on LEFT(A.OrgName, 15) = LEFT(B.OrgName, 15) and RIGHT(A.TIN, 4) = RIGHT(B.TIN, 4)
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0



/**********First 15 characters of Name are matching*********/
insert into 
#RelatedAlerts(XAlertID, XWatchedPartyID, YAlertID, YWatchedPartyID,MatchCriteria)
select 
A.AlertID as XAlertID
,A.WatchedPartyID as XWatchedPartyID
,B.AlertID as YAlertID
,B.WatchedPartyID as YWatchedPartyID
,'First 15 characters of Name are matching' as MatchCriteria
 from 
#AlertParties A
inner join #AlertParties B
on LEFT(A.OrgName, 15) = LEFT(B.OrgName, 15) 
where A.AlertID <> B.AlertID
and B.AssignedToUserID is null and B.WFStatus ='Assign Alert' and B.StatusCodeNumber =0




/**********Remove alerts which are already related*********/
select 
Z.XAlertID
,Z.XWatchedPartyID
,Z.YAlertID
,Z.YWatchedPartyID
into #RelatedAlertsWithExcept 
from
(
select 
XAlertID
,XWatchedPartyID
,YAlertID
,YWatchedPartyID
 from #RelatedAlerts
 
			except 

select 
RelAlt.ParentAlertID as XAlertID
,ParAlert.WatchedPartyID as XWatchedPartyID
,RelAlt.ChildAlertID as YAlertID
,ChldAlert.WatchedPartyID as YWatchedPartyID
from 
KYP.MDM_RelatedAlerts RelAlt 
inner join KYP.MDM_Alert ParAlert 
      on  RelAlt.ParentAlertID = ParAlert.AlertID 
inner join KYP.MDM_Alert ChldAlert 
      on  RelAlt.ChildAlertID = ChldAlert.AlertID 
where RelAlt.IsDeleted <> 1
      

            except

select 
RelAlt.ChildAlertID as XAlertID
,ChldAlert.WatchedPartyID as XWatchedPartyID
,RelAlt.ParentAlertID as YAlertID
,ParAlert.WatchedPartyID as YWatchedPartyID
  
from 
KYP.MDM_RelatedAlerts RelAlt 
inner join KYP.MDM_Alert ParAlert 
      on  RelAlt.ParentAlertID = ParAlert.AlertID 
inner join KYP.MDM_Alert ChldAlert 
      on  RelAlt.ChildAlertID = ChldAlert.AlertID 
where RelAlt.IsDeleted <> 1
) Z

DELETE x
FROM (
	SELECT *
		,ROW_NUMBER() OVER (
			PARTITION BY XAlertID
			,YAlertID
			,MatchCriteria ORDER BY XAlertID DESC
			) AS row1
	FROM #RelatedAlerts
	WHERE XAlertID IS NOT NULL
	) x
WHERE x.row1 > 1

/**********Populate Potentially Related Alert table*********/

INSERT INTO [KYP].[MDM_PotentiallyRelatedAlerts]
([AlertID]
,[PotentiallyRelatedAlertID]
,[MatchCriteria]
,[CreatedDate]
)

select 
A.XAlertID
,A.YAlertID
,A.MatchCriteria 
,GETDATE()
from #RelatedAlerts A 
inner join #RelatedAlertsWithExcept B
on 
	A.XAlertID = B.XAlertID 
	and A.XWatchedPartyID = B.XWatchedPartyID
	and A.YAlertID = B.YAlertID 
	and A.YWatchedPartyID = B.YWatchedPartyID
	
	
drop table #AlertParties
drop table #RelatedAlerts
drop table #RelatedAlertsWithExcept	

end
GO

