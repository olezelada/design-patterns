



/* ==========================================================
-- Author:		<Mvillarroel>

-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_OneTimeUpdate_PartyAssociate]
 	
AS

BEGIN
declare @cont       int,
        @UniqueID   int
        

CREATE TABLE #TempUnique
	(
		ID			INT PRIMARY KEY IDENTITY(1,1),
		Uniqueid	int
		)

insert into #TempUnique 
select UniqueMOCAsProfileTINwiseID 
from KYPEnrollment.UniqueMOCAsProfileTINwise where IsDeleted =0 and currentrecordflag=1
set @cont=1
WHILE @cont <= (SELECT COUNT(*) FROM #TempUnique)
BEGIN
  SELECT @UniqueID=Uniqueid 
  FROM #TempUnique WHERE ID = @cont
  exec [KYPEnrollment].[sp_Update_PartyAssociate] @uniqueid
  set @cont=@cont+1
END
drop table #TempUnique
--recovery all taxid, accountid of accounts that not have mocas
SELECT	ACC.ACCOUNTID,BPM.ProfileID,ACC.EIN AS TaxID,acc.AccountNumber,acc.PartyID as Partyid_account
into #Tempacc
FROM KYPEnrollment.pADM_Account ACC
inner JOIN KYPEnrollment.pAccount_Owner OWN ON ACC.AccountID = OWN.AccountID
inner JOIN KYPEnrollment.pAccount_BizProfile_Details BPD 	ON ACC.AccountID	= BPD.AccountID
inner join KYPEnrollment.pAccount_BizProfile_Master BPM 	ON BPD.ProfileId	= BPM.ProfileId
left JOIN KYPEnrollment.pAccount_PDM_Party P ON ACC.PartyID		= P.ParentPartyID and P.Type IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity','Individual Ownership','Entity Ownership') 
and p.CurrentRecordFlag = 1
WHERE	ACC.PackageName		IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND 
(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
BPM.ProfileID		IS NOT NULL AND
isnull(ACC.EIN,'')<> '' and
ACC.IsDeleted		= 0			AND
IsTempProfile		= 0			AND
IsPastOwner=0 and 
p.PartyID is null 
and acc.NPI  NOT LIKE '%[a-z]%'
--only active accounts
and LEFT(acc.StatusAcc,1)  IN ('1','7','9')

--insert into paccount_Taxid_associate
insert into kypenrollment.pAccount_TaxID_Associate(AccountID,PartyID,EntityID,TaxID,CurrentRecordFlag ) 
select AccountID,partyid_account,AccountNumber ,taxid,1 from #Tempacc  except
select AccountID,PartyID,EntityID,taxid,1 from kypenrollment.pAccount_TaxID_Associate 

drop table #Tempacc

end


GO

