
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Ownership Relationship : recive 4 para metros
-- @ownerRelationID, @newPartyIDOwner ,@newPartyIDOwned INT, @lastActionUserID
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_OwnershipRelationship]
	@ownerRelationID INT,
	@newPartyIDOwner INT,
	@newPartyIDOwned INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @newOwnerRelationID int,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()
	SET @newOwnerRelationID=0
	
	IF((SELECT COUNT([OwnerRelationID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] WHERE [OwnerRelationID] = @ownerRelationID)>0)
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
		([PartyIDOwner]
		,[PartyIDOwned]
		,[LastAction] 
		,[LastActionDate] 
		,[LastActorUserID] 
		,[LastActionApprovedBy] 
		,[CurrentRecordFlag]
		,[TypeAssociation]
		,[TransDescription]
		,[FamiliarRelationship]
		,[FamiliarRelationshipOther])
		SELECT @newPartyIDOwner 
		,@newPartyIDOwned
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
		,[TypeAssociation]
		,[TransDescription]
		,[FamiliarRelationship]
		,[FamiliarRelationshipOther]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] WHERE [OwnerRelationID] = @ownerRelationID

		SELECT @newOwnerRelationID = Scope_Identity()
		SELECT @message = '[pAccount_PDM_OwnershipRelationship] @newOwnerRelationID : ' + CONVERT(char(10), @newOwnerRelationID)
		RAISERROR(@message, 0, 1) WITH NOWAIT	
	END	
	RETURN  @newOwnerRelationID				
END


GO

