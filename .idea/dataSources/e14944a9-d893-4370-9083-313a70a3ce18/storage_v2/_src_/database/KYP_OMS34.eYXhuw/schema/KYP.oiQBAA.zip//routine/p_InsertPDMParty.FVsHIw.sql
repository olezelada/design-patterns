

/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMParty]
(
 @Type varchar(15)= NULL
 ,@Name varchar(100) =NULL
 ,@IsProvider bit = 0
 ,@IsEnrolled bit=1
 ,@IsTemp bit=0
 ,@IsActive bit=1
 ,@LoadType varchar(50)=NULL
 ,@LoadID varchar(20)=NULL
 ,@LastLoadDate Datetime=NULL 
 ,@DateModified Datetime=NULL
 ,@IsDeleted bit=0
 ,@Source varchar(15)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
 ,@CurrentModule smallint=NULL
 ,@TypeOfParty varchar(50) = NULL

)
as begin 

INSERT INTO [KYP].[PDM_Party]
           ([Type]
           ,[Name]
           ,[IsProvider]
           ,[IsEnrolled]
           ,[IsTemp]
           ,[IsActive]
           ,[LoadType]
           ,[LoadID]
           ,[LastLoadDate]
           ,[DateModified]
           ,[IsDeleted]
           ,[Source]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[CurrentModule]
           ,[TypeOfParty])
     VALUES
           (@Type
           ,@Name
           ,@IsProvider
           ,@IsEnrolled
           ,@IsTemp
           ,@IsActive
           ,@LoadType
           ,@LoadID
           ,@LastLoadDate
           ,@DateModified
           ,@IsDeleted
           ,@Source
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DeletedBy
           ,@DateDeleted
           ,@CurrentModule
           ,@TypeOfParty)

	return IDENT_CURRENT('[KYP].[PDM_Party]')

end


GO

