
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Account Main Procedure.   
-- PARAMETERS: 
-- @application_Id : ApplicationId that have the diaffiliation. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Disaffiliation_Account] 
 @party_id INT
AS
BEGIN
 DECLARE @target_path VARCHAR(200),@affiliation_id INT,@posicion INT,@length INT, @string VARCHAR(100),@count INT
	BEGIN TRY 
		IF (SELECT COUNT(CurrentAffiliationID) FROM [KYPPORTAL].[PortalKYP].[pPDM_CurrentAffiliation] WHERE PartyID=@party_id AND IsAffilied=0)>0
		BEGIN 
		UPDATE KYPEnrollment.pAccount_RenderingAffiliation SET CurrentRecordFlag=0 where  RenderingAffiliationID in 
		  (select SUBSTRING(targetpath,charindex('RenderingAffiliationID',TargetPath,1)+23,LEN(targetpath)) as id from kypportal.portalkyp.pPDM_CurrentAffiliation WHERE PartyID=@party_id AND IsAffilied=0 )

		PRINT 'DIS-AFFILIATION'
		END
	END TRY
	BEGIN CATCH	
		IF @@TranCount>0
			Rollback Transaction;		
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'party_id',@KeyValue = @party_id;
	END CATCH	
END


GO

