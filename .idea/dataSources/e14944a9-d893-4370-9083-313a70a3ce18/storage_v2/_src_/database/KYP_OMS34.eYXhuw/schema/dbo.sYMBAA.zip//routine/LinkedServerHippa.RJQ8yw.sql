
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[LinkedServerHippa]
@HippaServerName VARCHAR(250)
AS

BEGIN

DECLARE 
@HippaLoginServer VARCHAR(100),
@ExistCount2 INT


SET @HippaLoginServer = ''+ @HippaServerName +''


	SELECT @ExistCount2 = COUNT(1) FROM sys.servers WHERE name = @HippaLoginServer
	
	IF @ExistCount2 = 0
		BEGIN
			EXECUTE sp_addlinkedserver @HippaLoginServer
		END

END


GO

