-- =============================================
-- Author:  Sheetal
-- Create date: Aug 06 2012
-- Description: Find the MCAREID of Party if received
-- =============================================
CREATE PROCEDURE [KYP].[p_FindProviderSpeciality]
 -- Add the parameters for the stored procedure here
 @PartyID int
 ,@Speciality_Code varchar(20)
 ,@CurrentModule smallint
 
AS
BEGIN
 SET NOCOUNT ON;
 
 declare @SpecialityID int
 /********Get the SecNPI ID based on PartyID**********/
 if exists ( 
 select 1
 from KYP.PDM_Party A
 inner join KYP.PDM_Speciality B
  on A.PartyID = B.PartyID   
  and ISNULL(A.IsDeleted,0) = 0  
 where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0) 
  and  A.PartyID = @PartyID
  and B.Speciality_Code = @Speciality_Code  
 )
 begin
 select @SpecialityID = B.SpecialityID 
 from KYP.PDM_Party A
 inner join KYP.PDM_Speciality B
  on A.PartyID = B.PartyID   
  and ISNULL(A.IsDeleted,0) = 0  
 where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0) 
  and  A.PartyID = @PartyID
  and B.Speciality_Code = @Speciality_Code  
 
    return @SpecialityID 
 end 
 else 
 return -1    
END


GO

