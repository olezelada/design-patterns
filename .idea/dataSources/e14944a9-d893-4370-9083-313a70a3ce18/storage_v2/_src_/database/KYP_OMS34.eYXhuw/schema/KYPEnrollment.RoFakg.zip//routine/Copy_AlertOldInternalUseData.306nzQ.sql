








-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_AlertOldInternalUseData] 

@AlertNo varchar (10), @AlertID int, @AccountId int, @MedicaidID varchar(50), @AlertIUD int, @ProviderTypeCode varchar(10)
	
AS
BEGIN

		Update A
			Set A.AccountID=@AccountId,
				A.EnrollStatusAcc=B.StatusAcc,
				A.EnrollStatusBeginDate=B.StatusBeginDate,
				A.EnrollStatusComments=B.StatusReasonCode,
				A.EnrollStatusReasonCode=B.EnrollStatusComments,
				A.serviceLocNo=B.ServiceLocationNo,
				A.OwnerNo=B.OwnerNo,
				A.NPI=B.NPI,
				A.ProviderTypeCode=B.ProviderTypeCode,
				A.ProviderTypeDecs=B.ProviderType,
				A.OwnerEffectiveDate=C.EffectiveBeingDate,
				A.BillingStatus=D.BillingStatus,
				A.BillingBeginDate=D.BillingBeginDate,
				A.BillingComments=D.BillingComments,
				A.ProvisionalCode=D.ProvisionalCode,
				A.ProvisionalCodeDesc=D.ProvisionalCodeDesc,
				A.ProvisionalCodeDate=D.ProvisionalCodeDate,
				A.LabStatusCode=D.LabStatusCode,
				A.LabStatusCodeDesc=D.LabSpecCodeDesc,
				A.LabStatusCodeDate=D.LabStatusCodeDate,
				A.PracticeTypeEntityCode=D.PracTypeCode1,
				A.PracticeTypeEntityCodeDesc=D.PracTypeCode1Desc,
				A.PracticeTypeRegisteredCode=D.PracTypeCode2,
				A.PracticeTypeRegisteredCodeDesc=D.PracTypeCode2Desc,
				A.TINType=D.TINUpdateType,
				A.TINTypeDesc=D.TINUpdateTypeDesc,
				A.TINDate=D.TINUpdateDate,
				A.OutOfStateInd=D.OutOfStateInd,
				A.OutOfStateIndDesc=D.OutOfStateIndDesc,
				A.SpecProcTypeCode=D.SpecProcTypeCode,
				A.SpecProcTypeCodeDesc=D.SpecProcTypeCodeDesc,
				A.CHDPCode=D.CHDPCode,
				A.AtypicalProviderNo=D.AtypicalProviderNo,
				A.ReEnrolInd=D.ReEnrolInd,
				A.ReEnrolDate=D.ReEnrolDate
			
			from KYPEnrollment.EDM_AlertlInternalUse A
			inner join KYPEnrollment.padm_account B on B.AccountID=@AccountId
			inner join KYPEnrollment.pAccount_Owner C on C.AccountId=B.AccountId
			inner join KYPEnrollment.EDM_AccountInternalUse D on D.AccountID=B.AccountID and D.IsApproved=1
			where A.MedicaidID= @MedicaidID and A.AlertID=@AlertID and A.AlertNo=@AlertNo and A.ProviderTypeCode=@ProviderTypeCode
			
			
			insert into KYPEnrollment.EDM_AlertInteranlMany(
				AlertIUD,
				CodeIdentification,
				CodeDescription,
				CodeType,
				CodeDateEffDate,
				CodeDateExpDate,
				isDeleted,
				StatusCodeNumber,
				TooltipStatus,
				IsTemporal,
				InitiatedByUser,
				InitiatedOnMS,
				TemporalKey,
				CurrentPage,
				TempAction,
				LastAction,
				LastActionDate,
				LastActorUserID,
				LastActionReason,
				LastActionComments,
				LastActionApprovedBy,
				CurrentRecordFlag,
				CreatedBy,
				ModifiedBy
			) 
			
			select 
					@AlertIUD,
					B.CodeIdentification,
					B.CodeDescription,
					B.CodeType,
					B.CodeDateEffDate,
					B.CodeDateExpDate,
					B.isDeleted,
					B.StatusCodeNumber,
					B.TooltipStatus,
					B.IsTemporal,
					B.InitiatedByUser,
					B.InitiatedOnMS,
					B.TemporalKey,
					B.CurrentPage,
					B.TempAction,
					B.LastAction,
					B.LastActionDate,
					B.LastActorUserID,
					B.LastActionReason,
					B.LastActionComments,
					B.LastActionApprovedBy,
					B.CurrentRecordFlag,
					B.CreatedBy,
					B.ModifiedBy
			from KYPEnrollment.EDM_AccountInternalUse A
			inner join KYPEnrollment.EDM_AccountInternalMany B on A.AccountInternalUseID=B.AccountInternalUseID
			where AccountID=@AccountId  and isnull(B.isDeleted,0) = 0 and A.IsApproved=1 and B.IsApproved=1 --AND B.CurrentRecordFlag = 1(KEN-19352)
	

	
END


GO

