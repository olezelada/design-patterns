
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Owner Role.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @owner_relation_id : OwnerRelationID Application that will be Create in Update Account or Create Association, it is Null when account is create.
-- @acc_owner_relation_id : this is the OwnerRelationID Account that will be Create in Update Account or Create Association, it is Null when account is create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Owner_Role]
   @party_account_id         INT,
   @party_app_id             INT,
   @last_action_user_id      VARCHAR (100),
   @owner_relation_id        INT,
   @acc_owner_relation_id    INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE;
   SET @date_created = GETDATE ();

   IF @owner_relation_id IS NULL AND @acc_owner_relation_id IS NULL
      BEGIN
         INSERT INTO [KYPEnrollment].[pAccount_PDM_Owner_Role] (
                        [TypeForm],
                        [PercentCheck],
                        [PercentValue],
                        [Partner],
                        [PartnerValue],
                        [Managing],
                        [ManagingValue],
                        [Director],
                        [DirectorValue],
                        [Other],
                        [OtherValue],
                        [ExecutiveDirector],
                        [ClinicalDirector],
                        [CreatedBy],
                        [DateCreated],
                        [IsDeleted],
                        [PercentDate],
                        [PartnerDate],
                        [ManagingDate],
                        [OtherDate],
                        [Agent],
                        [PartyID],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [SoleOwner],
                        [OtherDateRole],
                        [LessPercent],
                        [BoardMember],
                        [BoardMemberDate],
                        [IsOwner])
            SELECT [TypeForm],
                   [PercentCheck],
                   [PercentValue],
                   [Partner],
                   [PartnerValue],
                   [Managing],
                   [ManagingValue],
                   [Director],
                   [DirectorValue],
                   [Other],
                   [OtherValue],
                   [ExecutiveDirector],
                   [ClinicalDirector],
                   [CreatedBy],
                   @date_created,
                   [IsDeleted],
                   [PercentDate],
                   [PartnerDate],
                   [ManagingDate],
                   [OtherDate],
                   [Agent],
                   @party_account_id,
                   'C',
                   @date_created,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [SoleOwner],
                   [OtherDateRole],
                   [LessPercent],
                   [BoardMember],
                   [BoardMemberDate],
                   [IsOwner]
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role]
             WHERE PartyID = @party_app_id
      END
   ELSE
      BEGIN
         INSERT INTO [KYPEnrollment].[pAccount_PDM_Owner_Role] (
                        [TypeForm],
                        [OwnerRelationID],
                        [PercentCheck],
                        [PercentValue],
                        [Partner],
                        [PartnerValue],
                        [Managing],
                        [ManagingValue],
                        [Director],
                        [DirectorValue],
                        [Other],
                        [OtherValue],
                        [ExecutiveDirector],
                        [ClinicalDirector],
                        [CreatedBy],
                        [DateCreated],
                        [IsDeleted],
                        [PercentDate],
                        [PartnerDate],
                        [ManagingDate],
                        [OtherDate],
                        [Agent],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [SoleOwner],
                        [OtherDateRole],
                        [LessPercent],
                        [BoardMember],
                        [BoardMemberDate],
                        [IsOwner])
            SELECT [TypeForm],
                   @acc_owner_relation_id,
                   [PercentCheck],
                   [PercentValue],
                   [Partner],
                   [PartnerValue],
                   [Managing],
                   [ManagingValue],
                   [Director],
                   [DirectorValue],
                   [Other],
                   [OtherValue],
                   [ExecutiveDirector],
                   [ClinicalDirector],
                   [CreatedBy],
                   @date_created,
                   [IsDeleted],
                   [PercentDate],
                   [PartnerDate],
                   [ManagingDate],
                   [OtherDate],
                   [Agent],
                   'C',
                   @date_created,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [SoleOwner],
                   [OtherDateRole],
                   [LessPercent],
                   [BoardMember],
                   [BoardMemberDate],
                   [IsOwner]
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Owner_Role]
             WHERE OwnerRelationID = @owner_relation_id AND IsDeleted = 0
      END
END


GO

