


-- =============================================
-- Author:		Amita Karan
-- Create date: Sep 15 2014
-- Description:	Finds if the NPI exists
-- =============================================
CREATE PROCEDURE [KYP].[p_FindPDMProviderProfile]
	-- Add the parameters for the stored procedure here
	 @NPI int=NULL
     ,@TIN varchar(11)=NULL
     ,@SSN varchar(11)=NULL
	 ,@PracticeType varchar(50)=NULL
	 --,@foundorNot int output
	
AS
BEGIN
	SET NOCOUNT ON;	
	declare @pro_ID int			
			
	/********Check if NPI exists**********/
	if exists (	
	select 1
	from KYP.PDM_ProviderProfile where NPI = @NPI or (SSN=@SSN AND PracticeType=@PracticeType) 
										or (TIN=@TIN AND PracticeType=@PracticeType))
	begin	
	select @pro_ID = ProfileID
	from KYP.PDM_ProviderProfile
	where NPI = @NPI or (SSN=@SSN AND PracticeType=@PracticeType)
					 or (TIN=@TIN AND PracticeType=@PracticeType)
	return @pro_ID	
	end	
	else 
	return -1  	
END


GO

