



/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Subcontractor Association Table.   
-- PARAMETERS: 
-- @acc_parent_party_id : partyID Provider to new Account that will be create. 
-- @acc_party_owner_id : partyID Owner Account will be associate.
-- @parent_party_id : partyID Provider to Application that will be Account. 
-- @party_owner_id : partyID Owner Application is associate. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Subcontractor_Ownership]
   @acc_parent_party_id    INT,
   @acc_party_owner_id     INT,
   @parent_party_id        INT,
   @party_owner_id         INT,
   @last_action_user_id    VARCHAR (100),
   @account_id             INT
AS
BEGIN
   DECLARE
      @app_owner_relation_id     INT,
      @acc_owner_relation_id     INT,
      @party_subcontractor       INT,
      @full_name_person          VARCHAR (100),
      @acc_party_subcontractor   INT,
      @party_type                VARCHAR (50),
      @count_association         INT,
      @type_association          VARCHAR (100),
      @is_prepopulated           BIT,
      @org_id                    INT,
      @person_id                 INT,
      @legal_name                VARCHAR (150),
      @type                      VARCHAR (50),
      @target_path               VARCHAR (200),
      @main_party_id             INT;

   DECLARE @subcon_asso TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           Type             VARCHAR (50),
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200)
                        )
   DECLARE @party_prepopulate TABLE
                              (
                                 pk          INT IDENTITY (1, 1),
                                 PartyID     INT,
                                 LegalName   VARCHAR (150),
                                 Type        VARCHAR (100)
                              )

   INSERT INTO @subcon_asso
      SELECT PartyID,
             Type,
             IsPrepopulated,
             part.TargetPath
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] part
             INNER JOIN
             [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship] rel
                ON part.PartyID = rel.PartyIDOwned
       WHERE     rel.PartyIDOwner = @party_owner_id
             AND rel.isdeleted = 0
             AND (   Type = 'SubcontractorEntity'
                  OR Type = 'SubcontractorIndividual'
                  OR TYPE = 'SubcontractorOwnerIndividual'
                  OR TYPE = 'SubcontractorOwnerEntity')
             AND (part.IsDeleted IS NULL OR part.IsDeleted = 'false')
             AND (   ParentPartyID = @parent_party_id
                  OR ParentPartyID IN
                        (SELECT PartyID
                           FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                          WHERE     ParentPartyID = @parent_party_id
                                AND (   Type = 'SubcontractorEntity'
                                     OR Type = 'SubcontractorIndividual')
                                AND (IsDeleted IS NULL OR IsDeleted = 'false')));


   DECLARE
      @cont   INT,
      @tot    INT
   SELECT @tot = MAX (pk) FROM @subcon_asso
   SET @cont = 1

   WHILE @cont <= @tot
   BEGIN
      SELECT @party_subcontractor = PartyID,
             @party_type = Type,
             @is_prepopulated = IsPrepopulated,
             @target_path = TargetPath
      FROM @subcon_asso
      WHERE pk = @cont
      SELECT @count_association = COUNT (OwnerRelationID)
        FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
       WHERE     PartyIDOwner = @party_owner_id
             AND PartyIDOwned = @party_subcontractor
             AND (   TypeAssociation = 'SubcontractorEntityAssociation'
                  OR TypeAssociation = 'SubcontractorIndividualAssociation'
                  OR TypeAssociation =
                        'SubcontractorIndividualOwnerAssociation')
             AND IsDeleted = 0;


      IF @count_association > 0
         BEGIN
            --1
            --if assoc with party new
            IF EXISTS
                  (SELECT *
                     FROM #subcontractors
                    WHERE PartyID_Portal = @party_subcontractor)
               BEGIN
                  SELECT @acc_party_subcontractor = PartyID_Enroll
                  FROM #subcontractors
                  WHERE PartyID_Portal = @party_subcontractor

                  IF @party_type = 'SubcontractorEntity'
                     SET @type_association = 'SubcontractorEntityAssociation'
                  ELSE
                     IF @party_type = 'SubcontractorIndividual'
                        SET @type_association =
                               'SubcontractorIndividualAssociation'
                     ELSE
                        IF @party_type = 'SubcontractorOwnerIndividual'
                           SET @type_association =
                                  'SubcontractorIndividualOwnerAssociation'

                  INSERT INTO #Owner_Association (AssPartyAppID,
                                                  AssPartyAccID,
                                                  SubcontractorAccID,
                                                  TypeAsso)
                  VALUES (@acc_party_owner_id,
                          @party_subcontractor,
                          @acc_party_subcontractor,
                          @type_association)

                  SELECT @app_owner_relation_id = OwnerRelationID
                    FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                   WHERE     PartyIDOwner = @party_owner_id
                         AND PartyIDOwned = @party_subcontractor
                         AND TypeAssociation = @type_association;
                  EXEC @acc_owner_relation_id =
                          [KYPEnrollment].[sp_Copy_Ownership_Relationship] NULL,
                                                                           @acc_party_owner_id,
                                                                           @acc_party_subcontractor,
                                                                           @party_owner_id,
                                                                           @party_subcontractor,
                                                                           @last_action_user_id,
                                                                           @type_association;
                  EXEC [KYPEnrollment].[sp_Copy_Owner_Role] NULL,
                                                            NULL,
                                                            @last_action_user_id,
                                                            @app_owner_relation_id,
                                                            @acc_owner_relation_id;
               END
            ELSE
               --if assoc with party that already exist
               BEGIN
                  IF CHARINDEX (N'|PartyID|', @target_path) > 0
                     BEGIN
                        EXEC [KYPEnrollment].[sp_Split_TargetPath] @target_path,
                                                                   @acc_party_subcontractor OUTPUT;
                     END

                  IF @party_type = 'SubcontractorEntity'
                     SET @type_association = 'SubcontractorEntityAssociation'
                  ELSE
                     IF @party_type = 'SubcontractorIndividual'
                        SET @type_association =
                               'SubcontractorIndividualAssociation'
                     ELSE
                        IF @party_type = 'SubcontractorOwnerIndividual'
                           SET @type_association =
                                  'SubcontractorIndividualOwnerAssociation'

                  INSERT INTO #Owner_Association (AssPartyAppID,
                                                  AssPartyAccID,
                                                  SubcontractorAccID,
                                                  TypeAsso)
                  VALUES (@acc_party_owner_id,
                          @party_subcontractor,
                          @acc_party_subcontractor,
                          @type_association)

                  SELECT @app_owner_relation_id = OwnerRelationID
                    FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                   WHERE     PartyIDOwner = @party_owner_id
                         AND PartyIDOwned = @party_subcontractor
                         AND TypeAssociation = @type_association;
                  EXEC @acc_owner_relation_id =
                          [KYPEnrollment].[sp_Copy_Ownership_Relationship] NULL,
                                                                           @acc_party_owner_id,
                                                                           @acc_party_subcontractor,
                                                                           @party_owner_id,
                                                                           @party_subcontractor,
                                                                           @last_action_user_id,
                                                                           @type_association;
                  EXEC [KYPEnrollment].[sp_Copy_Owner_Role] NULL,
                                                            NULL,
                                                            @last_action_user_id,
                                                            @app_owner_relation_id,
                                                            @acc_owner_relation_id;
               END
         --
         END

      SET @cont = @cont + 1
   END
END


GO

