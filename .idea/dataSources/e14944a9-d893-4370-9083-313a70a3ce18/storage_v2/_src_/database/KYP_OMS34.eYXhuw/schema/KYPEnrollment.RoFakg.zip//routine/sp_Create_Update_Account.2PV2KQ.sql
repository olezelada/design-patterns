


/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create or update Account.
-- PARAMETERS:
-- @application_no : Application Number that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @priority : ADM_Case.Priority to Enrollment data base.
-- @risk : ADM_Case.risk to Enrollment data base.
-- @composite_risk : ADM_Case.CompositeRisk to Enrollment data base.
-- @case_id : ADM_Case.CaseID to Enrollment data base, for Account Number.
-- @account_no : Account Number, it is null when account is create, only have value when a account will be update.
-- ============================================================*/

CREATE PROCEDURE KYPEnrollment.sp_Create_Update_Account
@application_no VARCHAR(15),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@risk VARCHAR(15),
@composite_risk INT,
@case_id INT,
@account_no VARCHAR(20)
AS
BEGIN
  DECLARE @account_id INT
         ,@applicationId INT
         ,@application_Code VARCHAR(100)
         ,@application_type VARCHAR(30)
         ,@party_id_app INT
         ,@activityStatus VARCHAR(25)
         ,@provider_type_code VARCHAR(50)
         ,@case INT
         ,@accid INT
         ,@profile int
         ,@npi VARCHAR(100)
		 ,@legal_name VARCHAR(200)
		 ,@updatePayToAddress BIT
		 ,@sourceAccount VARCHAR(20)
		 ,@questionnaireAccount VARCHAR(20)
		 ,@FBP bit
		 ,@crossover bit
		 ,@UpdateLegalName bit --Added for CAPAVE-3812
		 ,@UpdateBusinessName bit --Added for CAPAVE-3812
		 ,@UpdateMailToAddress bit --Added for CAPAVE-3812		 
		 ,@npiType VARCHAR(35);
         
  SELECT
    @applicationId = ApplicationID
   ,@application_Code = ApplicationCode
   ,@application_type = ApplicationType
   ,@party_id_app = PartyID
   ,@case = caseid
   ,@profile = profile_id
   ,@npi = NPI
   ,@npiType = NpiType
   ,@updatePayToAddress = UpdatePayToAddress
   ,@sourceAccount = SourceAccount
   ,@questionnaireAccount = QuestionnaireAccount
   ,@FBP=FBPApp
   ,@UpdateLegalName=UpdateLegalName --Added for CAPAVE-3812
   ,@UpdateBusinessName=UpdateBusinessName --Added for CAPAVE-3812
   ,@UpdateMailToAddress=UpdateMailToAddress --Added for CAPAVE-3812   
  FROM [KYPPORTAL].[PortalKYP].[pADM_Application]
  WHERE ApplicationNo = @application_no
  --

  SELECT
    @activityStatus = ISNULL(activitystatus, '')
  FROM [KYPPORTAL].[PortalKYP].[pADM_case]
  WHERE CaseID = @case

  IF (@account_no <> '')
    AND @application_Code NOT IN ('GSP_SP_DAG',
    'ISP_SP_DAI',
    'ISP_RS_P_DM',
    'ISP_RS_U_RA',
    'ISP_RS_S_RM',
    'RP_RS_MDH',
    'ISP_RS_O_RA',
    'ISP_RS_P_RA',
    'ISP_RS_OAP_RA',
    'ISP_DMC_SUDTP_S') AND @activityStatus <>'Become Tribal'
  BEGIN

  
    IF NOT EXISTS (SELECT
          AccountTransactionID
        FROM [KYPEnrollment].[AccountTransactions]
        WHERE AccountNumber = @account_no
        AND ApplicationNumber = @application_no)
      AND EXISTS (SELECT
          AccountID
        FROM KYPEnrollment.pADM_Account
        WHERE AccountNumber = @account_no
        AND IsDeleted = 0
        AND (IsPastOwner = 0
        OR IsPastOwner IS NULL))
    BEGIN
      SELECT
        @account_id = AccountID
      FROM KYPEnrollment.pADM_Account
      WHERE AccountNumber = @account_no
      AND IsDeleted = 0
      AND IsPastOwner = 0;

      PRINT 'UPDATE ACCOUNT'

      IF @application_type = 'CHOW'
        OR (@application_type = 'Revalidation'
        AND @activityStatus = 'CHOW')
      BEGIN
        PRINT 'CLONE ACCOUNT'

	SELECT  @provider_type_code = ProviderTypeCode FROM KYPPORTAL.PortalKYP.pADM_Application WHERE ApplicationNo = @application_no

	EXEC [KYPEnrollment].[Main_Procedure_Clone_Account] @account_id
                                                           ,@account_no
                                                           ,@last_Action_User_ID
                                                           ,@priority
                                                           ,@risk
                                                           ,@composite_risk
                                                           ,@case_id
                                                           ,@application_no
                                                           ,@application_type
                                                           ,@party_id_app
							                                              ,@provider_type_code;
      ---

      END
      ELSE
      BEGIN
        CREATE TABLE #TaxIDChange (
          ID INT IDENTITY (1, 1)
         ,PartyID INT
         ,TYPE VARCHAR(50)
         ,IsPrepopulated BIT
         ,IsChangeTaxID BIT
         ,TargetPath VARCHAR(200)
        )

        EXEC [KYPEnrollment].[sp_Update_Account] @application_no
                                                ,@account_no
                                                ,@last_Action_User_ID;
       
        EXEC [KYPEnrollment].[sp_Update_Modules_Account] @application_no
                                                        ,@account_no
                                                        ,@last_Action_User_ID;

        DROP TABLE #TaxIDChange
      END


      IF @application_type = 'Revalidation'
        OR @application_type = 'Reenrollment'
      BEGIN
        UPDATE [KYPPORTAL].[PortalKYP].[AccountRevalidationTime]
        SET IsRevalidated = 1
        WHERE AccountID = @account_id;
      END

      -- KEN-8551 KEN-7432
      -- Update last date Revalidation KEN 9392

      IF @application_type IN ('Revalidation',
        'Reenrollment',
        'CHOW',
        'CHOA')
      BEGIN
        UPDATE KYPEnrollment.pADM_Account
        SET DateModified = GETDATE()
           ,reenrollmentdate = kypenrollment.ScheduleAccDate()--KEN-16183
        WHERE AccountID = @account_id;

        EXEC [KYPEnrollment].[sp_Update_affiliationsDMC] @application_no
                                                    ,@application_Code;
      END

      --KPP-6612
      IF @application_type = 'Supplemental'
      BEGIN
        UPDATE KYPEnrollment.pADM_Account
        SET DateModified = GETDATE()
        WHERE AccountID = @account_id;
      END


      INSERT INTO [KYPEnrollment].[AccountTransactions] ([AccountID],
      [AccountNumber],
      [ApplicationID],
      [ApplicationNumber],
      ApplicationType)
        VALUES (@account_id, @account_no, @applicationId, @application_no, @application_type)
    END
    ELSE
    IF EXISTS (SELECT
          AccountID
        FROM KYPEnrollment.pADM_Account
        WHERE AccountNumber = @account_no
        AND IsDeleted = 0
        AND (IsPastOwner = 0
        OR IsPastOwner IS NULL))
    BEGIN
      PRINT 'ACCOUNT: '
      + CONVERT(VARCHAR(20), @account_no)
      + ' ALREADY WAS UPDATED'
    END

---------------------------------------------------------------------------------------------------------

        DECLARE @main_app_number varchar(100),@main_app_npi varchar(100),@main_app_package varchar(50),@serviceAddress varchar(250), @owner_number varchar(15)
        select @main_app_number = ApplicationNumber , @main_app_npi = NPI, @serviceAddress = PracticeAddress, @main_app_package = PackageName, @owner_number = OwnerNo FROM KYPEnrollment.pADM_Account WHERE IsDeleted=0 and AccountNumber = @account_no
        SELECT @owner_number = BillingFutureStatus FROM KYPEnrollment.EDM_SupplementalInternalUse WHERE LastActionComments = @application_no

			if  (@account_no is not null and @account_id is null)
			begin
				SET @main_app_number = @application_no
				select  @account_id = AccountID from KYPEnrollment.pADM_Account where AccountNumber=@account_no
				
			end

	  	     EXEC [KYPEnrollment].sp_Detect_update_related @account_id,
														   @application_no,
														   @last_Action_User_ID,
														   @priority,
														   @composite_risk,
														   @case_id,
														   @risk,
														   @application_type,
														   @main_app_number

          
            EXEC [KYPEnrollment].[sp_Update_Twins] @main_app_number,@main_app_npi,@application_no,@party_id_app,@last_Action_User_ID,@account_id
		  
		IF (@updatePayToAddress IS NOT NULL and @updatePayToAddress=1 )
        BEGIN
          EXEC [KYPEnrollment].[sp_Detect_PayToAddress] @application_no,@last_Action_User_ID,@party_id_app,@profile,@npi,@main_app_npi,@applicationId, @owner_number;
        END
        
		--Added the If stat. for CAPAVE-3812
		If (@UpdateLegalName=1 or @UpdateBusinessName=1 or @UpdateMailToAddress=1)
		Begin
			Exec KYPENROLLMENT.Usp_Spread_Fields @application_no, @main_app_npi, @last_Action_User_ID,	@party_id_app ,@account_id
		End        

----------------------------------------------------------------------------------------------------------


  END
  ELSE
  BEGIN
     -- this statement commented to avoid blocking creating the account twice

        /*IF NOT EXISTS(SELECT AccountTransactionID FROM [KYPEnrollment].[AccountTransactions] WHERE ApplicationNumber = @application_no)
        BEGIN*/
      print 'activity status';
      print @activityStatus;
      PRINT 'CREATE ACCOUNT'


				CREATE TABLE #tempProviderType (id INT IDENTITY (1, 1),[tempProviderType] [nvarchar](50) NULL,[appName] [nvarchar](50) NULL,
				[AccountNumber] [varchar](20) NULL,[partyAddressId] [int] NULL,	[IsFBP] [bit] NULL,	[locationID] [int] NULL )




        EXEC KYPEnrollment.GetProviderTypeBuffer @application_no, @case_id

    SELECT @application_type = ApplicationType,@crossover = ISNULL(IsCrossoverApp,0)  FROM [KYPPORTAL].[PortalKYP].[pADM_Application] WHERE ApplicationNo = @application_no;

    WHILE EXISTS(SELECT id
                 FROM #tempProviderType
                 WHERE appName = @application_no)
      BEGIN



        DECLARE @count INT, @new_accountNumber VARCHAR(20), @isFbp BIT;

			--IF NOT EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
			IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NULL
			BEGIN
				CREATE TABLE #Control_Association_Tax_NewMod (pk INT IDENTITY (1, 1),npi varchar(100),profileid varchar(30) )
			END


        SELECT TOP 1
          @count = id,
          @provider_type_code = tempProviderType,
          @new_accountNumber = AccountNumber,
          @isFbp = IsFBP
        FROM #tempProviderType
        WHERE appName = @application_no

		IF NOT EXISTS (SELECT * FROM [KYPEnrollment].[AccountTransactions] WHERE AccountNumber=@new_accountNumber and ApplicationNumber=@application_no )
		BEGIN
        PRINT @provider_type_code
        PRINT @new_accountNumber

      IF @application_type IN ('Rendering-S', 'SUDMD/SUDTP Simplified Package') and @account_no<>''
        BEGIN
          SET @new_accountNumber = @account_no
        END

        IF (ISNULL(@provider_type_code,'') = '102' AND @crossover = 0)
		BEGIN
		  PRINT('EXECUTING 102');
		  EXEC [KYPEnrollment].[sp_Process_DPP_Account_creation] @application_no
                                                                 , @last_Action_User_ID
                                                                 , @priority
                                                                 , @risk
                                                                 , @composite_risk
                                                                 , @provider_type_code
                                                                 , @new_accountNumber
                                                                 , @npiType;
		END
		ELSE
		BEGIN
		  PRINT('EXECUTING NORMAL ACCOUNT');
		  EXEC [KYPEnrollment].[sp_Create_New_Account] @application_no
                                                  , @last_Action_User_ID
                                                  , @priority
                                                  , @risk
                                                  , @composite_risk
                                                  , @case_id
                                                  , @application_type
                                                  , @provider_type_code
                                                  , @new_accountNumber;
		END


        IF EXISTS(SELECT id
                  FROM #tempProviderType
                  WHERE id = @count AND partyAddressId IS NOT NULL)
          BEGIN
            EXEC [KYPEnrollment].sp_Replace_Address @new_accountNumber,
                                                    @application_no,
                                                    @count,
                                                    @last_Action_User_ID,
                                                    @party_id_app,
                                                    @provider_type_code,
                                                    @applicationId,
                                                    @application_type

          END

        DECLARE @new_account_id INT

        SELECT @new_account_id = AccountID
        FROM KYPEnrollment.pADM_Account
        WHERE AccountNumber = @new_accountNumber

        IF 1 = @isFbp
          BEGIN
			EXEC [KYPEnrollment].[sp_FBP_related_data_update] @new_Account_Id,@application_no,@applicationId,@npi,@legal_name
          END
          
          
        INSERT INTO [KYPEnrollment].[AccountTransactions]
        ([AccountID]
          , [AccountNumber]
          , [ApplicationID]
          , [ApplicationNumber]
          , ApplicationType)
        VALUES
          (@new_account_id
            , @new_accountNumber
            , @applicationId
            , @application_no
            , @application_type)
          
	  END



        DELETE FROM #tempProviderType
        WHERE id = @count

      END


		--IF EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t where t.TABLE_NAME like '#Control_Association_Tax_NewMod%')
		IF OBJECT_ID('tempdb..#Control_Association_Tax_NewMod') IS NOT NULL
		Begin
			drop TABLE #Control_Association_Tax_NewMod
		End

		IF (@updatePayToAddress=1 or Exists(Select CaseID
												From kyp.adm_Case 
												Where Number=@application_no
												and Applntype in ('New','New Group','New Rendering')))
        BEGIN
			EXEC [KYPEnrollment].[sp_Detect_PayToAddress_NewApps] @application_no, @last_Action_User_ID, @party_id_app, @profile,@npi, @npi, @applicationId, @application_type;
		End
		
		--Added the If stat. for CAPAVE-3812
		If (@UpdateLegalName=1 or @UpdateBusinessName=1 or @UpdateMailToAddress=1)
		Begin
			Exec KYPENROLLMENT.Usp_Spread_Fields @application_no, @npi, @last_Action_User_ID, @party_id_app ,@new_account_id
		End		

   		EXEC [KYPEnrollment].[sp_RenderAffiliations_related_data_update] @application_no,@application_Code,@application_type,@accid,@account_no
   		
    END      
            
    --Adding Condition for Application History
    IF Not Exists(select AccountNumber from KYPEnrollment.ApplicationHistory where Applicationnumber=@application_no
		and AccountNumber in (Select AccountNumber from KYPEnrollment.pADM_Account Where ApplicationNumber=@application_no and IsDeleted=0))
	BEGIN
		EXEC [KYPEnrollment].[sp_ApplicationHistory_related_data_insertion] @application_no
	End         
    --Adding Condition for Application History
END

GO

