
CREATE PROCEDURE [KYP].[p_UpdatePDMParty] (
	@PartyID INT
	,@Type VARCHAR(25) = NULL
	,@Name VARCHAR(200) = NULL
	,@IsProvider BIT = NULL
	,@IsEnrolled BIT = NULL
	,@IsTemp BIT = NULL
	,@IsActive BIT = NULL
	,@LoadType VARCHAR(50) = NULL
	,@LoadID VARCHAR(20) = NULL
	,@LastLoadDate DATETIME = NULL
	,@DateModified SMALLDATETIME = NULL
	,@IsDeleted BIT = NULL
	,@Source VARCHAR(10) = NULL
	,@CreatedBy INT = NULL
	,@DateCreated SMALLDATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted SMALLDATETIME = NULL
	,@CurrentModule SMALLINT = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	IF (LTRIM(RTRIM(ISNULL(@Type, '')))) = ''
	BEGIN
		SET @Type = NULL;
	END
	
	IF (LTRIM(RTRIM(ISNULL(@Name, '')))) = ''
	BEGIN
		SET @Name = NULL;
	END
	
	IF ISNULL(@IsProvider, '') = ''
	BEGIN
		SET @IsProvider = NULL;
	END
	
	IF ISNULL(@IsEnrolled, '') = ''
	BEGIN
		SET @IsEnrolled = NULL;
	END
	
	IF ISNULL(@IsTemp, '') = ''
	BEGIN
		SET @IsTemp = NULL;
	END
	
	IF ISNULL(@IsActive, '') = ''
	BEGIN
		SET @IsActive = NULL;
	END
	
	IF (LTRIM(RTRIM(ISNULL(@LoadType, '')))) = ''
	BEGIN
		SET @LoadType = NULL;
	END
	
	IF (LTRIM(RTRIM(ISNULL(@LoadID, '')))) = ''
	BEGIN
		SET @LoadID = NULL;
	END
	
	IF ISNULL(@LastLoadDate, '') = ''
	BEGIN
		SET @LastLoadDate = NULL;
	END
	
	IF ISNULL(@DateModified, '') = ''
	BEGIN
		SET @DateModified = NULL;
	END
	
	IF ISNULL(@IsDeleted, '') = ''
	BEGIN
		SET @IsDeleted = NULL;
	END
	
	IF (LTRIM(RTRIM(ISNULL(@Source, '')))) = ''
	BEGIN
		SET @Source = NULL;
	END
	
	IF ISNULL(@CreatedBy, '') = ''
	BEGIN
		SET @CreatedBy = NULL;
	END
	
	IF ISNULL(@DateCreated, '') = ''
	BEGIN
		SET @DateCreated = NULL;
	END
	
	IF ISNULL(@ModifiedBy, '') = ''
	BEGIN
		SET @ModifiedBy = NULL;
	END
	
	IF ISNULL(@DeletedBy, '') = ''
	BEGIN
		SET @DeletedBy = NULL;
	END
	
	IF ISNULL(@DateDeleted, '') = ''
	BEGIN
		SET @DateDeleted = NULL;
	END
	
	IF ISNULL(@CurrentModule, '') = ''
	BEGIN
		SET @CurrentModule = NULL;
	END

	SET @SQLQuery = 'Update [KYP].[PDM_Party] Set '

	IF @Type IS NOT NULL
		SET @updatelist = '[Type] = ''' + @Type + ''''

	--select @SQLQuery = @SQLQuery + @updatelist
	IF @Name IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Name] = ''' + replace(@Name, '', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[Name] = ''' + replace(@Name, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @IsProvider IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsProvider] = ' + CAST(@IsProvider AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsProvider] = ' + CAST(@IsProvider AS VARCHAR(1)) + ''
	END

	IF @IsEnrolled IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsEnrolled] = ' + CAST(@IsEnrolled AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = ',[IsEnrolled] = ' + CAST(@IsEnrolled AS VARCHAR(1)) + ''
	END

	IF @IsTemp IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsTemp] = ' + CAST(@IsTemp AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = ',[IsTemp] = ' + CAST(@IsTemp AS VARCHAR(1)) + ''
	END

	IF @IsActive IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsActive] = ' + CAST(@IsActive AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = ',[IsActive] = ' + CAST(@IsActive AS VARCHAR(1)) + ''
	END

	IF @LoadType IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LoadType] = ''' + replace(@LoadType, '''', CHAR(39) + CHAR(39)) + ''''
		ELSE
			SET @updatelist = '[LoadType] = ''' + replace(@LoadType, '''', CHAR(39) + CHAR(39)) + ''''
	END

	IF @LoadID IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LoadID] = ''' + @LoadID + ''''
		ELSE
			SET @updatelist = '[LoadID] = ''' + @LoadID + ''''
	END

	IF @LastLoadDate IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[LastLoadDate] = ''' + convert(VARCHAR(25), @LastLoadDate, 121) + ''''
		ELSE
			SET @updatelist = '[LastLoadDate] = ''' + convert(VARCHAR(25), @LastLoadDate, 121) + ''''
	END

	IF @DateModified IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
		ELSE
			SET @updatelist = '[DateModified] = ''' + convert(VARCHAR(25), @DateModified, 121) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	IF @Source IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Source] = ''' + @Source + ''''
		ELSE
			SET @updatelist = '[Source] = ''' + @Source + ''''
	END

	IF @CreatedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
		ELSE
			SET @updatelist = '[CreatedBy] = ' + Convert(VARCHAR(10), @CreatedBy)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + convert(VARCHAR(25), @DateCreated, 121) + ''''
	END

	IF @ModifiedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
		ELSE
			SET @updatelist = '[ModifiedBy] = ' + Convert(VARCHAR(10), @ModifiedBy)
	END

	IF @DeletedBy IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
		ELSE
			SET @updatelist = '[DeletedBy] = ' + Convert(VARCHAR(10), @DeletedBy)
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + convert(VARCHAR(25), @DateDeleted, 121) + ''''
	END

	IF @CurrentModule IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
		ELSE
			SET @updatelist = '[CurrentModule] = ' + Convert(VARCHAR(10), @CurrentModule)
	END

	SET @filter = ' where PartyID=' + Convert(VARCHAR(10), @PartyID)
	SET @SQLQuery = @SQLQuery + @updatelist + @filter

	EXECUTE sp_Executesql @SQLQuery
END


GO

