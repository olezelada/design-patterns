
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Person Other Name by Traking.   
-- PARAMETERS: 
-- @acc_party_id : PartyId Account that will be update. 
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Person_OtherName]
@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @app_other_person_id INT;

IF @action_taken='Added'
  BEGIN
   IF @target_path NOT LIKE '%|%'
	BEGIN
	PRINT @action_taken+': '+'NEW ROW'
	  SELECT @app_other_person_id = PesonONID FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName] WHERE TargetPath=@target_path;
	  --IF (SELECT COUNT(FiledID) FROM [KYPEnrollment].[Control_Add_row] WHERE FiledID=@app_other_person_id AND NameTable='pAccount_PDM_Person_OtherName')= 0
	   IF NOT EXISTS(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_other_person_id AND NameTable='pAccount_PDM_Person_OtherName')

	  BEGIN
	  PRINT @action_taken 
	  EXEC [KYPEnrollment].[sp_Copy_Person_OtherName] NULL,NULL,@last_action_user_id,@app_other_person_id,@acc_party_id;
	  --INSERT INTO [KYPEnrollment].[Control_Add_row](FiledID,NameTable)
	   INSERT INTO #Control_Add_row(FiledID,NameTable)
	  VALUES(@app_other_person_id,'pAccount_PDM_Person_OtherName'); 
	  END 
   	END
   	ELSE
   	BEGIN
   	 PRINT @action_taken+': '+'FIELD'
   	  EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_Person_OtherName',@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
   	END  
END
  
IF @action_taken='Updated'
  BEGIN
  PRINT @action_taken
  EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_Person_OtherName',@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
END
  
IF @action_taken='Deleted' AND @target_path LIKE '%pAccount_PDM_Person_OtherName%'
  BEGIN
  PRINT @action_taken
  UPDATE [KYPEnrollment].[pAccount_PDM_Person_OtherName] SET CurrentRecordFlag = 0 WHERE PesonONID = @acc_PK_value;
END
END


GO

