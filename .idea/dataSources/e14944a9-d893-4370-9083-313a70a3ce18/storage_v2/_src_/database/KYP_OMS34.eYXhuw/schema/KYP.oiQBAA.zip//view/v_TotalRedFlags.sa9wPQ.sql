
CREATE VIEW [KYP].[v_TotalRedFlags] AS
SELECT SUM(X.RedFlagCount) As RedFlag,X.ApplicationID FROM(
SELECT DISTINCT P.ApplicationID,F.RedFlagCount
 FROM KYP.SDM_RedFlag F INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = F.ScreeningID AND P.IsActive = 1
 )X GROUP BY X.ApplicationID


GO

