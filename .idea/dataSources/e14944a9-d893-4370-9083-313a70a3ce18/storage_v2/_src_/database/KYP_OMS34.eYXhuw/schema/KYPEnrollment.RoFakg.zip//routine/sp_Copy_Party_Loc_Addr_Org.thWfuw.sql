



/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Party, Location, Address and Organization row.   
-- PARAMETERS: 
-- @party_id : partyID Application that will be Account. 
-- @new_party_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @type : Party type.
-- @app_party_row_id : this is the PartyID Row to Application that will be Create in Update Account, it is Null when account is create.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   @type                   VARCHAR (50),
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_hospital      INT,
      @new_Party_hsp_id    INT,
      @count_association   INT,
      @is_prepopulated     BIT,
      @org_id              INT,
      @legal_name          VARCHAR (100),
      @target_path         VARCHAR (200),
      @main_party_id       INT


   CREATE TABLE #childsub
   (
      pk               INT IDENTITY (1, 1),
      PartyID          INT,
      Type             VARCHAR (50),
      targetpath       VARCHAR (200),
      isprepopulated   BIT
   )


   IF @app_party_row_id IS NULL
      --esta parte ya no se ejecuta para los subcontractors cuando es nueva cuenta
      --1
      BEGIN
         DECLARE @party_cursor TABLE
                               (
                                  pk               INT IDENTITY (1, 1),
                                  PartyID          INT,
                                  IsPrepopulated   BIT,
                                  TargetPath       VARCHAR (200)
                               )

         INSERT INTO @party_cursor
            SELECT PartyID, IsPrepopulated, TargetPath
              FROM [KYPPORTAL].[PortalKYP].pPDM_Party
             WHERE     Type = @type
                   AND IsDeleted = 0
                   AND ParentPartyID = @party_id


         DECLARE
            @cont   INT,
            @tot    INT
         SET @cont = 1
         SELECT @tot = MAX (pk) FROM @party_cursor

         WHILE @cont <= @tot
         BEGIN
            SELECT @party_hospital = PartyID,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath
            FROM @party_cursor
            WHERE pk = @cont


            IF (@type = 'SubcontractorEntity' OR @type = 'TransactionEntity')
               BEGIN
                  IF NOT EXISTS
                        (SELECT OwnerRelationID
                           FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnershipRelationship]
                          WHERE     PartyIDOwned = @party_hospital
                                AND (   TypeAssociation =
                                           'SubcontractorEntityAssociation'
                                     OR TypeAssociation =
                                           'SubcontractorIndividualAssociation'))
                     BEGIN
                        EXEC @new_Party_hsp_id =
                                [KYPEnrollment].[sp_Copy_Party] @party_hospital,
                                                                @new_party_id,
                                                                @account_id,
                                                                @last_action_user_id;
                        EXEC
                            @org_id =
                               [KYPEnrollment].[sp_Copy_Organization] @new_Party_hsp_id,
                                                                      @party_hospital,
                                                                      @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_hsp_id,
                                                               @party_hospital,
                                                               NULL,
                                                               @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_hospital,
                                                                           @new_Party_hsp_id,
                                                                           @last_action_user_id;

                        IF (@type = 'SubcontractorEntity')
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_Party_hsp_id,
                                                                        @party_hospital,
                                                                        @last_action_user_id,
                                                                        NULL,
                                                                        NULL;
                           END

                        IF (@type = 'TransactionEntity' AND @is_group = 1)
                           BEGIN
                              IF (   @is_prepopulated IS NULL
                                  OR @is_prepopulated = 0)
                                 BEGIN
                                    SELECT @legal_name = LegalName
                                      FROM KYPEnrollment.pAccount_PDM_Organization
                                     WHERE OrgID = @org_id
                                    --EXEC [KYPEnrollment].[Create_Significat_TaxId] @new_Party_hsp_id,'Entity',@legal_name, @new_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @new_Party_hsp_id,
                                                                                  @new_Party_hsp_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_hospital;
                                 END
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @main_party_id = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @target_path,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @main_party_id = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @main_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                                  @new_Party_hsp_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_hospital;
                                 END
                           END

                        IF (@type = 'SubcontractorEntity' AND @is_group = 1)
                           BEGIN
                              IF (   @is_prepopulated IS NULL
                                  OR @is_prepopulated = 0)
                                 BEGIN
                                    SELECT @legal_name = LegalName
                                      FROM KYPEnrollment.pAccount_PDM_Organization
                                     WHERE OrgID = @org_id
                                    --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_Party_hsp_id,'Entity',@legal_name, @new_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @new_Party_hsp_id,
                                                                                  @new_Party_hsp_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_hospital;
                                 END
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @main_party_id = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @target_path,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @main_party_id = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @main_party_id;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                                  @new_Party_hsp_id,
                                                                                  @account_id,
                                                                                  @type,
                                                                                  @party_hospital;
                                 END
                           END
                     END
               END
            ELSE
               BEGIN
                  EXEC @new_Party_hsp_id =
                          [KYPEnrollment].[sp_Copy_Party] @party_hospital,
                                                          @new_party_id,
                                                          @account_id,
                                                          @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_Organization] @new_Party_hsp_id,
                                                              @party_hospital,
                                                              @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_hsp_id,
                                                         @party_hospital,
                                                         NULL,
                                                         @last_action_user_id;
               END

            SET @cont = @cont + 1
         END
      END
   --1
   --update account @app_party_row_id
   ELSE
      BEGIN
         IF (@type = 'SubcontractorEntity' OR @type = 'TransactionEntity')
            --2
            BEGIN
               EXEC @new_Party_hsp_id =
                       [KYPEnrollment].[sp_Copy_Party] @app_party_row_id,
                                                       @new_party_id,
                                                       @account_id,
                                                       @last_action_user_id;
               EXEC
                   @org_id =
                      [KYPEnrollment].[sp_Copy_Organization] @new_Party_hsp_id,
                                                             @app_party_row_id,
                                                             @last_action_user_id;
               EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_hsp_id,
                                                      @app_party_row_id,
                                                      NULL,
                                                      @last_action_user_id;
               EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @app_party_row_id,
                                                                  @new_Party_hsp_id,
                                                                  @last_action_user_id;

               IF (@type = 'SubcontractorEntity')
                  BEGIN
                     EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_Party_hsp_id,
                                                               @party_hospital,
                                                               @last_action_user_id,
                                                               NULL,
                                                               NULL;

                     --mvc--
                     INSERT
                       INTO #subcontractors (PartyID_Portal,
                                             Type_sub,
                                             PartyID_Enroll)
                     VALUES (@app_party_row_id, @type, @new_Party_hsp_id)
                  END

               IF (@is_group = 1)
                  BEGIN
                     IF EXISTS
                           (SELECT ID
                              FROM #TaxIDChange
                             WHERE     PartyID = @app_party_row_id
                                   AND Type = @type)
                        BEGIN
                           SELECT @legal_name = LegalName
                           FROM KYPEnrollment.pAccount_PDM_Organization
                           WHERE OrgID = @org_id;

                           IF @type = 'TransactionEntity'
                              BEGIN
                                 --EXEC [KYPEnrollment].[Create_Significat_TaxId] @new_Party_hsp_id,'Entity',@legal_name, @new_party_id;
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @new_Party_hsp_id,
                                                                               @new_Party_hsp_id,
                                                                               @account_id,
                                                                               @type,
                                                                               @app_party_row_id;
                              END

                           IF @type = 'SubcontractorEntity'
                              BEGIN
                                 --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_Party_hsp_id,'Entity',@legal_name, @new_party_id;
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @new_Party_hsp_id,
                                                                               @new_Party_hsp_id,
                                                                               @account_id,
                                                                               @type,
                                                                               @app_party_row_id;
                              END
                        END
                     ELSE
                        BEGIN
                           SELECT TOP 1
                                  @main_party_id = Item
                             FROM [KYPEnrollment].[SplitString] (
                                     @target_path,
                                     '|')
                           ORDER BY item;
                           SELECT TOP 1
                                  @main_party_id = MainPartyID
                           FROM [KYPEnrollment].[pAccount_Party_Associate]
                           WHERE PartyID = @main_party_id;
                           EXEC [KYPEnrollment].[Create_Party_Associate] @main_party_id,
                                                                         @new_Party_hsp_id,
                                                                         @account_id,
                                                                         @type,
                                                                         @app_party_row_id;
                        END
                  END

               --child subcontractors
               IF EXISTS
                     (SELECT PartyID
                        FROM [KYPPORTAL].[PortalKYP].pPDM_Party
                       WHERE     type LIKE 'SubcontractorOwner%'
							 AND isnull(IsDeleted,0)=0
                             AND ParentPartyID = @app_party_row_id)
                  BEGIN
                     INSERT INTO #childsub
                        SELECT PartyID,
                               Type,
                               TargetPath,
                               IsPrepopulated
                          FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                         WHERE     ParentPartyID = @app_party_row_id
						 AND  Type in ('SubcontractorOwnerEntity','subcontractorOwnerIndividual')
                          
							  AND isnull(IsDeleted,0)=0

                     DECLARE
                        @cont1   INT,
                        @tot1    INT
                     SELECT @tot1 = MAX (pk) FROM #childsub
                     SET @cont1 = 1
                     DECLARE @partychildsub_port   INT
                     DECLARE @partychildsub_enr   INT
                     DECLARE @partychildtype_port   VARCHAR (50)
                     DECLARE @mainparty_child   INT
                     DECLARE @targetpath_child   VARCHAR (200)
                     DECLARE @isprepopulated_child   BIT

                     WHILE @cont1 <= @tot1
                     BEGIN
                        SELECT @partychildsub_port = partyid,
                               @partychildtype_port = TYPE,
                               @targetpath_child = targetpath,
                               @isprepopulated_child = isprepopulated
                        FROM #childsub
                        WHERE pk = @cont1
                        EXEC @partychildsub_enr =
                                [KYPEnrollment].[sp_Copy_Party] @partychildsub_port,
                                                                @new_Party_hsp_id,
                                                                @account_id,
                                                                @last_action_user_id;

                        --mvc--
                        INSERT
                          INTO #subcontractors (PartyID_Portal,
                                                Type_sub,
                                                PartyID_Enroll)
                           VALUES (
                                     @partychildsub_port,
                                     @partychildtype_port,
                                     @partychildsub_enr)

                        --
                        IF @partychildtype_port = 'SubcontractorOwnerEntity'
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Organization] @partychildsub_enr,
                                                                          @partychildsub_port,
                                                                          @last_action_user_id;
                           END
                        ELSE
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Person] @partychildsub_enr,
                                                                    @partychildsub_port,
                                                                    @last_action_user_id,
                                                                    'C';
                           END

                        EXEC [KYPEnrollment].[sp_Copy_Address] @partychildsub_enr,
                                                               @partychildsub_port,
                                                               NULL,
                                                               @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @partychildsub_enr,
                                                                  @partychildsub_port,
                                                                  @last_action_user_id,
                                                                  NULL,
                                                                  NULL;

                        --create new party_associate for new child subcontractors

                        IF (@is_group = 1)
                           BEGIN
                              IF (   @isprepopulated_child IS NULL
                                  OR @isprepopulated_child = 0)
                                 EXEC [KYPEnrollment].[Create_Party_Associate] @partychildsub_enr,
                                                                               @partychildsub_enr,
                                                                               @account_id,
                                                                               @partychildtype_port,
                                                                               @partychildsub_port;
                              ELSE
                                 BEGIN
                                    SELECT TOP 1
                                           @mainparty_child = Item
                                      FROM [KYPEnrollment].[SplitString] (
                                              @targetpath_child,
                                              '|')
                                    ORDER BY item;
                                    SELECT TOP 1
                                           @mainparty_child = MainPartyID
                                      FROM [KYPEnrollment].[pAccount_Party_Associate]
                                     WHERE PartyID = @mainparty_child;
                                    EXEC [KYPEnrollment].[Create_Party_Associate] @mainparty_child,
                                                                                  @partychildsub_enr,
                                                                                  @account_id,
                                                                                  @partychildtype_port,
                                                                                  @partychildsub_port;
                                 END
                           END

                        --

                        SET @cont1 = @cont1 + 1
                     END

                     TRUNCATE TABLE #childsub
                  END
            --
            END
         --2
         ELSE
            BEGIN
               EXEC @new_Party_hsp_id =
                       [KYPEnrollment].[sp_Copy_Party] @app_party_row_id,
                                                       @new_party_id,
                                                       @account_id,
                                                       @last_action_user_id;
               EXEC [KYPEnrollment].[sp_Copy_Organization] @new_Party_hsp_id,
                                                           @app_party_row_id,
                                                           @last_action_user_id;
               EXEC [KYPEnrollment].[sp_Copy_Address] @new_Party_hsp_id,
                                                      @app_party_row_id,
                                                      NULL,
                                                      @last_action_user_id;
            END


         RETURN @new_Party_hsp_id;
      END
END


GO

