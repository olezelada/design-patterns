-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[UpdateEnrollmentStatus] 
	
AS
BEGIN
	
	--create table #tblUpdatedID (AccountID int);
	
	--insert into #tblUpdatedID
	SELECT * into #tblUpdatedID FROM [KYPEnrollment].[pADM_Account] WHERE CAST(FutureDate AS Date) = '2018-02-01 00:00:00'--CAST(GETDATE() AS DATE)--'2018-02-01 00:00:00'; 

	IF EXISTS(SELECT COUNT(AccountID ) FROM  #tblUpdatedID)
	BEGIN
		UPDATE p
					SET
					StatusAcc = pa.FutureStatus,
					ActivationDate = pa.FutureDate,
					StatusBeginDate = pa.FutureDate,
					DeActivationDate = pa.DeActivationDate,
					StatusReasonCode = pa.FutureStatusReasonCode,
					EnrollStatusComments = pa.FutureEnrollComments,
					FutureStatus = NULL,
					FutureDate = NULL,
					FutureStatusReasonCode = NULL,
					FutureEnrollComments = NULL	
		FROM [KYPEnrollment].[pADM_Account] p 
		INNER JOIN #tblUpdatedID  pa ON pa.AccountID = p.AccountID and pa.StatusAcc <>'1 - Active';


			UPDATE p
				SET
				StatusAcc = pa.FutureStatus,
				ActivationDate = pa.FutureDate,
				StatusBeginDate = pa.FutureDate,
				DeActivationDate = pa.DeActivationDate,
				StatusReasonCode = pa.FutureStatusReasonCode,
				EnrollStatusComments = pa.FutureEnrollComments,
				FutureStatus = NULL,
				FutureDate = NULL,
				FutureStatusReasonCode = NULL,
				FutureEnrollComments = NULL	
			/*SELECT [StatusAcc],[StatusBeginDate],[DeActivationDate],[StatusReasonCode],
					[EnrollStatusComments],[FutureStatus],[FutureDate],[FutureStatusReasonCode],
					[FutureEnrollComments] */
			FROM [KYPEnrollment].[pADM_Account] p 
		    INNER JOIN #tblUpdatedID  pa ON pa.AccountID = p.AccountID and pa.StatusAcc = '1 - Active'
			

			UPDATE [KYPEnrollment].[AccountSearch]
					SET
					EnrollmentStatus = p.FutureStatus,
					StatusBeginDate = p.FutureDate,
          EnrolledOn = p.StatusBeginDate
			--SELECT FutureStatus,FutureDate 
			FROM #tblUpdatedID p
			INNER JOIN [KYPEnrollment].[AccountSearch] s ON s.AccountID = p.AccountID
			
	END
	
	drop table #tblUpdatedID ;
	
	
	END


GO

