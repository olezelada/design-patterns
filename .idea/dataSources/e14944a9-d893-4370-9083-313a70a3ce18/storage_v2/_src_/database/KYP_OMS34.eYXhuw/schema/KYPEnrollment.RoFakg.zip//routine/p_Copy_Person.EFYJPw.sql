-- =============================================
-- Author:		<Author,,Lperez>
-- copiar person recive 3 para metros
-- @personId  id de la persona, @newPartyId id del nuevo party, @lastActionUserID nombre del usuario que realiza la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Person]
	@personId INT,
	@newPartyId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @newPersonId int,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
	(PartyID ,
	PersonNumber ,
	PersonCategory ,
	SSN ,
	Salutation ,
	FirstName ,
	LastName ,
	MiddleName ,
	Gender ,
	DoB ,
	DoD ,
	Email1 ,
	Phone1 ,
	Email2 ,
	Phone2 ,
	Alias1 ,
	Alias2 ,
	CityofBirth ,
	StateofBirth ,
	CountryOfBirth ,
	Ethnicity ,
	Remark ,
	[LastAction] ,
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy] ,
	[CurrentRecordFlag] ,
	OtherFirstName ,
	OtherLastName ,
	OtherMiddleName ,
	Prefix ,
	OtherNameType ,
	OtherPrefix ,
	Sufix ,
	DriverLicense ,
	Position ,
	ExpirationDateDriverLic ,
	OtherOtherNameType ,
	ProfessionalTitle,
	Extension)
	SELECT @newPartyId
	,[PersonNumber]
	,[PersonCategory]
	,[SSN]
	,[Salutation]
	,[FirstName]
	,[LastName]
	,[MiddleName]
	,[Gender]
	,[DoB]
	,[DoD]
	,[Email1]
	,[Phone1]
	,[Email2]
	,[Phone2]
	,[Alias1]
	,[Alias2]
	,[CityofBirth]
	,[StateofBirth]
	,[CountryOfBirth]
	,[Ethnicity]
	,[Remark]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [Deleted] = 0 or [Deleted] is null then 1 else 0 end)
	,[OtherFirstName]
	,[OtherLastName]
	,[OtherMiddleName]
	,[Prefix]
	,[OtherNameType]
	,[OtherPrefix]
	,[Sufix]
	,[DriverLicense]
	,[Position]
	,[ExpirationDateDriverLic]
	,[OtherOtherNameType]
	,[ProfessionalTitle]
	,[Extension]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] WHERE PersonID = @personId
	SELECT @message = '[pPDM_Person] @newPersonId  ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT				
END


GO

