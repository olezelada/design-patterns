-- =============================================
-- Author:		Yogesh Sharma
-- Create date: Aug 03 2012
-- Description:	Find the SecNPIID of Party if received
-- =============================================
CREATE PROCEDURE [KYP].[p_FindSecondaryNPIRecord]
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@NPI int
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @SecNPIID int
	/********Get the SecNPI ID based on PartyID**********/
	if exists (	
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_SecondaryNPI B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 	
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.NPI = @NPI		
	)
	begin
	select @SecNPIID = SecNPIID
	from KYP.PDM_Party A
	inner join KYP.PDM_SecondaryNPI B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 	
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.NPI = @NPI		
	
    return @SecNPIID	
	end	
	else 
	return -1   	
END


GO

