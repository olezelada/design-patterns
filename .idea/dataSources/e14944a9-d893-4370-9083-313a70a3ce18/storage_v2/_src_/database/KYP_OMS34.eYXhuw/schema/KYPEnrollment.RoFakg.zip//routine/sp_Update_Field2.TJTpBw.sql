
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Fields by Traking.   
-- PARAMETERS: 
-- @acc_table_name : Table Name to contain field that will be update. 
-- @en_db_column : column that will be update. 
-- @data : new value for Column that will be update. 
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not. 
-- @stored_value : input Type that be Update.
-- @last_action_user_id : Enrollment User. 
-- @action_taken : Action that will be made.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Field2]
	@acc_table_name VARCHAR(100),
	@en_db_column VARCHAR(100), 
	@data VARCHAR(MAX), 
	@acc_PK VARCHAR(100), 
	@acc_PK_value INT,
	@is_text_date CHAR(1),
	@stored_value VARCHAR(MAX),
	@last_action_user_id VARCHAR(100),
	@action_taken VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @update NVARCHAR(MAX),@last_action VARCHAR(1),@count_like INT
	Declare @ParamDefinition AS NVarchar(2000), @accPKvalue varchar(100)
	DECLARE @cond VARCHAR(MAX)

	Set @ParamDefinition = '@accPKvalue INT'
	set @accPKvalue = CONVERT(VARCHAR(100),@acc_PK_value); 

	SET @last_action = 'U';

	SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column
	SET @cond = @acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);

	IF @action_taken = 'Deleted'
	BEGIN
	 
	 SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);
     EXECUTE(@update)
	END
	ELSE
	BEGIN
	    
		IF(@is_text_date = '1')
		BEGIN
			IF @data LIKE '%'+CHAR(39)+'%'
			BEGIN 
			SELECT @data = REPLACE(@data,CHAR(39),'''+CHAR(39)+''')
			END
			IF @stored_value ='checkbox'
			BEGIN
			  IF @data IS NULL OR @data='' 
			  BEGIN
				--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
				SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
			  END
			  ELSE
			  BEGIN
				--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = 1 WHERE '+@acc_PK+' = '+ '@accPKvalue';
				SET @update = @update +' = 1 WHERE '+@acc_PK+' = @accPKvalue';
			  END
			END
			ELSE
			BEGIN
			 IF @data =''  
			  BEGIN			
			      --SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
				  SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
			  END
			  ELSE  
			  BEGIN
			     -- SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = '''+@data+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';		
				  SET @update = @update +' = '''+@data+''' WHERE '+@acc_PK+' = @accPKvalue';	
			  END  
			END

			EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
			
			--EXECUTE(@update)

		
		END
		ELSE
		BEGIN
			 IF @stored_value ='checkbox'
			  BEGIN
				  IF @data IS NULL OR @data='' 
				  BEGIN
					--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
					SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
				  END
				  ELSE
				  BEGIN
					--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = 1 WHERE '+@acc_PK+' = '+ '@accPKvalue';
					SET @update = @update +' = 1 WHERE '+@acc_PK+' = @accPKvalue';
				  END
			  END
			  ELSE
			  BEGIN
                IF @data =''  
			    BEGIN			
			      --SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
				  SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
			    END
			    ELSE
			    BEGIN
			      --SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = '+@data +' WHERE '+@acc_PK+' = '+ '@accPKvalue';
				   SET @update = @update +' = '''+@data+''' WHERE '+@acc_PK+' = @accPKvalue';
			    END			 
			 END	
			 EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
			--	EXECUTE(@update)
		END
	END
	
	SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastAction '+' = '''+@last_action+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
	 EXEC sp_executesql @update,  @ParamDefinition,@acc_PK_value
	--EXECUTE(@update);
	
	SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionDate '+' = '''+CONVERT(VARCHAR(100),ISNULL(CASE WHEN CONVERT(DATE, GETDATE()) = '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), GETDATE()) END, ''))+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
	 EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
	--EXECUTE(@update);
	
	DECLARE @action_user VARCHAR(50)
	
	SELECT @action_user = COLUMN_NAME 
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=@acc_table_name AND (COLUMN_NAME = 'LastActorUserID' OR COLUMN_NAME = 'LastActionUserID')
    
    IF @action_user = 'LastActorUserID'
    BEGIN
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActorUserID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
    END
    ELSE
    BEGIN
      IF @action_user = 'LastActionUserID'
      BEGIN   
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionUserID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
	  END	
    END
	
	SELECT @action_user = COLUMN_NAME 
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=@acc_table_name AND (COLUMN_NAME = 'LastActionApprovedBy' OR COLUMN_NAME ='LastActionApprovedByUsedID')
    
    IF @action_user = 'LastActionApprovedBy'
    BEGIN
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionApprovedBy '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
    END
    ELSE
    BEGIN
      IF @action_user = 'LastActionApprovedByUsedID'
      BEGIN
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionApprovedByUsedID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
	  END	
    END
END


GO

