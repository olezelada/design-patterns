-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <13/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Insurance] 
@new_Account_Id int

AS
BEGIN
Declare @insurance int
	SET NOCOUNT ON;

select @insurance = i.InsuranceID
from KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Insurance] i ON a.PartyID=i.PartyID
where a.AccountID=@new_Account_Id and a.IsDeleted=0 and i.CurrentRecordFlag=1 and i.IsDeleted=0

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Insurance','InsuranceID',@insurance

UPDATE [KYPEnrollment].[pAccount_PDM_Insurance]
      SET  IsDeleted=0, CurrentRecordFlag = 0
    WHERE InsuranceID IN
			(select InsuranceID
        from KYPEnrollment.pADM_Account a INNER JOIN [KYPEnrollment].[pAccount_PDM_Insurance] i ON a.PartyID=i.PartyID
        where a.AccountID=@new_Account_Id and a.IsDeleted=0 and i.CurrentRecordFlag=1 and i.IsDeleted=0 )


END


GO

