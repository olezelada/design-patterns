CREATE PROCEDURE [KYPEnrollment].[sp_Update_Table_Ray]
   @acc_party_id           INT,
   @action_taken           VARCHAR (50),
   @last_action_user_id    VARCHAR (100),
   @target_path            VARCHAR (200),
   @en_db_column           VARCHAR (100),
   @data                   VARCHAR (MAX),
   @acc_PK                 VARCHAR (100),
   @acc_PK_value           INT,
   @is_text_date           CHAR (1),
   @acc_table_name         VARCHAR (100),
   @table_code             VARCHAR (20),
   @stored_value           VARCHAR (MAX),
   @account_id             INT,
   @new_fields_values      VARCHAR (MAX) = NULL,
   @row_uuid               VARCHAR (100) = NULL
AS
BEGIN
  SET  NOCOUNT ON;
  DECLARE
    @app_party_row_id      INT,
    @type                  VARCHAR (50),
    @parent_party_id       INT;
  DECLARE
    @partyOwner   INT,
    @part         INT
  IF (@action_taken = 'Updated' OR (@target_path LIKE '%|%' AND @action_taken = 'Added'))
  BEGIN
      EXEC [KYPEnrollment].[sp_Update_Field]  @acc_table_name, @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date, @stored_value, @last_action_user_id, @action_taken;
  END
  ELSE
  BEGIN

    SELECT @app_party_row_id = PartyID, @type = Type, @parent_party_id = ParentPartyID
    FROM   [KYPPORTAL].[PortalKYP].[pPDM_Party]
    WHERE  TargetPath = @target_path;

    IF  (@action_taken = 'Added') AND (@target_path NOT LIKE '%|%')

    BEGIN
        PRINT 'Copying rows from "rays" App-PartyID:';
        PRINT @app_party_row_id;

        INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
				  [PartyID],
				  [Type],
				  [Name],
				  [Description],
				  [CurrentRecordFlag],
				  [IsDeleted])
				  values (
				  @acc_party_id,
				  'RayList',
				  'ServiceList',
				  @data,
				  1,
				  0)

        PRINT 'End of copy table';
    END
    ELSE
    BEGIN
        IF (@action_taken = 'Deleted') AND (@data = 'Row Deleted') AND (@acc_table_name IS NOT NULL)
        BEGIN
            EXECUTE ( 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + ' = ' + @acc_PK_value);
        END
        ELSE
        BEGIN
            EXEC [KYPEnrollment].[sp_Update_Field]  @acc_table_name, @en_db_column, NULL, @acc_PK, @acc_PK_value, @is_text_date, @stored_value, @last_action_user_id, @action_taken;
        END
    END
  END
END


GO

