


-- =============================================
-- Author:		<Rajesh Singh>
-- Create date: <25Apr2016>
-- Description:	<Merge accounts to identify the profiles>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[SP_CA_Merge_Account_To_Profile]
	
AS
BEGIN
	


--IF OBJECT_ID (N'dbo.temp_Stage_CA_FULL_Data_26OCT', N'U') IS NOT NULL 
--    DROP TABLE dbo.temp_Stage_CA_FULL_Data_26OCT;
--    IF OBJECT_ID (N'dbo.temp_Stage_CA_Profile_Data', N'U') IS NOT NULL 
--    DROP TABLE dbo.temp_Stage_CA_Profile_Data;
	
	
	declare @iteration1 int = 0,@count1  int = 0,@group1 INT = 0,@criteria Varchar(50) = NULL,
			@key1 int = 0,@key2 int = 0,@key3 int = 0,@key4 int = 0,@key5 int = 0,@key6 int = 0,@key7 int = 0,@Key8 INT = 0,
			@match varchar(50)
       
    												
	
	INSERT INTO DBO.temp_Stage_CA_FULL_Data ([DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME] ,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP]
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
												,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1]
												)
    
 select  
 [DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME],[DH_PROV_BUSINESS_NAME] ,[DH_PROV_TYP] 
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
												,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1]
    
    from	
(	
select  [DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME],[DH_PROV_BUSINESS_NAME] ,[DH_PROV_TYP] 
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
												,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1]
												, case 
													when DH_ENROL_STAT_CD_1 IN ('1','7','9') then 'Active' 
													else 'Inactive'
												  end as ActivityStatus	
    from dbo.Stage_CAProfileCleanData  
    ) Z
    order by 
    ActivityStatus,[DA_LEGAL_NAME], [DH_PAY_TO_LN1], [DH_PAY_TO_CITY], [DH_PAY_TO_STATE],[DH_PAY_TO_ZIP5], [DH_EMP_ID_NO], [DH_SSN] , [DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE],[DH_ADDR_ZIP5], [DH_PROV_LIC_NO]
 
    
  
           
	INSERT INTO dbo.temp_Stage_CA_Profile_Data ([ID],[DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME] ,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP]
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
												,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1])
    select  [ID],[DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME] ,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP]
				,[DH_PAY_TO_LN1]
				,[DH_PAY_TO_CITY]
				,[DH_PAY_TO_STATE]
				,[DH_PAY_TO_ZIP5]
				,[DH_PAY_TO_ZIP4]
				,[DH_ADDR_LN1]
				,[DH_ADDR_CITY]
				,[DH_ADDR_STATE]
				,[DH_ADDR_ZIP5]
				,[DH_ADDR_ZIP4]
				,[DH_PIN]
				,[DH_PROV_TELE_NO] 
				,[DH_MAIL_TO_LN1] 
				,[DH_MAIL_TO_CITY] 
				,[DH_MAIL_TO_STATE] 
				,[DH_MAIL_TO_ZIP5] 
				,[DH_MAIL_TO_ZIP4] 
				,[DH_CLIA_NUMBER]
				,[DH_PROV_LIC_NO]
				,[DH_OWNER_NUM]
				,[DH_SERV_LOC_NUM]
				,[DA_LEGAL_NAME]
				,[DA_PROV_BUSINESS_NAME]
				,[DH_ENROL_STAT_CD_1]
    from dbo.temp_Stage_CA_FULL_Data where [ID] = 1
    
    
    
    --Select * from temp_Stage_CA
    --Select * from temp_Stage_CA_PMF
    
    Select @count1  = COUNT([ID]) from dbo.temp_Stage_CA_FULL_Data 
    SET @iteration1  = 2
    	          
    While @iteration1 <= @count1
    Begin
			
			  declare @Dummy_Tab1 table(
								[ID] INT primary key,
								[DH_SSN] [varchar](9) NULL,
								[DH_EMP_ID_NO] [varchar](9) NULL,
								[DH_PROV_NUMBER] [varchar](12) NULL,
								[DH_LEGAL_NAME] [varchar](50) NULL,
								[DH_PROV_BUSINESS_NAME] [varchar](50) NULL	,
								[DH_PROV_TYP] [varchar](50),
								[DH_PAY_TO_LN1] [varchar](24) NULL,
								[DH_PAY_TO_CITY] [varchar](17) NULL,
								[DH_PAY_TO_STATE] [varchar](2) NULL,
								[DH_PAY_TO_ZIP5] [varchar](5) NULL,
								[DH_PAY_TO_ZIP4] [varchar](4) NULL,
								[DH_ADDR_LN1] [varchar](24) NULL,
								[DH_ADDR_CITY] [varchar](17) NULL,
								[DH_ADDR_STATE] [varchar](2) NULL,
								[DH_ADDR_ZIP5] [varchar](5) NULL,
								[DH_ADDR_ZIP4] [varchar](4) NULL,
								[DH_PIN] [varchar](7) NULL,
								[DH_PROV_TELE_NO] [varchar](11) NULL,
								[DH_MAIL_TO_LN1] varchar(50),
								[DH_MAIL_TO_CITY] [varchar](17) NULL,
								[DH_MAIL_TO_STATE] [varchar](2) NULL,
								[DH_MAIL_TO_ZIP5] [varchar](5) NULL,
								[DH_MAIL_TO_ZIP4] [varchar](4) NULL	,
								[DH_CLIA_NUMBER] [varchar] (15) NULL,
								[DH_PROV_LIC_NO] [varchar] (50) NULL,
								[DH_OWNER_NUM] [varchar] (50),
								[DH_SERV_LOC_NUM] [varchar] (50),
								[DA_LEGAL_NAME] [varchar](50) NULL,
								[DA_PROV_BUSINESS_NAME] [varchar](50) NULL,
								[DH_ENROL_STAT_CD_1] [Varchar] (50) NULL,	
								count1 int NULL,iter int null,criteria Varchar(50) NULL
								)
									
						INSERT INTO @Dummy_Tab1([ID],[DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] 
												,[DH_LEGAL_NAME] 
												,[DH_PROV_BUSINESS_NAME]
												,[DH_PROV_TYP]
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
											    ,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1]
												,count1,iter,criteria)		
						Select DISTINCT top 1
												[ID],[DH_SSN] ,[DH_EMP_ID_NO] ,[DH_PROV_NUMBER] ,[DH_LEGAL_NAME] 
												,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP]
												,[DH_PAY_TO_LN1]
												,[DH_PAY_TO_CITY]
												,[DH_PAY_TO_STATE]
												,[DH_PAY_TO_ZIP5]
												,[DH_PAY_TO_ZIP4]
												,[DH_ADDR_LN1]
												,[DH_ADDR_CITY]
												,[DH_ADDR_STATE]
												,[DH_ADDR_ZIP5]
												,[DH_ADDR_ZIP4]
												,[DH_PIN]
												,[DH_PROV_TELE_NO]
												,[DH_MAIL_TO_LN1] 
												,[DH_MAIL_TO_CITY] 
												,[DH_MAIL_TO_STATE] 
												,[DH_MAIL_TO_ZIP5] 
												,[DH_MAIL_TO_ZIP4] 
												,[DH_CLIA_NUMBER]
												,[DH_PROV_LIC_NO]
												,[DH_OWNER_NUM]
												,[DH_SERV_LOC_NUM]
												,[DA_LEGAL_NAME]
												,[DA_PROV_BUSINESS_NAME]
												,[DH_ENROL_STAT_CD_1]
												,@count1,@iteration1,@criteria
						from DBO.temp_Stage_CA_FULL_Data 
						Where ID = @iteration1
						
		
						
						IF EXISTS (SELECT A.ID 
									FROM dbo.temp_Stage_CA_Profile_Data A 
									JOIN @Dummy_Tab1 B ON (LEFT(A.[DA_LEGAL_NAME],10) = LEFT(B.[DA_LEGAL_NAME],10)
														AND ((A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																								OR
														  (A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5])))
														  AND 1 = (CASE WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] = B.[DH_SSN] THEN 1																			
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] THEN 1
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] THEN 1
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) = RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 1
																		WHEN A.[DH_PROV_NUMBER] IS Not null AND B.[DH_PROV_NUMBER] IS NOT NULL 
																			AND A.[DH_PROV_NUMBER] = B.[DH_PROV_NUMBER] THEN 1
																			
																		WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] <> B.[DH_SSN] THEN 0
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] <> B.[DH_EMP_ID_NO] THEN 0
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL AND LEN(B.[DH_PROV_LIC_NO]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) <> RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 0
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] <> B.[DH_PROV_TELE_NO] THEN 0
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL AND LEN(B.[DH_PIN]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) <> RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 0
																																					
																		--WHEN A.DH_SSN IS Null OR B.DH_SSN IS NULL	THEN 1	
																		--WHEN A.[DH_EMP_ID_NO] IS Null OR B.[DH_EMP_ID_NO] IS NULL	THEN 1 
																		--WHEN A.[DH_PROV_LIC_NO] IS Null OR B.[DH_PROV_LIC_NO] IS NULL THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Null OR B.[DH_PROV_TELE_NO] IS NULL THEN 1
																		--WHEN A.[DH_PIN] IS Null OR B.[DH_PIN] IS NULL THEN 1
																		--WHEN A.[DH_PROV_NUMBER] IS Null OR B.[DH_PROV_NUMBER] IS NULL THEN 1																
																	ELSE 0	
																	END
																)
									)
						BEGIN
							SET @KEY1 = 1
							IF (@CRITERIA IS NULL)
								BEGIN
									SET @CRITERIA = 'LEGAL_NAME-ADDR-PAY_TO'
								END
								
							Select distinct top 1 @match = A.[ID]
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON LEFT(A.[DA_LEGAL_NAME],10) = LEFT(B.[DA_LEGAL_NAME],10)
														AND ((A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																								OR
														(A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5]))
														AND 1 = (CASE WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] = B.[DH_SSN] THEN 1																			
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] THEN 1
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] THEN 1
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) = RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 1
																		WHEN A.[DH_PROV_NUMBER] IS Not null AND B.[DH_PROV_NUMBER] IS NOT NULL 
																			AND A.[DH_PROV_NUMBER] = B.[DH_PROV_NUMBER] THEN 1
																			
																		WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] <> B.[DH_SSN] THEN 0
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] <> B.[DH_EMP_ID_NO] THEN 0
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL AND LEN(B.[DH_PROV_LIC_NO]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) <> RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 0
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] <> B.[DH_PROV_TELE_NO] THEN 0
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL AND LEN(B.[DH_PIN]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) <> RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 0
																																					
																		--WHEN A.DH_SSN IS Null OR B.DH_SSN IS NULL	THEN 1	
																		--WHEN A.[DH_EMP_ID_NO] IS Null OR B.[DH_EMP_ID_NO] IS NULL	THEN 1 
																		--WHEN A.[DH_PROV_LIC_NO] IS Null OR B.[DH_PROV_LIC_NO] IS NULL THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Null OR B.[DH_PROV_TELE_NO] IS NULL THEN 1
																		--WHEN A.[DH_PIN] IS Null OR B.[DH_PIN] IS NULL THEN 1
																		--WHEN A.[DH_PROV_NUMBER] IS Null OR B.[DH_PROV_NUMBER] IS NULL THEN 1																
																	ELSE 0	
																	END
																)
							
							if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
							BEGIN
								Update dbo.temp_Stage_CA_Profile_Data
								Set criteria = @criteria
								Where ID = @match
							END	
								
						END
						
						-------------------------------------
						
						if(@key1 = 0 )
						BEGIN
							
							Declare @SSN_Legalname varchar(100) = (Select TOP 1 [DH_LEGAL_NAME] From @Dummy_Tab1)
							Set @SSN_Legalname = (case	when len(Substring(replace(@SSN_Legalname,',',''),1,CHARINDEX(' ',@SSN_Legalname,1)))> 2 
															then Substring(replace(@SSN_Legalname,',',''),1,CHARINDEX(' ',@SSN_Legalname,1))
														when LEN(reverse(substring(REVERSE(rtrim(@SSN_Legalname)),1,charindex(' ',REVERSE(rtrim(@SSN_Legalname)),1)))) >4
															then  reverse(substring(REVERSE(rtrim(@SSN_Legalname)),1,charindex(' ',REVERSE(rtrim(@SSN_Legalname)),1)))
												END)	
												
							SET @SSN_Legalname = LTRIM(rtrim(@SSN_Legalname))																						
							
														
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B ON A.[DH_SSN] = B.[DH_SSN] 
										AND ( LEFT(A.[DA_LEGAL_NAME],6) = LEFT(B.[DA_LEGAL_NAME],6)
																	OR													
											(A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																	OR
											(A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5])
																	OR
											(RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4))	
																	OR
											(A.[DH_LEGAL_NAME] like '%'+@SSN_Legalname+'%')))
							BEGIN
								SET @KEY2 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'SSN'	
									END
									
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A
								JOIN @Dummy_Tab1 B ON A.[DH_SSN] = B.[DH_SSN]
								AND ( LEFT(A.[DA_LEGAL_NAME],6) = LEFT(B.[DA_LEGAL_NAME],6)
																	OR													
											(A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																	OR
											(A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5])
																	OR
											(RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4))	
																	OR
											(A.[DH_LEGAL_NAME] like '%'+@SSN_Legalname+'%'))
											
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END									
							END
						END
						-------------------------------------------------
						
						if(@key1 = 0 and @key2 = 0)
						BEGIN
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B 
										ON A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] 
										AND  LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10))
							BEGIN
								SET @KEY3 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'EMP_ID_NO-LEGAL_NAME'
									END
									
									
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A
								JOIN @Dummy_Tab1 B ON A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] 
										AND  LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10)
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END	
							END
						END	
						--------------------------------------------------------------------------------
																		
						if(@key1 = 0 and @key2 = 0 and @key3 = 0)
						BEGIN
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B 
										ON RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
										AND LEFT(A.[DA_LEGAL_NAME],10) 	= LEFT(B.[DA_LEGAL_NAME],10) 
										AND A.DH_PROV_TYP = B.DH_PROV_TYP
										)
							BEGIN
								SET @KEY4 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'PROV_LIC_NO-LEGAL_NAME-PROV_TYPE'
									END
									
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A
								JOIN @Dummy_Tab1 B ON RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
													AND LEFT(A.[DA_LEGAL_NAME],10) 	= LEFT(B.[DA_LEGAL_NAME],10) 
													AND A.DH_PROV_TYP = B.DH_PROV_TYP
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END	
							END
						END
						-----------------------------------------
						
						if(@key1 = 0 and @key2 = 0 and @Key3 = 0 and @Key4 = 0)
						BEGIN
							
							Declare @Legalname varchar(100) = (Select TOP 1 [DH_LEGAL_NAME] From @Dummy_Tab1)
							Set @Legalname = (case	when len(Substring(replace(@Legalname,',',''),1,CHARINDEX(' ',@Legalname,1)))> 2 
															then Substring(replace(@Legalname,',',''),1,CHARINDEX(' ',@Legalname,1))
														when LEN(reverse(substring(REVERSE(rtrim(@Legalname)),1,charindex(' ',REVERSE(rtrim(@Legalname)),1)))) >3
															then  reverse(substring(REVERSE(rtrim(@Legalname)),1,charindex(' ',REVERSE(rtrim(@Legalname)),1)))
												END)	
												
							SET @Legalname = LTRIM(rtrim(@Legalname))
							
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B 
										ON (A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5] OR A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
													and RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
													AND A.DH_PROV_TYP = B.DH_PROV_TYP 
													AND (A.[DH_LEGAL_NAME] like '%'+@Legalname+'%')													
										)
										
							BEGIN
								SET @key5 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'ZIP5-PROV_LIC_NO-PROV_TYPE'
									END
								
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B  ON (A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5] OR A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
													and RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
													AND A.DH_PROV_TYP = B.DH_PROV_TYP 
													AND (A.[DH_LEGAL_NAME] like '%'+@Legalname+'%')
													
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END		
							END
						END
						
						-----------------------------------------------------
						
						if(@key1 = 0 and @key2 = 0 and @Key3 = 0 and @key4 = 0 and @key5 = 0)
						BEGIN
								IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B 
										ON A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] 
										AND LEFT(A.[DA_LEGAL_NAME],20)= LEFT(B.[DA_LEGAL_NAME],20) )
								BEGIN
								SET @KEY6 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'PROV_TELE_NO-LEGAL_NAME'
									END
									
									Select distinct top 1 @match = A.[ID]
									FROM dbo.temp_Stage_CA_Profile_Data A
									JOIN @Dummy_Tab1 B ON A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] 
											AND LEFT(A.[DA_LEGAL_NAME],20)= LEFT(B.[DA_LEGAL_NAME],20)
								
									if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
									BEGIN
										Update dbo.temp_Stage_CA_Profile_Data
										Set criteria = @criteria
										Where ID = @match
									END		
								END
						END
						------------------------------------------------
						
						
						if(@key1 = 0 and @key2 = 0 and @Key3 = 0 and @key4 = 0 and @KEY5 = 0 and @key6 = 0 )
						BEGIN
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B 
										ON A.[DH_PIN] = B.[DH_PIN] 
										AND LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10))
										
							BEGIN
								SET @KEY7 = 1
								IF (@CRITERIA IS NULL)
									BEGIN
										SET @CRITERIA = 'PIN-LEGAL_NAME'
									END
								
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A
								JOIN @Dummy_Tab1 B ON A.[DH_PIN] = B.[DH_PIN] 
										AND LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10)
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END		
							END
						END
						--------------------------------------------------
						
						if(@key1 = 0 and @key2 = 0 and @Key3 = 0 and @key4 = 0 and @KEY5 = 0 and @key6 = 0 and @key7 = 0 )
						Begin
							IF EXISTS (SELECT A.ID 
										FROM dbo.temp_Stage_CA_Profile_Data A 
										JOIN @Dummy_Tab1 B ON A.[DH_PROV_NUMBER]	= B.[DH_PROV_NUMBER])
							BEGIN
								SET @KEY8 = 1
								SET @CRITERIA = 'PROV_NUMBER'
								
								Select distinct top 1 @match = A.[ID]
								FROM dbo.temp_Stage_CA_Profile_Data A
								JOIN @Dummy_Tab1 B ON A.[DH_PROV_NUMBER]	= B.[DH_PROV_NUMBER]								
								
								if exists (Select 1 from dbo.temp_Stage_CA_Profile_Data where criteria is null and ID = @match )
								BEGIN
									Update dbo.temp_Stage_CA_Profile_Data
									Set criteria = @criteria
									Where ID = @match
								END										
								
							END
						END
						-------------------------------------------------------------------------
						
						if(@key1 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON LEFT(A.[DA_LEGAL_NAME],10) = LEFT(B.[DA_LEGAL_NAME],10)
														AND ((A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																								OR
														(A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5]))
														AND 1 = (CASE WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] = B.[DH_SSN] THEN 1																			
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] THEN 1
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] THEN 1
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL 
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) = RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 1
																		WHEN A.[DH_PROV_NUMBER] IS Not null AND B.[DH_PROV_NUMBER] IS NOT NULL 
																			AND A.[DH_PROV_NUMBER] = B.[DH_PROV_NUMBER] THEN 1
																			
																		WHEN A.DH_SSN IS Not null AND B.DH_SSN IS NOT NULL 
																			AND A.[DH_SSN] <> B.[DH_SSN] THEN 0
																		WHEN A.[DH_EMP_ID_NO] IS Not null AND B.[DH_EMP_ID_NO] IS NOT NULL 
																			AND A.[DH_EMP_ID_NO] <> B.[DH_EMP_ID_NO] THEN 0
																		WHEN A.[DH_PROV_LIC_NO] IS Not null AND B.[DH_PROV_LIC_NO] IS NOT NULL AND LEN(B.[DH_PROV_LIC_NO]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) <> RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4) THEN 0
																		--WHEN A.[DH_PROV_TELE_NO] IS Not null AND B.[DH_PROV_TELE_NO] IS NOT NULL 
																		--	AND A.[DH_PROV_TELE_NO] <> B.[DH_PROV_TELE_NO] THEN 0
																		WHEN A.[DH_PIN] IS Not null AND B.[DH_PIN] IS NOT NULL AND LEN(B.[DH_PIN]) > 3
																			AND RIGHT(ltrim(rtrim(A.[DH_PIN])),4) <> RIGHT(ltrim(rtrim(B.[DH_PIN])),4) THEN 0
																																					
																		--WHEN A.DH_SSN IS Null OR B.DH_SSN IS NULL	THEN 1	
																		--WHEN A.[DH_EMP_ID_NO] IS Null OR B.[DH_EMP_ID_NO] IS NULL	THEN 1 
																		--WHEN A.[DH_PROV_LIC_NO] IS Null OR B.[DH_PROV_LIC_NO] IS NULL THEN 1
																		--WHEN A.[DH_PROV_TELE_NO] IS Null OR B.[DH_PROV_TELE_NO] IS NULL THEN 1
																		--WHEN A.[DH_PIN] IS Null OR B.[DH_PIN] IS NULL THEN 1
																		--WHEN A.[DH_PROV_NUMBER] IS Null OR B.[DH_PROV_NUMBER] IS NULL THEN 1																
																	ELSE 0	
																	END
																)						
						END 	
						
						
						if(@key2 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON A.[DH_SSN] = B.[DH_SSN]
							AND (LEFT(A.[DA_LEGAL_NAME],6) = LEFT(B.[DA_LEGAL_NAME],6)
																	OR
											(A.[DH_ADDR_LN1] = B.[DH_ADDR_LN1] AND A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
																				OR
											(A.[DH_PAY_TO_LN1] = B.[DH_PAY_TO_LN1] AND A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5])
																				OR
											(RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4))	
																OR
											(A.[DH_LEGAL_NAME] like '%'+@SSN_Legalname+'%'))
							WHERE (@key1 = 0)
						END 
						
						if(@key3 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON A.[DH_EMP_ID_NO] = B.[DH_EMP_ID_NO] 
												AND  LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10)
							WHERE (@key1 = 0 and @key2 = 0)
						END 
												
						if(@key4 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
												AND LEFT(A.[DA_LEGAL_NAME],10) 	= LEFT(B.[DA_LEGAL_NAME],10) 
												AND A.DH_PROV_TYP = B.DH_PROV_TYP
							WHERE (@key1 = 0 and @key2 = 0 and @key3 = 0)
						END 
						
											
						if(@key5 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON (A.[DH_PAY_TO_ZIP5] = B.[DH_PAY_TO_ZIP5] OR A.[DH_ADDR_ZIP5] = B.[DH_ADDR_ZIP5])
													and RIGHT(ltrim(rtrim(A.[DH_PROV_LIC_NO])),4) = RIGHT(ltrim(rtrim(B.[DH_PROV_LIC_NO])),4)
													AND A.DH_PROV_TYP = B.DH_PROV_TYP 
													AND (A.[DH_LEGAL_NAME] like '%'+@Legalname+'%')
							WHERE (@key1 = 0 and @key2 = 0 and @key3 = 0 and @key4 = 0)
						END
						
						if(@key6 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON A.[DH_PROV_TELE_NO] = B.[DH_PROV_TELE_NO] 
												AND LEFT(A.[DA_LEGAL_NAME],20)= LEFT(B.[DA_LEGAL_NAME],20)
							WHERE (@key1 = 0 and @key2 = 0 and @key3 = 0  and @key4 = 0 and @key5 = 0)
						END 
						
						
						if(@key7 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON A.[DH_PIN] = B.[DH_PIN] 
												AND LEFT(A.[DA_LEGAL_NAME],10)= LEFT(B.[DA_LEGAL_NAME],10)
							WHERE (@key1 = 0 and @key2 = 0 and @key3 = 0 and @key4 = 0 and @key5 = 0 and @key6 = 0)
						END 
										
																	
						if(@key8 = 1)									
						BEGIN
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4] 
											,[DH_CLIA_NUMBER],[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME]
											,[DA_PROV_BUSINESS_NAME],[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT  Distinct top 1 A.[ID],B.[DH_SSN],B.[DH_EMP_ID_NO],B.[DH_PROV_NUMBER],B.[DH_LEGAL_NAME]
											,B.[DH_PROV_BUSINESS_NAME],B.[DH_PROV_TYP],B.[DH_PAY_TO_LN1],B.[DH_PAY_TO_CITY],B.[DH_PAY_TO_STATE]
											,B.[DH_PAY_TO_ZIP5],B.[DH_PAY_TO_ZIP4],B.[DH_ADDR_LN1],B.[DH_ADDR_CITY],B.[DH_ADDR_STATE]
											,B.[DH_ADDR_ZIP5],B.[DH_ADDR_ZIP4],B.[DH_PIN],B.[DH_PROV_TELE_NO],B.[DH_MAIL_TO_LN1] 
											,B.[DH_MAIL_TO_CITY],B.[DH_MAIL_TO_STATE],B.[DH_MAIL_TO_ZIP5],B.[DH_MAIL_TO_ZIP4] 
											,B.[DH_CLIA_NUMBER],B.[DH_PROV_LIC_NO],B.[DH_OWNER_NUM],B.[DH_SERV_LOC_NUM],B.[DA_LEGAL_NAME]
											,B.[DA_PROV_BUSINESS_NAME],B.[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM dbo.temp_Stage_CA_Profile_Data A
							JOIN @Dummy_Tab1 B ON A.[DH_PROV_NUMBER]	= B.[DH_PROV_NUMBER]														
							WHERE (@key1 = 0 and @key2 = 0 and @key3 = 0 and @key4 = 0 and @key5 = 0 and @key6 = 0 and @key7 = 0)
						END 
						
						
						
					 
						
						 
											
						if(@key1 = 0 and @key2 = 0 and @key3 = 0 and @key4 = 0 and @key5 = 0 and @key6 = 0 and @key7 = 0 and @key8 = 0) 
						BEGIN
							
							Select @group1 = MAX(id) from dbo.temp_Stage_CA_Profile_Data
														
							INSERT INTO dbo.temp_Stage_CA_Profile_Data([ID],[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
											,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY],[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4],[DH_CLIA_NUMBER]
											,[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME],[DA_PROV_BUSINESS_NAME]
											,[DH_ENROL_STAT_CD_1],count1,iter,criteria)
							SELECT   @group1+1 ,[DH_SSN],[DH_EMP_ID_NO],[DH_PROV_NUMBER],[DH_LEGAL_NAME]
									,[DH_PROV_BUSINESS_NAME],[DH_PROV_TYP],[DH_PAY_TO_LN1],[DH_PAY_TO_CITY],[DH_PAY_TO_STATE]
											,[DH_PAY_TO_ZIP5],[DH_PAY_TO_ZIP4],[DH_ADDR_LN1],[DH_ADDR_CITY],[DH_ADDR_STATE]
											,[DH_ADDR_ZIP5],[DH_ADDR_ZIP4],[DH_PIN],[DH_PROV_TELE_NO],[DH_MAIL_TO_LN1] 
											,[DH_MAIL_TO_CITY] ,[DH_MAIL_TO_STATE],[DH_MAIL_TO_ZIP5],[DH_MAIL_TO_ZIP4],[DH_CLIA_NUMBER]
											,[DH_PROV_LIC_NO],[DH_OWNER_NUM],[DH_SERV_LOC_NUM],[DA_LEGAL_NAME],[DA_PROV_BUSINESS_NAME]
											,[DH_ENROL_STAT_CD_1],@count1,@iteration1,@criteria
							FROM @Dummy_Tab1
							
						END
						
						
			
		Set @group1 = 0				
		delete from @Dummy_Tab1	
		Set @key1 = 0			
		Set @key2 = 0
		Set @key3 = 0
		Set @key4 = 0			
		Set @key5 = 0
		Set @key6 = 0				
		Set @key7 = 0	
		Set @Key8 = 0			
		Set @criteria = NULL
		SET @SSN_Legalname = NULL
		SET @Legalname = NULL	
		Set @iteration1 = @iteration1 + 1
		--Select @iteration1 = MIN(id) from DBO.temp_Stage_CA_FULL_Data_26OCT where @iteration1 < id
    END

END


GO

