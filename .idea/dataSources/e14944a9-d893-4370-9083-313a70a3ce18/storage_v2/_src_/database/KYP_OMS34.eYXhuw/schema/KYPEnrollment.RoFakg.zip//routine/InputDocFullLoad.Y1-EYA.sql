
-- =============================================
-- Author:		Rahul Raghavendra
-- Create date: 18-Oct-2016
-- Description:	This SP will be executed as a nightly batch
--/*1*/: Telephone number was coming as NULL so we are taking it from ORG table or Person without any condition.
--/*1*/because of that category condition is ignored.
--/*2*/ Author: NagaPullaiah Fix: Fixing Telephone Number Issue for Account Type=R
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.	Author		Date			Description
---------------------------------------------------------------------------------------
-- #1					Pullaiah					Telephone number was coming as NULL so we are taking it from ORG table or Person without any condition.because of that category condition is ignored.
-- #2		CAPAVE-1244	Sundar		06-Feb-2017		Changed the calculation for ApplicationDate to consider ADM_Case.DateReceived for Portal records (LegacyAccountNo is null)
-- #3		CAPAVE-1221 Sundar		07-Feb-2017		Changed the field mappings for Specialty code and Date.
-- #4		Adhoc Issue								Duplicate Category of Services are displayed, To fix CurrentRecordflag=1 is considered.
-- #5		CAPAVE-1753	Sundar		30-Jun-2017		Changed the logic for Analyst, Reviewer and Supervisor fields
-- #6		CAPAVE-1832
--			/1833/1834,1835 Sundar      4-Jul-2017		Added the logic of Deleted records not to be considered for Full load
-- #7		MD-4		Sundar		17-Jul-2017		Changes made for MD Input Doc Implementation
-- #8		KEN-12838	Sundar		26-Aug-2017		Implemented PAVE 3.0 changes for Input Document
-- #9		PI-831		Sundar		18-Sep-2017		Changed ProviderTypeDetail value from Code+Description to only Code
-- #10		CAPAVE-2587		Sundar		14-Feb-2018		Changed the reference table for the field Business name from pADM_Account to Paccount_PDM_Organization
-- #11      CAPAVE-2576 Ramya       20-April-2018		Changed the reference table for the field Rejectreasoncode  from EDM_AccountInternalUse to pADM_Account
-- #12		CAPAVE-2666	Sundar		28-FEb-2018		Reverted the reference table for the field Business name from Paccount_PDM_Organization to pADM_Account
-- #13		KEN-13850	Sundar		8-Mar-2018		Biller ProviderTypeCode should always display the first 3 characters (Ex. 087a) for DMC in Input Document.
-- #14		KEN-15462	Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- #15     MD-1286&1287	Ramya		04-April-2018		--MD inpatient and outpatient changes for inputdoc(newly added columns ,NCPDP,FacilityType,NumberOfBed)
-- 16		CAPAVE-2990	Sundar		2-May-2018		Added the logic to display LegalName as Business when Business name is blank
-- 17		CAPAVE-3142,3139 Sundar	8-May-2018	Added EDM_AccountInternalMany.IsApproved = 1 to consider only the approved IUD changes
-- 18       KEN-16609    Ramya       6-June-2018     condition added to display LIC number and effective date based on LIC type and providertype code
-- 19		CAPAVE-3576	 Sundar		13-July-2018	If "Same as SSN" option is selected for EIN field in Portal then, EIN value should not displayed in Input document
-- 20		CAPAVE-3612	 Sundar		13-July-2018	Service County should be displayed only if OutofStateInd is 0
-- 21		KEN-18239	 Sundar		27-Jul-2018		Considered IsPrimary Field for displaying License
-- 22		KEN-19009	 Sundar		1-Oct-2018		Added IsDeleted=0 in Person and Organization tables to eliminate deleted records
-- 23		KEN-21177	 Sundar		27-Mar-2019		Added "MFCertificate" type for Mastectomy ProviderType implementation

CREATE PROCEDURE [KYPEnrollment].[InputDocFullLoad] 

AS
BEGIN
	SET NOCOUNT ON;

	Declare @StateCode varchar(2); --Added for #5 MD-4

	SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
		
	--Added for #5 MD-4
	Select @StateCode = StateCode
	From kyp.OIS_App_Version;
	
	--IF Exists(Select object_id
	--			from sys.objects 
	--			where type='U'
	--			and name='AccountInputDocFullLoad'
	--			and schema_id=(select schema_id
	--							from sys.schemas
	--							where name='KYPEnrollment'))
	--Begin
	--	Drop table KYPENROLLMENT.AccountInputDocFullLoad;
	--end
	
	truncate table KYPENROLLMENT.AccountInputDocFullLoad;
	
	IF (@StateCode = 'CA' or @StateCode IS NULL) --Added for #5 MD-4
	Begin --Added for #5 MD-4	
		INSERT INTO [KYPEnrollment].[AccountInputDocFullLoad]
				   ([AccountID]
				   ,[PartyID]
				   ,[ProvNameScan]
				   ,[Analyst]
				   ,[AnalystDT]
				   ,[Reviewer]
				   ,[ReviewerDT]
				   ,[Supervisor]
				   ,[SupervisorDT]
				   ,[NPI]
				   ,[OwnerNo]
				   ,[SerLocNo]
				   ,[ProviderType]
				   ,[LegalName]
				   ,[SSN]
				   ,[EffectiveBeingDate]
				   ,[EffEndDT]
				   ,[EIN]
				   ,[TINUpdateDate]
				   ,[TINUpdateType]
				   ,[facility]
				   ,[AccountType]
				   ,[ProvLocTypeCd]
				   ,[DBAName]
				   ,[Phone1]
				   ,[AdsL1]
				   ,[AdsL2]
				   ,[City]
				   ,[Acc_State]
				   ,[ZipPlus4]
				   ,[MAdsL1]
				   ,[MAdsL2]
				   ,[MCity]
				   ,[MState]
				   ,[MZipPlus4]
				   ,[SAdsL1]
				   ,[SAdsL2]
				   ,[SCity]
				   ,[SState]
				   ,[SZipPlus4]
				   ,[OutOfStateInd]
				   ,[AppDT]
				   ,[ProvTypeDetail]
				   ,[PracticeCode]
				   ,[StatusAcc]
				   ,[StatusBgnDt]
				   ,[RejResCode]
				   ,[Number]
				   ,[EffDT]
				   ,[CliaNumber]
				   ,[SpecProcTypeCode]
				   ,[CHDPCode]
				   ,[ProvCode]
				   ,[ProvCodeDT]
				   ,[ReEnrollIn]
				   ,[ReEnrollDate]
				   ,[ScodeIdty1]
				   ,[ScodeIdty2]
				   ,[ScodeIdty3]
				   ,[ScodeIdty4]
				   ,[ScodeIdty5]
				   ,[ScodeIdty6]
				   ,[ScodeIdty7]
				   ,[ScodeIdty8]
				   --Commented the Taxonomy, COS and Specialty field for #8 Ken-12838
				 /*  ,[TaxnC1]
				   ,[TaxnC2]
				   ,[TaxnC3]
				   ,[TaxnC4]
				   ,[TaxnC5]
				   ,[TaxnC6]
				   ,[TaxnC7]
				   ,[CI1]
				   ,[CEfD1]
				   ,[CExD1]
				   ,[CI2]
				   ,[CEfD2]
				   ,[CExD2]
				   ,[CI3]
				   ,[CEfD3]
				   ,[CExD3]
				   ,[CI4]
				   ,[CEfD4]
				   ,[CExD4]
				   ,[CI5]
				   ,[CEfD5]
				   ,[CExD5]
				   ,[CI6]
				   ,[CEfD6]
				   ,[CExD6]
				   ,[CI7]
				   ,[CEfD7]
				   ,[CExD7]
				   ,[CI8]
				   ,[CEfD8]
				   ,[CExD8]
				   ,[CI9]
				   ,[CEfD9]
				   ,[CExD9]
				   ,[CI10]
				   ,[CEfD10]
				   ,[CExD10]
				   ,[CI11]
				   ,[CEfD11]
				   ,[CExD11]
				   ,[CI12]
				   ,[CEfD12]
				   ,[CExD12]
				   ,[CI13]
				   ,[CEfD13]
				   ,[CExD13]
				   ,[CI14]
				   ,[CEfD14]
				   ,[CExD14]
				   ,[CI15]
				   ,[CEfD15]
				   ,[CExD15]
				   ,[Spec_C1]
				   ,[SpecCertDT1]
				   ,[Spec_C2]
				   ,[SpecCertDT2]
				   ,[Spec_C3]
				   ,[SpecCertDT3]
				   */
				   ,[GRPIDTY]
				   ,[LABStat]
				   ,[LABEFFDT]
				   ,[DocNo]
				   ,[ProfileID]
				   ,[LastLoadedDate]
				   ,[FName] --Added for #8 KEN-12838
				   ,[MName] --Added for #8 KEN-12838
				   ,[LName] --Added for #8 KEN-12838
				   ,[Title] --Added for #8 KEN-12838
				   ,[Suffix] --Added for #8 KEN-12838
				   ,CNO --County Code Added for #8 KEN-12838
				   )   
			SELECT Distinct x.AccountID,x.PartyID, x.ProvNameScan,
					Analyst,
					CONVERT( varchar(10), x.AnalystDate, 101) AS AnalystDT,
					Reviewer,
					CONVERT( varchar(10), x.ReviewerDate, 101) AS ReviewerDT,
					Supervisor,
					CONVERT( varchar(10), x.SupervisorDate, 101) AS SupervisorDT,
					NPI,OwnerNo,ServiceLocationNo as SerLocNo ,ProviderTypeCode AS ProviderType,LegalName,
					SSN,
					CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffectiveBeingDate,
					CASE WHEN CONVERT(varchar(10),x.EffectiveEndDate,101)='01/01/1900' THEN '' 
					When (X.EffectiveBeingDate IS NOT NULL and X.EffectiveEndDate IS null) Then '12/31/2069' --Added for KEN-15179 by Sundar on 16Jan 2018
					ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT,

					EIN,
					CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdateDate,

					TINUpdateType,x.facility,x.AccountType,
					ProvLocTypeCd,BusinessName as DBAName,Phone1,AddressLine1 as AdsL1,AddressLine2 as AdsL2,
					City,Acc_State,ZipPlus4,MAddressLine1 AS MAdsL1,MAddressLine2 as MAdsL2,MCity,MState,MZipPlus4,
					SAddressLine1 as SAdsL1 ,SAddressLine2 as SAdsL2,SCity,SState,SZipPlus4,OutOfStateInd,--PSS055 PROVIDER DETAIL SCREEN
					CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT
					--,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail --Commented for #9 PI-831
					,ProviderTypeCode AS ProvTypeDetail --Added for #9 PI-831
					,PracticeCode,StatusAcc,
					CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt,
					StatusReasonCode AS RejResCode,--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
					Number,
					CASE CONVERT(varchar(10),x.EffectiveDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT,

					x.CliaNumber,x.SpecProcTypeCode,x.CHDPCode,x.ProvisionalCode as ProvCode,

					CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
					WHEN '01/01/1900' 
					THEN '' 
					ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT,

					ReEnrolInd as ReEnrollIn,ReEnrollDate,
					SCodeIdentification1 as ScodeIdty1,SCodeIdentification2 as ScodeIdty2 ,SCodeIdentification3  as ScodeIdty3,SCodeIdentification4  as ScodeIdty4,SCodeIdentification5  as ScodeIdty5,
					SCodeIdentification6 as  ScodeIdty6,SCodeIdentification7 as ScodeIdty7 ,SCodeIdentification8 as ScodeIdty8,
					--Commented the Taxonomy, COS and Specialty field for #8 Ken-12838
					/*
					TaxonomyCode1 as TaxnC1,TaxonomyCode2 as TaxnC2,TaxonomyCode3 as TaxnC3,TaxonomyCode4 as TaxnC4,
					TaxonomyCode5 as TaxnC5,TaxonomyCode6 as TaxnC6,TaxonomyCode7 as TaxnC7,
					CCodeIdentification1 as CI1,CCodeDateEffDate1 AS  CEfD1 , CCodeDateExpDate1  AS CExD1
					,CCodeIdentification2 as CI2,CCodeDateEffDate2  AS CEfD2 , CCodeDateExpDate2  AS CExD2
					,CCodeIdentification3 as CI3,CCodeDateEffDate3  AS CEfD3 , CCodeDateExpDate3  AS CExD3
					,CCodeIdentification4 as CI4,CCodeDateEffDate4  AS CEfD4 , CCodeDateExpDate4  AS CExD4
					,CCodeIdentification5 as CI5,CCodeDateEffDate5  AS CEfD5 , CCodeDateExpDate5  AS CExD5
					,CCodeIdentification6 as CI6,CCodeDateEffDate6  AS CEfD6 , CCodeDateExpDate6  AS CExD6
					,CCodeIdentification7 as CI7,CCodeDateEffDate7  AS CEfD7 , CCodeDateExpDate7  AS CExD7
					,CCodeIdentification8 as CI8,CCodeDateEffDate8  AS CEfD8 , CCodeDateExpDate8  AS CExD8
					,CCodeIdentification9 as CI9,CCodeDateEffDate9 AS CEfD9 , CCodeDateExpDate9 AS CExD9

					,CCodeIdentification10 as CI10, CCodeDateEffDate10 AS  CEfD10 , CCodeDateExpDate10  AS CExD10
					,CCodeIdentification11 as CI11, CCodeDateEffDate11  AS  CEfD11 , CCodeDateExpDate11  AS CExD11
					,CCodeIdentification12 as CI12, CCodeDateEffDate12  AS CEfD12 , CCodeDateExpDate12  AS CExD12
					,CCodeIdentification13 as CI13, CCodeDateEffDate13  AS CEfD13 , CCodeDateExpDate13  AS CExD13
					,CCodeIdentification14 as CI14, CCodeDateEffDate14  AS CEfD14 , CCodeDateExpDate14  AS CExD14
					,CCodeIdentification15 as CI15, CCodeDateEffDate15  AS CEfD15 , CCodeDateExpDate15  AS CExD15


					,Speciality_Code1 AS Spec_C1,SpecCertDate1 AS SpecCertDT1
					,Speciality_Code2 AS Spec_C2, SpecCertDate2 AS SpecCertDT2
					,Speciality_Code3 AS Spec_C3,SpecCertDate3 AS SpecCertDT3, 
					*/
					GRPIDTY
					,LABStat
					,LABEFFDT
					,AccountNumber AS DocNo-- INTO Kypenrollment.AccountInputDocFullLoad
					,ProfileID
					--,@Username,
					,GETDATE() [LastLoadedDate]
					,FirstName  --Added for #8 KEN-12838
					,MiddleName  --Added for #8 KEN-12838
					,LastName  --Added for #8 KEN-12838
					,Title  --Added for #8 KEN-12838
					,Suffix  --Added for #8 KEN-12838
					,SCounty --Added for #8 KEN-12838
			 from (
					SELECT 
					A.AccountID As AccountID,
					U1.FullName AS Analyst,
					U1.LastActionDate AS AnalystDate,
					u2.FullName AS Supervisor ,
					U2.LastActionDate AS SupervisorDate,
					
					--U3.FullName AS Reviewer, --Commented for CAPAVE-1753
					--U3.LastActionDate AS ReviewerDate, --Commented for CAPAVE-1753
					U1.FullName AS Reviewer, --Added for CAPAVE-1753
					U1.LastActionDate AS ReviewerDate,	--Added for CAPAVE-1753	
					
					A.LastActionDate,
					A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
					A.PartyID ,
					A.LegalName AS ProvNameScan,
					A.NPI,
					A.OwnerNo,
					A.ServiceLocationNo,
					Left(A.ProviderTypeCode,3) ProviderTypeCode, --Consider only the first 3 characters for #13 KEN-13850 
					A.ProviderType,
					A.LegalName,
					A.SSN,
					isnull(B.EffectiveBeingDate,C.BillingBeginDate) as EffectiveBeingDate,
					--isnull(B.EffectiveEndDate,isnull(C.BillingEndDate,'12/31/2069')) as EffectiveEndDate,
					isnull(B.EffectiveEndDate,C.BillingEndDate) as EffectiveEndDate,--Changed for KEN-15179 by Sundar on 16Jan 2018
					Case When isnull(A.SSNasEIN,0) = 1 Then NULL Else A.EIN End as EIN, --Added Case Stat. for #19 CAPAVE-3576
					C.TINUpdateDate,
					C.TINUpdateType,
					A.ProvLocTypeCd as facility,
					A.AccountType as AccountType,
					c.ProvisionalCode AS ProvLocTypeCd,
					D.CodeIdentification,
					Case When isnull(A.BusinessName,'')='' Then A.LegalName
							Else A.BusinessName End as BusinessName,--Commented for #10 CAPAVE-2587 --Changed the field reference for CAPAVE-2666 --Changed for #12 CAPAVE-2666 --Added case statement for CAPAVE-2990
					--Q.BusinessName, --Changed for #10 CAPAVE-2587
					--Case when(P.Phone1 is null)then
					--Q.Phone1
					--else
					--E.Phone1
					--end AS Phone1,
					--Case when O.Category='Institutional' then
					--	Q.Phone1
					--	When O.Category='Physician' then
					--	P.Phone1
					--	End as Phone1,
						--Added	--Telephone Logic for Account type R
					(
					Case when T.ParentPartyID is not null and A.AccountType='R' and A.IsDeleted<>'1' 
					and S.PartyID is not null
					and A.IsProvOwnedData='1' then S.Phone1 
					else ISNULL(P.Phone1,Q.Phone1)end   
					)Phone1, /*1*/
					--Telephone Logic for Account type R/*2*/
						
					--	ISNULL(P.Phone1,Q.Phone1) Phone1, /*1*/
						
					-- TO PAY ADDRESS
					F.AddressLine1,F.AddressLine2,F.City,F.Abreviation as Acc_State,F.ZipPlus4 AS ZipPlus4,
					--MAILING ADDRESS
					G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.Abreviation AS MState,G.ZipPlus4 AS MZipPlus4,
					--SERVICE ADDRESS
					H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.Abreviation AS SState,H.ZipPlus4 AS SZipPlus4,
					C.OutOfStateInd,
					--PSS055 PROVIDER DETAIL SCREEN
					--A.ApplicationDate, --#2
					Case when A.LegacyAccountNo is NOT null then A.ApplicationDate
						else AC.DateCreated
						End ApplicationDate, --#2			
					A.ProviderType AS ProviderTypeDETAIL,
					C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,

					A.StatusAcc,
					A.StatusBeginDate,
					--C.RejectReasonCode StatusReasonCode,  --CAPAVE-2576 Ramya       22-Feb-2018		Changed the reference table for the field Rejectreasoncode  from EDM_AccountInternalUse to pADM_Account
                   replace(LEFT(A.StatusReasonCode , 2),' ','') StatusReasonCode,
					J.Number AS Number,
					J.EffectiveDate AS EffectiveDate,
					K.CliaNumber,
					C.SpecProcTypeCode, 
					C.CHDPCode as CHDPCode, /*Added for CHDP Code*/
					C.ProvisionalCode,
					C.ProvisionalCodeDate,
					C.ReEnrolInd,
					CONVERT(varchar(10),C.ReEnrolDate,101) as ReEnrollDate,
					--PSS038 PHYSICIAN CERTIFICATION
					--L.Speciality_Code,
					Case when(A.AccountType='G') then
					'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
					ELSE 
					'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
					END AS GRPIDTY,

					C.LabStatusCode AS LABStat,
					

					convert(varchar(10),C.LabStatusCodeDate,101) as LABEFFDT,
					A.AccountNumber
					,Z.ProfileID As ProfileID
					,E.FirstName --Added for #8 KEN-12838
					,E.MiddleName --Added for #8 KEN-12838
					,E.LastName --Added for #8 KEN-12838
					,isnull(E.ProfessionalTitle,E.Salutation) Title --Added for #8 KEN-12838
					,E.Sufix Suffix --Added for #8 KEN-12838
					--Added for #8 KEN-12838
					,Case When Isnull(C.OutOfStateInd,'0') = '0' Then H.CountyCode Else Null End SCounty --Added Case Statement for #20 CAPAVE-3612 
					from KYPEnrollment.pADM_Account A 
					
					--Commented for CAPAVE-1753
					  left join
					  (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
						   from KYPEnrollment.pAccount_History Acc
							INNER JOIN
						   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
						   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
						   where y.RoleName in('ReviewerS','Reviewer'))ROL
						   ON ACC.LastActorUserID =ROL.UserID)X
						   WHERE X.ROW=1) U1 on U1.AccountID=A.AccountID 
					   
					   left join 
					   
					   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
						   from KYPEnrollment.pAccount_History Acc
							INNER JOIN
						   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
						   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
						   where y.RoleName in('SupervisorR','SupervisorS'))ROL
						   ON ACC.LastActorUserID =ROL.UserID)X
						   WHERE X.ROW=1) U2 on U2.AccountID=A.AccountID
					   left join 
					   
					   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
						   from KYPEnrollment.pAccount_History Acc
							INNER JOIN
						   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
						   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
						   where y.RoleName in('ConfirmerS','Confirmer'))ROL
						   ON ACC.LastActorUserID =ROL.UserID)X
						   WHERE X.ROW=1) U3 on U3.AccountID=A.AccountID
						   --Commented for CAPAVE-1753
				 --  			Left Join (SELECT distinct AccountID, FullName, LastActionDate
					--				FROM (Select A.AccountID,Ur.UserID,U.FullName, DateTime LastActionDate, ROW_NUMBER() Over( Partition by A.AccountID ORDER BY C.CaseID desc,id DESC) R
					--							From KYP.ADM_WorkflowHistory H
					--							Join KYP.ADM_Case C on H.CaseID = Convert(varchar(20),C.CaseID)
					--							Join KYPEnrollment.pADM_Account A on C.AccountNo = A.AccountNumber
					--							Join KYP.OIS_JT_UserRole UR on H.UserID = UR.UserID	
					--							Join KYP.OIS_Role R on UR.RoleID = R.RoleID
					--							Join kyp.OIS_User U on UR.UserID=U.UserID
					--							Where H.UserID is not null
					--							and r.RoleName in('ReviewerS','Reviewer')
					--							) RT	
					--				Where RT.R = 1) U1 on A.AccountID = U1.AccountID
					--Left Join (SELECT distinct AccountID, FullName, LastActionDate
					--				FROM (Select A.AccountID,Ur.UserID,U.FullName, DateTime LastActionDate, ROW_NUMBER() Over( Partition by A.AccountID ORDER BY C.CaseID desc,id DESC) R
					--							From KYP.ADM_WorkflowHistory H
					--							Join KYP.ADM_Case C on H.CaseID = Convert(varchar(20),C.CaseID)
					--							Join KYPEnrollment.pADM_Account A on C.AccountNo = A.AccountNumber
					--							Join KYP.OIS_JT_UserRole UR on H.UserID = UR.UserID	
					--							Join KYP.OIS_Role R on UR.RoleID = R.RoleID
					--							Join kyp.OIS_User U on UR.UserID=U.UserID
					--							Where H.UserID is not null
					--							and r.RoleName in('SupervisorR','ConfirmerS')
					--							) RT	
					--				Where RT.R = 1) U2 on A.AccountID = U2.AccountID 
						   	   	 
					LEFT OUTER JOIN KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
					LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID
																			AND (C.IsApproved = 1 OR C.IsApproved is null)--#14	KEN-15462
					LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt' 
																			AND (D.IsApproved = 1 OR D.IsApproved is null)--#17	CAPAVE-3142, 3139
					LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
														AND isnull(E.Deleted,0)=0 --Added this condition by Sundar for KEN-21501 on 7-Mar-2019 
					--This is for Pay-to Address Details
					left outer join (select F.AddressLine1,F.AddressLine2,F.City,LS.Abreviation,F.Zip, F.ZipPlus4,x.PartyID  
										from KYPEnrollment.pAccount_PDM_Address F 
										inner join KYPEnrollment.pAccount_PDM_Location X
											 on F.AddressID = X.AddressID 
											 and X.Type='Pay-to'
											 and X.CurrentRecordFlag=1
										Left join kyp.LK_Screening LS on F.State=LS.Description
										 )F on F.PartyID = a.PartyID 
					--This is for Service Address Details	 
					left outer join (select H.AddressLine1,H.AddressLine2,H.City,LS.Abreviation,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County
											,CC.Code CountyCode --Added for #8 KEN-12838
										from KYPEnrollment.pAccount_PDM_Address H 
										inner join KYPEnrollment.pAccount_PDM_Location X
											 on H.AddressID = X.AddressID 
											 and X.Type='Servicing'
											 and X.CurrentRecordFlag=1
										Left join kyp.LK_Screening LS on H.State=LS.Description
										Left Join kyp.CA_CountyCodes CC on H.County = CC.Name
											 )H on H.PartyID = a.PartyID 
					--This is for Mailing Address Details
					left outer join(select G.AddressLine1,G.AddressLine2,G.City,LS.Abreviation,G.Zip,G.ZipPlus4,x.PartyID  
										from KYPEnrollment.pAccount_PDM_Address G
										inner join KYPEnrollment.pAccount_PDM_Location X
											 on G.AddressID = X.AddressID 
											 and X.Type='Mailing'
											 and X.CurrentRecordFlag=1
											 Left join kyp.LK_Screening LS on G.State=LS.Description
											 )G on G.PartyID = a.PartyID	 
					/*Added to fix 2 license problem for one account*/
					/*Changed the logic for #8 KEN-12838*/
					--LEFT  OUTER JOIN (select T1.PartyID,T1.Number,T1.EffectiveDate
					--					FROM KYPEnrollment.pAccount_PDM_Number T1
					--					Join (select MAX(NumberID) NumberID
					--						from KYPEnrollment.pAccount_PDM_Number
					--						where Type='Professional License' AND CurrentRecordFlag=1
					--						group by PartyID) T2 on T1.NumberID=T2.NumberID) J ON J.PartyID=A.PartyID 
					Left Join (Select PartyID,Number,EffectiveDate
								From (Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Row_Number() Over(Partition by t1.Partyid order by isnull(T1.IsPrimary,0) Desc,t1.Type desc,t1.LastActionDate desc) R
									from KYPEnrollment.pAccount_PDM_Number T1
									Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
									where t1.CurrentRecordFlag=1
									and Type in ('Professional License','Certificate')
									and T2.ProviderTypeCode not in ('021','029')
									Union all
									Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Row_Number() Over(Partition by t1.Partyid order by isnull(T1.IsPrimary,0) Desc,t1.LastActionDate desc) R
									from KYPEnrollment.pAccount_PDM_Number T1
									Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
									where t1.CurrentRecordFlag=1
									and T1.Number is not null
									and Type in ('orthotistBOC','orthotistABCOP')
									and T2.ProviderTypeCode = '021'	
									Union all
									(Select Tab.PartyID,Tab.Number,Tab.Type,Tab.LastActionDate,Tab.EffectiveDate,Row_Number() Over(Partition by tab.Partyid order by Tab.IsPrimary Desc,tab.LastActionDate desc) R
									From (Select T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,Isnull(T1.IsPrimary,0) IsPrimary
											from KYPEnrollment.pAccount_PDM_Number T1
											Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
											where t1.CurrentRecordFlag=1
											and T1.Number is not null
											and T2.ProviderTypeCode = '029'	
											and Type in ('prosthetistBOC','prosthetistABCOP','orthProsthABCOP','MFCertificate')
											Union all
											Select T1.PartyId,SecondNumber,Type,t1.LastActionDate,T1.SecondEffectiveDate,Isnull(T1.IsPrimary,0) IsPrimary
											from KYPEnrollment.pAccount_PDM_Number T1
											Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
											where t1.CurrentRecordFlag=1
											and T1.SecondNumber is NOT null
											and T2.ProviderTypeCode = '029'	
											and Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')
											) Tab
										)		
									) T
									Where T.R = 1) J on J.PartyID = A.PartyID
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
					/*Added to fix 2 license problem for one account*/
					--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Speciality L ON L.PartyID=A.PartyID and  L.IsPrimary=NULL and L.CurrentRecordFlag=1
					--LEFT  OUTER JOIN KYPEnrollment.pADM_AccountStatus N ON N.AccountID=A.AccountID and N.CurrentRecordFlag=1
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID 
																			and isnull(P.Deleted,0)=0 --Added this condition for 22 KEN-19009
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
																			and isnull(Q.IsDeleted,0)=0 --Added this condition for 22 KEN-19009
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID
					LEFT  OUTER JOIN KYPEnrollment.pAccount_BizProfile_Details Z ON Z.AccountID=A.AccountID
					
					LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party T ON A.PartyID=T.ParentPartyID --Added /*2*/
																			AND T.Type = 'Contact Person' --Added for CAPAVE-910 on 31-Mar-2017 By Sundar			
					LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person S ON S.PartyID=T.PartyID  --Added /*2*/
					Left Join kyp.ADM_Case AC on A.ApplicationNumber=AC.Number --#2	
					Where A.IsDeleted = 0 --Added for #6 CAPAVE-1832		
					
			)x
			 --Commented the Taxonomy, COS and Specialty field for #8 Ken-12838	
			left join (select AccountID, SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
							SCodeIdentification6,SCodeIdentification7,SCodeIdentification8
							/*,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
							TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
							,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14,CCodeIdentification15,
							CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
							CCodeDateEffDate10,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,
							CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
							CCodeDateExpDate10,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,
							Speciality_Code1,Speciality_Code2,Speciality_Code3
							,SpecCertDate1,SpecCertDate2,SpecCertDate3*/
						from(SELECT C.AccountId, CONVERT(varchar(20),(case when CodeIdentification = 'other' then left(UPPER(CodeDescription),5) else CodeIdentification end)) as CodeIdentification
									,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
								from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
								inner join KYPEnrollment.EDM_AccountInternalUse C 
								on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
								Where (C.IsApproved = 1 OR C.IsApproved is null)--#14 KEN-15462
								AND (EDMAIM.IsApproved = 1 OR EDMAIM.IsApproved is null)--#17 CAPAVE-3142, 3139
								/*
								UNION All
								SELECT A.Accountid, CONVERT(varchar(MAx), P.Speciality_Code) /*Taxonmy Code will be displayed instead of Description*/
								,'TaxonomyCode'+CONVERT(varchar(10), ROW_NUMBER()  over(partition by A.Accountid order by  SpecialityID desc) ) seq
									FROM KYPEnrollment.pAccount_PDM_Speciality P
									inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID And P.Type='Taxonomy Code'
								UNION ALL
								SELECT C.AccountId,CONVERT(varchar(20),CodeIdentification)
								,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  ASC)) seq
									from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
									inner join KYPEnrollment.EDM_AccountInternalUse C 
									on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
									and EDMAIM.currentrecordflag=1-- #4
								UNION ALL	
								SELECT C.AccountId,CONVERT(varchar(10),CodeDateEffDate,101)
								,'CCodeDateEffDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  ASC)) seq
									from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
									inner join KYPEnrollment.EDM_AccountInternalUse C 
									on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
									and EDMAIM.currentrecordflag=1 -- #4
								UNION ALL	
								SELECT C.AccountId,CONVERT(varchar(10),CodeDateExpDate,101)
								,'CCodeDateExpDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  ASC)) seq
									from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
									inner join KYPEnrollment.EDM_AccountInternalUse C 
									on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'  
									and EDMAIM.currentrecordflag=1 -- #4
								/*****PI-651*****/
								--#3 - Changed the Specialty code and Date for CAPAVE-1221, PI-710
								--UNION ALL 
								--SELECT A.Accountid,CONVERT(varchar(20), P.CodeIdentification)
								--,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by P.CodeIdentification  desc  ) ) 
								--seq
								--	FROM KYPEnrollment.EDM_AccountInternalMany P 
								--	inner join KYPEnrollment.EDM_AccountInternalUse A  on P.AccountInternalUseID=A.AccountInternalUseID And P.CodeType='Physician'
								--UNION ALL 		
								--SELECT A.Accountid,CONVERT(varchar(10), P.CodeDateEffDate,101)
								--,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  P.CodeDateEffDate desc) ) seq
								--	FROM KYPEnrollment.EDM_AccountInternalMany P 
								--	inner join KYPEnrollment.EDM_AccountInternalUse A  on P.AccountInternalUseID=A.AccountInternalUseID And P.CodeType='Physician'
								UNION ALL 
								SELECT A.Accountid,CONVERT(varchar(20), P.Speciality_Code)
								,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by P.SpecialityID  desc  ) ) 
									FROM KYPEnrollment.pAccount_PDM_Speciality P 
									inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
									Where P.Type='Specialty Code'
									and P.CurrentRecordFlag = 1	 
								UNION ALL 		
								SELECT A.Accountid,CONVERT(varchar(10), P.SpecCertDate,101)
								,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  P.SpecialityID desc) ) seq
									FROM KYPEnrollment.pAccount_PDM_Speciality P 
									inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID 
									Where P.Type='Specialty Code'	
									and P.CurrentRecordFlag = 1							
								 /*****PI-651*****/
								 */
						)ML(AccountId,StatusValue,seq)
						PIVOT (max(ml.StatusValue)  
						FOR ml.seq IN (SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
						SCodeIdentification6,SCodeIdentification7,SCodeIdentification8
						/*,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
						TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
						,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14,CCodeIdentification15,
						CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
						CCodeDateEffDate10,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,
						CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
						CCodeDateExpDate10,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,
						Speciality_Code1,Speciality_Code2,Speciality_Code3
						,SpecCertDate1,SpecCertDate2,SpecCertDate3
						*/
						)) pvt 
			  )y on x.AccountID= y.AccountId
			  --where x.AccountId=(3302630)
			  OPTION (MAXDOP 4)
	End --Added for #5 MD-4
	
	--Added the IF statement for #5 MD-4
	If @StateCode = 'MD'
	Begin
		INSERT INTO [KYPEnrollment].[AccountInputDocFullLoad]
			   ([AccountID]
				,MA_ID
				,[NPI]
				,[LegalName]
				,DOB
				,[SAdsL1]
				,[SAdsL2]
				,[SCity]
				,[SState]
				,[SZipPlus4]
				,[SCounty]
				,[OutOfStateInd]
				,[Phone1]
				,[ProviderType]
				,Sort
				,[EIN]			   			   			   			   
				,[SSN]
				,[Number]
				,[EffDT]
				,LicenseExpiryDate
				,[CliaNumber]
				,[LabPermitNo]
				,[DEA]
				,[PracticeType]
				,[RevalidationDate]
				,AppDT
				,StatusAcc
				,StatusBgnDt
				,[PrevProv]
				,[Audit]
				,[AuditDate]
				,[EPSDT]		
				,[AdsL1]
				,[AdsL2]
				,[City]
				,[Acc_State]
				,[ZipPlus4]
				,[MAdsL1]
				,[MAdsL2]
				,[MCity]
				,[MState]
				,[MZipPlus4]							   			   
				--,[MCAIDAgreement]
			    --,[NCPDP]--Added for #15
	      --      ,[FacilityType]--Added for #15
	      --      ,[NumberOfBed]--Added for #15
				,UserName	
				,LastLoadedDate	--Added by Sundar on 10Oct2017						   		
				)
		SELECT 
			AccountID	
			,MAID						
			,NPI	
			,LegalName
			,DOB
			,SAddressLine1
			,SAddressLine2
			,SCity
			,SState
			,SZipPlus4
			,County --Changed for mapping table from Pdm_Address to Edm_AccountInternalUse
			,OutOfStateInd
			,Phone1
			,ProviderType
			,Sort
			,TaxID							
			,SSN
			,LicNo
			,LicBeginDate
			,LicEndDate
			,CliaNumber
			,LabPermitNumber			
			,DEA
			,PracTypeCode									
			,RevalidationDate --Changed for mapping table from Edm_AccountInternalUse to Padm_Account.ReenrollmentDate
			,ApplicationDate
			,StateStatusAcc
			,StatusBeginDate
			,PrevProviderNo
			,AuditIndicator
			,AuditDate
			,EPSDT
			,AddressLine1
			,AddressLine2
			,City
			,Acc_State
			,ZipPlus4	
			,MAddressLine1
			,MAddressLine2
			,MCity
			,MState
			,MZipPlus4
			--,NCPDP--Added for #15
	  --      ,FacilityType--Added for #15
	  --      ,NumberOfBed--Added for #15
			,UserName	
			,GETDATE() --Added by Sundar on 10Oct2017			
		From [kypenrollment].[Vw_MD_InputDoc_FullLoad]			
		--Where AccountID=3303758
		OPTION (MAXDOP 4);
	End

	SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
END


GO

