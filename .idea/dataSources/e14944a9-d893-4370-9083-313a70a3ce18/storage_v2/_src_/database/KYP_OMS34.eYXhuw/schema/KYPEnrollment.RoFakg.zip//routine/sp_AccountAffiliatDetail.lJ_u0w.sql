





/* ==========================================================
-- Author:		<Rahul Raghavendra>
-- PROCEDURE: create AffiliatedAccount with affiliated data.   
-- PARAMETERS: 
-- @account_id : accountID for account to pass
-- @userID : UserId who as requested  
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_AccountAffiliatDetail]
	@account_id INT,
	@userID varchar(50)
AS
	BEGIN
	
	declare @parentAccountNo varchar(50);
	SELECT @parentAccountNo = AccountNumber FROM KYPEnrollment.pADM_Account where AccountID = @account_id;
	
	INSERT INTO [KYPEnrollment].[pAccountAffiliatDetail]
	
		(AccountID, LegacyAccountNo, P_SYS_ID, portaluserid, AccountType, ServiceLocationNo, ProvLocTypeCd, RiskDescriptor, OwnerNo, ProviderType, Risk, 
		EnrollmentRiskLevel, PIN, LegalName, DBAName, Prefix, Gender, Title, NPI, NPIType, PracticeAddress, StatusBeginDate, DateDied, IncorporatedDate, 
		OOBDate, ProvTypeUpdateDate, RiskScore, ApplicationDate, LastActionDate, ActivationDate, DeActivationDate, LastAction, DateCreated, DateModified, 
		LastActionReason, LastActionComments, LastActorUserID, LastActionApprovedBy, AccountUpdateDate, AccountUpdateUserID, AccountUpdateReason, 
		AccountUpdateComments, LastRevalidationDate, LastRevalidationReason, RevalidationDueDate, LastApplicationType, AccountUpdatedBy, LastAlertedDate, 
		LastScreenedDate, LastBilledDate, LastRenderedDate, LastDeltaLoadDate, ReenrollmentDate, ApplicationNumber, StatusAcc, SSN, SSNH, EIN, EINH, 
		Phone, PartyID, ReenrollmentIndicator, AccountNumber, IsDeleted, BusinessName, CreatedBy, profile_id, PackageName, ProviderTypeCode, 
		FutureStatus, FutureDate, StatusReasonCode, EnrollStatusComments, FutureStatusReasonCode, FutureEnrollComments, ApplicationStatusAcc, 
		ApplicationBeginDate, ApplicationReasonCode, ApplicationComments, SuppStatusAcc, SuppBeginDate, SuppReasonCode, SuppComments, 
		SuppFutureStatusAcc, SuppFutureDate, SuppFutureReason, SuppFutureComments, SuppDeActivationDate, IsPastOwner, ScheduleType, TIN, 
		AccountTypeDescriptor, OldMStatus, OldMStatusReasonCode, OldMStatusBeginDate, AccHistory, IsProvOwnedData, AccProcessing, 
		StateStatusAcc, StateEnrollmentStatus,AffiliationStartDate,AffiliationEndDate,UserID, ParentAccountID, ParentAccountNo )
		(
		SELECT 
		A1.AccountID, A1.LegacyAccountNo, A1.P_SYS_ID, B.RenderingAffiliationID, A1.AccountType, A1.ServiceLocationNo, A1.ProvLocTypeCd, A1.RiskDescriptor, A1.OwnerNo, A1.ProviderType, A1.Risk, A1.
		EnrollmentRiskLevel, A1.PIN, A1.LegalName, A1.DBAName, A1.Prefix, A1.Gender, A1.Title, A1.NPI, A1.NPIType, A1.PracticeAddress, A1.StatusBeginDate, A1.DateDied, A1.IncorporatedDate, A1.
		OOBDate, A1.ProvTypeUpdateDate, A1.RiskScore, A1.ApplicationDate, A1.LastActionDate, A1.ActivationDate, A1.DeActivationDate, A1.LastAction, A1.DateCreated, A1.DateModified, A1.
		LastActionReason, A1.LastActionComments, A1.LastActorUserID, A1.LastActionApprovedBy, A1.AccountUpdateDate, A1.AccountUpdateUserID, A1.AccountUpdateReason, A1.
		AccountUpdateComments, A1.LastRevalidationDate, A1.LastRevalidationReason, A1.RevalidationDueDate, A1.LastApplicationType, A1.AccountUpdatedBy, A1.LastAlertedDate, A1.
		LastScreenedDate, A1.LastBilledDate, A1.LastRenderedDate, A1.LastDeltaLoadDate, A1.ReenrollmentDate, A1.ApplicationNumber, A1.StatusAcc, A1.SSN, A1.SSNH, A1.EIN, A1.EINH,
		A1.Phone, A1.PartyID, A1.ReenrollmentIndicator, A1.AccountNumber, A1.IsDeleted, A1.BusinessName, A1.CreatedBy, A1.profile_id, A1.PackageName, A1.ProviderTypeCode, A1.
		FutureStatus, A1.FutureDate, A1.StatusReasonCode, A1.EnrollStatusComments, A1.FutureStatusReasonCode, A1.FutureEnrollComments, A1.ApplicationStatusAcc, A1.
		ApplicationBeginDate, A1.ApplicationReasonCode, A1.ApplicationComments, A1.SuppStatusAcc, A1.SuppBeginDate, A1.SuppReasonCode, A1.SuppComments, A1.
		SuppFutureStatusAcc, A1.SuppFutureDate, A1.SuppFutureReason, A1.SuppFutureComments, A1.SuppDeActivationDate, A1.IsPastOwner, A1.ScheduleType, A1.TIN, A1.
		AccountTypeDescriptor, A1.OldMStatus, A1.OldMStatusReasonCode, A1.OldMStatusBeginDate, A1.AccHistory, A1.IsProvOwnedData, A1.AccProcessing, A1.
		StateStatusAcc, null,B.AffiliationStartDate,B.AffiliationEndDate,@userID, @account_id, @parentAccountNo
		from 
		KYPEnrollment.pAccount_RenderingAffiliation B 
		inner join KYPEnrollment.pADM_Account A1 on B.AffiliatedAccountID=A1.AccountID
		where B.AccountID=@account_id
		and A1.IsDeleted=0
		and B.CurrentRecordFlag=1
		and (B.AffiliationEndDate is null or CONVERT(Date,B.AffiliationEndDate) >= CONVERT(Date,GETDATE()))

		union All
		SELECT 
		A1.AccountID, A1.LegacyAccountNo, A1.P_SYS_ID, B.RenderingAffiliationID, A1.AccountType, A1.ServiceLocationNo, A1.ProvLocTypeCd, A1.RiskDescriptor, A1.OwnerNo, A1.ProviderType, A1.Risk, A1.
		EnrollmentRiskLevel, A1.PIN, A1.LegalName, A1.DBAName, A1.Prefix, A1.Gender, A1.Title, A1.NPI, A1.NPIType, A1.PracticeAddress, A1.StatusBeginDate, A1.DateDied, A1.IncorporatedDate, A1.
		OOBDate, A1.ProvTypeUpdateDate, A1.RiskScore, A1.ApplicationDate, A1.LastActionDate, A1.ActivationDate, A1.DeActivationDate, A1.LastAction, A1.DateCreated, A1.DateModified, A1.
		LastActionReason, A1.LastActionComments, A1.LastActorUserID, A1.LastActionApprovedBy, A1.AccountUpdateDate, A1.AccountUpdateUserID, A1.AccountUpdateReason, A1.
		AccountUpdateComments, A1.LastRevalidationDate, A1.LastRevalidationReason, A1.RevalidationDueDate, A1.LastApplicationType, A1.AccountUpdatedBy, A1.LastAlertedDate, A1.
		LastScreenedDate, A1.LastBilledDate, A1.LastRenderedDate, A1.LastDeltaLoadDate, A1.ReenrollmentDate, A1.ApplicationNumber, A1.StatusAcc, A1.SSN, A1.SSNH, A1.EIN, A1.EINH,
		A1.Phone, A1.PartyID, A1.ReenrollmentIndicator, A1.AccountNumber, A1.IsDeleted, A1.BusinessName, A1.CreatedBy, A1.profile_id, A1.PackageName, A1.ProviderTypeCode, A1.
		FutureStatus, A1.FutureDate, A1.StatusReasonCode, A1.EnrollStatusComments, A1.FutureStatusReasonCode, A1.FutureEnrollComments, A1.ApplicationStatusAcc, A1.
		ApplicationBeginDate, A1.ApplicationReasonCode, A1.ApplicationComments, A1.SuppStatusAcc, A1.SuppBeginDate, A1.SuppReasonCode, A1.SuppComments, A1.
		SuppFutureStatusAcc, A1.SuppFutureDate, A1.SuppFutureReason, A1.SuppFutureComments, A1.SuppDeActivationDate, A1.IsPastOwner, A1.ScheduleType, A1.TIN, A1.
		AccountTypeDescriptor, A1.OldMStatus, A1.OldMStatusReasonCode, A1.OldMStatusBeginDate, A1.AccHistory, A1.IsProvOwnedData, A1.AccProcessing, A1.
		StateStatusAcc, null,B.AffiliationStartDate,B.AffiliationEndDate,@userID, @account_id, @parentAccountNo
		from
		KYPEnrollment.pAccount_RenderingAffiliation B 
		inner join KYPEnrollment.pADM_Account A1 on B.AccountID=A1.AccountID 
		where B.AffiliatedAccountID=@account_id
		and A1.IsDeleted=0
		and B.CurrentRecordFlag=1	
		and (B.AffiliationEndDate is null or CONVERT(Date,B.AffiliationEndDate) >= CONVERT(Date,GETDATE()))
		)
		
END


GO

