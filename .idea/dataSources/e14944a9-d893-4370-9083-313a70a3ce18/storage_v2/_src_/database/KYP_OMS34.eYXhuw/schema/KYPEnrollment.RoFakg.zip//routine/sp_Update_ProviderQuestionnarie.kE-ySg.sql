
/* ==========================================================
-- Author:		<NRojas>
-- PROCEDURE: Update Business Service for Legacy Accounts
-- PARAMETERS: 
-- @party_account_id: Party from account.
-- @application_id : Application ID. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_ProviderQuestionnarie]
   @party_account_id INT, 
   @application_id INT,
   @last_action_user_id VARCHAR (100)
AS
BEGIN
   SET NOCOUNT ON
   DECLARE @name VARCHAR(50),
		   @type VARCHAR(50),
		   @value VARCHAR(50)

   SELECT @name = Name
    FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie
    WHERE PartyID = @party_account_id;
    
    IF NOT EXISTS (SELECT TOP 1 Name FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie WHERE PartyID = @party_account_id)
    BEGIN
		SELECT @name = Name, @type = Type,
			   @Value = Value
		FROM KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie
    
		INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (Name, Type, Value, PartyID) 
				VALUES (@name,@type,@value, @party_account_id);
    END 
END


GO

