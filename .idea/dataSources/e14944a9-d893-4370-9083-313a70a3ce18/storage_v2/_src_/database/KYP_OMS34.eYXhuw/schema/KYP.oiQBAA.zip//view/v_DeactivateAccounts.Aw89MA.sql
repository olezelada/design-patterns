







CREATE VIEW [KYP].[v_DeactivateAccounts] 
AS
	select A.AccountID as AccountID,E.AddressID as AddressID, 
A.AccountNumber As AccountNumber,
D.ProfileName As ProfileName,
A.LegalName  As ProviderName,
A.NPI as NPI,
E.AddressLine1+', '+isnull(E.AddressLine2,'')+', '+isnull(City,'')+', '+isnull(State,'')+', '+isnull(County,'')+', '+isnull(ZipPlus4,'') As ServiceAddress,
case when (A.IsCrossover=1) then 'Y' else 'N' END as Crossover,
A.ProviderTypeCode as ProviderTypeCode,
C.ProfileID As ProfileID,
D.ProfileID As MaseterProfileID,
F.ProviderTypeDescription AS ProviderTypeDescription,
A.isDeactivationRequired As DeactivationRequired

from
KYPEnrollment.pADM_Account A
join KYPEnrollment.pAccount_PDM_Location B on B.PartyID=A.PartyID and Type='Servicing' 
join KYPEnrollment.pAccount_PDM_address E on E.AddressID=B.AddressID 
join KYPEnrollment.pAccount_BizProfile_Details C ON C.AccountID = A.AccountID
join KYPEnrollment.pAccount_BizProfile_Master D ON D.ProfileID = C.ProfileID
join KYP.PDM_ProviderTypeCode F on F.ProviderTypeCode=A.ProviderTypeCode
where 
 A.IsDeleted=0 and B.IsDeleted=0 and E.CurrentRecordFlag=1 --and C.CurrentRecordFlag=1
And A.StatusAcc in('1 - Active','3 - Pending','7 - Active Rendering (indirect)','9 - Temporary Suspended')


GO

