
CREATE PROCEDURE [KYPEnrollment].[UpdateBloodBankSections]
@application_Code VARCHAR (30)
,@account_party_id INT
,@last_action_user_id VARCHAR(100)
, @app_party_Id     INT

AS
BEGIN

        DECLARE @cliaId INT
        DECLARE @number_id INT
        DECLARE @today_date DATE = GETDATE()
		    DECLARE @is_deleted BIT = 0
		    DECLARE @current_record_flag BIT = 1
		    DECLARE @last_action VARCHAR(1) = 'C'

          IF (@application_Code IN ('F_BB_OE' , 'F_BB_SP'))
          BEGIN
            --only pAccount_PDM_Clia
            SELECT @cliaId = CliaID
            FROM KYPEnrollment.pAccount_PDM_Clia
            WHERE PartyID = @account_party_id AND CurrentRecordFlag=1
            IF @cliaId is null OR @cliaId = 0
            BEGIN
               EXEC [KYPEnrollment].[sp_Copy_Clia] @account_party_id, @app_party_Id, @last_action_user_id, NULL;
            END

            --only pAccount_PDM_Number
            SELECT @number_id = NumberID
            FROM KYPEnrollment.pAccount_PDM_Number
            WHERE PartyID = @account_party_id AND Type = 'LicenseAndCertificate' AND CurrentRecordFlag=1
            IF (@number_id IS NULL OR @number_id=0 )
            BEGIN
              EXEC [KYPEnrollment].[Copy_Twin_Number] @account_party_id, @app_party_Id, @last_action_user_id, 'LicenseAndCertificate';
            END
          END
END


GO

