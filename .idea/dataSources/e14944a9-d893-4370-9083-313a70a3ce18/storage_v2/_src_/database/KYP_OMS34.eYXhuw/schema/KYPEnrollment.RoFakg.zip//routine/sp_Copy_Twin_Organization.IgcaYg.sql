

/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: create Organization Twin.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @remarks_type : this is the type of the form.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Twin_Organization]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @remarks_type           VARCHAR (100)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @org_id         INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization] (
                  [PartyID],
                  [TIN],
                  [LegalName],
                  [DBAName1],
                  [BusinessName],
                  [Phone1],
                  [Remarks],
                  [CreatedBy],
                  [DateCreated],
                  [IsDeleted],
                  [Fax],
                  [NPI],
                  [License],
                  [EIN],
                  [Medicaid],
                  [DEA],
                  [Sellers],
                  [IsCorporation],
                  [Extension],
                  [CalOmsNumber],
                  [IsCalOms],
                  [LastAction],
                  [LastActionDate],
                  [LastActorUserID],
                  [LastActionApprovedBy],
                  [CurrentRecordFlag],
                  [OrgNumber],
                  [WebSiteUrl])
      SELECT @party_account_id,
             [TIN],
             [LegalName],
             [DBAName1],
             [BusinessName],
             [Phone1],
             [Remarks],
             [CreatedBy],
             @date_created,
             [IsDeleted],
             [Fax],
             [NPI],
             [License],
             [EIN],
             [Medicaid],
             [DEA],
             [Sellers],
             [IsCorporation],
             [Extension],
             [CalOmsNumber],
             [IsCalOms],
             'C',
             @date_created,
             @last_action_user_id,
             @last_action_user_id,
             1,
             [OrgNumber],
             [WebSiteUrl]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization]
       WHERE PartyID = @party_app_id AND Remarks = @remarks_type

   SELECT @org_id = SCOPE_IDENTITY ();
   RETURN @org_id
END


GO

