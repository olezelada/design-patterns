

CREATE VIEW [KYPEnrollment].[AccountHistoryView] as
  select  row_number() over ( order by a.HistoryID )as HistoryID
		  ,a.AccountID
		  ,a.Remarks
		  ,a.ActionName 
		  ,a.LastActorUserID
		  ,a.LastActionDate
		  ,a.TypeView 
		  ,a.ApplicationNumber
		  ,a.AccountStatus
		  ,a.ApplicationType
		  ,a.Resolution  Resolution
		  ,a.Field
		  ,a.OldValue
		  ,a.NewValue
		  ,a.AlertNumber
		  ,a.WatchlistCategory  
		  ,a.MonStatus
		  ,a.MonResolution
		  ,a.MonRelevance
		  ,a.NoteNumber NoteNumber
		  ,a.NoteTitle
		  ,a.DocNumber DocNumber
		  ,a.DocTitle  DocTitle 
		  ,a.MessageSubject
  from ( SELECT distinct  ach.HistoryID
			  ,ach.AccountID
			  ,ach.Remarks
			  ,pa.ActionName 
			  ,(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u 
where p.PersonID = u.PersonID and u.UserID= ach.LastActorUserID) as LastActorUserID
			  ,ach.LastActionDate
			  ,' 'TypeView 
			  ,hah.AplicationNumber ApplicationNumber
			  ,hah.AccountStatus
			  ,hah.ApplicationType
			  ,hah.Resolution  Resolution
			  ,(SELECT STUFF((SELECT '|'+Field
								FROM KYPEnrollment.HIS_MadeChange
							   where historyID = ach.HistoryID
							   FOR XML PATH('')
							  ),1,1, ''
							)) Field
			  ,(SELECT STUFF((SELECT '|'+oldvalue
								FROM KYPEnrollment.HIS_MadeChange
							   where historyID = ach.HistoryID
							   FOR XML PATH('')
							  ),1,1, ''
							)) OldValue
			  ,(SELECT STUFF((SELECT '|'+NewValue
								FROM KYPEnrollment.HIS_MadeChange
							   where historyID = ach.HistoryID
							   FOR XML PATH('')
							  ),1,1, ''
							)) NewValue
			  ,ha.AlertNumber
			  ,ha.WatchlistCategory  
			  ,ha.MonStatus
			  ,ha.MonResolution
			  ,ha.MonRelevance
			  ,hn.NoteNumber NoteNumber
			  ,hn.NoteTitle
			  ,hd.DocNumber DocNumber
			  ,hd.DocTitle  DocTitle 
			  ,me.MessageSubject
		 FROM KYPEnrollment.pAccount_History ach
			LEFT JOIN KYPEnrollment.HIS_Alert ha ON ha.HistoryID = ach.HistoryID and (ha.IsDeleted is null or ha.IsDeleted = 'false') 
			LEFT JOIN KYPEnrollment.HIS_ApplicationHistory hah ON hah.HistoryID = ach.HistoryID and (hah.IsDeleted is null or hah.IsDeleted = 'false') 
			LEFT JOIN KYPEnrollment.HIS_Document hd ON hd.HistoryID = ach.HistoryID  
			LEFT JOIN KYPEnrollment.HIS_MadeChange md ON md.HistoryID = ach.HistoryID and (md.IsDeleted is null or md.IsDeleted = 'false') 
			LEFT JOIN KYPEnrollment.HIS_Message me ON me.HistoryID = ach.HistoryID and (me.IsDeleted is null or me.IsDeleted = 'false') 
			LEFT JOIN KYPEnrollment.HIS_Note hn ON hn.HistoryID = ach.HistoryID and (hn.IsDeleted is null or hn.IsDeleted = 'false') 
			, KYPEnrollment.pAction pa
		 WHERE (ach.IsDeleted is null or ach.IsDeleted = 'false') 
		   and (hah.HistoryID is not null or ha.HistoryID is not null or hd.HistoryID is not null or md.HistoryID is not null or me.HistoryID is not null or hn.HistoryID is not null )
		   and ach.ActionID = pa.ActionID
		   ) a;


GO

