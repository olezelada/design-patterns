-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 10-May-2014
-- Description:	Deleting Message - Attachments link
--				for forwarded messages home page
-- =============================================
CREATE TRIGGER [KYP].[deleteTempAttachForMsgs]  
   ON   [KYP].[OIS_MessagesTemp]
   AFTER DELETE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @NewMessageID INT,
			@AttachmentID INT
			
	SET @NewMessageID = (SELECT NewMessageID FROM deleted);   
	
	DELETE FROM [KYP].[OIS_JT_MessageAttachment] WHERE MessageID = @NewMessageID	
	DELETE FROM [KYP].[OIS_MessagesTemp] WHERE NewMessageID = @NewMessageID
END


GO

