-- =============================================
-- Author:		Yogesh Sharma
-- Create date: July 28 2012
-- Description:	Find the OwnerID if Party exists as an owner of the provider 
-- =============================================
CREATE PROCEDURE [KYP].[p_FindOwnerRecord]
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@ProviderID int
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @OwnerID int
	/********Get the OwnerID based on PartyID of owner + ProviderID of the provider**********/
	if exists (	
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_Owner B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.ProviderID = @ProviderID
	)
	begin
	select @OwnerID = B.OwnerID
	from KYP.PDM_Party A
	inner join KYP.PDM_Owner B
		on A.PartyID = B.PartyID 		
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		and B.ProviderID = @ProviderID	
    return @OwnerID	
	end	
	else 
	return -1   	
END


GO

