CREATE PROCEDURE [KYPEnrollment].[sp_ProfileTinProcessedFromDeltaForMOCAatTaxID]
(
	@UniqueProfileTINXML XML
)
AS
BEGIN
	
	BEGIN TRY
	BEGIN TRAN
	
		DECLARE @XMLOutput		INT,
				@ProfileID		VARCHAR(40),
				@TaxID			VARCHAR(10),
				@ParentPartyID	INT,
				@AccountID		INT,
				@I				INT = 1,
				@J				INT = 1,
				@lCount			INT,
				@IsPastOwner	BIT
		
		DECLARE @TempPersonOrOrganization TABLE
		(
			PartyID						INT,
			Type						VARCHAR(50),
			Name						VARCHAR(100),
			IsProvider 					BIT,
			IsEnrolled 					BIT,
			IsTemp 						BIT,
			IsActive 					BIT,
			DateDeleted					SMALLDATETIME,
			MOCARelationshipStartDate	SMALLDATETIME,
			MOCARelationshipEndDate		SMALLDATETIME,
			CurrentRecordFlag 			BIT,
			SSN 						VARCHAR(11),
			Salutation					VARCHAR(50),
			FirstName					VARCHAR(25),
			MiddleName					VARCHAR(25),
			LastName					VARCHAR(25),
			DOB 						DATETIME,
			PersonOrOrganzationNPI		VARCHAR(10),
			OrgLegalName				VARCHAR(100),
			TIN							VARCHAR(11),
			EIN							VARCHAR(30),
			ProviderID					INT,
			ProviderNPI 				BIGINT,
			AddressID					INT,
			AddressLine1 				VARCHAR(250),
			AddressLine2 				VARCHAR(50),
			City 						VARCHAR(25),
			State 						VARCHAR(40),
			Zip 						VARCHAR(5),
			ZipPlus4 					VARCHAR(50),
			AddressType 				VARCHAR(30),
			LocationID					INT,
			LocAddressType 				VARCHAR(25),
			PdmOwnerID					INT,
			OtherDate 					SMALLDATETIME,
			TypeForm					VARCHAR(100),
			OtherValue					VARCHAR(150),
			DocumentID					INT,
			TypeDoc 					VARCHAR(40),
			NumberDoc 					VARCHAR(16),
			IsStateIssued 				BIT,
			StateIssued 				VARCHAR(40),
			TransactionID				INT,
			Description 				VARCHAR(150),
			Amount 						VARCHAR(10),
			AdverseActionID				INT,
			QuestionID					INT,
			Type_x 						VARCHAR(100),
			Reason 						VARCHAR(1000),
			State_x 					VARCHAR(40),
			Date_x 						DATETIME,
			DateType 					VARCHAR(40),
			EffectiveDate 				DATETIME,
			AdverseActionNPI 			VARCHAR(10),
			AdverseActionCity 			VARCHAR(25),
			ProgramType 				VARCHAR(50),
			Where_x 					VARCHAR(100),
			Action_x 					VARCHAR(50),
			LicenseAuthority 			VARCHAR(100),
			LegalName 					VARCHAR(100),
			DBA 						VARCHAR(100),
			AppFormID 					INT,
			DocumentInstanceID 			INT,
			ProgramTypeOther 			VARCHAR(100),
			OtherOwnershipParentPartyID	INT,
			OwnersOrOtherOwnershipFlag	INT
		)

		DELETE FROM KYPEnrollment.MOCAatTaxIDMOCASpreadingHistory

		-- Insert all the Profile and TAX wise records received from Delta
		IF OBJECT_ID('tempdb..#TempDeltaProcessedProfileTIN') IS NOT NULL
		BEGIN
			DROP TABLE #TempDeltaProcessedProfileTIN
		END;

		CREATE TABLE #TempDeltaProcessedProfileTIN
		(
			ID			INT PRIMARY KEY IDENTITY(1,1),
			ProfileID	VARCHAR(40),
			TaxID		VARCHAR(10),
			AccountID	INT,
			PartyID		INT
		)

		-- Insert all the Profile and TAX wise records received from Delta
		IF OBJECT_ID('tempdb..#TempDeltaProcessedDistinctProfileTIN') IS NOT NULL
		BEGIN
			DROP TABLE #TempDeltaProcessedDistinctProfileTIN
		END;

		CREATE TABLE #TempDeltaProcessedDistinctProfileTIN
		(
			ID			INT PRIMARY KEY IDENTITY(1,1),
			ProfileID	VARCHAR(40),
			TaxID		VARCHAR(10)
		)

		-- Insert all the Accounts in #TempAccountsofTAXandProfilewise table for combination of ProfileID and TaxID
		IF OBJECT_ID('tempdb..#TempAccountsofTAXandProfilewise') IS NOT NULL
		BEGIN
			DROP TABLE #TempAccountsofTAXandProfilewise
		END;

		CREATE TABLE #TempAccountsofTAXandProfilewise
		(
			ID				INT PRIMARY KEY IDENTITY(1,1),
			AccountID		INT,
			AccountPartyID	INT,
			ProfileID		VARCHAR(40),
			TaxID			VARCHAR(10),
			IsPastOwner		BIT
		)
		
		-- Insert all the MOCAs in #TempPartysOfAccount table for an Account, if it not exist for ProfileID and TaxID
		IF OBJECT_ID('tempdb..#TempPartysOfAccount') IS NOT NULL
		BEGIN
			DROP TABLE #TempPartysOfAccount
		END;

		CREATE TABLE #TempPartysOfAccount
		(
			ID			INT PRIMARY KEY IDENTITY(1,1),
			SSNorTIN	VARCHAR(30),
			Type		VARCHAR(50),
			FirstName	VARCHAR(100),
			LastName	VARCHAR(100),
			LegalName	VARCHAR(100)
		)
		
		-- In below Temporary table, all the MOCAs will be created which are already exist for all the Accounts. This temporary table we are using for Performance purpose(Inside the loop, this SQL query shouldn't execute for each loop).
		SELECT	ACC.AccountID,ACC.PartyID AS AccountPartyID,P.PartyID AS PartyID,P.Type AS MOCAType,ACC.EIN,BPM.ProfileID,
				PRS.SSN AS SSN,ORG.EIN AS TIN,PRS.FirstName,PRS.LastName,ORG.LegalName,P.IsDeleted,P.CurrentRecordFlag,
				CAST(P.MOCARelationshipStartDate AS DATE) AS MOCARelationshipStartDate,CAST(P.MOCARelationshipEndDate AS DATE) AS MOCARelationshipEndDate
			INTO #TempAccountExistingMOCAs
			FROM KYPEnrollment.pADM_Account ACC
			JOIN KYPEnrollment.pAccount_Owner OWN
			ON ACC.AccountID = OWN.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
			ON ACC.AccountID	= BPD.AccountID
			JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
			ON BPD.ProfileId	= BPM.ProfileID
			JOIN KYPEnrollment.pAccount_PDM_Party P
			ON ACC.PartyID		= P.ParentPartyID
			LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
			ON	P.PartyID		= PRS.PartyID
			LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
			ON P.PartyID		= ORG.PartyID
			WHERE ACC.PackageName IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
				  ((LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)) AND
				  (OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
				  (ACC.EIN IS NOT NULL AND ACC.EIN != '') AND
				  ACC.NPI NOT LIKE '%[a-z]%' AND
				  LEFT(StatusAcc,1)		IN ('1','7','9') AND
				  ACC.IsDeleted			= 0 AND
				  IsTempProfile			= 0 AND
				  P.CurrentRecordFlag	= 1 AND
				  Type					IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual',
											'SubcontractorEntity','Individual Ownership','Entity Ownership')

		CREATE INDEX IdxAccountExistingMOCAs ON #TempAccountExistingMOCAs(AccountID)													
		
		EXEC SP_XML_PrepareDocument @XMLOutput OUTPUT,@UniqueProfileTINXML
		
		;WITH CTE
		AS
		(
			SELECT *
				FROM OPENXML(@XMLOutput,'//MOCAatTaxID/Accounts',2)
				WITH (ProfileID VARCHAR(40),TaxID VARCHAR(10),AccountID INT,PartyID INT)
		)
		INSERT INTO #TempDeltaProcessedProfileTIN(ProfileID,TaxID,AccountID,PartyID)
			SELECT * FROM CTE
			
		INSERT INTO #TempDeltaProcessedDistinctProfileTIN(ProfileID,TaxID)
			SELECT DISTINCT ProfileID,TaxID FROM #TempDeltaProcessedProfileTIN

		-- Below loop will run for each Profile and TaxID
		WHILE @I <= (SELECT COUNT(1)
						FROM #TempDeltaProcessedDistinctProfileTIN)

		BEGIN

			SELECT @ProfileID = ProfileID,@TaxID = TaxID
				FROM #TempDeltaProcessedDistinctProfileTIN
				WHERE ID = @I

			INSERT INTO #TempAccountsofTAXandProfilewise(AccountID,AccountPartyID,ProfileID,TaxID,IsPastOwner)
				SELECT ACC.AccountID,PartyID AS AccountPartyID,BPM.ProfileID,ACC.EIN AS TaxID,ACC.IsPastOwner
					FROM KYPEnrollment.pADM_Account ACC
					JOIN KYPEnrollment.pAccount_Owner OWN
					ON ACC.AccountID = OWN.AccountID
					JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
					ON ACC.AccountID		= BPD.AccountID
					JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
					ON BPD.ProfileId		= BPM.ProfileId
					WHERE	ACC.EIN			= @TaxID		AND
							BPM.ProfileID	= @ProfileID	AND
							ACC.PackageName IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
							LEFT(StatusAcc,1) IN ('1','7','9') AND
							ACC.IsDeleted	= 0 AND
							IsTempProfile	= 0 AND
							((LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)) AND
							(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
							ACC.NPI NOT LIKE '%[a-z]%'

			-- Take unique Individual MOCAs from the Accounts having same TaxID and ProfileID. This temporary table we are using for Performance purpose(Inside the loop, this SQL query shouldn't execute for each loop).
			SELECT *
				INTO #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN
				FROM (SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
							 MOCARelationshipEndDate,CurrentRecordFlag,SSN,Salutation,FirstName,MiddleName,LastName,DOB,NPI
						FROM (SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
								 MOCARelationshipEndDate,P.CurrentRecordFlag,PRS.SSN,PRS.Salutation,PRS.FirstName,PRS.MiddleName,PRS.LastName,
								 PRS.DOB,PRS.NPI,ROW_NUMBER() OVER (PARTITION BY PRS.SSN,PRS.FirstName,PRS.LastName ORDER BY P.MocaRelationshipStartDate ASC) AS RN
								FROM KYPEnrollment.pADM_Account ACC
								JOIN KYPEnrollment.pAccount_Owner OWN
								ON ACC.AccountID = OWN.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
								ON	ACC.AccountID	= BPD.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
								ON	BPM.ProfileID	= @ProfileID	AND
									BPD.ProfileId	= BPM.ProfileID AND
									IsTempProfile	= 0
								JOIN KYPEnrollment.pAccount_PDM_Party P
								ON	ACC.PartyID		= P.ParentPartyID AND
									P.Type			IN('TransactionIndividual','SubcontractorIndividual','Individual Ownership') AND
									P.CurrentRecordFlag = 1
								JOIN KYPEnrollment.pAccount_PDM_Person PRS
								ON	P.PartyID		= PRS.PartyID
								WHERE	ACC.EIN			= @TaxID AND
										ACC.PackageName	IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
										ACC.IsDeleted	= 0 AND
										(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND
										(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
										ACC.NPI NOT LIKE '%[a-z]%' AND
										LEFT(StatusAcc,1) IN ('1','7','9')/* AND
										ISNULL(REPLACE(PRS.SSN,'-',''),'1') NOT IN(SELECT ISNULL(REPLACE(SSN,'-',''),'2') -- Don't pick the MOCAs which are coming through Delta load as they are the priority one and we are capturing them in below query.
																						FROM #TempDeltaProcessedProfileTIN Temp
																						JOIN KYPEnrollment.pAccount_PDM_Person PRS
																						ON Temp.PartyID = PRS.PartyID
																						WHERE ProfileID = @ProfileID AND
																							  TaxID		= @TaxID)*/) ILV
							WHERE ILV.RN = 1 AND
								  ISNULL(REPLACE(ILV.SSN,'-',''),'1') NOT IN(SELECT ISNULL(REPLACE(SSN,'-',''),'2') -- Don't pick the MOCAs which are coming through Delta load as they are the priority one and we are capturing them in below query.
																				FROM #TempDeltaProcessedProfileTIN Temp
																				JOIN KYPEnrollment.pAccount_PDM_Person PRS
																				ON Temp.PartyID = PRS.PartyID
																				WHERE ProfileID = @ProfileID AND
																					  TaxID		= @TaxID)

						UNION
							-- If the Delta Processed any MOCAs then take that MOCA as a priority one else above query will take the top MOCA base on partitioning Condition.
							SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
								   MOCARelationshipEndDate,CurrentRecordFlag,SSN,Salutation,FirstName,MiddleName,LastName,DOB,NPI
								FROM (SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
											 MOCARelationshipEndDate,P.CurrentRecordFlag,PRS.SSN AS SSN,PRS.Salutation,PRS.FirstName,PRS.MiddleName,
											 PRS.LastName,PRS.DOB,PRS.NPI,ROW_NUMBER() OVER (PARTITION BY PRS.SSN,PRS.FirstName,PRS.LastName ORDER BY P.MocaRelationshipStartDate ASC) AS RN
										FROM #TempDeltaProcessedProfileTIN Temp
										JOIN KYPEnrollment.pAccount_PDM_Party P
										ON Temp.PartyID	= P.PartyID
										JOIN KYPEnrollment.pAccount_PDM_Person PRS
										ON	P.PartyID	= PRS.PartyID) DP
										WHERE DP.RN = 1) ILV1

			-- Take unique Organization MOCAs from the Accounts having same TaxID and ProfileID. This temporary table we are using for Performance purpose(Inside the loop, this SQL query shouldn't execute for each loop).
			SELECT *
				INTO #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN
				FROM (SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
							 MOCARelationshipEndDate,CurrentRecordFlag,LegalName,TIN,NPI,EIN
						FROM (SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
									 MOCARelationshipEndDate,P.CurrentRecordFlag,ORG.LegalName,ORG.TIN,ORG.NPI,ORG.EIN,
									 ROW_NUMBER() OVER (PARTITION BY ORG.EIN,ORG.LegalName ORDER BY P.MocaRelationshipStartDate ASC) AS RN
								FROM KYPEnrollment.pADM_Account ACC
								JOIN KYPEnrollment.pAccount_Owner OWN
								ON ACC.AccountID = OWN.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
								ON	ACC.AccountID	= BPD.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
								ON	BPM.ProfileID	= @ProfileID	AND
									BPD.ProfileId	= BPM.ProfileID AND
									IsTempProfile	= 0
								JOIN KYPEnrollment.pAccount_PDM_Party P
								ON	ACC.PartyID		= P.ParentPartyID AND
									P.Type			IN('TransactionEntity','SubcontractorEntity','Entity Ownership') AND
									P.CurrentRecordFlag = 1
								JOIN KYPEnrollment.pAccount_PDM_Organization ORG
								ON	P.PartyID		= ORG.PartyID
								WHERE	ACC.EIN			= @TaxID AND
										ACC.PackageName	IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
										ACC.IsDeleted	= 0 AND
										(LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16) AND
										(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
										ACC.NPI NOT LIKE '%[a-z]%' AND
										LEFT(StatusAcc,1) IN ('1','7','9')/* AND
										ISNULL(REPLACE(ORG.EIN,'-',''),'1') NOT IN(SELECT ISNULL(REPLACE(EIN,'-',''),'2') -- Don't pick the MOCAs which are coming through Delta load as they are the priority one and we are capturing them in below query.
																						FROM #TempDeltaProcessedProfileTIN Temp
																						JOIN KYPEnrollment.pAccount_PDM_Organization ORG
																						ON Temp.PartyID = ORG.PartyID
																						WHERE ProfileID = @ProfileID AND
																							  TaxID		= @TaxID)*/) ILV
							WHERE ILV.RN = 1 AND
								  ISNULL(REPLACE(ILV.EIN,'-',''),'1') NOT IN(SELECT ISNULL(REPLACE(EIN,'-',''),'2') -- Don't pick the MOCAs which are coming through Delta load as they are the priority one and we are capturing them in below query.
																				FROM #TempDeltaProcessedProfileTIN Temp
																				JOIN KYPEnrollment.pAccount_PDM_Organization ORG
																				ON Temp.PartyID = ORG.PartyID
																				WHERE ProfileID = @ProfileID AND
																					  TaxID		= @TaxID)

						UNION
							-- If the Delta Processed any MOCAs then take that MOCA as a priority one else above query will take the top MOCA base on partitioning Condition.
							SELECT PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
								   MOCARelationshipEndDate,CurrentRecordFlag,LegalName,TIN,NPI,EIN
								FROM (SELECT P.PartyID,P.Type,P.Name,P.IsProvider,P.IsEnrolled,P.IsTemp,P.IsActive,P.DateDeleted,MOCARelationshipStartDate,
											 MOCARelationshipEndDate,P.CurrentRecordFlag,ORG.LegalName,ORG.TIN,ORG.NPI,ORG.EIN AS EIN,
											 ROW_NUMBER() OVER (PARTITION BY ORG.EIN,ORG.LegalName ORDER BY P.MocaRelationshipStartDate ASC) AS RN
										FROM #TempDeltaProcessedProfileTIN Temp
										JOIN KYPEnrollment.pAccount_PDM_Party P
										ON Temp.PartyID	= P.PartyID
										JOIN KYPEnrollment.pAccount_PDM_Organization ORG
										ON	P.PartyID	= ORG.PartyID) DP
								WHERE DP.RN = 1) ILV1

		-- Take OtherOwnership MOCAs for Individual and Organization from all the Accounts having same TaxID and ProfileID. In Party table, for OtherOwnership MOCAs, ParentPartyID would be either Individual Ownership or Entity Ownership and that's why we have written different SELECT statement.
		SELECT	* /*OwnershipPartyID,OwnershipSSNorEIN,
				[Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[DateDeleted],
				[MOCARelationshipStartDate],[MOCARelationshipEndDate],[CurrentRecordFlag],
				OtherOwnershipSSN,OtherOwnershipFirstName,OtherOwnershipLastName,Salutation,MiddleName,DOB,
				OtherOwnershipPartyID,OtherOwnershipEIN,OtherOwnershipLegalName,TIN,PersonOrOrganizationNPI,
				AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,LocAddressType*/
			INTO #TempMOCARelationforOtherOwnershipHavingSameProfileAndTIN
			FROM (SELECT OwnershipPartyID,OwnershipSSNorEIN,
						 [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[DateDeleted],
						 [MOCARelationshipStartDate],[MOCARelationshipEndDate],[CurrentRecordFlag],
						 OtherOwnershipSSN,OtherOwnershipFirstName,OtherOwnershipLastName,Salutation,MiddleName,DOB,
						 OtherOwnershipPartyID,OtherOwnershipEIN,OtherOwnershipLegalName,TIN,PersonOrOrganizationNPI,
						 AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,LocAddressType
						FROM (SELECT P.ParentPartyID AS OwnershipPartyID,ISNULL(PRS.SSN,ORG.EIN) AS OwnershipSSNorEIN,
									 P.PartyID AS OtherOwnershipPartyID,P1.EIN AS OtherOwnershipEIN,P1.LegalName AS OtherOwnershipLegalName,
									 P1.SSN AS OtherOwnershipSSN,P1.FirstName AS OtherOwnershipFirstName,P1.LastName AS OtherOwnershipLastName,
									 P1.[Type],P1.[Name],P1.[IsProvider],P1.[IsEnrolled],P1.[IsTemp],P1.[IsActive],P1.[DateDeleted],
									 P1.[MOCARelationshipStartDate],P1.[MOCARelationshipEndDate],P1.[CurrentRecordFlag],
									 P1.Salutation,P1.MiddleName,P1.DOB,P1.PersonOrOrganizationNPI,P1.TIN,
									 ADR.AddressID,ADR.AddressLine1,ADR.AddressLine2,City,State,Zip,ZipPlus4,AddressType,LOC.LocationID,LOC.Type AS LocAddressType,
									 ROW_NUMBER() OVER (PARTITION BY ISNULL(PRS.SSN,ORG.EIN),P1.EIN,P1.LegalName,P1.SSN,P1.FirstName,P1.LastName ORDER BY ACC.AccountID) AS RN
								FROM KYPEnrollment.pADM_Account ACC
								JOIN KYPEnrollment.pAccount_Owner OWN
								ON ACC.AccountID = OWN.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Details BPD
								ON	ACC.AccountID	= BPD.AccountID
								JOIN KYPEnrollment.pAccount_BizProfile_Master BPM
								ON	BPM.ProfileID	= @ProfileID	AND
									BPD.ProfileId	= BPM.ProfileID AND
									IsTempProfile	= 0
								JOIN KYPEnrollment.pAccount_PDM_Party P
								ON	ACC.AccountID		= P.AccountID								
								JOIN(SELECT P.PartyID,ISNULL(PRS.SSN,'') AS SSN,ISNULL(PRS.FirstName,'') AS FirstName,ISNULL(PRS.LastName,'') AS LastName,
											'' AS EIN,'' AS LegalName,
											P.[Type],P.[Name],P.[IsProvider],P.[IsEnrolled],P.[IsTemp],P.[IsActive],P.[DateDeleted],
											P.[MOCARelationshipStartDate],P.[MOCARelationshipEndDate],P.[CurrentRecordFlag],
											PRS.Salutation,PRS.MiddleName,PRS.DoB,PRS.NPI AS PersonOrOrganizationNPI,'' AS TIN
										FROM KYPEnrollment.pAccount_PDM_Party P
										JOIN KYPEnrollment.pAccount_PDM_Person PRS
										ON P.PartyID = PRS.PartyID
										WHERE Type = 'OtherOwnershipIndividual' AND
											  P.CurrentRecordFlag = 1
									 UNION ALL
									  SELECT P.PartyID,'' AS SSN,'' AS FirstName,'' AS LastName,ISNULL(EIN,'') AS EIN,ISNULL(LegalName,'') AS LegalName,
											 P.[Type],P.[Name],P.[IsProvider],P.[IsEnrolled],P.[IsTemp],P.[IsActive],P.[DateDeleted],
											 P.[MOCARelationshipStartDate],P.[MOCARelationshipEndDate],P.[CurrentRecordFlag],
											'' AS Salutation,'' AS MiddleName,'' AS DoB,NPI AS PersonOrOrganizationNPI,TIN
										FROM KYPEnrollment.pAccount_PDM_Party P
										JOIN KYPEnrollment.pAccount_PDM_Organization ORG
										ON P.PartyID = ORG.PartyID
										WHERE Type = 'OtherOwnershipEntity' AND
											  P.CurrentRecordFlag = 1) P1
								ON P.PartyID		= P1.PartyID
								LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
								ON P.ParentPartyID		= PRS.PartyID
								LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
								ON P.ParentPartyID		= ORG.PartyID
								LEFT JOIN KYPEnrollment.pAccount_PDM_Location LOC
								ON	P1.PartyID			= LOC.PartyID AND
									LOC.CurrentRecordFlag	= 1
								LEFT JOIN KYPEnrollment.pAccount_PDM_Address ADR
								ON	LOC.AddressID	= ADR.AddressID				
								WHERE	ACC.EIN			= @TaxID AND
										ACC.PackageName	IN('GSP_P_DM','GSP_AL_BL','IGSP_P_DM','IGSP_NP_AP') AND
										ACC.IsDeleted	= 0 AND
										((LEN(ACC.AccountNumber) != 12 AND LEN(ACC.AccountNumber) != 16)) AND
										(OWN.EffectiveEndDate IS NULL OR OWN.EffectiveEndDate >= GETDATE()) AND
										ACC.NPI NOT LIKE '%[a-z]%' AND
										P.CurrentRecordFlag = 1 AND
										LEFT(StatusAcc,1) IN ('1','7','9')/* AND -- Pick the SubGroup MOCAs and spread them into MOCA at TaxID
										ACC.IsPastOwner	= 0*/) ILV
							WHERE ILV.RN = 1) ILV1

			WHILE @J <= (SELECT COUNT(1)
							FROM #TempAccountsofTAXandProfilewise)
			
			BEGIN
			
				SELECT @AccountID = AccountID,@ParentPartyID = AccountPartyID,@IsPastOwner = IsPastOwner
					FROM #TempAccountsofTAXandProfilewise
					WHERE ID = @J

				-- DELETE CODE

				-- We won't delete the Subcontractor MOCAs from MOCA at TaxID as it will be managed by the Portal itself.
				UPDATE KYPEnrollment.pAccount_PDM_Party
					SET MOCARelationshipEndDate	= ILV.MOCARelationshipEndDate,
						CurrentRecordFlag		= ILV.CurrentRecordFlag,
						IsDeleted				= ILV.IsDeleted,
						LastActionDate			= CONVERT(VARCHAR(8), GETDATE(), 112)
						-- What about MOCA Relationship End Date field here. Do we need to update or not. How will come to know it is deleted or deassociate from the Portal as both the cases Portal mark as Deleted only.
					FROM KYPEnrollment.pAccount_PDM_Party PRT
					JOIN (SELECT A.PartyID,B.CurrentRecordFlag,B.IsDeleted,B.MOCARelationshipEndDate -- A.AccountID,A.AccountPartyID,A.PartyID,A.EIN,A.ProfileID,A.SSN,A.TIN,A.FirstName,A.LastName,A.LegalName
							FROM (SELECT *
									FROM #TempAccountExistingMOCAs
									WHERE AccountID = @AccountID AND
										  MOCAType	IN('Individual Ownership','Entity Ownership')) A
							LEFT JOIN (SELECT P.AccountID,P.PartyID,P.Type AS MOCAType,ISNULL(PRS.SSN,ORG.EIN) AS SSNorTIN,
											  P.MOCARelationshipEndDate,P.CurrentRecordFlag,P.IsDeleted
											FROM #TempDeltaProcessedProfileTIN Temp
											JOIN KYPEnrollment.pAccount_PDM_Party P
											ON Temp.PartyID	= P.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
											ON P.PartyID	= PRS.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
											ON P.PartyID	= ORG.PartyID
											WHERE	Temp.ProfileID	= @ProfileID	AND
													Temp.TaxID		= @TaxID		AND
													P.Type			IN('Individual Ownership','Entity Ownership') AND
													Temp.PartyID	IS NOT NULL) B
							ON (REPLACE(A.SSN,'-','') = REPLACE(B.SSNorTIN,'-','') OR REPLACE(A.TIN,'-','') = REPLACE(B.SSNorTIN,'-','')) AND
							   (A.IsDeleted			!= B.IsDeleted OR A.CurrentRecordFlag != B.CurrentRecordFlag)
							WHERE	B.IsDeleted			IS NOT NULL AND
									B.CurrentRecordFlag IS NOT NULL) ILV
					ON PRT.PartyID = ILV.PartyID

				-- UPDATE CODE
				-- CAPAVE-2176, MOCARelationshipStartDate and MOCARelationshipEndDate update.
				-- We won't update the Subcontractor MOCAs from MOCA at TaxID as it will be managed by the Portal itself.
				UPDATE KYPEnrollment.pAccount_PDM_Party
					SET MOCARelationshipStartDate	= ILV.MOCARelationshipStartDate,
						MOCARelationshipEndDate		= ILV.MOCARelationshipEndDate,
						-- CurrentRecordFlag			= ILV.CurrentRecordFlag,
						-- IsDeleted					= ILV.IsDeleted,
						LastActionDate				= CONVERT(VARCHAR(8), GETDATE(), 112)
					FROM KYPEnrollment.pAccount_PDM_Party PRT
					JOIN (SELECT A.PartyID,B.CurrentRecordFlag,B.IsDeleted,B.MOCARelationshipStartDate,B.MOCARelationshipEndDate -- A.AccountID,A.AccountPartyID,A.PartyID,A.EIN,A.ProfileID,A.SSN,A.TIN,A.FirstName,A.LastName,A.LegalName
							FROM (SELECT *
									FROM #TempAccountExistingMOCAs
									WHERE AccountID = @AccountID AND
										  MOCAType	IN('Individual Ownership','Entity Ownership')) A
							LEFT JOIN (SELECT P.AccountID,P.PartyID,P.Type AS MOCAType,ISNULL(PRS.SSN,ORG.EIN) AS SSNorTIN,
											  P.MOCARelationshipStartDate,P.MOCARelationshipEndDate,P.CurrentRecordFlag,P.IsDeleted
											FROM #TempDeltaProcessedProfileTIN Temp
											JOIN KYPEnrollment.pAccount_PDM_Party P
											ON Temp.PartyID	= P.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
											ON P.PartyID	= PRS.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
											ON P.PartyID	= ORG.PartyID
											WHERE	Temp.ProfileID	= @ProfileID	AND
													Temp.TaxID		= @TaxID		AND
													P.Type			IN('Individual Ownership','Entity Ownership') AND
													Temp.PartyID	IS NOT NULL AND
													P.IsDeleted		= 0 AND
													P.CurrentRecordFlag = 1) B
							ON (REPLACE(A.SSN,'-','') = REPLACE(B.SSNorTIN,'-','') OR REPLACE(A.TIN,'-','') = REPLACE(B.SSNorTIN,'-','')) AND
								(A.MOCARelationshipStartDate != CAST(B.MOCARelationshipStartDate AS DATE) OR A.MOCARelationshipEndDate != CAST(B.MOCARelationshipEndDate AS DATE))
							   -- (A.IsDeleted			!= B.IsDeleted OR A.CurrentRecordFlag != B.CurrentRecordFlag)
							WHERE	B.IsDeleted			IS NOT NULL AND
									B.CurrentRecordFlag IS NOT NULL) ILV
					ON PRT.PartyID = ILV.PartyID

				-- For an Account, Below resulted output records needs to be inserted into Party, Person or Organization etc. tables as they are exist in UniqueMOCAsProfileTINwise table but not in Account

				INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
					SELECT MPT.SSNorTIN,MPT.MOCAType,NULL,NULL,NULL
						FROM KYPEnrollment.UniqueMOCAsProfileTINwise MPT
						LEFT JOIN (SELECT *
									FROM #TempAccountExistingMOCAs
									WHERE AccountID = @AccountID) P
						ON P.EIN		= MPT.TAXID AND
						   P.ProfileID	= MPT.ProfileID AND
						   (REPLACE(P.SSN,'-','') = REPLACE(MPT.SSNorTIN,'-','') OR REPLACE(P.TIN,'-','') = REPLACE(MPT.SSNorTIN,'-',''))
						WHERE	MPT.PROFILEID			= @ProfileID	AND
								MPT.TAXID				= @TaxID		AND
								MPT.IsDeleted			= 0	AND
								MPT.CurrentRecordFlag	= 1	AND
								MPT.MOCAType			IN('Individual Ownership','Entity Ownership') AND
								-- (MPT.SSNorTIN IS NOT NULL AND MPT.SSNorTIN != '') AND -- This condition is important else it will take Subcontractor MOCAs also
								P.AccountID				IS NULL;

				-- As discussed in the call with Bolivia team, MOCA shouldn't spread to the Sub Group Account
				IF @IsPastOwner = 0
			
				BEGIN
			
					INSERT INTO #TempPartysOfAccount(SSNorTIN,Type,FirstName,LastName,LegalName)
						SELECT MPT.SSNorTIN,MPT.MOCAType,MPT.FirstName,MPT.LastName,MPT.LegalName
							FROM KYPEnrollment.UniqueMOCAsProfileTINwise MPT
							LEFT JOIN (SELECT *
										FROM #TempAccountExistingMOCAs
										WHERE AccountID = @AccountID) P
							ON P.EIN		= MPT.TAXID AND
							   P.ProfileID	= MPT.ProfileID AND
							   (((MPT.FirstName IS NULL OR MPT.FirstName = '') AND (MPT.LastName IS NULL OR MPT.LastName = '')) OR (MPT.LegalName IS NULL OR MPT.LegalName = '')) AND
							   ((P.FirstName = MPT.FirstName AND P.LastName = MPT.LastName) OR P.LegalName = MPT.LegalName)  AND
							   P.MOCAType = MPT.MOCAType
							WHERE	MPT.PROFILEID			= @ProfileID	AND
									MPT.TAXID				= @TaxID		AND
									MPT.IsDeleted			= 0	AND
									MPT.CurrentRecordFlag	= 1	AND
									MPT.MOCAType			IN('TransactionIndividual','TransactionEntity','SubcontractorIndividual','SubcontractorEntity') AND
									P.AccountID				IS NULL;

				END
				
				MERGE KYPEnrollment.pAccount_PDM_Party TRGT
				USING			
				(SELECT	NULL AS PartyID,ILV1.Type,ILV1.Name,ILV1.IsProvider,ILV1.IsEnrolled,ILV1.IsTemp,ILV1.IsActive,ILV1.DateDeleted,
						ILV1.MOCARelationshipStartDate,ILV1.MOCARelationshipEndDate,ILV1.CurrentRecordFlag,ILV1.SSN,ILV1.Salutation,
						ILV1.FirstName,ILV1.MiddleName,ILV1.LastName,ILV1.DOB,ILV1.NPI,PRV.ProvID,PRV.NPI AS ProviderNPI,ADR.AddressID,
						ADR.AddressLine1,ADR.AddressLine2,ADR.City,ADR.State,ADR.Zip,ADR.ZipPlus4,ADR.AddressType,LOC.LocationID,
						LOC.Type LocAddressType,POR.PdmOwnerID,POR.OtherDate,POR.TypeForm,POR.OtherValue,
						DOC.DocumentID,DOC.TypeDoc,DOC.NumberDoc,DOC.IsStateIssued,DOC.StateIssued,OT.TransactionID,OT.Description,OT.Amount,
						AA.AdverseActionID,AA.QuestionID,AA.Type_x,AA.Reason,AA.State_x,AA.Date_x,AA.DateType,AA.EffectiveDate,
						AA.NPI AS AdverseActionNPI,AA.City AS AdverseActionCity,AA.ProgramType,AA.Where_x,AA.Action_x,AA.LicenseAuthority,
						AA.LegalName,AA.DBA,AA.AppFormID,AA.DocumentInstanceID,AA.ProgramTypeOther
					FROM (SELECT PRS.*
							FROM #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN PRS
							JOIN #TempPartysOfAccount TEMP
							ON REPLACE(PRS.SSN,'-','') COLLATE DATABASE_DEFAULT = REPLACE(TEMP.SSNorTIN,'-','') COLLATE DATABASE_DEFAULT
							WHERE TEMP.Type	= 'Individual Ownership'
						  UNION
						  SELECT PRS.*
							FROM #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN PRS
							JOIN #TempPartysOfAccount TEMP
							ON PRS.FirstName COLLATE DATABASE_DEFAULT = TEMP.FirstName COLLATE DATABASE_DEFAULT AND
							   PRS.LastName	 COLLATE DATABASE_DEFAULT = TEMP.LastName  COLLATE DATABASE_DEFAULT AND
							   PRS.SSN IS NULL
							WHERE TEMP.Type	 IN ('TransactionIndividual','SubcontractorIndividual')) ILV1
					LEFT JOIN KYPEnrollment.pAccount_PDM_Provider PRV
					ON	ILV1.PartyID	= PRV.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON	ILV1.PartyID	= LOC.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Address ADR
					ON	LOC.AddressID	= ADR.AddressID					
					LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role POR
					ON	ILV1.PartyID	= POR.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Document DOC
					ON	ILV1.PartyID	= DOC.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction OT
					ON	ILV1.PartyID		= OT.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_AdverseAction AA
					ON	ILV1.PartyID	= AA.PartyID) SRC
				ON TRGT.PartyID = SRC.PartyID
				WHEN NOT MATCHED THEN
				INSERT(
						AccountID
						,[Type]
						,[Name]
						,[IsProvider]
						,[IsEnrolled]
						,[IsTemp]
						,[IsActive]
						,[LoadType]
						,[LoadID]
						,[LastLoadDate]
						,[DateModified]
						,[IsDeleted]
						,[Source]
						,[CreatedBy]
						,[DateCreated]
						,[ModifiedBy]
						,[DeletedBy]
						,[DateDeleted]
						,[ParentPartyID]
						,[profile_id]
						,[LastAction]
						,[LastActionDate]
						,[LastActorUserID]
						,[LastActionReason]
						,[LastActionComments]
						,[LastActionApprovedBy]
						,[LastMOCARelationshipUpdateBy]
						,[LastMOCAUpdateBy]
						,[MOCARelationshipStartDate]
						,[MOCARelationshipEndDate]
						,[CurrentRecordFlag]
					)
					VALUES
					(	
						@AccountID
						,SRC.[Type]
						,SRC.[Name]
						,SRC.[IsProvider]
						,SRC.[IsEnrolled]
						,SRC.[IsTemp]
						,SRC.[IsActive]
						,'DeltaAccLoad'
						,CONVERT(VARCHAR(8), GETDATE(), 112)
						,CONVERT(DATE,GETDATE(),112)
						,NULL
						,0
						,NULL
						,NULL
						,CONVERT(DATE,GETDATE(),112)
						,NULL
						,NULL
						,SRC.[DateDeleted]
						,@ParentPartyID
						,NULL
						,'C'
						,CONVERT(DATE,GETDATE(),112)
						,'system'
						,NULL
						,NULL
						,'system'
						,'M'
						,'M'
						,SRC.[MOCARelationshipStartDate]
						,SRC.[MOCARelationshipEndDate]
						,SRC.[CurrentRecordFlag]
					)
					OUTPUT	INSERTED.PartyID,SRC.Type,SRC.Name,SRC.IsProvider,SRC.IsEnrolled,SRC.IsTemp,SRC.IsActive,SRC.DateDeleted,
							SRC.MOCARelationshipStartDate,SRC.MOCARelationshipEndDate,SRC.CurrentRecordFlag,
							SRC.SSN,SRC.Salutation,SRC.FirstName,SRC.MiddleName,SRC.LastName,SRC.DOB,SRC.NPI,SRC.ProvID,
							SRC.NPI AS ProviderNPI,SRC.AddressID,SRC.AddressLine1,SRC.AddressLine2,SRC.City,
							SRC.State,SRC.Zip,SRC.ZipPlus4,SRC.AddressType,SRC.LocationID,SRC.Type LocAddressType,SRC.PdmOwnerID,SRC.OtherDate,
							SRC.TypeForm,SRC.OtherValue,
							SRC.DocumentID,SRC.TypeDoc,SRC.NumberDoc,SRC.IsStateIssued,SRC.StateIssued,SRC.TransactionID,SRC.Description,SRC.Amount,
							SRC.AdverseActionID,SRC.QuestionID,SRC.Type_x,SRC.Reason,SRC.State_x,SRC.Date_x,SRC.DateType,SRC.EffectiveDate,SRC.NPI AS AdverseActionNPI,
							SRC.City AS AdverseActionCity,SRC.ProgramType,SRC.Where_x,SRC.Action_x,SRC.LicenseAuthority,SRC.LegalName,SRC.DBA,
							SRC.AppFormID,SRC.documentInstanceId,SRC.ProgramTypeOther,1
						INTO @TempPersonOrOrganization(PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
										 MOCARelationshipEndDate,CurrentRecordFlag,SSN,Salutation,FirstName,MiddleName,LastName,DOB,PersonOrOrganzationNPI,
										 ProviderID,ProviderNPI,AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,
										 LocAddressType,PdmOwnerID,OtherDate,TypeForm,OtherValue,DocumentID,TypeDoc,
										 NumberDoc,IsStateIssued,StateIssued,TransactionID,Description,Amount,AdverseActionID,QuestionID,Type_x,Reason,State_x,Date_x,DateType,EffectiveDate,
										 AdverseActionNPI,AdverseActionCity,ProgramType,Where_x,Action_x,LicenseAuthority,LegalName,DBA,
										 AppFormID,DocumentInstanceID,ProgramTypeOther,OwnersOrOtherOwnershipFlag);
				
				INSERT INTO KYPEnrollment.MOCAatTaxIDMOCASpreadingHistory
					SELECT @AccountID,'MOCA Individual' AS GroupName,'NEW' AS Action,'SSN' AS Attribute,'-' AS OldValue,SSN AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('Individual Ownership') AND
							  OwnersOrOtherOwnershipFlag = 1
					UNION
					SELECT @AccountID,'Subcontractor' AS GroupName,'NEW' AS Action,'Name' AS Attribute,'-' AS OldValue,ISNULL(LastName,'') + ' ' + ISNULL(FirstName,'') + ' ' + ISNULL(MiddleName,'') AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('SubcontractorIndividual') AND
							  OwnersOrOtherOwnershipFlag = 1
					UNION
					SELECT @AccountID,'Significant Transaction' AS GroupName,'NEW' AS Action,'Name' AS Attribute,'-' AS OldValue,ISNULL(LastName,'') + ' ' + ISNULL(FirstName,'') + ' ' + ISNULL(MiddleName,'') AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('TransactionIndividual') AND
							  OwnersOrOtherOwnershipFlag = 1
				
				MERGE KYPEnrollment.pAccount_PDM_Party TRGT
				USING
				(SELECT	NULL AS PartyID,ILV1.Type,ILV1.Name,ILV1.IsProvider,ILV1.IsEnrolled,ILV1.IsTemp,ILV1.IsActive,ILV1.DateDeleted,
						ILV1.MOCARelationshipStartDate,ILV1.MOCARelationshipEndDate,ILV1.CurrentRecordFlag,ILV1.LegalName AS OrgLegalName,ILV1.TIN,
						ILV1.EIN,ILV1.NPI,PRV.ProvID,PRV.NPI AS ProviderNPI,ADR.AddressID,ADR.AddressLine1,ADR.AddressLine2,ADR.City,
						ADR.State,ADR.Zip,ADR.ZipPlus4,ADR.AddressType,LOC.LocationID,LOC.Type LocAddressType,POR.PdmOwnerID,POR.OtherDate,
						POR.TypeForm,POR.OtherValue,DOC.DocumentID,DOC.TypeDoc,DOC.NumberDoc,DOC.IsStateIssued,DOC.StateIssued,OT.TransactionID,
						OT.Description,OT.Amount,AA.AdverseActionID,AA.QuestionID,AA.Type_x,AA.Reason,AA.State_x,AA.Date_x,AA.DateType,AA.EffectiveDate,
						AA.NPI AS AdverseActionNPI,AA.City AS AdverseActionCity,AA.ProgramType,AA.Where_x,AA.Action_x,AA.LicenseAuthority,
						AA.LegalName,AA.DBA,AA.AppFormID,AA.DocumentInstanceID,AA.ProgramTypeOther
					FROM (SELECT ORG.*
							FROM #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN ORG
							JOIN #TempPartysOfAccount TEMP
							ON REPLACE(ORG.EIN,'-','') COLLATE DATABASE_DEFAULT = REPLACE(TEMP.SSNorTIN,'-','') COLLATE DATABASE_DEFAULT
							WHERE TEMP.Type	= 'Entity Ownership'
						  UNION					  
						  SELECT ORG.*
							FROM #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN ORG
							JOIN #TempPartysOfAccount TEMP
							ON	ORG.LegalName COLLATE DATABASE_DEFAULT = TEMP.LegalName COLLATE DATABASE_DEFAULT AND
								ORG.EIN IS NULL
							WHERE TEMP.Type IN ('TransactionEntity','SubcontractorEntity')) ILV1
					LEFT JOIN KYPEnrollment.pAccount_PDM_Provider PRV
					ON	ILV1.PartyID	= PRV.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Location LOC
					ON	ILV1.PartyID	= LOC.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Address ADR
					ON	LOC.AddressID	= ADR.AddressID					
					LEFT JOIN KYPEnrollment.pAccount_PDM_Owner_Role POR
					ON	ILV1.PartyID	= POR.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_Document DOC
					ON	ILV1.PartyID	= DOC.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_OwnerhipTransaction OT
					ON	ILV1.PartyID	= OT.PartyID
					LEFT JOIN KYPEnrollment.pAccount_PDM_AdverseAction AA
					ON	ILV1.PartyID	= AA.PartyID) SRC
				ON TRGT.PartyID = SRC.PartyID
				WHEN NOT MATCHED THEN
				INSERT
				(
					AccountID
					,[Type]
					,[Name]
					,[IsProvider]
					,[IsEnrolled]
					,[IsTemp]
					,[IsActive]
					,[LoadType]
					,[LoadID]
					,[LastLoadDate]
					,[DateModified]
					,[IsDeleted]
					,[Source]
					,[CreatedBy]
					,[DateCreated]
					,[ModifiedBy]
					,[DeletedBy]
					,[DateDeleted]
					,[ParentPartyID]
					,[profile_id]
					,[LastAction]
					,[LastActionDate]
					,[LastActorUserID]
					,[LastActionReason]
					,[LastActionComments]
					,[LastActionApprovedBy]
					,[LastMOCARelationshipUpdateBy]
					,[LastMOCAUpdateBy]
					,[MOCARelationshipStartDate]
					,[MOCARelationshipEndDate]
					,[CurrentRecordFlag]
				)
				VALUES
				(	
					@AccountID
					,SRC.[Type]
					,SRC.[Name]
					,SRC.[IsProvider]
					,SRC.[IsEnrolled]
					,SRC.[IsTemp]
					,SRC.[IsActive]
					,'DeltaAccLoad'
					,CONVERT(VARCHAR(8), GETDATE(), 112)
					,CONVERT(DATE,GETDATE(),112)
					,NULL
					,0
					,NULL
					,NULL
					,CONVERT(DATE,GETDATE(),112)
					,NULL
					,NULL
					,SRC.[DateDeleted]
					,@ParentPartyID
					,NULL
					,'C'
					,CONVERT(DATE,GETDATE(),112)
					,'system'
					,NULL
					,NULL
					,'system'
					,'M'
					,'M'
					,SRC.[MOCARelationshipStartDate]
					,SRC.[MOCARelationshipEndDate]
					,SRC.[CurrentRecordFlag]
				)
				OUTPUT	INSERTED.PartyID,SRC.Type,SRC.Name,SRC.IsProvider,SRC.IsEnrolled,SRC.IsTemp,SRC.IsActive,SRC.DateDeleted,
						SRC.MOCARelationshipStartDate,SRC.MOCARelationshipEndDate,SRC.CurrentRecordFlag,
						SRC.OrgLegalName,SRC.TIN,SRC.EIN,SRC.NPI,
						SRC.ProvID,SRC.NPI AS ProviderNPI,SRC.AddressID,SRC.AddressLine1,SRC.AddressLine2,SRC.City,
						SRC.State,SRC.Zip,SRC.ZipPlus4,SRC.AddressType,SRC.LocationID,SRC.Type LocAddressType,SRC.PdmOwnerID,SRC.OtherDate,
						SRC.TypeForm,SRC.OtherValue,
						SRC.DocumentID,SRC.TypeDoc,SRC.NumberDoc,SRC.IsStateIssued,SRC.StateIssued,SRC.TransactionID,SRC.Description,SRC.Amount,
						SRC.AdverseActionID,SRC.QuestionID,SRC.Type_x,SRC.Reason,SRC.State_x,SRC.Date_x,SRC.DateType,SRC.EffectiveDate,
						SRC.NPI AS AdverseActionNPI,SRC.City AS AdverseActionCity,SRC.ProgramType,SRC.Where_x,SRC.Action_x,SRC.LicenseAuthority,
						SRC.LegalName,SRC.DBA,SRC.AppFormID,SRC.documentInstanceId,SRC.ProgramTypeOther,1
					INTO @TempPersonOrOrganization(PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
									 MOCARelationshipEndDate,CurrentRecordFlag,OrgLegalName,TIN,EIN,PersonOrOrganzationNPI,
									 ProviderID,ProviderNPI,AddressID,AddressLine1,AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,
									 LocAddressType,PdmOwnerID,OtherDate,TypeForm,OtherValue,DocumentID,TypeDoc,
									 NumberDoc,IsStateIssued,StateIssued,TransactionID,Description,Amount,AdverseActionID,QuestionID,Type_x,Reason,State_x,Date_x,DateType,EffectiveDate,
									 AdverseActionNPI,AdverseActionCity,ProgramType,Where_x,Action_x,LicenseAuthority,LegalName,DBA,
									 AppFormID,DocumentInstanceID,ProgramTypeOther,OwnersOrOtherOwnershipFlag);
				
				INSERT INTO KYPEnrollment.MOCAatTaxIDMOCASpreadingHistory
					SELECT @AccountID,'MOCA Organization' AS GroupName,'NEW' AS Action,'EIN' AS Attribute,'-' AS OldValue,EIN AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('Entity Ownership') AND
							  OwnersOrOtherOwnershipFlag = 1
					UNION
					SELECT @AccountID,'Subcontractor' AS GroupName,'NEW' AS Action,'Name' AS Attribute,'-' AS OldValue,OrgLegalName AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('SubcontractorEntity') AND
							  OwnersOrOtherOwnershipFlag = 1
					UNION
					SELECT @AccountID,'Significant Transaction' AS GroupName,'NEW' AS Action,'Name' AS Attribute,'-' AS OldValue,OrgLegalName AS NewValue,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('TransactionEntity') AND
							  OwnersOrOtherOwnershipFlag = 1  
							  
				SELECT @lCount = COUNT(1)
					FROM @TempPersonOrOrganization

				IF @lCount > 0

				BEGIN

					INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
					(
						PartyID,
						SSN,
						Salutation,
						FirstName,
						MiddleName,
						LastName,
						DoB,
						NPI,
						Deleted,
						DateCreated,
						DateDeleted,
						lastAction,
						LastActionDate,
						LastActorUserId,
						LastActionApprovedBy,
						CurrentRecordFlag
					)
					SELECT	PartyID,
							SSN,
							Salutation,
							FirstName,
							MiddleName,
							LastName,
							DOB,
							PersonOrOrganzationNPI,
							0,
							CONVERT(DATE,GETDATE(),112),
							NULL,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							'system',
							1  
						FROM @TempPersonOrOrganization
						WHERE Type IN('TransactionIndividual','SubcontractorIndividual','Individual Ownership') AND
							  OwnersOrOtherOwnershipFlag = 1

					INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
						(
							PartyID,
							LegalName,
							DBAName1,
							TIN,
							NPI,
							IsDeleted,
							DateCreated,
							DateDeleted,
							lastAction,
							LastActionDate,
							LastActorUserID,
							LastActionApprovedBy,
							CurrentRecordFlag,
							EIN
						)
						SELECT	PartyID,
								OrgLegalName,
								NULL,
								TIN,
								PersonOrOrganzationNPI,
								0,
								CONVERT(DATE,GETDATE(),112),
								NULL,
								'C',
								CONVERT(DATE,GETDATE(),112),
								'system',
								'system',
								1,
								EIN
							FROM @TempPersonOrOrganization
							WHERE Type IN('TransactionEntity','SubcontractorEntity','Entity Ownership') AND
								  OwnersOrOtherOwnershipFlag = 1
/*					
					-- As discussed in the call with Bolivia team, MOCA shouldn't spread to the Sub Group Account			
					IF @IsPastOwner = 0
					
					BEGIN

						-- Below MERGE statement is written after insertion of Person and Organization table, these we have done because as we know OtherOwnership MOCAs ParentPartyID (Not Account Party ID) would be either Individual Ownership or Entity Ownership. So before creating OtherOwnership MOCAs it's Individual/Entity Ownership should be created with SSN and EIN and that's why below code is written after above code.
						MERGE KYPEnrollment.pAccount_PDM_Party TRGT
						USING
						(SELECT	NULL AS PartyID,ILV1.ParentPartyID,ILV1.Type,ILV1.Name,ILV1.IsProvider,ILV1.IsEnrolled,ILV1.IsTemp,ILV1.IsActive,ILV1.DateDeleted,
								ILV1.MOCARelationshipStartDate,ILV1.MOCARelationshipEndDate,ILV1.CurrentRecordFlag,ILV1.OtherOwnershipLegalName AS OrgLegalName,
								ILV1.TIN,ILV1.OtherOwnershipEIN AS EIN,ILV1.PersonOrOrganizationNPI AS NPI,ILV1.AddressID,ILV1.AddressLine1,
								ILV1.AddressLine2,ILV1.City,ILV1.State,ILV1.Zip,ILV1.ZipPlus4,ILV1.AddressType,ILV1.LocationID,ILV1.LocAddressType
								-- ,ILV1.PartyID AS PartyIDForOwnershipRelation
							FROM (SELECT XYZ.*,Inserting_Records.*
									FROM (SELECT ILV1.*
											FROM (SELECT *
													FROM #TempMOCARelationforOtherOwnershipHavingSameProfileAndTIN) ILV1
											LEFT JOIN (SELECT P.ParentPartyID AS AccountOwnershipPartyID,ISNULL(PRS.SSN,ORG.EIN) AS AccountOwnershipSSNorEIN,
															  P.PartyID AS AccountOtherOwnershipPartyID,
															  ISNULL(ORG1.EIN,'') AS AccountOtherOwnershipEIN,ISNULL(ORG1.LegalName,'') AS AccountOtherOwnershipLegalName,
															  ISNULL(PRS1.SSN,'') AS AccountOtherOwnershipSSN,ISNULL(PRS1.FirstName,'') AS AccountOtherOwnershipFirstName,
															  ISNULL(PRS1.LastName,'') AS AccountOtherOwnershipLastName
															FROM KYPEnrollment.pADM_Account ACC
															JOIN KYPEnrollment.pAccount_PDM_Party P
															ON ACC.AccountID = P.AccountID AND
															   Type		IN ('OtherOwnershipEntity','OtherOwnershipIndividual')
															LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
															ON P.ParentPartyID	= PRS.PartyID
															LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
															ON P.ParentPartyID	= ORG.PartyID
															LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS1
															ON P.PartyID		= PRS1.PartyID
															LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG1
															ON P.PartyID		= ORG1.PartyID
															WHERE ACC.AccountID = @AccountID AND
																  P.CurrentRecordFlag = 1) ILV2
											ON	ILV1.OwnershipSSNorEIN			= ILV2.AccountOwnershipSSNorEIN AND
												ILV1.OtherOwnershipEIN			= ILV2.AccountOtherOwnershipEIN  AND
												ILV1.OtherOwnershipLegalName	= ILV2.AccountOtherOwnershipLegalName  AND
												ILV1.OtherOwnershipSSN			= ILV2.AccountOtherOwnershipSSN  AND
												ILV1.OtherOwnershipFirstName	= ILV2.AccountOtherOwnershipFirstName  AND
												ILV1.OtherOwnershipLastName		= ILV2.AccountOtherOwnershipLastName
											WHERE ILV2.AccountOwnershipPartyID IS NULL) Inserting_Records
									LEFT JOIN (SELECT P.PartyID AS ParentPartyID,ISNULL(PRS.SSN,ORG.EIN) AS SSNorEIN -- ,PRS.SSN,ORG.EIN,PRS.FirstName,PRS.LastName,ORG.LegalName
												FROM KYPEnrollment.pAccount_PDM_Party P
												LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
												ON P.PartyID	= PRS.PartyID
												LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
												ON P.PartyID	= ORG.PartyID			
												WHERE AccountID = @AccountID AND
													  Type		IN('Individual Ownership','Entity Ownership') AND
													  P.CurrentRecordFlag = 1) XYZ
									ON REPLACE(Inserting_Records.OwnershipSSNorEIN,'-','') = REPLACE(XYZ.SSNorEIN,'-','')) ILV1) SRC
						ON TRGT.PartyID = SRC.PartyID
						WHEN NOT MATCHED THEN
						INSERT
						(
							AccountID
							,[Type]
							,[Name]
							,[IsProvider]
							,[IsEnrolled]
							,[IsTemp]
							,[IsActive]
							,[LoadType]
							,[LoadID]
							,[LastLoadDate]
							,[DateModified]
							,[IsDeleted]
							,[Source]
							,[CreatedBy]
							,[DateCreated]
							,[ModifiedBy]
							,[DeletedBy]
							,[DateDeleted]
							,[ParentPartyID]
							,[profile_id]
							,[LastAction]
							,[LastActionDate]
							,[LastActorUserID]
							,[LastActionReason]
							,[LastActionComments]
							,[LastActionApprovedBy]
							,[LastMOCARelationshipUpdateBy]
							,[LastMOCAUpdateBy]
							,[MOCARelationshipStartDate]
							,[MOCARelationshipEndDate]
							,[CurrentRecordFlag]
						)
						VALUES
						(	
							@AccountID
							,SRC.[Type]
							,SRC.[Name]
							,SRC.[IsProvider]
							,SRC.[IsEnrolled]
							,SRC.[IsTemp]
							,SRC.[IsActive]
							,'MonthlyProvider'
							,'MLOAD_' + CONVERT(VARCHAR(8), GETDATE(), 112)
							,CONVERT(DATE,GETDATE(),112)
							,NULL
							,0
							,NULL
							,NULL
							,CONVERT(DATE,GETDATE(),112)
							,NULL
							,NULL
							,SRC.[DateDeleted]
							,SRC.ParentPartyID
							,NULL
							,'C'
							,CONVERT(DATE,GETDATE(),112)
							,'system'
							,NULL
							,NULL
							,'system'
							,'M'
							,'M'
							,SRC.[MOCARelationshipStartDate]
							,SRC.[MOCARelationshipEndDate]
							,SRC.[CurrentRecordFlag]
						)
						OUTPUT	INSERTED.PartyID,SRC.Type,SRC.Name,SRC.IsProvider,SRC.IsEnrolled,SRC.IsTemp,SRC.IsActive,SRC.DateDeleted,
								SRC.MOCARelationshipStartDate,SRC.MOCARelationshipEndDate,SRC.CurrentRecordFlag,
								SRC.OrgLegalName AS OrgLegalName,SRC.TIN,SRC.EIN,SRC.NPI,SRC.AddressID,SRC.AddressLine1,SRC.AddressLine2,SRC.City,
								SRC.State,SRC.Zip,SRC.ZipPlus4,SRC.AddressType,SRC.LocationID,SRC.Type LocAddressType,SRC.ParentPartyID,2 -- ,SRC.PartyIDForOwnershipRelation
							INTO @TempPersonOrOrganization(PartyID,Type,Name,IsProvider,IsEnrolled,IsTemp,IsActive,DateDeleted,MOCARelationshipStartDate,
											 MOCARelationshipEndDate,CurrentRecordFlag,OrgLegalName,TIN,EIN,PersonOrOrganzationNPI,AddressID,AddressLine1,
											 AddressLine2,City,State,Zip,ZipPlus4,AddressType,LocationID,LocAddressType,OtherOwnershipParentPartyID,OwnersOrOtherOwnershipFlag); -- ,PartyIDForOwnershipRelation

						INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
						(
							PartyID,
							SSN,
							Salutation,
							FirstName,
							MiddleName,
							LastName,
							DoB,
							NPI,
							Deleted,
							DateCreated,
							DateDeleted,
							lastAction,
							LastActionDate,
							LastActorUserId,
							LastActionApprovedBy,
							CurrentRecordFlag
						)
						SELECT	PartyID,
								SSN,
								Salutation,
								FirstName,
								MiddleName,
								LastName,
								DOB,
								PersonOrOrganzationNPI,
								0,
								CONVERT(DATE,GETDATE(),112),
								NULL,
								'C',
								CONVERT(DATE,GETDATE(),112),
								'system',
								'system',
								1  
							FROM @TempPersonOrOrganization
							WHERE Type IN(/*'TransactionIndividual','SubcontractorIndividual','Individual Ownership',*/'OtherOwnershipIndividual') AND
								  OwnersOrOtherOwnershipFlag = 2
							
						INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
							(
								PartyID,
								LegalName,
								DBAName1,
								TIN,
								NPI,
								IsDeleted,
								DateCreated,
								DateDeleted,
								lastAction,
								LastActionDate,
								LastActorUserID,
								LastActionApprovedBy,
								CurrentRecordFlag,
								EIN
							)
							SELECT	PartyID,
									OrgLegalName,
									NULL,
									TIN,
									PersonOrOrganzationNPI,
									0,
									CONVERT(DATE,GETDATE(),112),
									NULL,
									'C',
									CONVERT(DATE,GETDATE(),112),
									'system',
									'system',
									1,
									EIN
								FROM @TempPersonOrOrganization
								WHERE Type IN(/*'TransactionEntity','SubcontractorEntity','Entity Ownership',*/'OtherOwnershipEntity') AND
									  OwnersOrOtherOwnershipFlag = 2

					END
*/			
					INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
				   (
						[PartyID],
						[DateCreated],
						[IsDeleted],
						[NPI],
						[LastAction],
						[LastActionDate],
						[LastActorUserID],
						[LastActionApprovedBy],
						[CurrentRecordFlag]
					)
					SELECT	PartyID,
							CONVERT(DATE,GETDATE(),112)
							,0
							,ProviderNPI
							,'C'
							,CONVERT(DATE,GETDATE(),112)
							,'system'
							,'system'
							,1
						FROM @TempPersonOrOrganization
						WHERE Type IN('Individual Ownership','Entity Ownership') AND
							  ProviderID IS NOT NULL AND ProviderID != '' 
					 
					INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
					(
						AddressLine1,
						AddressLine2,
						City,
						State,
						Zip,
						ZipPlus4,
						AddressType,
						LastAction,
						LastActionDate,
						LastActionUserID,
						LastActionApprovedByUsedID,
						CurrentRecordFlag,
						ServiceLocationNo,
						TempAddressID
					)
					SELECT	AddressLine1,
							AddressLine2,
							City,
							State,
							Zip,
							ZipPlus4,
							AddressType,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							'system',
							1,
							NULL,
							PartyID
						FROM @TempPersonOrOrganization
						WHERE AddressID IS NOT NULL AND AddressID != ''

					INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
					(
						AddressID,
						PartyID,
						ProviderID,
						DateCreated,
						InActive,
						IsDeleted,
						Type,
						LastAction,
						LastActionDate,
						LastActorUserID,
						LastActionApprovedBy,
						CurrentRecordFlag
					)
					SELECT	NULL,
							PartyID,
							NULL,
							CONVERT(DATE,GETDATE(),112),
							1,
							0,
							LocAddressType,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							'system',
							1
						FROM @TempPersonOrOrganization
						WHERE LocationID IS NOT NULL AND LocationID != ''
					
					UPDATE KYPEnrollment.pAccount_PDM_Location
						SET AddressID = ADR.AddressID
						FROM KYPEnrollment.pAccount_PDM_Location LOC
						JOIN KYPEnrollment.pAccount_PDM_Address ADR
						ON LOC.PartyID	= ADR.TempAddressID
						/*WHERE TempAddressID	IN(SELECT PartyID
												FROM @TempPersonOrOrganization) AND
							  LOC.AddressID	IS NULL*/

					UPDATE [KYPEnrollment].[pAccount_PDM_Address]
						SET TempAddressID = NULL
						WHERE TempAddressID IN(SELECT PartyID
												FROM @TempPersonOrOrganization);

					INSERT INTO KYPEnrollment.pAccount_PDM_Owner_Role
					(
						TypeForm,
						IsDeleted,
						CurrentRecordFlag,
						Other,
						OtherValue,
						OtherDate,
						PartyID,
						DateCreated,
						LastAction,
						LastActionDate,
						LastActionApprovedBy,
						LastActorUserID
					)
					SELECT	TypeForm,
							0,
							1,
							1,
							OtherValue,
							OtherDate,
							PartyID,
							CONVERT(DATE,GETDATE(),112),
							'C',
							NULL,
							'system',
							'system'  
						FROM @TempPersonOrOrganization
						WHERE Type IN ('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity') AND
							  PdmOwnerID IS NOT NULL AND PdmOwnerID != ''

					INSERT INTO [KYPEnrollment].[pAccount_PDM_Document]
					(
						[PartyID],
						[TypeDoc],
						[NumberDoc],
						[IsStateIssued],
						[StateIssued],
						[CreatedBy],
						[DateCreated],
						[ModifiedBy],
						[DateModified],
						[DeletedBy],
						[DateDeleted],
						[IsDeleted],
						[LastAction],
						[LastActionDate],
						[LastActorUserID],
						[LastActionReason],
						[LastActionComments],
						[LastActionApprovedBy],
						[CurrentRecordFlag]
					)
					SELECT	PartyID,
							TypeDoc,
							NumberDoc,
							IsStateIssued,
							StateIssued,
							NULL,
							CONVERT(DATE,GETDATE(),112),
							NULL,
							NULL,
							NULL,
							NULL,
							0,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							NULL,
							NULL,
							'system',
							1				
						FROM @TempPersonOrOrganization
						WHERE Type IN('Individual Ownership','Entity Ownership') AND
							  DocumentID IS NOT NULL AND DocumentID != ''
					
					INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction]
					(
						[PartyID],
						[Description],
						[Amount],
						[CreatedBy],
						[DateCreated],
						[ModifiedBy],
						[DateModified],
						[DeletedBy],
						[DateDeleted],
						[IsDeleted],
						[LastAction],
						[LastActionDate],
						[LastActorUserID],
						[LastActionReason],
						[LastActionComments],
						[LastActionApprovedBy],
						[CurrentRecordFlag]
					)
					SELECT	PartyID,
							Description,
							Amount,
							NULL,
							CONVERT(DATE,GETDATE(),112),
							NULL,
							NULL,
							NULL,
							NULL,
							0,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							NULL,
							NULL,
							'system',
							1				
						FROM @TempPersonOrOrganization
						WHERE TransactionID IS NOT NULL AND TransactionID != '' AND
							  Type IN ('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity','TransactionIndividual','TransactionEntity')
					
					INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
					(
						[QuestionID],
						[PartyID],
						[Type_x],
						[Reason],
						[State_x],
						[Date_x],
						[DateType],
						[EffectiveDate],
						[NPI],
						[City],
						[ProgramType],
						[Where_x],
						[Action_x],
						[LicenseAuthority],
						[CreatedBy],
						[DateCreated],
						[ModifiedBy],
						[DateModified],
						[DeletedBy],
						[DateDeleted],
						[IsDeleted],
						[LegalName],
						[DBA],
						[AppFormID],
						[documentInstanceId],
						[LastAction],
						[LastActionDate],
						[LastActorUserID],
						[LastActionReason],
						[LastActionComments],
						[LastActionApprovedBy],
						[CurrentRecordFlag],
						ProgramTypeOther
					)
					SELECT	QuestionID,
							PartyID,
							Type_x,
							Reason,
							State_x,
							Date_x,
							DateType,
							EffectiveDate,
							AdverseActionNPI,
							AdverseActionCity,
							ProgramType,
							Where_x,
							Action_x,
							LicenseAuthority,
							NULL,
							CONVERT(DATE,GETDATE(),112),
							NULL,
							NULL,
							NULL,
							NULL,
							0,
							LegalName,
							DBA,
							AppFormID,
							DocumentInstanceID,
							'C',
							CONVERT(DATE,GETDATE(),112),
							'system',
							NULL,
							NULL,
							'system',
							1,
							ProgramTypeOther
						FROM @TempPersonOrOrganization
						WHERE Type IN('Individual Ownership','Entity Ownership') AND
							  AdverseActionID IS NOT NULL AND AdverseActionID != ''
/*
					IF @IsPastOwner = 0
			
					BEGIN

						INSERT INTO KYPEnrollment.pAccount_PDM_OwnershipRelationship
						(
							PartyIDOwner,
							PartyIDOwned,
							TypeAssociation,
							FamiliarRelationship,
							DateCreated,
							CreatedBy,
							IsDeleted,
							LastAction,
							LastActionDate,
							LastActorUserID,
							LastActionApprovedBy,
							CurrentRecordFlag
						)
						SELECT	PARTY_OWNER.PartyOwnerID,
								ISNULL(PARTY_OWNED_OTHER.PartyOwnedID,PARTY_OWNED_OWN.PartyOwnedID),
								MAIN.TypeAssociation,
								MAIN.FamiliarRelationship,
								CONVERT(DATE,GETDATE(),112),
								NULL,
								0,
								'C',
								CONVERT(DATE,GETDATE(),112),
								'system',
								'system',
								1
							FROM (-- Below query will produce the result which needs to be inserted into an Account as the output relationship result is not exist for an Account
								  SELECT ILV.*
									FROM (-- Take all the unique relationships from all the Accounts having same TaxID and ProfileID
										  SELECT *
											FROM (SELECT P.Type AS PartyOwnerType,P1.Type AS PartyOwnedType,TypeAssociation,RS.FamiliarRelationship,P.AccountID,RS.PartyIDOwner,RS.PartyIDOwned,PRS.SSN AS OwnerSSN,PRS.FirstName AS OwnerFirstName,PRS.LastName AS OwnerLastName,
														 ORG.EIN AS OwnerEIN,ORG.LegalName AS OwnerLegalName,
														 PRS1.SSN AS OwnedSSN,PRS1.FirstName AS OwnedFirstName,PRS1.LastName AS OwnedLastName,ORG1.EIN AS OwnedEIN,
														 ORG1.LegalName AS OwnedLegalName,
														 ROW_NUMBER() OVER (PARTITION BY ISNULL(PRS.SSN,''),ISNULL(PRS.FirstName,''),ISNULL(PRS.LastName,''),ISNULL(PRS1.SSN,''),
																				ISNULL(PRS1.FirstName,''),ISNULL(PRS1.LastName,''),ISNULL(ORG.EIN,''),ISNULL(ORG.LegalName,''),
																				ISNULL(ORG1.EIN,''),ISNULL(ORG1.LegalName,''),ISNULL(P1.Type,'') ORDER BY P.MocaRelationshipStartDate) RN
													FROM #TempAccountsofTAXandProfilewise ACC
													JOIN KYPEnrollment.pAccount_PDM_Party P
													ON	ACC.AccountPartyID	= P.ParentPartyID AND
														P.Type				IN('Individual Ownership','Entity Ownership') AND
														P.CurrentRecordFlag = 1
													JOIN KYPEnrollment.pAccount_PDM_OwnershipRelationship RS
													ON P.PartyID			= RS.PartyIDOwner
													JOIN KYPEnrollment.pAccount_PDM_Party P1
													ON P1.PartyID			= RS.PartyIDOwned
													LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
													ON	RS.PartyIDOwner		= PRS.PartyID
													LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS1
													ON	RS.PartyIDOwned		= PRS1.PartyID
													LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG 
													ON	RS.PartyIDOwner		= ORG.PartyID
													LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG1
													ON	RS.PartyIDOwned		= ORG1.PartyID
													WHERE ((P.Type			IN('Individual Ownership') AND P1.Type IN('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity','OtherOwnershipEntity','OtherOwnershipIndividual')) OR
														  (P.Type			IN('Entity Ownership') AND P1.Type IN('SubcontractorIndividual','SubcontractorEntity','OtherOwnershipEntity','OtherOwnershipIndividual')))) ILV
											WHERE ILV.RN = 1) ILV
									LEFT JOIN (-- Take all the unique relationships from an Account
											   SELECT *
												FROM(SELECT RS.PartyIDOwner,RS.PartyIDOwned,PRS.SSN AS OwnerSSN,PRS.FirstName AS OwnerFirstName,PRS.LastName AS OwnerLastName,
															ORG.EIN AS OwnerEIN,ORG.LegalName AS OwnerLegalName,
															PRS1.SSN AS OwnedSSN,PRS1.FirstName AS OwnedFirstName,PRS1.LastName AS OwnedLastName,ORG1.EIN AS OwnedEIN,
															ORG1.LegalName AS OwnedLegalName,
															ROW_NUMBER() OVER (PARTITION BY ISNULL(PRS.SSN,''),ISNULL(PRS.FirstName,''),ISNULL(PRS.LastName,''),ISNULL(PRS1.SSN,''),
																					ISNULL(PRS1.FirstName,''),ISNULL(PRS1.LastName,''),ISNULL(ORG.EIN,''),ISNULL(ORG.LegalName,''),
																					ISNULL(ORG1.EIN,''),ISNULL(ORG1.LegalName,''),ISNULL(P1.Type,'') ORDER BY P.MocaRelationshipStartDate) RN
														FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship RS
														JOIN KYPEnrollment.pAccount_PDM_Party P
														ON P.PartyID			= RS.PartyIDOwner
														JOIN KYPEnrollment.pAccount_PDM_Party P1
														ON P1.PartyID			= RS.PartyIDOwned
														LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
														ON	RS.PartyIDOwner		= PRS.PartyID
														LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS1
														ON	RS.PartyIDOwned		= PRS1.PartyID
														LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG 
														ON	RS.PartyIDOwner		= ORG.PartyID
														LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG1
														ON	RS.PartyIDOwned		= ORG1.PartyID
														WHERE P.AccountID		= @AccountID AND
															  P.CurrentRecordFlag = 1 AND
															  ((P.Type			IN('Individual Ownership') AND P1.Type IN('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity','OtherOwnershipEntity','OtherOwnershipIndividual')) OR
															  (P.Type			IN('Entity Ownership') AND P1.Type IN('SubcontractorIndividual','SubcontractorEntity','OtherOwnershipEntity','OtherOwnershipIndividual')))) XYZ
												WHERE XYZ.RN = 1) ILV1
									ON ISNULL(ILV.OwnerSSN,'')			= ISNULL(ILV1.OwnerSSN,'') AND
									   ISNULL(ILV.OwnerEIN,'')			= ISNULL(ILV1.OwnerEIN,'') AND
									   ISNULL(ILV.OwnedSSN,'')			= ISNULL(ILV1.OwnedSSN,'') AND
									   ISNULL(ILV.OwnedFirstName,'')	= ISNULL(ILV1.OwnedFirstName,'') AND
									   ISNULL(ILV.OwnedLastName,'')		= ISNULL(ILV1.OwnedLastName,'') AND
									   ISNULL(ILV.OwnedEIN,'')			= ISNULL(ILV1.OwnedEIN,'') AND
									   ISNULL(ILV.OwnedLegalName,'')	= ISNULL(ILV1.OwnedLegalName,'')
									WHERE ILV1.PartyIDOwned IS NULL) MAIN
							-- Joining with Below table will give the PartyOwnerID for a processing Account
							LEFT JOIN (SELECT P.PartyID AS PartyOwnerID,p.AccountID,Type,PRS.SSN AS PartyOwnerSSN,PRS.FirstName AS PartyOwnerFirstName,
											  PRS.LastName AS PartyOwnerLastName,ORG.EIN AS PartyOwnerEIN,ORG.LegalName AS PartyOwnerLegalName
											FROM KYPEnrollment.pAccount_PDM_Party P
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
											ON P.PartyID = PRS.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
											ON P.PartyID = ORG.PartyID				
											WHERE P.AccountID			= @AccountID	AND
												  P.CurrentRecordFlag	= 1			AND
												  Type IN('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity','OtherOwnershipEntity','OtherOwnershipIndividual')) PARTY_OWNER
							ON ISNULL(MAIN.OwnerSSN,MAIN.OwnerEIN) = ISNULL(PARTY_OWNER.PartyOwnerSSN,PARTY_OWNER.PartyOwnerEIN)
							-- Joining with Below table will give the PartyOwnedID for a processing Account for "OtherOwnership" MOCA type.
							LEFT JOIN (SELECT P.PartyID AS PartyOwnedID,p.AccountID,Type,PRS.SSN AS PartyOwnedSSN,PRS.FirstName AS PartyOwnedFirstName,
											  PRS.LastName AS PartyOwnedLastName,ORG.EIN AS PartyOwnedEIN,ORG.LegalName AS PartyOwnedLegalName,prs1.SSN,org1.EIN
											FROM KYPEnrollment.pAccount_PDM_Party P
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
											ON P.PartyID = PRS.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
											ON P.PartyID = ORG.PartyID				
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS1
											ON P.ParentPartyID = PRS1.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG1
											ON P.ParentPartyID = ORG1.PartyID				
											WHERE P.AccountID			= @AccountID	AND
												  P.CurrentRecordFlag	= 1				AND
												  Type IN('OtherOwnershipEntity','OtherOwnershipIndividual')) PARTY_OWNED_OTHER
							ON ISNULL(MAIN.OwnedSSN,'')		= ISNULL(PARTY_OWNED_OTHER.PartyOwnedSSN,'')			AND
							   ISNULL(MAIN.OwnedEIN,'')		= ISNULL(PARTY_OWNED_OTHER.PartyOwnedEIN,'')			AND
							   ISNULL(MAIN.OwnedFirstName,'')= ISNULL(PARTY_OWNED_OTHER.PartyOwnedFirstName,'')	AND
							   ISNULL(MAIN.OwnedLastName,'') = ISNULL(PARTY_OWNED_OTHER.PartyOwnedLastName,'')		AND
							   ISNULL(MAIN.OwnedLegalName,'')= ISNULL(PARTY_OWNED_OTHER.PartyOwnedLegalName,'')	AND 
							   ((ISNULL(PARTY_OWNED_OTHER.SSN,'') = ISNULL(MAIN.OwnerSSN,'') AND ISNULL(PARTY_OWNED_OTHER.EIN,'') = ISNULL(MAIN.OwnerEIN,''))) AND
							   MAIN.PartyOwnedType = PARTY_OWNED_OTHER.Type
							-- Joining with Below table will give the PartyOwnerID for a processing Account for other than "OtherOwnership" MOCA Type. We are writing different join because for OtherOwnership MOCA type parties ParentPartyID could be either "Entity Ownership" or "Individual Ownership"
							LEFT JOIN (SELECT P.PartyID AS PartyOwnedID,p.AccountID,Type,PRS.SSN AS PartyOwnedSSN,PRS.FirstName AS PartyOwnedFirstName,
											  PRS.LastName AS PartyOwnedLastName,ORG.EIN AS PartyOwnedEIN,ORG.LegalName AS PartyOwnedLegalName
											FROM KYPEnrollment.pAccount_PDM_Party P
											LEFT JOIN KYPEnrollment.pAccount_PDM_Person PRS
											ON P.PartyID = PRS.PartyID
											LEFT JOIN KYPEnrollment.pAccount_PDM_Organization ORG
											ON P.PartyID = ORG.PartyID				
											WHERE P.AccountID			= @AccountID	AND
												  P.CurrentRecordFlag	= 1			AND
												  Type IN('Individual Ownership','Entity Ownership','SubcontractorIndividual','SubcontractorEntity')) PARTY_OWNED_OWN
							ON  ISNULL(MAIN.OwnedLegalName,'')	= ISNULL(PARTY_OWNED_OWN.PartyOwnedLegalName,'')	AND
								ISNULL(MAIN.OwnedSSN,'')		= ISNULL(PARTY_OWNED_OWN.PartyOwnedSSN,'')			AND
								ISNULL(MAIN.OwnedEIN,'')		= ISNULL(PARTY_OWNED_OWN.PartyOwnedEIN,'')			AND
								ISNULL(MAIN.OwnedFirstName,'')	= ISNULL(PARTY_OWNED_OWN.PartyOwnedFirstName,'')	AND
								ISNULL(MAIN.OwnedLastName,'')	= ISNULL(PARTY_OWNED_OWN.PartyOwnedLastName,'')		AND
								MAIN.PartyOwnedType = PARTY_OWNED_OWN.Type

					END
*/			
				END

				DELETE FROM @TempPersonOrOrganization
				TRUNCATE TABLE #TempPartysOfAccount
-- PRINT @AccountID
-- PRINT @J				
				SET @AccountID		= NULL
				SET @ParentPartyID	= NULL

				SET @J = @J + 1

			END
			
			-- Call the below Procedure which will Insert the Accounts and it's MOCAs in Party Associate tables.
			EXEC [KYPEnrollment].[sp_Update_PartyAssociate_Taxid_Bulk_mvcV2] @TaxID,@ProfileID
			/*IF	(@TaxID = '951750445' AND @ProfileID = '0000127136') OR (@TaxID = '942494000' AND @ProfileID = '0000020390') OR
				(@TaxID = '942728480' AND @ProfileID = '0000133667')
			
			BEGIN
				-- PRINT 'KAISER OR CPE'
				EXEC [KYPEnrollment].[sp_Update_PartyAssociate_Taxid_Bulk] @TaxID,@ProfileID
			END
			
			ELSE
			
			BEGIN
				-- PRINT 'OTHER MOCAs'
				EXEC [KYPEnrollment].[sp_Update_PartyAssociate_TaxID] @TaxID,@ProfileID
			END
			*/
			TRUNCATE TABLE #TempAccountsofTAXandProfilewise
			
			IF OBJECT_ID('tempdb..#TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN') IS NOT NULL
			BEGIN
				DROP TABLE #TempUniqueIndMOCAForAnAccountHavingSameProfileAndTIN
			END;
			
			IF OBJECT_ID('tempdb..#TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN') IS NOT NULL
			BEGIN
				DROP TABLE #TempUniqueOrgMOCAForAnAccountHavingSameProfileAndTIN
			END;
			
			IF OBJECT_ID('tempdb..#TempMOCARelationforOtherOwnershipHavingSameProfileAndTIN') IS NOT NULL
			BEGIN
				DROP TABLE #TempMOCARelationforOtherOwnershipHavingSameProfileAndTIN
			END;

			SET @ProfileID	= NULL
			SET @TaxID		= NULL
-- PRINT @ProfileID
			SET @J = 1
			SET @I = @I + 1

		END
		
		DROP TABLE #TempDeltaProcessedProfileTIN
		DROP TABLE #TempDeltaProcessedDistinctProfileTIN
		DROP TABLE #TempAccountsofTAXandProfilewise
		DROP TABLE #TempPartysOfAccount
		DROP TABLE #TempAccountExistingMOCAs

	COMMIT TRAN
	SELECT 1

	END TRY

	BEGIN CATCH

		ROLLBACK TRAN
		INSERT INTO kypenrollment.DeltaProcedureErrorLog(ErrorName,ErrorNumber,ErrorProcedure,ErrorMessage,ErrorLine,ErrorDate)
		SELECT 'Delta MOCA at TaxID Procedure Error',ERROR_NUMBER(),ERROR_PROCEDURE(),ERROR_MESSAGE(),ERROR_LINE(),GETDATE()

		SELECT 0

	END CATCH

END


GO

