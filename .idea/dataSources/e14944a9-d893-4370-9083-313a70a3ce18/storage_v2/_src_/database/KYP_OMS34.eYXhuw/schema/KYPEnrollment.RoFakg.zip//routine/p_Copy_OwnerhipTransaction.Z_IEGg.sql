
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Ownership transaction: recive 4 parametros
-- party ID old, new party id, nombre del usuario que registra y
-- type: si es vacio hace un copiado a partir del party id O si es distinto de vacio hace la copia a partir de transaction id
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_OwnerhipTransaction]
	@partyId INT,
	@newPartyId INT,
	@lastActionUserID varchar(100),
	@type varchar(50)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF(@type ='')
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnerhipTransaction]
		(PartyID ,
		[Description] ,
		Amount ,
		[LastAction] ,	
		[LastActionDate] ,
		[LastActorUserID] ,
		[LastActionApprovedBy] ,
		[CurrentRecordFlag])
		SELECT @newPartyId
		,[Description]
		,[Amount]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnerhipTransaction] WHERE PartyID = @partyId		
	END
	ELSE
	BEGIN
		INSERT INTO [KYPEnrollment].pAccount_PDM_OwnerhipTransaction
		(PartyID ,
		Description ,
		Amount ,
		[LastAction],
		[LastActionDate],
		[LastActorUserID],
		[LastActionApprovedBy],
		[CurrentRecordFlag])
		SELECT @newPartyId
		,[Description]
		,[Amount]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
		FROM [KYPPORTAL].[PortalKYP].[pPDM_OwnerhipTransaction] WHERE TransactionID = @partyId
	END
	SELECT @message = '[pAccount_PDM_OwnerhipTransaction]  : ' + CONVERT(char(10), 'OK')
	RAISERROR(@message, 0, 1) WITH NOWAIT		
END


GO

