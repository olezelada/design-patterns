
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_ClosedAlertHistoryCount]
	-- Add the parameters for the stored procedure here
	
	@AlertID int,
	@watchedPartyID int,
	@CurrentWFStatus Varchar(50)
AS
begin   
--DISABLE TRIGGER trg_MDM_AlertOnUpdate ON [KYP].[MDM_Alert];
--DISABLE TRIGGER trg_SetFalsePositiveonUpdate ON [KYP].[MDM_Alert];
declare @closeCount int;
select  @closeCount =COUNT(*) from KYP.MDM_Alert where WatchedPartyID=@watchedPartyID and CurrentWFStatus = 'CloseAlert';
update KYP.MDM_Alert set Row_Updation_Source='sp_ClosedAlertHistoryCount',AlertHistoryCount = @closeCount where AlertID=@AlertID;
--ENABLE TRIGGER trg_MDM_AlertOnUpdate  ON [KYP].[MDM_Alert];
--ENABLE TRIGGER trg_SetFalsePositiveonUpdate  ON [KYP].[MDM_Alert];
 End


GO

