
-- =============================================
-- Author:		<Rahul Raghavendra>
-- Create date: <Create Date,07/12/2018,>
-- Description:	<Description,KEN-17737,
	--1.	If it is for group- Then all the rendering and rendering -s applications affiliated with it shall be disaffiliated. 
	--2.	If it is a rendering � then all the groups for which it is affiliated with shall be disaffiliated.
	--3.	If it is NMP- Then the group to which it is affiliated shall be disaffiliated. >
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------

CREATE PROCEDURE [KYPEnrollment].[Copy_DisenrolledData] 
@AccountNumber varchar(20),
@ApplicationReceivedDate SMALLDATETIME,
@userName varchar(200),
@ProviderTypeCode varchar(10)
	
AS
BEGIN

SET NOCOUNT ON;
Declare 
@AccountType varchar(50),
@AccountID int

BEgin Try
	SELECT @AccountID=AccountID, @AccountType=AccountType FROM KYPEnrollment.pADM_Account WHERE AccountNumber=@AccountNumber

		If (@AccountType in ('R','NMP'))
		BEGIN
			UPDATE B
					SET B.AffiliationEndDate=@ApplicationReceivedDate - 1,
						B.CurrentRecordFlag=0,
						B.LastActionApprovedBy=@userName,
						B.LastActionDate=GetDate(),
						B.LastAction='U' 
					FROM KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_RenderingAffiliation B ON A.AccountID=B.AffiliatedAccountID and isnull(B.CurrentRecordFlag,1)=1
					WHERE A.AccountID=@AccountID and A.IsDeleted=0 and A.AccProcessing=0
					
			UPDATE C
					SET C.CodeDateExpDate = @ApplicationReceivedDate - 1,
						C.LastActionDate = GETDATE(),
						C.ModifiedBy=@userName,
						C.LastAction='U',
						Row_Updation_Source = 'Trigger_return'
					FROM KYPEnrollment.pADM_Account A
					inner join KYPEnrollment.EDM_AccountInternalUse B ON B.AccountID=A.AccountID and B.IsApproved=1 and isnull(B.CurrentRecordFlag,1)=1
					inner join KYPEnrollment.EDM_AccountInternalMany C ON B.AccountInternalUseID=C.AccountInternalUseID and C.IsApproved= 1
					WHERE A.AccountID=@AccountID and C.CodeType='Category' AND isnull(C.CurrentRecordFlag,1)=1 AND isnull(C.isDeleted,0) = 0
					and A.IsDeleted=0 and A.AccProcessing=0

				
		END
		ELSE IF(@ProviderTypeCode in ('016','015'))
		BEGIN
		
				UPDATE B
					SET B.AffiliationEndDate=@ApplicationReceivedDate - 1,
						B.CurrentRecordFlag=0,
						B.LastActionApprovedBy=@userName,
						B.LastActionDate=GetDate(),
						B.LastAction='U' 						
					FROM KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_RenderingAffiliation B ON A.AccountID=B.AffiliatedAccountID and isnull(B.CurrentRecordFlag,1)=1
					WHERE A.AccountID in (
										select PB.AccountID from KYPEnrollment.pADM_Account PA
										inner join KYPEnrollment.pADM_Account PB on PA.NPI= PB.NPI and PA.OwnerNo=PB.OwnerNo and PA.ServiceLocationNo=PB.ServiceLocationNo
										where PA.AccountID=@AccountID and PB.ProviderTypeCode in('016','015') and PB.IsDeleted=0 and PB.AccProcessing=0
					)
					
			UPDATE C
					SET C.CodeDateExpDate = @ApplicationReceivedDate - 1,
						C.LastActionDate = GETDATE(),
						C.ModifiedBy=@userName,
						C.LastAction='U',
						Row_Updation_Source = 'Trigger_return'
						
					FROM KYPEnrollment.pADM_Account A
					inner join KYPEnrollment.EDM_AccountInternalUse B ON B.AccountID=A.AccountID and B.IsApproved=1 and isnull(B.CurrentRecordFlag,1)=1
					inner join KYPEnrollment.EDM_AccountInternalMany C ON B.AccountInternalUseID=C.AccountInternalUseID and C.IsApproved= 1
					WHERE A.AccountID in (
										select PB.AccountID from KYPEnrollment.pADM_Account PA
										inner join KYPEnrollment.pADM_Account PB on PA.NPI= PB.NPI and PA.OwnerNo=PB.OwnerNo and PA.ServiceLocationNo=PB.ServiceLocationNo
										where PA.AccountID=@AccountID and PB.ProviderTypeCode in('016','015') and PB.IsDeleted=0 and PB.AccProcessing=0
					)				
					and C.CodeType='Category' AND isnull(C.CurrentRecordFlag,1)=1 AND isnull(C.isDeleted,0) = 0
		END
		ELSE
		BEGIN
		
			
			UPDATE B
					SET B.AffiliationEndDate=@ApplicationReceivedDate - 1,
						B.CurrentRecordFlag=0,
						B.LastActionApprovedBy=@userName,
						B.LastActionDate=GetDate(),
						B.LastAction='U'  
					FROM KYPENROLLMENT.pADM_Account A
					inner join  KYPEnrollment.pAccount_RenderingAffiliation B ON A.AccountID=B.AccountID and isnull(B.CurrentRecordFlag,1)=1
					WHERE A.AccountID=@AccountID and A.IsDeleted=0 and A.AccProcessing=0
					
			UPDATE C
					SET C.CodeDateExpDate = @ApplicationReceivedDate - 1,
						C.LastActionDate = GETDATE(),
						C.ModifiedBy=@userName,
						C.LastAction='U',
						Row_Updation_Source = 'Trigger_return'
						
					FROM KYPEnrollment.pADM_Account A
					inner join KYPEnrollment.EDM_AccountInternalUse B ON B.AccountID=A.AccountID and B.IsApproved=1 and B.CurrentRecordFlag=1
					inner join KYPEnrollment.EDM_AccountInternalMany C ON B.AccountInternalUseID=C.AccountInternalUseID and C.IsApproved= 1
					WHERE A.AccountID=@AccountID and C.CodeType='Category' AND isnull(C.CurrentRecordFlag,1)=1 AND isnull(C.isDeleted,0) = 0
					and A.IsDeleted=0 and A.AccProcessing=0

		END	
End Try
Begin Catch
	 IF @@TRANCOUNT > 0
	 ROLLBACK TRANSACTION 
	  
	 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'AccountID',@KeyValue = @AccountID; 
End Catch		
END


GO

