







CREATE TRIGGER [KYP].[trg_MDM_AlertOnUpdate] ON [KYP].[MDM_Alert]
AFTER UPDATE
AS
BEGIN
	SET NOCOUNT ON;
	--**
	DECLARE @Row_Updation_Source VARCHAR(100),
	@WFStatusAlert VARCHAR(100),
	@StatusCodeAlert int
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source,@WFStatusAlert=WFStatus,@StatusCodeAlert=StatusCodeNumber FROM INSERTED 
	IF (ISNULL(@Row_Updation_Source,'') in ('KYP.MDM_Alert', 'p_LoadSearchProviders','p_UpdateAlertage','p_LoadDataInMDMRelatedAlerts','sp_ClosedAlertHistoryCount') AND Update(Row_Updation_Source)) or not exists (select * from inserted)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	
	--**
      
	DECLARE @alertID INT
		,@UserID INT
		,@USERIDBY INT
		,@CurrentlyAssignedToID VARCHAR(50)
		,@CurrentlyAssignedByID VARCHAR(50)
		,@MajorDisposition VARCHAR(50)
		,@DateInitiated SMALLDATETIME
		,@PartyName VARCHAR(100)
		,@AlertNumber VARCHAR(15)
		,@NoofDays INT
		,@Rangename VARCHAR(20)
		,@WatchlistName VARCHAR(100)
		,@Priority VARCHAR(15)
		,@DateResolved SMALLDATETIME
		,@DaysCurrentStatus INT
		,@StatuscodeNumber INT
		,@Statuscode VARCHAR(10)
		,@IsDeleted BIT
		,@CurrentWFStatus VARCHAR(100)
		,@IsMerged VARCHAR(10)
		,@AlertStatusGroup VARCHAR(25)
		,@Medicaid_id varchar(20)
		,@MatchStatusIndicatordecription varchar(15)
        ,@AlertRelevance varchar(20)
        ,@AlertCreatedDate datetime
        ,@AlertCreatedBy int
        ,@PartyID int
        ,@ActivityStatus varchar(50)
        ,@Status varchar(10)
        
        

	SELECT @alertID = AlertID
		,@UserID = AssignedToUserID
		,@USERIDBY= AssignedByUserID
		,@MajorDisposition = CurrentMajorDisposition
		,@PartyName = WatchedPartyName
		,@AlertNumber = AlertNo
		,@WatchlistName = WatchlistName
		,@DateInitiated = DateInitiated
		,@Priority = Priority
		,@DateResolved = DateClosed
		,@StatuscodeNumber = StatusCodeNumber
		,@IsDeleted = IsDeleted
		,@CurrentWFStatus = WFStatus
		,@IsMerged = ISMERGED
		,@Medicaid_id=MedicaidID
		,@MatchStatusIndicatordecription=MatchStatusIndicatorDesc
		,@AlertRelevance=Relevance
		,@AlertCreatedDate=CreatedDate
		,@PartyID=WatchedPartyID
		,@ActivityStatus=ActivityStatus
		,@Status=status
		
	FROM inserted


	SELECT @CurrentlyAssignedToID = UserID
	FROM KYP.OIS_User
	WHERE PersonID = @UserID
	
  SELECT @CurrentlyAssignedByID = UserID
	FROM KYP.OIS_User
	WHERE PersonID = @USERIDBY 


	SELECT @NoofDays = ABS(DATEDIFF(d, @DateInitiated, GETDATE()))
		,@Rangename = CASE 
			WHEN @NoofDays >= 0
				AND @NoofDays <= 3
				THEN '0-3 days'
			WHEN @NoofDays > 3
				AND @NoofDays <= 10
				THEN '4-10 days'
			WHEN @NoofDays > 10
				AND @NoofDays <= 15
				THEN '11-15 days'
			WHEN @NoofDays > 15
				THEN '15+ days'
			ELSE NULL
			END
		,@DaysCurrentStatus = ABS(DATEDIFF(d, @DateResolved, GETDATE()))
		,@AlertStatusGroup = CASE 
			WHEN @StatuscodeNumber = 9
				THEN 'Incoming Alert'
			WHEN @StatuscodeNumber IN (
					10
					,11
					,13
					)
				THEN 'Working Alert'
			ELSE NULL
			END
		,@StatuscodeNumber = CASE 
			WHEN @StatuscodeNumber IN (
					11
					,13
					)
				THEN 10
			ELSE @StatuscodeNumber
			END

	SELECT @Statuscode = NULLIF(Description, '')
	FROM KYP.LK_Screening
	WHERE SortOder = @StatuscodeNumber
		AND TypeID = 2

	IF EXISTS (
			SELECT 1
			FROM [KYP].[MDM_DashBoardTable]
			WHERE AlertID = @alertID
			)
	BEGIN
		UPDATE [KYP].[MDM_DashBoardTable]
		SET [AgeByDays] = @NoofDays
			,[Range] = @Rangename
			,[AlertType] = @WatchlistName
			,[CurrentlyAssignedToID] = @CurrentlyAssignedToID
			,[CurrentMajorDisposition] = @MajorDisposition
			,[DateInitiated] = @DateInitiated
			,[DateResolved] = @DateResolved
			,[PartyName] = @PartyName
			,[AlertNumber] = @AlertNumber
			,[StatuscodeNumber] = @StatuscodeNumber
			,[Statuscode] = @Statuscode
			,[Priority] = @Priority
			,[DaysCurrentStatus] = @DaysCurrentStatus
			,[CurrentWFStatus] = @CurrentWFStatus
			,[IsMerged] = @IsMerged
			,[AlertStatusGroup] = @AlertStatusGroup
		FROM [KYP].[MDM_DashBoardTable]
		JOIN inserted ON [KYP].[MDM_DashBoardTable].AlertID = @alertID
	END
	ELSE IF @alertID IS NOT NULL
	BEGIN
		INSERT INTO [KYP].[MDM_DashBoardTable] (
			[AlertID]
			,[AgeByDays]
			,[Range]
			,[AlertType]
			,[CurrentlyAssignedToID]
			,[CurrentWFStatus]
			,[CurrentMajorDisposition]
			,[DateInitiated]
			,[DateResolved]
			,[PartyName]
			,[AlertNumber]
			,[Statuscode]
			,[StatuscodeNumber]
			,[Month]
			,[RiskRange]
			,[NPI]
			,[RiskScore]
			,[Priority]
			,[DaysCurrentStatus]
			,[IsMerged]
			,[AlertStatusGroup]
			)
		VALUES (
			@alertID
			,@NoofDays
			,@Rangename
			,@WatchlistName
			,@CurrentlyAssignedToID
			,@CurrentWFStatus
			,@MajorDisposition
			,@DateInitiated
			,@DateResolved
			,@PartyName
			,@AlertNumber
			,@Statuscode
			,@StatuscodeNumber
			,NULL
			,NULL
			,NULL
			,NULL
			,@Priority
			,@DaysCurrentStatus
			,@IsMerged
			,@AlertStatusGroup
			)
	END



	IF(@CurrentWFStatus = 'Completed' and @Status = 'Complet')
	BEGIN
		Insert into Debug(FieldName, FieldValue, ProcedureName, LogTime)Values (@ActivityStatus,@CurrentWFStatus,@AlertNumber,GETDATE())
		DELETE FROM KYP.MDM_DashBoardTable WHERE AlertID = @alertID		
		--Start KEN-19407
		EXECUTE [KYPEnrollment].[Copy_GK_Watchlist_Data] @alertID
		--END KEN-19407			 
		IF EXISTS(SELECT 1 FROM KYP.MDM_AlertResolution WHERE ResolutionType 
			IN('Suspend Account Temporarily','Suspend Account','Enrollment Record Updated','Deactivate Account','Deactivate Provider As Deceased') AND AlertID=@alertID)
		BEGIN
			EXECUTE [KYPEnrollment].[Copy_AlertInternalUseData] @AlertNumber,@alertID
		END
		 
        IF NOT EXISTS (SELECT 1 FROM KYPEnrollment.pAccount_History WHERE RelatedID = @alertID and ActionID=54)
		BEGIN				
			EXECUTE [KYP].[p_UpdateAlertonAccount] @alertID ,@CurrentlyAssignedToID ,@CurrentlyAssignedByID ,@MatchStatusIndicatordecription ,@WatchlistName ,@AlertRelevance,@AlertCreatedDate,@AlertCreatedBy ,@Medicaid_id ,@CurrentWFStatus ,@AlertNumber,@DateResolved ,@PartyID,@Priority,@PartyName;												  
		END	
	--CP-34 Implementation END
	END
END


GO

