



CREATE VIEW [KYPEnrollment].[Vw_BizProfile_Details]
AS
Select --(row_number() over ( order by A.AccountID))  AS ViewID,
	   A.BizProfileDetailsID, A.ProfileID, A.AccountID, A.AccountTypeID
	   ,A.AccountEnrollmentStatus, A.AccountBillingStatus, A.AccountLegalName
	   ,A.AccountDBAName, A.AccountProviderType,A.AccountNPI,A.AccountSSN
	   ,A.AccountEIN,A.AccountAddressType,A.AccountAddressLine1,A.AccountAddressLine2
	   ,A.AccountAdrCity,A.AccountAdrState,A.AccountAdrZip9,A.AccountLicenseType
	   ,A.AccountLicenseNo,A.AccountPhone,A.AccountPIN,A.UserRemark,A.EffectiveBeginDate
	   ,A.EffectiveEndDate,A.LastAction,A.LastActionDate,A.LastActorUserID,A.LastActionReason
	   ,A.LastActionComments,A.LastActionApprovedBy,A.CurrentRecordFlag,A.AccountNumber
	   ,A.PayAccountAddressLine1,A.PayAccountAddressLine2,A.PayAccountAdrCity,A.PayAccountAdrState
	   ,A.PayAccountAdrZip9,A.AcID,A.AcName,pAcc.LegacyAccountNo,pAcc.StateStatusAcc
from KYPEnrollment.pAccount_BizProfile_Details A
inner join KYPEnrollment.pADM_Account pAcc on pAcc.AccountID = A.AccountID
Where A.CurrentRecordFlag = 1


GO

