CREATE FUNCTION [dbo].[fnIsSmallDateTime](@d VARCHAR(50))
    RETURNS BIT
    AS
    BEGIN
    DECLARE @bitReturnValue bit
 
 
    SELECT @bitReturnValue =CASE
             WHEN ISDATE(@d) = 1 THEN CASE
                                        WHEN convert(datetime,@d) > ='19000101'
                         AND convert(datetime,@d) <= '20790606 23:59:29.998' THEN 1
                                        ELSE 0
                                      END
             ELSE 0
           END
    RETURN @bitReturnValue
    END


GO

