/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertSDMPartyScreening]
(@PartyID int
 ,@ScreeningSchemeID int= NULL
 ,@CreatedBy int =NULL
 ,@DateCreated datetime = NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[SDM_PartyScreening]
           ([PartyID]
           ,[ScreeningSchemeID]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@ScreeningSchemeID
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[SDM_PartyScreening]')

end


GO

