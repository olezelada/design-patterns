-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [KYP].[RemoveUnwantedCharacters] 
(
	
	@NameValue varchar(500)
)
RETURNS varchar(255)
AS
BEGIN 
   declare 
   @NameValue1 varchar(250),
   @NameValue2 varchar(250),
   @NameValue3 varchar(250),
   @NameValue4 varchar(250)
      
    if substring(@NameValue,1,1)=' '  or RIGHT(@namevalue,1)=' '
    begin      
      select @NameValue  = rtrim(ltrim(@NameValue))
    end
    if substring(@NameValue,1,1)='''' or RIGHT(@namevalue,1)=''''
    begin
	  select @NameValue = KYP.RemoveSinglequotesAdd(@NameValue)
	end 
	if substring(@NameValue,1,1)='"' or RIGHT(@namevalue,1)='"'
	begin
      select @NameValue = KYP.RemovedoublequotesAdd(@NameValue)
    end
    if substring(@NameValue,1,1)='\' or RIGHT(@namevalue,1)='\'
    begin
      select @NameValue = KYP.RemoveforwardslashAdd(@NameValue)
    end
    if  substring(@NameValue,1,1)='/' or RIGHT(@namevalue,1)='/'
    begin
      select @NameValue = KYP.RemovebackslashAdd(@NameValue)
    end

return @NameValue
END


GO

