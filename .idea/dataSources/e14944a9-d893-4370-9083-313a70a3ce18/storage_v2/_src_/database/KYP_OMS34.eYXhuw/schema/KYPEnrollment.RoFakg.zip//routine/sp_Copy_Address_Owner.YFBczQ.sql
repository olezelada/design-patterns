

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create address and location by Entity Ownership corporation.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @address_id : this is the addressID Application that will be Create in Update Account, it is Null when account is create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Address_Owner]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@address_id INT = NULL

AS
BEGIN
SET NOCOUNT ON 
DECLARE @date_created SMALLDATETIME;
 SET @date_created = CURRENT_TIMESTAMP;
 IF @address_id IS NULL
 BEGIN
  DECLARE @address_app_id INT, @location_app_id INT,@address_acc_id INT;

  declare @IDS table(id int,LocationID int)

--		DECLARE corporation_address_cursor CURSOR FAST_FORWARD READ_ONLY FOR
		declare @corporation_address table(pk int identity(1,1),AddressID int,LocationID int)
		--SELECT identity(INT,1,1) as pk, [AddressID],[LocationID] 
        --        into #corporation_address
		/*insert into @corporation_address */

		select [AddressID],[LocationID] 
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  
		WHERE [PartyID] = @party_app_id
		order by AddressID desc
		
		--OPEN corporation_address_cursor
		--FETCH NEXT FROM corporation_address_cursor INTO @address_app_id,@location_app_id
		/*declare @cont int,@tot int
		set @cont=1
		select @tot=MAX(pk) from @corporation_address 
        WHILE @cont<=@tot
              --WHILE @@FETCH_STATUS = 0
		BEGIN
                  select @address_app_id=[AddressID],@location_app_id=[LocationID] from @corporation_address where pk=@cont*/

			INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
			   ([AddressLine1] ,
				[AddressLine2] ,
				[County] ,
				[City] ,
				[Zip] , 
				[ZipPlus4] , 
				[State] , 
				[Country] , 
				[Latitude] ,
				[Longitude] , 
				[GeographicArea],
				[LastAction],
				[LastActionDate],
				[LastActionUserID],
				[LastActionApprovedByUsedID],
				[CurrentRecordFlag],
				TempAddressID)
			 OUTPUT inserted.AddressID INTO @IDs(ID)
				SELECT [AddressLine1]
				,[AddressLine2]
				,[County]
				,[City]
				,[Zip]
				,[ZipPlus4]
				,[State]
				,[Country]
				,[Latitude]
				,[Longitude]
				,[GeographicArea]
				,'C'
				,@date_created
				,@last_action_user_id
				,@last_action_user_id
				,1
				,AddressID
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] WHERE AddressID in ( select [AddressID]	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] 
			 WHERE [PartyID] = @party_app_id )
			     AND [IsDeleted] = 0	
			--SELECT @address_acc_id = SCOPE_IDENTITY(); 
	

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
		   ([AddressID] ,
			[PartyID] ,
			[Type] ,
			[CreatedBy] ,
			[DateCreated] ,
			[IsDeleted] ,
			[LastAction],
			[LastActionDate],
			[LastActorUserID],
			[LastActionApprovedBy],
			[CurrentRecordFlag])
		SELECT ad.AddressID
			,@party_account_id
			,lo.[Type]
			,lo.[CreatedBy]
			,@date_created
			,lo.[IsDeleted]
			,'C'
			,@date_created
			,@last_action_user_id
			,@last_action_user_id
			,1
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] lo
		INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.TempAddressID = lo.AddressID
		WHERE  [LocationID]  in ( select LocationID	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  WHERE [PartyID] = @party_app_id)
		AND [IsDeleted] = 0	

		UPDATE [KYPEnrollment].[pAccount_PDM_Address] SET TempAddressID = NULL
		WHERE AddressID IN (SELECT id FROM @IDs)
			--set @cont=@cont+1

		--	FETCH NEXT FROM corporation_address_cursor INTO @address_app_id,@location_app_id
		--END	
		--CLOSE corporation_address_cursor;
		--DEALLOCATE corporation_address_cursor;
        --drop table #corporation_address
 END
 ELSE
 BEGIN
 INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
			   ([AddressLine1] ,
				[AddressLine2] ,
				[County] ,
				[City] ,
				[Zip] , 
				[ZipPlus4] , 
				[State] , 
				[Country] , 
				[Latitude] ,
				[Longitude] , 
				[GeographicArea],
				[LastAction],
				[LastActionDate],
				[LastActionUserID],
				[LastActionApprovedByUsedID],
				[CurrentRecordFlag])
				SELECT [AddressLine1]
				,[AddressLine2]
				,[County]
				,[City]
				,[Zip]
				,[ZipPlus4]
				,[State]
				,[Country]
				,[Latitude]
				,[Longitude]
				,[GeographicArea]
				,'C'
				,@date_created
				,@last_action_user_id
				,@last_action_user_id
				,1
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] WHERE AddressID = @address_id 	
			SELECT @address_acc_id = SCOPE_IDENTITY(); 
		
		    DECLARE @location_id INT;
            SELECT @location_id= LocationID FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] WHERE AddressID= @address_id;
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
		   ([AddressID] ,
			[PartyID] ,
			[Type] ,
			[CreatedBy] ,
			[DateCreated] ,
			[IsDeleted] ,
			[LastAction],
			[LastActionDate],
			[LastActorUserID],
			[LastActionApprovedBy],
			[CurrentRecordFlag])
			SELECT @address_acc_id
			,@party_account_id
			,[Type]
			,[CreatedBy]
			,@date_created
			,[IsDeleted]
			,'C'
			,@date_created
			,@last_action_user_id
			,@last_action_user_id
			,1
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] WHERE [LocationID] = @location_id	
 END
END

GO

