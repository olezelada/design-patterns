
/* ==========================================================
-- Author:		<clopez>
-- PROCEDURE: update section Licensure Exemption.
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Exempt_Licensure]
                                      @party_account_id INT,
                                      @party_app_id INT
AS
BEGIN
   SET  NOCOUNT ON

  if exists(  SELECT *
              FROM   [KYPPORTAL].[PortalKYP].[pPDM_ProviderQuestionnarie]
              WHERE  PartyID =@party_app_id
              AND    Value = 'true'
              AND    Name LIKE 'exemptCheck%')
  BEGIN
    UPDATE [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie]
    SET    CurrentRecordFlag = 0,
           IsDeleted = 1
    WHERE  PartyID = @party_account_id
    AND    Name LIKE 'exemptCheck%';
    PRINT 'DELETED: Section (Licensure Exemption) data deleted'
  END
  EXEC [KYPEnrollment].[sp_Copy_Exempt_Licensure] @party_account_id, @party_app_id;

  PRINT 'UPDATED Section: Licensure Exemption'
  PRINT 'PartyID: '+ cast(@party_account_id as varchar(10)) + '(ACCOUNT)'
  PRINT 'PartyID: '+ cast(@party_app_id as varchar(10)) + '(APPLICATION)'

END


GO

