


-- =============================================
-- Author:		<Author,,Lperez>
-- PROCEDURE que relaciona account con otros account apartir de una busqueda 
-- valores de busqueda 
-- SIMILAR (EIN,SSN,NPI) que sean parecidos
-- RELATED ( @address Zip, Specialty)
-- Performance improved by Richard Jimenez 03/02/2018, 12/09/2018 using TVF Functions
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		Blocked Session		Sundar		14Nov2018		Replaced While loops to direct Insert statements.

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_SimilarRelated]
	@accountID INT,
	@partyID INT,
	@npi varchar(10),
	@ein varchar(10),
	@ssn varchar(10),
	@addressZip varchar(5),
	@lastActorUserID varchar(100)
AS
BEGIN  
	BEGIN TRY  
		DECLARE @sql nvarchar(MAX),@accountIDTmp INT,@partyIDTmp INT,@idTmp INT,@IDTmpB INT,@npiTmp varchar(15),@einTmp varchar(15),@ssnTmp varchar(15),  
		@message varchar(100),@dateCreated date,@lastAction varchar(1),@specialityCode varchar(100)  

		SET @dateCreated = GETDATE();  
		SET @lastAction = 'C';  

		SELECT @message = 'SIMILAR RELATED: BEGIN'  
		RAISERROR(@message, 0, 1) WITH NOWAIT   

		-- SIMILAR (EIN,SSN,NPI) que sean parecidos  

		--DECLARE Related_Cursor CURSOR FOR    
		declare  @related table (pk int identity(1,1),AccountID int ,SSN varchar(10), EIN varchar(10),  NPI varchar(10))  
		-- select identity(int,1,1)as pk,srd.AccountID,ISNULL(srd.SSN,'') as SSN,ISNULL(srd.EIN,'') AS EIN, ISNULL(srd.NPI,'') AS NPI    
		--into #related  
		insert into @related  
		select srd.AccountID,ISNULL(srd.SSN,'') as SSN,ISNULL(srd.EIN,'') AS EIN, ISNULL(srd.NPI,'') AS NPI    
		FROM [KYPEnrollment].[TVF_SearchSimilarRelated](@ssn,@ein,@npi) srd    
		--WHERE srd.SSN=@ssn  OR srd.EIN = @ein   OR srd.NPI=@npi   

		-- Insert related AccountID and AccountLinkedID  

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]  
		([AccountID]  
		,[LinkedWithAccountID]  
		,[LinkType]  
		,[LinkingRemarks]  
		,[LastAction]  
		,[LastActionDate]  
		,[LastActorUserID]  
		,[LastActionApprovedBy]  
		,[CurrentRecordFlag])  
		SELECT @accountID,r.AccountID,'Related','','C',GETDATE(),@lastActorUserID,@lastActorUserID,1 FROM @related r  
		UNION ALL   
		SELECT r.AccountID,@accountID,'Related','','C',GETDATE(),@lastActorUserID,@lastActorUserID,1 FROM @related r  
		-- Insert  

		--Ein  
		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]  
		([Attribute]  
		,[Value]  
		,[LinkedAccountID])    
		SELECT 'ein',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount]WHERE AccountID = @accountID and LinkedWithAccountID =t.AccountID and LinkType ='Related') as lid  
		FROM [KYPEnrollment].[TVF_SearchSimilarRelated](NULL,@ein,NULL) t    
		--WHERE t.ein<>'' and t.ein= @ein    
		UNION ALL  
		SELECT 'ein',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount] WHERE AccountID = t.AccountID and LinkedWithAccountID =@accountID and LinkType ='Related') as lid  
		FROM [KYPEnrollment].[TVF_SearchSimilarRelated](NULL,@ein,NULL) t      
		--WHERE t.ein<>'' and t.ein= @ein     
		--EIN   

		--NPI  
		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]  
		([Attribute]  
		,[Value]  
		,[LinkedAccountID])    
		SELECT 'npi',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount]WHERE AccountID = @accountID and LinkedWithAccountID =t.AccountID and LinkType ='Related') as lid  
		FROM  [KYPEnrollment].[TVF_SearchSimilarRelated](NULL,NULL,@npi)  t --[KYPEnrollment].[SearchSimilarRelated] t    
		--WHERE t.npi<>'' and t.npi= @ein    
		UNION ALL  
		SELECT 'npi',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount] WHERE AccountID = t.AccountID and LinkedWithAccountID =@accountID and LinkType ='Related') as lid  
		FROM [KYPEnrollment].[TVF_SearchSimilarRelated](NULL,NULL,@npi) t -- [KYPEnrollment].[SearchSimilarRelated] t    
		-- WHERE t.npi<>'' and t.npi= @ein   

		--NPI  
		--ssn  
		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]  
		([Attribute]  
		,[Value]  
		,[LinkedAccountID])    
		SELECT 'ssn',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount]WHERE AccountID = @accountID and LinkedWithAccountID =t.AccountID and LinkType ='Related') as lid  
		FROM  [KYPEnrollment].[TVF_SearchSimilarRelated](@ssn,NULL,NULL) t --[KYPEnrollment].[SearchSimilarRelated] t    
		-- WHERE t.ssn<>'' and t.ssn= @ssn   
		UNION ALL  
		SELECT 'ssn',t.ein, ( SELECT top 1 LinkedAccountID from [KYPEnrollment].[pADM_LinkedAccount] WHERE AccountID = t.AccountID and LinkedWithAccountID =@accountID and LinkType ='Related') as lid  
		FROM [KYPEnrollment].[TVF_SearchSimilarRelated](@ssn,NULL,NULL) t    
		--WHERE t.ssn<>'' and t.ssn= @ssn   

		--ssn  

		DECLARE @cont int,@tot int  
		set @cont=1  

		IF Object_ID('tempdb..#similarcode') is not null 
			Drop Table #similarcode;

		create table #similarcode (  
		pk int identity(1,1),  
		Speciality_Code varchar(50)  
		); 
		--CREATE CLUSTERED INDEX ix_tempSimilarCode ON #similarcode ([pk]);  
		--declare @similarcode table (pk int identity(1,1),Speciality_Code varchar(50))  

		insert into #similarcode  
		select spa.Speciality_Code   
		from [KYPPORTAL].[PortalKYP].[pPDM_Speciality] spa WHERE spa.PartyID = @partyID and spa.Type = 'Specialty Code'  

		IF Object_ID('tempdb..#similar') is not null 
			Drop Table #similar;
			
		create table #similar (  
		pk int identity(1,1),  
		AccountID INT,  
		PartyID INT  
		);  
		--CREATE CLUSTERED INDEX ix_tempSimilar ON #similar ([pk]);  

		IF Object_ID('tempdb..#LinkedAccount') is not null 
			Drop Table #LinkedAccount;
			
		Create table #LinkedAccount(LinkedAccountID int)

		--declare @similar table(pk int identity(1,1),AccountID INT ,PartyID INT)  
		insert into #similar   
		select DISTINCT acc.AccountID, acc.PartyID   
		from [KYPEnrollment].[pADM_Account] acc   
		INNER JOIN [KYPEnrollment].pAccount_PDM_Party par ON par.AccountID = acc.AccountID  
		INNER JOIN [KYPEnrollment].pAccount_PDM_Location lo ON lo.PartyID=par.PartyID AND lo.Type='Servicing'  
		INNER JOIN [KYPEnrollment].pAccount_PDM_Address ad ON ad.AddressID = lo.AddressID   
		INNER JOIN [KYPEnrollment].pAccount_PDM_Speciality sp ON sp.PartyID = par.PartyID AND sp.Type = 'Specialty Code'  
		WHERE ad.ZipPlus4 LIKE '%'+@addressZip+'%'   
		--AND sp.Speciality_Code IN(select spa.Speciality_Code from [KYPPORTAL].[PortalKYP].[pPDM_Speciality] spa WHERE spa.PartyID = @partyID and spa.Type = 'Specialty Code')  
		AND sp.Speciality_Code IN(select spa.Speciality_Code from #similarcode spa )   

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
			([AccountID]
			,[LinkedWithAccountID]
			,[LinkType]
			,[LinkingRemarks]
			,[LastAction]
			,[LastActionDate]
			,[LastActorUserID]
			,[LastActionApprovedBy]
			,[CurrentRecordFlag])
		Output Inserted.LinkedAccountID into #LinkedAccount(LinkedAccountID)
		Select 
			@accountId,
			AccountID,
			'Similar',
			'',
			'C',
			Getdate(),
			@lastActorUserID,
			@lastActorUserID,
			1
		From #Similar;

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
			([Attribute]
			,[Value]
			,[LinkedAccountID])
		Select 'Specialty Code',
			T2.Speciality_Code,
			T1.LinkedAccountID
		From #LinkedAccount t1
		Cross Join #similarcode t2 

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
			([Attribute]
			,[Value]
			,[LinkedAccountID])
		Select 'Address ZIP',
			@addressZip,
			T1.LinkedAccountID
		From [KYPEnrollment].pAccount_PDM_Location lo   
			INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.AddressID = lo.AddressID 
			Join #Similar LA on Lo.PartyId = La.PartyID
			Join [KYPEnrollment].[pADM_LinkedAccount] AL on Al.LinkedWithAccountID = LA.AccountID
			Join #LinkedAccount t1 on Al.LinkedAccountID = T1.LinkedAccountID	
			where lo.Type='Servicing' AND ad.ZipPlus4 LIKE '%'+@addressZip+'%'
		
		Truncate table #LinkedAccount;

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
			([AccountID]
			,[LinkedWithAccountID]
			,[LinkType]
			,[LinkingRemarks]
			,[LastAction]
			,[LastActionDate]
			,[LastActorUserID]
			,[LastActionApprovedBy]
			,[CurrentRecordFlag])
		Output Inserted.LinkedAccountID into #LinkedAccount(LinkedAccountID)
		Select 
			AccountID,
			@accountId,
			'Similar',
			'',
			'C',
			Getdate(),
			@lastActorUserID,
			@lastActorUserID,
			1
		From #Similar;

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
			([Attribute]
			,[Value]
			,[LinkedAccountID])
		Select 'Specialty Code',
			T2.Speciality_Code,
			T1.LinkedAccountID
		From #LinkedAccount t1
		Cross Join #similarcode t2 

		INSERT INTO [KYPEnrollment].[pADM_LinkedAccountValue]
			([Attribute]
			,[Value]
			,[LinkedAccountID])
		Select 'Address ZIP',
			@addressZip,
			T1.LinkedAccountID
		From [KYPEnrollment].pAccount_PDM_Location lo   
			INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.AddressID = lo.AddressID 
			Join #Similar LA on Lo.PartyId = La.PartyID
			Join [KYPEnrollment].[pADM_LinkedAccount] AL on Al.AccountID = LA.AccountID
			Join #LinkedAccount t1 on Al.LinkedAccountID = T1.LinkedAccountID	
			where lo.Type='Servicing' AND ad.ZipPlus4 LIKE '%'+@addressZip+'%'		


	/*  declare @cont1 int,@tot1 int  
	set @cont1=1  
	select @tot1= MAX(pk) from #similar  
	set @tot=1  
	select @tot=MAX(pk) from #similarcode   

	while @cont1<=@tot1  

	BEGIN   
		select @accountIDTmp=AccountID,@partyIDTmp=PartyID from #similar where pk=@cont1  

		EXEC @IDTmp = [KYPEnrollment].[sp_Copy_LinkedAccount] @accountID,@accountIDTmp,'Similar','',@lastActorUserID;    
		EXEC @IDTmpB = [KYPEnrollment].[sp_Copy_LinkedAccount] @accountIDTmp,@accountID,'Similar','',@lastActorUserID;    


		set @cont=1  
		while @cont<=@tot  
		BEGIN  
			select @specialityCode=Speciality_Code from #similarcode where pk=@cont  
			IF exists(select sp.Speciality_Code from [KYPEnrollment].pAccount_PDM_Speciality sp where sp.PartyID = @partyIDTmp AND sp.Speciality_Code = @specialityCode AND sp.Type = 'Specialty Code')  
			BEGIN  

				EXEC [KYPEnrollment].[sp_Copy_LinkedAccountValue] @IDTmp,@specialityCode,'Specialty Code';  
				EXEC [KYPEnrollment].[sp_Copy_LinkedAccountValue] @IDTmpB,@specialityCode,'Specialty Code';   
			END   
			set @cont=@cont+1  

		END;  


		IF EXISTS (  
		select 1 from [KYPEnrollment].pAccount_PDM_Location lo   
		INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.AddressID = lo.AddressID   
		where lo.PartyID=@partyIDTmp AND lo.Type='Servicing' AND ad.ZipPlus4 LIKE '%'+@addressZip+'%'  
		)  
		/*((select COUNT(ad.ZipPlus4) from [KYPEnrollment].pAccount_PDM_Location lo   
		INNER JOIN [KYPEnrollment].[pAccount_PDM_Address] ad ON ad.AddressID = lo.AddressID   
		where lo.PartyID=@partyIDTmp AND lo.Type='Servicing' AND ad.ZipPlus4 LIKE '%'+@addressZip+'%' )>0)*/  
		BEGIN  

			EXEC [KYPEnrollment].[sp_Copy_LinkedAccountValue] @IDTmp,@addressZip,'Address ZIP';  
			EXEC [KYPEnrollment].[sp_Copy_LinkedAccountValue] @IDTmpB,@addressZip,'Address ZIP';   
		END   
		set @cont1=@cont1+1  

	END;  
	*/
		SELECT @message = 'SIMILAR RELATED: END'  
		RAISERROR(@message, 0, 1) WITH NOWAIT   
   
	END TRY  
	BEGIN CATCH   
		DECLARE @kval varchar(100)  
		SET @kval = CONVERT(varchar(100), @accountID);  
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'accountID',@KeyValue=@kval  
	--print 'ok'  
	END CATCH   
END


GO

