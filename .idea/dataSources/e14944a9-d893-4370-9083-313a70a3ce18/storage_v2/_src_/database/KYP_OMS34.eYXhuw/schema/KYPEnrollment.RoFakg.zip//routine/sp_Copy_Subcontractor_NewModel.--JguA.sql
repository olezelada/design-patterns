
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Subcontractor_NewModel]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),
   @TaxidProfileid         INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
   DECLARE
      @party_adr           INT,
      @new_party_adr       INT,
      @count_association   INT,
      @main_party_id       INT,
      @is_prepopulated     BIT,
      @target_path         VARCHAR (200),
      @full_name_person    VARCHAR (100),
      @type                VARCHAR (50),
      @org_id              INT,
      @legal_name          VARCHAR (100),
      @person_id           INT;
   PRINT '[sp_Copy_Subcontractor_newmodel]';

   --new account
   IF @TaxidProfileid >0
      BEGIN
         --Call to procedure [KYPEnrollment].[sp_Copy_ProviderQuestionnarie] por store the values of radio button
        -- EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarie] @new_party_id,
        --                                                      @party_id

         DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200),
                           Type             VARCHAR (50)
                        )

         CREATE TABLE #childsub
         (
            pk               INT IDENTITY (1, 1),
            PartyID          INT,
            Type             VARCHAR (50),
            targetpath       VARCHAR (200),
            isprepopulated   BIT
         )

         INSERT INTO @party
            SELECT PartyID,
                   IsPrepopulated,
                   TargetPath,
                   type
              FROM [KYPPORTAL].[PortalKYP].pPDM_Party
             WHERE     type LIKE 'Subcontractor%'
                   AND (IsDeleted = 0 OR IsDeleted = NULL)
                   AND ParentPartyID = @party_id
            ORDER BY partyid DESC

         DECLARE
            @cont   INT,
            @tot    INT
         SELECT @tot = MAX (pk) FROM @party
         SET @cont = 1

         WHILE @cont <= @tot
         BEGIN
            SELECT @party_adr = PartyID,
                   @is_prepopulated = IsPrepopulated,
                   @target_path = TargetPath,
                   @type = type
            FROM @party
            WHERE pk = @cont

            --1
            IF (@type = 'SubcontractorIndividual')
               BEGIN
                 
                  EXEC @new_party_adr =
                          [KYPEnrollment].[sp_Copy_Party_NewModel] @party_adr,
                                                          @new_party_id,
                                                          @account_id,
                                                          @last_action_user_id,
                                                          @TaxidProfileid ;
                  EXEC @person_id =
                          [KYPEnrollment].[sp_Copy_Person] @new_party_adr,
                                                           @party_adr,
                                                           @last_action_user_id,
                                                           'C';
                  EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
                                                         @party_adr,
                                                         NULL,
                                                         @last_action_user_id;
                  EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr,
                                                                     @new_party_adr,
                                                                     @last_action_user_id;

                  --mvc--
                  INSERT
                    INTO #subcontractors (PartyID_Portal,
                                          Type_sub,
                                          PartyID_Enroll)
                  VALUES (@party_adr, @type, @new_party_adr)

                  --

                  IF (@type = 'SubcontractorIndividual')
                     BEGIN
                        EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_adr,
                                                                  @party_adr,
                                                                  @last_action_user_id,
                                                                  NULL,
                                                                  NULL;
                     END

                
               END
            --1
            ELSE
               BEGIN
                  IF (@type = 'SubcontractorEntity')
                     BEGIN
                       
                        EXEC @new_party_adr =
                                [KYPEnrollment].[sp_Copy_Party_NewModel] @party_adr,
                                                                @new_party_id,
                                                                @account_id,
                                                                @last_action_user_id,
                                                                @taxidprofileid;
                        EXEC
                            @org_id =
                               [KYPEnrollment].[sp_Copy_Organization] @new_party_adr,
                                                                      @party_adr,
                                                                      @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr,
                                                               @party_adr,
                                                               NULL,
                                                               @last_action_user_id;
                        EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr,
                                                                           @new_party_adr,
                                                                           @last_action_user_id;

                        --mvc--
                        INSERT
                          INTO #subcontractors (PartyID_Portal,
                                                Type_sub,
                                                PartyID_Enroll)
                        VALUES (@party_adr, @type, @new_party_adr)

                        --

                        IF (@type = 'SubcontractorEntity')
                           BEGIN
                              EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @new_party_adr,
                                                                        @party_adr,
                                                                        @last_action_user_id,
                                                                        NULL,
                                                                        NULL;
                           END


                       
                     --END

                     END
               END

            --**
            --subcontractor father was created
            --if it has children
            --party.type
            --SubcontractorOwnerEntity
            --subcontractorOwnerIndividual


            IF EXISTS
                  (SELECT PartyID
                     FROM [KYPPORTAL].[PortalKYP].pPDM_Party
                    WHERE     type LIKE 'SubcontractorOwner%'
                          AND (IsDeleted = 0 OR IsDeleted = NULL)
                          AND ParentPartyID = @party_adr)
               BEGIN
                  --declare @childsub table (pk int identity(1,1),PartyID int, Type varchar(50))

                  INSERT INTO #childsub
                     SELECT PartyID,
                            Type,
                            TargetPath,
                            IsPrepopulated
                       FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
                      WHERE     ParentPartyID = @party_adr
                            AND (   Type = 'SubcontractorOwnerEntity'
                                 OR Type = 'subcontractorOwnerIndividual')
                            AND (IsDeleted = 0 OR IsDeleted = NULL);

                  DECLARE
                     @cont1   INT,
                     @tot1    INT
                  SELECT @tot1 = MAX (pk) FROM #childsub
                  SET @cont1 = 1
                  DECLARE @partychildsub_port   INT
                  DECLARE @partychildsub_enr   INT
                  DECLARE @partychildtype_port   VARCHAR (50)
                  DECLARE @mainparty_child   INT
                  DECLARE @targetpath_child   VARCHAR (200)
                  DECLARE @isprepopulated_child   BIT

                  WHILE @cont1 <= @tot1
                  BEGIN
                     SELECT @partychildsub_port = partyid,
                            @partychildtype_port = TYPE,
                            @targetpath_child = targetpath,
                            @isprepopulated_child = isprepopulated
                     FROM #childsub
                     WHERE pk = @cont1
                     EXEC @partychildsub_enr =
                             [KYPEnrollment].[sp_Copy_Party] @partychildsub_port,
                                                             @new_party_adr,
                                                             @account_id,
                                                             @last_action_user_id;

                     --mvc--
                     INSERT
                       INTO #subcontractors (PartyID_Portal,
                                             Type_sub,
                                             PartyID_Enroll)
                        VALUES (
                                  @partychildsub_port,
                                  @partychildtype_port,
                                  @partychildsub_enr)

                     --
                     IF @partychildtype_port = 'SubcontractorOwnerEntity'
                        BEGIN
                           EXEC [KYPEnrollment].[sp_Copy_Organization] @partychildsub_enr,
                                                                       @partychildsub_port,
                                                                       @last_action_user_id;
                        END
                     ELSE
                        BEGIN
                           EXEC [KYPEnrollment].[sp_Copy_Person] @partychildsub_enr,
                                                                 @partychildsub_port,
                                                                 @last_action_user_id,
                                                                 'C';
                        END

                     EXEC [KYPEnrollment].[sp_Copy_Address] @partychildsub_enr,
                                                            @partychildsub_port,
                                                            NULL,
                                                            @last_action_user_id;
                     EXEC [KYPEnrollment].[sp_Copy_Owner_Role] @partychildsub_enr,
                                                               @partychildsub_port,
                                                               @last_action_user_id,
                                                               NULL,
                                                               NULL;

                     --create new party_associate for new child subcontractors

                    

                     --
                     SET @cont1 = @cont1 + 1
                  END

                  TRUNCATE TABLE #childsub
               --delete from #childsub
               --DBCC CHECKIDENT (#childsub , RESEED, 0)
               END

            --**
            SET @cont = @cont + 1
         END
      --end while
      END

   DROP TABLE #childsub
   RETURN @new_party_adr
END


GO

