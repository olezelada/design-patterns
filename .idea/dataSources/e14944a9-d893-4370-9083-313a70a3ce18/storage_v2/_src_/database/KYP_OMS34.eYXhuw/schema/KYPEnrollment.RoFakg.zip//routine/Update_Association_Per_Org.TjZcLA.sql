

/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Update_Association_Per_Org]
	@PartyOwner INT,
	@party_id INT,
	@last_action VARCHAR(1),
	@profId VARCHAR(100)
AS

BEGIN
	DECLARE @mainParty INT, @TypeAssociation VARCHAR(50), @new_Party_Id INT
	
	DECLARE @partyMoca TABLE (ID INT IDENTITY(1,1),PartyID INT)
	 INSERT INTO  @partyMoca SELECT party.PartyID FROM [KYPEnrollment].[pAccount_PDM_Party] party INNER JOIN [KYPEnrollment].[pADM_Account] acc
	 ON party.AccountID = acc.AccountID  INNER JOIN [KYPEnrollment].[pAccount_BizProfile_Details] prof
	 ON acc.AccountID = prof.AccountID AND prof.ProfileID=@profId  WHERE ParentPartyID= @party_id AND (Type='OtherOwnershipIndividual' OR 
	 Type='OtherOwnershipEntity')
	 DECLARE @count_partyMoca_Id INT,@top_PartyMocaId INT, @partyMocaIdUpdate INT, @typeMocaUpdate VARCHAR(20)
	 SELECT @top_PartyMocaId = MAX(ID) FROM @partyMoca; 
	 SET @count_partyMoca_Id = 1
	 WHILE @count_partyMoca_Id <= @top_PartyMocaId
	 BEGIN
		dECLARE @PartyAdverse int, @locationID int, @addresID int, @newAddressID int, @realtion int
		
		select  @PartyAdverse = PartyID from @partyMoca where ID=@count_partyMoca_Id;
		
		select @locationID = loc.LocationID, @addresID = addr.AddressID  from KYPEnrollment.[pAccount_PDM_Party] party inner join [KYPEnrollment].[pAccount_PDM_Location] loc on party.PartyID = loc.PartyID
		inner join [KYPEnrollment].[pAccount_PDM_Address] addr on addr.AddressID = loc.AddressID
		delete from [KYPEnrollment].[pAccount_PDM_AdverseAction] WHERE PartyID=@PartyAdverse
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
			([ParentPartyID],[Type] ,[Name] ,[IsProvider] ,[IsEnrolled] ,[IsTemp] ,[IsActive] ,[LoadType] ,[LoadID] ,[LastLoadDate] ,[DateModified] ,[CurrentRecordFlag]
			,[Source] ,[LastAction] ,[LastActionDate] ,[profile_id],[IsDeleted],[LastActorUserID],[LastActionApprovedBy])
		SELECT @PartyOwner, [Type],[Name],[IsProvider],[IsEnrolled],[IsTemp],[IsActive],[LoadType],[LoadID],[LastLoadDate],[DateModified]
			,1,[Source],@last_action,[DateCreated],[profile_id],[IsDeleted],[LastActorUserID],[LastActorUserID]
			FROM [KYPEnrollment].[pAccount_PDM_Party] WHERE PartyID = @PartyAdverse AND IsDeleted = 0 AND (Type='OtherOwnershipIndividual' OR 
	 Type='OtherOwnershipEntity')
			
		SELECT @new_Party_Id = SCOPE_IDENTITY();
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]	
			([PartyIDOwner],[PartyIDOwned],[DateCreated],[DateModified],[DateDeleted]
           ,[CreatedBy],[ModifiedBy],[DeletedBy],[IsDeleted],[TypeAssociation],[TransDescription]
           ,[FamiliarRelationship],[FamiliarRelationshipOther],[LastAction],[LastActionDate],[LastActorUserID]
           ,[LastActionReason],[LastActionComments],[LastActionApprovedBy],[CurrentRecordFlag],[TempRelationshipID])
		SELECT @PartyOwner,@new_Party_Id,[DateCreated],[DateModified],[DateDeleted]
           ,[CreatedBy],[ModifiedBy],[DeletedBy],[IsDeleted],[TypeAssociation],[TransDescription]
           ,[FamiliarRelationship],[FamiliarRelationshipOther],@last_action,[LastActionDate],[LastActorUserID]
           ,[LastActionReason],[LastActionComments],[LastActionApprovedBy],[CurrentRecordFlag],[TempRelationshipID]
			FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] WHERE PartyIDOwned = @PartyAdverse AND IsDeleted = 0
			
		SELECT @realtion = SCOPE_IDENTITY();

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
           ([PartyID],[LegalName],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionReason]
           ,[LastActionComments],[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,[LegalName],@last_action
           ,[LastActionDate],[LastActorUserID],[LastActionReason]
           ,[LastActionComments],[LastActionApprovedBy],[CurrentRecordFlag] FROM [KYPEnrollment].[pAccount_PDM_Organization] WHERE PartyID=@PartyAdverse
           
                      
       INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           ([PartyID],[FirstName],[LastName],[MiddleName],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,[FirstName],[LastName],[MiddleName],@last_action
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag] FROM [KYPEnrollment].[pAccount_PDM_Person] WHERE PartyID=@PartyAdverse
           
        INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
           ([AddressLine1],[City], [State], [County], [ZipPlus4]
           ,[LastActionDate],[LastActionReason],[LastActionComments]
           ,[CurrentRecordFlag])
		SELECT [AddressLine1],[City], [State], [County], [ZipPlus4]
           ,[LastActionDate],[LastActionReason],[LastActionComments]
           ,[CurrentRecordFlag] FROM [KYPEnrollment].[pAccount_PDM_Address] WHERE AddressID=@addresID
           
        SELECT @newAddressID = SCOPE_IDENTITY();
        
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Location]
           ([PartyID],[AddressID],[Type],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,@newAddressID,[type], @last_action
           ,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag] FROM [KYPEnrollment].[pAccount_PDM_Location] WHERE LocationID=@locationID
           
	  SET @count_partyMoca_Id = @count_partyMoca_Id+1
	 END
END


GO

