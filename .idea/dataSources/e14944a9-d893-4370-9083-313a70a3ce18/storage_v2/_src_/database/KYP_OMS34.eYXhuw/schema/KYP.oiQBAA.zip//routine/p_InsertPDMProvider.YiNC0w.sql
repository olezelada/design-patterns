
/******Script for insert procedure************/
CREATE PROCEDURE [KYP].[p_InsertPDMProvider] (
	@PartyID INT
	,@Category VARCHAR(15) = NULL
	,@Type VARCHAR(50) = NULL
	,@PrimarySpecialty VARCHAR(255) = NULL
	,@SecondSpecialty VARCHAR(150) = NULL
	,@NPI INT = NULL
	,@UPIN VARCHAR(6) = NULL
	,@CCN VARCHAR(6) = NULL
	,@HIN VARCHAR(9) = NULL
	,@Remarks VARCHAR(250) = NULL
	,@IsEnrolled BIT = 1
	,@ProvNumber VARCHAR(20) = NULL
	,@CurrentModule INT = NULL
	,@Mon_MedicaidID VARCHAR(20) = NULL
	,@EnrolledSince DATETIME = NULL
	,@CreatedBy INT = NULL
	,@DateCreated DATETIME = NULL
	,@ModifiedBy INT = NULL
	,@DateModified DATETIME = NULL
	,@DeletedBy INT = NULL
	,@DateDeleted DATETIME = NULL
	,@IsDeleted BIT = 0
	,@DEA VARCHAR(20) = NULL
	,@NABPNum VARCHAR(15) = NULL
	,@CLIA VARCHAR(10) = NULL
	,@AccGenNumber VARCHAR(50) = NULL
	)
AS
BEGIN
	INSERT INTO [KYP].[PDM_Provider] (
		[PartyID]
		,[Category]
		,[Type]
		,[PrimarySpecialty]
		,[SecondSpecialty]
		,[NPI]
		,[UPIN]
		,[CCN]
		,[HIN]
		,[Remarks]
		,[IsEnrolled]
		,[ProvNumber]
		,[CurrentModule]
		,[Mon_MedicaidID]
		,[EnrolledSince]
		,[CreatedBy]
		,[DateCreated]
		,[ModifiedBy]
		,[DateModified]
		,[DeletedBy]
		,[DateDeleted]
		,[IsDeleted]
		,[DEA]
		,[CLIA]
		,[NABP_Num]
		,[AccGenNumber]
		)
	VALUES (
		@PartyID
		,@Category
		,@Type
		,@PrimarySpecialty
		,@SecondSpecialty
		,@NPI
		,@UPIN
		,@CCN
		,@HIN
		,@Remarks
		,@IsEnrolled
		,@ProvNumber
		,@CurrentModule
		,@Mon_MedicaidID
		,@EnrolledSince
		,@CreatedBy
		,@DateCreated
		,@ModifiedBy
		,@DateModified
		,@DeletedBy
		,@DateDeleted
		,@IsDeleted
		,@DEA
		,@CLIA
		,@NABPNum
		,@AccGenNumber
		)

	RETURN IDENT_CURRENT('[KYP].[PDM_Provider]')
END


GO

