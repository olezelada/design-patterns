
CREATE TRIGGER [KYP].[UpdateUserDetails] 
   ON  [KYP].[OIS_User]
   AFTER Update
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF @Row_Updation_Source = 'dbo.ANNOTATIONSTABLE.CreateUserDetails' AND Update(Row_Updation_Source) 
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	 
	IF @Row_Updation_Source = 'dbo.UserTable.InsertUsers' AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END	

	IF @Row_Updation_Source = 'dbo.UserTable.DeleteUsers' AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END	
	
    -- Insert statements for trigger here
	DECLARE @userID VARCHAR(100),
			@emailID VARCHAR(100),
			@fullName VARCHAR(100),
			@personID INT
			
	--SET @userID = (SELECT UserID FROM inserted);
	--SET @emailID = (SELECT EmailID FROM inserted);
	--SET @fullName = (SELECT FullName FROM inserted);
	--SET @personID = (SELECT PersonID FROM inserted);
	
	SELECT @userID = UserID FROM inserted
	SELECT @emailID = EmailID FROM inserted
	SELECT @fullName = FullName FROM inserted
	SELECT @personID = PersonID FROM inserted	
	
	
	--ALTER TABLE [dbo].[ANNOTATIONSTABLE] DISABLE TRIGGER CreateUserDetails;
	
	IF UPDATE(EmailID)
	BEGIN
		UPDATE	[dbo].[ANNOTATIONSTABLE] SET [dbo].[ANNOTATIONSTABLE].[ANNOTATION_VALUE] = @emailID 
		WHERE	[dbo].[ANNOTATIONSTABLE].[USER_NAME] = @userID AND [dbo].[ANNOTATIONSTABLE].[ANNOTATION_NAME] = 'mail'
	END
	
	IF UPDATE(FullName)
	BEGIN
		UPDATE	[KYP].[MDM_Alert] SET [KYP].[MDM_Alert].[Assignee] = @fullName 
		WHERE	[KYP].[MDM_Alert].[AssignedToUserID] = @personID
	END
	
	--ALTER TABLE [dbo].[ANNOTATIONSTABLE] ENABLE TRIGGER CreateUserDetails;
END


GO

