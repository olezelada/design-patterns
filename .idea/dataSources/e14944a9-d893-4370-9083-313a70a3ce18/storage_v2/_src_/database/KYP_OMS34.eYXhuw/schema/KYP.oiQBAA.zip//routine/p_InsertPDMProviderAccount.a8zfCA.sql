
CREATE PROCEDURE [KYP].[p_InsertPDMProviderAccount] (
	@AccountNumber VARCHAR(15) = NULL
	,@ProviderName VARCHAR(150) = NULL
	,@NPI INT = NULL
	,@PracticeAddress1 VARCHAR(250) = NULL
	,@PracticeAddress2 VARCHAR(250) = NULL
	,@City VARCHAR(25) = NULL
	,@State VARCHAR(25) = NULL
	,@Zip VARCHAR(5) = NULL
	,@ProviderStatus VARCHAR(50) = NULL
	,@ProfileID INT
	,@DateCreated DATETIME = NULL
	,@DateDeleted DATETIME = NULL
	,@IsDeleted BIT = 0
	,@Specialty VARCHAR(225) = NULL
	,@SSN VARCHAR(11) = NULL
	,@TIN VARCHAR(11) = NULL
	,@AccGenNumber VARCHAR(50) = NULL
	,@ProviderType VARCHAR(200) = NULL
	,@DBAName VARCHAR(200) = NULL
	,@DEA VARCHAR(20) = NULL
	,@DOB DATETIME = NULL
	,@CLIA VARCHAR(20) = NULL
	,@PhoneNumber VARCHAR(15) = NULL
	,@Account_Practice_Type varchar(500)=null
	)
AS
BEGIN
	INSERT INTO [KYP].[PDM_ProviderAccount] (
		[AccountNumber]
		,[ProviderName]
		,[NPI]
		,[PracticeAddress1]
		,[PracticeAddress2]
		,[City]
		,[State]
		,[Zip]
		,[ProviderStatus]
		,[ProfileID]
		,[DateCreated]
		,[DateDeleted]
		,[IsDeleted]
		,[PrimarySpecialty]
		,[SSN]
		,[TIN]
		,[AccGenNumber]
		,[ProviderType]
		,[DBAName]
		,[DEA]
		,[DOB]
		,[CLIA]
		,[PhoneNumber]
		,[PracticeType]
		)
	VALUES (
		@AccountNumber
		,@ProviderName
		,@NPI
		,@PracticeAddress1
		,@PracticeAddress2
		,@City
		,@State
		,@Zip
		,@ProviderStatus
		,@ProfileID
		,@DateCreated
		,@DateDeleted
		,@IsDeleted
		,@Specialty
		,@SSN
		,@TIN
		,@AccGenNumber
		,@ProviderType
		,@DBAName
		,@DEA
		,@DOB
		,@CLIA
		,@PhoneNumber
		,@Account_Practice_Type
		)

	RETURN IDENT_CURRENT('[KYP].[PDM_ProviderAccount]')
END


GO

