
CREATE PROCEDURE [KYP].[p_UpdatePDMAccount] (
	@AccountNumber VARCHAR(15) = NULL
	,@ProviderName VARCHAR(150) = NULL
	,@NPI INT = NULL
	,@PracticeAddress1 VARCHAR(250) = NULL
	,@PracticeAddress2 VARCHAR(250) = NULL
	,@City VARCHAR(25) = NULL
	,@State VARCHAR(25) = NULL
	,@Zip VARCHAR(5) = NULL
	,@ProviderStatus VARCHAR(50) = NULL
	,@ProfileID INT
	,@DateCreated DATETIME = NULL
	,@DateDeleted DATETIME = NULL
	,@IsDeleted BIT = 1
	,@Specialty VARCHAR(225) = NULL
	,@SSN VARCHAR(11) = NULL
	,@TIN VARCHAR(11) = NULL
	,@AccGenNumber VARCHAR(50) = NULL
	,@ProviderType VARCHAR(200) = NULL
	,@DBAName VARCHAR(200) = NULL
	,@DEA VARCHAR(20) = NULL
	,@DOB DATETIME = NULL
	,@CLIA VARCHAR(20) = NULL
	,@PhoneNumber VARCHAR(15) = NULL
	,@Account_Practice_Type VARCHAR(500) = NULL
	)
AS
BEGIN
	SET NOCOUNT ON

	/* Variable Declaration */
	DECLARE @SQLQuery AS NVARCHAR(4000)
	DECLARE @updatelist AS NVARCHAR(4000)
	DECLARE @filter AS VARCHAR(100)

	SET @SQLQuery = 'Update [KYP].[PDM_ProviderAccount] Set '

	IF @AccountNumber IS NOT NULL
		SET @updatelist = '[AccountNumber] = ''' + @AccountNumber + ''''

	IF @AccGenNumber IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ' ,[AccGenNumber] = ''' + @AccGenNumber + ''''
		ELSE
			SET @updatelist = '[AccGenNumber] = ''' + @AccGenNumber + ''''
	END

	IF @ProviderName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProviderName] = ''' + CONVERT(VARCHAR(150), @ProviderName, 121) + ''''
		ELSE
			SET @updatelist = '[ProviderName] = ''' + CONVERT(VARCHAR(150), @ProviderName, 121) + ''''
	END

	IF @NPI IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[NPI] = ''' + CONVERT(VARCHAR(10), @NPI) + ''''
		ELSE
			SET @updatelist = '[NPI] = ''' + CONVERT(VARCHAR(10), @NPI) + ''''
	END

	IF @PracticeAddress1 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PracticeAddress1] = ''' + CONVERT(VARCHAR(250), @PracticeAddress1, 121) + ''''
		ELSE
			SET @updatelist = '[PracticeAddress1] = ''' + CONVERT(VARCHAR(250), @PracticeAddress1, 121) + ''''
	END

	IF @PracticeAddress2 IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PracticeAddress2] = ''' + CONVERT(VARCHAR(250), @PracticeAddress2, 121) + ''''
		ELSE
			SET @updatelist = '[PracticeAddress2] = ''' + CONVERT(VARCHAR(250), @PracticeAddress2, 121) + ''''
	END

	IF @City IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[City] = ''' + CONVERT(VARCHAR(25), @City, 121) + ''''
		ELSE
			SET @updatelist = '[City] = ''' + CONVERT(VARCHAR(25), @City, 121) + ''''
	END

	IF @State IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[State] = ''' + CONVERT(VARCHAR(25), @State, 121) + ''''
		ELSE
			SET @updatelist = '[State] = ''' + CONVERT(VARCHAR(25), @State, 121) + ''''
	END

	IF @Zip IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[Zip] = ''' + CONVERT(VARCHAR(5), @Zip, 121) + ''''
		ELSE
			SET @updatelist = '[Zip] = ''' + CONVERT(VARCHAR(5), @Zip, 121) + ''''
	END

	IF @ProviderStatus IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProviderStatus] = ''' + CONVERT(VARCHAR(50), @ProviderStatus, 121) + ''''
		ELSE
			SET @updatelist = '[ProviderStatus] = ''' + CONVERT(VARCHAR(50), @ProviderStatus, 121) + ''''
	END

	IF @ProfileID IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProfileID] = ' + CONVERT(VARCHAR(10), @ProfileID)
		ELSE
			SET @updatelist = '[ProfileID] = ' + CONVERT(VARCHAR(10), @ProfileID)
	END

	IF @DateCreated IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateCreated] = ''' + CONVERT(VARCHAR(25), @DateCreated) + ''''
		ELSE
			SET @updatelist = '[DateCreated] = ''' + CONVERT(VARCHAR(25), @DateCreated) + ''''
	END

	IF @DateDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DateDeleted] = ''' + CONVERT(VARCHAR(25), @DateDeleted) + ''''
		ELSE
			SET @updatelist = '[DateDeleted] = ''' + CONVERT(VARCHAR(25), @DateDeleted) + ''''
	END

	IF @IsDeleted IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
		ELSE
			SET @updatelist = '[IsDeleted] = ' + CAST(@IsDeleted AS VARCHAR(1)) + ''
	END

	IF @Specialty IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PrimarySpecialty] = ''' + CAST(@Specialty AS VARCHAR(225)) + ''''
		ELSE
			SET @updatelist = '[PrimarySpecialty] = ''' + CAST(@Specialty AS VARCHAR(225)) + ''''
	END

	IF @SSN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[SSN] = ''' + CAST(@SSN AS VARCHAR(11)) + ''''
		ELSE
			SET @updatelist = '[SSN] = ''' + CAST(@SSN AS VARCHAR(11)) + ''''
	END

	IF @TIN IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[TIN] = ''' + CAST(@TIN AS VARCHAR(11)) + ''''
		ELSE
			SET @updatelist = '[TIN] = ''' + CAST(@TIN AS VARCHAR(11)) + ''''
	END

	IF @ProviderType IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[ProviderType] = ''' + CAST(@ProviderType AS VARCHAR(200)) + ''''
		ELSE
			SET @updatelist = '[ProviderType] = ''' + CAST(@ProviderType AS VARCHAR(200)) + ''''
	END

	IF @DBAName IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DBAName] = ''' + CAST(@DBAName AS VARCHAR(200)) + ''''
		ELSE
			SET @updatelist = '[DBAName] = ''' + CAST(@DBAName AS VARCHAR(200)) + ''''
	END

	IF @DEA IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DEA] = ''' + CAST(@DEA AS VARCHAR(20)) + ''''
		ELSE
			SET @updatelist = '[DEA] = ''' + CAST(@DEA AS VARCHAR(20)) + ''''
	END

	IF @DOB IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[DOB] = ''' + CONVERT(VARCHAR(25), @DOB) + ''''
		ELSE
			SET @updatelist = '[DOB] = ''' + CONVERT(VARCHAR(25), @DOB) + ''''
	END

	IF @CLIA IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[CLIA] = ''' + CAST(@CLIA AS VARCHAR(20)) + ''''
		ELSE
			SET @updatelist = '[CLIA] = ''' + CAST(@CLIA AS VARCHAR(20)) + ''''
	END

	IF @PhoneNumber IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PhoneNumber] = ''' + CAST(@PhoneNumber AS VARCHAR(15)) + ''''
		ELSE
			SET @updatelist = '[PhoneNumber] = ''' + CAST(@PhoneNumber AS VARCHAR(15)) + ''''
	END

	IF @Account_Practice_Type IS NOT NULL
	BEGIN
		IF @updatelist IS NOT NULL
			SET @updatelist = @updatelist + ',[PracticeType] = ''' + CAST(@Account_Practice_Type AS VARCHAR(500)) + ''''
		ELSE
			SET @updatelist = '[PracticeType] = ''' + CAST(@Account_Practice_Type AS VARCHAR(15)) + ''''
	END

	SET @filter = ' where AccountNumber=''' + Convert(VARCHAR(15), @AccountNumber) + ''''
	SET @SQLQuery = @SQLQuery + @updatelist + @filter + ' AND AccGenNumber = ''' + Convert(VARCHAR(50), @AccGenNumber) + ''''

	--print @SQLQuery
	EXECUTE sp_Executesql @SQLQuery
END


GO

