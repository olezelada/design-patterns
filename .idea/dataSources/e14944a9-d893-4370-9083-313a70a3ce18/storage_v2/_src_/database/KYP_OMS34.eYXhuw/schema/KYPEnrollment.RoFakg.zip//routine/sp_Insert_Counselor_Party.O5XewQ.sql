
-- =============================================
-- Author:		<DH>
-- Create date: <17/01/2019>
-- Description:	<insert new Counselor for update account>
-- @counselor_party_Id : PartyID of the counselor
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Insert_Counselor_Party]
	@counselor_party_Id INT,
	@new_Party_Id INT,
	@account_id INT,
	@last_action_user_id VARCHAR(100)

AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @new_person int, @new_party_counselor int;

	IF EXISTS (SELECT PartyID FROM KYPPORTAL.PortalKYP.pPDM_Party where PartyID=@counselor_party_Id  and Type = 'Counselor')
	BEGIN

			EXEC @new_party_counselor = [KYPEnrollment].[sp_Copy_Party_Counselor] 	@counselor_party_Id,	@new_Party_Id,	@account_id,	@last_action_user_id;
			
			EXEC @new_person = [KYPEnrollment].sp_Copy_Person @new_party_counselor,@counselor_party_Id,@last_action_user_id;
			
			EXEC [KYPEnrollment].sp_Copy_AllOtherNames 	@counselor_party_Id,@last_action_user_id,@new_party_counselor;
			
			EXEC [KYPEnrollment].[sp_Copy_Provider] @new_party_counselor,@counselor_party_Id,@last_action_user_id;
			
			EXEC [KYPEnrollment].[sp_Copy_Number]	@new_party_counselor,	@counselor_party_Id,	@last_action_user_id,	null;

			EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @account_id, @counselor_party_Id, @new_party_counselor
		
	END
	
END
GO

