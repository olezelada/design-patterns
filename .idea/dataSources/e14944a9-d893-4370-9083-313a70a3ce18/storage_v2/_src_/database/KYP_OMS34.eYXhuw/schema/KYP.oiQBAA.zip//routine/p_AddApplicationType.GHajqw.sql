
-- =============================================
-- Author:		<Amita Karan>
-- Create date: <17/09/2014>
-- Description:	<Added a new column Application Type to maintain the provider profile history, NEW, MOCA Change, Data Update are the new Application type>
-- =============================================
CREATE PROCEDURE [KYP].[p_AddApplicationType]
	-- Add the parameters for the stored procedure here
	@SSN_NUM INT
	,@FullName_incoming VARCHAR(200)
AS
DECLARE @existingSSN VARCHAR(9)
	,@FullName VARCHAR(200)
	,@cursorSSN CURSOR

BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--if  @PDM_CaseID =-1
	SELECT C.SSN
	FROM KYP.PDM_Person C
	INNER JOIN kyp.PDM_Owner B ON C.PartyID = B.PartyID

	OPEN @cursorSSN

	FETCH NEXT
	FROM @cursorSSN
	INTO @existingSSN

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SSN_NUM = @existingSSN
			RETURN - 1
	END

	CLOSE @cursorSSN

	SELECT C.FirstName + ' ' + C.LastName
	FROM KYP.PDM_Person C
	INNER JOIN kyp.PDM_Owner B ON C.PartyID = B.PartyID

	OPEN @cursorSSN

	FETCH NEXT
	FROM @cursorSSN
	INTO @FullName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @FullName_incoming = @FullName
			RETURN - 1
	END

	CLOSE @cursorSSN

	-- Insert statements for procedure here	
	--Check for Employee data
	SELECT C.SSN
	FROM KYP.PDM_Person C
	INNER JOIN kyp.PDM_Employee B ON C.PartyID = B.PartyID

	OPEN @cursorSSN

	FETCH NEXT
	FROM @cursorSSN
	INTO @existingSSN

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @SSN_NUM = @existingSSN
			RETURN - 1
	END

	CLOSE @cursorSSN

	SELECT C.FirstName + ' ' + C.LastName
	FROM KYP.PDM_Person C
	INNER JOIN kyp.PDM_Employee B ON C.PartyID = B.PartyID

	OPEN @cursorSSN

	FETCH NEXT
	FROM @cursorSSN
	INTO @FullName

	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF @FullName_incoming = @FullName
			RETURN - 1
	END

	CLOSE @cursorSSN
END


GO

