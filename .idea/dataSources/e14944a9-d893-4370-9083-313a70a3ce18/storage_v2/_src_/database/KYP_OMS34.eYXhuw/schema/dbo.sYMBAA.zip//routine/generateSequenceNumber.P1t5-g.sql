
CREATE PROCEDURE [dbo].[generateSequenceNumber] 
	-- Add the parameters for the stored procedure here
	--@customSeqnumber int,
	@PANo varchar(10) output	
AS
DECLARE @customSeqnumber int,
		@natNum int,
		@check bit,
		@checkCaseCount int,
		@checkProviderCount int,
		@NPIProfile int,
		@NPIAccount int,
		@now datetime
BEGIN		
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	
	SET NOCOUNT ON;
	SET @natNum = 1
	SET @check=1
	WHILE(@check = 1)
		BEGIN	
		SET  @customSeqnumber = @natNum		
			select @PANo = 
				(char(@customSeqnumber / 260000 % 26 + 65) + 	
				char(@customSeqnumber/ 260000 % 26 + 65) + 
				char(@customSeqnumber / 26000 % 26 + 65) + 
				char(@customSeqnumber / 1000 % 26 + 65) + 
				char(@customSeqnumber / 100 % 10 + 48) + 
				char(@customSeqnumber / 10 % 10 + 48) + 
				char(@customSeqnumber % 10 + 48))
				
				SELECT @checkCaseCount = COUNT(1) FROM KYP.ADM_Case WHERE PAN = @PANo
				--SELECT @checkProviderCount = COUNT(1) FROM KYP.PDM_ProviderProfile WHERE PAN = @PANo
				IF @checkCaseCount = 0 -- and (@checkProviderCount=0))
					BEGIN 
						SET @check=0;						
					END		
				ELSE
					BEGIN
						SET @check=1;
						SET @natNum = @natNum+1;
					END	
			END	
END


GO

