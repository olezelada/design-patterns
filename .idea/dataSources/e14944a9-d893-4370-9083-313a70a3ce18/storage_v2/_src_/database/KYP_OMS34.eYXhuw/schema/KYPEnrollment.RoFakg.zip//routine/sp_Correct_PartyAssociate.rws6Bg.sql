

CREATE PROCEDURE [KYPEnrollment].[sp_Correct_PartyAssociate]
	@Taxid varchar(10),
	@profileid varchar(40)
	
AS
BEGIN
select type,moca,partyid  into #mains from
(
select  ROW_NUMBER() OVER(PARTITION BY type,moca ORDER BY type,moca ASC,accountid asc) 
    AS num, * from
 (select asoc.*,isnull(convert(varchar(200),per.ssn),isnull(convert(varchar(200),org.ein),isnull(convert(varchar(200),legalname),isnull(per.lastname,'')+isnull(per.firstname,'')))) as moca from kypenrollment.paccount_taxid_associate tax 
inner join kypenrollment.pAccount_BizProfile_Details prof on tax.accountid=prof.accountid 
inner join kypenrollment.paccount_party_associate asoc on tax.accountid=asoc.accountid
inner join kypenrollment.paccount_pdm_party part on asoc.partyid=part.partyid
left join kypenrollment.paccount_pdm_person per on asoc.partyid=per.partyid
left join kypenrollment.paccount_pdm_organization org on asoc.partyid=org.partyid
where tax.taxid=@taxid and profileid=@profileid and tax.CurrentRecordFlag=1 and part.currentrecordflag=1 ) deta) aux
where num=1

update asoc set mainpartyid=ma.partyid 
--select * from
--select asoc.*,isnull(convert(varchar(200),per.ssn),isnull(convert(varchar(200),org.ein),isnull(convert(varchar(200),legalname),isnull(per.lastname,'')+isnull(per.firstname,'')))) as moca 
from kypenrollment.paccount_taxid_associate tax 
inner join kypenrollment.pAccount_BizProfile_Details prof on tax.accountid=prof.accountid 
inner join kypenrollment.paccount_party_associate asoc on tax.accountid=asoc.accountid
inner join kypenrollment.paccount_pdm_party part on asoc.partyid=part.partyid
left join kypenrollment.paccount_pdm_person per on asoc.partyid=per.partyid
left join kypenrollment.paccount_pdm_organization org on asoc.partyid=org.partyid
inner join #mains ma on part.type=ma.type and 
isnull(convert(varchar(200),per.ssn),isnull(convert(varchar(200),org.ein),isnull(convert(varchar(200),legalname),isnull(per.lastname,'')+isnull(per.firstname,''))))=ma.moca 

where tax.taxid=@taxid and profileid=@profileid and tax.CurrentRecordFlag=1 and part.currentrecordflag=1 

drop table #mains


END


GO

