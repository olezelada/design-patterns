
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: Choose Table by Update.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @table_code : Type of Table.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User.
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- @acc_table_name : Table Name to contain field that will be update.
-- @entity_id : MasterPartyID to Ownership Application.
-- @stored_value : input Type that be Update.
-- @account_id : AccountID that will be update.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Account_Table]
   @acc_party_id           INT,
   @table_code             VARCHAR (20),
   @action_taken           VARCHAR (50),
   @last_action_user_id    VARCHAR (100),
   @target_path            VARCHAR (200),
   @en_db_column           VARCHAR (100),
   @data                   VARCHAR (MAX),
   @acc_PK                 VARCHAR (100),
   @acc_PK_value           INT,
   @is_text_date           CHAR (1),
   @acc_table_name         VARCHAR (100),
   @entity_id              INT,
   @stored_value           VARCHAR (MAX),
   @account_id             INT,
   @new_fields_values      VARCHAR (MAX) = NULL,
   @row_uuid               VARCHAR (100) = NULL,
   @application_id         INT = NULL,
   @app_party_id           INT,
   @application_Code        VARCHAR(50)
AS
BEGIN
   IF @table_code = 'otherNames'
      BEGIN
         PRINT @table_code
         EXEC [KYPEnrollment].[sp_Update_Person_OtherName] @acc_party_id,
                                                           @action_taken,
                                                           @last_action_user_id,
                                                           @target_path,
                                                           @en_db_column,
                                                           @data,
                                                           @acc_PK,
                                                           @acc_PK_value,
                                                           @is_text_date;
      END

   IF @table_code = 'businessPermits' OR @table_code = 'profLicCertif'
      BEGIN
         PRINT @table_code
         EXEC [KYPEnrollment].[sp_Update_Number] @acc_party_id,
                                                 @action_taken,
                                                 @last_action_user_id,
                                                 @target_path,
                                                 @en_db_column,
                                                 @data,
                                                 @acc_PK,
                                                 @acc_PK_value,
                                                 @is_text_date,
                                                 @app_party_id,
                                                 @table_code;
      END

   IF @table_code = 'specialty' OR @table_code = 'taxonomy'
      BEGIN
         PRINT @table_code
         EXEC [KYPEnrollment].[sp_Update_Speciality] @acc_party_id,
                                                     @action_taken,
                                                     @last_action_user_id,
                                                     @target_path,
                                                     @en_db_column,
                                                     @data,
                                                     @acc_PK,
                                                     @acc_PK_value,
                                                     @is_text_date;
      END

    IF @table_code = 'peerCoach' AND @application_Code NOT IN ('F_THS_OE', 'F_THS_SP')
    BEGIN
      PRINT @table_code
      EXEC [KYPEnrollment].[sp_Update_Peer_Coach] @acc_party_id
                                                  ,	@action_taken
                                                  ,	@last_action_user_id
                                                  ,	@target_path
                                                  ,	@en_db_column
                                                  ,	@data
                                                  , @acc_PK
                                                  , @acc_PK_value
                                                  ,	@is_text_date
                                                  , @acc_table_name
                                                  , @application_id
                                                  , @app_party_id;

    END

   --ownerSubAssocTable owner---subcont before
   --entitySubTable     owner---subcont entity now
   --assoSubIndTable    owner---subcont indiv now
   --assoSubOwnerTable  owner---subcont owner sub now
   --individualSubTable owner---owner before-now
   --otherAssocTable    owner---other individual before-now
   --otherEntAssocTable owner---other entity before-now

   IF    @table_code = 'ownerSubAssocTable'
      OR @table_code = 'individualSubTable'
      OR @table_code = 'entitySubTable'
      OR @table_code = 'assoSubIndTable'
      OR @table_code = 'assoSubOwnerTable'
      BEGIN
         EXEC [KYPEnrollment].[sp_Update_Subcontractor_Indivisual_Assoc] @entity_id,
                                                                         @action_taken,
                                                                         @last_action_user_id,
                                                                         @target_path,
                                                                         @en_db_column,
                                                                         @data,
                                                                         @acc_PK,
                                                                         @acc_PK_value,
                                                                         @is_text_date,
                                                                         @acc_table_name,
                                                                         @stored_value;
      END

   IF     @table_code != 'otherNames'
      AND @table_code != 'businessPermits'
      AND @table_code != 'profLicCertif'
      AND @table_code != 'specialty'
      AND @table_code != 'taxonomy'
      AND @table_code != 'individualSubTable'
      AND @table_code != 'ownerSubAssocTable'
      AND @table_code != 'convictedTable'
      AND @table_code != 'liableTable'
      AND @table_code != 'settlementTable'
      AND @table_code != 'licenseActions'
      AND @table_code != 'ownerCorpoTable'
      AND @table_code != 'suspensionRevokedPh'
      AND @table_code != 'disciplineHearingPh'
      AND @table_code != 'licenseAuthorityPh'
      AND @table_code != 'isThisTechnician'
      AND @table_code != 'imagingAddressTable'
      AND @table_code != 'imagingAddrNoDocTab'
      AND @table_code != 'additionalLocations'
      AND @table_code != 'supervisingPhysTable'
      AND @table_code != 'rays'
      AND @table_code != 'others'
      BEGIN
         --new table 'subOwnerTable'
         IF    @entity_id IS NULL
            OR (   @table_code = 'subcontractorTable'
                OR @table_code = 'ownerTable'
                OR @table_code = 'subOwnerTable'
                OR @table_code = 'whollySuppliersTable'
                OR @table_code = 'significantSubTable')
            BEGIN
               EXEC [KYPEnrollment].[sp_Update_All_New_Party_Tables] @acc_party_id,
                                                                     @action_taken,
                                                                     @last_action_user_id,
                                                                     @target_path,
                                                                     @en_db_column,
                                                                     @data,
                                                                     @acc_PK,
                                                                     @acc_PK_value,
                                                                     @is_text_date,
                                                                     @acc_table_name,
                                                                     @table_code,
                                                                     @stored_value,
                                                                     @account_id,
                                                                     @new_fields_values,
                                                                     @row_uuid;
            END
         ELSE
            --for tablecode otherAssocTable / otherEntAssocTable entity_id has that be<>null
            BEGIN
               EXEC [KYPEnrollment].[sp_Update_All_New_Party_Tables] @entity_id,
                                                                     @action_taken,
                                                                     @last_action_user_id,
                                                                     @target_path,
                                                                     @en_db_column,
                                                                     @data,
                                                                     @acc_PK,
                                                                     @acc_PK_value,
                                                                     @is_text_date,
                                                                     @acc_table_name,
                                                                     @table_code,
                                                                     @stored_value,
                                                                     @account_id,
                                                                     @new_fields_values,
                                                                     @row_uuid;
            END
      END

   -- IF (@table_code='convictedTable' OR @table_code='liableTable' OR @table_code='settlementTable' OR @table_code='licenseActions') AND NOT EXISTS(SELECT FiledID FROM #Control_Add_row WHERE FiledID=(SELECT TOP 1 PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction] WHERE TargetPath = @target_path) AND NameTable='pAccount_PDM_Party')
   -- Added tablesCode for MD.
   IF     (   @table_code = 'convictedTable'
           OR @table_code = 'liableTable'
           OR @table_code = 'settlementTable'
           OR @table_code = 'licenseActions'
           OR @table_code = 'surrenderedTable'
           OR @table_code = 'pendingTable'           
		   OR @table_code = 'pendingTable'
           OR @table_code = 'suspensionRevokedPh'
           OR @table_code = 'disciplineHearingPh'
           OR @table_code = 'licenseAuthorityPh')
      AND NOT EXISTS
             (SELECT FiledID
                FROM #Control_Add_row
               WHERE     FiledID =
                            (SELECT TOP 1
                                    PartyID
                               FROM [KYPPORTAL].[PortalKYP].[pPDM_AdverseAction]
                              WHERE TargetPath = @target_path)
                     AND NameTable = 'pAccount_PDM_Party')
      BEGIN
         PRINT @table_code

         IF @entity_id IS NULL
            BEGIN
               EXEC [KYPEnrollment].[sp_Update_Adverse_Action] @acc_party_id,
                                                               @action_taken,
                                                               @last_action_user_id,
                                                               @target_path,
                                                               @en_db_column,
                                                               @data,
                                                               @acc_PK,
                                                               @acc_PK_value,
                                                               @is_text_date,
                                                               @app_party_id;
            END
         ELSE
            BEGIN
               EXEC [KYPEnrollment].[sp_Update_Adverse_Action] @entity_id,
                                                               @action_taken,
                                                               @last_action_user_id,
                                                               @target_path,
                                                               @en_db_column,
                                                               @data,
                                                               @acc_PK,
                                                               @acc_PK_value,
                                                               @is_text_date;
            END
      END

   IF @table_code = 'finesDebtsTable'
      BEGIN
         PRINT @table_code
         EXEC [KYPEnrollment].[sp_Update_Fines_Debts] @acc_party_id,
                                                      @action_taken,
                                                      @last_action_user_id,
                                                      @target_path,
                                                      @en_db_column,
                                                      @data,
                                                      @acc_PK,
                                                      @acc_PK_value,
                                                      @is_text_date;
      END

   --IF @table_code='ownerCorpoTable' AND (SELECT COUNT(FiledID)FROM[KYPEnrollment].[Control_Add_row] WHERE FiledID=(SELECT TOP 1 PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] WHERE TargetPath = @target_path) AND NameTable='pAccount_PDM_Party')=0
   IF     @table_code = 'ownerCorpoTable'
      AND NOT EXISTS
             (SELECT FILEDID
                FROM #Control_Add_row
               WHERE     FiledID =
                            (SELECT TOP 1
                                    PartyID
                               FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]
                              WHERE TargetPath = @target_path)
                     AND NameTable = 'pAccount_PDM_Party')
      BEGIN
         PRINT @table_code;
         EXEC [KYPEnrollment].[sp_Update_Address_Owner] @entity_id,
                                                        @action_taken,
                                                        @last_action_user_id,
                                                        @target_path,
                                                        @en_db_column,
                                                        @data,
                                                        @acc_PK,
                                                        @acc_PK_value,
                                                        @is_text_date;
      END

   -- Update Dea for MD.
   IF @table_code = 'deaTable'
      BEGIN
         PRINT @table_code
         EXEC [KYPEnrollment].[sp_Update_Dea] @acc_party_id,
                                              @action_taken,
                                              @last_action_user_id,
                                              @target_path,
                                              @en_db_column,
                                              @data,
                                              @acc_PK,
                                              @acc_PK_value,
                                              @is_text_date;
      END

  IF @table_code in ('modalities','modResAddress')
    BEGIN
	    PRINT @table_code
    	EXEC [KYPEnrollment].[sp_Update_Modalities]		@acc_party_id,	@action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date,@acc_table_name ;
    END

  IF @table_code='counselors'
    BEGIN
	    PRINT @table_code
    	EXEC [KYPEnrollment].[sp_Update_Counselors]		@acc_party_id,	@action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date,@acc_table_name;
    END

  IF @table_code='counAlias'
      BEGIN
        PRINT @table_code
        EXEC [KYPEnrollment].[sp_Update_Counselors_Alias] @acc_party_id, @action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date,@acc_table_name;
      END

  IF @table_code IN ('vanDrivers','pilots','ambulanceDrivers','driversNMT')
    BEGIN
	    PRINT @table_code
    	EXEC [KYPEnrollment].[sp_Update_Operators]		@acc_party_id,	@action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date, @acc_table_name, @application_id;
    END

  IF @table_code IN ('ambulances','aircraft','litterWheelchairVan','nonMedicalVehicles')
    BEGIN
	    PRINT @table_code
    	EXEC [KYPEnrollment].[sp_Update_Vehicles]		@acc_party_id,	@action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date, @acc_table_name, @application_id;
    END


  IF @table_code IN ('geoLocAddress','geoLocAddressNoDoc')	
	BEGIN
		EXEC [KYPEnrollment].[sp_Update_GeoLocations] @acc_party_id,
													  @action_taken,
													  @last_action_user_id,
													  @target_path,
													  @en_db_column, 
													  @data, 
													  @acc_PK, 
													  @acc_PK_value,
													  @is_text_date,
		  											  @acc_table_name
		  											  
	END	
	
	-- Location Stock Pharmacy, DME	
	 IF @table_code='isLocationStock'
		BEGIN
			PRINT @table_code
				EXEC [KYPEnrollment].[sp_Update_Location_Stock_Table] @acc_party_id,	@action_taken,	@last_action_user_id,	@target_path,	@en_db_column,	@data, 	@acc_PK, @acc_PK_value,	@is_text_date,@account_id,  @acc_table_name;
    		  
		END

    IF @table_code IN('isThisTechnician')
		BEGIN
			PRINT 'Running Table: isThisTechnician... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_Table_Technicians]  @acc_party_id, @action_taken, @last_action_user_id, @target_path,
			                                                    @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,
			                                                    @acc_table_name, @table_code, @stored_value, @account_id,
			                                                    @new_fields_values, @row_uuid;
      PRINT 'END Running isThisTechnician';
		END

		IF @table_code IN('imagingAddressTable', 'imagingAddrNoDocTab')
		BEGIN
			PRINT 'Running Table: ' + @table_code + '... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_Table_OtherAddressLocation] @acc_party_id, @action_taken, @last_action_user_id,
			                                                            @target_path, @en_db_column, @data, @acc_PK, @acc_PK_value,
			                                                            @is_text_date, @acc_table_name, @table_code, @stored_value,
			                                                            @account_id, @new_fields_values, @row_uuid;
      PRINT 'END Running ' + @table_code;
		END

		IF @table_code IN('additionalLocations')
		BEGIN
			PRINT 'Running Table: ' + @table_code + '... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_dpp_AdditionalAddressLocation] @acc_party_id, @action_taken, @last_action_user_id,
			                                                            @target_path, @en_db_column, @data, @acc_PK, @acc_PK_value,
			                                                            @is_text_date, @acc_table_name, @table_code, @stored_value,
			                                                            @account_id, @new_fields_values, @row_uuid;
      PRINT 'END Running ' + @table_code;
		END

		IF @table_code IN('supervisingPhysTable')
		BEGIN
			PRINT 'Running Table: supervisingPhysTable... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_Table_SupervisingPhysician] @acc_party_id, @action_taken, @last_action_user_id,
			                                                            @target_path, @en_db_column, @data, @acc_PK, @acc_PK_value,
			                                                            @is_text_date, @acc_table_name, @table_code, @stored_value,
			                                                            @account_id, @new_fields_values, @row_uuid;
      PRINT 'END Running supervisingPhysTable';
		END

		IF @table_code IN('rays')
		BEGIN
			PRINT 'Running Table: rays... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_Table_Ray] @acc_party_id, @action_taken, @last_action_user_id, @target_path,
			                                                    @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,
			                                                    @acc_table_name, @table_code, @stored_value, @account_id,
			                                                    @new_fields_values, @row_uuid;
      PRINT 'END Running rays';
		END

		IF @table_code IN('others')
		BEGIN
			PRINT 'Running Table: others... (' + @action_taken + ' <-> ' + @target_path + ')';
			EXEC [KYPEnrollment].[sp_Update_Table_Other] @acc_party_id, @action_taken, @last_action_user_id, @target_path,
			                                                    @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,
			                                                    @acc_table_name, @table_code, @stored_value, @account_id,
			                                                    @new_fields_values, @row_uuid;
      PRINT 'END Running others';
		END
END
GO

