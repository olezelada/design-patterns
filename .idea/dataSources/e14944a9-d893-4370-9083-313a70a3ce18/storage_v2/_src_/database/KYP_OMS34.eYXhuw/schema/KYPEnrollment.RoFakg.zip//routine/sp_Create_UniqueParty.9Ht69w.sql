

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Unique Party.   
-- PARAMETERS: 
--  @ein : EIN to new Account that will be create. 
--	@ssn : SSN to new Account that will be create.
--	@business_type : Name Entity Type to pAccount_PDM_EntityType.
--	@business_legal_name : Legal Name to pAccount_PDM_Organization.
--	@last_name : LastName to pAccount_PDM_Person.
--	@middle_name : middleName to pAccount_PDM_Person.
--	@fist_name : fistName pAccount_PDM_Person.
--	@dob : date birthday pAccount_PDM_Person.	
--	@last_action_user_id : this is user to Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Create_UniqueParty]
	@ein VARCHAR(10),
	@ssn VARCHAR(10),
	@business_type VARCHAR(50),
	@business_legal_name VARCHAR(150),
	@last_name VARCHAR(50),
	@middle_name VARCHAR(50),
	@fist_name VARCHAR(50),
	@dob SMALLDATETIME,	
	@last_action_user_id VARCHAR(100)
AS
BEGIN

print 'In [sp_Create_UniqueParty]'

print @ssn
print @dob
print @business_type
print @business_legal_name
print @ein

    SET NOCOUNT ON
    DECLARE @date_created SMALLDATETIME,
			@unique_party INT
    	
	SET @date_created = CAST(GETDATE()	AS SMALLDATETIME)
	INSERT INTO [KYPEnrollment].[pAccount_UniqueParty]
	([EIN]
	,[SSN]
	,[BusinessType]
	,[BusinessLegalName]
	,[BusinessDBAName]
	,[LastName]
	,[MiddleName]
	,[FistName]
	,[DOB]
	,[LastAction]
	,[LastActorUserID]
	,[LastActionDate]
	,[LastActionApprovedByUsedId])
	VALUES
	(@ein
	,@ssn
	,@business_type
	,@business_legal_name
	,@business_legal_name
	,@last_name
	,@middle_name 
	,@fist_name 
	,@dob 
	,'C'
	,@last_action_user_id
	,@date_created
	,@last_action_user_id)
	
	SET @unique_party = SCOPE_IDENTITY()	
	
	RETURN @unique_party
END


GO

