






-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 07-JAN-2015
-- Description:	GET Application Type for Person
-- =============================================
CREATE PROCEDURE [KYP].[p_GetIndApplicationType] 
	-- Add the parameters for the stored procedure here
	 @ProviderOrApplicationNbr VARCHAR(20),
	 @SSN_NUM VARCHAR(11),
	 @PERSON_FULLNAME VARCHAR(200),
	 @PartyType VARCHAR(50),
	 @PartyID INT,
	 @INS_UPD VARCHAR(20),
	 @ApplnTypeInd VARCHAR(20) OUTPUT
AS
		
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @EXISTING_SSN VARCHAR(11),
			@EXISTING_NAME VARCHAR(100),
			@PROV_NUMBER_EXIST BIT,
			@MOCA_STR VARCHAR(20),
			@DATUPD_STR VARCHAR(20)
			
	SET @MOCA_STR = 'MOCA Change'
	SET @DATUPD_STR = 'Data Update'
	
	IF EXISTS (SELECT 1 FROM KYP.ADM_Case WHERE Number = @ProviderOrApplicationNbr)
	BEGIN
		SET @PROV_NUMBER_EXIST = 1
	END 
	
	IF @INS_UPD = 'INSERT'
	BEGIN		
		IF EXISTS (SELECT TOP 1 *
					FROM KYP.PDM_Person A 
					INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
					AND B.PartyRole = 'Person' AND B.PartyType = @PartyType
					INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
					INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
					WHERE D.Number = @ProviderOrApplicationNbr
					ORDER BY A.PersonID DESC)
		BEGIN
			SELECT TOP 1
			@EXISTING_NAME = LastName + COALESCE((', ' + FirstName), '') + COALESCE((' ' + MiddleName), ''),
			@EXISTING_SSN = SSN
			FROM KYP.PDM_Person A 
			INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
			AND B.PartyRole = 'Person' AND B.PartyType = @PartyType
			INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
			INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
			WHERE D.Number = @ProviderOrApplicationNbr
			ORDER BY A.PersonID DESC
			
			IF(@EXISTING_SSN <> @SSN_NUM) 
			BEGIN 
				SET @ApplnTypeInd = @MOCA_STR;
			END
			ELSE IF(@EXISTING_NAME <> @PERSON_FULLNAME)
			BEGIN 
				SET @ApplnTypeInd = @MOCA_STR;
			END
			ELSE IF(@PROV_NUMBER_EXIST = 1)
			BEGIN 
				SET @ApplnTypeInd = @DATUPD_STR;
			END
		END
	END
	ELSE IF EXISTS (SELECT TOP 1 *
		FROM KYP.PDM_Person A 
		INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
		AND B.PartyRole = 'Person' AND B.PartyType = @PartyType
		INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
		INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
		WHERE D.Number = @ProviderOrApplicationNbr AND A.PartyID = @PartyID
		ORDER BY A.PersonID DESC)
	BEGIN		
		SELECT TOP 1
		@EXISTING_NAME = LastName + COALESCE((', ' + FirstName), '') + COALESCE((' ' + MiddleName), ''),
		@EXISTING_SSN = SSN
		FROM KYP.PDM_Person A 
		INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
		AND B.PartyRole = 'Person' AND B.PartyType = @PartyType
		INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
		INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
		WHERE D.Number = @ProviderOrApplicationNbr AND A.PartyID = @PartyID
		ORDER BY A.PersonID DESC
	 
		IF(@EXISTING_SSN <> @SSN_NUM) 
		BEGIN 
			SET @ApplnTypeInd = @MOCA_STR;
		END
		ELSE IF(@EXISTING_NAME <> @PERSON_FULLNAME)
		BEGIN 
			SET @ApplnTypeInd = @MOCA_STR;
		END
		ELSE IF(@PROV_NUMBER_EXIST = 1)
		BEGIN 
			SET @ApplnTypeInd = @DATUPD_STR;
		END
	END
	ELSE
	BEGIN
		SET @ApplnTypeInd = @DATUPD_STR
	END
END


GO

