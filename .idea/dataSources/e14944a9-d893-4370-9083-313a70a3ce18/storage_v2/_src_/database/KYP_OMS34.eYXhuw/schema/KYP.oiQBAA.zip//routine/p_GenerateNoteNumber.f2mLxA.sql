



	-- =============================================
	-- Author:		Yogesh Sharma
	-- Create date: Aug 09 2012
	-- Description:	Finds Provider PartyID based on Name and Application Num
	-- =============================================
	CREATE PROCEDURE [KYP].[p_GenerateNoteNumber]
		-- Add the parameters for the stored procedure here
		@Noteid Int,
		@Notenumber VARCHAR(15) OUTPUT
	AS
		BEGIN
			SET NOCOUNT ON;
		  -- try block
			  BEGIN TRY
			  
				DECLARE @ParentID INT
					,@Number VARCHAR(15)
					,@NumberingSchemaInfo VARCHAR(20)
					,@nextNumber VARCHAR(10)
					,@counter_aux INT
					,@limit INT
					,@len INT
					,@zeros VARCHAR(10)
					,@updatenumber INT

				SELECT @counter_aux = 0, @limit = 8, @zeros = ''

				--SELECT TOP (1) @nextNumber = NextNumberValue FROM KYP.OIS_LK_NextNumber WITH (NOLOCK) WHERE NAME = 'NT'

				SELECT @len = LEN(@Noteid)

				SELECT @limit = @limit - @len

				IF (@limit > @counter_aux)
				BEGIN
					WHILE (@limit > @counter_aux)
					BEGIN
						SELECT @zeros = @zeros + '0'

						SELECT @counter_aux = @counter_aux + 1
					END
				END

				SELECT @Number = 'NT-' + @zeros + convert(varchar(10),@Noteid)

				--SELECT @updatenumber = convert(INT, @nextNumber)

				--SELECT @updatenumber = @updatenumber + 1

				--UPDATE KYP.OIS_LK_NextNumber
				--SET NextNumberValue = convert(VARCHAR, @updatenumber)
				--WHERE NAME = 'NT'

				SELECT @Notenumber = @Number
				END TRY
		BEGIN CATCH
					IF @@TranCount>0
						Rollback Transaction;	
							
					Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'Noteid',@KeyValue = @Noteid;
				END CATCH
			
			END


  GO

