

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Place Business form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccountID that will be create. 
-- ============================================================
*/

create PROCEDURE [KYPEnrollment].[sp_Copy_Place_Business]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@account_id INT,
@is_update BIT = 0,
@table_code VARCHAR(20) = NULL

AS
BEGIN
  IF @is_update = 0
  BEGIN
       DECLARE @type_Radio VARCHAR(50),@type_answer_two VARCHAR(50),@type_answer_Three VARCHAR(100),@date_create DATE
       SET @date_create = GETDATE();
  
	  SELECT @type_Radio = PrimaryAnswer, @type_answer_two = SecondAnswer, @type_answer_Three = ThirdAnswer 
	  FROM  [KYPPORTAL].[PortalKYP].[pPDM_PlaceBusiness] WHERE PartyID =@party_app_id;
	  
		INSERT INTO [KYPEnrollment].[pAccount_PDM_PlaceBusiness] (
				[PartyId]
			   ,[PrimaryAnswer]
			   ,[SecondAnswer]
			   ,[ThirdAnswer]
			   ,[IsDeleted]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag])
		  VALUES(@party_account_id
				,@type_Radio
				,@type_answer_two
				,@type_answer_Three
				,0
				,'C'
				,@date_create
				,@last_action_user_id 
				,@last_action_user_id
				,1) 
	  
	   IF  @type_Radio ='RadioOne' OR @type_Radio = NULL
	   BEGIN
			DECLARE @party_place_r1 INT,@party_place_acc_r1 INT
			SELECT @party_place_r1 = PartyID 
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] 
			WHERE Type='Lease Information' AND ParentPartyID= @party_app_id AND IsDeleted=0;

			EXEC @party_place_acc_r1 = [KYPEnrollment].[sp_Copy_Party] @party_place_r1,@party_account_id,@account_id,@last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_Person]@party_place_acc_r1,@party_place_r1,@last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_Address]@party_place_acc_r1,@party_place_r1,NULL,@last_action_user_id;
		END
		ELSE         
		 IF @type_answer_Three LIKE '%health facility%' OR @type_answer_Three LIKE '%licensed hospital%'
		 BEGIN
		  --**
		     declare @newparty table (partEnroll int,partPortal int)
		     declare @partaddres table (partaddEnroll int, partaddPortal int)
			 INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
			([Type] ,
			[Name] ,
			[IsProvider] ,
			[IsEnrolled] ,
			[IsTemp] ,
			[IsActive] ,
			[LoadType] ,
			[LoadID] ,
			[LastLoadDate] ,
			[IsDeleted],
			[DateModified] ,
			[CurrentRecordFlag] ,
			[Source] ,
			[LastAction] ,
			[LastActionDate] ,
			[profile_id],
			[ParentPartyID],
			[AccountID],
			[LastActorUserID],
			[LastActionApprovedBy],
			temppartyid)
			
			output inserted.PartyID,inserted.TempPartyID into @newparty
			SELECT [Type]
			,[Name]
			,[IsProvider]
			,[IsEnrolled]
			,[IsTemp]
			,[IsActive]
			,[LoadType]
			,[LoadID]
			,[LastLoadDate]
			,[IsDeleted]
			,[DateModified]
			,1
			,[Source]
			,'C'
			,@date_Create
			,[profile_id]
			,@party_account_id
			,@account_id
			,@last_action_user_id
			,@last_action_user_id
			,partyid
			FROM 
			[KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE (Type='FacilityBusiness Address' OR Type='HospitalBusiness Address') 
			 AND ParentPartyID = @party_app_id AND IsDeleted='false'
			
			 INSERT INTO [KYPEnrollment].[pAccount_PDM_Address] (
                        [AddressLine1],
                        [AddressLine2],
                        [County],
                        [City],
                        [Zip],
                        [ZipPlus4],
                        [State],
                        [Country],
                        [Latitude],
                        [Longitude],
                        [GeographicArea],
                        [LastAction],
                        [LastActionDate],
                        [LastActionUserID],
                        [LastActionApprovedByUsedID],
                        [CurrentRecordFlag],
                        [AdaAccessible],   
                        [TtyCapacity],
                        [TtyNumber],
                        tempaddressid)
             output inserted.AddressID,inserted.TempAddressID into @partaddres           
            SELECT [AddressLine1],
                   [AddressLine2],
                   [County],
                   [City],
                   [Zip],
                   [ZipPlus4],
                   [State],
                   [Country],
                   [Latitude],
                   [Longitude],
                   [GeographicArea],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [AdaAccessible],         -- New columns for new Packages MD.
                   [TtyCapacity],
                   [TtyNumber],
                   addr.addressid
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Address]  addr inner join [KYPPORTAL].[PortalKYP].[pPDM_location] loc on addr.AddressID=loc.AddressID 
              inner join @newparty newpar on loc.PartyID=newpar.partPortal
             
			  INSERT INTO [KYPEnrollment].[pAccount_PDM_Location] (
                        [AddressID],
                        [PartyID],
                        [Type],
                        [WorkingDays],
                        [WorkingHours],
                        [Phone1],
                        [Phone2],
                        [Fax],
                        [Remarks],
                        [InActive],
                        [Email],
                        [IsLicensed],
                        [IsRented],
                        [Status],
                        [Name],
                        [IsSchoolSide],
                        [IsDonatedSpace],
                        [IsDeleted],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag])
            SELECT newparadd.partaddenroll,
                   newpar.partenroll,
                   [Type],
                   [WorkingDays],
                   [WorkingHours],
                   [Phone1],
                   [Phone2],
                   [Fax],
                   [Remarks],
                   [InActive],
                   [Email],
                   [IsLicensed],
                   [IsRented],
                   [Status],
                   [Name],
                   [IsSchoolSide],
                   [IsDonatedSpace],
                   [IsDeleted],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] loc
              inner join @newparty newpar on loc.PartyID=newpar.partPortal 
              inner join @partaddres newparadd on loc.AddressID=newparadd.partaddPortal 
            
			 
			 
			 
		update kypenrollment.paccount_pdm_party set TempPartyID=null where PartyID in (select partEnroll  from @newparty)	
		update kypenrollment.pAccount_PDM_Address set TempAddressID =null where AddressID in (select partaddEnroll from @partaddres )  
		 END
		
 END
 ELSE
 BEGIN
   IF @table_code = 'leaseInformation'
   BEGIN
    DECLARE @party_place_acc_u INT
    
		EXEC @party_place_acc_u = [KYPEnrollment].[sp_Copy_Party] @party_app_id,@party_account_id,@account_id,@last_action_user_id;
		EXEC [KYPEnrollment].[sp_Copy_Person]@party_place_acc_u,@party_app_id,@last_action_user_id;
		EXEC [KYPEnrollment].[sp_Copy_Address]@party_place_acc_u,@party_app_id,NULL,@last_action_user_id;
   END
   ELSE
   BEGIN
		DECLARE @party_place_acc_f INT
		EXEC @party_place_acc_f = [KYPEnrollment].[sp_Copy_Party] @party_app_id,@party_account_id,@account_id,@last_action_user_id;
		EXEC [KYPEnrollment].[sp_Copy_Address]@party_place_acc_f,@party_app_id,NULL,@last_action_user_id;
   END
 END
END

GO

