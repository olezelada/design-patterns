
CREATE PROCEDURE KYP.p_FindPartyAddress
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@AddressLine1 varchar(250)
	,@City varchar(25)
	,@Zip varchar(5)= NULL
	,@State varchar(25)
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;	
		
	DECLARE @LASTNAME VARCHAR(50)
	DECLARE @DBANAME VARCHAR(100)
	DECLARE @LAGALNAME VARCHAR(50)
	DECLARE @PROTYPE VARCHAR(25)
	
	SELECT @PROTYPE= Category FROM KYP.PDM_Provider where PartyID=@PartyID
	
	IF @PROTYPE='Institutional'
	BEGIN
	 SELECT @LAGALNAME= LegalName,@DBANAME=DBAName1 FROM KYP.PDM_Organization WHERE PartyID=@PartyID
		 if exists (	
				select 1 from KYP.PDM_Organization A
							 inner join 
							     KYP.PDM_Location B on A.PartyID = B.PartyID  and ISNULL(B.IsDeleted,0) = 0 
				             inner join KYP.PDM_Address C  on B.AddressID = C.AddressID and ISNULL(C.IsDeleted,0) = 0
				             inner join kyp.PDM_Party d
				             on d.PartyID=A.PartyID 
						  where ISNULL(D.CurrentModule,0) = ISNULL(@CurrentModule,0) AND 
							(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(@AddressLine1,'')))) AND 
							(LTRIM(RTRIM(ISNULL(A.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(@DBANAME,'')))) AND 
							(LTRIM(RTRIM(ISNULL(A.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(@LAGALNAME,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.City,'')))) = (LTRIM(RTRIM(ISNULL(@City,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.State,'')))) = (LTRIM(RTRIM(ISNULL(@State,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.Zip,'')))) = (LTRIM(RTRIM(ISNULL(@Zip,'')))) AND
							(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(A.DBAName1,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(A.LegalName,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(C.City,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(C.State,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(C.Zip,'')))) != '' 
				)
				begin		
					return 1
				end
		
		ELSE IF EXISTS(
					select 1 from KYP.PDM_Organization A inner join KYP.PDM_Location B
							on A.PartyID = B.PartyID and ISNULL(B.IsDeleted,0) = 0 
							inner join 
							KYP.PDM_Address C on B.AddressID = C.AddressID and ISNULL(C.IsDeleted,0) = 0
							inner join kyp.PDM_Party d
				             on d.PartyID=A.PartyID 
						where ISNULL(d.CurrentModule,0) = ISNULL(@CurrentModule,0) AND 
							(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(@AddressLine1,'')))) AND 
							(LTRIM(RTRIM(ISNULL(A.LegalName,'')))) = (LTRIM(RTRIM(ISNULL(@LAGALNAME,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.City,'')))) = (LTRIM(RTRIM(ISNULL(@City,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.State,'')))) = (LTRIM(RTRIM(ISNULL(@State,'')))) AND 
							(LTRIM(RTRIM(ISNULL(C.Zip,'')))) = (LTRIM(RTRIM(ISNULL(@Zip,''))))AND
							(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(A.LegalName,'')))) != '' AND							
							(LTRIM(RTRIM(ISNULL(C.City,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(C.State,'')))) != '' AND
							(LTRIM(RTRIM(ISNULL(C.Zip,'')))) != '' 
					)
				begin		
					return 1
				end
		ELSE IF EXISTS(
					select 1 from KYP.PDM_Organization A inner join KYP.PDM_Location B
									on A.PartyID = B.PartyID and ISNULL(B.IsDeleted,0) = 0 
									inner join 
									KYP.PDM_Address C on B.AddressID = C.AddressID and ISNULL(C.IsDeleted,0) = 0 
							 inner join kyp.PDM_Party d
				             on d.PartyID=A.PartyID 
					where ISNULL(d.CurrentModule,0) = ISNULL(@CurrentModule,0) AND 
						(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(@AddressLine1,'')))) AND 
						(LTRIM(RTRIM(ISNULL(A.DBAName1,'')))) = (LTRIM(RTRIM(ISNULL(@DBANAME,'')))) AND 
						(LTRIM(RTRIM(ISNULL(C.City,'')))) = (LTRIM(RTRIM(ISNULL(@City,'')))) AND 
						(LTRIM(RTRIM(ISNULL(C.State,'')))) = (LTRIM(RTRIM(ISNULL(@State,'')))) AND 
						(LTRIM(RTRIM(ISNULL(C.Zip,'')))) = (LTRIM(RTRIM(ISNULL(@Zip,''))))AND
						(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) != '' AND
						(LTRIM(RTRIM(ISNULL(A.DBAName1,'')))) != '' AND							
						(LTRIM(RTRIM(ISNULL(C.City,'')))) != '' AND
						(LTRIM(RTRIM(ISNULL(C.State,'')))) != '' AND
						(LTRIM(RTRIM(ISNULL(C.Zip,'')))) != '' 
					)
					begin		
						return 1
					end
		
			else 
				return -1 
			END
	ELSE 
			BEGIN 
				SELECT @LASTNAME= LastName from KYP.PDM_Person WHERE PartyID=@PartyID
					 if exists (	
						select 1 from KYP.PDM_Person A
									 inner join 
										 KYP.PDM_Location B on A.PartyID = B.PartyID  and ISNULL(B.IsDeleted,0) = 0 
									 inner join KYP.PDM_Address C  on B.AddressID = C.AddressID and ISNULL(C.IsDeleted,0) = 0 
							inner join kyp.PDM_Party d
				             on d.PartyID=A.PartyID 
								  where ISNULL(d.CurrentModule,0) = ISNULL(@CurrentModule,0) AND 
									(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) = (LTRIM(RTRIM(ISNULL(@AddressLine1,'')))) AND 
									(LTRIM(RTRIM(ISNULL(A.LastName,'')))) = (LTRIM(RTRIM(ISNULL(@LASTNAME,'')))) AND 
									(LTRIM(RTRIM(ISNULL(C.City,'')))) = (LTRIM(RTRIM(ISNULL(@City,'')))) AND 
									(LTRIM(RTRIM(ISNULL(C.State,'')))) = (LTRIM(RTRIM(ISNULL(@State,'')))) AND 
									(LTRIM(RTRIM(ISNULL(C.Zip,'')))) = (LTRIM(RTRIM(ISNULL(@Zip,'')))) AND
									(LTRIM(RTRIM(ISNULL(C.AddressLine1,'')))) != '' AND															
									(LTRIM(RTRIM(ISNULL(C.City,'')))) != '' AND
									(LTRIM(RTRIM(ISNULL(C.State,'')))) != '' AND
									(LTRIM(RTRIM(ISNULL(C.Zip,'')))) != '' 
						)
						begin		
							return 1
						end
					
					else 
						return -1 
			END
			
	
END


GO

