
CREATE VIEW [KYPEnrollment].[v_OutEDI_MOCA_D_File_WeeklyReport]
AS
SELECT row_number() OVER (ORDER BY PartyID ASC) AS ID, *
FROM         
(
Select DISTINCT x.PartyID,x.SSN,x.TIN,x.NPI,SUBSTRING(x.LegalName,1,50) AS LegalName,x.DateCreated,x.DateDeleted,x.DoB,x.DateModified
,x.LastActionDate,x.Type

from( 
select PRT.PartyID
,PRT.Type,PRT.LastActionDate,PRT.DateCreated,PRT.DateDeleted,PRT.LastMOCARelationshipUpdateBy 
,P.DoB
,O.LegalName
,PVDR.NPI
,ONR.DateModified
,Case when(PRT.Type='Individual Ownership') then (select SSN from KYPEnrollment.pAccount_PDM_Person where PartyID=PRT.PartyID)ELSE NULL END AS SSN
,Case when(PRT.Type='Entity Ownership') then (select TIN from [KYPEnrollment].[pAccount_PDM_Organization] where PartyID=PRT.PartyID)ELSE NULL END AS TIN

from KYPEnrollment.pAccount_PDM_Party PRT
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Organization] O on O.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Owner_Role] ONR on ONR.PartyID=PRT.PartyID
where PRT.IsProvider=0
--AND CONVERT(VARCHAR, PRT.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-7, 101) and  CONVERT(VARCHAR, PRT.LastActionDate , 101)<=  CONVERT(VARCHAR, GETDATE(), 101)
--AND PRT.LastMOCAUpdateBy in('P','E','T')
--AND PRT.DateCreated!=PRT.DateDeleted
--AND CONVERT(VARCHAR, PRT.LastActionDate , 101) >=  CONVERT(VARCHAR, GETDATE()-1, 101) 

) x 
) z

------------------------------------------- Close of MOCA Details file ------------------------------------------------------------------------------


GO

