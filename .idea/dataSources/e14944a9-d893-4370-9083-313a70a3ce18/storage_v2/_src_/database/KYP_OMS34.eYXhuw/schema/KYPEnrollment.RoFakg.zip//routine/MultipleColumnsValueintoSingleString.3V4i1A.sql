
CREATE FUNCTION [KYPEnrollment].[MultipleColumnsValueintoSingleString]
(
	@AddressLine1		VARCHAR(250),
	@AddressLine2		VARCHAR(250),
	@City				VARCHAR(25),
	@State				VARCHAR(40),
	@County				VARCHAR(25),
	@ZipPlus4			VARCHAR(25)
)
RETURNS VARCHAR(200)
AS
BEGIN

	DECLARE @FullAddress	VARCHAR(300) = '',
			@Value			VARCHAR(250) = '',
			@I				INT = 1
	
	DECLARE @Temp TABLE
	(
		ID		INT IDENTITY(1,1) PRIMARY KEY,
		Value	VARCHAR(250)
	)
	
	INSERT INTO @Temp(Value) SELECT @AddressLine1
	INSERT INTO @Temp(Value) SELECT @AddressLine2
	INSERT INTO @Temp(Value) SELECT @City
	INSERT INTO @Temp(Value) SELECT @State
	INSERT INTO @Temp(Value) SELECT @County
	INSERT INTO @Temp(Value) SELECT @ZipPlus4

	WHILE @I <= (SELECT COUNT(1)
					FROM @Temp)
	
	BEGIN
	
		SELECT @Value = Value
			FROM @Temp
			WHERE ID = @I
		
		IF @FullAddress = ''
			SET @FullAddress = ISNULL(@Value,'')
		ELSE IF @FullAddress != '' AND @Value != ''
			SET @FullAddress = @FullAddress + ', ' + @Value
		
		SET @I = @I + 1

	END
	
	RETURN @FullAddress
	
END;


GO

