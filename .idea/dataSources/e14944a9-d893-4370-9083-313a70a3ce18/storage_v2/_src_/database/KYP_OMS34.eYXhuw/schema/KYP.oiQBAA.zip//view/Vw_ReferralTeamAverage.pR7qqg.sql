

CREATE VIEW [KYP].[Vw_ReferralTeamAverage] as 
SELECT ROW_NUMBER() OVER(ORDER BY C.ReferralDate) ReferralId,       
       C.TypeDescription,      
       C.ReferralDate,      
       C.DaysWithReferral,       
       C.ReferralTeamDesc,
       RTC.ReferralTeamCount
      -- convert(decimal(10,2),C.DaysWithReferral)/RTC.ReferralTeamCount as R
FROM KYP.Vw_TotalReferredApplication C
Left Join (Select ReferralTeamDesc,convert(decimal(10,2),SUM(DaysWithReferral))/COUNT(1) ReferralTeamCount
  From KYP.Vw_TotalReferredApplication 
  Group by ReferralTeamDesc) RTC on C.ReferralTeamDesc = RTC.ReferralTeamDesc
WHERE C.ReferralDate IS NOT NULL


GO

