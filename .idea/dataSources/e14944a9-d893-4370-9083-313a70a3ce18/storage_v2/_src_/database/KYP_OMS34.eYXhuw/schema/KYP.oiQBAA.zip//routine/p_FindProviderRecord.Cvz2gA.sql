
-- =============================================
-- Author:		Yogesh Sharma
-- Create date: July 28 2012
-- Description:	Find the ProviderID if Party exists as a Provider with its identifier 
-- =============================================
CREATE PROCEDURE [KYP].[p_FindProviderRecord]
	-- Add the parameters for the stored procedure here
	@PartyID int
	,@ProvIdentifierID varchar(20) --This would take P_ID for monitoring and P_APPL_NUM for screening
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @ProvID int
	/********Get the providerid based on PartyID + P_ID**********/
	if exists (	
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_Provider B
		on A.PartyID = B.PartyID 
		and A.IsProvider=1
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		--and B.Mon_MedicaidID = @ProvIdentifierID
		and B.ProvNumber =@ProvIdentifierID 
	)
	begin
	select @ProvID = B.ProvID
	from KYP.PDM_Party A
	inner join KYP.PDM_Provider B
		on A.PartyID = B.PartyID 
		and A.IsProvider=1
		and ISNULL(A.IsDeleted,0) = 0 
		and ISNULL(B.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and  A.PartyID = @PartyID
		--and B.Mon_MedicaidID = @ProvIdentifierID	
		and B.ProvNumber =@ProvIdentifierID
    return @ProvID	
	end	
	else 
	return -1   	
END


GO

