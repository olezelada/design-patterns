
CREATE TRIGGER [dbo].[InsertAppRoles] 
   ON  [dbo].[ROLETABLE]
   AFTER INSERT
AS 
BEGIN

	declare @roleName varchar(100);
	declare @roleType varchar(50);
	declare @messageRole varchar(100);
	
	select @roleName = role_name from INSERTED;
    select @roleType = role_type from INSERTED;
	
    IF (@roleType <> 'System')
	BEGIN
		SELECT @messageRole = GroupName FROM KYP.OIS_MedicalGroups WHERE GroupName = @roleName;
		
		IF(@roleName = @messageRole)
		BEGIN 
			INSERT INTO KYP.OIS_Role(RoleName, Description, Deleted, UserRoleType) values(@roleName, @roleName, 0,'MessageRole')
		END
		ELSE 
		BEGIN 
			INSERT INTO KYP.OIS_Role(RoleName, Description, Deleted, UserRoleType) values(@roleName, @roleName, 0,'LoginRole')
		END
	END
END


GO

