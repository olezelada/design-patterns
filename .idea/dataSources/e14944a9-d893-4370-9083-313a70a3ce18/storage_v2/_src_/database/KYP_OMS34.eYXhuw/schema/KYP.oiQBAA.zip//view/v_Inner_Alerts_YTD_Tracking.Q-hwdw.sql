CREATE VIEW [KYP].[v_Inner_Alerts_YTD_Tracking]
AS

SELECT TOP (100) PERCENT A.MonthNo AS ID,
A.YearNo, 
A.MonthNo,
A.ProvidersRecieved,				
B.Nbr as TotalAlerts,				
C.[ConfirmedAlerts],				
C.[FalsePositives],					
C.[IgnoredAlerts],
D.[SanctionAlerts],
D.[LicensureAlerts], 
D.[DemographicAlerts],
E.Nbr as [ActionTakenOn]


FROM

(
      select 
	  datepart(year, LastLoadDate) as YearNo
      ,datepart(month, LastLoadDate) as MonthNo
      ,count(distinct Pvd.PartyID) as ProvidersRecieved 
      from 
      KYP.PDM_Party Prty
      INNER JOIN KYP.PDM_Provider Pvd ON  
            Prty.PartyID= Pvd.PartyID AND ISNULL(Prty.IsDeleted,0)=0 AND ISNULL(Pvd.IsDeleted,0)=0
            AND Prty.IsProvider=1 
            AND Prty.CurrentModule=2
      Group By datepart(year, LastLoadDate), datepart(month, LastLoadDate)
) A

INNER JOIN 

(
	select 
		datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
		datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
		count(distinct alertid) as Nbr
	from
	(
		
				select alertid, dateinitiated from KYP.MDM_Alert where ISNULL(IsDeleted,0)=0
				union
				select NULL as alertid, getdate() as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated
	) MDM_Alert_AllMonths
	group by 
	datepart(year, MDM_Alert_AllMonths.DateInitiated), 
	datepart(month, MDM_Alert_AllMonths.DateInitiated) 
)B

ON A.YearNo= B.YearNo
AND A.MonthNo = B.MonthNo

INNER JOIN

(
	SELECT YearNo,MonthNo,[ConfirmedAlerts],[FalsePositives], [IgnoredAlerts]
	FROM
	(
		select YearNo,MonthNo, MatchStatusIndicator, Nbr from 
		(
			select 
				datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
				datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
				MDM_Alert_AllMonths.MatchStatusIndicator,
				count(distinct alertid) as Nbr
			from
			(
				select 
				alertid, 
				dateinitiated,
				case 
					when MatchStatusIndicator = 'C' 
					then 'ConfirmedAlerts'
					when MatchStatusIndicator = 'I' 
					then 'IgnoredAlerts'
					when MatchStatusIndicator = 'F' 
					then 'FalsePositives'
				end as MatchStatusIndicator

				from (
						select alertid, dateinitiated, MatchStatusIndicator from KYP.MDM_Alert 
							where MatchStatusIndicator in ('C','I','F') and ISNULL(IsDeleted,0)=0
						union
						select NULL as alertid, getdate() as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'C' as MatchStatusIndicator
						union 
						select NULL as alertid, getdate() as dateinitiated, 'I' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'I' as MatchStatusIndicator
						union
						select NULL as alertid, getdate() as dateinitiated, 'F' as MatchStatusIndicator
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'F' as MatchStatusIndicator
				) MDM_Alert
			) MDM_Alert_AllMonths
			group by 
			datepart(year, MDM_Alert_AllMonths.DateInitiated), 
			datepart(month, MDM_Alert_AllMonths.DateInitiated), 
			MDM_Alert_AllMonths.MatchStatusIndicator
		) AlertMatch_Year_Mnth
	) AS SourceTable
	PIVOT
	(
	MAX(Nbr)
	FOR MatchStatusIndicator IN ([ConfirmedAlerts],[FalsePositives], [IgnoredAlerts])
	) AS PivotTable
)C

ON B.YearNo= C.YearNo
AND B.MonthNo = C.MonthNo

INNER JOIN

(
	SELECT YearNo,MonthNo,[SanctionAlerts],[LicensureAlerts], [DemographicAlerts]
	FROM
	(
		select YearNo,MonthNo, WatchlistName, Nbr  from 
		(
			select 
				datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo,
				datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo,
				MDM_Alert_AllMonths.WatchlistName,
				count(distinct MDM_Alert_AllMonths.alertid) as Nbr
			from
			(
				select 
				alertid, 
				dateinitiated,
				case 
					when WatchListName in ('OIG LEIE', 'GSA EPLS', 'Individual Sanctions', 'Organization Sanctions','SanctionAlerts')
					then 'SanctionAlerts'
					when WatchListName in ('Licensure','Individual NPI','Individual DEA','Organization NPI','Organization DEA','LicensureAlerts')
					then 'LicensureAlerts'
					when WatchListName in ('SSN Fraud','SSA DMF','Sex Offenders','DemographicAlerts')
					then 'DemographicAlerts'
				end as WatchlistName

				from (
						select alertid, dateinitiated, WatchlistName from KYP.MDM_Alert where ISNULL(IsDeleted,0)=0
						union
						select NULL as alertid, getdate() as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'SanctionAlerts' as WatchlistName
						union 
						select NULL as alertid, getdate() as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'LicensureAlerts' as WatchlistName
						union
						select NULL as alertid, getdate() as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 
						select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union 			                                            
						select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
						union			                                            
						select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated, 'DemographicAlerts' as WatchlistName
				) MDM_Alert
			) MDM_Alert_AllMonths
			group by 
			datepart(year, MDM_Alert_AllMonths.DateInitiated), 
			datepart(month, MDM_Alert_AllMonths.DateInitiated), 
			MDM_Alert_AllMonths.WatchlistName
		) AlertWatchlist_Year_Mnth
	) AS SourceTable
	PIVOT
	(
	MAX(Nbr)
	FOR WatchlistName IN ([SanctionAlerts],[LicensureAlerts], [DemographicAlerts])
	) AS PivotTable
) D

ON C.YearNo= D.YearNo
AND C.MonthNo = D.MonthNo

INNER JOIN

(
	select 
		datepart(year, MDM_Alert_AllMonths.DateInitiated) as YearNo, 
		datepart(month, MDM_Alert_AllMonths.DateInitiated) as MonthNo, 
		count(distinct alertid) as Nbr
	from
	(
		
				select A.alertid, A.dateinitiated from KYP.MDM_Alert A inner join KYP.MDM_AlertResolution B 
					on A.alertid=B.alertid and ISNULL(A.IsDeleted,0)=0 and ISNULL(B.IsDeleted,0)=0
				union
				select NULL as alertid, getdate() as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-1,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-2,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-3,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-4,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-5,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-6,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-7,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-8,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-9,getdate()) as dateinitiated
				union 
				select NULL as alertid, dateadd(month,-10,getdate()) as dateinitiated
				union
				select NULL as alertid, dateadd(month,-11,getdate()) as dateinitiated
	) MDM_Alert_AllMonths
	group by 
	datepart(year, MDM_Alert_AllMonths.DateInitiated), 
	datepart(month, MDM_Alert_AllMonths.DateInitiated) 
)E

ON D.YearNo= E.YearNo
AND D.MonthNo = E.MonthNo


WHERE A.YearNo=datepart(year,getdate())
ORDER BY A.MonthNo ASC


GO

