CREATE PROCEDURE [dbo].[UpdateAlertDetailData]
AS
BEGIN
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_GenWatchedPartyID')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_GenWatchedPartyID
	END

	CREATE TABLE tmp_GenWatchedPartyID (WatchedPartyID INT)

	DECLARE @pmfloaddate DATETIME

	SELECT TOP 1 @pmfloaddate = fileloaddate
	FROM KYP.MDM_MonthlyActiveProvider
	ORDER BY ID DESC

	INSERT INTO tmp_GenWatchedPartyID
	SELECT DISTINCT WatchedPartyID
	FROM KYP.MDM_Alert
	WHERE DateInitiated >= @pmfloaddate

	UPDATE kyp.PDM_Provider
	SET PrimarySpecialty = 'Unknown'
	WHERE PrimarySpecialty IS NULL

	DELETE x
	FROM KYP.MDM_PartyDetail x
	INNER JOIN tmp_GenWatchedPartyID y ON x.PartyID = y.WatchedPartyID

	DELETE x
	FROM KYP.MDM_PartyAddress x
	INNER JOIN tmp_GenWatchedPartyID y ON x.PartyID = y.WatchedPartyID

	INSERT INTO KYP.MDM_PartyDetail
	SELECT a.PartyID
		,B.NPI
		,B.SSN
		,C.PrimarySpecialty
		,D.LicenseCode
		,TaxId
		,'Person'
		,'OMS'
		,D.LicenseState
	FROM KYP.PDM_Party A
	INNER JOIN tmp_GenWatchedPartyID genAlrt ON genAlrt.WatchedPartyID = A.PartyID
	INNER JOIN KYP.PDM_Person B ON A.PartyID = B.PartyID
		AND A.CurrentModule = 2
		AND A.IsDeleted <> 1
	LEFT JOIN KYP.PDM_Provider C ON B.PartyID = C.PartyID
	LEFT JOIN KYP.PDM_License D ON B.PartyID = D.PartyID
	
	UNION
	
	SELECT A.PartyID
		,B.NPI
		,SSN
		,C.PrimarySpecialty
		,D.LicenseCode
		,B.TIN
		,'Organization'
		,'OMS'
		,D.LicenseState
	FROM KYP.PDM_Party A
	INNER JOIN tmp_GenWatchedPartyID genAlrt ON genAlrt.WatchedPartyID = A.PartyID
	INNER JOIN KYP.PDM_Organization B ON A.PartyID = B.PartyID
		AND A.CurrentModule = 2
		AND A.IsDeleted <> 1
	LEFT JOIN KYP.PDM_Provider C ON B.PartyID = C.PartyID
	LEFT JOIN KYP.PDM_License D ON B.PartyID = D.PartyID

	UPDATE KYP.MDM_PartyDetail
	SET Speciality = 'Unknown'
	WHERE Speciality IS NULL

	UPDATE KYP.MDM_PartyDetail
	SET NPI = ''
	WHERE NPI IS NULL

	UPDATE KYP.MDM_PartyDetail
	SET SSN = ''
	WHERE SSN IS NULL

	UPDATE KYP.MDM_PartyDetail
	SET License = ''
	WHERE License IS NULL

	UPDATE KYP.MDM_PartyDetail
	SET TaxID = ''
	WHERE TaxID IS NULL

	UPDATE KYP.MDM_PartyDetail
	SET LicenseState = ''
	WHERE LicenseState IS NULL

	INSERT INTO KYP.MDM_PartyAddress
	SELECT x.WatchedPartyID
		,(a.AddressLine1 + ' ' + a.CITY + ' ' + a.[State] + ' ' + a.ZIP) AS Address
		,a.AddressLine1
		,a.City
		,a.[STATE]
		,a.ZIP
	FROM tmp_GenWatchedPartyID x
	INNER JOIN KYP.PDM_LocatiON b ON b.PartyID = x.WatchedPartyID
	INNER JOIN KYP.PDM_Address a ON a.AddressID = b.AddressID
	WHERE (a.AddressLine1 + ' ' + a.CITY + ' ' + a.[State] + ' ' + a.ZIP) IS NOT NULL

	DELETE x
	FROM (
		SELECT *
			,ROW_NUMBER() OVER (
				PARTITION BY partyid
				,npi
				,ssn
				,speciality
				,taxid
				,license
				,licensestate
				,type
				,db_flag ORDER BY id
				) row
		FROM KYP.MDM_PartyDetail
		) x
	WHERE x.row > 1

	DELETE x
	FROM (
		SELECT *
			,ROW_NUMBER() OVER (
				PARTITION BY PartyID
				,[Address]
				,Address1
				,City
				,[State]
				,Zip ORDER BY ID
				) row
		FROM KYP.MDM_PartyAddress
		) x
	WHERE x.row > 1
	
	IF EXISTS (
			SELECT 1
			FROM sys.objects
			WHERE object_id = OBJECT_ID(N'tmp_GenWatchedPartyID')
				AND type IN (N'U')
			)
	BEGIN
		DROP TABLE tmp_GenWatchedPartyID
	END
END
GO

