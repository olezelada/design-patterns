




CREATE VIEW [KYPEnrollment].[v_OutEDITaxonomy_WeeklyReport_Reconciliation] as
With TX as (
	SELECT A.AccountID,A.NPI,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode,S.Speciality_Code,
		ROW_NUMBER() over(partition by A.NPI,A.OwnerNo,A.ServiceLocationNo,A.ProviderTypeCode order by S.SpecialityId) R
		FROM KYPEnrollment.pADM_Account A
		Join KYPEnrollment.pAccount_PDM_Speciality S on A.PartyID=S.PartyID
		WHERE S.Type='Taxonomy Code'
		and A.IsDeleted=0
		and S.CurrentRecordFlag = 1
		and A.ProviderTypeCode<>'100'), --Added to eliminate Mixed Group records
TD AS (
		Select S1.AccountID,
			S1.Speciality_Code Speciality_Code1,
			S2.Speciality_Code Speciality_Code2,
			S3.Speciality_Code Speciality_Code3,
			S4.Speciality_Code Speciality_Code4,
			S5.Speciality_Code Speciality_Code5,
			S6.Speciality_Code Speciality_Code6,
			S7.Speciality_Code Speciality_Code7,
			S8.Speciality_Code Speciality_Code8,
			S9.Speciality_Code Speciality_Code9,
			S10.Speciality_Code Speciality_Code10,
			S11.Speciality_Code Speciality_Code11,
			S12.Speciality_Code Speciality_Code12,
			S13.Speciality_Code Speciality_Code13,
			S14.Speciality_Code Speciality_Code14,
			S15.Speciality_Code Speciality_Code15
	From (Select AccountId,Speciality_Code
			From TX
			Where R=1) S1
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=2) S2 ON S1.AccountID=S2.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=3) S3 ON S1.AccountID=S3.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=4) S4 ON S1.AccountID=S4.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=5) S5 ON S1.AccountID=S5.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=6) S6 ON S1.AccountID=S6.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=7) S7 ON S1.AccountID=S7.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=8) S8 ON S1.AccountID=S8.AccountID										
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=9) S9 ON S1.AccountID=S9.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=10) S10 ON S1.AccountID=S10.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=11) S11 ON S1.AccountID=S11.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=12) S12 ON S1.AccountID=S12.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=13) S13 ON S1.AccountID=S13.AccountID
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=14) S14 ON S1.AccountID=S14.AccountID	
	Left Join (Select AccountId,Speciality_Code
			From TX
			Where R=15) S15 ON S1.AccountID=S15.AccountID)
Select Distinct Tx.NPI,Tx.OwnerNo,Tx.ServiceLocationNo,Tx.ProviderTypeCode,
Td.Speciality_Code1,Td.Speciality_Code2,
Td.Speciality_Code3,Td.Speciality_Code4,
Td.Speciality_Code5,Td.Speciality_Code6,
Td.Speciality_Code7,Td.Speciality_Code8,
Td.Speciality_Code9,Td.Speciality_Code10,
Td.Speciality_Code11,
Td.Speciality_Code12,
Td.Speciality_Code13,
Td.Speciality_Code14,
Td.Speciality_Code15
from TX
Join TD ON Tx.AccountID=TD.AccountID


GO

