




CREATE VIEW [KYPEnrollment].[view_AllDataFindings_TEST]
 AS
SELECT row_number() OVER (ORDER BY category ASC) AS ViewID, *
FROM         
(		
		select fe.InfoID, fe.JournalEvent, fe.Type, fe.PSubFormID, fe.PFieldID, fe.PartyID,  'SCREENING' as category,a.ReasonCode as Reasoncode, CASE 
				 WHEN a.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (a.ExternalYesNO = '1' or a.ExternalYesNO = 'Yes') THEN
						'EXTERNAL' 
						WHEN (a.ExternalYesNO = '0' or a.ExternalYesNO = 'NO')  THEN
						'INTERNAL' 
					 ELSE NULL END
			    END As isexternaldesc
			 ,CASE 
				 WHEN a.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (a.ExternalYesNO = '1' or a.ExternalYesNO = 'Yes') THEN
						'Yes' 
						WHEN (a.ExternalYesNO = '0' or a.ExternalYesNO = 'NO')  THEN
						'No' 
					 ELSE NULL END
			    END As isexternalYesNo   
	          ,(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u where p.PersonID = u.PersonID and u.UserID= a.UserID) as addedby
            , a.DateCreated addedon
		     , a.Name titleFinding
		     , CAST(a.Content AS varchar(MAX)) descFinding
		     , a.Score riskScoreFinding
		     , a.Type typeFinding
		     , a.UpdAction actionFinding
		     , '' fieldFinding
		     , 0 ignoredFinding
		     , a.AutoFlag flagScore
		     , a.DiffScore diffScore
		     , a.Tags tagsFinding
		     , a.DocumentCount docCountFinding
		     , cast(a.CaseID+'' as int) caseIDFinding
			 , a.NoteID findingID
			 , 'SCREENING' as PStatus
			 , 'Confirmed' isIgnoredMsg
			 , CAST(a.UnformattedContent AS varchar(5000)) findingDescription
		from kyp.OIS_Note a, kyp.MDM_JournalBasicInfo fe
		where  a.NoteID IN (select DISTINCT c.CFId from  KYP.Eventdates c ) and a.Type NOT IN ('Application Review','Related Accounts')
			and fe.InfoID = a.PInID
		UNION
		SELECT fe.InfoID, fe.JournalEvent, fe.Type, fe.PSubFormID, fe.PFieldID, fe.PartyID,  'APP REVIEW' as category
		     , f.ReasonCode as Reasoncode
		     , CASE 
				 WHEN f.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
				 CASE WHEN f.ExternalYesNO = '1' or f.ExternalYesNO = 'Yes' THEN
					'EXTERNAL' 
					WHEN f.ExternalYesNO = '0' or f.ExternalYesNO = 'NO' THEN
					'INTERNAL' 
				 ELSE NULL END
			    END As isexternaldesc
			 , CASE 
				 WHEN f.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
				 CASE WHEN f.ExternalYesNO = '1' or f.ExternalYesNO = 'Yes' THEN
					'Yes' 
					WHEN f.ExternalYesNO = '0' or f.ExternalYesNO = 'NO' THEN
					'No' 
				 ELSE NULL END
			    END As isexternal   
                         ,(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u 
            where p.PersonID = u.PersonID and u.UserID= f.UserID) as addedby
             , f.DateCreated addedon
		     , f.Name titleFinding
		     , CAST(f.Content AS varchar(MAX)) descFinding
		     , f.Score riskScoreFinding
		     , f.Type typeFinding
		     , f.UpdAction actionFinding
		     , ISNULL( (select top 1 fl.fieldLabel from KYPEnrollment.FieldLabel fl where fe.PFieldID = fl.fieldID and fe.PAppID=fl.ApplicationID and fe.PSubFormID=fl.SubFormID),'') as fieldFinding
		     , fe.IsIgnored ignoredFinding
		     , f.AutoFlag flagScore
		     , f.DiffScore diffScore
		     , f.Tags tagsFinding
		     , f.DocumentCount docCountFinding
		     , cast(fe.PCaseID+'' as int) caseIDFinding
			 , f.NoteID findingID
			 , fe.PStatus as PStatus
			 , CASE 
				 WHEN fe.IsIgnored = '1' THEN 
					'Ignored'
				 ELSE 
				 CASE WHEN fe.IsIgnored = '0' THEN
					'Confirmed' 
				 ELSE 'NA' END
			    END As isIgnoredMsg   
			     ,CAST(f.UnformattedContent AS varchar(5000)) findingDescription
		  from kyp.OIS_Note f,
			   KYP.MDM_JournalBasicInfo fe  	
		 where f.NoteID IN (select DISTINCT c.CFId from  KYP.Eventdates c ) and f.PInID=fe.InfoID and f.Type IN ('Application Review') /*and (fe.IsIgnored != 'true' or fe.IsIgnored != '1')*/ and f.ReasonCode!='null'
		UNION
		select 0 as InfoID, '' as JournalEvent, '' as Type, 0 as PSubFormID, '' as PFieldID, 0 as PartyID,  'RELATED ACCOUNTS' as category,h.ReasonCode as Reasoncode, CASE 
				 WHEN h.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (h.ExternalYesNO = '1' or h.ExternalYesNO = 'Yes') THEN
						'EXTERNAL' 
						WHEN (h.ExternalYesNO = '0' or h.ExternalYesNO = 'NO')  THEN
						'INTERNAL' 
					 ELSE NULL END
			    END As isexternaldesc
			 ,CASE 
				 WHEN h.ExternalYesNO IS NULL THEN 'N/D'
				 ELSE 
					 CASE WHEN (h.ExternalYesNO = '1' or h.ExternalYesNO = 'Yes') THEN
						'Yes' 
						WHEN (h.ExternalYesNO = '0' or h.ExternalYesNO = 'NO')  THEN
						'No' 
					 ELSE NULL END
			    END As isexternalYesNo   
	          ,(select p.LastName+' '+p.FirstName from KYP.OIS_Person p, KYP.OIS_User u where p.PersonID = u.PersonID and u.UserID= h.UserID) as addedby
            , h.DateCreated addedon
		     , h.Name titleFinding
		     , CAST(h.Content AS varchar(MAX)) descFinding
		     , h.Score riskScoreFinding
		     , h.Type typeFinding
		     , h.UpdAction actionFinding
		     , '' fieldFinding
		     , 0 ignoredFinding
		     , h.AutoFlag flagScore
		     , h.DiffScore diffScore
		     , h.Tags tagsFinding
		     , h.DocumentCount docCountFinding
		     , cast(h.CaseID+'' as int) caseIDFinding
			 , h.NoteID findingID
			 , 'Related Accounts' as PStatus
			 , 'Confirmed' isIgnoredMsg
			 , CAST(h.UnformattedContent AS varchar(5000)) findingDescription
		from kyp.OIS_Note h 
		where  h.NoteID IN (select DISTINCT c.CFId from  KYP.Eventdates c ) and h.Type IN ('Related Accounts')
)G


GO

