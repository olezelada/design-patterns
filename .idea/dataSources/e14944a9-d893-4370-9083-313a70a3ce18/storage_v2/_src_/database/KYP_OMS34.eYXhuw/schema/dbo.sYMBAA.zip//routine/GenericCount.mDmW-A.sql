-- =============================================
-- Author:		jzapata
-- Create date: 20170811
-- Description:	Procedure executes whichever query is received as parameter.
--				this will be used to return count results
-- =============================================
CREATE PROCEDURE [dbo].[GenericCount]
	@query varchar(MAX)
AS
BEGIN
	EXEC(@query)

END


GO

