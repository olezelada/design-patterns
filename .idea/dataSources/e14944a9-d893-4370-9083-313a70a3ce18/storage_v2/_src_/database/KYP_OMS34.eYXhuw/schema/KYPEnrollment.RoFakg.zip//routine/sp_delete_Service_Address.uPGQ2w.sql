-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Service_Address] 
@new_Account_Id int

AS
BEGIN
SET NOCOUNT ON;
--**
declare @partiacc int
select @partiacc=partyid from KYPENROLLMENT.pADM_Account where AccountID=@new_Account_Id
update ad set CurrentRecordFlag =0 
from
  KYPEnrollment.pAccount_PDM_Party p  
INNER JOIN KYPEnrollment.pAccount_PDM_Location l ON p.PartyID=l.PartyID INNER JOIN KYPEnrollment.pAccount_PDM_Address ad
ON ad.AddressID=l.AddressID where (p.PartyID=@partiacc or p.ParentPartyID=@partiacc) and (l.Type='Servicing' or l.Type='ServAddrGeoLocation')  and l.CurrentRecordFlag=1 and l.IsDeleted=0

update l set CurrentRecordFlag =0 ,IsDeleted =1
from
 KYPEnrollment.pAccount_PDM_Party p  
INNER JOIN KYPEnrollment.pAccount_PDM_Location l ON p.PartyID=l.PartyID INNER JOIN KYPEnrollment.pAccount_PDM_Address ad
ON ad.AddressID=l.AddressID where (p.PartyID=@partiacc or p.ParentPartyID=@partiacc) and (l.Type='Servicing' or l.Type='ServAddrGeoLocation')  and l.CurrentRecordFlag=1 and l.IsDeleted=0

END

GO

