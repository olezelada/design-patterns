CREATE VIEW  [KYPEnrollment].[Portable_Imaging_Service]
AS
select 'X-Ray(Imaging)' as Service, questionnarie.Description as EquipmentName,number.Number,number.Type,
number.NumberID as NumberID,questionnarie.QuestionID as ServiceID,questionnarie.Value as Value,questionnarie.PartyID as Partyid
from KYPEnrollment.pAccount_PDM_ProviderQuestionnarie questionnarie 
Join KYPEnrollment.pAccount_PDM_Number number on questionnarie.PartyID = Number.Partyid 
where number.Type='numberRay' and questionnarie.Type='RayList'

union all

select 'Mammography' as Service, questionnarie.Description as EquipmentName,number.Number,number.Type,number.NumberID as NumberID,
questionnarie.QuestionID as ServiceID,questionnarie.Value as Value,questionnarie.PartyID as Partyid
from KYPEnrollment.pAccount_PDM_ProviderQuestionnarie questionnarie 
Join KYPEnrollment.pAccount_PDM_Number number on questionnarie.PartyID = Number.Partyid 
where number.Type='numberMammography' and questionnarie.Type='mammographyUsed' 

union all

select 'Ultrasound' as Service, questionnarie.Description as EquipmentName,number.Number,number.Type,number.NumberID as NumberID,
questionnarie.QuestionID as ServiceID,questionnarie.Value as Value,questionnarie.PartyID as Partyid
from KYPEnrollment.pAccount_PDM_ProviderQuestionnarie questionnarie 
Join KYPEnrollment.pAccount_PDM_Number number on questionnarie.PartyID = Number.Partyid 
where number.Type='numberUltrasound' and questionnarie.Type='ultrasoundUsed'

union all

select 'Other('+questionnarie.Value+')' as Service, questionnarie.Description as EquipmentName,'N/A' ,null,null,
questionnarie.QuestionID as ServiceID,questionnarie.Value as Value,questionnarie.PartyID as Partyid
from KYPEnrollment.pAccount_PDM_ProviderQuestionnarie questionnarie
where questionnarie.Type='ServiceOtherList'


GO

