
CREATE TRIGGER [KYP].[AttachmentEntity_DocumentAdded] ON [KYP].[AttachmentEntity]
WITH EXECUTE AS CALLER
FOR INSERT
AS
BEGIN
	Declare @AttachmentEntityDep varchar(100)

	Set @AttachmentEntityDep = (Select AttachmentEntityDep from Inserted where AttachmentEntityDep = 'pADM_Account')
    
    if(@AttachmentEntityDep = 'pADM_Account')
    BEGIN
	    Declare @CreatedBy varchar(100)
        Declare @AttachmentID int
        Declare @AccountID varchar(100)
        Declare @HistoryID int
        Declare @Title varchar(100)
        Declare @AttNumber varchar(100)
        
        Set @AccountID = (Select AttachmentEntityDepID from Inserted where AttachmentEntityDep = 'pADM_Account')
        Set @AttachmentID = (Select AttachmentID from Inserted where AttachmentEntityDep = 'pADM_Account')
        Set @CreatedBy 	= (Select Author from [KYP].[OIS_Attachment] where AttachmentID = @AttachmentID)
        Set @Title		= (Select Title from [KYP].[OIS_Attachment] where AttachmentID = @AttachmentID)
        Set @AttNumber		= (Select Number from [KYP].[OIS_Attachment] where AttachmentID = @AttachmentID)
    	
                INSERT INTO 
                  KYPEnrollment.pAccount_History
                  (
                    AccountID,
                    ActionID,
                    DateCreated,
                    IsDeleted,
                    LastActorUserID,
                    LastActionDate
                  ) 
                  VALUES (
                     @AccountID,
                     47,
                    getdate(),
                    0,
                    @CreatedBy,
                    getdate()  
                  )
                  
                  
                  set @HistoryID = (SELECT SCOPE_IDENTITY());
                  print @HistoryID

              
                INSERT INTO 
                    KYPEnrollment.HIS_Document
                  (
                    HistoryID,
                    DateCreate,
                    IsDeleted,
                    DocNumber,
                    DocTitle
                  ) 
                  VALUES (
                    @HistoryID,
                    getDate(),
                    0,
                    @AttNumber,
                    @Title
                  );
        
                
               -- print (SELECT SCOPE_IDENTITY())

    END
    
END


GO

