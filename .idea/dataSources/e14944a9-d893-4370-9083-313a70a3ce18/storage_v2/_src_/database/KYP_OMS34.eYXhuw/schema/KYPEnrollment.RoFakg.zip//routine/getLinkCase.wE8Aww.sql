

CREATE FUNCTION [KYPEnrollment].[getLinkCase](@CaseID varchar(10))
RETURNS  varchar(500)
  
AS
BEGIN
  Declare @vResult varchar(500)
  Declare @vPartial varchar(500)
  Declare @vCounter integer=0

  DECLARE Cur_ESFS CURSOR FOR
  
  select  CONVERT(VARCHAR(10), CaseIDA)  from KYPEnrollment.Linked_ADM_Case where (CaseIDM=@CaseID) and StatusLinked='Link'
  
  OPEN Cur_ESFS  
  
  SET @vResult='A';
  SET @vPartial='';
  FETCH Cur_ESFS INTO @vPartial
  WHILE (@@FETCH_STATUS = 0)
  BEGIN	
	
	if len(@vPartial) >0
	begin
	  SET @vCounter = @vCounter + 1
	  
	  IF @vCounter = 1 
		BEGIN
			SET @vResult = @vPartial
		END
	  ELSE 
		BEGIN
			SET @vResult = @vResult + ', ' +  @vPartial
	    END
	end
	FETCH Cur_ESFS INTO @vPartial

  END 
  CLOSE Cur_ESFS
  DEALLOCATE Cur_ESFS
  SET @vResult = @vResult 
  return @vResult
END


GO

