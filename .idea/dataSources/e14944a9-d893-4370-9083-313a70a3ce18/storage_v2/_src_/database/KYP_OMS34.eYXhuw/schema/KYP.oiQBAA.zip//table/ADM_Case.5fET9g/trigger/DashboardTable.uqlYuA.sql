
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[DashboardTable] 
   ON  [KYP].[ADM_Case] 
   AFTER INSERT
AS 
BEGIN
	
Declare @caseID INT,
        @UserID int,
        @CurrentlyAssignedToID varchar(50),
        @MajorDisposition varchar(50),
        @DateInitiated smalldatetime,
        @Name varchar(50),
        @Number varchar(50),
        @NoofDays int,
        @Rangename varchar(20),
        @CaseType varchar(25),
        @Q1 int,
        @YY int,
        @YY1 int,
        @Priority int,
        @DateResolved smalldatetime,
        @DaysCurrentStatus int,
        @StatuscodeNumber int,
        @Statuscode int,
        @Type int,
        @Risk varchar(10),
        @MinorDisposition varchar(50),
        @CaseAge varchar(10),
        @UserFullName varchar(100),
        @isPPU bit

	--Added by Sundar for Elk implementation on 25 Feb 2019
	IF Exists(Select VersionID from kyp.OIS_App_Version where StateCode='CA')
	Begin
		Update kyp.ADM_Case Set LastActionDate = Getdate()
		Where CaseID IN (Select CaseID from inserted);
	End

SET @caseID = (select CaseID from inserted);
SET @UserID=(Select CurrentlyAssignedToID from inserted);
Set @CurrentlyAssignedToID =(Select UserID from KYP.OIS_User where PersonID=@UserID)
SET @MajorDisposition=(select CurrentMajorDisposition from inserted);
SET @DateInitiated=(select DateInitiated from inserted);
SET @Name=(Select ProviderName from inserted);
SET @Number=(select Number from inserted); 
set @Type=(Select Type from inserted);
set @MinorDisposition= (select CurrentMinorDisposition from inserted)
SET @CaseType=(Select ApplnType from inserted);
Set @NoofDays=Datediff(d,@DateInitiated,getdate())
set @Rangename=KYP.AuditDays(@DateInitiated)
set @Q1= Datepart(qq,@DateInitiated)
set @YY= Datepart(yyyy,@DateInitiated)
set @YY1=Right(Datepart(yy,@DateInitiated),2)
set @Priority= (select Priority from inserted)
set @Risk= (select Description from KYP.LK_Screening where TypeID=3 and SortOder=@Priority)
set @DateResolved =(select DateResolved from inserted)
set  @DaysCurrentStatus= Datediff(d,@DateResolved,getdate())
Set @StatuscodeNumber=(select StatusCodeNumber from inserted);
set @caseAge=  ABS(DATEDIFF(d, @DateInitiated, GETDATE()))
set @UserFullName = ( Select FullName from KYP.OIS_User where PersonID=@UserID)
set @isPPU = (select IsPPURequired from inserted)
if @StatuscodeNumber=10 
begin 
set @Statuscode= 1
end
else if @StatuscodeNumber=11
begin
set @Statuscode=1
end
else if @StatuscodeNumber=13
begin
set @Statuscode=1
end
else
begin
set @Statuscode=2
end
insert into KYP.DSH_DashBoardTable (CaseID,CurrentlyAssignedToID,CurrentMajorDisposition,DateInitiated,ProviderName,AgeByDays,Range,CaseType,CaseNumber,Quarter,Year,LasttwoDigYear,Priority,DaysCurrentStatus,DateResolved,Statuscode,CurrentMinorDisposition,isCompleted,IsPPURequired) values (@caseID,@CurrentlyAssignedToID,@MajorDisposition,@DateInitiated,@Name,@NoofDays,@Rangename,@CaseType,@Number,@Q1,@YY,@YY1,@Priority,@DaysCurrentStatus,@DateResolved,@Statuscode,@MinorDisposition,0,@isPPU) 

update KYP.ADM_Case set Risk=@Risk,caseAge=@caseAge where CaseID=@caseID
update KYP.ADM_Case set CurrentlyAssignedToName=@CurrentlyAssignedToID where CaseID=@caseID
update KYP.ADM_Case set UserFullName=@UserFullName where CaseID=@caseID

END


--select * from KYP.LK_Screening

GO

