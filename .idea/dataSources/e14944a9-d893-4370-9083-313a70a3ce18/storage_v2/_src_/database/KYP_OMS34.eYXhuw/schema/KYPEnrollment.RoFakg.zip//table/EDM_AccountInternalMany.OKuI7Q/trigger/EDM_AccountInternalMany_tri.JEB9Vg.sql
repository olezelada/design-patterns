

CREATE TRIGGER [KYPEnrollment].[EDM_AccountInternalMany_tri] ON [KYPEnrollment].[EDM_AccountInternalMany]
WITH EXECUTE AS CALLER
FOR INSERT
AS
BEGIN

       --Updated on 2/16/18
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 
	IF @Row_Updation_Source = 'Trigger_return' AND Update(Row_Updation_Source)
	BEGIN
		PRINT 'Return Back to Proc'
		RETURN
	END


	Declare @IsTemporal bit
	Declare @AccountID int
    Declare @AccountInternalUseID int
    Declare @Category varchar(max)
    Declare @CategoryOfService varchar(max)
    
    Select @AccountInternalUseID = AccountInternalUseID from Inserted
    Select @IsTemporal = IsTemporal from Inserted
    Select @AccountID = AccountID from [KYPEnrollment].[EDM_AccountInternalUse] where  AccountInternalUseID = @AccountInternalUseID
    
    if((@IsTemporal = 0 or @IsTemporal is null) and @AccountID>0)
    BEGIN
    	Declare @CodeType varchar(10)
        Declare @CodeDescription varchar(250)
        Declare @ModifiedType varchar(20)
        Declare @HistoryID int
        
        Select @CodeType = CodeType from Inserted
        Select @CodeDescription = CodeDescription from Inserted
                
        if(@CodeType='Sanction')
        Begin
        	set @ModifiedType = 'Sanction Code'
        End
        Else if(@CodeType='Specialty')
        Begin
        	set @ModifiedType = 'Lab Specialty Code'
        End
        Else if(@CodeType='Category')
        Begin
        	set @ModifiedType = 'Category of Service'
        End   
                INSERT INTO 
                  KYPEnrollment.pAccount_History
                  (
                    AccountID,
                    ActionID,
                    DateCreated,
                    IsDeleted,
                    LastActorUserID,
                    LastActionDate
                  ) 
                  VALUES (
                     @AccountID,
                     43,
                    getdate(),
                    0,
                    (select top 1 CreatedBy from Inserted),
                    getdate()  
                  )
                  
                  
                  set @HistoryID = (SELECT SCOPE_IDENTITY());
                  print @HistoryID

              
              
              INSERT INTO 
                  KYPEnrollment.HIS_MadeChange
                (
                  HistoryID,
                  Field,
                  NewValue,
                  DateCreate,
                  OldValue
                ) 
                VALUES (
                  @HistoryID,
                  @ModifiedType,
                  @CodeDescription,
                  getDate(),
                  ''                 
                )
                
               -- print (SELECT SCOPE_IDENTITY())

    END
    SELECT @AccountInternalUseID=[AccountInternalUseID] FROM [KYPEnrollment].[EDM_AccountInternalUse] WHERE AccountID =@AccountID
	  
	  SELECT @Category = LTRIM(RTRIM(STUFF (( SELECT ', ' + CodeIdentification + ' - ' + CodeDescription  AS [text()]
	  FROM KYPEnrollment.EDM_AccountInternalMany
	  Where AccountInternalUseID = @AccountInternalUseID AND CodeType = 'Category'
      FOR XML PATH('')),1,1,'')))
      PRINT @AccountInternalUseID
      PRINT @Category
      UPDATE [KYPEnrollment].[AccountSearch]
      SET
			CategoryOfService = @Category
      WHERE AccountID = @AccountID;
END


GO

