
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Insurance recive 3 parametros
-- @partyIdPortal id party old del portal,	@partyIdOMS new party id  de Account, @lastActionUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Insurance]
	@partyIdPortal INT,
	@partyIdOMS INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	IF((SELECT COUNT([InsuranceID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Insurance] WHERE PartyID = @partyIdPortal)>0)
	BEGIN
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Insurance]
	([PartyID] ,
	[PolicyNumber] ,
	[Type] ,
	[IssuanceDate] ,
	[ExpirationDate] ,
	[MinimumOccurrence] ,
	[AnualAggregate] ,
	[LastAction],
	[LastActionDate],
	[LastActorUserID]	,
	[LastActionApprovedBy],
	[CurrentRecordFlag])
	SELECT @partyIdOMS
	,[PolicyNumber]
	,[Type]
	,[IssuanceDate]
	,[ExpirationDate]
	,[MinimumOccurrence]
	,[AnualAggregate]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Insurance] WHERE PartyID = @partyIdPortal

	SELECT @message = 'New Insurance ' + CONVERT(char(10), 'Insurance copy')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	END					
END


GO

