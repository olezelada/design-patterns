/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMMCARENBR]
(
  @PartyID int
 ,@MCARE_NUM varchar(15) =NULL
 ,@DateModified Datetime=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
)
as begin 

INSERT INTO [KYP].[PDM_MCARENBR]
           ([PartyID]
           ,[MCARE_NUM]
           ,[DateModified]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted])
     VALUES
           (@PartyID
           ,@MCARE_NUM
           ,@DateModified
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DeletedBy
           ,@DateDeleted)

	return IDENT_CURRENT('[KYP].[PDM_MCARENBR]')

end


GO

