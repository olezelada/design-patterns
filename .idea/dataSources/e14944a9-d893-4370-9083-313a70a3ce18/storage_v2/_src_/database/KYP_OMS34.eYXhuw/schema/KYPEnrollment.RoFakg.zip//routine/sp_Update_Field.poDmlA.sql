

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Field]
	@acc_table_name VARCHAR(100),
	@en_db_column VARCHAR(100), 
	@data VARCHAR(MAX), 
	@acc_PK VARCHAR(100), 
	@acc_PK_value INT,
	@is_text_date CHAR(1),
	@stored_value VARCHAR(MAX),
	@last_action_user_id VARCHAR(100),
	@action_taken VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @update NVARCHAR(MAX),@last_action VARCHAR(1),@count_like INT
	Declare @ParamDefinition AS NVarchar(2000), @accPKvalue varchar(100)
	DECLARE @cond VARCHAR(MAX)

	Set @ParamDefinition = '@accPKvalue INT'
	set @accPKvalue = CONVERT(VARCHAR(100),@acc_PK_value); 

	SET @last_action = 'U';

	SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column
	SET @cond = @acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);

	IF @action_taken = 'Deleted'
	BEGIN
	 
	 SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ CONVERT(VARCHAR(100),@acc_PK_value);
     EXECUTE(@update)
	END
	ELSE
	BEGIN
	    
		IF(@is_text_date = '1')
		BEGIN
			IF @data LIKE '%'+CHAR(39)+'%'
			BEGIN 
			SELECT @data = REPLACE(@data,CHAR(39),'''+CHAR(39)+''')
			END
			IF @stored_value ='checkbox'
			BEGIN
			  IF @data IS NULL OR @data='' 
			  BEGIN
				--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
				SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
			  END
			  ELSE
			  BEGIN
			    -- Check condition.
				IF (@en_db_column = 'Languages')
				BEGIN
					SET @update = @update +' = '''+@data+''' WHERE '+@acc_PK+' = @accPKvalue';
				END
				ELSE
				BEGIN
					--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = 1 WHERE '+@acc_PK+' = '+ '@accPKvalue';
					SET @update = @update +' = 1 WHERE '+@acc_PK+' = @accPKvalue';
				END
			  END
			END
			ELSE
			BEGIN
			 IF @data =''  
			  BEGIN			
			      --SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
				  SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
			  END
			  ELSE  
			  BEGIN
			     -- SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = '''+@data+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';		
				   			     
				  IF (@en_db_column = 'SoleOwner' OR @en_db_column = 'IsCorporation')
				  BEGIN					
					 IF (@data='No')
					 BEGIN
						set @data = '0'
					 END
					 
					 IF (@data='Yes')
					 BEGIN
						set @data = '1'
					 END						
				  END	
				  SET @update = @update +' = '''+@data+''' WHERE '+@acc_PK+' = @accPKvalue';	
			  END  
			END

			EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
			
			--EXECUTE(@update)

		END
		ELSE
		BEGIN
			 IF @stored_value ='checkbox'
			  BEGIN
				  IF @data IS NULL OR @data='' 
				  BEGIN
					--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
					SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
				  END
				  ELSE
				  BEGIN
					--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = 1 WHERE '+@acc_PK+' = '+ '@accPKvalue';
					SET @update = @update +' = 1 WHERE '+@acc_PK+' = @accPKvalue';
				  END
			  END
			  ELSE
			  BEGIN
                IF @data =''  
			    BEGIN			
					-- Check condition.
					IF (@en_db_column = 'AgeFrom' or @en_db_column = 'AgeTo')
					BEGIN
						SET @update = @update +' = 0 WHERE '+@acc_PK+' = @accPKvalue';
					END
					ELSE
					BEGIN
						--SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = NULL WHERE '+@acc_PK+' = '+ '@accPKvalue';
						SET @update = @update +' = NULL WHERE '+@acc_PK+' = @accPKvalue';
					END	
			    END
			    ELSE
			    BEGIN
			      --SET @update = 'UPDATE KYPEnrollment.'+@acc_table_name+' SET '+@en_db_column+' = '+@data +' WHERE '+@acc_PK+' = '+ '@accPKvalue';
				   SET @update = @update +' = '''+@data+''' WHERE '+@acc_PK+' = @accPKvalue';
			    END			 
			 END	
			 EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
			--	EXECUTE(@update)
		END
	END
	
	SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastAction '+' = '''+@last_action+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
	 EXEC sp_executesql @update,  @ParamDefinition,@acc_PK_value
	--EXECUTE(@update);
	
	SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionDate '+' = '''+CONVERT(VARCHAR(100),ISNULL(CASE WHEN CONVERT(DATE, GETDATE()) = '1900-01-01' THEN '' ELSE CONVERT(VARCHAR(100), GETDATE()) END, ''))+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
	 EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
	--EXECUTE(@update);
	
	DECLARE @action_user VARCHAR(50)
	
	SELECT @action_user = COLUMN_NAME 
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=@acc_table_name AND (COLUMN_NAME = 'LastActorUserID' OR COLUMN_NAME = 'LastActionUserID')
    
      --mvc--
    declare @antes varchar(100)
    set @antes=''
    IF @action_user = 'LastActorUserID'
    BEGIN
        if @acc_table_name='pAccount_PDM_PaymentDetail'
         begin
           select @antes=LastActorUserID from kypenrollment.pAccount_PDM_PaymentDetail where PaymentDetailID=  @acc_PK_value
           if @antes<>'system' 
             begin
               SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActorUserID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+  CONVERT(VARCHAR(100),@acc_PK_value);
		       EXECUTE(@update);
             end
            else
              print 'lastactoruserid not updated'
         end
        else
          begin  
            SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActorUserID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+  CONVERT(VARCHAR(100),@acc_PK_value);
		    EXECUTE(@update);
		   end 
    END
    ---
   
    ELSE
    BEGIN
      IF @action_user = 'LastActionUserID'
      BEGIN   
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionUserID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
	  END	
    END
	
	SELECT @action_user = COLUMN_NAME 
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME=@acc_table_name AND (COLUMN_NAME = 'LastActionApprovedBy' OR COLUMN_NAME ='LastActionApprovedByUsedID')
    
    IF @action_user = 'LastActionApprovedBy'
    BEGIN
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionApprovedBy '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
    END
    ELSE
    BEGIN
      IF @action_user = 'LastActionApprovedByUsedID'
      BEGIN
        SET @update = 'UPDATE  KYPEnrollment.'+@acc_table_name+' SET LastActionApprovedByUsedID '+' = '''+@last_action_user_id+''' WHERE '+@acc_PK+' = '+ '@accPKvalue';
		EXEC sp_executesql @update,  @ParamDefinition, @accPKvalue
		--EXECUTE(@update);
	  END	
    END
END


GO

