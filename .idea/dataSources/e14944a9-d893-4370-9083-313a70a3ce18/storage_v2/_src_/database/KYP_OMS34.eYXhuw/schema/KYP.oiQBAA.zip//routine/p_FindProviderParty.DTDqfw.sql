
-- =============================================
-- Author:		Yogesh Sharma
-- Create date: Aug 09 2012
-- Description:	Finds Provider PartyID based on Name and Application Num
-- =============================================
CREATE PROCEDURE [KYP].[p_FindProviderParty]
	-- Add the parameters for the stored procedure here
	@Name varchar(100) 	
	,@NPI varchar(10) = NULL
	,@ProvNumber varchar(20) = NULL
	,@DEA varchar(11) = NULL
	,@CurrentModule smallint = NULL
	
AS
BEGIN
	SET NOCOUNT ON;
	
	declare @PartyID int
	/********Do a Name+NPI + DEA + P_ID match**********/
	if exists (				
	select 1
	from KYP.PDM_Party A
	inner join KYP.PDM_Provider B
		on A.PartyID = B.PartyID 
		and ISNULL(A.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and A.Name = @Name
		and ISNULL(B.NPI, 0) = ISNULL(convert(int, @NPI),0)
		and B.ProvNumber = @ProvNumber
		and ISNULL(B.DEA,'0') = ISNULL(@DEA,'0')
		and A.IsEnrolled = 1
	)
	begin	
	select @PartyID = A.PartyID
	from KYP.PDM_Party A
	inner join KYP.PDM_Provider B
		on A.PartyID = B.PartyID 
		and ISNULL(A.IsDeleted,0) = 0 
	where ISNULL(A.CurrentModule,0) = ISNULL(@CurrentModule,0)	
		and A.Name = @Name
		and ISNULL(B.NPI, 0) = ISNULL(convert(int, @NPI),0)		
		and B.ProvNumber = @ProvNumber
		and ISNULL(B.DEA,'0') = ISNULL(@DEA,'0')
		and A.IsEnrolled = 1
	return @PartyID	
	end	
	else 
	return -1   	
END


GO

