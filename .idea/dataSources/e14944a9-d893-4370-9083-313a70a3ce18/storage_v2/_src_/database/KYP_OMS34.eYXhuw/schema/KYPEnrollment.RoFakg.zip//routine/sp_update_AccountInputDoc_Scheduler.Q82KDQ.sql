




CREATE PROCEDURE [KYPEnrollment].[sp_update_AccountInputDoc_Scheduler]
@acc_party_id INT,
@Username varchar(100)

AS
Declare @party_id int

BEGIN
set @party_id=(select PartyID from KYPEnrollment.pADM_Account where AccountID=@acc_party_id )

INSERT INTO [KYPEnrollment].[AccountInputDocSch]
               ([AccountID]
               
           ,[PartyID]
           ,[ProvNameScan]
           ,[Analyst]
           ,[AnalystDT]
           ,[Reviewer]
           ,[ReviewerDT]
           ,[Supervisor]
           ,[SupervisorDT]
           ,[NPI]
           ,[OwnerNo]
           ,[SerLocNo]
           ,[ProviderType]
           ,[LegalName]
           ,[SSN]
           ,[EffBDT]
           ,[EffEDT]
           ,[EIN]
           ,[TINUpdDate]
           ,[TINUpdType]
           ,[ProvLocTypeCd]
           ,[DBAName]
           ,[Phone1]
           ,[AdsL1]
           ,[AdsL2]
           ,[City]
           ,[Acc_State]
           ,[ZipPlus4]
           ,[MAdsL1]
           ,[MAdsL2]
           ,[MCity]
           ,[MState]
           ,[MZipPlus4]
           ,[SAdsL1]
           ,[SAdsL2]
           ,[SCity]
           ,[SState]
           ,[SZipPlus4]
           ,[OutOfStateInd]
           ,[AppDT]
           ,[ProvTypeDetail]
           ,[PracticeCode]
           ,[StatusAcc]
           ,[StatusBgnDt]
           ,[RejResCode]
           ,[Number]
           ,[EffDT]
           ,[CliaNumber]
           ,[SpecProcTypeCode]
           ,[ProvCode]
           ,[ProvCodeDT]
           ,[ReEnrollIn]
           ,[ScodeIdty1]
           ,[ScodeIdty2]
           ,[ScodeIdty3]
           ,[ScodeIdty4]
           ,[ScodeIdty5]
           ,[ScodeIdty6]
           ,[ScodeIdty7]
           ,[ScodeIdty8]
           ,[TaxnC1]
           ,[TaxnC2]
           ,[TaxnC3]
           ,[TaxnC4]
           ,[TaxnC5]
           ,[TaxnC6]
           ,[TaxnC7]
           ,[CCodeIdty1]
           ,[CCodeEffDT1]
           ,[CCodeExpDT1]
           ,[CCodeIdty2]
           ,[CCodeEffDT2]
           ,[CCodeExpDT2]
           ,[CCodeIdty3]
           ,[CCodeEffDT3]
           ,[CCodeExpDT3]
           ,[CCodeIdty4]
           ,[CCodeEffDT4]
           ,[CCodeExpDT4]
           ,[CCodeIdty5]
           ,[CCodeEffDT5]
           ,[CCodeExpDT5]
           ,[CCodeIdty6]
           ,[CCodeEffDT6]
           ,[CCodeExpDT6]
           ,[CCodeIdty7]
           ,[CCodeEffDT7]
           ,[CCodeExpDT7]
           ,[CCodeIdty8]
           ,[CCodeEffDT8]
           ,[CCodeExpDT8]
           ,[CCodeIdty9]
           ,[CCodeEffDT9]
           ,[CCodeExpDT9]
		   ,[CCodeIdty10]
           ,[CCodeEffDT10]
           ,[CCodeExpDT10]
		   ,[CCodeIdty11]
           ,[CCodeEffDT11]
           ,[CCodeExpDT11]
		   ,[CCodeIdty12]
           ,[CCodeEffDT12]
           ,[CCodeExpDT12]
		   ,[CCodeIdty13]
           ,[CCodeEffDT13]
           ,[CCodeExpDT13]
		   ,[CCodeIdty14]
           ,[CCodeEffDT14]
           ,[CCodeExpDT14]
		   ,[CCodeIdty15]
           ,[CCodeEffDT15]
           ,[CCodeExpDT15]
           ,[Spec_C1]
           ,[SpecCertDT1]
           ,[Spec_C2]
           ,[SpecCertDT2]
           ,[Spec_C3]
           ,[SpecCertDT3],
           [GRPIDTY]  ,
           [LABStat]  ,
           [LABEFFDT]  ,
           [DOCNO]   ,
           [userName]
           )
 select  DISTINCT x.AccountID,x.PartyID, x.ProvNameScan,
 Analyst,
 CONVERT( varchar(10), x.AnalystDate, 101) AS AnalystDT,
 Reviewer,
 CONVERT( varchar(10), x.ReviewerDate, 101) AS ReviewerDT,
 Supervisor,
 CONVERT( varchar(10), x.SupervisorDate, 101) AS SupervisorDT,
NPI,OwnerNo,ServiceLocationNo as SerLocNo ,ProviderTypeCode + '- '+ProviderType AS ProviderType,LegalName,

SSN,
CASE CONVERT(varchar(10),X.EffectiveBeingDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),X.EffectiveBeingDate,101) END AS EffectiveBeingDate,
CASE CONVERT(varchar(10),x.EffectiveEndDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveEndDate,101) END AS EffEndDT,


EIN,
CASE CONVERT(varchar(10),x.TINUpdateDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.TINUpdateDate,101) END AS TINUpdateDate,

TINUpdateType,
 ProvLocTypeCd,DBAName,Phone1,AddressLine1 as AdsL1,AddressLine2 as AdsL2,
 City,Acc_State,ZipPlus4,MAddressLine1 AS MAdsL1,MAddressLine2 as MAdsL2,MCity,MState,MZipPlus4,
SAddressLine1 as SAdsL1 ,SAddressLine2 as SAdsL2,SCity,SState,SZipPlus4,OutOfStateInd,--PSS055 PROVIDER DETAIL SCREEN
CONVERT( varchar(10), x.ApplicationDate, 101) AS  AppDT,ProviderTypeCode + '- '+ProviderType AS ProvTypeDetail, PracticeCode,StatusAcc,
CONVERT( varchar(10), x.StatusBeginDate, 101) AS  StatusBgnDt,RejectReasonCode AS RejResCode,--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
 --CodeIdentificationCateg,
--CodeDateEffDate,
--CodeDateExpDate,
Number,
CASE CONVERT(varchar(10),x.EffectiveDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.EffectiveDate,101) END AS  EffDT,


x.CliaNumber,x.SpecProcTypeCode,x.ProvisionalCode as ProvCode,
CASE CONVERT(varchar(10),x.ProvisionalCodeDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),x.ProvisionalCodeDate,101) END AS ProvCodeDT,

ReenrollmentIndicator as ReEnrollIn,
--PSS038 PHYSICIAN CERTIFICATION Speciality_Code,
 SCodeIdentification1 as ScodeIdty1,SCodeIdentification2 as ScodeIdty2 ,SCodeIdentification3  as ScodeIdty3,SCodeIdentification4  as ScodeIdty4,SCodeIdentification5  as ScodeIdty5,
 SCodeIdentification6 as  ScodeIdty6,SCodeIdentification7 as ScodeIdty7 ,SCodeIdentification8 as ScodeIdty8,
  TaxonomyCode1 as TaxnC1,TaxonomyCode2 as TaxnC2,TaxonomyCode3 as TaxnC3,TaxonomyCode4 as TaxnC4,
  TaxonomyCode5 as TaxnC5,TaxonomyCode6 as TaxnC6,TaxonomyCode7 as TaxnC7,
 CCodeIdentification1 as CCodeIdty1,CONVERT( varchar(10), CAST (CCodeDateEffDate1 AS DATE), 101) AS  CCodeEffDT1 ,CONVERT( varchar(10), CAST(CCodeDateExpDate1 AS DATE), 101) AS CCodeExpDT1
,CCodeIdentification2 as CCodeIdty2,CONVERT( varchar(10), CAST (CCodeDateEffDate2 AS DATE), 101) AS CCodeEffDT2 ,CONVERT( varchar(10), CAST(CCodeDateExpDate2 AS DATE), 101) AS CCodeExpDT2
,CCodeIdentification3 as CCodeIdty3,CONVERT( varchar(10), CAST (CCodeDateEffDate3 AS DATE), 101) AS CCodeEffDT3 ,CONVERT( varchar(10), CAST(CCodeDateExpDate3 AS DATE), 101) AS CCodeExpDT3
,CCodeIdentification4 as CCodeIdty4,CONVERT( varchar(10), CAST (CCodeDateEffDate4 AS DATE), 101) AS CCodeEffDT4 ,CONVERT( varchar(10), CAST(CCodeDateExpDate4 AS DATE), 101) AS CCodeExpDT4
,CCodeIdentification5 as CCodeIdty5,CONVERT( varchar(10), CAST (CCodeDateEffDate5 AS DATE), 101) AS CCodeEffDT5 ,CONVERT( varchar(10), CAST(CCodeDateExpDate5 AS DATE), 101) AS CCodeExpDT5
,CCodeIdentification6 as CCodeIdty6,CONVERT( varchar(10), CAST (CCodeDateEffDate6 AS DATE), 101) AS CCodeEffDT6 ,CONVERT( varchar(10), CAST(CCodeDateExpDate6 AS DATE), 101) AS CCodeExpDT6
,CCodeIdentification7 as CCodeIdty7,CONVERT( varchar(10), CAST (CCodeDateEffDate7 AS DATE), 101) AS CCodeEffDT7 ,CONVERT( varchar(10), CAST(CCodeDateExpDate7 AS DATE), 101) AS CCodeExpDT7
,CCodeIdentification8 as CCodeIdty8,CONVERT( varchar(10), CAST (CCodeDateEffDate8 AS DATE), 101) AS CCodeEffDT8 ,CONVERT( varchar(10), CAST(CCodeDateExpDate8 AS DATE), 101) AS CCodeExpDT8
,CCodeIdentification9 as CCodeIdty9,CONVERT( varchar(10), CAST (CCodeDateEffDate9 AS DATE), 101)AS CCodeEffDT9 ,CONVERT( varchar(10), CAST(CCodeDateExpDate9 AS DATE), 101) AS CCodeExpDT9

,CCodeIdentification10 as CCodeIdty10,CONVERT( varchar(10), CAST (CCodeDateEffDate10 AS DATE), 101) AS  CCodeEffDT10 ,CONVERT( varchar(10), CAST(CCodeDateExpDate10 AS DATE), 101) AS CCodeExpDT10
,CCodeIdentification11 as CCodeIdty11,CONVERT( varchar(10), CAST (CCodeDateEffDate11 AS DATE), 101) AS  CCodeEffDT11 ,CONVERT( varchar(10), CAST(CCodeDateExpDate11 AS DATE), 101) AS CCodeExpDT11
,CCodeIdentification12 as CCodeIdty12,CONVERT( varchar(10), CAST (CCodeDateEffDate12 AS DATE), 101) AS CCodeEffDT12 ,CONVERT( varchar(10), CAST(CCodeDateExpDate12 AS DATE), 101) AS CCodeExpDT12
,CCodeIdentification13 as CCodeIdty13,CONVERT( varchar(10), CAST (CCodeDateEffDate13 AS DATE), 101) AS CCodeEffDT13 ,CONVERT( varchar(10), CAST(CCodeDateExpDate13 AS DATE), 101) AS CCodeExpDT13
,CCodeIdentification14 as CCodeIdty14,CONVERT( varchar(10), CAST (CCodeDateEffDate14 AS DATE), 101) AS CCodeEffDT14 ,CONVERT( varchar(10), CAST(CCodeDateExpDate14 AS DATE), 101) AS CCodeExpDT14
,CCodeIdentification15 as CCodeIdty15,CONVERT( varchar(10), CAST (CCodeDateEffDate15 AS DATE), 101) AS CCodeEffDT15 ,CONVERT( varchar(10), CAST(CCodeDateExpDate15 AS DATE), 101) AS CCodeExpDT15


,Speciality_Code1 AS Spec_C1,CONVERT( varchar(10), CAST(SpecCertDate1 AS DATE), 101) AS SpecCertDT1
,Speciality_Code2 AS Spec_C2,CONVERT( varchar(10), CAST(SpecCertDate2 AS DATE), 101) AS SpecCertDT2
,Speciality_Code3 AS Spec_C3,CONVERT( varchar(10), CAST(SpecCertDate3 AS DATE), 101) AS SpecCertDT3 
 ,GRPIDTY,
 LABStat,LABEFFDT,
 AccountNumber AS ACCNo
,@Username
 from (


SELECT 
A.AccountID As AccountID,
U1.FullName AS Analyst,
U1.LastActionDate AS AnalystDate,
u2.FullName AS Supervisor ,
U2.LastActionDate AS SupervisorDate,
U3.FullName AS Reviewer,
U3.LastActionDate AS ReviewerDate,
A.LastActionDate,
A.IsDeleted,A.DateCreated,A.AccountUpdatedBy,
A.PartyID ,
--PED PROVIDER MASTER FILE INPUT DOCUMENT
A.LegalName AS ProvNameScan,
--Document Review and Approve Signatures
--PMF Transaction Signatures
A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
A.ProviderType,
--PSS059 OWNER SCREEN
A.LegalName,
A.SSN,
B.EffectiveBeingDate,
B.EffectiveEndDate,
A.EIN,
C.TINUpdateDate,
C.TINUpdateType,
c.ProvisionalCode AS ProvLocTypeCd,
D.CodeIdentification,
--PSS070 LOCATION SCREEN 
A.DBAName,
Case when(R.Type='Individual Ownership') then 
E.Phone1 ELSE
Q.Phone1
END
  AS Phone1,

-- TO PAY ADDRESS
--F.AddressLine1,F.AddressLine2,F.City,F.State as Acc_State,F.Zip+'-'+F.ZipPlus4 AS ZipPlus4, Changed the zip format PI-350
F.AddressLine1,F.AddressLine2,F.City,F.State as Acc_State,F.ZipPlus4 AS ZipPlus4,
--MAILING ADDRESS
--G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.State AS MState,G.Zip+'-'+G.ZipPlus4 AS MZipPlus4,Changed the zip format PI-350
G.AddressLine1 AS MAddressLine1,G.AddressLine2 AS MAddressLine2,G.City AS MCity,G.State AS MState,G.ZipPlus4 AS MZipPlus4,
--SERVICE ADDRESS
--H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.State AS SState,H.Zip+'-'+H.ZipPlus4 AS SZipPlus4,Changed the zip format PI-350
H.AddressLine1 AS SAddressLine1,H.AddressLine2 AS SAddressLine2,H.City AS SCity,H.State AS SState,H.ZipPlus4 AS SZipPlus4,
C.OutOfStateInd,
--PSS055 PROVIDER DETAIL SCREEN
A.ApplicationDate,
A.ProviderType AS ProviderTypeDETAIL,
C.PracTypeCode1+C.PracTypeCode2 AS PracticeCode,


A.StatusAcc,
A.StatusBeginDate,
C.RejectReasonCode,
--CATEGORIES OF SERVICES(CATEGORY, BEGIN DATE, ENDDATE):
--I.CodeIdentification AS CodeIdentificationCateg,
--I.CodeDateEffDate,
--I.CodeDateExpDate,
J.Number,
J.EffectiveDate, --as LIC_EFF_DT,
K.CliaNumber, --as CLIA_NO,
C.SpecProcTypeCode, --as SPEC_PROC_TYP,
C.CHDPCode,-- as CHDP_PROV_NO,
C.ProvisionalCode,
C.ProvisionalCodeDate,
A.ReenrollmentIndicator,
--PSS038 PHYSICIAN CERTIFICATION
L.Speciality_Code,
Case when(A.AccountType='G') then
'ADD/DEL MEMBRS TO GRP SHFT-PF6(PSS036-GRP MEMBRS)' 
ELSE 
'ADD/DELETE GRPS TO MEMBER PF5(PSS035-MEMBER GRPS)'
END AS GRPIDTY,

--C.LabSpecCode+ '-'+C.LabSpecCodeDesc AS LABStat, Since we are storing data in LabStatusCode not in LabSpecCode hence chaged.
C.LabStatusCode AS LABStat,
--C.LabSpecCodeEfDate as LABEFFDT,Since we are storing data in LabStatusCodeDate not in LabStatusCodeDate hence chaged.
convert(varchar(10),C.LabStatusCodeDate,101) as LABEFFDT,
A.AccountNumber
 






 from KYPEnrollment.pADM_Account A 
  left join
  (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('ReviewerS','Reviewer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U1 on U1.AccountID=A.AccountID 
   
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('SupervisorR','SupervisorS'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U2 on U2.AccountID=A.AccountID
   left join 
   
   (SELECT * FROM  (select ACC.AccountID, LastActorUserID, LastActionDate,ROL.RoleName,ROL.UserID,ROL.FullName, ROW_NUMBER()OVER(PARTITION BY ACC.AccountID ORDER BY LastActionDate DESC)AS ROW
   from KYPEnrollment.pAccount_History Acc
INNER JOIN
   (select DISTINCT x.UserID,y.RoleName,z.FullName from KYP.OIS_JT_UserRole x inner join KYP.OIS_Role  y
   on x.RoleID= y.RoleID inner join KYP.OIS_User z on x.UserID=z.UserID
   where y.RoleName in('ConfirmerS','Confirmer'))ROL
   ON ACC.LastActorUserID =ROL.UserID)X
   WHERE X.ROW=1) U3 on U3.AccountID=A.AccountID
 
LEFT OUTER JOIN 
KYPEnrollment.pAccount_Owner B ON A.AccountID=B.AccountID
LEFT OUTER JOIN
KYPEnrollment.EDM_AccountInternalUse C ON A.AccountID=C.AccountID --and C.CurrentRecordFlag = 1 Reomved since protal data was not setting.
LEFT OUTER JOIN KYPEnrollment.EDM_AccountInternalMany D ON C.AccountInternalUseID=D.AccountInternalUseID AND D.CodeType = 'SanctionTxt'
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person E ON A.PartyID=E.PartyID 
--This is for Pay-to Address Details
left outer join 
(select F.AddressLine1,F.AddressLine2,F.City,F.State,F.Zip, F.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address F 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on F.AddressID = X.AddressID 
	 and X.Type='Pay-to'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = a.PartyID 
--This is for Service Address Details	 
left outer join 	 
	(select H.AddressLine1,H.AddressLine2,H.City,H.State,H.Zip,H.ZipPlus4,x.PartyID,x.Phone1,H.County  from KYPEnrollment.pAccount_PDM_Address H 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on H.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)H
	 on H.PartyID = a.PartyID 
--This is for Mailing Address Details
left outer join(select G.AddressLine1,G.AddressLine2,G.City,G.State,G.Zip,G.ZipPlus4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address G
inner join KYPEnrollment.pAccount_PDM_Location X
	 on G.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)G
	 on G.PartyID = a.PartyID	 
	 
	 
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address F ON F.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Pay-to' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address G ON G.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Mailing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Address H ON H.AddressID=(Select AddressID from KYPEnrollment.pAccount_PDM_Location where Type='Servicing' AND  PartyID=A.PartyID AND CurrentRecordFlag=1)
--LEFT  OUTER JOIN KYPEnrollment.EDM_AccountInternalMany I ON I.AccountInternalUseID=C.AccountInternalUseID AND C.AccountID=A.AccountID AND I.CodeType = 'Category'
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Number J ON J.PartyID=A.PartyID AND J.Type='Professional License' AND J.CurrentRecordFlag=1
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Clia K ON K.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Speciality L ON L.PartyID=A.PartyID and  L.IsPrimary=NULL and L.CurrentRecordFlag=1
--LEFT  OUTER JOIN KYPEnrollment.pAccount_RenderingAffiliation M ON M.AccountID=A.AccountID and A.AccountType='NMP'
LEFT  OUTER JOIN KYPEnrollment.pADM_AccountStatus N ON N.AccountID=A.AccountID and N.CurrentRecordFlag=1
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Provider O ON O.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Person P ON P.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Organization Q ON Q.PartyID=A.PartyID
LEFT  OUTER JOIN KYPEnrollment.pAccount_PDM_Party R ON R.PartyID=A.PartyID

)x
left join (
select AccountID, SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
   TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14,CCodeIdentification15,
CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
CCodeDateEffDate10,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,
CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
CCodeDateExpDate10,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3

  from(    
   
   -- DH-SANCTION-TXT-2019 occurs 8 times
                -- 8 Occurance for 'CodeIdentification' from "KYPEnrollment.EDM_AccountInternalMany" table where CodeType = 'Sanction'
              SELECT C.AccountId, CONVERT(varchar(20),CodeIdentification) as CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
    inner join KYPEnrollment.EDM_AccountInternalUse C 
    on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
    where AccountID=@acc_party_id
    
       UNION All
        SELECT A.Accountid, CONVERT(varchar(MAx), P.Speciality_Code) /*Taxonmy Code will be displayed instead of Description*/
         ,'TaxonomyCode'+CONVERT(varchar(10), ROW_NUMBER()  over(partition by A.Accountid order by  SpecialityID desc) ) seq
                FROM KYPEnrollment.pAccount_PDM_Speciality P
                inner join KYPEnrollment.pADM_Account A on p.PartyID=A.PartyID And P.Type='Taxonomy Code'
                 where AccountID=@acc_party_id
       UNION ALL
	SELECT C.AccountId,CONVERT(varchar(20),CodeIdentification)
	,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
 where AccountID=@acc_party_id
	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateEffDate)
	,'CCodeDateEffDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
 where AccountID=@acc_party_id
	UNION ALL	
	SELECT C.AccountId,CONVERT(varchar(20),CodeDateExpDate)
	,'CCodeDateExpDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID  DESC)) seq
	from KYPEnrollment.EDM_AccountInternalMany EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C 
	on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Category'
      where AccountID=@acc_party_id    
	UNION ALL 
	--SELECT A.Accountid,CONVERT(varchar(20), P.Speciality_Code)
	--,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc  ) ) seq
	--FROM KYPEnrollment.pAccount_PDM_Speciality P 
	--inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID And P.Type='Specialty Code'
	-- where AccountID=@acc_party_id
	--UNION ALL 
	--SELECT A.Accountid,CONVERT(varchar(20), P.SpecCertDate)
	--,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  SpecialityID desc) ) seq
	--FROM KYPEnrollment.pAccount_PDM_Speciality P 
	--inner join KYPEnrollment.pADM_Account A  on P.PartyID=A.PartyID  And P.Type='Specialty Code'	
	-- where AccountID=@acc_party_id	//Modified for Physican Certifican changes related to Portal as per PMG Comments
	
	
	
	SELECT A.Accountid,CONVERT(varchar(20), P.PhyCertCode)
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by PhyCertCode  desc  ) ) 
	seq
	FROM KYPEnrollment.EDM_AccountInternalUse P 
	inner join KYPEnrollment.pADM_Account A  on P.AccountID=A.AccountID --And P.Type='Specialty Code'
	 where A.AccountID=@acc_party_id
	UNION ALL 
	
	SELECT A.Accountid,CONVERT(varchar(20), P.PhyCertCodeEfDate)
	,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by A.Accountid order by  PhyCertCodeEfDate desc) ) seq
	FROM KYPEnrollment.EDM_AccountInternalUse P 
	inner join KYPEnrollment.pADM_Account A  on P.AccountID=A.AccountID 
	where A.AccountID=@acc_party_id
	
	
		
       )ML(AccountId,StatusValue,seq)

PIVOT (max(ml.StatusValue)  
	 FOR ml.seq IN (SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,SCodeIdentification5,
   SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,TaxonomyCode1,TaxonomyCode2,TaxonomyCode3,TaxonomyCode4,
   TaxonomyCode5,TaxonomyCode6,TaxonomyCode7,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14,CCodeIdentification15,
CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,
CCodeDateEffDate10,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,
CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,
CCodeDateExpDate10,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,
Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
)) pvt 

where AccountId=@acc_party_id
  )y
on x.AccountID= y.AccountId
where x.AccountID=@acc_party_id

-------- --Group Rendering Account-------------------------------------------------------------
INSERT INTO [KYPEnrollment].[GroupRenderingforAccount]
           ([GRPIDTY]
           ,[AccountID]
           ,[ReqType]
           ,[Provider]
           ,[OWNERNO]
           ,[SLocNo]
           ,[ProvType]
           ,[userName])


select DISTINCT 'A',
A.AccountID,
Case When(CONVERT(VARCHAR, RAff.AffiliationStartDate , 101) =  
CONVERT(VARCHAR, GETDATE(), 101)) then 'A' 
When (CONVERT(VARCHAR, RAff.AffiliationEndDate , 101) =  
CONVERT(VARCHAR, GETDATE(), 101)) then 'D' 
else
 'E' END AS RequestType

-- Field of pAccount_PDM_Number (For Rendring)
,AR.NPI AS Provider,
AR.OwnerNo AS OWNERNO,
Ar.ServiceLocationNo AS SLocNo,
AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType 
,@Username

from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID

-- This is for  Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
where  RAff.AffiliatedAccountID is not null and RAff.AccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')

--Billing Rendering---------------------------------------------------------------

INSERT INTO [KYPEnrollment].[GroupRenderingforAccount]
           ([GRPIDTY]
           ,[AccountID]
           ,[ReqType]
           ,[Provider]
           ,[OWNERNO]
           ,[SLocNo]
           ,[ProvType]
           ,[userName])


select DISTINCT 'A',
A.AccountID,
Case When(CONVERT(VARCHAR, RAff.AffiliationStartDate , 101) =  
CONVERT(VARCHAR, GETDATE(), 101)) then 'A' 
When (CONVERT(VARCHAR, RAff.AffiliationEndDate , 101) =  
CONVERT(VARCHAR, GETDATE(), 101)) then 'D' 
else
 'E' END AS RequestType
-- Field of pAccount_PDM_Number (For Rendring)
,AR.NPI AS Provider,
AR.OwnerNo AS OWNERNO,
Ar.ServiceLocationNo AS SLocNo,
AR.ProviderTypeCode + '- '+AR.ProviderType AS ProvType ,
@Username


from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AffiliatedAccountID

-- This is for  Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AccountID
where  RAff.AccountID is not null and RAff.AffiliatedAccountID=@acc_party_id and RAff.TypeAffiliation in ('Group-Rendering','NEW_RENDERING_FROM_ACCOUNT','NEW_RENDERING_FROM_GROUP','RENDERING_S_FROM_GROUP','RENDERING_S_FROM_ACCOUNT' ,'RENDERING_S_FROM_APPLICATION')





-----NMP Renderer ----------------------------------------------------------------------------
INSERT INTO [KYPEnrollment].[NMPRenderingForAccount]
           ([AccountID]
           ,[TypeAffiliation]
           ,[RenderingAffiliationID]
           ,[RenAffStDT]
           ,[RenAffEndDT]
           ,[ProvTC]
           ,[NMPRendNPI]
           ,[NMPRendLic]
           ,[LegalName]
           ,[SSN]
           ,[ProvC]
           ,[ProvCDate]
           ,[ReEnrollInd]
           ,[ReEnrollDT]
           ,[StatusAcc]
           ,[StsEffBnDT]
           ,[StsEffEdDT]
           ,[srADD1]
           ,[srADD2]
           ,[srcity]
           ,[srstate]
           ,[srZip4]
           ,[MADD1]
           ,[MADD2]
           ,[MCity]
           ,[MState]
           ,[MZip4],[username])
select Distinct
RAff.AccountID
,RAff.TypeAffiliation,
 RAff.RenderingAffiliationID
, CONVERT( varchar(10), RAff.AffiliationStartDate, 101)  AS RenAffStDT,
CONVERT( varchar(10), RAff.AffiliationEndDate, 101) AS RenAffEndDT,

--A.ProviderTypeCode as ProvTC Changed to pick Rendring Rendring ProviderTypeCode not billing NPI
--AR.ProviderTypeCode as ProvTC only one character has to picked as ProviderTypeCode.
LEFT(AR.ProviderTypeCode,1) as ProvTC

-- Field of pAccount_PDM_Number (For Rendring)
--,A.NPI AS NMPRendNPI Changed to pick Rendring NPI not billing NPI
,AR.NPI AS NMPRendNPI

,LIC.Number AS NMPRendLic,
AR.LegalName,AR.SSN,

D.ProvisionalCode as ProvC,

CASE CONVERT(varchar(10),D.ProvisionalCodeDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),D.ProvisionalCodeDate,101) END 
AS ProvCDate,
AR.ReenrollmentIndicator AS ReEnrollInd,

CASE CONVERT(varchar(10),AR.ReenrollmentDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),AR.ReenrollmentDate,101) END AS ReEnrollDT,
 AR.StatusAcc,
 
 CASE CONVERT(varchar(10),ACS.EffectiveBeginDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),ACS.EffectiveBeginDate,101) END AS StsEffBnDT,

CASE CONVERT(varchar(10),ACS.EffectiveEndDate,101) 
WHEN '01/01/1900' 
THEN '' 
ELSE CONVERT(varchar(10),ACS.EffectiveEndDate,101) END AS StsEffEdDT,

  
--servicing Address
srADD1,srADD2,srcity,srstate,srZip4,
--Mailing Address
MADD1,MADD2,MCity,MState,MZip4
,@Username
from KYPEnrollment.pAccount_RenderingAffiliation RAff
-- This is for Billing 
LEFT OUTER JOIN KYPEnrollment.pADM_Account A on A.AccountID=RAff.AccountID
-- This is for NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pADM_Account AR on AR.AccountID=RAff.AffiliatedAccountID
left outer join KYPEnrollment.EDM_AccountInternalUse D on  D.AccountID=RAff.AffiliatedAccountID --and D.CurrentRecordFlag=1 Reomved since protal data was not setting.
--License of NMP Rendering
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Number LIC on LIC.PartyID=AR.PartyID AND LIC.Type='Professional License' AND LIC.CurrentRecordFlag=1
 --left outer join KYPEnrollment.pADM_AccountStatus ACS on Acs.AccountID=AR.AccountID and ACS.CurrentRecordFlag=1 Changed the below line due unwanted data
left outer join KYPEnrollment.pADM_AccountStatus ACS on Acs.AccountID=AR.AccountID and ACS.CurrentRecordFlag=1 AND ACS.StatusType='Enrollment' 
left outer join 
(select SR.AddressLine1 as srADD1,SR.AddressLine2 AS srADD2,SR.City as srcity,SR.State AS srstate ,SR.ZipPlus4 AS srZip4,x.PartyID,SR.County AS srcountry from KYPEnrollment.pAccount_PDM_Address SR
inner join KYPEnrollment.pAccount_PDM_Location X
	 on SR.AddressID = X.AddressID 
	 and X.Type='Servicing'
	 and X.CurrentRecordFlag=1)E
	 on E.PartyID = AR.PartyID

--This is for Mailing Address Details
left outer join(select D.AddressLine1 as MADD1,D.AddressLine2 as MADD2,D.City as MCity,D.State as MState,D.ZipPlus4 as MZip4,x.PartyID  from KYPEnrollment.pAccount_PDM_Address D 
inner join KYPEnrollment.pAccount_PDM_Location X
	 on D.AddressID = X.AddressID 
	 and X.Type='Mailing'
	 and X.CurrentRecordFlag=1)F
	 on F.PartyID = AR.PartyID
where  RAff.AccountID=@acc_party_id and  RAff.AffiliatedAccountID is not null and RAff.TypeAffiliation in ('NMP','NEW_RENDERING_MIDLEVEL_FROM_ACCOUNT','NEW_RENDERING_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_GROUP','RENDERING_S_MIDLEVEL_FROM_ACCOUNT')
 
 
 
-- --Moca Details for Account
INSERT INTO [KYPEnrollment].[MocaDetailforAccount]
           ([ParentPartyID]
           ,[PartyID]
           ,[Type]
           ,[MOCASrtDT]
           ,[MOCAEdDT]
           ,[MOCADelDT]
           ,[DOB]
           ,[LegalName]
           ,[NPI]
           ,[SSN],[TIN],[username])

select  distinct PRT.ParentPartyID,PRT.PartyID
,PRT.Type,CONVERT(varchar(10),PRT.MOCARelationshipStartDate,101) AS MOCASrtDT,
CONVERT(varchar(10),PRT.MOCARelationshipEndDate,101) AS MOCAEdDT,
CONVERT(varchar(10),PRT.DateDeleted,101)  AS MOCADelDT,
CONVERT(varchar(10),P.DOB,101),
Case when(PRT.Type='Individual Ownership')
then
P.LastName +''+P.FirstName
else
O.LegalName
END AS LegalName,

Case when(PRT.Type='Individual Ownership')
then
P.NPI
else
O.NPI
END AS NPI,

Case when(PRT.Type='Individual Ownership') then 
P.SSN else NULL End AS SSN,
Case when(PRT.Type='Entity Ownership') then 
 O.TIN ELSE NULL END AS TIN
,@Username
from KYPEnrollment.pAccount_PDM_Party PRT
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Organization] O on O.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Owner_Role] ONR on ONR.PartyID=PRT.PartyID
where  AccountID=@acc_party_id and IsProvider=0 and   PRT.Type in ('Entity Ownership','Individual Ownership') 
 
 
END


GO

