


Create Trigger [KYPEnrollment].[Tr_MocaTaxid] on [KYPEnrollment].[pAccount_PDM_Owner_Role]
for Update
as
Begin
declare @Daterecived smalldatetime
		,@Partyid int;
select @Daterecived=DateReceived,@Partyid=PartyID from inserted
if UPDATE(DateReceived)
Begin
Update KYPEnrollment.pAccount_PDM_Owner_Role set DateReceived= @Daterecived where PartyID in (
select PartyID from kypenrollment.pAccount_PDM_Party where Type in ('Individual Ownership','Entity Ownership') and AccountID in (
Select A.AccountID from kypenrollment.pAccount_BizProfile_Details A Inner Join 
(
Select ProfileID,Accountid,AccountEIN from kypenrollment.pAccount_BizProfile_Details where AccountID in (
select AccountID from kypenrollment.pAccount_PDM_Party where Type in ('Individual Ownership','Entity Ownership') and PartyID in (
Select PartyID from KYPEnrollment.pAccount_PDM_Owner_Role where PartyID=@Partyid))
) B on A.ProfileID=b.ProfileID and A.AccountEIN=B.AccountEIN and A.AccountID<>B.AccountID)) and DateReceived is null
end
end


GO

