    
    
    
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Signif_Add]    
 @party_id INT,     
 @new_party_id INT,     
 @last_action_user_id VARCHAR(100),    
 --@type VARCHAR (50),    
 @app_party_row_id INT,    
 @account_id INT,     
 @is_group BIT = 0    
AS    
BEGIN    
 DECLARE @party_adr INT,    
 @new_party_adr INT,    
 @count_association INT,    
 @main_party_id INT,    
 @is_prepopulated BIT,    
 @target_path VARCHAR(200),    
 @full_name_person VARCHAR(100),    
 @type VARCHAR (50),    
 @org_id INT,    
 @legal_name VARCHAR(100),    
 @person_id INT;    
 print '[sp_Copy_Party_Loc_Addr_Signif]';    
   
  --CREATE TABLE #subcontractors (pk INT IDENTITY (1, 1)    
  -- ,PartyID_Portal INT    
  -- ,Type_sub VARCHAR(50)    
  -- ,PartyID_Enroll INT    
  --)   
   
 --new account    
 IF @app_party_row_id IS NULL    
 BEGIN    
             
   --1    
   IF (@type = 'SubcontractorIndividual' )    
   BEGIN    
        
    
    --BEGIN    
     EXEC @new_party_adr = [KYPEnrollment].[sp_Copy_Party] @party_adr, @new_party_id, @account_id,@last_action_user_id;    
     EXEC @person_id = [KYPEnrollment].[sp_Copy_Person] @new_party_adr, @party_adr, @last_action_user_id,'C';    
     EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr, @party_adr, NULL, @last_action_user_id;    
     EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr, @new_party_adr, @last_action_user_id;    
     --mvc--    
     insert into #subcontractors (PartyID_Portal,Type_sub,PartyID_Enroll)    
     VALUES (@app_party_row_id,@type, @new_party_adr)    
     --    
         
      EXEC [KYPEnrollment].[sp_Copy_Owner_Role]@new_party_adr,@party_adr,@last_action_user_id,NULL,NULL;     
    
         
     IF (@type = 'SubcontractorIndividual' AND @is_group=1)    
     BEGIN     
      IF (@is_prepopulated IS NULL OR @is_prepopulated = 0)    
      BEGIN    
          SELECT @full_name_person = [FirstName]+' '+[LastName] FROM KYPEnrollment.pAccount_PDM_Person WHERE PersonID = @person_id;    
       --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Individual',@full_name_person, @new_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@new_party_adr, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      ELSE    
      BEGIN    
       SELECT TOP 1 @main_party_id = Item FROM [KYPEnrollment].[SplitString](@target_path, '|') ORDER BY item;    
       SELECT TOP 1 @main_party_id = MainPartyID FROM [KYPEnrollment].[pAccount_Party_Associate] WHERE PartyID = @main_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@main_party_id, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      END    
    --END    
   END    
   --1     
   ELSE    
   BEGIN    
       
    if (@type = 'SubcontractorEntity' )    
     begin    
       
    --BEGIN    
     EXEC @new_party_adr = [KYPEnrollment].[sp_Copy_Party] @party_adr, @new_party_id, @account_id,@last_action_user_id;    
     EXEC @org_id = [KYPEnrollment].[sp_Copy_Organization] @new_party_adr, @party_adr, @last_action_user_id;    
     EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr, @party_adr, NULL, @last_action_user_id;    
     EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr, @new_party_adr, @last_action_user_id;    
     --mvc--    
     insert into #subcontractors (PartyID_Portal,Type_sub,PartyID_Enroll)    
     VALUES (@app_party_row_id,@type, @new_Party_adr)    
     --    
         
      EXEC [KYPEnrollment].[sp_Copy_Owner_Role]@new_party_adr,@party_adr,@last_action_user_id,NULL,NULL;     
         
     IF (@type = 'SubcontractorEntity'  AND  @is_group=1)    
     BEGIN    
      IF(@is_prepopulated IS NULL OR @is_prepopulated = 0)    
      BEGIN    
       SELECT @legal_name = LegalName FROM KYPEnrollment.pAccount_PDM_Organization WHERE OrgID=@org_id     
       --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Entity',@legal_name, @new_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@new_party_adr, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      ELSE    
      BEGIN    
       SELECT TOP 1 @main_party_id = Item FROM [KYPEnrollment].[SplitString](@target_path, '|') ORDER BY item;    
       SELECT TOP 1 @main_party_id = MainPartyID FROM [KYPEnrollment].[pAccount_Party_Associate] WHERE PartyID = @main_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@main_party_id, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      END    
         
     --END    
         
       end    
       
    if (@type = 'SubcontractorOwnerIndividual' )    
     begin    
       
    --BEGIN    
     EXEC @new_party_adr = [KYPEnrollment].[sp_Copy_Party] @party_adr, @new_party_id, @account_id,@last_action_user_id;    
     EXEC @org_id = [KYPEnrollment].[sp_Copy_Organization] @new_party_adr, @party_adr, @last_action_user_id;    
     EXEC [KYPEnrollment].[sp_Copy_Address] @new_party_adr, @party_adr, NULL, @last_action_user_id;    
     EXEC [KYPEnrollment].[sp_Copy_OwnerhipTransaction] @party_adr, @new_party_adr, @last_action_user_id;    
     --mvc--    
     insert into #subcontractors (PartyID_Portal,Type_sub,PartyID_Enroll)    
     VALUES (@app_party_row_id,@type, @new_Party_adr)    
     --    
         
     IF (@type = 'SubcontractorOwnerIndividual')    
     BEGIN    
      EXEC [KYPEnrollment].[sp_Copy_Owner_Role]@new_party_adr,@party_adr,@last_action_user_id,NULL,NULL;     
     END     
         
         
     IF (@type = 'SubcontractorOwnerIndividual'  AND  @is_group=1)    
     BEGIN    
      IF(@is_prepopulated IS NULL OR @is_prepopulated = 0)    
      BEGIN    
       SELECT @legal_name = LegalName FROM KYPEnrollment.pAccount_PDM_Organization WHERE OrgID=@org_id     
       --EXEC [KYPEnrollment].[Create_Subcontractor_TaxId] @new_party_adr,'Entity',@legal_name, @new_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@new_party_adr, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      ELSE    
      BEGIN    
       SELECT TOP 1 @main_party_id = Item FROM [KYPEnrollment].[SplitString](@target_path, '|') ORDER BY item;    
       SELECT TOP 1 @main_party_id = MainPartyID FROM [KYPEnrollment].[pAccount_Party_Associate] WHERE PartyID = @main_party_id;    
       EXEC [KYPEnrollment].[Create_Party_Associate]@main_party_id, @new_party_adr, @account_id, @type,@party_adr;    
      END    
      END    
         
     --END    
         
       end    
    END    
      
 END    
   
   --DROP TABLE #subcontractors    
    
     
RETURN @new_party_adr    
     
END


GO

