





CREATE VIEW [KYPEnrollment].[view_MocaTaxIdProfile]
AS
SELECT row_number() over (order by PartyID DESC) AS ViewID, result.*
		FROM(
			SELECT party.PartyID, party.Type, 
				case when party.Type = 'Individual Ownership' then person.PersonID  else org.OrgID end as MocaID, 
				case when party.Type = 'Individual Ownership' then person.FirstName  else org.LegalName end as  FirstName,
				case when party.Type = 'Individual Ownership' then person.LastName else '' end as LastName,
				case when party.Type = 'Individual Ownership' then person.MiddleName else '' end as MiddleName, 
				case when party.Type = 'Individual Ownership' then (ISNULL (person.FirstName, '') + ' ' +  ISNULL (person.LastName, '')) else org.LegalName  end as legalName,
				case when party.Type = 'Individual Ownership' then (ISNULL (person.LastName, '') + ' ' +  ISNULL (person.FirstName, '')) else org.LegalName  end as legalNameReverse,
				case when party.Type = 'Individual Ownership' then person.SSN else org.EIN  end as SsnOrTaxId,
				case when party.Type = 'Individual Ownership' then provider.NPI else NULL  end as NPI,
				case when party.Type = 'Individual Ownership' then replace(person.SSN,'-','') else replace(org.EIN,'-','')  end as SsnTinUnformatted,
				taxIdProfile.taxID,
				taxIdProfile.profileID,
				taxIdProfile.taxIDprofileID

			FROM
				KYPEnrollment.pAccount_PDM_Party party
				LEFT JOIN KYPEnrollment.TaxIDProfile taxIdProfile ON party.taxIDprofileID = taxIdProfile.taxIDprofileID
				LEFT JOIN KYPEnrollment.pAccount_PDM_Provider provider on party.PartyID = provider.PartyID  
				LEFT JOIN KYPEnrollment.pAccount_PDM_Person person on party.PartyID = person.PartyID  
				LEFT JOIN KYPEnrollment.pAccount_PDM_Organization org on party.PartyID = org.PartyID
			WHERE
				
				 party.IsDeleted = 0
				 AND party.CurrentRecordFlag = 1
				 AND (party.taxIDprofileID is not null AND party.taxIDprofileID <> '')
				 AND (party.MOCARelationshipEndDate IS NULL OR party.MOCARelationshipEndDate > GETDATE())
				 and ((party.Type = 'Individual Ownership'
				      and (person.Deleted is null OR person.Deleted = 0))
				 OR (party.Type = 'Entity Ownership'
				      and (org.IsDeleted is null OR org.IsDeleted = 0 )))
		)
		AS result


GO

