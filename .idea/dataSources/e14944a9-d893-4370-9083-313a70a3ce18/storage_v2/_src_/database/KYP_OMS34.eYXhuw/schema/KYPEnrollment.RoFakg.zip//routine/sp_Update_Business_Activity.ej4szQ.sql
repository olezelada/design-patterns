-- =============================================
-- Author:		<jvera>
-- Create date: <01/24/2018>
-- Description:	<This procedure update Business Activity>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Business_Activity]
@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1)
AS
BEGIN
	DECLARE @app_activity_id INT

	IF @action_taken='Added'
	BEGIN
		SELECT @app_activity_id = ActivityId FROM [KYPPORTAL].[PortalKYP].[pPDM_BusinessActivity] WHERE TargetPath=@target_path;
	  
		IF not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_activity_id AND NameTable='pAccount_PDM_BusinessActivity') 
		BEGIN
			PRINT 'BUSINESS ACTIVITY ADD NEW'
			EXEC [KYPEnrollment].[sp_Copy_Business_Activity] null, @acc_party_id, @last_Action_User_ID, @app_activity_id;

			INSERT INTO #Control_Add_row(FiledID,NameTable)
			VALUES(@app_activity_id,'pAccount_PDM_BusinessActivity'); 
		END 
	END
  
	IF @action_taken='Updated'
	  BEGIN
	   --if aproved the change
	  
	  if EXISTS(SELECT ActivityId FROM [KYPPORTAL].[PortalKYP].[pPDM_BusinessActivity] WHERE TargetPath=@target_path and Approved = 1)
	  BEGIN
		PRINT 'BUSINESS ACTIVITY CHANGE APPROVED';
		EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_BusinessActivity',@en_db_column,@data,@acc_PK,@acc_PK_value,@is_text_date,NULL,@last_action_user_id,@action_taken;
	  END	 
	  
	END
  
	IF @action_taken='Deleted' AND @target_path LIKE '%pAccount_PDM_BusinessActivity%'
	BEGIN
		PRINT 'DELETE BUSINESS ACTIVITY'
		UPDATE [KYPEnrollment].pAccount_PDM_BusinessActivity SET CurrentRecordFlag = 0 WHERE ActivityID = @acc_PK_value;
	END
END


GO

