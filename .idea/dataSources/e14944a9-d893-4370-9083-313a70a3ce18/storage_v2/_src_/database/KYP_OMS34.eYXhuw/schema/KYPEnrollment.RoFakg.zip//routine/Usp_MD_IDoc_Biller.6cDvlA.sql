
-- =============================================
-- Author:		Sundar
-- Create date: 31-May-2017
-- Description:	This SP is used to fetch Billing Provider information to be populated in Input Document. This is used in Biller and ORP Input Documents.PI-799
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------


CREATE PROCEDURE [KYPEnrollment].[Usp_MD_IDoc_Biller]
      @acc_party_id int, 
      @Username varchar(50)
AS
BEGIN
	--SET NOCOUNT ON;

	Truncate table kypenrollment.ID_BillerInfo;
	
	INSERT INTO KYPEnrollment.ID_BillerInfo(AccountID, 
		MA_ID, 
		NPI, 
		ProviderName, 
		DOB, 
		SAddressLine1, 
		SAddressLine2, 
		SCity, 
		SState, 
		SZip, 
		SCounty, 
		OutofState, 
		Telephone, 
		ProviderType, 
		Sort, 
		TaxID, 
		SSN, 
		License, 
		LicenseBeginDate, 
		LicenseExpiryDate, 
		CLIA, 
		--LabPermitNo, 
		DEA, 
		PracticeType, 
		RevalidationDate, 
		ApplicationDate, 
		StatusCode, 
		StatusBeginDate, 
		PrevProv, 
		Audit, 
		AuditDate, 
		EPSDT, 
		PAddressLine1, 
		PAddressLine2, 
		PCity, 
		PState, 
		PZip, 
		MAddressLine1, 
		MAddressLine2, 
		MCity, 
		MState, 
		MZip, 
		UserName)
	Select AccountID,
		MA_ID, 
		NPI, 
		LegalName, 
		DOB, 
		[SAdsL1], 
		[SAdsL2], 
		[SCity],
		[SState],
		[SZipPlus4],
		SCounty, 
		OutOfStateInd, 
		Phone1, 
		ProviderType, 
		Sort, 
		EIN, 
		SSN, 
		Number, 
		EffDT, 
		LicenseExpiryDate, 
		CliaNumber, 
		--LabPermitNo, 
		DEA, 
		PracticeType, 
		RevalidationDate, 
		AppDT, 
		StatusAcc, 
		StatusBgnDt, 
		PrevProv, 
		Audit, 
		AuditDate, 
		EPSDT, 
		AdsL1, 
		MAdsL2, 
		City, 
		Acc_State, 
		ZipPlus4, 
		MAdsL1, 
		MAdsL2, 
		MCity, 
		MState, 
		MZipPlus4, 
		@Username
	From kypenrollment.AccountInputDocFullLoad
	Where AccountID = @acc_party_id;

	--Speciality Codes
	Insert into KYPEnrollment.ID_Speciality(AccountID, 
											userName, 
											IsPrimary, 
											Specialty, 
											SpecDate)
	Select T1.AccountID,
			@Username,
			t3.PrimarySpecialty,
			Case When t2.IsPrimary = 1 Then 'P' Else 'S' End,
			Convert(varchar(10),T2.SpecCertDate,101)
	from kypenrollment.pADM_Account T1
	Join kypenrollment.pAccount_PDM_Speciality T2 on T1.PartyID=T2.PartyID
	Join kypenrollment.pAccount_PDM_Provider T3 on T1.PartyID = T3.PartyID
	Where T2.Type = 'Specialty Code'
	and T2.IsDeleted = 0
	and T2.CurrentRecordFlag = 1
	AND T2.SpecCertDate is not null
	AND T1.AccountID = @acc_party_id;
	
	--Category of Services
	Insert into KYPEnrollment.ID_Category(AccountID,
				UserName,
				BeginDate, 
				EndDate, 
				COSCode, 
				CreatedUpdatedDate)
	Select A.AccountID, 
		@Username,
		Convert(varchar(10),IM.CodeDateEffDate,101), 
		Convert(varchar(10),IM.CodeDateExpDate,101), 
		IM.CodeIdentification, 
		Convert(varchar(10),IM.LastActionDate,101)
	From kypenrollment.pADM_Account A
	Join kypenrollment.EDM_AccountInternalUse IU on IU.AccountID = A.AccountID
	Join kypenrollment.EDM_AccountInternalMany IM on IM.AccountInternalUseID = IU.AccountInternalUseID
	Where A.AccountID = @acc_party_id
	AND IM.CodeType = 'Category'
	AND IM.isDeleted = 0
	AND IM.CurrentRecordFlag = 1
	Order by IM.LastActionDate Desc

	--Group Information
	Insert into KYPEnrollment.ID_GroupAffiliation(AccountID, userName, Group_MAID, BeginDate, EndDate, CreatedUpdatedDate)
	SELECT RA.AffiliatedAccountID, 
				@Username, 
				A.LegacyAccountNo Group_MAID, 
				Convert(varchar(10),RA.AffiliationStartDate,101), 
				Convert(varchar(10),RA.AffiliationEndDate,101), 
				Convert(varchar(10),RA.LastActionDate,101)
	FROM kypenrollment.pAccount_RenderingAffiliation RA
	Join kypenrollment.pADM_Account A on A.AccountID = RA.AccountID
	Where Ra.isDeleted = 0
	and RA.CurrentRecordFlag = 1
	AND A.IsDeleted = 0
	AND Ra.AffiliatedAccountID = @acc_party_id

	--Lab Classification
	Insert into KYPEnrollment.ID_LabClassification(AccountID, 
				userName, 
				BeginDate, 
				EndDate, 
				LabStatusCode, 
				CreatedUpdatedDate)
	Select A.AccountID, 
		@Username,
		Convert(varchar(10),B.CodeDateEffDate,101), 
		Convert(varchar(10),B.CodeDateExpDate,101), 
		Left(B.CodeIdentification,3), 
		Convert(varchar(10),B.LastActionDate,101) LastActionDate
	From kypenrollment.pADM_Account A
	Join (Select IU.AccountID,Left(IM.CodeIdentification,3) CodeIdentification, IM.CodeDateEffDate, IM.CodeDateExpDate, MAX(IM.LastActionDate) LastActionDate
			From kypenrollment.EDM_AccountInternalUse IU 
			Join kypenrollment.EDM_AccountInternalMany IM on IM.AccountInternalUseID = IU.AccountInternalUseID
			Where IM.CodeType = 'Specialty'
				AND IM.isDeleted = 0
				AND IM.CurrentRecordFlag = 1
			Group by IU.AccountID,Left(IM.CodeIdentification,3), IM.CodeDateEffDate, IM.CodeDateExpDate
			) B on B.AccountID = A.AccountID
	Where A.AccountID = @acc_party_id
	Order by B.LastActionDate Desc
	
END


GO

