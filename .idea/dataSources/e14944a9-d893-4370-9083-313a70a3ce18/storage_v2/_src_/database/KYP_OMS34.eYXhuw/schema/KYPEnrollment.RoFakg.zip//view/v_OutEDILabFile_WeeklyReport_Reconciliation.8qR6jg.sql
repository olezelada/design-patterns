



CREATE VIEW [KYPEnrollment].[v_OutEDILabFile_WeeklyReport_Reconciliation] as
With Acs as (Select AccountID,StatusCode,StatusEffectiveDate,ROW_NUMBER() over(PARTITION by AccountId order by LabStatusId desc) R
		From KYPEnrollment.pAccount_PDM_LabStatus),
LabStatus as (select distinct T1.AccountId
	,T1.StatusCode as StatusCode1,T1.StatusEffectiveDate as StatusEffectiveDate1,
	T2.StatusCode as StatusCode2,T2.StatusEffectiveDate as StatusEffectiveDate2,
	T3.StatusCode as StatusCode3,T3.StatusEffectiveDate as StatusEffectiveDate3,
	T4.StatusCode as StatusCode4,T4.StatusEffectiveDate as StatusEffectiveDate4,
	T5.StatusCode as StatusCode5,T5.StatusEffectiveDate as StatusEffectiveDate5
	from (select AccountId,StatusCode,StatusEffectiveDate
			from ACS 
			where R=1) T1
			LEft JOIN (select AccountId,StatusCode,StatusEffectiveDate
			from ACS
			where R=2) T2 on T1.AccountId=T2.AccountId
			LEft JOIN (select AccountId,StatusCode,StatusEffectiveDate
			from ACS
			where R=3) T3 on T1.AccountId=T3.AccountId
			LEft JOIN (select AccountId,StatusCode,StatusEffectiveDate
			from ACS
			where R=4) T4 on T1.AccountId=T4.AccountId	
			LEft JOIN (select AccountId,StatusCode,StatusEffectiveDate
			from ACS
			where R=5) T5 on T1.AccountId=T5.AccountId)			
select 
A.NPI,
A.OwnerNo,
A.ServiceLocationNo,
A.ProviderTypeCode,
LS.StatusCode1, LS.StatusEffectiveDate1,
LS.StatusCode2, LS.StatusEffectiveDate2,
LS.StatusCode3, LS.StatusEffectiveDate3,
LS.StatusCode4, LS.StatusEffectiveDate4,
LS.StatusCode5, LS.StatusEffectiveDate5,
IM.CodeIdentification,
IM.CodeDateEffDate,
Im.CodeDateExpDate
from KYPEnrollment.pADM_Account A
Join LabStatus LS ON A.AccountID=LS.AccountID
Left Join KYPEnrollment.EDM_AccountInternalUse IU on A.AccountID=IU.AccountID
Left Join KYPEnrollment.EDM_AccountInternalMany IM on IM.AccountInternalUseID=IU.AccountInternalUseID and IM.CodeType='Specialty'
where A.IsDeleted=0
and A.ProviderTypeCode<>'100' --Added to eliminate Mixed Group records


GO

