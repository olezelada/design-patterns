-- =============================================
-- Author:		<ohuanca>
-- Create date: <09-03-18>
-- Description:	check if doesn't exist of party site account
-- @party_id_provider: party id from application
-- @acc_party_id: party id of account
-- @last_action_user_id: identifier from tracking
-- @account_id: identifier of account
-- @typePartyApplication: type of party
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_Pharmacist_Information]
  @party_id_provider INT,
  @acc_party_id INT,
  @last_action_user_id VARCHAR(100),
  @account_id INT,
  @typePartyApplication VARCHAR(50)
AS
BEGIN
      IF NOT EXISTS (SELECT PartyID FROM KYPEnrollment.pAccount_PDM_Party party WHERE ParentPartyID = @acc_party_id AND Type = @typePartyApplication)
      BEGIN
        EXEC [KYPEnrollment].[sp_Copy_Pharmacy_Information] @party_id_provider, @acc_party_id, @last_action_user_id, NULL, @account_id, NULL;

        PRINT 'INSERT TABLES: Person, Document, NUMBER'
      END
END


GO

