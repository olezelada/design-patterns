










CREATE VIEW [KYP].[v_SummaryProviderReport]
AS


SELECT    row_number() OVER (ORDER BY (SELECT 1)) AS ID,
--NewID() as ID
 *
FROM         
(
SELECT   A.PartyID, D.AddressLine1, D.AddressLine2, D.State, D.Zip, D.ZipPlus4, 
               
               CASE 
					WHEN H.Specialty = 'Y' THEN 'Not Disclosed' 
					ELSE A.PrimarySpecialty
               END PrimarySpecialty,
               
               CASE 
					WHEN H.DEA = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),A.DEA)
               END DEA,
               
               CASE 
					WHEN H.NPI = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),A.NPI)
               END NPI,
               
               CASE 
					WHEN H.City = 'Y' THEN 'Not Disclosed' 
					ELSE D.City
               END City,
               
               CASE 
					WHEN H.StrAttr1 = 'Y' THEN 'Not Disclosed' 
					ELSE B.Name
               END Name,
               
               CASE 
					WHEN H.PhoneNo = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),C.Phone1)
               END PhoneNO,
               
               CASE 
					WHEN H.Taxonomy_Status = 'Y' THEN 'Not Disclosed' 
					ELSE CONVERT(varchar(15),T.Taxonomy)
               END Taxonomy,
               
               CASE
					WHEN H.Taxonomy_Status = 'T' THEN 'True' 
					WHEN H.Taxonomy_Status = 'P' THEN 'Partial' 
					WHEN H.Taxonomy_Status = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.Taxonomy_Status = 'F' THEN 'Negative' 
					WHEN H.Taxonomy_Status = 'X' THEN 'Not Found' 
					WHEN H.Taxonomy_Status = 'Y' THEN 'Found (Not Disclosed)' 
               END TaxonomyCheckResult, 
               
               CASE
					WHEN H.DEA = 'T' THEN 'True' 
					WHEN H.DEA = 'P' THEN 'Partial' 
					WHEN H.DEA = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.DEA = 'F' THEN 'Negative' 
					WHEN H.DEA = 'X' THEN 'Not Found' 
					WHEN H.DEA = 'Y' THEN 'Found (Not Disclosed)' 
               END ASDEACheckResult, 
                
               CASE 
					WHEN H.NPI = 'T' THEN 'True' 
					WHEN H.NPI = 'P' THEN 'Partial' 
					WHEN H.NPI = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.NPI = 'F' THEN 'Negative' 
					WHEN H.NPI = 'X' THEN 'Not Found' 
					WHEN H.NPI = 'Y' THEN 'Found (Not Disclosed)'
			   END AS NPICheckResult,
               
                CASE 
					WHEN H.City = 'T' THEN 'True' 
					WHEN H.City = 'P' THEN 'Partial' 
					WHEN H.City = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.City = 'F' THEN 'Negative' 
					WHEN H.City = 'X' THEN 'Not Found' 
					WHEN H.City = 'Y' THEN 'Found (Not Disclosed)'
				END AS CityCheckResult,
                CASE 
					WHEN	H.License = 'T' THEN 'True' 
					WHEN	H.License = 'P' THEN 'Partial' 
					WHEN	H.License = 'U' THEN 'Unknown/Not Applicable' 
					WHEN	H.License = 'F' THEN 'Negative'
					WHEN	H.License = 'X' THEN 'Not Found' 
					WHEN	H.License = 'Y' THEN 'Found (Not Disclosed)'
					ELSE 'NA'
                END AS LicenseCheckResult, 
               CASE 
					WHEN B.Type!='Person' AND H.CLIA = 'T' THEN 'True' 
					WHEN B.Type!='Person' AND H.CLIA = 'P' THEN 'Partial' 
					WHEN B.Type!='Person' AND H.CLIA = 'U' THEN 'Unknown/Not Applicable' 
					WHEN B.Type!='Person' AND H.CLIA = 'F' THEN 'Negative' 
					WHEN B.Type!='Person' AND H.CLIA = 'X' THEN 'Not Found' 
					WHEN B.Type!='Person' AND H.CLIA = 'Y' THEN 'Found (Not Disclosed)'
					ELSE 'NA'
					END AS CLIACheckResult, 
               CASE 
					WHEN H.PhoneNo = 'T' THEN 'True' 
					WHEN H.PhoneNo = 'P' THEN 'Partial' 
					WHEN H.PhoneNo = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.PhoneNo = 'F' THEN 'Negative' 
					WHEN H.PhoneNo = 'X' THEN 'Not Found' 
					WHEN H.PhoneNo = 'Y' THEN 'Found (Not Disclosed)'
					END AS PhoneResult, 
               CASE 
					WHEN H.Specialty = 'T' THEN 'True' 
					WHEN H.Specialty = 'P' THEN 'Partial' 
					WHEN H.Specialty = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.Specialty = 'F' THEN 'Negative' 
					WHEN H.Specialty = 'X' THEN 'Not Found' 
					WHEN H.Specialty = 'Y' THEN 'Found (Not Disclosed)'
					END AS PrimarySpecialtyCheckResult, 
               CASE 
					WHEN H.StrAttr1 = 'T' THEN 'True' 
					WHEN H.StrAttr1 = 'P' THEN 'Partial' 
					WHEN H.StrAttr1 = 'U' THEN 'Unknown/Not Applicable' 
					WHEN H.StrAttr1 = 'F' THEN 'Negative'
					WHEN H.StrAttr1 = 'X' THEN 'Not Found' 
					WHEN H.StrAttr1 = 'Y' THEN 'Found (Not Disclosed)'
                END AS NameCheckResult,
                
               CASE 
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'0')))='0' THEN 'None'
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'')))='' THEN 'None'
					WHEN I.AffiliationCount IS NULL THEN 'None'
					ELSE 'Found (Not Disclosed)' 
               END AS AffiliationCheckResult,
               
               CASE 
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.AffiliationCount,'')))='' THEN NULL
					WHEN I.AffiliationCount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,I.AffiliationCount)+' Found' 
                END AS AffiliationCount,
                
                CASE
					WHEN ltrim(rtrim(isnull(I.SanctionCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(I.SanctionCount,'')))='' THEN NULL 
					WHEN I.SanctionCount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,I.SanctionCount)+' Found' 
                 END AS SanctionCount, 
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSADDRESSCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSADDRESSCount,'')))='' THEN NULL  
					WHEN N.HMSADDRESSCount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,N.HMSADDRESSCount)+' Found' 
                 END AS HMSADDRESSCount,  
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSDEACount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSDEACount,'')))='' THEN NULL  
					WHEN N.HMSDEACount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,N.HMSDEACount)+' Found' 
                 END AS HMSDEACount,
				CASE
					WHEN ltrim(rtrim(isnull(N.HMSLICENSECount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSLICENSECount,'')))='' THEN NULL 
					WHEN N.HMSLICENSECount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,N.HMSLICENSECount)+' Found' 
                 END AS HMSLICENSECount,
                CASE
					WHEN ltrim(rtrim(isnull(N.HMSNPICount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSNPICount,'')))='' THEN NULL  
					WHEN N.HMSNPICount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,N.HMSNPICount)+' Found' 
                 END AS HMSNPICount,
                 
                 CASE
					WHEN ltrim(rtrim(isnull(N.HMSTAXIDCount,'0')))='0' THEN NULL
					WHEN ltrim(rtrim(isnull(N.HMSTAXIDCount,'')))='' THEN NULL   
					WHEN N.HMSTAXIDCount IS NULL THEN NULL
					ELSE 'Total '+ CONVERT(VARCHAR,N.HMSTAXIDCount)+' Found' 
                 END AS HMSTAXIDCount,
                 
                  CASE
					WHEN B.Type='Person' THEN 'NA'  
					WHEN H.CLIA = 'Y' THEN 'Not Disclosed'
					ELSE A.CLIA 
                 END AS CLIA,
                 'License' as LicenseCode,
                 CASE
					WHEN  H.License = 'Y' THEN 'Not Disclosed'
					ELSE MR.DisclosedData--dbo.[ConcatRows]('DisclosedData',G.ScreeningID) 
					 
                  END AS LICENSE, 
                  
                  CASE 
					WHEN MR.MatchResult = 'T' THEN 'True' 
					WHEN MR.MatchResult = 'P' THEN 'Partial' 
					WHEN MR.MatchResult = 'U' THEN 'Unknown/Not Applicable' 
					WHEN MR.MatchResult = 'F' THEN 'Negative'
					WHEN MR.MatchResult = 'X' THEN 'Not Found' 
					WHEN MR.MatchResult = 'Y' THEN 'Found (Not Disclosed)'
                END AS LICENSEMatchResult,
					 
                
                  
					G.AppPartyID, G.ScreeningID, G.PartyType AS PartyRole
FROM  KYP.PDM_Provider AS A
		 INNER JOIN KYP.PDM_Party AS B ON A.PartyID = B.PartyID AND A.IsDeleted <> 1 AND B.CurrentModule = 1 
		 INNER JOIN KYP.PDM_Location AS C ON A.PartyID = C.PartyID AND C.IsDeleted <> 1 
		 INNER JOIN KYP.PDM_Address AS D ON C.AddressID = D.AddressID 
		 INNER JOIN KYP.SDM_ApplicationParty AS G ON A.PartyID = G.PartyID 
		 INNER JOIN KYP.SDM_DBCheckResult AS H ON G.ScreeningID = H.ScreeningID
		 LEFT  JOIN KYP.PDM_CLIA AS F ON F.PartyID = A.PartyID AND F.DateDeleted IS NULL
		 LEFT  JOIN KYP.SDM_DBCheckDetail AS I ON i.DBChkResultID = H.DBChkResultID 
		 LEFT  JOIN KYP.SDM_ProvMasterData AS N ON N.ScreeningID=G.ScreeningID
		 LEFT JOIN
		 (SELECT ScreeningID,DisclosedData,MatchResult FROM KYP.SDM_MoreValue WHERE SortOrder = 1 AND AttributeName = 'LIC' 
		-- AND MatchResult != 'U' AND LTRIM(RTRIM(ISNULL(DisclosedData,''))) != '' AND Category = 'PRACTICE') MR
		 AND Category = 'PRACTICE') MR
		 ON MR.ScreeningID = G.ScreeningID 	 
		  
		 LEFT  JOIN KYP.PDM_Taxonomy AS T ON A.PartyID = T.PartyID 
--
) Q


GO

