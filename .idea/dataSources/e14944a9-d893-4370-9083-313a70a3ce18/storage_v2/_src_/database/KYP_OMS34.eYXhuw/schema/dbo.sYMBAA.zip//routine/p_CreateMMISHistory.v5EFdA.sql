-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_CreateMMISHistory] 
	-- Add the parameters for the stored procedure here
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
insert into dbo.MMIS_Main_PMF_File_History 
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMainFile.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_Main_PMF_File 
except
select 
DH_PROV_NUMBER,DH_OWNER_NUM,DH_SERV_LOC_NUM,DH_OWNER_EFFEC_BEG_DT,DH_OWNER_EFFEC_END_DT,
DH_LEGAL_NAME,DH_EMP_ID_NO,DH_SSN,DH_PIN,DH_TIN_UPDATE_TYPE,DH_TIN_UPDATE_DATE,DH_PAY_TO_ATTEN_LN,
DH_PAY_TO_LN1,DH_PAY_TO_LN2,DH_PAY_TO_CITY,DH_PAY_TO_STATE,DH_PAY_TO_ZIP5,DH_PAY_TO_ZIP4,DH_DT_PROV_ADDED,
DH_LAST_ACTY_DT,DH_LAST_ACTY_TIME,DH_SANCTION_TXT_1,DH_SANCTION_TXT_2,DH_SANCTION_TXT_3,DH_SANCTION_TXT_4,
DH_SANCTION_TXT_5,DH_SANCTION_TXT_6,DH_SANCTION_TXT_7,DH_SANCTION_TXT_8,DH_PROV_LOC_TYPE_CD,DH_PROV_BUSINESS_NAME,
DH_ADDR_ATTEN_LN,DH_ADDR_LN1,DH_ADDR_LN2,DH_ADDR_CITY,DH_ADDR_STATE,DH_ADDR_ZIP5,DH_ADDR_ZIP4,DH_PROV_CNTY_CD,
DH_PROV_TELE_NO,DH_NAME_OF_FAC_ADMIN,DH_MAIL_TO_ATTEN_LN,DH_MAIL_TO_LN1,DH_MAIL_TO_LN2,DH_MAIL_TO_CITY,DH_MAIL_TO_STATE,
DH_MAIL_TO_ZIP5,DH_MAIL_TO_ZIP4,DH_OUT_OF_STATE_IND,DH_PROV_TYP,DH_ENROL_STAT_CD_1,DH_STAT_EFF_DT_1,DH_STAT_END_DT_1,
DH_ENROL_STAT_CD_2,DH_STAT_EFF_DT_2,DH_STAT_END_DT_2,DH_ENROL_STAT_CD_3,DH_STAT_EFF_DT_3,DH_STAT_END_DT_3,
DH_ENROL_STAT_CD_4,DH_STAT_EFF_DT_4,DH_STAT_END_DT_4,DH_ENROL_STAT_CD_5,DH_STAT_EFF_DT_5,DH_STAT_END_DT_5,DH_CATSERV_CD_1,
DH_CATSERV_BEGIN_DT_1,DH_CATSERV_END_DT_1,DH_CATSERV_CD_2,DH_CATSERV_BEGIN_DT_2,DH_CATSERV_END_DT_2,DH_CATSERV_CD_3,
DH_CATSERV_BEGIN_DT_3,DH_CATSERV_END_DT_3,DH_CATSERV_CD_4,DH_CATSERV_BEGIN_DT_4,DH_CATSERV_END_DT_4,DH_CATSERV_CD_5,
DH_CATSERV_BEGIN_DT_5,DH_CATSERV_END_DT_5,DH_CATSERV_CD_6,DH_CATSERV_BEGIN_DT_6,DH_CATSERV_END_DT_6,DH_CATSERV_CD_7,
DH_CATSERV_BEGIN_DT_7,DH_CATSERV_END_DT_7,DH_CATSERV_CD_8,DH_CATSERV_BEGIN_DT_8,DH_CATSERV_END_DT_8,DH_CATSERV_CD_9,
DH_CATSERV_BEGIN_DT_9,DH_CATSERV_END_DT_9,DH_CATSERV_CD_10,DH_CATSERV_BEGIN_DT_10,DH_CATSERV_END_DT_10,DH_CATSERV_CD_11,
DH_CATSERV_BEGIN_DT_11,DH_CATSERV_END_DT_11,DH_CATSERV_CD_12,DH_CATSERV_BEGIN_DT_12,DH_CATSERV_END_DT_12,DH_CATSERV_CD_13,
DH_CATSERV_BEGIN_DT_13,DH_CATSERV_END_DT_13,DH_CATSERV_CD_14,DH_CATSERV_BEGIN_DT_14,DH_CATSERV_END_DT_14,DH_CATSERV_CD_15,
DH_CATSERV_BEGIN_DT_15,DH_CATSERV_END_DT_15,DH_CATSERV_CD_16,DH_CATSERV_BEGIN_DT_16,DH_CATSERV_END_DT_16,DH_CATSERV_CD_17,
DH_CATSERV_BEGIN_DT_17,DH_CATSERV_END_DT_17,DH_CATSERV_CD_18,DH_CATSERV_BEGIN_DT_18,DH_CATSERV_END_DT_18,DH_CATSERV_CD_19,
DH_CATSERV_BEGIN_DT_19,DH_CATSERV_END_DT_19,DH_CATSERV_CD_20,DH_CATSERV_BEGIN_DT_20,DH_CATSERV_END_DT_20,DH_SPE_CD_1,
DH_SPE_CERT_DT_1,DH_SPE_CD_2,DH_SPE_CERT_DT_2,DH_SPE_CD_3,DH_SPE_CERT_DT_3,DH_SPEC_PROCESS_TYPE_CD,DH_IMD_FACIL_TYPE,DH_TYP_OF_PRAC_ORG,
DH_APP_DT,DH_REJECT_REASON_CD,DH_EXCEPTION_IND,DH_PROVIS_ENROLL_CD,DH_PROVIS_ENROLL_EFFEC_DT,DH_RE_ENROLLMENT_IND,
DH_RE_ENROLL_EFF_DATE,DH_PROV_LIC_NO,DH_PROV_LIC_BOARD_CD,DH_PROV_LIC_DT,DH_CLIA_NUMBER,DH_CLIA_TYPE_CERTIFICATION,DH_TYPE_LAST_ACTY_DT 
from dbo.MMIS_Main_PMF_File_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMainFile.txt')
from dbo.MMIS_Main_PMF_File_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.DH_PROV_NUMBER,x.DH_OWNER_NUM,x.DH_SERV_LOC_NUM,x.DH_PROV_TYP order by id desc)row
from dbo.MMIS_Main_PMF_File_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_Main_PMF_File_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over(partition by x.DH_PROV_NUMBER,x.DH_OWNER_NUM,x.DH_SERV_LOC_NUM,x.DH_PROV_TYP order by id desc)row
from dbo.MMIS_Main_PMF_File_History x
)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_Main_PMF_File_History x
left join dbo.MMIS_Main_PMF_File y
 on x.DH_PROV_NUMBER=y.DH_PROV_NUMBER
	 and x.DH_OWNER_NUM=y.DH_OWNER_NUM
	 and x.DH_SERV_LOC_NUM=y.DH_SERV_LOC_NUM
	 and x.DH_PROV_TYP=y.DH_PROV_TYP
where y.DH_PROV_NUMBER is null



insert into dbo.MMIS_GroupProvider_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISGroupProvider.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_GroupProvider 
except
select [PM-PROV-NUMBER],[PM-OWNER-NUM],[PM-SERV-LOC-NUM],[PM-KEY-PROV-TYP],[PM-PROV-NOS-IN-GRP]
from dbo.MMIS_GroupProvider_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISGroupProvider.txt')
from dbo.MMIS_GroupProvider_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP] order by id desc)row
from dbo.MMIS_GroupProvider_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_GroupProvider_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP] order by id desc)row
from dbo.MMIS_GroupProvider_History x
)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_GroupProvider_History x
left join dbo.MMIS_GroupProvider y
  on x.[PM-PROV-NUMBER]=y.[PM-PROV-NUMBER]
	 and x.[PM-OWNER-NUM]=y.[PM-OWNER-NUM]
	 and x.[PM-SERV-LOC-NUM]=y.[PM-SERV-LOC-NUM]
	 and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
where y.[PM-PROV-NUMBER] is null


insert into dbo.MMIS_MOCADetailFile_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMocaDetail.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_MOCADetailFile 
except
select DH_MOCA_SSN,DH_MOCA_TIN,DH_MOCAL_NPI,DH_MOCA_LEGAL_NAME,DH_MOCA_EFF_DT,DH_MOCA_END_DT,DH_MOCA_DOB,[Column 7]
from dbo.MMIS_MOCADetailFile_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMocaDetail.txt')
from dbo.MMIS_MOCADetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.DH_MOCA_SSN,x.DH_MOCA_TIN order by id desc)row
from dbo.MMIS_MOCADetailFile_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_MOCADetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by  x.DH_MOCA_SSN,x.DH_MOCA_TIN order by id desc)row
from dbo.MMIS_MOCADetailFile_History x)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_MOCADetailFile_History x
left join dbo.MMIS_MOCADetailFile y
  on x.DH_MOCA_SSN=y.DH_MOCA_SSN
	 and x.DH_MOCA_TIN=y.DH_MOCA_TIN
where y.DH_MOCA_SSN is null and y.DH_MOCA_TIN is null

insert into dbo.MMIS_MOCARelationShipFile_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMocaRelationship.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_MOCARelationShipFile 
except
select DH_MOCA_BILL_PROV_NO,DH_MOCA_BILL_OWNER,DH_MOCA_BILL_LOCATION,DH_MOCA_BILL_PROV_TYPE,DH_MOCA_BILL_SSN,
DH_MOCA_BILL_TIN,DH_MOCA_BILL_EFF_DT,DH_MOCA_BILL_END_DT,[Column 8]
from dbo.MMIS_MOCARelationShipFile_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISMocaRelationship.txt')
from dbo.MMIS_MOCARelationShipFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE order by id desc)row
from dbo.MMIS_MOCARelationShipFile_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_MOCARelationShipFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by  x.DH_MOCA_BILL_PROV_NO,x.DH_MOCA_BILL_OWNER,x.DH_MOCA_BILL_LOCATION,x.DH_MOCA_BILL_PROV_TYPE  order by id desc)row
from dbo.MMIS_MOCARelationShipFile_History x)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_MOCARelationShipFile_History x
left join dbo.MMIS_MOCARelationShipFile y
  on x.DH_MOCA_BILL_PROV_NO=y.DH_MOCA_BILL_PROV_NO
  and x.DH_MOCA_BILL_OWNER = y.DH_MOCA_BILL_OWNER
  and x.DH_MOCA_BILL_LOCATION=y.DH_MOCA_BILL_LOCATION
  and x.DH_MOCA_BILL_PROV_TYPE=y.DH_MOCA_BILL_PROV_TYPE
where y.DH_MOCA_BILL_PROV_NO is null and y.DH_MOCA_BILL_OWNER is null


insert into dbo.MMIS_NMPDetailFile_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISNMPDetail.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_NMPDetailFile 
except
select NMP_PROV_NO,NMP_LEGAL_NAME,NMP_ADDR_ATTEN_LN,NMP_ADDR_LN1,NMP_ADDR_LN2,NMP_ADDR_CITY,NMP_ADDR_STATE,NMP_ADDR_ZIP_5,
NMP_ADDR_ZIP_4,NMP_MAIL_TO_ATTEN_LN,NMP_MAIL_TO_LN1,NMP_MAIL_TO_LN2,NMP_MAIL_TO_CITY,NMP_MAIL_TO_STATE,NMP_MAIL_TO_ZIP_5,
NMP_MAIL_TO_ZIP_4,DH_NMP_SSN,NMP_ENROL_STAT_CD_1,NMP_STAT_EFF_DT_1,NMP_STAT_END_DT_1,NMP_ENROL_STAT_CD_2,NMP_STAT_EFF_DT_2,
NMP_STAT_END_DT_2,NMP_ENROL_STAT_CD_3,NMP_STAT_EFF_DT_3,NMP_STAT_END_DT_3,NMP_ENROL_STAT_CD_4,NMP_STAT_EFF_DT_4,NMP_STAT_END_DT_4,
NMP_ENROL_STAT_CD_5,NMP_STAT_EFF_DT_5,NMP_STAT_END_DT_5,NMP_RE_ENROMENT_IN,NMP_RE_ENR_EFF_DATE,NMP_PROVIS_ENROLL_IND,
NMP_PROVIS_ENROLL_EFFEC_DT,[Column 36]
from dbo.MMIS_NMPDetailFile_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISNMPDetail.txt')
from dbo.MMIS_NMPDetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.NMP_PROV_NO order by id desc)row
from dbo.MMIS_NMPDetailFile_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_NMPDetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by  x.NMP_PROV_NO  order by id desc)row
from dbo.MMIS_NMPDetailFile_History x)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_NMPDetailFile_History x
left join dbo.MMIS_NMPDetailFile y
  on x.NMP_PROV_NO=y.NMP_PROV_NO
where y.NMP_PROV_NO is null 

insert into dbo.MMIS_NMPRelationshipFile_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISNMPRelationship.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_NMPRelationshipFile 
except
select [PM-PROV-NUMBER],[PM-OWNER-NUM],[PM-SERV-LOC-NUM],[PM-KEY-PROV-TYP],[PM-NMP-LICENSE],[PM-NMP-PROV-NUMBER],
[PM-NMP-TYPE],[PM-NMP-EFF-DT],[PM-NMP-END-DT]
from dbo.MMIS_NMPRelationshipFile_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISNMPRelationship.txt')
from dbo.MMIS_NMPRelationshipFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP] order by id desc)row
from dbo.MMIS_NMPRelationshipFile_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_NMPRelationshipFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by  x.[PM-PROV-NUMBER],x.[PM-OWNER-NUM],x.[PM-SERV-LOC-NUM],x.[PM-KEY-PROV-TYP]  order by id desc)row
from dbo.MMIS_NMPRelationshipFile_History x)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_NMPRelationshipFile_History x
left join dbo.MMIS_NMPRelationshipFile y
  on x.[PM-PROV-NUMBER]= y.[PM-PROV-NUMBER]
  and x.[PM-OWNER-NUM]= y.[PM-OWNER-NUM]
  and x.[PM-SERV-LOC-NUM]= y.[PM-SERV-LOC-NUM]
  and x.[PM-KEY-PROV-TYP]=y.[PM-KEY-PROV-TYP]
where y.[PM-PROV-NUMBER] is null 



insert into dbo.MMIS_ORPDetailFile_History
select y.*,(select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISORPDetail.txt')
 ,null,null,0,GETDATE()
 from 
(select * from dbo.MMIS_ORPDetailFile 
except
select [MCAL-ORP-PROV-NO],[MCAL-ORP-LEGAL-NAME],[MCAL-ORP-SSN],[MCAL-ORP-ADDR-ATTEN-LN],[MCAL-ORP-ADDR-LN1],[MCAL-ORP-ADDR-LN2]
,[MCAL-ORP-ADDR-CITY],[MCAL-ORP-ADDR-STATE],[MCAL-ORP-ADDR-ZIP_5],[MCAL-ORP-ADDR-ZIP_4],[MCAL-ORP-MAIL-TO-ATTEN-LN],[MCAL-ORP-MAIL-TO-LN1]
,[MCAL-ORP-MAIL-TO-LN2],[MCAL-ORP-MAIL-TO-CITY],[MCAL-ORP-MAIL-TO-STATE],[MCAL-ORP-MAIL-TO-ZIP5],[MCAL-ORP-MAIL-TO-ZIP4],[MCAL-ORP-PROV-TYPE]
,[MCAL-ORP-ENROL-STAT-CD_1],[MCAL-ORP-STAT-EFF-DT_1],[MCAL-ORP-STAT-END-DT_1],[MCAL-ORP-ENROL-STAT-CD_2],[MCAL-ORP-STAT-EFF-DT_2]
,[MCAL-ORP-STAT-END-DT_2],[MCAL-ORP-ENROL-STAT-CD_3],[MCAL-ORP-STAT-EFF-DT_3],[MCAL-ORP-STAT-END-DT_3],[MCAL-ORP-ENROL-STAT-CD_4]
,[MCAL-ORP-STAT-EFF-DT_4],[MCAL-ORP-STAT-END-DT_4],[MCAL-ORP-ENROL-STAT-CD_5],[MCAL-ORP-STAT-EFF-DT_5],[MCAL-ORP-STAT-END-DT_5]
,[MCAL-ORP-PROF-LIC-NO],[MCAL-ORP-PROF-LIC-EFF-DT],[MCAL-ORP-PROVIS-ENROLL-IND],[MCAL-ORP-PROVIS-ENROLL-EFFEC-DT],[MCAL-ORP-RE-ENROMENT-IN]
,[MCAL-ORP-RE-ENR-EFF-DATE],[MCAL-ORP-LAST-ACTVT-DT],[MCAL-ORP-LAST-UPDT-USER]
from dbo.MMIS_ORPDetailFile_History)y

update x 
set x.LastLoadFileDate = (select filedate from dbo.MMIS_LatestFileNames where mmis_filename='MMISORPDetail.txt')
from dbo.MMIS_ORPDetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by x.[MCAL-ORP-PROV-NO] order by id desc)row
from dbo.MMIS_ORPDetailFile_History x)y
on x.id= y.id
where y.row=1

update x 
set x.OldRecordFlag = 1
from dbo.MMIS_ORPDetailFile_History x
inner join
(select id, x.LastLoadFileDate, ROW_NUMBER()over
(partition by  x.[MCAL-ORP-PROV-NO]  order by id desc)row
from dbo.MMIS_ORPDetailFile_History x)y
on x.id= y.id
where y.row>1

update x 
set x.DateFieDeleted = GETDATE()
from dbo.MMIS_ORPDetailFile_History x
left join dbo.MMIS_ORPDetailFile y
  on x.[MCAL-ORP-PROV-NO]= y.[MCAL-ORP-PROV-NO]
where y.[MCAL-ORP-PROV-NO] is null 
END


GO

