












CREATE TRIGGER [KYPEnrollment].[CreateAccountIUDData] ON [KYPEnrollment].[EDM_AccountInternalUseOldData]
WITH EXECUTE AS CALLER
 AFTER INSERT
AS 
BEGIN
SET NOCOUNT  ON
Declare
@AccountID int, 
@AccountInternalUseID int,
@LastActionComments varchar(255)

SET @AccountID = (select AccountID from inserted);
SET @LastActionComments = (select LastActionComments from inserted);
SET @AccountInternalUseID = (select AccountInternalUseID from inserted);
SELECT @AccountID = ISNULL([AccountID],0) FROM [KYPEnrollment].[EDM_AccountInternalUseOldData] WHERE AccountID = @AccountID
SET @AccountID = ISNULL(@AccountID,0);
PRINT @AccountID
SELECT @AccountInternalUseID = ISNULL([AccountInternalUseID],0) FROM KYPEnrollment.EDM_AccountInternalUse where AccountID = @AccountID
SET @AccountInternalUseID = ISNULL(@AccountInternalUseID,0);
PRINT @AccountInternalUseID
SELECT @LastActionComments = ISNULL([LastActionComments],0) FROM KYPEnrollment.EDM_AccountInternalUseOldData where LastActionComments = @LastActionComments
SET @LastActionComments = ISNULL(@LastActionComments,0);
PRINT @LastActionComments
EXECUTE [KYPEnrollment].[Copy_AccountInternalUseOldData] @AccountID, @AccountInternalUseID, @LastActionComments
END


GO

