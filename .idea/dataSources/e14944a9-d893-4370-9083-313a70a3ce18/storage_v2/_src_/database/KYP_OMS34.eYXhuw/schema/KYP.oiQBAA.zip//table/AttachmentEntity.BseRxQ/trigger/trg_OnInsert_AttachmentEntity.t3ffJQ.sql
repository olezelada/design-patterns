


-- =============================================
-- Author:		Yogesh Sharma
-- Create date: 18 May 2012
-- Description:	Trigger to handle attachment count in the table KYP.FrameworkCount
--				On insert in the table KYP.AttachmentEntity 
--				The trigger is written with the assumption that inserts on table KYP.AttachmentEntity
--				occur on a row by row basis and not bulk inserts to the table.
-- =============================================
CREATE TRIGGER [KYP].[trg_OnInsert_AttachmentEntity]
   ON  [KYP].[AttachmentEntity]
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.	

	SET NOCOUNT ON;
	
		--CAPAVE-133 , pd-95
		declare @Alertid int
	
	select @Alertid = AttachmentEntityTypeID from inserted;
		
	select x.alertid INTO #alertsActivityDate 
	from(select alertid from kyp.MDM_Alert with(nolock) 
		where AlertID=@Alertid and @AlertID is not null
	union select alertid from kyp.MDM_Alert with(nolock) 
		where AlertNo=@Alertid and @AlertID is not null)x

	
	select alertid into #DatetoUpdate from (
	select alertid from #alertsActivityDate 
	union
	SELECT ChildAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ParentAlertID 
	in(	select alertid from #alertsActivityDate)
	UNION
	SELECT ParentAlertID AS alertid
	FROM kyp.MDM_RelatedAlerts WITH (NOLOCK) WHERE ChildAlertID 
	in(select alertid from #alertsActivityDate))x
		
		
	Update kyp.MDM_Alert set LastActivityDate = GETDATE()
		where alertid in(select alertid from #DatetoUpdate)
	--CAPAVE-133 , pd-95
	
	IF EXISTS (
		SELECT 1 
		FROM KYP.FrameworkCount A	INNER JOIN INSERTED B 
			ON A.FrameworkEntityType = B.AttachmentEntityType 
			AND A.FrameworkEntityTypeID = B.AttachmentEntityTypeID
	)
	UPDATE A 
		SET A.DocumentCount = A.DocumentCount + 1, 
			A.ModifiedDate = getdate(), 
			A.ModifiedBy = 'Document Increased'
	FROM KYP.FrameworkCount A	INNER JOIN INSERTED B 
			ON A.FrameworkEntityType = B.AttachmentEntityType 
			AND A.FrameworkEntityTypeID = B.AttachmentEntityTypeID
    option (maxdop 1)


	ELSE 
	INSERT INTO [KYP].[FrameworkCount]
           ([FrameworkEntityType]
           ,[FrameworkEntityTypeID]
		   ,[NoteCount] 
           ,[DocumentCount]
           ,[CommunicationCount]
           ,[CreatedDate]
           ,[CreatedBy]
           ,[ModifiedDate]
           ,[ModifiedBy]
           ,[IsDeleted])
     SELECT AttachmentEntityType
           ,AttachmentEntityTypeID
		   ,0 as NoteCount
           ,1 as DocumentCount
		   ,0 as CommunicationCount
           ,getdate() as CreatedDate
           ,'Document Created' as CreatedBy
           ,NULL
           ,NULL
           ,0
	FROM INSERTED    
	


END


GO

