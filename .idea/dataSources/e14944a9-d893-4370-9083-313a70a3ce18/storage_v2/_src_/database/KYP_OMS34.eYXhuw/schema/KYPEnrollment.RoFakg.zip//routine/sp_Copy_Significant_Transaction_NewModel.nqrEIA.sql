
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Significant Transaction form.   
-- PARAMETERS: 
-- @@party_app_id : partyID Application that will be Account. 
-- @party_account_id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Significant_Transaction_NewModel]
@party_app_id int,
@party_account_id int,
@last_action_user_id VARCHAR(100),
@account_id INT,
@is_group BIT = 0,
@taxidprofileid int
AS
BEGIN 
	--EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Ind_newModel] @party_app_id,@party_account_id,@last_action_user_id,'TransactionIndividual',NULL,@account_id,@is_group,@taxidprofileid ;
	--EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org_newmodel] @party_app_id,@party_account_id,@last_action_user_id,'TransactionEntity',NULL,@account_id,@is_group,@taxidprofileid ;


    EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_Signif_newModel @party_app_id,@party_account_id,@last_action_user_id,NULL,@account_id,@is_group;
	EXEC [KYPEnrollment].sp_Copy_Party_Loc_Addr_SignifSecond_newModel @party_app_id,@party_account_id,@last_action_user_id,NULL,@account_id,@is_group,@taxidprofileid;
	

	PRINT 'New Significant Transaction'
END


GO

