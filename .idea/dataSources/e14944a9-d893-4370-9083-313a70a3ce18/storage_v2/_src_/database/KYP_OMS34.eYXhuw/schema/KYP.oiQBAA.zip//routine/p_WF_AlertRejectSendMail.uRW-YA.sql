

CREATE PROCEDURE [KYP].[p_WF_AlertRejectSendMail]
	@AlertNo VARCHAR(100),
	@NotesDescription VARCHAR(MAX)
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @FullName VARCHAR(100),
			@Sub VARCHAR(100),
			@body VARCHAR(MAX),
			@EmailAddTo VARCHAR(150);
	
    SET @Sub = 'Alert Declined (' + @AlertNo + ')'

	DECLARE @RejNotes VARCHAR(MAX);

	SET @RejNotes = @NotesDescription

	IF @RejNotes IS NULL
	BEGIN
		SET @RejNotes = '';
	END

	SET @body = @RejNotes;
	SET @EmailAddTo = (
			SELECT EmailID
			FROM KYP.OIS_User WITH (NOLOCK)
			WHERE PersonID = (
					SELECT AssignedByUserID
					FROM KYP.MDM_Alert WITH (NOLOCK)
					WHERE AlertNo = @AlertNo
					)
			)

	IF @EmailAddTo <> ''
		AND @EmailAddTo IS NOT NULL
	BEGIN
		EXEC msdb.dbo.sp_send_dbmail @profile_name = 'administrator'
			,@body = @body
			,@body_format = 'HTML'
			,@recipients = @EmailAddTo
			,@subject = @Sub;
	END
END


GO

