





CREATE VIEW [KYP].[v_EDIFileForNM]
AS
SELECT     row_number() OVER (ORDER BY AssignedBy ASC) AS ID, *
FROM         
(

--------------------------------------------------------------------------------------
---- GENERATED ALERTS
--------------------------------------------------------------------------------------
--Select DISTINCT X.AlertNo,X.ProvNumber,X.MedicaidID,X.NPI,'NULL' as ResoultionType,X.Status,X.ActivityDate,X.AssignedBy,X.Remarks,X.FileSource,
--     X.STAT_EFF_DT,X.NMP_END_DT,X.MOCA_END_DT,X.GroupProviderNo,
-- substring(X.ProvNumber,11,2) AS PROV_OWNER_NUM,
-- substring(X.ProvNumber,13,3) AS PROV_SERV_LOC_NUM,
-- substring(X.ProvNumber,16,3) AS PROV_TYP_NUM, 
--  NULL  AS NewStatusCode,
--  CASE When X.FileSource = 'P' THEN 
--  CASE WHEN X.Type = 'Person' THEN
--                          (SELECT   TOP 1   SSN
--                            FROM          KYP.PDM_Person
--                            WHERE      PartyID =  X.WatchedPartyID)
--       ELSE NULL END
--	ELSE NULL END AS MOCO_SSN,
-- CASE When X.FileSource = 'P' THEN 
--	   CASE WHEN X.Type = 'Organization' THEN
--                          (SELECT   TOP 1   TIN
--                            FROM         KYP.PDM_Organization
--                            WHERE      PartyID = X.WatchedPartyID)
--       	 ELSE NULL END
-- END AS MOCO_TIN,
-- NULL As NMP_LicenseNO
--    from (
--SELECT  DISTINCT
--	B.AlertNo, 
--	A.MedicaidID,
--	C.ProvNumber,
--	B.WatchedPartyID, 
--	P.Type, 
--	C.NPI, 
--	'AlertCreated' AS 'Status', 
--	B.CreatedDate AS 'ActivityDate', 
--    E.FullName AS 'AssignedBy',
--    REPLACE(REPLACE(CONVERT(VARCHAR(1000), D .UnformattedContent), CHAR(13),' '), CHAR(10), ' ') AS 'Remarks',
--     /*updated CAPVAE 374*/
--	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
--		GP.FileSource
--    ELSE 
--		P.FileSource
--    END AS FileSource,
--   	P.STAT_EFF_DT As STAT_EFF_DT,
--    P.NMP_END_DT As NMP_END_DT,
--	P.MOCA_END_DT As MOCA_END_DT,
--	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
--	 GP.Group_ProviderNO   
--    ELSE NULL END As GroupProviderNo
--    FROM KYP.MDM_SearchProviders A 
--	INNER JOIN KYP.MDM_Alert B 
--		ON A.AlertID = B.AlertID 
--	LEFT OUTER JOIN KYP.PDM_Provider C 
--		ON C.ProvID = A.ProviderID 
--	LEFT OUTER JOIN KYP.OIS_Note D 
--		ON D .RelatedEntityID = B.AlertID 
--		AND D.Type = 'Special Instructions' 
--		AND D .RelatedEntityID IS NOT NULL 
--		AND D .NoteID =     (SELECT DISTINCT TOP 1 NoteID
--                             FROM          KYP.OIS_Note
--                             WHERE      RelatedEntityID = D .RelatedEntityID) 
--    LEFT OUTER JOIN KYP.OIS_User E 
--		ON E.PersonID = B.AssignedByUserID
--    LEFT OUTER JOIN KYP.PDM_Party P ON P.PartyID = B.WatchedPartyID	
--    LEFT OUTER JOIN KYP.PDM_MasterGroupProvider GP on GP.Member_ProviderNO=C.ProvNumber	
-- WHERE B.WFStatus = 'Assign Alert' 
-- AND B.StatusCodeNumber = 12
-- AND A.MatchType = 'Auto' 
-- AND CONVERT(VARCHAR, B.CreatedDate, 101) =  CONVERT(VARCHAR, GETDATE()-1, 101) 
-- ) X where (X.FileSource!='S' and X.FileSource!='Y')
 
 /*UNION ALL
 
 ------------------------------------------------------------------------------------
 -- ALERTS WITH WORKFLOW STEPS
 ------------------------------------------------------------------------------------  
 Select DISTINCT X.AlertNo,X.ProvNumber,X.MedicaidID,X.NPI,X.ResolutionType,X.Status,X.ActivityDate,X.AssignedBy,X.Remarks,X.FileSource,
      X.STAT_EFF_DT,X.NMP_END_DT,X.MOCA_END_DT,X.GroupProviderNo,
 substring(X.ProvNumber,11,2) AS PROV_OWNER_NUM,
 substring(X.ProvNumber,13,3) AS PROV_SERV_LOC_NUM,
 substring(X.ProvNumber,16,3) AS PROV_TYP_NUM,     
CASE WHEN X.FileSource IN( 'M','N','O') THEN
		CASE WHEN X.ResolutionType = 'Account Suspension' THEN
			'6' 
			WHEN X.ResolutionType = 'Account Termination' THEN
			'2' 
			WHEN X.ResolutionType = 'Temporary Suspension' THEN
			'9' 
			WHEN X.ResolutionType = 'Deceased' THEN
			'4' 
		ELSE 'NA' END
	ELSE NULL END AS NewStatusCode,

CASE When X.FileSource = 'P' THEN 
	  CASE WHEN X.Type = 'Person' THEN
                          (SELECT    TOP 1  SSN
                            FROM          KYP.PDM_Person
                            WHERE      PartyID =  X.WatchedPartyID)
       ELSE NULL END
	ELSE NULL END AS MOCO_SSN,
 CASE When X.FileSource = 'P' THEN 
	   CASE WHEN X.Type = 'Organization' THEN
                          (SELECT   TOP 1   TIN
                            FROM         KYP.PDM_Organization
                            WHERE      PartyID = X.WatchedPartyID)
       	 ELSE NULL END
 END AS MOCO_TIN,
 NULL as NMP_LicenseNO
 
   from (SELECT DISTINCT
   	B.AlertNo, 
   	A.MedicaidID,
	C.ProvNumber,
	B.WatchedPartyID, 
	R.ResolutionType,
	P.Type, 
	C.NPI,
	'AlertAssignedTo' + [KYP].[convertToTitleCase] (G.RoleName) AS 'Status', 
	G.DateTime AS 'ActivityDate', 
	G.UserFullName AS 'AssignedBy', 
	REPLACE(REPLACE(CONVERT(VARCHAR(1000), G.Notes), CHAR(13), ' '), CHAR(10), ' ') AS 'Remarks',
	/*updated CAPVAE 374*/
	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
		GP.FileSource
    ELSE 
		P.FileSource
    END AS FileSource,
    P.STAT_EFF_DT As STAT_EFF_DT,
    P.NMP_END_DT As NMP_END_DT,
	P.MOCA_END_DT As MOCA_END_DT,
	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
	 GP.Group_ProviderNO   
    ELSE NULL END As GroupProviderNo
	FROM KYP.MDM_SearchProviders A 
	INNER JOIN  (SELECT AlertID,WFStatus, AlertNo,WatchedPartyID FROM KYP.MDM_Alert a 
    LEFT JOIN  KYP.MDM_RelatedAlerts b 
    on b.ParentAlertID = a.AlertID 
    WHERE a.IsMerged = 'N' and MatchStatusIndicator != 'F' and MatchStatusIndicator !='I') B
     on a.AlertID= b.AlertID
		LEFT OUTER JOIN KYP.PDM_Provider C ON C.ProvID = A.ProviderID 
		LEFT OUTER JOIN KYP.MDM_WorkflowHistory G ON G.AlertID = B.AlertID 
							AND G.Type='EDI'
		LEFT OUTER JOIN KYP.MDM_AlertResolution R ON A.AlertID = R.AlertID  and R.ResolutionID in
(SELECT ResolutionID from  KYP.MDM_AlertResolution Res where Res.AlertID = A.AlertID and Res.ResolutionType in ('Account Suspension','Account Termination') and Res.ResolutionType is Not null)
		LEFT OUTER JOIN KYP.PDM_Party P ON P.PartyID = B.WatchedPartyID
		LEFT OUTER JOIN KYP.PDM_MasterGroupProvider GP on GP.Member_ProviderNO=C.ProvNumber	
	WHERE A.IsDeleted <> 1 
		AND B.WFStatus <> 'Completed' 
		AND B.WFStatus <> 'Assign Alert'
		AND A.MatchType = 'Auto'
	AND CONVERT(VARCHAR, G.DateTime, 101) =  CONVERT(VARCHAR, GETDATE()-1 , 101)
	)X   where   X.ResolutionType in( 'Account Suspension', 'Account Termination') and (X.FileSource!='S' and X.FileSource!='Y')                                                                                                                             
 */
 --UNION ALL
 
 ------------------------------------------------------------------------------------
-- CLOSED ALERTS
------------------------------------------------------------------------------------  
 Select DISTINCT X.AlertNo,X.ProvNumber,X.MedicaidID,X.NPI,X.ResolutionType,X.Status,X.ActivityDate,X.AssignedBy,X.Remarks,X.FileSource,
      X.STAT_EFF_DT,X.NMP_END_DT,X.MOCA_END_DT,X.GroupProviderNo,
  substring(X.ProvNumber,11,2)  AS PROV_OWNER_NUM,
  substring(X.ProvNumber,13,3) AS PROV_SERV_LOC_NUM,
  substring(X.ProvNumber,16,3) AS PROV_TYP_NUM,
CASE WHEN X.FileSource IN( 'M','N','O') THEN
		CASE WHEN X.ResolutionType = 'Suspend Account Temporarily' or X.ResolutionType ='Account Suspension' THEN
			'9' 
			WHEN X.ResolutionType = 'Suspend Account' or X.ResolutionType ='Account Termination' THEN
			'6' 
			WHEN X.ResolutionType = 'Deactivate Provider As Deceased' THEN
			'4' 
			WHEN X.ResolutionType = 'Deactivate Account' THEN
			'2' 
		ELSE 'NA' END
	ELSE NULL END AS NewStatusCode,

CASE When X.FileSource = 'P' THEN 
	  CASE WHEN X.Type = 'Person' THEN
                          (SELECT  TOP 1    SSN
                            FROM          KYP.PDM_Person
                            WHERE      PartyID =  X.WatchedPartyID)
       ELSE NULL END
	ELSE NULL END AS MOCO_SSN,
 CASE When X.FileSource = 'P' THEN                                                                                                                                        
	   CASE WHEN X.Type = 'Organization' THEN
                          (SELECT   TOP 1   TIN
                            FROM         KYP.PDM_Organization
                            WHERE      PartyID = X.WatchedPartyID)
       	 ELSE NULL END
 END AS MOCO_TIN,
 NULL As NMP_LicenseNO
 
   from (
    SELECT	DISTINCT
    B.AlertNo, 
    A.MedicaidID,
    C.ProvNumber,
	B.WatchedPartyID, 
	R.ResolutionType,
	P.Type,
	C.NPI, 
	'AlertClosed' AS 'Status', 
	B.DateClosed AS 'ActivityDate', 
	E.FullName AS 'AssignedBy', 
    REPLACE(REPLACE(CONVERT(VARCHAR(1000), D .UnformattedContent), CHAR(13), ' '), CHAR(10), ' ') AS 'Remarks',
    /*updated CAPVAE 374*/
	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
		GP.FileSource
    ELSE 
		P.FileSource
    END AS FileSource,
   	P.STAT_EFF_DT As STAT_EFF_DT,
    P.NMP_END_DT As NMP_END_DT,
	P.MOCA_END_DT As MOCA_END_DT,
	CASE WHEN GP.Group_ProviderNO IS NOT NULL THEN
	 GP.Group_ProviderNO   
    ELSE NULL END As GroupProviderNo
    FROM KYP.MDM_SearchProviders A 
	INNER JOIN  (SELECT AlertID,WFStatus, AlertNo,WatchedPartyID,AssignedToUserID,DateClosed FROM KYP.MDM_Alert a 
    LEFT JOIN  KYP.MDM_RelatedAlerts b 
    on b.ParentAlertID = a.AlertID 
     WHERE a.IsMerged = 'N' and MatchStatusIndicator != 'F' and MatchStatusIndicator !='I') B
    on a.AlertID= b.AlertID
	LEFT OUTER JOIN KYP.PDM_Provider C 
		ON C.ProvID = A.ProviderID 
	LEFT OUTER JOIN KYP.OIS_Note D 
		ON D.RelatedEntityID = B.AlertID 
		AND D.Type = 'Disposition' 		
        LEFT OUTER JOIN KYP.OIS_User E ON E.PersonID = B.AssignedToUserID
       LEFT OUTER JOIN KYP.MDM_AlertResolution R ON A.AlertID = R.AlertID  and R.ResolutionID in
(SELECT ResolutionID from  KYP.MDM_AlertResolution Res where Res.AlertID = A.AlertID and  RES.ProviderID=A.ProviderID and Res.ResolutionType in ('Suspend Account Temporarily', 'Suspend Account','Deactivate Account','Deactivate Provider As Deceased','Account Suspension','Account Termination')and Res.ResolutionType is Not null)
        LEFT OUTER JOIN KYP.PDM_Party P ON P.PartyID =B.WatchedPartyID	
        LEFT OUTER JOIN KYP.PDM_MasterGroupProvider GP on GP.Member_ProviderNO=C.ProvNumber
  WHERE A.IsDeleted <> 1 
  AND B.WFStatus = 'Completed' 
  
--AND A.Impacted = 1
--AND A.MatchType = 'Auto'
AND CONVERT(VARCHAR, B.DateClosed, 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)
 )X where   X.ResolutionType in( 'Suspend Account Temporarily', 'Suspend Account','Deactivate Account','Deactivate Provider As Deceased','Account Suspension','Account Termination') and (X.FileSource!='S' and X.FileSource!='Y' and X.FileSource!='N' and X.FileSource!='P')
 )
Z


GO

