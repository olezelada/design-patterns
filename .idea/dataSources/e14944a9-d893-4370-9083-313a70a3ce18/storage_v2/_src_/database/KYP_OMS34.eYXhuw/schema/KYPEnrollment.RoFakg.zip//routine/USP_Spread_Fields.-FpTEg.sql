


-- =============================================
-- Author:		Sundar
-- Create date: 12-Dec-2018
-- Description:	Spread Fields based on NPI/ OwnerNo or NPI/OwnerNo/ServiceLocationNo
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[USP_Spread_Fields]
	@p_ApplicationNo varchar(15),
	@pNPI varchar(20),
	@plast_Action_User_ID VARCHAR(100),
	@party_id_app int,
	@pAccountID int
AS
BEGIN
	SET NOCOUNT ON;
	
	Declare @OwnerNo varchar(5),
			@ServiceLocationNo varchar(5),
			@ProfessionalTitle varchar(10) ,
			@LastName varchar(25),
			@FirstName varchar(25),
			@MiddleName varchar(25),
			@Sufix varchar(10),
			@LegalName varchar(150),
			@BusinessName Varchar(150),
			@AddressLine1 varchar(250),
			@AddressLine2 varchar(50),
			@City varchar(25),
			@State varchar(40),
			@County varchar(25),
			@Zip varchar(5),
			@ZipPlus4 varchar(50),
			@Country varchar(40),
			@Latitude varchar(8),
			@Longitude varchar(7),
			@GeographicArea varchar(50),
			@AppAddressID int,
			@UpdateLegalName bit,
			@UpdateBusinessName bit,
			@UpdateMailToAddress bit,
			@NPIType varchar(100),
			@SupUpdateFlag varchar(20)

	Declare @Tab_Name table (AccountID int,
									FieldName varchar(200),
									OldValue varchar(2000),
									NewValue varchar(2000))
			
	Declare @Tab_MailAddress Table(Accountid Int,
									AddressLine1 varchar(250), 
									AddressLine2 varchar(50),
									City varchar(25),
									State varchar(40),
									County  varchar(25),
									Zip varchar(20))
									
	Begin Try
	
		Select @NPIType = NPIType
		From kypenrollment.pADM_Account
		Where AccountID=@pAccountID
		
		Select @SupUpdateFlag = SupUpdateFlag
		From kyp.ADM_Case
		Where Number = @p_ApplicationNo

		Select @OwnerNo = BillingFutureStatus,
				@ServiceLocationNo = ProvCrossReferenceCode
			from kypenrollment.edm_applicationinternaluse where ApplicationNumber=@p_ApplicationNo;
		
		IF (@OwnerNo is null or @ServiceLocationNo is null)
		Begin
			Select @OwnerNo = BillingFutureStatus,
					@ServiceLocationNo = ProvCrossReferenceCode
				from kypenrollment.edm_Supplementalinternaluse where LastActionComments=@p_ApplicationNo;	
		End
		
		--Added the below IF stat for Supplemental NR application
		IF (@OwnerNo is null or @ServiceLocationNo is null) and @SupUpdateFlag = '5A'
		Begin
			Select @OwnerNo = OwnerNo,
					@ServiceLocationNo = ServiceLocationNo
				from kypenrollment.pADM_Account where AccountID=@pAccountID;	
		End		

		Select @UpdateLegalName = UpdateLegalName,
				@UpdateBusinessName = UpdateBusinessName,
				@UpdateMailToAddress = UpdateMailToAddress
		From kypportal.portalkyp.padm_application 
		Where applicationno=@p_ApplicationNo;

		IF @UpdateLegalName = 1
		Begin
			IF @NPIType = 'Individual'
			Begin
				Select @ProfessionalTitle = RTRIM(LTRIM(ProfessionalTitle)),
						@LastName = RTRIM(LTRIM(LastName)),
						@FirstName = RTRIM(LTRIM(FirstName)),
						@MiddleName = RTRIM(LTRIM(MiddleName)),
						@Sufix = RTRIM(LTRIM(Sufix))
				From kypportal.portalKyp.pPDM_Person
				Where PartyID = @party_id_app
				and (isnull(ProfessionalTitle,'')<>''
						or isnull(LastName,'')<>''
						or isnull(FirstName,'')<>''
						or isnull(MiddleName,'')<>''
						or isnull(Sufix,'')<>'')
				 
				IF (@ProfessionalTitle is not null
						or @LastName is not null
						or @FirstName is not null
						or @MiddleName is not null
						or @Sufix is not null)
				Begin
					Set @LegalName = ISNULL(@LastName, '') + ', ' + ISNULL(@FirstName, '') + ' ' + ISNULL(LEFT(@MiddleName, 1), '') + ' ' + ISNULL(@ProfessionalTitle, '')
					
					Update T2
					Set T2.LegalName = @LegalName,
						T2.LastActionDate = GETDATE(),
						T2.LastActorUserID = @plast_Action_User_ID,
						T2.LastActionComments = isnull(T2.LastActionComments,'')+'LegalName_Spread',
						T2.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
						,T2.IsProvOwnedData = 1 --Added for KEN-21574 by Sundar on 5-Apr-2019						
					Output Deleted.AccountID,'LegalName',Deleted.LegalName,Inserted.LegalName INTO @Tab_Name(AccountID,FieldName,OldValue,NewValue)
					From Kypenrollment.padm_account t1
					Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo  --Commented OwnerNo for KEN-20822
					Where T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
						and T2.IsDeleted=0
						and T1.AccountID=@pAccountID
						and T1.AccountID<>t2.AccountID
						and T1.LegalName <> t2.LegalName --Added for KEN-20823
					
					--Update T3
					--Set T3.ProfessionalTitle = @ProfessionalTitle,
					--	T3.LastName = @LastName,
					--	T3.FirstName = @FirstName,
					--	T3.MiddleName = @MiddleName,
					--	T3.Sufix = @Sufix,
					--	T3.LastActionDate = GETDATE(),
					--	T3.LastActorUserID = @plast_Action_User_ID,
					--	T3.LastActionComments = isnull(T3.LastActionComments,'')+'LegalName_Spread'
					--From Kypenrollment.padm_account t1
					--Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo --Commented OwnerNo for KEN-20822
					--Join kypenrollment.pAccount_PDM_Person t3 on t2.PartyID = T3.PartyID
					--Where T2.IsDeleted=0
					--	and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
					--	and T1.AccountID=@pAccountID
					--	and T2.NPIType = 'Individual'
					--	and T1.AccountID<>t2.AccountID;
					
					-- Changed the Update Statement for KEN-20823
					Update T3
					Set T3.ProfessionalTitle = @ProfessionalTitle,
						T3.LastName = @LastName,
						T3.FirstName = @FirstName,
						T3.MiddleName = @MiddleName,
						T3.Sufix = @Sufix,
						T3.LastActionDate = GETDATE(),
						T3.LastActorUserID = @plast_Action_User_ID,
						T3.LastActionComments = isnull(T3.LastActionComments,'')+'LegalName_Spread'
					From Kypenrollment.padm_account t1
					Join @Tab_Name t2 on t1.AccountID=T2.AccountID
					Join kypenrollment.pAccount_PDM_Person t3 on t1.PartyID = T3.PartyID
					Where T1.IsDeleted=0					
					
					--Commented for KEN-20787 by Sundar on 11 Jan 2019
					--Update T3
					--Set T3.LegalName = @LegalName,
					--	T3.LastActionDate = GETDATE(),
					--	T3.LastActorUserID = @plast_Action_User_ID,
					--	T3.LastActionComments = isnull(T3.LastActionComments,'')+'LegalName_Spread'
					--From Kypenrollment.padm_account t1
					--Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI and T1.OwnerNo=T2.OwnerNo
					--Join kypenrollment.pAccount_PDM_Organization t3 on t2.PartyID = T3.PartyID
					--Where T2.IsDeleted=0
					--	and T1.AccountID=@pAccountID
					--	and T1.AccountID<>t2.AccountID	
				End			
			End

			IF @NPIType = 'Organization'
			BEGIN
				Select @LegalName = LegalName
				From kypportal.portalKyp.pPDM_Organization
				Where PartyID = @party_id_app
				and isnull(LegalName,'') <> '';	
				
				If @LegalName is not null
				Begin
					Update T2
					Set T2.LegalName = @LegalName,
						T2.LastActionDate = GETDATE(),
						T2.LastActorUserID = @plast_Action_User_ID,
						T2.LastActionComments = isnull(T2.LastActionComments,'')+'LegalName_Spread',
						T2.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
						,T2.IsProvOwnedData = 1 --Added for KEN-21574 by Sundar on 5-Apr-2019 
					Output Deleted.AccountID,'LegalName',Deleted.LegalName,Inserted.LegalName INTO @Tab_Name(AccountID,FieldName,OldValue,NewValue)
					From Kypenrollment.padm_account t1
					Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo --Commented OwnerNo for KEN-20822
					Where T2.IsDeleted=0
						and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
						and T1.AccountID=@pAccountID
						and T1.AccountID<>t2.AccountID
						and isnull(T1.LegalName,'')<>isnull(T2.LegalName,'') --Added for KEN-20823		
				
					--Update T3
					--Set T3.LegalName = @LegalName,
					--	T3.LastActionDate = GETDATE(),
					--	T3.LastActorUserID = @plast_Action_User_ID,
					--	T3.LastActionComments = isnull(T3.LastActionComments,'')+'LegalName_Spread'
					--From Kypenrollment.padm_account t1
					--Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo --Commented OwnerNo for KEN-20822
					--Join kypenrollment.pAccount_PDM_Organization t3 on t2.PartyID = T3.PartyID
					--Where T2.IsDeleted=0
					--	and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
					--	and T1.AccountID=@pAccountID
					--	and T1.AccountID<>t2.AccountID	
					
					--Changed the Update Statement for KEN-20823
					Update T3
					Set T3.LegalName = @LegalName,
						T3.LastActionDate = GETDATE(),
						T3.LastActorUserID = @plast_Action_User_ID,
						T3.LastActionComments = isnull(T3.LastActionComments,'')+'LegalName_Spread'
					From Kypenrollment.padm_account t1
					Join @Tab_Name t2 on t1.AccountID=T2.AccounTID
					Join kypenrollment.pAccount_PDM_Organization t3 on t1.PartyID = T3.PartyID
					Where T1.IsDeleted=0					
				End				
			End

			Insert INTO [Kypenrollment].[NPI_SpreadHistory]([AccountID],
															[FieldName],
															[FromValue],
															[ToValue],
															[LoadDate],
															[SourceApplication],
															[SourceAccountID],
															[LastActorUserID])		
			Select T1.AccountID,T1.FieldName,T1.OldValue,T1.NewValue,getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID 
			From @Tab_Name T1;	
				
			Insert INTO [Kypenrollment].InputDoc_Biller([AccountID],
															[FieldName],
															[FromValue],
															[ToValue],
															DateModified)		
			Select T1.AccountID,T1.FieldName,T1.OldValue,T1.NewValue,getdate()
			From @Tab_Name T1;				
		
			delete from @Tab_Name;
		End
		
		IF @UpdateBusinessName = 1
		Begin
			Select @BusinessName = BusinessName
				From KYPPORTAL.PortalKYP.pPDM_Organization
				Where partyid=@party_id_app
				and ISNULL(BusinessName,'') <> '';
			
			IF @BusinessName is not null
			Begin
				Update T2
				Set T2.BusinessName = @BusinessName,
					T2.LastActionDate = GETDATE(),
					T2.LastActorUserID = @plast_Action_User_ID,
					T2.LastActionComments = isnull(T2.LastActionComments,'')+'BusinessName_Spread',
					T2.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
					,T2.IsProvOwnedData = 1 --Added for KEN-21574 by Sundar on 5-Apr-2019 
				Output Deleted.AccountID,'BusinessName',Deleted.BusinessName,Inserted.BusinessName INTO @Tab_Name(AccountID,FieldName,OldValue,NewValue)		
				From Kypenrollment.padm_account t1
				Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo and T1.ServiceLocationNo = T2.ServiceLocationNo --Commented OwnerNo and ServiceLocationNo for KEN-20822
				Where T2.IsDeleted=0
					and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
					and T2.ServiceLocationNo = @ServiceLocationNo --Added this condition for KEN-20822
					and T1.AccountID=@pAccountID
					and T1.AccountID<>t2.AccountID
					and ISNULL(T1.BusinessName,'') <> ISNULL(T2.BusinessName,'') --Changed the condition for KEN-20823	
			
				--Update T3
				--Set T3.BusinessName = @BusinessName,
				--	T3.LastActionDate = GETDATE(),
				--	T3.LastActorUserID = @plast_Action_User_ID,
				--	T3.LastActionComments = isnull(T3.LastActionComments,'')+'BusinessName_Spread'
				--From Kypenrollment.padm_account t1
				--Join kypenrollment.padm_Account t2 on t1.NPI=t2.NPI --and T1.OwnerNo=T2.OwnerNo and T1.ServiceLocationNo = T2.ServiceLocationNo --Commented OwnerNo and ServiceLocationNo for KEN-20822
				--Join kypenrollment.paccount_pdm_organization t3 on T2.PartyID=T3.PartyID
				--Where T2.IsDeleted=0
				--	and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
				--	and T2.ServiceLocationNo = @ServiceLocationNo --Added this condition for KEN-20822				
				--	and T1.AccountID=@pAccountID
				--	and T1.AccountID<>t2.AccountID	
				--	and ISNULL(T1.BusinessName,'') <> ''

				--Changed the Update Statement for KEN-20823
				Update T3
				Set T3.BusinessName = @BusinessName,
					T3.LastActionDate = GETDATE(),
					T3.LastActorUserID = @plast_Action_User_ID,
					T3.LastActionComments = isnull(T3.LastActionComments,'')+'BusinessName_Spread'
				From Kypenrollment.padm_account t1
				Join @Tab_Name t2 on t1.AccountID=T2.AccountID
				Join kypenrollment.paccount_pdm_organization t3 on T1.PartyID=T3.PartyID
				Where T1.IsDeleted=0				

				Insert INTO [Kypenrollment].[NPI_SpreadHistory]([AccountID],
																[FieldName],
																[FromValue],
																[ToValue],
																[LoadDate],
																[SourceApplication],
																[SourceAccountID],
																[LastActorUserID])		
				Select T1.AccountID,T1.FieldName,T1.OldValue,T1.NewValue,getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID 
				From @Tab_Name T1;	
					
				Insert INTO [Kypenrollment].InputDoc_Biller([AccountID],
																[FieldName],
																[FromValue],
																[ToValue],
																DateModified)		
				Select T1.AccountID,'DBAName',T1.OldValue,T1.NewValue,getdate()
				From @Tab_Name T1;				
			
				delete from @Tab_Name;	
			End			
		End
		
		IF @UpdateMailToAddress = 1 and Exists(Select t1.AddressID
												From KYPPORTAL.PortalKYP.pPDM_Location t1
												Join KYPPORTAL.PortalKYP.pPDM_Address T2 on t1.AddressID = T2.AddressID
												Where t1.PartyID = @party_id_app
													and t1.Type='Mailing')
		Begin
			Select @AppAddressID = AddressID From Kypportal.portalKYP.PPDM_Location Where PartyID = @party_id_app and Type = 'Mailing'

			Select @AddressLine1 = t2.AddressLine1,
					@AddressLine2 = T2.AddressLine2,
					@City = T2.City,
					@State = T2.State,
					@County = T2.County,
					@Zip = T2.Zip,
					@ZipPlus4 = T2.ZipPlus4,
					@Country = T2.Country,
					@Latitude = T2.Latitude,
					@Longitude = T2.Longitude,
					@GeographicArea = T2.GeographicArea
				From KYPPORTAL.PortalKYP.pPDM_Location t1
				Join KYPPORTAL.PortalKYP.pPDM_Address T2 on t1.AddressID = T2.AddressID
				Where t1.PartyID = @party_id_app
					and t1.Type='Mailing';					
			
			Update T4
			Set T4.AddressLine1 = @AddressLine1,
				T4.AddressLine2 = @AddressLine2,
				T4.City = @City,
				T4.State = @State,
				T4.County = @County,
				T4.Zip = @Zip,
				T4.ZipPlus4 = @ZipPlus4,
				T4.Country = @Country,
				T4.Latitude = @Latitude,
				T4.Longitude = @Longitude,
				t4.GeographicArea = @GeographicArea,
				T4.LastActionDate = GETDATE(),
				T4.LastActionUserID = @plast_Action_User_ID,
				T4.LastActionComments = isnull(T4.LastActionComments,'')+'MailToAddress_Spread'
			Output T2.AccountID,Deleted.AddressLine1,Deleted.AddressLine2,Deleted.City,Deleted.State,Deleted.County,Deleted.ZipPlus4
											INTO @Tab_MailAddress(Accountid,
																		AddressLine1,
																		AddressLine2,
																		City,
																		State,
																		County,
																		Zip)		
			From Kypenrollment.padm_Account T1
			Join kypenrollment.padm_Account t2 on t1.NPI = T2.NPI --and T1.OwnerNo = T2.OwnerNo and T1.ServiceLocationNo = T2.ServiceLocationNo --Commented OwnerNo and ServiceLocationNo for KEN-20822
			Join kypenrollment.paccount_pdm_location T3 on T2.Partyid=T3.PartyID
			Join kypenrollment.pAccount_PDM_Address t4 on T3.AddressID = T4.AddressID
			Where T2.IsDeleted = 0
				and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
				and T2.ServiceLocationNo = @ServiceLocationNo --Added this condition for KEN-20822			
				and T1.AccountID=@pAccountID
				and T3.Type = 'Mailing'
				and T3.IsDeleted = 0
				and T1.AccountID<>t2.AccountID
				and isnull(t4.AddressLine1,'')+isnull(t4.AddressLine2,'')+isnull(t4.City,'')+isnull(t4.State,'')+isnull(t4.ZipPlus4,'') <> isnull(@AddressLine1,'')+ isnull(@AddressLine2,'')+isnull(@City,'')+isnull(@State,'')+isnull(@ZipPlus4,'') --Added this condition for KEN-20823 
			
			--Update T3
			--Set T3.LastActionDate = getdate(),
			--	T3.LastActorUserID = @plast_Action_User_ID,
			--	T3.LastActionComments = isnull(T3.LastActionComments,'')+'MailToAddress_Spread'
			--From Kypenrollment.padm_Account T1
			--Join kypenrollment.padm_Account t2 on t1.NPI = T2.NPI --and T1.OwnerNo = T2.OwnerNo and T1.ServiceLocationNo = T2.ServiceLocationNo --Commented OwnerNo and ServiceLocationNo for KEN-20822
			--Join kypenrollment.paccount_pdm_location T3 on T2.Partyid=T3.PartyID
			--Where T2.IsDeleted = 0
			--	and T2.OwnerNo = @OwnerNo --Added this condition for KEN-20822
			--	and T2.ServiceLocationNo = @ServiceLocationNo --Added this condition for KEN-20822			
			--	and T1.AccountID=@pAccountID
			--	and T3.Type = 'Mailing'
			--	and T3.IsDeleted = 0
			--	and T1.AccountID<>t2.AccountID	

			--Changed the Update statement for KEN-20823 
			Update T3
			Set T3.LastActionDate = getdate(),
				T3.LastActorUserID = @plast_Action_User_ID,
				T3.LastActionComments = isnull(T3.LastActionComments,'')+'MailToAddress_Spread'
			From Kypenrollment.padm_Account T1
			Join @Tab_MailAddress t2 on t1.AccountID=T2.AccountID
			Join kypenrollment.paccount_pdm_location T3 on T1.Partyid=T3.PartyID
			Where T1.IsDeleted = 0
				and T3.Type = 'Mailing'
				and T3.IsDeleted = 0			
			
		   --Added the below Update Statement for KEN-21574 by Sundar on 5-Apr-2019
		   Update T2
		   Set T2.IsProvOwnedData = 1
		   From @Tab_MailAddress T1
		   Join kypenrollment.Padm_Account T2 on T1.AccountID = T2.AccountID
		   Where T2.IsDeleted = 0
			
			Insert into [Kypenrollment].[NPI_SpreadHistory]([AccountID],
															[FieldName],
															[FromValue],
															[ToValue],
															[LoadDate],
															[SourceApplication],
															[SourceAccountID],
															[LastActorUserID])	
			Select T1.AccountId,'AddressLine1',T1.AddressLine1,@AddressLine1,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID
			From @Tab_MailAddress T1
			Union all
			Select T1.AccountId,'AddressLine2',T1.AddressLine2,@AddressLine2,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID		
			From @Tab_MailAddress T1		
			Union all
			Select T1.AccountId,'City',T1.City,@City,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID
			From @Tab_MailAddress T1	
			Union all				
			Select T1.AccountId,'State',T1.State,@State,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID
			From @Tab_MailAddress T1		
			Union all				
			Select T1.AccountId,'ZipPlus4',T1.Zip,@ZipPlus4,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID
			From @Tab_MailAddress T1	
			Union all				
			Select T1.AccountId,'County',T1.County,@County,Getdate(),@p_ApplicationNo,@pAccountID,@plast_Action_User_ID
			From @Tab_MailAddress T1;
				
			Insert INTO [Kypenrollment].InputDoc_Biller([AccountID],
															[FieldName],
															[FromValue],
															[ToValue],
															DateModified)		
			Select T1.AccountId,'MAdsL1',T1.AddressLine1,@AddressLine1,Getdate()
			From @Tab_MailAddress T1
			Union all
			Select T1.AccountId,'MAdsL2',T1.AddressLine2,@AddressLine2,Getdate()		
			From @Tab_MailAddress T1		
			Union all
			Select T1.AccountId,'MCity',T1.City,@City,Getdate()
			From @Tab_MailAddress T1	
			Union all				
			Select T1.AccountId,'MState',T1.State,@State,Getdate()
			From @Tab_MailAddress T1		
			Union all				
			Select T1.AccountId,'MZipPlus4',T1.Zip,@ZipPlus4,Getdate()
			From @Tab_MailAddress T1
																													
		End
	End Try
	Begin Catch
		 IF @@TRANCOUNT > 0
		 ROLLBACK TRANSACTION 
		  
		 Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'ApplicationNumber',@KeyValue = @p_ApplicationNo; 
		 
	End Catch	
END


GO

