
CREATE VIEW [KYP].[View_PharmacyCOS] as
Select  ROW_NUMBER() OVER(ORDER BY T1.Number ASC) AS RID, T1.Number, T2.ProviderTypeCode,T3.Approved,T3.IsDeleted,T3.EffectiveDate,T3.Activity,T3.Percentage,T3.DescriptionActivity,T3.PartyID
from KYP.ADM_Case T1
Join KYPPORTAL.PortalKYP.pADM_Application T2 on T1.Number = T2.ApplicationNo
Join KYPPORTAL.PortalKYP.pPDM_BusinessActivity T3 on T3.PartyID = T2.PartyID
Where  T3.IsDeleted = 0 
--and T3.Approved = 1


GO

