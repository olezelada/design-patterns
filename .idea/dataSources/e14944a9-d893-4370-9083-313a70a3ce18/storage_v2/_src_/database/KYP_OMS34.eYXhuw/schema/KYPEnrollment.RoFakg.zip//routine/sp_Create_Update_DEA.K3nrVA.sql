-- =============================================
-- Author:		<ohuanca>
-- Create date: <08-03-18>
-- Description:	check if exists tuple of DEA site account
-- Params:
-- @field_code_tracking: field code got from tracking
-- @fieldCode: fieldCode for compare with tracking
-- @new_value_text: NewValueText from tracking
-- @party_id_provider: party id from application
-- @acc_party_id: party id of account
-- @last_action_user_id: identifier from tracking
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_DEA]
  @field_code_tracking VARCHAR(100),
  @fieldCode VARCHAR(100),
  @new_value_text VARCHAR(100),
  @party_id_provider INT,
  @acc_party_id INT,
  @last_action_user_id VARCHAR(100)
AS
BEGIN
  IF @field_code_tracking = @fieldCode
  BEGIN
    IF EXISTS(select DeaID from KYPEnrollment.pAccount_PDM_DEA where PartyID = @acc_party_id AND CurrentRecordFlag = 'true')
    BEGIN
          UPDATE KYPEnrollment.pAccount_PDM_DEA SET DEA = @new_value_text WHERE PartyID = @acc_party_id
          PRINT 'UPDATE TABLE DEA'
    END
    ELSE
    BEGIN
        INSERT INTO KYPEnrollment.pAccount_PDM_DEA (
        DEA,
        PartyID,
        CurrentRecordFlag,
        LastAction,
        LastActionDate,
        LastActorUserID,
        LastActionApprovedBy)
        VALUES(
        @new_value_text,
        @acc_party_id,
        1,
        'C',
        GETDATE(),
        @last_action_user_id,
        @last_action_user_id);

      PRINT 'INSERT TABLE DEA'
    END
  END
END


GO

