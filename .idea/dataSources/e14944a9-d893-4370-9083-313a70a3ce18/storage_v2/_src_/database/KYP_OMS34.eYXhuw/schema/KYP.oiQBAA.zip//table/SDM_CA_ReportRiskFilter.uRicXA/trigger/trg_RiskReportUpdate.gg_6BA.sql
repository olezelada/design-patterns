


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[trg_RiskReportUpdate] 
   ON  [KYP].[SDM_CA_ReportRiskFilter] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	--SET NOCOUNT ON;

    -- Insert statements for trigger here
    
    
    declare @userID varchar(100)
	declare @FromDate date;
	declare @ToDate date;
	declare @riskRange varchar(100);
	declare @providerType varchar(250);
	declare @searchByUserID varchar(100); 
	declare @ReportFilter_ID int;
	declare @ApprovedCount int
	declare @RejectedCount int
	declare @filterCount int
	declare @isApproved varchar(1)
	declare @isRejected varchar(1)

 -- Insert statements for trigger here
	SELECT @ReportFilter_ID = i.ID FROM INSERTED i;	
	SELECT @userID = i.UserID FROM INSERTED i;		
	SELECT @FromDate = cast(i.FromDate as date) FROM INSERTED i;
	SELECT @ToDate = cast(i.ToDate as date) FROM INSERTED i;
	SELECT @riskRange = i.RiskRange FROM INSERTED i;
	SELECT @providerType = i.ProviderType FROM INSERTED i;
	SELECT @SearchByUserID = i.SearchByUserID FROM INSERTED i;
	SELECT @isApproved = i.IsApproved FROM INSERTED i;
	SELECT @isRejected = i.IsRejected FROM INSERTED i;
	
	
	
-- Delete already existing report data for this UserID
	SELECT @filterCount = (SELECT COUNT(UserID) FROM KYP.SDM_CA_ReportRiskFilter 
								WHERE UserID = @UserID AND ID != @ReportFilter_ID);
	PRINT 'Filter Count' 
	PRINT @filterCount
	IF(@filterCount > 0)
	BEGIN
		DELETE FROM KYP.SDM_CA_ReportRiskFilter WHERE UserID = @UserID AND ID != @ReportFilter_ID; 
	END
	
	IF (@SearchByUserID is null OR LTRIM(RTRIM(@SearchByUserID))  = '')
	BEGIN
		SET @SearchByUserID  = '%'
	END	
	
	IF (@riskRange  is null OR LTRIM(RTRIM(@riskRange))  = '')
	BEGIN
		SET @riskRange  = '%'
	END	
	
	IF (@providerType  is null OR LTRIM(RTRIM(@providerType))  = '')
	BEGIN
		SET @providerType  = '%'
	END
	
	-- truncate table of Data 
	truncate table KYP.SDM_CA_RiskRangeReport
	truncate table KYP.SDM_CA_RiskReportTableChart
	PRINT '@FromDate' 
	PRINT @FromDate
	PRINT '@ToDate' 
	PRINT @ToDate
	PRINT '@riskRange' 
	PRINT @riskRange
	PRINT '@providerType' 
	PRINT @providerType
	PRINT '@searchByUserID' 
	PRINT @searchByUserID
	
	SELECT @ToDate = CONVERT(VARCHAR,Cast(@ToDate as datetime) + 1, 101)
	
	IF @isApproved = 'Y' AND @isRejected = 'Y'
	BEGIN
	/* INSERT DATA FOR BAR CHART*/
	insert into KYP.SDM_CA_RiskRangeReport
	Select X.UserID,X.Range,X.Approved,X.Rejected,X.ReportFilter_ID from (	
		Select 
			Case WHEN Range LIKE '>500'	  THEN 6		
				 WHEN Range LIKE '401-500' THEN 5 
				 WHEN Range LIKE '301-400' THEN 4
				 WHEN Range LIKE '201-300' THEN 3
				 WHEN Range LIKE '100-200' THEN 2 
		         WHEN Range LIKE '<100'    THEN 1 
		         ELSE 0  END As SortOrder, @userID As UserID,Range,
			SUM( Case 
				 WHEN Range LIKE '>500' AND Status = 'Approved' THEN 1 
			     WHEN Range LIKE '401-500' AND Status = 'Approved' THEN 1 
		         WHEN Range LIKE '301-400' AND Status = 'Approved' THEN 1
		         WHEN Range LIKE '201-300' AND Status = 'Approved' THEN 1
		         WHEN Range LIKE '100-200' AND Status = 'Approved' THEN 1 
		         WHEN Range LIKE '<100' AND Status = 'Approved' THEN 1 
		         ELSE 0 END) As Approved,
		  SUM( CASE WHEN Range LIKE '>500' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '401-500' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '301-400' AND Status = 'Rejected' THEN 1
				WHEN Range LIKE '201-300' AND Status = 'Rejected' THEN 1
				WHEN Range LIKE '100-200' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '<100' AND Status = 'Rejected' THEN 1 
				ELSE 0 END) As Rejected , @ReportFilter_ID As ReportFilter_ID
		from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
		AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
		TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
	GROUP BY Range ) X ORDER BY X.SortOrder Desc
	
	/* INSERT DATA FOR TABLE CHART*/
	INSERT INTO KYP.SDM_CA_RiskReportTableChart
	Select ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
			DateResolved,CurrentlyAssignedToName,Range,RCount,DateAssigned,DateReceived from(
		Select 
				Case	WHEN Range LIKE '>500'	  THEN 6		
						WHEN Range LIKE '401-500' THEN 5 
						WHEN Range LIKE '301-400' THEN 4
						WHEN Range LIKE '201-300' THEN 3
						WHEN Range LIKE '100-200' THEN 2 
						WHEN Range LIKE '<100'    THEN 1 
						ELSE 0  END As SortOrder,
				ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
				DateResolved,CurrentlyAssignedToName,Range, 
				(Select COUNT(ApplicationID) from KYP.v_RiskRangeAcceptReject 
				WHERE (DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID) AS RCount,
				DateAssigned,DateReceived
				from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
				
	) Y ORDER BY Y.SortOrder Desc
	
    END
    
	IF @isApproved = 'Y' AND @isRejected = 'N'
	BEGIN
		insert into KYP.SDM_CA_RiskRangeReport
	Select X.UserID,X.Range,X.Approved,X.Rejected,X.ReportFilter_ID from (	
		Select 
			Case WHEN Range LIKE '>500'	  THEN 6		
				 WHEN Range LIKE '401-500' THEN 5 
				 WHEN Range LIKE '301-400' THEN 4
				 WHEN Range LIKE '201-300' THEN 3
				 WHEN Range LIKE '100-200' THEN 2 
		         WHEN Range LIKE '<100'    THEN 1 
		         ELSE 0  END As SortOrder, @userID As UserID,Range,
			SUM( Case 
				 WHEN Range LIKE '>500' AND Status = 'Approved' THEN 1 
			     WHEN Range LIKE '401-500' AND Status = 'Approved' THEN 1 
		         WHEN Range LIKE '301-400' AND Status = 'Approved' THEN 1
		         WHEN Range LIKE '201-300' AND Status = 'Approved' THEN 1
		         WHEN Range LIKE '100-200' AND Status = 'Approved' THEN 1 
		         WHEN Range LIKE '<100' AND Status = 'Approved' THEN 1 
		         ELSE 0 END) As Approved,
		  0 As Rejected , @ReportFilter_ID As ReportFilter_ID
		from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
		AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
		TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
	GROUP BY Range ) X ORDER BY X.SortOrder Desc
	
	/* INSERT DATA FOR TABLE CHART*/
	INSERT INTO KYP.SDM_CA_RiskReportTableChart
	Select ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
			DateResolved,CurrentlyAssignedToName,Range,RCount,DateAssigned,DateReceived from(
		Select 
				Case	WHEN Range LIKE '>500'	  THEN 6		
						WHEN Range LIKE '401-500' THEN 5 
						WHEN Range LIKE '301-400' THEN 4
						WHEN Range LIKE '201-300' THEN 3
						WHEN Range LIKE '100-200' THEN 2 
						WHEN Range LIKE '<100'    THEN 1 
						ELSE 0  END As SortOrder,
				ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
				DateResolved,CurrentlyAssignedToName,Range, 
				(Select COUNT(ApplicationID) from KYP.v_RiskRangeAcceptReject 
				Where 
				(DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
				AND Status = 'Approved') AS RCount,
				DateAssigned,DateReceived
				from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
				AND Status = 'Approved'
				
	) Y ORDER BY Y.SortOrder Desc
	
	END
	
	
	IF @isApproved = 'N' AND @isRejected = 'Y'
	BEGIN
	
	insert into KYP.SDM_CA_RiskRangeReport
	Select X.UserID,X.Range,X.Approved,X.Rejected,X.ReportFilter_ID from (	
		Select 
			Case WHEN Range LIKE '>500'	  THEN 6		
				 WHEN Range LIKE '401-500' THEN 5 
				 WHEN Range LIKE '301-400' THEN 4
				 WHEN Range LIKE '201-300' THEN 3
				 WHEN Range LIKE '100-200' THEN 2 
		         WHEN Range LIKE '<100'    THEN 1 
		         ELSE 0  END As SortOrder, @userID As UserID,Range,
				0 As Approved,
		  SUM( CASE WHEN Range LIKE '>500' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '401-500' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '301-400' AND Status = 'Rejected' THEN 1
				WHEN Range LIKE '201-300' AND Status = 'Rejected' THEN 1
				WHEN Range LIKE '100-200' AND Status = 'Rejected' THEN 1 
				WHEN Range LIKE '<100' AND Status = 'Rejected' THEN 1 
				ELSE 0 END) As Rejected , @ReportFilter_ID As ReportFilter_ID
		from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
		AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
		TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
		GROUP BY Range ) X ORDER BY X.SortOrder Desc
		
		
		/* INSERT DATA FOR TABLE CHART*/
	INSERT INTO KYP.SDM_CA_RiskReportTableChart
	Select ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
			DateResolved,CurrentlyAssignedToName,Range,RCount,DateAssigned,DateReceived from(
		Select 
				Case	WHEN Range LIKE '>500'	  THEN 6		
						WHEN Range LIKE '401-500' THEN 5 
						WHEN Range LIKE '301-400' THEN 4
						WHEN Range LIKE '201-300' THEN 3
						WHEN Range LIKE '100-200' THEN 2 
						WHEN Range LIKE '<100'    THEN 1 
						ELSE 0  END As SortOrder,
				ApplicationID,Number,ProviderName,TypeDescription,NormalizedRisk,CompositeRisk,Status,
				DateResolved,CurrentlyAssignedToName,Range, 
				(Select COUNT(ApplicationID) from KYP.v_RiskRangeAcceptReject  
				where (DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
				AND Status = 'Rejected') AS RCount,
				DateAssigned,DateReceived
				from KYP.v_RiskRangeAcceptReject where (DateResolved >= @FromDate 
				AND DateResolved <= @ToDate) AND Range LIKE @riskRange AND 
				TypeDescription LIKE @providerType AND 	CurrentlyAssignedToName LIKE @searchByUserID
				AND Status = 'Rejected'
				
	) Y ORDER BY Y.SortOrder Desc
		
	
	END

END


GO

