

/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create DEA.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_id_app : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @dea_id_app : this is the DeaID Application that will be Create in Update Account, it is Null when account is create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Dea]
   @party_account_id       INT,
   @party_id_app           INT,
   @last_action_user_id    VARCHAR (100),
   @dea_id_app             INT
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE;
   SET @date_created = GETDATE ();

   IF @party_id_app IS NULL
      BEGIN
         INSERT INTO [KYPEnrollment].[pAccount_PDM_DEA] (
                        [PartyID],
                        [DEA],
                        [ExpiryDate],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [DocumentInstanceId]) -- New columns for new Packages MD.
            SELECT @party_account_id,
                   [DEA],
                   [ExpiryDate],
                   'C',
                   @date_created,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [documentInstanceId]    -- New columns for new Packages MD.
              FROM [KYPPORTAL].[PortalKYP].[pPDM_DEA]
             WHERE DeaID = @dea_id_app
      END
   ELSE
      BEGIN
         INSERT INTO [KYPEnrollment].[pAccount_PDM_DEA] (
                        [PartyID],
                        [DEA],
                        [ExpiryDate],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag],
                        [DocumentInstanceId]) -- New columns for new Packages MD.
            SELECT @party_account_id,
                   [DEA],
                   [ExpiryDate],
                   'C',
                   @date_created,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [documentInstanceId]    -- New columns for new Packages MD.
              FROM [KYPPORTAL].[PortalKYP].[pPDM_DEA]
             WHERE PartyID = @party_id_app AND IsDeleted = 0
      END
END


GO

