-- =============================================
-- Author:		Sheetal
-- Create date: 19-Dec-2012
-- Description:	Procedure to insert Impacted
--				Providers with non-repeated values
-- =============================================
CREATE PROCEDURE [dbo].[InsertMissedImpProv] 
	
AS 
BEGIN
	DECLARE 
		@ParentOrChildAlertID INT
		
		
	DECLARE mycursorA CURSOR FOR   
    SELECT AlertID from KYP.MDM_Alert where isMerged='N' 
    and currentWFStatus in ('CloseAlert','ProvideResolution','IdentifyImpact')
    and AlertID not in 
    (select AlertID from KYP.MDM_ImpProviders) 
     order by AlertID
    
   	OPEN mycursorA
	FETCH NEXT FROM mycursorA INTO @ParentOrChildAlertID
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		  exec dbo.createImpProv @ParentOrChildAlertID
		  FETCH NEXT FROM mycursorA INTO @ParentOrChildAlertID	
	END
	CLOSE mycursorA 
	DEALLOCATE mycursorA
END


GO

