

CREATE VIEW [KYP].[v_Alerts_Weekly_OverDue]
AS
SELECT     TOP (100) PERCENT row_number() OVER (ORDER BY A.AlertNo ASC) AS ID, A.AlertNo AS AlertNumber, A.WatchedPartyName AS PartyName, 
A.MatchPercent, A.DateInitiated AS AlertDate, B.FullName AS AssignedToUserName, B.EmailID AS AssignedToUserEmailID, D .FullName AS ManagerName, 
D .EmailID AS ManagerEmailID, A.AssignedDate AS AssignedDate, datediff(day, A.AssignedDate, ISNULL(A.DateClosed, getdate())) 
AS AlertAgeFromAssignment, A.Priority
FROM         KYP.MDM_Alert A INNER JOIN
                      KYP.OIS_User B ON A.AssignedToUserID = B.PersonID LEFT JOIN
                      KYP.OIS_Managee C ON B.UserID = C.ManageeName LEFT JOIN
                      KYP.OIS_User D ON C.ManagerID = D .UserID
WHERE     dateadd(day, 7, A.AssignedDate) <= ISNULL(A.DateClosed, getdate()) AND ISNULL(B.Active, 1) = 1 AND A.WFStatus <> 'Completed'
ORDER BY AlertAgeFromAssignment DESC


GO

