

CREATE VIEW [KYP].[v_TimeToFirstAssignmentChart]
AS

SELECT W.week As week, W.WeekStartDate As WeekStartDate,ISNULL(X.TFFA_Days,0) As TFFA_Days, X.DateCreated As DateCreated,X.DateAssigned As DateAssigned,
W.weekFormattedDate As weekFormattedDate, ISNULL(X.CTFFA,0) As CTFFA FROM

(
SELECT 1 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), 0) AS WeekStartDate ,   CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 0), 101) AS weekFormattedDate  UNION ALL
SELECT 2 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 7), 101) AS weekFormattedDate UNION ALL
SELECT 3 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 14), 101) AS weekFormattedDate UNION ALL
SELECT 4 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 21), 101) AS weekFormattedDate UNION ALL
SELECT 5 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 28), 101) AS weekFormattedDate UNION ALL
SELECT 6 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 35), 101) AS weekFormattedDate UNION ALL
SELECT 7 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 42), 101) AS weekFormattedDate UNION ALL
SELECT 8 As week , DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49) AS WeekStartDate , CONVERT(VARCHAR(5),DATEADD(WK, DATEDIFF(WK, 0, GETDATE()), - 49), 101) AS weekFormattedDate) W 

LEFT JOIN (

SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(1)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 1
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(2)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 2
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(3)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 3
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(4)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 4
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(5)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 5
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(6)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 6
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(7)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 7
UNION ALL
SELECT     Week AS week, WeekStartDate, TFFA_Days, DateCreated, DateAssigned, weekFormattedDate,
                          (SELECT     KYP.calculateCummulativeTimeToFirstAssignment(8)) AS CTFFA
FROM         KYP.v_TimeToFirstAssignment
WHERE     Week = 8
)X ON X.week = W.week


GO

