

CREATE procedure [KYP].[p_InsertADMCaseExtended]
(
   @Number  varchar(15)
  ,@CaseID int
  ,@Ground bit
  ,@Air bit
  ,@ISDMC bit
  ,@NewAccountName varchar(200)=NULL
  ,@IsFBP bit
  ,@isReactivation bit = NULL
  ,@ReactivationAccNo varchar(max) = NULL
  ,@ReactivateAppType varchar(25) = NULL
  ,@CHOWLocationType varchar(5)
  ,@CHOWAccountNo varchar (20)
  ,@IsDppApp bit
  ,@ChangeServiceAddress int /** ADDED for CAPAVE-3812**/
)
as begin 






INSERT INTO [KYP].[ADM_CaseExtended]
           ([Number]
           ,[CaseID]
           ,[AirTransportation]
           ,[GroundTransportation]
           ,[ISDMCNEWACCOUNTREQUIRED]
           ,[NewAccountRequired]
           ,[IsFacilityBasedProvider]
           ,[isReactivation]
           ,[ReactivationAccNo]
           ,[ReactivateAppType]
           ,[CHOWAccountNoOrProfileID]
           ,[CHOWLocationType]
           ,[IsServiceAddressChange]/** ADDED for CAPAVE-3812**/
           ,[ISDPP]
           )

     VALUES
          ( @Number
           ,@CaseID
           ,@Air
           ,@Ground
           ,@ISDMC
           ,@NewAccountName
           ,@IsFBP
           ,@isReactivation
           ,@ReactivationAccNo
           ,@ReactivateAppType
           ,@CHOWAccountNo
           ,@CHOWLocationType
           ,case when(@ChangeServiceAddress > 0) then 1 else 0 END /** ADDED for CAPAVE-3812**/
           ,@IsDppApp
)



end


GO

