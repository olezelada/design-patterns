
/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Update_Adverse_Provider]
	@PartyOwner INT,
	@party_id INT,
	@last_action VARCHAR(1)

AS

BEGIN
	DECLARE @mainParty INT, @TypeAssociation VARCHAR(50), @new_Party_Id INT
	
	DECLARE @partyMoca TABLE (ID INT IDENTITY(1,1),PartyID INT)
	 INSERT INTO  @partyMoca SELECT PartyID FROM [KYPEnrollment].[pAccount_PDM_Party] WHERE ParentPartyID= @party_id AND Type='InvActionQuestion'
	 DECLARE @count_partyMoca_Id INT,@top_PartyMocaId INT, @partyMocaIdUpdate INT, @typeMocaUpdate VARCHAR(20)
	 SELECT @top_PartyMocaId = MAX(ID) FROM @partyMoca; 
	 SET @count_partyMoca_Id = 1
	 WHILE @count_partyMoca_Id <= @top_PartyMocaId
	 BEGIN
		dECLARE @PartyAdverse int, @provId int ,  @adverse int, @ccountID int
		select  @PartyAdverse = PartyID from @partyMoca where ID=@count_partyMoca_Id;
		select @ccountID = AccountID FROM [KYPEnrollment].pAccount_PDM_Party WHERE ParentPartyID=@PartyOwner and Type='InvActionQuestion'
		update [KYPEnrollment].pAccount_PDM_Party set CurrentRecordFlag =0  WHERE ParentPartyID=@PartyOwner and Type='InvActionQuestion'
		
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
			([ParentPartyID],[Type] ,[Name] ,[AccountID] ,[IsEnrolled] ,[IsTemp] ,[IsActive] ,[LoadType] ,[LoadID] ,[LastLoadDate] ,[DateModified] ,[CurrentRecordFlag]
			,[Source] ,[LastAction] ,[LastActionDate] ,[profile_id],[IsDeleted],[LastActorUserID],[LastActionApprovedBy])		
		SELECT @PartyOwner, [Type],[Name],@ccountID,[IsEnrolled] ,[IsTemp] ,[IsActive] ,[LoadType] ,[LoadID] ,[LastLoadDate] ,[DateModified] ,[CurrentRecordFlag]
			,[Source] ,@last_action ,[LastActionDate] ,[profile_id],[IsDeleted],[LastActorUserID],[LastActionApprovedBy]
			FROM [KYPEnrollment].[pAccount_PDM_Party] WHERE PartyID = @PartyAdverse AND CurrentRecordFlag = 1 AND Type='InvActionQuestion'
		
		SELECT @new_Party_Id = SCOPE_IDENTITY();
		
		INSERT INTO [KYPEnrollment].[pAccount_PDM_AdverseAction]
           ([PartyID] ,[Type_x],[Reason],[State_x],[Date_x],[DateType],[EffectiveDate],[NPI],[City]
           ,[ProgramType],[Where_x],[Action_x],[LicenseAuthority],[CreatedBy],[DateCreated],[ModifiedBy]
           ,[DateModified],[DeletedBy],[DateDeleted],[IsDeleted],[LegalName],[DBA],[AppFormID],[documentInstanceId]
           ,[LastAction],[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag],[ProgramTypeOther])
		SELECT @new_Party_Id,[Type_x],[Reason],[State_x],[Date_x],[DateType],[EffectiveDate],[NPI],[City]
           ,[ProgramType],[Where_x],[Action_x],[LicenseAuthority],[CreatedBy],[DateCreated],[ModifiedBy]
           ,[DateModified],[DeletedBy],[DateDeleted],[IsDeleted],[LegalName],[DBA],[AppFormID],[documentInstanceId]
           ,@last_action,[LastActionDate],[LastActorUserID],[LastActionReason],[LastActionComments]
           ,[LastActionApprovedBy],[CurrentRecordFlag],[ProgramTypeOther] FROM [KYPEnrollment].[pAccount_PDM_AdverseAction] WHERE PartyID=@PartyAdverse
          
          SELECT @adverse = SCOPE_IDENTITY();
                      
        INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID],[Category],[Type],[CreatedBy] ,[DateCreated],[IsDeleted],[NPI],[LastAction]
           ,[LastActionDate],[LastActorUserID],[LastActionApprovedBy],[CurrentRecordFlag])
		SELECT @new_Party_Id,[Category],[Type],[CreatedBy] ,[DateCreated],[IsDeleted],[NPI],@last_action
           ,[LastActionDate],[LastActorUserID],[LastActionApprovedBy],[CurrentRecordFlag] FROM [KYPEnrollment].[pAccount_PDM_Provider] WHERE PartyID=@PartyAdverse
           
           SELECT @provId = SCOPE_IDENTITY();   
	  SET @count_partyMoca_Id = @count_partyMoca_Id+1
	 END
END


GO

