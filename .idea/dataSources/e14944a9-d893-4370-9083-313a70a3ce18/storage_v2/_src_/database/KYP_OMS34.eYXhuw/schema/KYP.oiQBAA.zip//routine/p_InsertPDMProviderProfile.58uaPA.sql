
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[p_InsertPDMProviderProfile] 
 (		   @ProfileName varchar(150)=NULL
           ,@NPI int=NULL
           ,@TIN varchar(11)=NULL
           ,@SSN varchar(11)=NULL
           ,@PracticeType varchar(50)=NULL
           ,@DateCreated datetime=NULL
           ,@DateDeleted datetime=NULL
           ,@IsDeleted bit=0)
as begin 

INSERT INTO [KYP].[PDM_ProviderProfile]
           ([ProfileName]
           ,[NPI]
           ,[TIN]
           ,[SSN]
           ,[PracticeType]
           ,[DateCreated]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@ProfileName
           ,@NPI
           ,@TIN
           ,@SSN
           ,@PracticeType
           ,@DateCreated
           ,@DateDeleted
           ,@IsDeleted)
			
	return IDENT_CURRENT('[KYP].[PDM_ProviderProfile]')

end


GO

