CREATE PROCEDURE [dbo].[AdressUpdate] @ServerName VARCHAR(250)
	,@DatabaseName VARCHAR(250)
	,@UserName VARCHAR(100)
	,@Password VARCHAR(100)
AS
BEGIN
	DECLARE @SQLQuery NVARCHAR(4000)
		,@Combine1 VARCHAR(1000)
		,@Combine2 VARCHAR(1000)
		,@Person VARCHAR(50)
		,@Organization VARCHAR(50)
		,@LoginServer VARCHAR(250)
		,@LoginUsername VARCHAR(100)
		,@LoginPwd VARCHAR(100)

	/* ADDING LINKED SERVER */
	SET @LoginServer = '[' + @ServerName + ']'
	SET @LoginUsername = '[' + @UserName + ']'
	SET @LoginPwd = '[' + @Password + ']'

	IF NOT EXISTS (
			SELECT *
			FROM sys.servers
			WHERE NAME = @ServerName
			)
	BEGIN
		EXECUTE sp_addlinkedserver @LoginServer

		EXECUTE sp_addlinkedsrvlogin @LoginServer
			,'false'
			,@LoginUsername
			,@LoginUsername
			,@LoginPwd
	END

	/*Bug : KYP-18176*/
	DECLARE @pmfloaddate DATETIME

	SELECT TOP 1 @pmfloaddate = fileloaddate
	FROM KYP.MDM_MonthlyActiveProvider
	ORDER BY id DESC

	IF OBJECT_ID('tempdb..#searchparty') IS NOT NULL
	BEGIN
		DROP TABLE #searchparty
	END

	CREATE TABLE #searchparty (
		searchpartyid INT
		,hmsid VARCHAR(32) collate SQL_Latin1_General_CP1_CI_AS
		)

	INSERT INTO #searchparty
	SELECT DISTINCT p.SearchPartyID
		,NULL
	FROM KYP.MDM_SearchProviders p
	INNER JOIN KYP.MDM_Alert m ON p.SearchPartyID = m.WatchedPartyID
	WHERE m.DateInitiated >= @pmfloaddate

	UPDATE x
	SET x.hmsid = p.HMS_ID
	FROM KYP.MDM_SearchProviders p
	INNER JOIN #searchparty x ON p.SearchPartyID = x.searchpartyid
	WHERE p.HMS_ID IS NOT NULL

	--TRUNCATE TABLE KYP.MDM_PartyAddress 
	SET @Combine1 = 'y.ADDRESS1+''' + ' ' + '''+y.CITY+''' + ' ' + '''+y.STATE+''' + ' ' + '''+y.ZIP'
	SET @Combine2 = 'a.AddressLine1+''' + ' ' + '''+a.CITY+''' + ' ' + '''+a.STATE+''' + ' ' + '''+a.ZIP'
	SET @Person = 'Person'
	SET @Organization = 'Organization'
	SET @SQLQuery = 'INSERT INTO KYP.MDM_PartyAddress 
SELECT x.SearchPartyID,(' + @Combine1 + ') AS Address,y.ADDRESS1,y.City,y.State,y.ZIP
FROM #searchparty x
	INNER JOIN [' + @ServerName + '].[' + @DatabaseName + '].dbo.HMS_OrganizatiON y
	ON y.HMS_POID = x.hmsid
	INNER JOIN KYP.PDM_Party p
	ON p.PartyID = x.SearchPartyID
WHERE x.hmsid IS NOT NULL AND p.Type =''' + @Organization + ''' 
UNION 
SELECT x.SearchPartyID,(' + @Combine1 + ') AS Address,y.ADDRESS1,y.City,y.State,y.ZIP
FROM #searchparty x
	INNER JOIN [' + @ServerName + '].[' + @DatabaseName + '].dbo.HMS_Individual_Address y
	ON y.HMS_PIID = x.hmsid
	INNER JOIN KYP.PDM_Party p
	ON p.PartyID = x.SearchPartyID
WHERE x.hmsid IS NOT NULL AND p.Type =''' + @Person + '''
UNION 
SELECT x.SearchPartyID,(' + @Combine2 + ') AS Address,a.AddressLine1,a.City,a.State,a.ZIP
FROM #searchparty x
	INNER JOIN KYP.PDM_LocatiON b
	ON b.PartyID=x.SearchPartyID
	INNER JOIN KYP.PDM_Address a
	ON a.AddressID = b.AddressID
WHERE (' + @Combine2 + ') IS NOT NULL'

	EXECUTE sp_Executesql @SQLQuery
END
GO

