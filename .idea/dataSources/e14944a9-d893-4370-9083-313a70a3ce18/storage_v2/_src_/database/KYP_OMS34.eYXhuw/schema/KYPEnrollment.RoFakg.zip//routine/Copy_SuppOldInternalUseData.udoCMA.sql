



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[Copy_SuppOldInternalUseData] 
@AccountID int, @AccountInternalUseID int
	
AS
BEGIN

Declare
	

	
		@AccInternalUseID int,
    @CreatedBy varchar(100),
    @LastActionReason varchar(500)

    	
		--Combined select and update statement
	UPDATE b
	SET
	 BillingStatus = a.BillingStatus 
	,b.BillingBeginDate = a.BillingBeginDate 
	,b.BillingEndDate = a.BillingEndDate 
	,b.BillingFutureStatus = a.BillingFutureStatus
	,b.BillingFutureDate = a.BillingFutureDate
	,b.BillingComments = a.BillingComments
	,b.BillingFutureComments = a.BillingFutureComments
	,b.ProvisionalCode = a.ProvisionalCode
	,b.ProvisionalCodeDate = a.ProvisionalCodeDate
	,b.ProvisionalCodeDesc = a.ProvisionalCodeDesc
	,b.LabStatusCode = a.LabStatusCode
	,b.LabSpecCodeDesc = a.LabSpecCodeDesc
	,b.LabStatusCodeDate = a.LabStatusCodeDate
	,b.OutOfStateInd = a.OutOfStateInd
	,b.OutOfStateIndDesc = a.OutOfStateIndDesc
	,b.SpecProcTypeCode = a.SpecProcTypeCode
	,b.SpecProcTypeCodeDesc = a.SpecProcTypeCodeDesc
	,b.ProvCrossReferenceValue = a.ProvCrossReferenceValue
	,b.CHDPCode = a.CHDPCode
	,b.AtypicalProviderNo = a.AtypicalProviderNo
	--,b.PhyCertCode = a.PhyCertCode
	--,b.PhyCertCodeDesc = a.PhyCertCodeDesc
	--,b.PhyCertCodeEfDate = a.PhyCertCodeEfDate
	,b.ReEnrolInd = a.ReEnrolInd
	,b.ReEnrolDate = a.ReEnrolDate
	,b.PracTypeCode1 = a.PracTypeCode1
	,b.PracTypeCode1Desc = a.PracTypeCode1Desc
	,b.PracTypeCode2 = a.PracTypeCode2
	,b.PracTypeCode2Desc = a.PracTypeCode2Desc
	,b.TINUpdateType = a.TINUpdateType
	,b.TINUpdateTypeDesc = a.TINUpdateTypeDesc
	,b.TINUpdateDate = a.TINUpdateDate
	 FROM [KYPEnrollment].[EDM_AccountInternalUse] a
	join
	[KYPEnrollment].[EDM_SupplementalInternalUse] b
	on a.accountid = b.accountid
	WHERE b.AccountID = @AccountID;
	
	SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_SupplementalInternalUse] WHERE AccountID=@AccountID
	


	--Removed while loop for set based operation
 IF OBJECT_ID('tempdb..#AccInternalUseManyIDtemp2') IS NOT NULL
     DROP TABLE #AccInternalUseManyIDtemp2;

	Select AccInternalUseManyID-- ,AccountInternalUseID
	into #AccInternalUseManyIDtemp2 
	FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID = @AccountInternalUseID

	INSERT INTO [KYPEnrollment].[EDM_SupplementalInteranlMany]
	    ([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[LastActionReason])

		SELECT @AccInternalUseID,
		[CodeIdentification],
		[CodeDescription],
		[CodeType],
		[CodeDateEffDate],
		[CodeDateExpDate],
	     @createdby,
		 @LastActionReason
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID  in (Select AccInternalUseManyID from #AccInternalUseManyIDtemp2)
		
	
	
	
		
/*	@BillingStatus varchar(30),
	@BillingBeginDate smalldatetime,
	@BillingEndDate smalldatetime,
	@BillingFutureStatus varchar(30),
	@BillingFutureDate smalldatetime,
	@BillingComments varchar(500),
	@BillingFutureComments varchar(500),
	@ProvisionalCode varchar(2),
	@ProvisionalCodeDate smalldatetime,
	@ProvisionalCodeDesc varchar(200),
	@LabStatusCode varchar(30),
	@LabSpecCodeDesc varchar(200),
	@LabStatusCodeDate smalldatetime,
	@OutOfStateInd varchar(1),
	@OutOfStateIndDesc varchar(200),
	@SpecProcTypeCodeDesc varchar(200),
	@SpecProcTypeCode varchar(10),
	@ProvCrossReferenceValue varchar(20),
	@CHDPCode varchar(150),
	@AtypicalProviderNo varchar(11),
	--@PhyCertCode varchar(2),
	--@PhyCertCodeDesc varchar(200),
	--@PhyCertCodeEfDate smalldatetime,
	@ReEnrolInd varchar(10),
	@ReEnrolDate smalldatetime,
	@PracTypeCode1 varchar(1),
	@PracTypeCode1Desc varchar(250),
	@PracTypeCode2 varchar(1),
	@PracTypeCode2Desc varchar(250),
	@TINUpdateType varchar(5),
	@TINUpdateTypeDesc varchar(250),
	@TINUpdateDate smalldatetime,
	@AccInternalUseID int
	
Declare
	
    @CodeIdentification varchar(10),
    @CodeDescription varchar(250),
    @CodeType varchar(10),
    @CodeDateEffDate smalldatetime,
    @CodeDateExpDate smalldatetime,
    @CreatedBy varchar(100),
    @LastActionReason varchar(500)

    
	SELECT @BillingStatus =[BillingStatus],@BillingBeginDate =[BillingBeginDate],@BillingEndDate =[BillingEndDate],
	@BillingFutureStatus =[BillingFutureStatus],@BillingFutureDate =[BillingFutureDate],@BillingComments =[BillingComments],
	@BillingFutureComments =[BillingFutureComments],@ProvisionalCode =[ProvisionalCode],@ProvisionalCodeDate =[ProvisionalCodeDate],
	@ProvisionalCodeDesc =[ProvisionalCodeDesc],@LabStatusCode =[LabStatusCode],@LabSpecCodeDesc =[LabSpecCodeDesc],@LabStatusCodeDate =[LabStatusCodeDate],
	@OutOfStateInd =[OutOfStateInd],@OutOfStateIndDesc =[OutOfStateIndDesc],@SpecProcTypeCode =[SpecProcTypeCode],@SpecProcTypeCodeDesc =[SpecProcTypeCodeDesc],
	@ProvCrossReferenceValue =[ProvCrossReferenceValue],@CHDPCode =[CHDPCode], @AtypicalProviderNo =[AtypicalProviderNo],@ReEnrolInd =[ReEnrolInd],@ReEnrolDate =[ReEnrolDate],
	--@PhyCertCode =[PhyCertCode],@PhyCertCodeDesc =[PhyCertCodeDesc],@PhyCertCodeEfDate =[PhyCertCodeEfDate],
	@PracTypeCode1 =[PracTypeCode1], @PracTypeCode1Desc=[PracTypeCode1Desc],
	@PracTypeCode2 =[PracTypeCode2],@PracTypeCode2Desc =[PracTypeCode2Desc],@TINUpdateType =[TINUpdateType], @TINUpdateTypeDesc=[TINUpdateTypeDesc],
	@TINUpdateDate =[TINUpdateDate] FROM [KYPEnrollment].[EDM_AccountInternalUse]
	WHERE AccountID =@AccountID
	
	PRINT @AccountID
	
	declare @AppCount int;
	
	SELECT @AppCount = COUNT(AccInternalUseManyID) FROM [KYPEnrollment].[EDM_AccountInternalMany]
	WHERE AccountInternalUseID =@AccountInternalUseID 		
	
	
	PRINT @AccountInternalUseID
	
	UPDATE [KYPEnrollment].[EDM_SupplementalInternalUse]
	SET
	 BillingStatus = @BillingStatus 
	,BillingBeginDate = @BillingBeginDate 
	,BillingEndDate = @BillingEndDate 
	,BillingFutureStatus = @BillingFutureStatus
	,BillingFutureDate = @BillingFutureDate
	,BillingComments = @BillingComments
	,BillingFutureComments = @BillingFutureComments
	,ProvisionalCode = @ProvisionalCode
	,ProvisionalCodeDate = @ProvisionalCodeDate
	,ProvisionalCodeDesc = @ProvisionalCodeDesc
	,LabStatusCode = @LabStatusCode
	,LabSpecCodeDesc = @LabSpecCodeDesc
	,LabStatusCodeDate = @LabStatusCodeDate
	,OutOfStateInd = @OutOfStateInd
	,OutOfStateIndDesc = @OutOfStateIndDesc
	,SpecProcTypeCode = @SpecProcTypeCode
	,SpecProcTypeCodeDesc = @SpecProcTypeCodeDesc
	,ProvCrossReferenceValue = @ProvCrossReferenceValue
	,CHDPCode = @CHDPCode
	,AtypicalProviderNo = @AtypicalProviderNo
	--,PhyCertCode = @PhyCertCode
	--,PhyCertCodeDesc = @PhyCertCodeDesc
	--,PhyCertCodeEfDate = @PhyCertCodeEfDate
	,ReEnrolInd = @ReEnrolInd
	,ReEnrolDate = @ReEnrolDate
	,PracTypeCode1 = @PracTypeCode1
	,PracTypeCode1Desc = @PracTypeCode1Desc
	,PracTypeCode2 = @PracTypeCode2
	,PracTypeCode2Desc = @PracTypeCode2Desc
	,TINUpdateType = @TINUpdateType
	,TINUpdateTypeDesc = @TINUpdateTypeDesc
	,TINUpdateDate = @TINUpdateDate
	WHERE AccountID = @AccountID;
	
	SELECT @AccInternalUseID = AccountInternalUseID FROM [KYPEnrollment].[EDM_SupplementalInternalUse] WHERE AccountID=@AccountID
	
	Declare @accManyUserID int;
	
	WHILE(@AppCount > 0)
	BEGIN
		SELECT @accManyUserID=X.AccInternalUseManyID FROM(
		SELECT row_number() OVER(order by AccInternalUseManyID) As RowNumber,AccInternalUseManyID
		FROM [KYPEnrollment].[EDM_AccountInternalMany] WHERE AccountInternalUseID =@AccountInternalUseID )X WHERE X.RowNumber = @AppCount
	
		SELECT @CodeIdentification =[CodeIdentification],@CodeDescription =[CodeDescription],@CodeType =[CodeType],
		@CodeDateEffDate =[CodeDateEffDate],@CodeDateExpDate =[CodeDateExpDate],@CreatedBy =[CreatedBy],@LastActionReason =[LastActionReason]
		FROM [KYPEnrollment].[EDM_AccountInternalMany]
		WHERE AccInternalUseManyID =@accManyUserID
		
		INSERT INTO [KYPEnrollment].[EDM_SupplementalInteranlMany]
		([AccountInternalUseID]
		,[CodeIdentification]
		,[CodeDescription]
		,[CodeType]
		,[CodeDateEffDate]
		,[CodeDateExpDate]
		,[CreatedBy]
		,[LastActionReason])
		VALUES(
		@AccInternalUseID,
		@CodeIdentification 
		,@CodeDescription 
		,@CodeType 
		,@CodeDateEffDate
		,@CodeDateExpDate
		,@CreatedBy
		,@LastActionReason)
	
		SET @AppCount = @AppCount - 1
	
	END
	*/

	
	
	
	END


GO

