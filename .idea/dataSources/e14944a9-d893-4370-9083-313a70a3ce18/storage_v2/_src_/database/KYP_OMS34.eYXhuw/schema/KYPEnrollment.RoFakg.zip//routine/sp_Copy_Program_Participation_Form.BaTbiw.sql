/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Program Participation form.   
-- PARAMETERS: 
-- @party_Account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Program_Participation_Form]
@party_Account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@account_id INT
AS
BEGIN
 
	EXEC [KYPEnrollment].[sp_Copy_Party_Loc_Addr_Org]@party_app_id, @party_Account_id,@last_action_user_id, 'Provider Q1',NULL,@account_id;
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation]@party_Account_id,@party_app_id,@last_action_user_id,'ProgramParticipation',NULL,@account_id;
	
	PRINT 'New Program Participation'
END


GO

