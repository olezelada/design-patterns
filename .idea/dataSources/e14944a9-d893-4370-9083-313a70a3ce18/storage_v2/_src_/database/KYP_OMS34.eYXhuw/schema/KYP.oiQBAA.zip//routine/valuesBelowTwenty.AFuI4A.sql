
-- =============================================
-- Author:		Vinoth
-- Create date: 18th June 2014
-- Description:	To get the number in words below twenty
-- =============================================
CREATE FUNCTION [KYP].[valuesBelowTwenty] 
(
	-- Add the parameters for the function here
	@num INT
)
RETURNS VARCHAR(50)
AS
BEGIN
	DECLARE @Name VARCHAR(25)

	IF(@Num=1) SET @Name='One'
	IF(@Num=2) SET @Name='Two'
	IF(@Num=3) SET @Name='Three'
	IF(@Num=4) SET @Name='Four'
	IF(@Num=5) SET @Name='Five'
	IF(@Num=6) SET @Name='Six'
	IF(@Num=7) SET @Name='Seven'
	IF(@Num=8) SET @Name='Eight'
	IF(@Num=9) SET @Name='Nime'
	IF(@Num=10) SET @Name='Ten'
	IF(@Num=11) SET @Name='Eleven'
	IF(@Num=12) SET @Name='Twelve'
	IF(@Num=13) SET @Name='Thirteen'
	IF(@Num=14) SET @Name='Forteen'
	IF(@Num=15) SET @Name='Fifteen'
	IF(@Num=16) SET @Name='Sixteen'
	IF(@Num=17) SET @Name='Seventeen'
	IF(@Num=18) SET @Name='Eighteen'
	IF(@Num=19) SET @Name='Nineteen'

	RETURN @Name
END


GO

