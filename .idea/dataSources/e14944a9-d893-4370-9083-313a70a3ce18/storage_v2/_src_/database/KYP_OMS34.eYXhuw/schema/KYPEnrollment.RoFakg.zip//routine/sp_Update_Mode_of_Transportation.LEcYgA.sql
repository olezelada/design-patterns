-- =============================================
-- Author:		<rloayza>
-- Create date: <03/21/2018>
-- Description:	Update mode of trasportation
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Mode_of_Transportation]
    @party_account_id    INT,
    @application_id      INT,
    @last_action_user_id VARCHAR(100)
AS
  BEGIN
    SET NOCOUNT ON
    DECLARE @date_created DATE;
    DECLARE @app_party_id INT;
    DECLARE @air INT;
    DECLARE @ground INT;

    SELECT @app_party_id = PartyID FROM KYPPORTAL.PortalKYP.pADM_Application WHERE ApplicationID = @application_id

    IF EXISTS(SELECT * FROM KYPEnrollment.pADM_Account WHERE PartyID = @party_account_id AND ProviderTypeCode = '038')
      BEGIN
        SET @air = 1;
        END
    ELSE
      BEGIN
        SET @ground = 1;
      END

    SET @date_created = GETDATE();

    IF NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_PDM_ModeOfTransportation WHERE PartyId = @party_account_id)
      BEGIN
        EXEC KYPEnrollment.sp_copy_ModeOfTransportation @party_account_id, @app_party_id, @last_action_user_id, @air, @ground
        RETURN;
      END

    IF 1 = @air
      BEGIN
        UPDATE KYPEnrollment.pAccount_PDM_ModeOfTransportation
          SET
            TypeEmergency = appMDT.TypeEmergency,
            Nonemergency = appMDT.Nonemergency,
            Air = appMDT.Air,
            Fixedwing = appMDT.Fixedwing,
            Helicopter = appMDT.Helicopter,
            LastAction = 'U',
            LastActionUserID = @last_action_user_id
        FROM (SELECT TypeEmergency, Nonemergency, Air, Fixedwing, Helicopter
              FROM KYPPORTAL.PortalKYP.pPDM_ModeOfTransportation WHERE PartyId = @app_party_id) appMDT
        WHERE PartyId = @party_account_id

        RETURN;
      END

    IF 1 = @ground
      BEGIN
        UPDATE KYPEnrollment.pAccount_PDM_ModeOfTransportation
        SET
          TypeEmergency = appMDT.TypeEmergency,
          Nonemergency = appMDT.Nonemergency,
          Ground = appMDT.Ground,
          Ambulance = appMDT.Ambulance,
          LittlerVan = appMDT.LittlerVan,
          WheelchairVan = appMDT.WheelchairVan,
          LastAction = 'U',
          LastActionUserID = @last_action_user_id
        FROM (SELECT TypeEmergency, Nonemergency, Ground, Ambulance, LittlerVan, WheelchairVan
              FROM KYPPORTAL.PortalKYP.pPDM_ModeOfTransportation WHERE PartyId = @app_party_id) appMDT
        WHERE PartyId = @party_account_id

        RETURN;
      END

END


GO

