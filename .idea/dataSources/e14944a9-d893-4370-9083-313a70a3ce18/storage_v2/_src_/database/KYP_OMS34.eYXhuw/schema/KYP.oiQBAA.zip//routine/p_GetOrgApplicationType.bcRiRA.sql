






-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 07-JAN-2015
-- Description:	GET Application Type for Organization
-- =============================================
CREATE PROCEDURE [KYP].[p_GetOrgApplicationType] 
	-- Add the parameters for the stored procedure here
	 @ProviderOrApplicationNbr VARCHAR(20),
	 @TAX_ID VARCHAR(11),
	 @ORG_NAME VARCHAR(200),
	 @DBA_NAME VARCHAR(200),
	 @PartyType VARCHAR(50),
	 @PartyID INT,
	 @INS_UPD VARCHAR(20),
	 @ApplnTypeOrg VARCHAR(20) OUTPUT
AS
		
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @EXISTING_TAXID VARCHAR(11),
			@EXISTING_ORGNAME VARCHAR(200),
			@EXISTING_DBANAME VARCHAR(200),
			@PROV_NUMBER_EXIST BIT,
			@MOCA_STR VARCHAR(20),
			@DATUPD_STR VARCHAR(20)
			
	SET @MOCA_STR = 'MOCA Change'
	SET @DATUPD_STR = 'Data Update'	
	
	IF EXISTS (SELECT 1 FROM KYP.ADM_Case WHERE Number = @ProviderOrApplicationNbr)
	BEGIN
		SET @PROV_NUMBER_EXIST = 1
	END 
	
	IF @INS_UPD = 'INSERT'
	BEGIN
		IF EXISTS (SELECT TOP 1 * 		
			FROM KYP.PDM_Organization A 		
			INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
			AND B.PartyRole = 'Organization' AND B.PartyType = @PartyType
			INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
			INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
			WHERE D.Number = @ProviderOrApplicationNbr
			ORDER BY A.OrgID DESC)
		BEGIN			
			SELECT TOP 1
			@EXISTING_ORGNAME = LegalName,
			@EXISTING_DBANAME = DBAName1,
			@EXISTING_TAXID = TIN
			FROM KYP.PDM_Organization A 
			INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
			AND B.PartyRole = 'Organization' AND B.PartyType = @PartyType
			INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
			INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
			WHERE D.Number = @ProviderOrApplicationNbr
			ORDER BY A.OrgID DESC
			
			IF(@EXISTING_TAXID <> @TAX_ID) 
			BEGIN 
				SET @ApplnTypeOrg = @MOCA_STR;
			END
			ELSE IF(@EXISTING_ORGNAME <> @ORG_NAME)
			BEGIN 
				SET @ApplnTypeOrg = @MOCA_STR;
			END
			ELSE IF(@EXISTING_DBANAME <> @DBA_NAME)
			BEGIN 
				SET @ApplnTypeOrg = @MOCA_STR;
			END
			ELSE IF(@PROV_NUMBER_EXIST = 1)
			BEGIN 
				SET @ApplnTypeOrg = @DATUPD_STR;
			END				
		END		
	END
	ELSE IF EXISTS (SELECT TOP 1 * 		
		FROM KYP.PDM_Organization A 		
		INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
		AND B.PartyRole = 'Organization' AND B.PartyType = @PartyType
		INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
		INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
		WHERE D.Number = @ProviderOrApplicationNbr AND A.PartyID = @PartyID
		ORDER BY A.OrgID DESC)
	BEGIN
		SELECT TOP 1
		@EXISTING_ORGNAME = LegalName,
		@EXISTING_DBANAME = DBAName1,
		@EXISTING_TAXID = TIN
		FROM KYP.PDM_Organization A 
		INNER JOIN KYP.SDM_ApplicationParty B ON A.PartyID = B.PartyID 
		AND B.PartyRole = 'Organization' AND B.PartyType = @PartyType
		INNER JOIN KYP.ADM_Application C ON C.ApplicationID = B.ApplicationID 
		INNER JOIN KYP.ADM_Case D ON D.CaseID = C.CaseID
		WHERE D.Number = @ProviderOrApplicationNbr AND A.PartyID = @PartyID
		ORDER BY A.OrgID DESC
	 
		IF(@EXISTING_TAXID <> @TAX_ID) 
		BEGIN 
			SET @ApplnTypeOrg = @MOCA_STR;
		END
		ELSE IF(@EXISTING_ORGNAME <> @ORG_NAME)
		BEGIN 
			SET @ApplnTypeOrg = @MOCA_STR;
		END
		ELSE IF(@EXISTING_DBANAME <> @DBA_NAME)
		BEGIN 
			SET @ApplnTypeOrg = @MOCA_STR;
		END
		ELSE IF(@PROV_NUMBER_EXIST = 1)
		BEGIN 
			SET @ApplnTypeOrg = @DATUPD_STR;
		END	
	END
	ELSE
	BEGIN
		SET @ApplnTypeOrg = @DATUPD_STR
	END
END


GO

