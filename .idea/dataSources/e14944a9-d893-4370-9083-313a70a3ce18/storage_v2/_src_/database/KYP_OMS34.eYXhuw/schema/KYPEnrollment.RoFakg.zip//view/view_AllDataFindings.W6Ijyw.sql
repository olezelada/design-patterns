




CREATE VIEW [KYPEnrollment].[view_AllDataFindings]
 AS

 With cte1
 as
 (
SELECT --row_number() OVER (ORDER BY FindingId ASC) AS ViewID,
identificador as ViewID,
row_number() over (partition by category,Reasoncode,isexternaldesc,isexternalYesNo,addedby,addedon,titleFinding,descFinding,riskScoreFinding,
typeFinding,actionFinding,fieldFinding,ignoredFinding,flagScore,diffScore,tagsFinding,docCountFinding,caseIDFinding,findingID,
PStatus,isIgnoredMsg,findingDescription,RiskScoreColor,PartyRole,SectionCode,Status,DMSID--,fieldvalueid
 order by FindingId) as sortid,
identificador, FormattedContent, infoid, JournalEvent, type, PSubFormID, PFieldID, PartyID, category, Reasoncode, isexternaldesc, isexternalYesNo,
addedby, addedon, titleFinding, descFinding, riskScoreFinding, typeFinding, actionFinding, fieldFinding, ignoredFinding,
flagScore, diffScore, tagsFinding, docCountFinding,
caseIDFinding, findingID, PStatus, isIgnoredMsg, findingDescription,
RiskScoreColor, PartyRole, SectionNanme, Status, DMSID
FROM
(
		SELECT       CONVERT(varchar(15), a.noteid)  + CONVERT(varchar(15), isnull(fe.infoid, 0)) + CONVERT(varchar(15), isnull(fvt.fieldvalueid, 0)) AS identificador,
                                              CASE WHEN a.Type IN ('Related Accounts') THEN '' ELSE fe.FormattedContent END AS FormattedContent, CASE WHEN a.Type IN ('Related Accounts') THEN 0 ELSE fe.InfoID END AS infoid,
                                               CASE WHEN a.Type IN ('Related Accounts') THEN '' ELSE fe.JournalEvent END AS JournalEvent, CASE WHEN a.Type IN ('Related Accounts') THEN '' ELSE fe.Type END AS type,
                                              CASE WHEN a.Type IN ('Related Accounts') THEN 0 ELSE fe.PSubFormID END AS PSubFormID, CASE WHEN a.Type IN ('Related Accounts') THEN '' ELSE fe.PFieldID END AS PFieldID,
                                              CASE WHEN a.Type IN ('Related Accounts') THEN 0 ELSE fe.PartyID END AS PartyID,
                                              CASE WHEN a.Type = 'Application Review' THEN 'APP REVIEW' WHEN a.Type = 'RELATED ACCOUNTS' THEN A.Type ELSE 'SCREENING' END AS category,
                                              a.ReasonCode AS Reasoncode, CASE WHEN a.ExternalYesNO IS NULL THEN 'N/D' WHEN (a.ExternalYesNO = '1' OR
                                              a.ExternalYesNO = 'Yes') THEN 'EXTERNAL' WHEN (a.ExternalYesNO = '0' OR
                                              a.ExternalYesNO = 'NO') THEN 'INTERNAL' ELSE NULL END AS isexternaldesc, CASE WHEN a.ExternalYesNO IS NULL THEN 'N/D' WHEN (a.ExternalYesNO = '1' OR
                                              a.ExternalYesNO = 'Yes') THEN 'Yes' WHEN (a.ExternalYesNO = '0' OR
                                              a.ExternalYesNO = 'NO') THEN 'No' ELSE NULL END AS isexternalYesNo,
                                                  (SELECT     p.LastName + ' ' + p.FirstName
                                                    FROM          KYP.OIS_Person p, KYP.OIS_User u
                                                    WHERE      p.PersonID = u.PersonID AND u.UserID = a.UserID) AS addedby, a.DateCreated addedon, a.Name titleFinding, CAST(a.Content AS varchar(MAX)) descFinding,
                                              a.Score riskScoreFinding, a.Type typeFinding, a.UpdAction actionFinding, CASE WHEN a.Type IN ('Application Review') THEN ISNULL
                                                  ((SELECT     TOP 1 fl.fieldLabel
                                                      FROM         KYPEnrollment.FieldLabel fl
                                                      WHERE     fe.PFieldID = fl.fieldID AND fe.PAppID = fl.ApplicationID AND fe.PSubFormID = fl.SubFormID), '') ELSE '' END AS fieldFinding, CASE WHEN a.Type IN ('Application Review')
                                              THEN fe.IsIgnored ELSE 0 END AS ignoredFinding, a.AutoFlag flagScore, a.DiffScore diffScore, a.Tags tagsFinding, a.DocumentCount docCountFinding,
                                              CASE WHEN a.Type IN ('Application Review') THEN cast(fe.PCaseID + '' AS int) ELSE cast(a.CaseID + '' AS int) END caseIDFinding, a.NoteID findingID,
                                              CASE WHEN a.Type IN ('Application Review') THEN fe.PStatus WHEN a.Type IN ('Related Accounts') THEN 'Related Accounts' ELSE 'SCREENING' END AS PStatus,
                                              CASE WHEN a.Type = 'Application Review' AND fe.IsIgnored = '1' THEN 'Ignored' WHEN a.Type = 'Application Review' AND
                                              fe.IsIgnored = '0' THEN (CASE WHEN a.UpdatedOn is null THEN 'Confirmed' ELSE 'Edited' END) WHEN a.Type = 'Application Review' THEN 'NA' ELSE (CASE WHEN a.UpdatedOn is null THEN 'Confirmed' ELSE 'Edited' END) END AS isIgnoredMsg, CAST(a.UnformattedContent AS varchar(max))
                                              findingDescription, a.RiskScoreColor, a.PartyRole, Fvt.SectionCode, Fvt.SectionNanme, a.Status, a.DMSID
												/*NO TRACKING FIELD*/
                       FROM          kyp.OIS_Note a LEFT JOIN
							                  /*NO EVENT TABLE*/
                                              kyp.MDM_JournalBasicInfo fe ON a.PInID = fe.infoid LEFT JOIN
                                              Kypportal.PortalKYP.FieldValuesTracking Fvt ON Fe.pAppID = Fvt.ApplicationId AND Fvt.SubFormID = Fe.PSubFormId AND Fvt.FieldCode = Fe.PFieldID
                                              and Fvt.AppPartyID = Fe.PartyID

                       WHERE      (((a.Type = 'Application Review' AND a.ReasonCode IS NOT NULL) OR
                                              a.Type <> 'Application Review' ) AND isnull(a.Deleted,'0')<>'1') and a.AutoFlag is not null and a.ExternalYesNO is not null
		)G
)
Select * from cte1
where sortid = 1

GO

