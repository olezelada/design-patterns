
-- =============================================
-- Author:		<Author,,Lperez>
-- realiza el linked de todas las aplicaciones del portal
-- @accountID nuevo account id con al que se realiza la relacion, @linkedWithAccountID id del account con el que se va a relacionar, @linkType flag  tipo de relacion que van a tener estos dos account,
-- @linkingRemarks  flag valor portal ,@lastActorUserID nombre del usuario que realizo la aprobacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_LinkedAccount]
	@accountID INT,
	@linkedWithAccountID INT,
	@linkType varchar(10),
	@linkingRemarks varchar(100),
	@lastActorUserID varchar(100)	
AS
BEGIN
	DECLARE @dateCreated date,@lastAction varchar(1),@linkedAccountId INT,@message varchar(100)
	
	SET @dateCreated = GETDATE();
	SET @lastAction = 'C';
	
	INSERT INTO [KYPEnrollment].[pADM_LinkedAccount]
	([AccountID]
	,[LinkedWithAccountID]
	,[LinkType]
	,[LinkingRemarks]
	,[LastAction]
	,[LastActionDate]
	,[LastActorUserID]
	,[LastActionApprovedBy]
	,[CurrentRecordFlag])
	values(
	@accountID,
	@linkedWithAccountID,
	@linkType,
	@linkingRemarks,
	'C',
	@dateCreated,
	@lastActorUserID,
	@lastActorUserID,
	'true')
	
	SELECT @linkedAccountId = Scope_Identity()	
	SELECT @message = '@linkedAccountId: '+CONVERT(char(10), @linkedAccountId)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	RETURN @linkedAccountId
END


GO

