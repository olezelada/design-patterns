



CREATE FUNCTION [KYPEnrollment].[TVF_SearchSimilarRelated] (@ssn varchar(10), @ein varchar(10), @npi varchar(10))
RETURNS TABLE
AS
RETURN
SELECT *
FROM
(
select DISTINCT acc.AccountID, acc.NPI, acc.SSN,acc.EIN , ad.ZipPlus4
from [KYPEnrollment].[pADM_Account] acc 
INNER JOIN [KYPEnrollment].pAccount_PDM_Party par ON par.AccountID = acc.AccountID
INNER JOIN [KYPEnrollment].pAccount_PDM_Location lo ON lo.PartyID=par.PartyID AND lo.Type='Servicing'
INNER JOIN [KYPEnrollment].pAccount_PDM_Address ad ON ad.AddressID = lo.AddressID 
) srd
where srd.SSN=@ssn  OR srd.EIN = @ein   OR srd.NPI=@npi

GO

