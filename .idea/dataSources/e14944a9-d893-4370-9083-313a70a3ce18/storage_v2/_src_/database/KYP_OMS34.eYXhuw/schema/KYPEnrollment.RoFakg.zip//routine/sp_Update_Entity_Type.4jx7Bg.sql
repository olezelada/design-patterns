-- =============================================
-- Author:		<ohuanca>
-- Create date: <06-03-18>
-- Description:	verify if targetPath is diff null then update the entity type site account
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Entity_Type]
  @application_id INT,
  @field_code_tracking VARCHAR(100),
  @fieldCode VARCHAR(100),
  @party_id_provider INT
AS
BEGIN

IF NOT EXISTS(SELECT FieldValueID FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = @fieldCode)
BEGIN
  DECLARE @entityTypeId INT, @targetPathEntityType VARCHAR(200), @nameEntityType VARCHAR(100)

  SELECT @targetPathEntityType = TargetPath, @nameEntityType = NameEntityType
  FROM [KYPPORTAL].[PortalKYP].[pADM_App_EntityType]
  WHERE PartyID = @party_id_provider

  IF @targetPathEntityType IS NOT NULL AND @targetPathEntityType <> ''
  BEGIN

    EXEC [KYPEnrollment].[sp_Split_TargetPath] @targetPathEntityType, @entityTypeId OUTPUT

    IF @nameEntityType IS NOT NULL AND @nameEntityType <> ''
    BEGIN
        UPDATE KYPEnrollment.pAccount_PDM_EntityType SET NameEntityType = @nameEntityType WHERE EntityTypeID = @entityTypeId
    END

    PRINT 'update pAccount_PDM_EntityType'
  END
  PRINT 'after execute sp_UpdateEntityType'
END
END


GO

