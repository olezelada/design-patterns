
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: Update Profecional Licenses (table Number) by Traking.
-- PARAMETERS:
-- @acc_party_id : PartyId Account that will be update.
-- @action_taken : Action that will be made.
-- @last_action_user_id : Enrollment User
-- @target_path : target path to Traking.
-- @en_db_column : column that will be update.
-- @data : new value for Column that will be update.
-- @acc_PK : Name Primary key to table that will be update.
-- @acc_PK_value : Value Primary key to table that will be update.
-- @is_text_date : Flag if Data is Text or not.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Update_Number]
	@acc_party_id INT,
	@action_taken VARCHAR(50),
	@last_action_user_id VARCHAR(100),
	@target_path VARCHAR(200),
	@en_db_column VARCHAR(100),
	@data VARCHAR(MAX),
	@acc_PK VARCHAR(100),
	@acc_PK_value INT,
	@is_text_date CHAR(1),
	@app_party_id INT,
	@table_code VARCHAR(25)
AS
BEGIN
	DECLARE @app_number_id INT

	IF @action_taken='Added'
	BEGIN
		PRINT @action_taken
		SELECT @app_number_id = NumberID FROM [KYPPORTAL].[PortalKYP].[pPDM_Number] WHERE TargetPath=@target_path;
		IF  not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@app_number_id AND NameTable='pAccount_PDM_Number')

		BEGIN
			EXEC [KYPEnrollment].[sp_Copy_Number] @acc_party_id, NULL, @last_action_user_id, @app_number_id;
			INSERT INTO #Control_Add_row (FiledID,NameTable)
			VALUES(@app_number_id,'pAccount_PDM_Number');
		END
	END

	IF @action_taken='Updated'
	BEGIN
		PRINT @action_taken

		IF @table_code = 'profLicCertif'
            BEGIN
                UPDATE [KYPEnrollment].[pAccount_PDM_Number] SET AppNumberID =temp.appNumberId
                FROM (	SELECT NumberID as appNumberId
                    FROM KYPPORTAL.PortalKYP.pPDM_Number
                    WHERE TargetPath = @target_path AND PartyID = @app_party_id )temp
                WHERE NumberID = @acc_PK_value
            END

		EXEC [KYPEnrollment].[sp_Update_Field] 'pAccount_PDM_Number', @en_db_column, @data, @acc_PK, @acc_PK_value, @is_text_date,NULL,@last_action_user_id,@action_taken;
		EXEC KYPEnrollment.sp_Store_Copy_Table_Number_Docs @acc_party_id,'pAccount_PDM_Number','NumberID'

	END

	IF @action_taken='Deleted' AND @target_path LIKE '%pAccount_PDM_Number%'
	BEGIN
		PRINT @action_taken
		UPDATE [KYPEnrollment].[pAccount_PDM_Number] SET CurrentRecordFlag = 0 WHERE NumberID = @acc_PK_value;
	END
END
GO

