

CREATE PROCEDURE [KYPEnrollment].[p_Copy_AllApplication]
	@applicationId int,@priority int,@providerNumber varchar(15)
	--@lastActionUserID varchar(100)
AS
BEGIN
	Declare
	@lastActionUserID varchar(100),
		@caseId int,
		@caseNumber nvarchar(100),
		@newApplicationId int,
		@appFormId int,
		@newAppFormId int,
		@formType nvarchar(100),
		@unincorpSoleProprietor nvarchar(200),
		@partyId int,
		@newPartyId int,
		@personId int,
		@newPersonId int,
		@addressId int,
		@newAddressId int,
		@accountId int,
		@newAccountId int,
		@dateCreated date,
		@businessProvID int,
		@newBusinessProvID int,
		@locationId int,
		@newLocationId int,
		@doB date,
		@doBh VARCHAR(10),
		@isRendering nvarchar(20)

	Declare
		@iLoopControl int,
		@iNextRowId int,
		@iCurrentRowId int,
		@iCount int,
		@intErrorCode int,
		@message varchar(100),		
		@partyIdTmpCont int,
		@partyIdTmpContOld int,
		@newAddressTmp int
		
	-- Organization
	Declare
		@legalName nvarchar(150),
		@tin nvarchar(20),
		@EIN nvarchar(10),
		@dBAName nvarchar(150),
		@businessName nvarchar(150),
		@organizationId int,
		@isOrganization int
		
	-- Person
	Declare
		@firstName nvarchar(150),
		@lastName nvarchar(150),		
		@middleName nvarchar(150),
		@sufix nvarchar(150),
		@ssn nvarchar(10),
		@prefix nvarchar(10),
		@gender nvarchar(1),
		@title nvarchar(10),
		@name nvarchar(250),
		@contactFirstName nvarchar(150),
		@contactLastName nvarchar(150),
		@personIdA int,
		@personIdB int
	
	-- Address
	Declare
		@addressLine1 nvarchar(150),
		@addressLine2 nvarchar(150),
		@practiceAddress nvarchar(250),
		@zipPlus4 nvarchar(15),
		@zip nvarchar(7),
		@addressIdA int
		
	-- other
	Declare
		@npi nvarchar(10),
		@applicationCode nvarchar(20),
		@accNo int,
		@profile_id int

	SET @dateCreated = GETDATE()	

	SELECT @partyId = [PartyID], @businessProvID = [BusinessProvID], @isRendering = ISNULL([ApplicationCode],'')
	FROM [KYPPORTAL].[PortalKYP].[pADM_Application] 
	WHERE [ApplicationID] = @applicationId

	SELECT @message = '@partyId: ' + CONVERT(char(10), @partyId)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	SELECT @message = '@caseId: ' + CONVERT(char(10), @caseId)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	SELECT @message = '@@businessProvID: ' + CONVERT(char(10), @businessProvID)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	SELECT @message = '@@isRendering: ' + CONVERT(char(20), @isRendering)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	

	IF ISNULL(@partyId,0) = 0
	BEGIN
		PRINT 'No application found in [ADM_Application] table!'
		RETURN
	END

	-----------------pADM_Account-------------------
	DECLARE @isVal INT
	SET @isVal = 0
	IF((@isRendering = 'ISP_RP_U_RA'))
	BEGIN
		IF((@isRendering <> 'ISP_RP_P_DM'))
		BEGIN
		SET @isVal = 1
		END		
	END
	ELSE
	BEGIN
		IF((@isRendering <> 'ISP_RP_U_RA'))
		BEGIN
			IF((@isRendering = 'ISP_RP_P_DM'))
			BEGIN
			SET @isVal = 1
			END		
		END
	END
	
	--SET @accNo=100000000+@businessProvID
	INSERT INTO [KYPEnrollment].[pADM_Account]
	([LegacyAccountNo]
	,[AccountNumber]
	,[P_SYS_ID]
	,[AccountType]
	,[ServiceLocationNo]
	,[OwnerNo]
	,[ProviderType]
	,[Risk]
	,[EnrollmentRiskLevel]
	,[PIN]
	,[LegalName]
	,[DBAName]
	,[Prefix]
	,[Gender]
	,[Title]
	,[DateDied]
	,[IncorporatedDate]
	,[OOBDate]
	,[RiskScore]
	,[ApplicationDate]
	,[LastActionDate]
	,[ActivationDate]
	,[DeActivationDate]
	,[LastAction]
	,[LastActionReason]
	,[LastActionComments]
	--,[LastActorUserID]
	--,[LastActionApprovedBy]
	,[AccountUpdateDate]
	,[AccountUpdateUserID]
	,[AccountUpdateReason]
	,[AccountUpdateComments]
	,[LastRevalidationDate]
	,[LastRevalidationReason]
	,[RevalidationDueDate]
	,[LastApplicationType]
	,[LastAlertedDate]
	,[LastScreenedDate]
	,[LastBilledDate]
	,[LastRenderedDate]
	,[LastDeltaLoadDate]
	,[TIN]
	--,[TINH]
	,[ApplicationNumber]
	,[StatusAcc]
	,[SSN]
	,[EIN]
	,[PartyID]
	,[ReenrollmentIndicator]
	,[NPI]
	,[IsDeleted]
	,[CreatedBy]
	,[profile_id])
	SELECT null--[LegacyAccountNo]
	,''--[AccountNumber]
	,null--[P_SYS_ID]
	,null--[AccountType]
	,null--[ServiceLocationNo]
	,null--[OwnerNo]
	,null--[ProviderType]
	,null--[Risk]
	,null--[EnrollmentRiskLevel]
	,null--[PIN]
	,''--[LegalName]
	,null--[DBAName]
	,null--[Prefix]
	,null--[Gender]
	,null--[Title]
	,null--[DateDied]
	,@dateCreated
	,null--[OOBDate]
	,@priority--[RiskScore]
	,@dateCreated--[ApplicationDate]
	,@dateCreated--[LastActionDate]
	,null--[ActivationDate]
	,null--[DeActivationDate]
	,'C'--[LastAction]
	,null--[LastActionReason]
	,null--[LastActionComments]
	--,@lastActionUserID
	--,@lastActionUserID
	,null--[AccountUpdateDate]
	,null--[AccountUpdateUserID]
	,null--[AccountUpdateReason]
	,null--[AccountUpdateComments]
	,null--[LastRevalidationDate]
	,null--[LastRevalidationReason]
	,null--[RevalidationDueDate]
	,null--[LastApplicationType]
	,null--[LastAlertedDate]
	,null--[LastScreenedDate]
	,null--[LastBilledDate]
	,null--[LastRenderedDate]
	,null--[LastDeltaLoadDate]
	,null--[TIN]
	--,null--[TINH]
	,[Number]--[ApplicationNumber]
	,'3 - Pending'
	,''--[SSN]
	,''--[EIN]
	,null--[PartyID]
	,null--[ReenrollmentIndicator]
	,application.NPI 
	,0
	,ca.CreatedBy 
	,ca.profile_id
	FROM [KYPPORTAL].[PortalKYP].[pADM_Application]  application INNER JOIN
		 [KYPPORTAL].[PortalKYP].[pADM_Case] ca ON application.[CaseID] = ca.[CaseID]
	WHERE [ApplicationID] = @applicationId
	  
	SELECT @newAccountId = Scope_Identity()
	  
	SELECT @message = 'New ADM_Account: ' + CONVERT(char(10), @newAccountId)
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	--PROCEDURE [KYPEnrollment].[p_Copy_RelationRenderingInsert] @accountID INT, @providerNumber varchar(15)
	EXEC [KYPEnrollment].[p_Copy_RelationRenderingInsert] @newAccountId,@providerNumber,@lastActionUserID;

	INSERT INTO  KYPEnrollment.EDM_AccountInternalUse
	(AccountID,OutOfStateInd,OutOfStateIndDesc) 
	VALUES (@newAccountId,0,'In State Provider');
	
	--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
	EXEC @newPartyId = [KYPEnrollment].[p_Copy_Party] @partyId,NULL,@newAccountId,@lastActionUserID;
	
	UPDATE [KYPEnrollment].[pADM_Account] SET [PartyID] = @newPartyId WHERE [AccountID]=@newAccountId	
		
	SELECT @unincorpSoleProprietor =[NameEntityType] FROM [KYPPORTAL].[PortalKYP].[pADM_App_EntityType] WHERE PartyID = @partyId
	
	--PROCEDURE [KYPEnrollment].[p_Copy_EntityType] @partyId INT,@newPartyIdProv INT
	EXEC [KYPEnrollment].[p_Copy_EntityType] @partyId,@newPartyId,@lastActionUserID;

	--PROCEDURE [KYPEnrollment].[p_Copy_Provider] @providerId INT, @newPartyId INT
	EXEC [KYPEnrollment].[p_Copy_Provider] @businessProvID,@newPartyId,@lastActionUserID;		

	IF((SELECT COUNT([PartyID])	FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] Where [PartyID] = @partyId AND [Remark] = 'Individual Profile')>0)
	BEGIN
		-- Person information
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
		([PartyID]
		,[PersonNumber]
		,[PersonCategory]
		,[SSN]
		,[Salutation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Gender]
		,[DoB]
		,[DoD]
		,[Email1]
		,[Phone1]
		,[Email2]
		,[Phone2]
		,[Alias1]
		,[Alias2]
		,[CityofBirth]
		,[StateofBirth]
		,[CountryOfBirth]
		,[Ethnicity]
		,[Remark]
		,[LastAction] 
		,[LastActionDate] 
		,[LastActorUserID] 
		,[LastActionApprovedBy]
		,[CurrentRecordFlag]
		,[OtherFirstName]
		,[OtherLastName]
		,[OtherMiddleName]
		,[Prefix]
		,[OtherNameType]
		,[OtherPrefix]
		,[Sufix]
		,[DriverLicense]
		,[Position]
		,[ExpirationDateDriverLic]
		,[OtherOtherNameType]
		,[ProfessionalTitle])
		SELECT @newPartyId
		,[PersonNumber]
		,[PersonCategory]
		,[SSN]
		,[Salutation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Gender]
		,[DoB]
		,[DoD]
		,[Email1]
		,[Phone1]
		,[Email2]
		,[Phone2]
		,[Alias1]
		,[Alias2]
		,[CityofBirth]
		,[StateofBirth]
		,[CountryOfBirth]
		,[Ethnicity]
		,[Remark]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[Deleted]
		,[OtherFirstName]
		,[OtherLastName]
		,[OtherMiddleName]
		,[Prefix]
		,[OtherNameType]
		,[OtherPrefix]
		,[Sufix]
		,[DriverLicense]
		,[Position]
		,[ExpirationDateDriverLic]
		,[OtherOtherNameType]
		,[ProfessionalTitle]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] Where [PartyID] = @partyId AND [Remark] = 'Individual Profile'
		
		SELECT @newPersonId = Scope_Identity()	  	
		SELECT @personId = [PersonId] FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] WHERE PartyID = @partyId AND [Remark] = 'Individual Profile'			
		-- Other Person	
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Person_OtherName]
		([PersonID]
		,[OtherNameType]
		,[Salunation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Remarks]	 
		,[LastAction] 
		,[LastActionDate] 
		,[LastActorUserID] 
		,[LastActionApprovedBy]
		,[CurrentRecordFlag])
		SELECT @newPersonId
		,[OtherNameType]
		,[Salunation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Remarks]	 
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[IsDeleted]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Person_OtherName]
		WHERE [PersonID] = @personId
    END
		
	-- Residential Address		
	SELECT @addressId = [AddressID],@locationId = [LocationID] FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  WHERE [PartyID] = @partyId AND [Type] = 'Individual Profile'
	IF ISNULL(@addressId,0) <> 0
	BEGIN
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressId = [KYPEnrollment].[p_Copy_Address] @addressId,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationId,@newAddressId,@newPartyId,NULL,NULL,@lastActionUserID;		
	END
	
	SELECT @message = 'New Address Residential: ' + CONVERT(char(10), 'full Residential Address')
	RAISERROR(@message, 0, 1) WITH NOWAIT
		
	-- Organization	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization]
	([PartyID] ,
	[OrgNumber] ,
	[OrgCategory] ,
	[TIN] ,
	[PrimaryDUNS] ,
	[LegalName] ,
	[DBAName1] ,
	[DBAName2] ,
	[IncTyp] ,
	[IncState] ,
	[IncDate] ,
	[ForeginOwned] ,
	[Email1] ,
	[Phone1] ,
	[Email2] ,
	[Phone2] ,
	[Remarks] ,
	[LastAction] ,
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy],
	[CurrentRecordFlag],
	[Fax] ,
	[NPI] ,
	[License] ,
	[EIN] ,
	[Medicaid] ,
	[DEA] ,
	[Sellers] ,
	[IsCorporation] ,
	[Extension])
	SELECT @newPartyId
	,[OrgNumber]
	,[OrgCategory]
	,[TIN]
	,[PrimaryDUNS]
	,[LegalName]
	,[DBAName1]
	,[DBAName2]
	,[IncTyp]
	,[IncState]
	,[IncDate]
	,[ForeginOwned]
	,[Email1]
	,[Phone1]
	,[Email2]
	,[Phone2]
	,[Remarks]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,[IsDeleted]
	,[Fax]
	,[NPI]
	,[License]
	,[EIN]
	,[Medicaid]
	,[DEA]
	,[Sellers]
	,[IsCorporation]
	,[Extension]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] WHERE PartyID = @partyId

	-- Document 	
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Document]
	( [PartyID] ,
	[TypeDoc] ,
	[NumberDoc] ,
	[IsStateIssued] ,
	[StateIssued] ,
	[LastAction] ,
	[LastActionDate] ,
	[LastActorUserID] ,
	[LastActionApprovedBy],
	[CurrentRecordFlag])
	SELECT @newPartyId
	,[TypeDoc]
	,[NumberDoc]
	,[IsStateIssued]
	,[StateIssued]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,[IsDeleted]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Document] WHERE PartyID = @partyId
		
	IF ((SELECT COUNT([PartyID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE [ParentPartyID] = @partyId AND [Type]  = 'Contact Person' AND [Type_IsProvider] = 'Contact Person0')>0)
	BEGIN
		------------- Contact Person	
		SELECT @partyIdTmpContOld = [PartyID] FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE [ParentPartyID] = @partyId AND [Type]  = 'Contact Person' AND [Type_IsProvider] = 'Contact Person0'
		
		-- Party Contact Person
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
		([Type]
		,[Name]
		,[IsProvider]
		,[IsEnrolled]
		,[IsTemp]
		,[IsActive]
		,[LoadType]
		,[LoadID]
		,[LastLoadDate]
		,[Source]
		,[LastAction] 
		,[LastActionDate] 
		,[LastActorUserID] 
		,[LastActionApprovedBy]
		,[CurrentRecordFlag]
		,[ParentPartyID]
		,[profile_id]
		,[AccountID])
		SELECT [Type]
		,[Name]
		,[IsProvider]
		,[IsEnrolled]
		,[IsTemp]
		,[IsActive]
		,[LoadType]
		,[LoadID]
		,[LastLoadDate]
		,[Source]
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[IsDeleted]	 
		,@newPartyId
		,[profile_id]
		,@newAccountId
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE [ParentPartyID] = @partyId AND [Type]  = 'Contact Person' AND [Type_IsProvider] = 'Contact Person0'

		SELECT @partyIdTmpCont = Scope_Identity()

		SELECT @message = 'New Contact person Party: ' + CONVERT(char(10), @partyIdTmpCont)
		RAISERROR(@message, 0, 1) WITH NOWAIT
		-- Person c
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
		([PartyID]
		,[PersonNumber]
		,[PersonCategory]
		,[SSN]
		,[Salutation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Gender]
		,[DoB]
		,[DoD]
		,[Email1]
		,[Phone1]
		,[Email2]
		,[Phone2]
		,[Alias1]
		,[Alias2]
		,[CityofBirth]
		,[StateofBirth]
		,[CountryOfBirth]
		,[Ethnicity]
		,[Remark]	 
		,[LastAction] 
		,[LastActionDate] 
		,[LastActorUserID] 
		,[LastActionApprovedBy]
		,[CurrentRecordFlag]
		,[OtherFirstName]
		,[OtherLastName]
		,[OtherMiddleName]
		,[Prefix]
		,[OtherNameType]
		,[OtherPrefix]
		,[Sufix]
		,[DriverLicense]
		,[Position]
		,[ExpirationDateDriverLic]
		,[OtherOtherNameType]
		,[ProfessionalTitle])
		SELECT @partyIdTmpCont
		,[PersonNumber]
		,[PersonCategory]
		,[SSN]
		,[Salutation]
		,[FirstName]
		,[LastName]
		,[MiddleName]
		,[Gender]
		,[DoB]
		,[DoD]
		,[Email1]
		,[Phone1]
		,[Email2]
		,[Phone2]
		,[Alias1]
		,[Alias2]
		,[CityofBirth]
		,[StateofBirth]
		,[CountryOfBirth]
		,[Ethnicity]
		,[Remark]	 
		,'C'
		,@dateCreated
		,@lastActionUserID
		,@lastActionUserID
		,[Deleted]
		,[OtherFirstName]
		,[OtherLastName]
		,[OtherMiddleName]
		,[Prefix]
		,[OtherNameType]
		,[OtherPrefix]
		,[Sufix]
		,[DriverLicense]
		,[Position]
		,[ExpirationDateDriverLic]
		,[OtherOtherNameType]
		,[ProfessionalTitle]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] Where [PartyID] = @partyIdTmpContOld-- AND [Remark] = 'Individual Profile'

		SELECT @message = 'New Contact Person: ' + CONVERT(char(10), 'full contact')
		RAISERROR(@message, 0, 1) WITH NOWAIT			
	END
	
	-- Service Address
	set @addressId = 0
	set @locationId = 0			

	SELECT @addressId = [AddressID],@locationId = [LocationID] FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  WHERE [PartyID] = @partyId AND [Type] = 'Servicing'
	IF ISNULL(@addressId,0) <> 0
	BEGIN
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressId = [KYPEnrollment].[p_Copy_Address] @addressId,@lastActionUserID;			

		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationId,@newAddressId,@newPartyId,NULL,NULL,@lastActionUserID;		
	END			

	SELECT @message = 'New Address Service: ' + CONVERT(char(10), 'Service')
	RAISERROR(@message, 0, 1) WITH NOWAIT			

	-- Pay-to Address	
	set @addressId = 0
	set @locationId = 0			

	SELECT @addressId = [AddressID],@locationId = [LocationID] FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  WHERE [PartyID] = @partyId AND [Type] = 'Pay-to'
	IF ISNULL(@addressId,0) <> 0
	BEGIN	
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressId = [KYPEnrollment].[p_Copy_Address] @addressId,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationId,@newAddressId,@newPartyId,NULL,NULL,@lastActionUserID;		
	END
	
	SELECT @message = 'New Address Pay-to: ' + CONVERT(char(10), 'Pay-to')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	-- Mailing Address	
	set @addressId = 0
	set @locationId = 0
		
	SELECT @addressId = [AddressID],@locationId = [LocationID] FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]  WHERE [PartyID] = @partyId AND [Type] = 'Mailing'
	IF ISNULL(@addressId,0) <> 0
	BEGIN
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddressId = [KYPEnrollment].[p_Copy_Address] @addressId,@lastActionUserID;			

		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locationId,@newAddressId,@newPartyId,NULL,NULL,@lastActionUserID;
	END
	
	SELECT @message = 'New Address Mailing: ' + CONVERT(char(10), 'Mailing')
	RAISERROR(@message, 0, 1) WITH NOWAIT

	--  Specialty Codes. and Taxonomy Codes.
	INSERT INTO [KYPEnrollment].[pAccount_PDM_Speciality]
	([PartyID]
	,[TaxonomyCode]
	,[IsPrimary]
	,[Speciality_Code]
	,[Board]
	,[LastAction] 
	,[LastActionDate] 
	,[LastActorUserID] 
	,[LastActionApprovedBy]
	,[CurrentRecordFlag]
	,[Type])
	SELECT @newPartyId
	,[TaxonomyCode]
	,[IsPrimary]
	,[Speciality_Code]
	,[Board]
	,'C'
	,@dateCreated
	,@lastActionUserID
	,@lastActionUserID
	,[IsDeleted]
	,[Type]
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Speciality] WHERE [PartyID] = @partyId 
	
	SELECT @message = 'New Specialty and Taxonomy: ' + CONVERT(char(10), 'Ok')
	RAISERROR(@message, 0, 1) WITH NOWAIT
		
	--CURSOR FOR  Hospital Privileges
	SELECT @message = 'Hospital Privileges ' + CONVERT(char(10), 'Begin')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	DECLARE @partyIdOldHp int,@orgIdOldHp int,@locaIdOldHp int,@addsIdOldHp int, @newPartyIdOldHp  int,@newOrgIdOldHp int,@newLocaIdOldHp int,@newAddsIdOldHp int
	
	DECLARE Hospital_Privileges_Cursor CURSOR FOR		
	SELECT org.OrgID, address.AddressID, location.LocationID, party.PartyID                   
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Organization org ON party.PartyID = org.PartyID
	WHERE (party.Type = 'Resigned Privileges' OR party.Type = 'Hospital Privileges' OR party.Type = 'Revoked Privileges') 
	AND party.ParentPartyID = @partyId
		
	OPEN Hospital_Privileges_Cursor;
	FETCH NEXT FROM Hospital_Privileges_Cursor INTO @orgIdOldHp,@addsIdOldHp,@locaIdOldHp,@partyIdOldHp 
	WHILE @@FETCH_STATUS = 0
	BEGIN		
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyIdOldHp = [KYPEnrollment].[p_Copy_Party] @partyIdOldHp,@newPartyId,@newAccountId,@lastActionUserID;  
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddsIdOldHp = [KYPEnrollment].[p_Copy_Address] @addsIdOldHp,@lastActionUserID;	
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locaIdOldHp,@newAddsIdOldHp,@newPartyIdOldHp,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Organization] @orgID INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Organization] @orgIdOldHp,@newPartyIdOldHp,@lastActionUserID;		

		FETCH NEXT FROM Hospital_Privileges_Cursor INTO @orgIdOldHp,@addsIdOldHp,@locaIdOldHp,@partyIdOldHp
	END;
	CLOSE Hospital_Privileges_Cursor;
	DEALLOCATE Hospital_Privileges_Cursor;	
	
	SELECT @message = 'Hospital Privileges ' + CONVERT(char(10), 'END')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	
	--CURSOR FOR Lease Information A	
	SELECT @message = 'Lease Information ' + CONVERT(char(10), 'Begin')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	DECLARE @partyIdOldLI int,@persIdOldLI int,@locaIdOldLI int,@addsIdOldLI int, @newPartyIdOldLI  int,@newPersIdOldLI int,@newLocaIdOlLI int,@newAddsIdOldLI int
	
	DECLARE Lease_Information_Cursor CURSOR FOR		
	SELECT pers.PersonID , address.AddressID, location.LocationID, party.PartyID                   
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Person pers ON party.PartyID = pers.PartyID
	WHERE (party.Type IN('Lease Information','Lease Information Owner')) AND party.ParentPartyID = @partyId
		
	OPEN Lease_Information_Cursor;
	FETCH NEXT FROM Lease_Information_Cursor INTO @persIdOldLI,@addsIdOldLI,@locaIdOldLI,@partyIdOldLI 
	WHILE @@FETCH_STATUS = 0
	BEGIN			
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyIdOldLI = [KYPEnrollment].[p_Copy_Party] @partyIdOldLI,@newPartyId,@newAccountId,@lastActionUserID; 
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddsIdOldLI = [KYPEnrollment].[p_Copy_Address] @addsIdOldLI,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locaIdOldLI,@newAddsIdOldLI,@newPartyIdOldLI,NULL,NULL,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Person]	@personId INT, @newPartyId INT
		EXEC [KYPEnrollment].[p_Copy_Person] @persIdOldLI,@newPartyIdOldLI,@lastActionUserID;
		
		FETCH NEXT FROM Lease_Information_Cursor INTO @persIdOldLI,@addsIdOldLI,@locaIdOldLI,@partyIdOldLI
	END;
	CLOSE Lease_Information_Cursor;
	DEALLOCATE Lease_Information_Cursor;
	
	--CURSOR FOR Lease Information B	
	SELECT @message = 'Lease Information B ' + CONVERT(char(10), 'Begin')
	RAISERROR(@message, 0, 1) WITH NOWAIT
	DECLARE @partyIdOldLIB int,@locaIdOldLIB int,@addsIdOldLIB int, @newPartyIdOldLIB  int,@newLocaIdOlLIB int,@newAddsIdOldLIB int
	
	DECLARE Lease_InformationB_Cursor CURSOR FOR	
	SELECT address.AddressID, location.LocationID, party.PartyID                   
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Location] as location INNER JOIN
		[KYPPORTAL].[PortalKYP].[pPDM_Address] as address ON location.AddressID = address.AddressID INNER JOIN
		[KYPPORTAL].[PortalKYP].pPDM_Party as party ON location.PartyID = party.PartyID 
	WHERE (party.Type = 'LeaseInfBusiness Address') 
	AND party.ParentPartyID = @partyId
		
	OPEN Lease_InformationB_Cursor;
	FETCH NEXT FROM Lease_InformationB_Cursor INTO @addsIdOldLIB,@locaIdOldLIB,@partyIdOldLIB 
	WHILE @@FETCH_STATUS = 0
	BEGIN			
		--PROCEDURE [KYPEnrollment].[p_Copy_Party] @partyId INT,@newPartyIdProv INT,@accountId INT
		EXEC @newPartyIdOldLIB = [KYPEnrollment].[p_Copy_Party] @partyIdOldLIB,@newPartyId,@newAccountId,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Address] @addressId INT
		EXEC @newAddsIdOldLIB = [KYPEnrollment].[p_Copy_Address] @addsIdOldLIB,@lastActionUserID;
		
		--PROCEDURE [KYPEnrollment].[p_Copy_Location] @locationId INT,@newAddressId INT,@newPartyId INT,@newProviderID INT,@newPersonID INT
		EXEC [KYPEnrollment].[p_Copy_Location] @locaIdOldLIB,@newAddsIdOldLIB,@newPartyIdOldLIB,NULL,NULL,@lastActionUserID;
		 
		FETCH NEXT FROM Lease_InformationB_Cursor INTO @addsIdOldLIB,@locaIdOldLIB,@partyIdOldLIB
	END;
	CLOSE Lease_InformationB_Cursor;
	DEALLOCATE Lease_InformationB_Cursor;
	
	SELECT @message = 'Lease Information B: ' + CONVERT(char(10), 'END')
	RAISERROR(@message, 0, 1) WITH NOWAIT	
		
	SELECT @message = 'Update Account: ' + CONVERT(char(10), 'BEGIN')
	RAISERROR(@message, 0, 1) WITH NOWAIT

	declare
		@ssnh varchar(11),
		@tinh varchar(10),
		@EINH varchar(10),
		@legalNamet varchar(150)
	
	
	-- Data Business Profile
	SELECT @organizationId = [OrgID] ,@LegalName = [LegalName]  ,@EIN = [EIN],@dBAName = [DBAName1],@businessName = [BusinessName] 
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] WHERE PartyID = @partyId	
	
	-- Data Individual Profile
	select @legalNamet=LastName+','+FirstName+MiddleName,@prefix=[Prefix],@gender = [Gender],@title = [ProfessionalTitle] ,@ssn = SSN,@doB = [DoB]  
	from [KYPPORTAL].[PortalKYP].[pPDM_Person] per WHERE per.[PartyID] = @partyId	
	
	
	SET @isOrganization = 0
	SET @doB = null
	SET @prefix= ''
	SET @gender = ''
	SET @title = ''
	SET @ssn = ''
	SET @tin = @EIN 
	
	IF ISNULL(@organizationId,0) <> 0
	BEGIN	
		SET @isOrganization = 1;	
		SELECT @message = '@organizationId: ' + CONVERT(char(10), 'OK')
		RAISERROR(@message, 0, 1) WITH NOWAIT
	END
	ELSE
	BEGIN
		SET @legalName=@legalNamet		
	END
	
	IF(ISNULL(@EIN,'')='')
	BEGIN
		SET @tin= @ssn
	END
	
	SELECT @message = '@Name: ' + CONVERT(char(100), @legalName)+ CONVERT(char(100), @EIN)/*+CONVERT(char(100), @ssn)+CONVERT(char(100), @prefix)+CONVERT(char(100), @gender)+CONVERT(char(100), @title)*/
	RAISERROR(@message, 0, 1) WITH NOWAIT
	SET @ssnh=@ssn
	SET @tinh=@tin
	SET @EINH = @EIN 
	
	IF charindex('-',@tinh) = 2
	BEGIN
		SET @tinh = replace(@tinh, SUBSTRING(@tinh,1,7),'XX-XXX')  
	END
	ELSE
	BEGIN
		SET @tinh = replace(@tinh, SUBSTRING(@tinh,0,7),'XXX-XX')
	END
	
	SET @EINH = replace(@EINH, SUBSTRING(@EINH,0,7),'XX-XXX')
	SET @ssnh = replace(@ssnh, SUBSTRING(@ssnh,0,7),'XXX-XX')
	
	SET @EIN = replace(@EIN,'-','')
	SET @ssn = replace(@ssn,'-','')
			
	UPDATE [KYPEnrollment].[pADM_Account]
	SET [LegalName] = ISNULL(@legalName,'') 
	,[EIN] = ISNULL(@EIN,'') 
	,[SSN] = ISNULL(@ssn,'') 
	,[Prefix] = ISNULL(@prefix,'') 
	,[Gender] = ISNULL(@gender,'') 
	,[Title] = ISNULL(@title,'') 
	,[TIN] = ISNULL(@tin,'') 
	,[BusinessName] = ISNULL(@businessName,'') 
	,[DBAName] = ISNULL(@dBAName,'') 
	--,[SSNH]	  = ISNULL(@ssnh,'') 
	--,[EINH] = ISNULL(@EINH ,'')
	--,[TINH] = ISNULL(@tinh ,'')
	WHERE [AccountID]=@newAccountId	

	SELECT @message = '[p_Copy_EntityInLine]-----: ' + CONVERT(char(10), 'BEGIN')
	RAISERROR(@message, 0, 1) WITH NOWAIT	
	EXECUTE [KYPEnrollment].[p_Copy_EntityInLine] @partyId,@newPartyId,@newAccountId,@lastActionUserID;	
	SELECT @message = '[p_Copy_EntityInLine]-----: ' + CONVERT(char(10), 'END')
	RAISERROR(@message, 0, 1) WITH NOWAIT	
		
	IF (@isVal=0)
	BEGIN
		SELECT @message = 'p_Copy_Subcontractor_Ownership_Interest-----: ' + CONVERT(char(10), 'BEGIN')
		RAISERROR(@message, 0, 1) WITH NOWAIT	
		EXECUTE [KYPEnrollment].[p_Copy_Subcontractor_Ownership_Interest] @partyId,@newPartyId,@newAccountId,@lastActionUserID;
		SELECT @message = 'p_Copy_Subcontractor_Ownership_Interest-----: ' + CONVERT(char(10), 'END')
		RAISERROR(@message, 0, 1) WITH NOWAIT		
	END	

	SET NOCOUNT OFF
	PRINT 'Copy Account DONE!'	
	
END


GO

