-- =============================================
-- Author:		<clopez>
-- Create date: <01/26/2018 15:00:00>
-- Description:	<This procedure copy Technician/Supervisors address for portable Imaging package>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Technicians_Supervisors]
  @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT,
	@last_Action_User_ID VARCHAR(100)

AS
BEGIN
  /* Technician Section */
	EXEC [KYPEnrollment].[sp_Copy_Technicians] @new_Account_Id, @new_Party_Id, @party_Id, @last_Action_User_ID;
	/*Supervising Physician Section*/
	EXEC [KYPEnrollment].[sp_Copy_Supervising_Physician] @new_Account_Id, @new_Party_Id, @party_Id, @last_Action_User_ID;

END


GO

