






CREATE VIEW [KYP].[v_CaseSummaryReport] AS

SELECT 
ROW_NUMBER() OVER(ORDER BY X.SortDate DESC) As ID ,
 X.* FROM (

/** MILSTONE **/

SELECT DISTINCT (CONVERT(VARCHAR,M.CompletionDate,101) + ' ' + RIGHT(CONVERT(CHAR(20), M.CompletionDate, 22), 11)) As Date,
DATEDIFF(DAY,M.CompletionDate,C.DateReceived) As DE , 'flag' AS Icon,
'Milestone: ' + M.TemplateValue AS Details,'NA' As Findings,'#FFFFFF' As BG,
C.CaseID,
M.CompletionDate SortDate  
FROM KYP.ADM_Case C
INNER JOIN KYP.ADM_Application A ON A.CaseID = C.CaseID 
INNER JOIN KYP.SDM_ApplicationParty S ON S.ApplicationID = A.ApplicationID AND IsActive = 1
RIGHT JOIN KYP.Milestone_CaseDetail M ON M.CaseID = C.CaseID AND M.SequenceNumber > 2 AND M.IsVisible = 1 AND M.IsCompleted = 1


/** Resolutions **/

UNION ALL

SELECT DISTINCT 
(CONVERT(VARCHAR,R.DateCreated,101) + ' ' + RIGHT(CONVERT(CHAR(20), R.DateCreated, 22), 11))
 As Date,DATEDIFF(DAY,C.DateReceived,R.DateCreated) As DE , 'info' AS Icon,
 R.ResolutionType  As Details,'NA' As Findings,
CASE WHEN R.ResolutionType = 'Referred-Licensing and Certification (L&C)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Enrolled/Provisional Status Granted' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'NPI Change' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Denied' THEN 'rgb(255, 0, 0);'
	 WHEN R.ResolutionType = 'Referred-Office of Legal Services (OLS)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Deficiency Notice Sent' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Referred-Audits and Investigations (A&I)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Benefits Division' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Lab Field Services' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Other' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Pharmacy' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Review Cancelled - Close as duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN R.ResolutionType = 'Closed as Duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN R.ResolutionType = 'Approve' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Approved' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Close without account update' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Dis-Enrolled by Provider' THEN 'rgb(128, 128, 128);'
	 WHEN R.ResolutionType = 'Review Cancelled - Application Withdrawn' THEN 'rgb(0, 128, 128);'	 
	 WHEN R.ResolutionType = 'Ignored' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Referred' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Close with no action' THEN 'rgb(255, 174, 0);'	 
	 ELSE '#FFFFFF;' END As BG,C.CaseID
	 ,R.DateCreated SortDate  
	 FROM KYP.ADM_Case C
INNER JOIN KYP.ADM_Application A ON A.CaseID = C.CaseID 
INNER JOIN KYP.SDM_ApplicationParty S ON S.ApplicationID = A.ApplicationID AND IsActive = 1
RIGHT JOIN KYP.SDM_Resolution R ON R.ApplicationID = S.ApplicationID AND 
--ISNULL(R.ResolutionType,'') NOT IN ('Temp','') 
--AND R.DateCreated IS NOT NULL AND R.ResolutionNoteID IS NOT NULL AND R.IsDeleted <> 1
ISNULL(R.ResolutionType,'') NOT IN ('Temp','') AND ISNULL(R.DateCreated,'') != '' 
AND ISNULL(R.ResolutionNoteID,'') != '' AND ISNULL(R.IsDeleted,1) != 1

UNION ALL 




/** Findings **/

SELECT DISTINCT 
(CONVERT(VARCHAR,F.addedon,101) + ' ' + RIGHT(CONVERT(CHAR(20), F.addedon, 22), 11))
As Date,DATEDIFF(DAY,C.DateReceived,F.addedon) As DE , 'description' AS Icon,
'Created ' + LOWER(F.isexternaldesc) + 'finding #'+ ISNULL(C.Number,'')  AS Details,
 'Title: ' + F.titleFinding  As Findings,
'#FFFFFF' As BG,
C.CaseID,F.addedon   FROM KYP.ADM_Case C
INNER JOIN KYP.ADM_Application A ON A.CaseID = C.CaseID 
INNER JOIN KYP.SDM_ApplicationParty S ON S.ApplicationID = A.ApplicationID AND IsActive = 1
RIGHT JOIN (
SELECT  a.DateCreated addedon, 
                CASE WHEN a.Type IN ('Application Review') THEN cast(fe.PCaseID + '' AS int) ELSE cast(a.CaseID + '' AS int) END caseIDFinding,
                CASE WHEN a.ExternalYesNO IS NULL THEN 'N/D' 
                     WHEN (a.ExternalYesNO = '1' OR    a.ExternalYesNO = 'Yes') THEN 'EXTERNAL' 
                     WHEN (a.ExternalYesNO = '0' OR    a.ExternalYesNO = 'NO') THEN 'INTERNAL' ELSE NULL END AS isexternaldesc,
                a.Name titleFinding                              
												/*NO TRACKING FIELD*/
        FROM          kyp.OIS_Note a   JOIN
							                  /*NO EVENT TABLE*/
         kyp.MDM_JournalBasicInfo fe ON a.PInID = fe.infoid 
         WHERE      (((a.Type = 'Application Review' AND a.ReasonCode IS NOT NULL) OR
                                              a.Type <> 'Application Review' ) AND isnull(a.Deleted,'0')<>'1')
)
 F ON F.caseIDFinding = C.CaseID 


---**
UNION ALL
/** Messages **/

Select 
(CONVERT(VARCHAR,U.CreatedOn,101) + ' ' + RIGHT(CONVERT(CHAR(20), U.CreatedOn, 22), 11))
As Date,DATEDIFF(DAY,C.DateReceived,U.CreatedOn) As DE,'email' As Icon,
		'Enrollment system sent message to provider in Portal' As Details
		,'Subject: ' + ISNULL(M.Subject,'') As Findings,
		'#FFFFFF' As BG,
		CONVERT(VARCHAR,A.EntityID) AS CaseID,U.CreatedOn
from KYP.OIS_UserMessage U 
INNER JOIN KYP.OIS_Messages M ON M.MessageID = U.MessageID AND M.Type IN('TEMP') AND M.Type IS NOT NULL
INNER JOIN KYP.OIS_MessageAssociation A ON M.MessageID = A.MessageID AND A.EntityName = 'ADM_Case'
INNER JOIN KYP.ADM_Case C ON A.EntityID = C.CaseID AND C.IsPPURequired = 0

UNION ALL

/** Work Flow **/
SELECT DISTINCT W.Date,W.DE,W.Icon,W.Details,W.Findings,W.BG,W.CaseID,SortDateTime  FROM(
		SELECT -- ROW_NUMBER() OVER(Order by H.ID ASC) AS ID,
		(CONVERT(VARCHAR,H.SortDateTime,101) + ' ' + RIGHT(CONVERT(CHAR(20), H.SortDateTime, 22), 11)) 
		As Date,H.SortDateTime,DATEDIFF(DAY,C.DateReceived,H.SortDateTime) As DE,'settings' As Icon,
		CASE 
		WHEN H.MajorStatus = 'Assign application' AND LOWER(H.UserID) = 'userr' AND H.ActivityStatus = 'In Progress' THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' currently unassigned list of supervisor confirmer'
		
		WHEN H.MajorStatus = 'Assign application' AND H.ActivityStatus = 'Completed' THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' assigned by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Accept Assignment' AND C.StatusCodeNumber = 9 AND H.ActivityStatus = 'In Progress' THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Accepts or Declines Assignment by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Accept Assignment' AND H.ActivityStatus = 'Declined' THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Declined by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Accept Assignment' AND (H.ActivityStatus = 'Accepted')  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Accepted by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND (H.ActivityStatus = 'Accepted')  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Accepted by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Review Application/Screening' AND (H.ActivityStatus = 'Completed')  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Review Application/Screening Completed by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Review Application/Screening' AND (H.ActivityStatus = 'In Progress')  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' under Review Application/Screening by ' + H.UserFullName
				
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'In Progress'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Set resolution under progress by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'Reverted'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Reverted by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'Returned'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Returned by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'Referred'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Referred by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'Completed'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + '  Set resolution Completed by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Completed' AND H.ActivityStatus = 'Completed'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Completed by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'ReAssignment' AND H.ActivityStatus = 'Reassigned'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Reassigned by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'ReAssignment' AND H.ActivityStatus = 'Accepted'   THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Reassigned Accepted by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND H.ActivityStatus = 'Suspended'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Suspended by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND H.ActivityStatus = 'Resumed'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Resumed by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND H.ActivityStatus = 'Consulted'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Consulted by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND H.ActivityStatus = 'Escalated'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Escalated by ' + H.UserFullName
		
		WHEN H.MajorStatus IS NULL AND H.ActivityStatus = 'Returned'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Returned by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Set resolution' AND H.ActivityStatus = 'Returned'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Returned by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Review Cancelled' AND (H.ActivityStatus = 'Completed' OR H.ActivityStatus = 'In Progress')  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Review Cancelled by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Assign application' AND H.ActivityStatus = 'Referred'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Referred by ' + H.UserFullName
		
		WHEN H.MajorStatus = 'Pending Approver Assignment' AND H.ActivityStatus = 'In Progress'  THEN
		'This application# ' + CONVERT(VARCHAR,C.Number)  + ' Assgined by ' + H.UserFullName
		
		
		END AS Details,'NA' As Findings,
			'#FFFFFF' As BG,
		CONVERT(VARCHAR,C.CaseID) AS CaseID
		FROM KYP.ADM_WorkflowHistory H 
			INNER JOIN KYP.ADM_Case C ON C.CaseID = H.CaseID AND H.Type = 'HISTORY'
			INNER JOIN KYP.OIS_User U ON U.PersonID = C.AssignedFromID 		
	)W WHERE ISNULL(W.Details,'')  != ''


)X WHERE ISNULL(X.Details,'') <> ''


GO

