



CREATE VIEW [KYP].[view_AgeMilestoneReport] 
AS
SELECT 
 ROW_NUMBER() over(order by A.DateReceived Desc) As RID,
 A.CaseID As CaseID,
 A.Number As AppNumber,
 A.ProviderName As ProviderName,
 A.Priority As Priority,
 COALESCE(LTRIM(RTRIM(NULLIF(A.Provider_NPI,''))),'NA') As Provider_NPI,
 A.ApplnTypeAlias As ApplnTypeAlias,
 A.TypeDescription As ProviderType,
 A.ASSIGNED_BY_NAME As ASSIGNED_BY_NAME,
 A.DateReceived As DateReceived,
 COALESCE(LTRIM(RTRIM(NULLIF(A.MILESTONE,''))),'NA') As MILESTONE,
 COALESCE(LTRIM(RTRIM(NULLIF(convert(varchar(10), cast(B.CompletionDate as date), 101),''))),'NA') As MilestoneDate,
 ISNULL(A.DAYS_REMAINING,0) As DAYS_REMAINING,
 COALESCE(LTRIM(RTRIM(NULLIF(A.UserFullName,''))),'NA') As UserFullName,
 COALESCE(LTRIM(RTRIM(NULLIF(A.THRESHOLD,''))),'NA') As THRESHOLD,
 A.WFProcessing As WFProcessing,
 COALESCE(LTRIM(RTRIM(NULLIF(A.WFMajorStep,''))),'NA') As WFMajorStep
 
FROM KYP.ADM_Case A 
	INNER JOIN (select CaseId,MAX(CompletionDate) CompletionDate 
				From KYP.Milestone_CaseDetail
						Where IsCompleted=1
						Group by CaseID) B on A.CaseID = B.CaseID
						
 WHERE A.IsPPURequired = 0


GO

