



CREATE VIEW [KYP].[SDM_Summary_Report_View]
AS
SELECT TOP (100) PERCENT row_number() OVER (ORDER BY Z.NoteID ASC) AS ID, Z.Number,Z.ReasonCode, Z.NoteEntityTypeID, Z.Tags, Z.Author, Z.DateCreated, 
Z.UnformattedContent, Z.CaseID, Z.FullDateCreated, Z.Name, Z.NoteID, Z.NoteEntityDepID, Z.NoteNumber, Z.Type, Z.RangeName, Z.PartyName, Z.Score, Z.PartyID, 
Z.IsDeleted, Z.UserID
FROM  (SELECT DISTINCT 
                              B.Number, B.ReasonCode, C.NoteEntityTypeID, B.Tags, B.Author, B.DateCreated, CONVERT(varchar(max), B.UnformattedContent) AS UnformattedContent, B.CaseID, 
                              B.FullDateCreated, B.Name, B.NoteID, C.NoteEntityDepID, C.NoteNumber, F.PartyRole AS Type, E.RangeName, G.Name AS PartyName, B.Score, G.PartyID, 
                              B.UserID, ISNULL(A.IsDeleted, 0) AS IsDeleted
               FROM   KYP.SDM_ScreeningFinding A INNER JOIN
                              KYP.OIS_Note B ON A.FindingNoteID = B.NoteID INNER JOIN
                              KYP.NoteEntity C ON B.Number = C.NoteNumber INNER JOIN
                              KYP.SDM_RiskScore D ON D.FindingID = A.FindingID LEFT JOIN
                              KYP.SDM_RiskFactor E ON E.RiskFactorID = D.RiskFactorID LEFT JOIN
                              KYP.SDM_ApplicationParty F ON D.ApplicationID = F.ApplicationID AND D.ScreeningID = f.ScreeningID LEFT JOIN
                              KYP.PDM_Party G ON F.PartyID = G.PartyID
               WHERE ISNULL(A.IsDeleted, 0) <> 1 AND C.NoteEntityType = 'ADM_Case') Z
ORDER BY Z.NoteEntityTypeID


GO

