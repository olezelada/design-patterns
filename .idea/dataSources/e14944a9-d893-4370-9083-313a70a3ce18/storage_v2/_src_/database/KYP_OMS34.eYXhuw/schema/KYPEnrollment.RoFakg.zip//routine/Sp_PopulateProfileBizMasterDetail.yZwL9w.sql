
--Fill Product Profile Master Detail
CREATE PROC [KYPEnrollment].[Sp_PopulateProfileBizMasterDetail] as
begin
--delete existing master data for full load
truncate table [KYPEnrollment].[pAccount_BizProfile_Details]
delete from KYPEnrollment.[pAccount_BizProfile_Master]

exec ('IF EXISTS (
    SELECT *
    FROM sys.objects
    WHERE [type] = ''TR'' AND [name] = ''Create_ProfileID''
   )
	DISABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON KYPEnrollment.[pAccount_BizProfile_Master]')
	
INSERT INTO [KYPEnrollment].[pAccount_BizProfile_Master]
           ([ProfileID]                    
           ,[CurrentRecordFlag]
           ,[IsTempProfile]
           ,[ProfileCreatedDate])

select distinct RIGHT('0000000000'+ISNULL(convert(varchar(10),a.id),''),10),  
1 as CurrentRecordFlag,
0 as IsTempProfile,
GETDATE() AS ProfileCreatedDate
from dbo.temp_Stage_CA_Profile_Data A
join KYPEnrollment.pADM_Account B  
on A.ProviderReferenceNo = left(B.LegacyAccountNo,9)


exec ('
IF EXISTS (
    SELECT *
    FROM sys.objects
    WHERE [type] = ''TR'' AND [name] = ''Create_ProfileID''
   )
	ENABLE TRIGGER [KYPEnrollment].[Create_ProfileID] ON KYPEnrollment.[pAccount_BizProfile_Master]')

INSERT INTO [KYPEnrollment].[pAccount_BizProfile_Details]
           ([ProfileID]
           ,[AccountID]
           ,[AccountEnrollmentStatus]
           ,[AccountBillingStatus]
           ,[AccountLegalName]
           ,[AccountDBAName]
           ,[AccountProviderType]
           ,[AccountNPI]
           ,[AccountSSN]
           ,[AccountEIN]
           ,[AccountAddressType]
           ,[AccountAddressLine1]
           ,[AccountAddressLine2]
           ,[AccountAdrCity]
           ,[AccountAdrState]
           ,[AccountAdrZip9]
           ,[AccountLicenseType]
           ,[AccountLicenseNo]
           ,[AccountPhone]
           ,[AccountPIN]  
           ,[EffectiveBeginDate]
           ,[CurrentRecordFlag]
           ,[PayAccountAddressLine1]
           ,[PayAccountAddressLine2]
           ,[PayAccountAdrCity]
           ,[PayAccountAdrState]
           ,[PayAccountAdrZip9]
           ,[AccountNumber]
           ,[LEGACYACCOUNTNO])

select  distinct
           RIGHT('0000000000'+ISNULL(convert(varchar(10),id),''),10) as [ProfileID]
           ,B.AccountID as [AccountID]
           , case when KYPEnrolmentStatus IN ('1','7','9') then '1 - Active'
            else '2 - Inactive' 
            end as [AccountEnrollmentStatus]
           , case 
                        when KYPEnrolmentStatus = '1' then '1 - Billing'
                        when KYPEnrolmentStatus = '7' then '7 - Rendering'
                        when KYPEnrolmentStatus = '9' then '9 - TempSuspended'
                        when KYPEnrolmentStatus = '6' then '6 - Suspended'
                        when KYPEnrolmentStatus = '3' then '3 - Pending'
                        when KYPEnrolmentStatus = '4' then '4 - Deceased'
                        when KYPEnrolmentStatus = '5' then '5 - Rejected'
                        when KYPEnrolmentStatus = '8' then '8 - Contract'
                        when KYPEnrolmentStatus = '2' then '2 - Inactive'              
            else null 
            end as [AccountBillingStatus]
           ,DH_LEGAL_NAME as  [AccountLegalName]
           ,DH_LEGAL_NAME as  [AccountDBAName]
           ,DH_PROV_TYP as [AccountProviderType]
           ,DH_PROV_NUMBER as [AccountNPI]
           ,DH_SSN as [AccountSSN]
           ,DH_EMP_ID_NO as  [AccountEIN]
           ,'Service Address' as [AccountAddressType]
           ,DH_ADDR_LN1 as  [AccountAddressLine1]
           ,Null as  [AccountAddressLine2]
           ,DH_ADDR_CITY as  [AccountAdrCity]
           ,DH_ADDR_STATE as  [AccountAdrState]
           ,DH_ADDR_ZIP5 + isnull(DH_ADDR_ZIP4,'') as [AccountAdrZip9]
           ,null as [AccountLicenseType]
           ,DH_PROV_LIC_NO as  [AccountLicenseNo]
           ,right(DH_PROV_TELE_NO,12) as  [AccountPhone]
           ,DH_PIN as  [AccountPIN]  
           ,B.StatusBeginDate AS EffectiveBeginDate
           ,1 as [CurrentRecordFlag]
           ,DH_PAY_TO_LN1 as  [PayAccountAddressLine1]
           ,null as  [PayAccountAddressLine2]
           ,DH_PAY_TO_CITY [PayAccountAdrCity]
           ,DH_PAY_TO_STATE [PayAccountAdrState]
           ,DH_PAY_TO_ZIP5 + isnull(DH_PAY_TO_ZIP4,'') [PayAccountAdrZip9]
           ,AccountNumber as AccountNumber
           ,B.LegacyAccountNo
from dbo.temp_Stage_CA_Profile_Data A 
join KYPEnrollment.pADM_Account B  
on A.ProviderReferenceNo = left(B.LegacyAccountNo,9)
join dbo.Stage_MD_State_KYP_Status C 
on C.Provider_MA_Number = A.ProviderReferenceNo



update A 
set A.ProfileName=B.AccountLegalName,A.EIN=B.AccountEIN
from [KYPEnrollment].[pAccount_BizProfile_MAster] A
join [KYPEnrollment].[pAccount_BizProfile_Details] B
on A.ProfileID=B.ProfileID



Update A set A.LinkedAccountCount=b.ProfileCount
from KYPEnrollment.pAccount_BizProfile_Master A
inner Join (
select ProfileID, COUNT(*) as ProfileCount from KYPEnrollment.pAccount_BizProfile_Details A Inner join KYPEnrollment.pADM_Account B on a.AccountID=b.AccountID
where b.LegacyAccountNo is not null
group by ProfileID )B
on A.ProfileID=b.ProfileID

End


GO

