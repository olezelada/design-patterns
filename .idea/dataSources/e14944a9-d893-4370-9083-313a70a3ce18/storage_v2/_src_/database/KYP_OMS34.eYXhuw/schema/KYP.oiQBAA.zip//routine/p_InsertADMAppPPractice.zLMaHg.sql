CREATE PROCedure [KYP].[p_InsertADMAppPPractice]
(@ApplicationID int
 ,@PartyID int= NULL
 ,@UseEIN bit =0
 ,@CreatedBy int = NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@UPIN varchar(6)=NULL
)
as begin 

INSERT INTO [KYP].[ADM_App_PPractice]
           ([ApplicationID]
           ,[PartyID]
           ,[UseEIN]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[UPIN])
     VALUES
           (@ApplicationID
           ,@PartyID
           ,@UseEIN
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@UPIN)

	return IDENT_CURRENT('[KYP].[ADM_App_PPractice]')

end


GO

