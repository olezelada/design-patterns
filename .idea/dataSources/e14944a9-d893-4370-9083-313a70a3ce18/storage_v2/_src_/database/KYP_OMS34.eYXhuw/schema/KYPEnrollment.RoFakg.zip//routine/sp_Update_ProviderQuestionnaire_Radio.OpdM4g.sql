-- =============================================
-- Author:		<ohuanca>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
								
CREATE PROCEDURE [KYPEnrollment].[sp_Update_ProviderQuestionnaire_Radio]
	@field_code_tracking VARCHAR(100),
	@fieldCode VARCHAR(40),
	@questionnaireName VARCHAR(40),
	@new_value_text VARCHAR(MAX),
	@acc_party_id INT,
	@questionnaireType VARCHAR(40),
	@party_app_id INT
AS
BEGIN
	IF @field_code_tracking IN (@fieldCode)
    BEGIN
		--copy values
      IF NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie WHERE name = @questionnaireName and PartyID = @acc_party_id)
      BEGIN
        PRINT 'SAVE RADIO INFORMATION';
        EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByName] @party_app_id, @acc_party_id, @questionnaireName;
      END
    END
END


GO

