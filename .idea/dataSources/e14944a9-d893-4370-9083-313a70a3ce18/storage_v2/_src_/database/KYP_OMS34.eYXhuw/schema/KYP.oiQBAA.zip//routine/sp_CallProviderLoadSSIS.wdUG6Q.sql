
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[sp_CallProviderLoadSSIS] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @SQLQuery AS VARCHAR(2000)

	SET @SQLQuery = 'DTExec /FILE ^"C:\upload\With License Expiry ACS Provider Load To Provider Database.dtsx^" '

	EXEC master..xp_CMDShell '"C:\upload\GetFile\GetFile.bat"'

	EXEC master..xp_cmdshell @SQLQuery
END


GO

