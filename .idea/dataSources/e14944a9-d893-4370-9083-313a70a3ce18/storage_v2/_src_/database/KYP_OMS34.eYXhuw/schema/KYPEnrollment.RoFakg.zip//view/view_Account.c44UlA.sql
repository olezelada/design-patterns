



CREATE VIEW [KYPEnrollment].[view_Account] AS
SELECT distinct
account.AccountID accountId, 
account.ApplicationNumber applicationNumber, 
account.LegalName legalName, 
account.BusinessName businessName, 
account.DateModified updatedDate, 
account.ActivationDate activationDate, 
account.StatusAcc statusAccount, 
account.NPI npi, 
account.DateCreated dateApproved, 
account.StatusBeginDate beginDate, 
account.AccountNumber accountNumber, 
account.NPIType npiType, 
account.PackageName packageName, 
account.ProviderTypeCode providerTypeCode,
account.RevalidationDueDate dateExpired,
account.PartyID partyId,
account.ProviderType providerType,
account.PracticeAddress practiceAddress,
account.portaluserid portalUserId, 
account.AccountType  accountType, 
account.ScheduleType scheduleType,
account.ServiceLocationNo serviceLocationNo,
details.ProfileID 
FROM 
KYPEnrollment.pADM_Account account, 
KYPEnrollment.pAccount_BizProfile_Details details
 WHERE   
   ( account.StatusAcc IN  ('1 - Active','7 - Active Rendering (indirect)', '9 - Temporary Suspended') or
   (account.StatusAcc IN  ('2 - Inactive')  AND account.AccountType IN ('NMP', 'ORP'))
   )
 AND details.CurrentRecordFlag = 1
 AND account.IsDeleted= 0
 AND account.AccountID = details.AccountID
 AND account.IsPastOwner= 0 
 AND (account.npi like '1%' OR account.npi like '4%')


GO

