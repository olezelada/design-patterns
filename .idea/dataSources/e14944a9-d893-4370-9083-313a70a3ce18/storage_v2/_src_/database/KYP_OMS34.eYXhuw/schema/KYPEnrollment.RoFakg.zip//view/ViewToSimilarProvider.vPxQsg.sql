



--Select * from [KYPEnrollment].[ViewToSimilarProvider] where PartyID = 4

--Select * from KYPEnrollment.pAccount_PDM_Location 
--Select * from KYPEnrollment.pAccount_PDM_Address where PartyID = 4
--Select * from KYP.SDM_ApplicationParty where PartyID = 3


--by Specialty and ZIP
CREATE VIEW [KYPEnrollment].[ViewToSimilarProvider]
AS
select (row_number() over ( order by r.CaseID)) AS ViewID, r.*
from
-- for individual
(
select DISTINCT pa.PartyID,
	 ca.CaseID,
	 ca.IsPPURequired , 
	 ISNULL(ca.WFStatus,'') As WFStatus,
	 app.ApplicationID,
	 app.Status,
	 ca.Number as ApplicationNumber,
	 ca.Number as ProviderNumber, 
	 CASE WHEN apppa.PartyType = 'Owner Person' OR apppa.PartyType = 'Managing Control Person' THEN	 
	 (ISNULL((Select TOP 1 ISNULL(p.FirstName,'')+' '+ISNULL(p.MiddleName ,'')+' '+ISNULL(p.LastName ,'') From  KYP.PDM_Person p where p.PartyID=pa.PartyID),''))
	 WHEN apppa.PartyType = 'Provider Person' THEN ca.ProviderName
	 ELSE
	 ca.ProviderName END as Name,
	 ca.ApplnTypeAlias as ApplicationType,
	 ca.MILESTONE as Milestone,
	 pe.NPI,
	 pe.SSN as SSN,
	 pe.TaxId as TIN, 
	-- ISNULL((Select TOP 1 ISNULL(ad.AddressLine1 ,'')+', '+ISNULL(ad.AddressLine2 ,'')+', '+ISNULL(ad.City ,'')+', '+ISNULL(ad.[State] ,'')+', '+ ISNULL(ad.Zip ,'')+(CASE WHEN ad.ZipPlus4 is null THEN '' ELSE '-'+ad.ZipPlus4 END)+', '+ISNULL(ad.County,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc),'') as PracticeAddress, 
	ISNULL(AD.AddressLine1 ,'') + ', ' + ISNULL(AD.AddressLine2 ,'') + ', ' + ISNULL(AD.City ,'')+', ' + ISNULL(ad.statecode ,'') + ', ' + ISNULL(AD.ZipPlus4 ,'') +  ', ' + ISNULL(AD.County,'') as PracticeAddress, 
    ISNULL(ca.TypeDescription,'') as ProviderType,
	ISNULL((Select TOP 1 ISNULL(ad.Zip ,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc),'') as Zip, 
	 (Select TOP 1 ISNULL(ad.ZipPlus4 ,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc) as ZipPlus4, 
	 (ISNULL((Select Substring((Select ',' + CONVERT(VARCHAR(15), CaseIDA) From KYPEnrollment.Linked_ADM_Case where CaseIDM=cas.CaseID and StatusLinked='Link' For XML Path('')),2,8000) From KYP.ADM_Case as cas WHERE cas.CaseID = ca.CaseID),'A')) as CaseIDLinked,
	 '' as Specialty,
	 '' as StatusLinked,
	 ISNULL(ca.WFStatus,'') As Filter,
	 SA.AddressLine1 As  SrAddressLine1,
	 SA.AddressLine2 As  SrAddressLine2,
	 SA.City As SrCity,
	 SA.State As SrState,
	 SA.Zip As SrZip5,
	 SA.ZipPlus4 As SrZip4,
	 PT.AddressLine1 As PTAddressLine1,
	 PT.AddressLine2 As PTAddressLine2,
	 PT.City As PTCity,
	 PT.State As PTState,
	 PT.Zip As PTZip5,
	 PT.ZipPlus4 As PTZip4   
	from KYP.PDM_Party as pa
	inner join KYP.PDM_Person as pe on pa.PartyID=pe.PartyID
	inner join (KYP.SDM_ApplicationParty as apppa inner join (KYP.ADM_Application as app inner join KYP.ADM_Case as ca on app.CaseID=ca.CaseID) on apppa.ApplicationID=app.ApplicationID ) 
	on apppa.PartyID=pa.PartyID AND apppa.isActive = 1
	LEFT JOIN KYPEnrollment.PortalAddress SA ON ca.CaseID = SA.EnrollCaseID AND SA.IsDeleted = 0 AND SA.Type = 'Servicing'
    LEFT JOIN KYPEnrollment.PortalAddress PT ON ca.CaseID = PT.EnrollCaseID AND PT.IsDeleted = 0 AND PT.Type = 'Pay-to'
	LEFT JOIN [KYP].[View_AllAddresses] AD on AD.ApplicationNo = ca.Number and AD.Type='Servicing'
where (app.isDeleted is null or app.IsDeleted='false') 
and (apppa.IsDeleted is null or apppa.IsDeleted='false') 
and (pa.IsDeleted is null  or pa.IsDeleted ='false') 
and ca.IsPPURequired=0
and ca.WFProcessing=0
and apppa.PartyType = 'Provider Person'
union all
--for organization
select DISTINCT pa.PartyID,
	 ca.CaseID,
	 ca.IsPPURequired, 
	 ISNULL(ca.WFStatus,'') As WFStatus,
	 app.ApplicationID,
	 app.Status,
	 ca.Number as ApplicationNumber,
	 ca.Number as ProviderNumber,
	 CASE WHEN apppa.PartyType = 'Owner Organization'  THEN	
	 org.LegalName 
	 WHEN apppa.PartyType = 'Provider Organization' THEN ca.ProviderName 	 
	 ELSE ca.ProviderName END as Name,
	 ca.ApplnTypeAlias as ApplicationType,
	 ca.MILESTONE as Milestone,
	 org.NPI,
	 org.SSN as SSN,
	 org.TIN as TIN, --in the org. is tin
	-- ISNULL((Select TOP 1 ISNULL(ad.AddressLine1 ,'')+', '+ISNULL(ad.AddressLine2 ,'')+', '+ISNULL(ad.City ,'')+', '+ISNULL(ad.[State] ,'')+', '+ ISNULL(ad.Zip ,'')+(CASE WHEN ad.ZipPlus4 is null THEN '' ELSE '-'+ad.ZipPlus4 END)+', '+ISNULL(ad.County,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc),'') as PracticeAddress, 
	 ISNULL(AD.AddressLine1 ,'') + ', ' + ISNULL(AD.AddressLine2 ,'') + ', ' + ISNULL(AD.City ,'')+', ' + ISNULL(ad.statecode ,'') + ', ' + ISNULL(AD.ZipPlus4 ,'') +  ', ' + ISNULL(AD.County,'') as PracticeAddress, 
	 ISNULL(ca.TypeDescription,'') as ProviderType,
	 ISNULL((Select TOP 1 ISNULL(ad.Zip ,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc),'') as Zip, 
	 (Select TOP 1 ISNULL(ad.ZipPlus4 ,'') from KYP.PDM_Location as lo LEFT JOIN KYP.PDM_Address as ad ON ad.AddressID = lo.AddressID WHERE lo.PartyID = pa.PartyID AND lo.InActive = 1 AND lo.IsDeleted =0 ORDER by lo.LocationID desc) as ZipPlus4, 
	 (ISNULL((Select Substring((Select ',' + CONVERT(VARCHAR(15), CaseIDA) From KYPEnrollment.Linked_ADM_Case where CaseIDM=cas.CaseID and StatusLinked='Link' For XML Path('')),2,8000) From KYP.ADM_Case as cas WHERE cas.CaseID = ca.CaseID),'A')) as CaseIDLinked,
	 '' as Specialty,
	 '' as StatusLinked, ISNULL(ca.WFStatus,'') As Filter,
	 SA.AddressLine1 As  SrAddressLine1,
	 SA.AddressLine2 As  SrAddressLine2,
	 SA.City As SrCity,
	 SA.State As SrState,
	 SA.Zip As SrZip5,
	 SA.ZipPlus4 As SrZip4,
	 PT.AddressLine1 As PTAddressLine1,
	 PT.AddressLine2 As PTAddressLine2,
	 PT.City As PTCity,
	 PT.State As PTState,
	 PT.Zip As PTZip5,
	 PT.ZipPlus4 As PTZip4  
from KYP.PDM_Party as pa
	inner join KYP.PDM_Organization as org on pa.PartyID=org.PartyID
	inner join (KYP.SDM_ApplicationParty as apppa inner join (KYP.ADM_Application as app inner join KYP.ADM_Case as ca on app.CaseID=ca.CaseID) on apppa.ApplicationID=app.ApplicationID ) 
	on apppa.PartyID=pa.PartyID AND apppa.isActive = 1
	LEFT JOIN KYPEnrollment.PortalAddress SA ON ca.CaseID = SA.EnrollCaseID AND SA.IsDeleted = 0 AND SA.Type = 'Servicing'
    LEFT JOIN KYPEnrollment.PortalAddress PT ON ca.CaseID = PT.EnrollCaseID AND PT.IsDeleted = 0 AND PT.Type = 'Pay-to'
	Left Join [KYP].[View_AllAddresses] AD on AD.ApplicationNo = ca.Number and AD.Type='Servicing'
where (app.isDeleted is null or app.IsDeleted='false') and (apppa.IsDeleted is null or apppa.IsDeleted='false') and 
	  (pa.IsDeleted is null  or pa.IsDeleted ='false') and ca.IsPPURequired=0 and ca.WFProcessing=0
	  and Apppa.PartyType = 'Provider Organization' 
) r


GO

