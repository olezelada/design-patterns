-- =============================================
-- Author:		<Author,,Lperez>
-- =============================================
--, Speciality_Code, TaxonomyCode, NPI, SSN,EIN , ZipPlus4 
CREATE VIEW [KYPEnrollment].[SearchSimilarRelated]
AS
select (row_number() over ( order by r.AccountID)) AS ViewID, r.*
from
(
select DISTINCT acc.AccountID, acc.NPI, acc.SSN,acc.EIN , ad.ZipPlus4
from [KYPEnrollment].[pADM_Account] acc 
INNER JOIN [KYPEnrollment].pAccount_PDM_Party par ON par.AccountID = acc.AccountID
INNER JOIN [KYPEnrollment].pAccount_PDM_Location lo ON lo.PartyID=par.PartyID AND lo.Type='Servicing'
INNER JOIN [KYPEnrollment].pAccount_PDM_Address ad ON ad.AddressID = lo.AddressID 
) r


GO

