

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[InsertScheduledAccountsData] 
@AccountID int, @ScheduleID int
AS
BEGIN

Declare
@TempAccountID varchar(300),
@CaseId int,
@ApplicationNumber varchar(15),
@AccountNumber varchar(50),
@ProviderName varchar(250),
@ScheduledStatus varchar(50),
@ReenrollmentStatus varchar(50),
@RevalidationTemplate varchar(300),
@FirstExtensionTemplate varchar(300),
@FinalExtensionTemplate varchar(300),
@StartDate smalldatetime,
@EndDate smalldatetime,
@CreatedOn smalldatetime,
@FirstExtensionDate smalldatetime,
@FirstExtensionEndDate smalldatetime,
@FinalExtensionDate smalldatetime, 
@FinalExtensionEndDate smalldatetime,
@FirstExtensionDays int,
@FinalExtensionDays int,
@ScheduleType varchar(2),
@Type varchar(50),
@rowsize int =0,
@lOIDMSID varchar(100),
@lOILetterName varchar(200)

	SELECT @FirstExtensionDays = FirstExtensionDays, @FinalExtensionDays = FinalExtensionDays, @ScheduleType = ScheduleType, @RevalidationTemplate = [RevalidationLetter],@FirstExtensionTemplate = [FirstExtensionLetter],@FinalExtensionTemplate= [FinalextensionLetter],
	@StartDate = [RevalidationStartDate], @EndDate =[RevalidationEndDate], @CreatedOn = [CreatedOn] , @FirstExtensionDate = [FirstExtensionStartDate], 
	@FirstExtensionEndDate = [FirstExtensionEndDate], @FinalExtensionDate =[FinalExtensionStartDate], @FinalExtensionEndDate =[FinalExtensionEndDate],
	@lOIDMSID = LOIDMSID, @lOILetterName = LOILetterName
	FROM [KYPEnrollment].[ScheduledAccounts] WHERE ID = @ScheduleID


	SELECT @ApplicationNumber = [ApplicationNumber], @AccountNumber = [AccountNumber], @ProviderName = [LegalName] FROM [KYPEnrollment].[pADM_Account]
	WHERE AccountID = convert(int,@AccountID)

	SELECT @CaseId = [CaseID] FROM [KYP].[ADM_Case]
	WHERE Number = @ApplicationNumber
	

	INSERT INTO [KYPEnrollment].[AccountRevalidation]
	([CaseId]
	,[ApplicationNumber]
	,[AccountNumber]
	,[ProviderName]
	,[ScheduledStatus]
	,[ReenrollmentStatus]
	,[RevalidationTemplate]
	,[FirstExtensionTemplate]
	,[FinalExtensionTemplate]
	,[StartDate]
	,[EndDate]
	,[CreatedOn]
	,[AccountID]
	,[Type]
	,[FirstExtensionDate]
	,[FirstExtensionEndDate]
	,[FinalExtensionDate]
	,[FinalExtensionEndDate]
	,[ScheduleID]
	,[FirstExtensionDays]
	,[FinalExtensionDays]
	,[LOIDMSID]
	,[LOILetterName])
			VALUES(
			 @CaseId
			,@ApplicationNumber
			,@AccountNumber
			,@ProviderName
			,'Scheduled'
			,'Not Started'
			,@RevalidationTemplate
			,@FirstExtensionTemplate
			,@FinalExtensionTemplate
			,@StartDate
			,@EndDate
			,GETDATE()
			,@AccountID
			,(case when @ScheduleType = 'RV' then 'Revalidation' else 'Re-enrollment' end)
			,@FirstExtensionDate
			,@FirstExtensionEndDate
			,@FinalExtensionDate
			,@FinalExtensionEndDate
			,@ScheduleID
			,@FirstExtensionDays
			,@FinalExtensionDays
			,@lOIDMSID
			,@lOILetterName
			)
--Drop table #tblAccount

END


GO

