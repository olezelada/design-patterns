-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RemoveUnwantedCharacters] 
(
	
	@NameValue varchar(500)
)
RETURNS varchar(255)
AS
BEGIN 
   declare 
   @NameValue1 varchar(250),
   @NameValue2 varchar(250),
   @NameValue3 varchar(250),
   @NameValue4 varchar(250)
      
    if substring(@NameValue,1,1)=' '  or RIGHT(@namevalue,1)=' '
    begin      
      select @NameValue  = rtrim(ltrim(@NameValue))
    end
    if substring(@NameValue,1,1)='''' or RIGHT(@namevalue,1)=''''
    begin
	  select @NameValue = dbo.RemoveSinglequotesAdd(@NameValue)
	end 
	if substring(@NameValue,1,1)='"' or RIGHT(@namevalue,1)='"'
	begin
      select @NameValue = dbo.RemovedoublequotesAdd(@NameValue)
    end
    if substring(@NameValue,1,1)='\' or RIGHT(@namevalue,1)='\'
    begin
      select @NameValue = dbo.RemoveforwardslashAdd(@NameValue)
    end
    if  substring(@NameValue,1,1)='/' or RIGHT(@namevalue,1)='/'
    begin
      select @NameValue = dbo.RemovebackslashAdd(@NameValue)
    end

return @NameValue
END


GO

