



CREATE VIEW [KYP].[v_CaseSummaryResolutions] AS
Select	ROW_NUMBER() OVER( order by R.DateCreated desc) RID,
		CONVERT(VARCHAR,A.CaseID) AS CaseID,
		R.ResolutionType As Resolution,
		COALESCE(ActivityStatus,'') + COALESCE(('/'+R.UserID),'') + COALESCE((','+ CONVERT(VARCHAR,R.DateCreated,101) + ' ' + RIGHT(CONVERT(CHAR(20), R.DateCreated, 22), 11)),'') AS Event_AddedOn,
		R.Notes As Details,
		CASE WHEN R.ResolutionType = 'Referred-Licensing and Certification (L&C)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Enrolled/Provisional Status Granted' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'NPI Change' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Denied' THEN 'rgb(255, 0, 0);'
	 WHEN R.ResolutionType = 'Referred-Office of Legal Services (OLS)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Deficiency Notice Sent' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Referred-Audits and Investigations (A&I)' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Benefits Division' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Lab Field Services' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Other' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Referred-Pharmacy' THEN 'rgb(0, 0, 255);'
	 WHEN R.ResolutionType = 'Review Cancelled - Close as duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN R.ResolutionType = 'Closed as Duplicate' THEN 'rgb(255, 128, 0);'
	 WHEN R.ResolutionType = 'Approve' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Approved' THEN 'rgb(29, 204, 6);'
	 WHEN R.ResolutionType = 'Close without account update' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Dis-Enrolled by Provider' THEN 'rgb(128, 128, 128);'
	 WHEN R.ResolutionType = 'Review Cancelled - Application Withdrawn' THEN 'rgb(0, 128, 128);'	 
	 WHEN R.ResolutionType = 'Ignored' THEN 'rgb(255, 174, 0);'
	 WHEN R.ResolutionType = 'Referred' THEN 'rgb(0, 0, 255);'	
	 WHEN R.ResolutionType = 'Close with no action' THEN 'rgb(255, 174, 0);' 
	 WHEN R.ResolutionType = 'Exempt' THEN 'rgb(29, 204, 6);' 
	 WHEN R.ResolutionType = 'Reject' THEN 'rgb(255, 0, 0);' 
	 ELSE '#FFFFFF;' END As RBG
from KYP.SDM_Resolution R INNER JOIN KYP.ADM_Application A ON R.ApplicationID = A.ApplicationID 
where R.ResolutionType != 'Temp' AND ActivityStatus != 'Temp' --Condition added by Ameet for KEN-9062


GO

