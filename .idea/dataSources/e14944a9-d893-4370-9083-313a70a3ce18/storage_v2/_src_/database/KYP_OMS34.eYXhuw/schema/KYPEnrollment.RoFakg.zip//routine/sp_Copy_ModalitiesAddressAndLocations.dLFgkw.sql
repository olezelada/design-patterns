
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <08/09/2017>
-- Description:	<Copy ALL the addresses and Locations related to Modalities of Portal to Enrollment from a PartyID on Enrollment>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ModalitiesAddressAndLocations]
	@mod_party_id int,
	@party_Id int,
	@last_Action_User_ID varchar(100)
	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

declare @addresses table (pk int identity(1,1),AddressID int,LocationID int);
declare @tot int;
declare @cont int,@add int,@new_add int,@loc int,@party_mod_portal int;

select top 1 @party_mod_portal = PartyID from KYPPORTAL.PortalKYP.pPDM_Party where PartyID=@party_Id and Type='Modality'

DECLARE @date_created DATE;
SET @date_created =  GETDATE();

IF EXISTS (SELECT DISTINCT AddressID from [KYPPORTAL].[PortalKYP].[pPDM_location] where PartyID=@party_mod_portal and IsDeleted=0)
and exists(select ModalityId from KYPEnrollment.pAccount_PDM_Modalities m where PartyId=@mod_party_id and ModlityCode in ('HDP','RS','NTP') and CurrentRecordFlag=1)

BEGIN

		INSERT INTO @addresses (AddressID,LocationID)
		SELECT l.AddressID,l.LocationID from [KYPPORTAL].[PortalKYP].[pPDM_location] l INNER JOIN [KYPPORTAL].[PortalKYP].[pPDM_Address] a
		ON a.AddressID=l.AddressID 		where l.PartyID=@party_Id and l.Type='modResAddress' and l.IsDeleted=0 and a.IsDeleted=0
		select @tot =MAX(pk) from @addresses ;
		set @cont=1;

		WHILE @cont<=@tot
		begin
		
		select @add = AddressID, @loc = LocationID from @addresses where pk=@cont;

		
		----------------------------------------------------------------
		INSERT INTO KYPEnrollment.pAccount_PDM_Address (
		AddressLine1,
		AddressLine2,
		County,
		City,
		Zip,
		ZipPlus4,
		State,
		Country,
		Latitude,
		Longitude,
		GeographicArea,
		LastAction,
		LastActionDate,
		LastActionUserID,
		CurrentRecordFlag,
		AdaAccessible,
		TtyCapacity,
		TtyNumber,
		Explanation)
		
		SELECT 
		AddressLine1,
		AddressLine2,
		County,
		City,
		Zip,
		ZipPlus4,
		State,
		Country,
		Latitude,
		Longitude,
		GeographicArea,
		'C',
		@date_created,
		@last_Action_User_ID,
		1,
		AdaAccessible,
		TtyCapacity,
		TtyNumber,
		Explanation 
		
		FROM KYPPORTAL.PortalKYP.pPDM_Address where AddressID = @add and IsDeleted=0
		
		SET @new_add = SCOPE_IDENTITY()
		
		INSERT INTO KYPEnrollment.pAccount_PDM_Location (
		AddressID,
		PartyID,
		Type,
		WorkingDays,
		WorkingHours,
		Phone1,
		Phone2,
		Fax,
		Remarks,
		CreatedBy,
		DateCreated,
		InActive,
		IsDeleted,
		Email,
		IsLicensed,
		IsRented,
		Status,
		Name,
		LastAction,
		LastActionDate,
		CurrentRecordFlag,
		IsSchoolSide,
		IsDonatedSpace,
		ProviderTypeCode,
		ProviderType,
		Approved,
		EffectiveDate,
		LastActorUserID,
		LastActionApprovedBy)
		
		select  
		@new_add,
		@mod_party_id,
		'modResAddress',
		WorkingDays,
		WorkingHours,
		Phone1,
		Phone2,
		Fax,
		Remarks,
		CreatedBy,
		@date_created,
		InActive,
		0,
		Email,
		IsLicensed,
		IsRented,
		Status,
		Name,
		'C',
		@date_created,
		1,
		IsSchoolSide,
		IsDonatedSpace,
		ProviderTypeCode,
		ProviderType,
		1,
		EffectiveDate,
		@last_Action_User_ID,
		@last_Action_User_ID
		
		FROM KYPPORTAL.PortalKYP.pPDM_Location where LocationID=@loc and IsDeleted=0
		
		PRINT 'NEW ADDRESS FOR MODALITY CREATED'
		


		
		set @cont= @cont + 1
		end

END


END


GO

