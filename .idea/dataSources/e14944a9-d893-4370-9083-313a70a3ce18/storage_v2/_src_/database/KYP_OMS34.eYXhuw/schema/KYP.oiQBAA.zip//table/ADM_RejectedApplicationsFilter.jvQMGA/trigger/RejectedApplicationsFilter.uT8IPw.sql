


-- =============================================
-- Author:		<Vinoth>
-- Create date: <April 25, 2013>
-- Description:	<Used for applying top 5 filter on rejected applications>
-- =============================================
CREATE TRIGGER [KYP].[RejectedApplicationsFilter]
   ON [KYP].[ADM_RejectedApplicationsFilter]
   AFTER INSERT
AS 
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @FromDate datetime,
			@ToDate datetime,
			@UserID varchar(100),
			@ProviderType varchar(100),
			@ReasonCode varchar(100),
			@ScreeningLevel varchar(100)
			
	SET @FromDate = (SELECT FromDate FROM inserted);
	SET @ToDate = (SELECT ToDate FROM inserted);
	SET @UserID = (SELECT UserID FROM inserted);
	SET @ProviderType = (SELECT ProviderType FROM inserted);
	SET @ReasonCode = (SELECT ReasonCode FROM inserted);
	SET @ScreeningLevel = (SELECT ScreeningLevel FROM inserted);
		
	IF (LTRIM(RTRIM(ISNULL(@ProviderType,''))) = '')
	BEGIN
		SET @ProviderType = '%'
	END		
	
	IF (LTRIM(RTRIM(ISNULL(@ReasonCode,''))) = '')
	BEGIN
		SET @ReasonCode = '%'
	END
	
	IF (LTRIM(RTRIM(ISNULL(@ScreeningLevel,''))) = '')
	BEGIN
		SET @ScreeningLevel = '%'
	END
	
		
	DELETE FROM [KYP].[ADM_RejectedApplications];
	
	INSERT INTO [KYP].[ADM_RejectedApplications]
				SELECT row_number() OVER (ORDER BY A.PType ASC) AS TopID, CNTP, PType, Type	FROM 
				(
					SELECT	COUNT(ProviderType) AS CNTP, ProviderType AS PType, 'ProviderType' AS Type
					FROM	KYP.v_RejectedApplication
					WHERE	(RejectedDate BETWEEN '' + @FromDate + '' AND '' + DATEADD(DAY, 1, @ToDate) + '') 
						AND	v_RejectedApplication.ProviderType like @ProviderType 
						AND v_RejectedApplication.ScreeningLevel like @ScreeningLevel							
						AND v_RejectedApplication.ReasonCode like @ReasonCode							
					GROUP BY ProviderType
						
					UNION
					
					SELECT	COUNT(ReasonCode) AS CNTReason, ReasonCode AS RCode, 'ReasonCode' AS Expr1
					FROM	KYP.v_RejectedApplication AS v_RejectedApplication_1
					WHERE	(RejectedDate BETWEEN '' + @FromDate + '' AND '' + DATEADD(DAY, 1, @ToDate) + '') 
						AND	v_RejectedApplication_1.ProviderType like @ProviderType 
						AND v_RejectedApplication_1.ScreeningLevel like @ScreeningLevel 
						AND v_RejectedApplication_1.ReasonCode like @ReasonCode 
					GROUP BY ReasonCode
				) AS A
	
	
	
	
	
END


GO

