


/* ==========================================================
-- Author:		<Ralba,TJaldin>
-- PROCEDURE: Update Account by Traking.   
-- PARAMETERS: 
-- @application_no: Application Number to application type (Supplemental,CHOW,CHOA).
-- @account_number : Account Number that will be update. 
-- @last_action_user_id : Enrollment User.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[Update_Associations_NewModel]
	@last_action VARCHAR(1),
	@party_id_app INT,
	@app_id INT,
	@account_id INT,
	@profId VARCHAR(100)

AS

BEGIN
    --not include otherassociations
	select *  into #FieldTrakingByParty1 from [KYPPORTAL].[PortalKYP].[FieldValuesTracking] 
	where AccTableName IS NOT NULL AND AccPKValue IS NOT NULL AND AccPK IS NOT NULL AND applicationid=@app_id and( TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable' or TableCode='significantSubTable')

if exists(select * from 	#FieldTrakingByParty1)
begin
	create table #partyRelation  (ID INT IDENTITY(1,1),CurrentValueInt INT , NewValueInt INT, TargetPath VARCHAR(200),AccPK varchar(100),AccPKValue int)
	insert into #partyRelation
	--update in associations with subcontractors or ownership
	select CurrentValueInt,NewValueInt, SUBSTRING(TargetPath,CHARINDEX('pAccount_PDM_OwnershipRelationship|OwnerRelationID|',TargetPath,1)+51, 
	LEN(TargetPath)),AccPK,accpkvalue from #FieldTrakingByParty1 WHERE (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable' or TableCode='significantSubTable')
	 and CurrentValueInt is not null 
	and NewValueInt is not null 

	
	CREATE TABLE #PartyPortal (PartyID INT,ParentPartyID INT,Type VARCHAR(50),IsPrepopulated BIT,TargetPath VARCHAR(200),Partyenroll VARCHAR(200))
	INSERT INTO #PartyPortal
	SELECT PartyID,ParentPartyID ,Type,IsPrepopulated,TargetPath,SUBSTRING(targetpath,CHARINDEX('pAccount_PDM_Party|PartyID|',TargetPath,1)+27,LEN(targetpath)) AS partyenroll 
	FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE ParentPartyID= @party_id_app or
	( ParentPartyID IN (SELECT PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE ParentPartyID = @party_id_app))
	OR PartyID = @party_id_app
	
	;WITH PartyLevels (partyidlevel,type,IsPrepopulated,partypadre,partyabuelo,partylevel,partyenroll,partyenrollmain) AS
	(
		SELECT PartyID,Type,IsPrepopulated,NULL,NULL,0 AS partylevel , partyenroll,null FROM #PartyPortal
		WHERE ParentPartyID  IS NULL UNION ALL
		SELECT p.PartyID,p.Type,p.IsPrepopulated,
		pe.partyidlevel, pe.partypadre ,
		partylevel+1 ,P.partyenroll,null
		FROM #PartyPortal AS p INNER JOIN PartyLevels pe ON p.ParentPartyID=pe.partyidlevel

	)
	select * into #PartiesLevelTable  from PartyLevels

	--update pl set pl.partyenrollmain= pl.partyenroll
	--FROM  #PartiesLevelTable pl 
	

	SELECT pl.*, pl.partyenroll MainPartyID,pl.partyenroll  AS partyIDEnrollment, case when part.partyid is null then @account_id  else part.accountid end AccountID INTO #AssociationsTable FROM  #PartiesLevelTable pl 
	left join kypenrollment.paccount_pdm_party part  ON (ISNULL (pl.partyenroll, '') = CONVERT (VARCHAR (10), part.partyid))
	
	 
	--party Prepopulados
	update relation set partyidowned=asso1.partyIDEnrollment
	from 	#partyRelation 
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on relation.OwnerRelationID =#partyRelation.accpkvalue
	inner join #AssociationsTable asso1 on #partyRelation.NewValueInt=asso1.partyidlevel and  asso1.isprepopulated=1

	--se cambia la asociacion a un party nuevo
	update relation set partyidowned=party.PartyID
	from 	
	#partyRelation 
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on relation.OwnerRelationID =#partyRelation.accpkvalue
	inner join #AssociationsTable asso1 on #partyRelation.NewValueInt=asso1.partyidlevel and  (asso1.isprepopulated is null or asso1.isprepopulated='')
	inner join KYPEnrollment.pAccount_PDM_Party party on #partyRelation.NewValueInt=party.TempPartyID and party.AccountID  =@account_id
	
	/* KPP-5555 Update  if Relationship TextValue was modified */
	create table #partyRelation1  (ID INT IDENTITY(1,1),CurrentValueText varchar(max) , NewValueText varchar(max), TargetPath VARCHAR(200),AccPK varchar(100),AccPKValue int)

	insert into #partyRelation1
	select CurrentValueText,NewValueText, SUBSTRING(TargetPath,CHARINDEX('pAccount_PDM_OwnershipRelationship|OwnerRelationID|',TargetPath,1)+51, 
	LEN(TargetPath)),AccPK,accpkvalue from #FieldTrakingByParty1 WHERE (TableCode='ownerSubAssocTable' OR TableCode='individualSubTable'  or TableCode='entitySubTable' or TableCode='assoSubIndTable' or TableCode='assoSubOwnerTable' or TableCode='significantSubTable')
	 and CurrentValueText is not null 
	and NewValueText is not null 
	
	update relation set TransDescription = #partyRelation1.NewValueText
	from 	#partyRelation1 
	inner join KYPEnrollment.pAccount_PDM_OwnershipRelationship relation on relation.OwnerRelationID =#partyRelation1.accpkvalue
	
	
	
	/*update family relation of owner association with subcontractor owners*/
	SELECT mainTrack.CurrentValueText
	  , mainTrack.NewValueText
	  , EntityId = SUBSTRING(mainTrack.TargetPath,CHARINDEX('pAccount_PDM_OwnershipRelationship|OwnerRelationID|',mainTrack.TargetPath,1)+51
	  , LEN(mainTrack.TargetPath))
	  , mainTrack.AccPK
	  , mainTrack.accpkvalue
	INTO #FamilyTracking
	FROM #FieldTrakingByParty1 mainTrack
	WHERE FieldValueID IN (SELECT MAX(FieldValueID)
              FROM #FieldTrakingByParty1 track
		          WHERE track.FieldCode = 'familyRelation'
		          AND track.ActionTaken = 'Updated'
		          AND track.TableCode = 'assoSubOwnerTable'
		          AND track.AccPKValue = mainTrack.AccPKValue
	            )
	    AND mainTrack.CurrentValueText IS NOT NULL
	    AND mainTrack.NewValueText IS NOT NULL

	PRINT('UPDATING FAMILY RELATION VALUE OF OWNER ASSOCIATION');

	UPDATE relation
	SET FamiliarRelationship = #FamilyTracking.NewValueText
		, LastAction = 'U'
		, LastActionDate = GETDATE()
	FROM #FamilyTracking
	INNER JOIN KYPEnrollment.pAccount_PDM_OwnershipRelationship relation ON relation.OwnerRelationID = #FamilyTracking.accpkvalue

    drop table #partyRelation
	drop table #PartyPortal
	drop table #PartiesLevelTable
	drop table #AssociationsTable
	drop table #FamilyTracking

end
	/*this part delete all association that was not prepopulated (related new subcontractor aproach)*/
	/*read all party of mocas involved on this update*/
  SELECT AppPartyID
	INTO #PartyMocaPrepopulated
  FROM KYPPORTAL.PortalKYP.FieldValuesTracking mainTracking
  WHERE mainTracking.FieldValueID IN (
            SELECT MAX(tracking.FieldValueID)
            FROM KYPPORTAL.PortalKYP.FieldValuesTracking tracking
            WHERE tracking.ApplicationID = @app_id
              AND tracking.TableCode = 'ownerTable'
              AND tracking.FieldCode = 'associationSubcontractorOwner'
              AND tracking.AppPartyID = mainTracking.AppPartyID
              AND tracking.IsDeleted = 0)
    AND mainTracking.CurrentValueText = 'Yes'
    AND mainTracking.NewValueText = 'No'
  ORDER BY mainTracking.FieldValueID DESC
if exists(select * from #PartyMocaPrepopulated)
begin
  /*update Ownerrelationship account*/
    UPDATE relation
      SET relation.CurrentRecordFlag = 0
      , relation.IsDeleted = 1
      , relation.LastAction = 'D'
    FROM KYPEnrollment.pAccount_PDM_OwnershipRelationship relation
      INNER JOIN (SELECT partyAccountMoca = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(party.TargetPath), 0, PATINDEX('%|%', (REVERSE(party.TargetPath))))),''))
                  FROM KYPPORTAL.PortalKYP.pADM_App_Field field
                    INNER JOIN KYPPORTAL.PortalKYP.pADM_App_Form form on form.AppFormID = field.AppFormID
                    INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party party on party.PartyID = form.PartyID
                    INNER JOIN #PartyMocaPrepopulated mocaTracking on mocaTracking.AppPartyID = party.PartyID
                  WHERE form.ApplicationID = @app_id
                    AND form.Type = 'OwnerAssociation'
                    AND field.Type = 'assocSubcontractorOwner'
                    ANd ISNULL(field.Value,'') = 'No'
                    AND party.TargetPath like '%pAccount%'
                    AND party.IsDeleted = 0
                    AND form.IsDeleted = 0) mocaApplication on mocaApplication.partyAccountMoca = relation.ParentPartyIdAssociation
    WHERE relation.IsDeleted = 0
      AND relation.CurrentRecordFlag = 1
      AND relation.TypeAssociation = 'SubcontractorIndividualOwnerAssociation'
      
end

	drop table #FieldTrakingByParty1
	
	DROP TABLE #PartyMocaPrepopulated
	--drop table #valueOrganization
	--drop table #valuePerson
END


GO

