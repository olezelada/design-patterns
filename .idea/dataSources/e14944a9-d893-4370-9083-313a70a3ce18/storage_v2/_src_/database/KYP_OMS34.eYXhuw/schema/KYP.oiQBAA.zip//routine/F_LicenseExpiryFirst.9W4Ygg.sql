CREATE FUNCTION [KYP].[F_LicenseExpiryFirst]()
RETURNS Date
as
Begin
DECLARE @Month int
DECLARE @Year int
DECLARE @ReMonth date
DECLARE @ReYear date
set @Month = datepart(month,dateadd(month,1, getdate()));
set @Year = datepart(year,dateadd(month,1, getdate()));
set @ReMonth=(select DATEADD(month,@Month-1,DATEADD(year,@Year-1900,0)) /*First*/)

--set @ReYear =(select DATEADD(day,-1,DATEADD(month,@Month,DATEADD(year,@Year-1900,0))) /*Last*/)

return @ReMonth
end


GO

