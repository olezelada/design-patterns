-- =============================================
-- Author:		<Lacunza Giresse>
-- Create date: <20/11/2017>
-- Description:	<This procedure fill the section_sp table with the procedures and sections required, if you add a new procedure/section that has to be in the update twins flow, please add it here>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].sp_Fill_Section_Table

AS
BEGIN

	SET NOCOUNT ON;

INSERT INTO [KYPEnrollment].section_sp (sp_copy,sp_delete,section_code,IsDeleted)
values
('[KYPEnrollment].[sp_Copy_Personal_Information] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no',	'[KYPEnrollment].[sp_delete_Personal_Information] @new_Account_Id',	'1.2.1',0),
('[KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id,'+char(39)+'Individual Profile'+char(39)+', @last_Action_User_ID;',	'KYPEnrollment.sp_delete_Residential_Address @new_Account_Id',	'1.2.2',0),
('[KYPEnrollment].[sp_Copy_Identification] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no',	'[KYPEnrollment].[sp_delete_Identification] @new_Account_Id',	'1.2.3',0),
('[KYPEnrollment].[sp_Copy_Twin_Business_Profile_Section] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no',	'[KYPEnrollment].[sp_delete_Business_Profile_Section] @new_Account_Id',	'2.1.1',0),
('[KYPEnrollment].[sp_Copy_Twin_Business_Profile_Section] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no',	'[KYPEnrollment].[sp_delete_Business_Profile_Section] @new_Account_Id', '2.1.3',0),
('[KYPEnrollment].[sp_Copy_Business_Permit_Section] @new_Party_Id,@party_Id,@last_action_user_id;',	'[KYPEnrollment].[sp_delete_Business_Permit_Section] @new_Account_Id', '2.1.4',0),
('[KYPEnrollment].[sp_Copy_Service_Address] @new_Account_Id,@new_Party_Id,@party_Id,@last_action_user_id,@application_no',	'[KYPEnrollment].[sp_delete_Service_Address] @new_Account_Id',	'2.2.1',0),
('[KYPEnrollment].[sp_Copy_Address] @new_Party_Id, @party_Id,'+char(39)+'Mailing'+char(39)+',@last_Action_User_ID;', '[KYPEnrollment].[sp_delete_Mailing_Address] @new_Account_Id'	,'2.2.5',0),
('[KYPEnrollment].[sp_Copy_Insurance] @new_Party_Id,@party_Id,@last_action_user_id;',	'[KYPEnrollment].[sp_delete_Insurance] @new_Account_Id',	'2.3.1',0),
('[KYPEnrollment].[sp_Contact_Person] @party_Id,@new_Party_Id,@last_action_user_id,@new_Account_Id',	'[KYPEnrollment].[sp_delete_Contact_Person] @new_Account_Id',	'2.4.1',0),
('[KYPEnrollment].[sp_Copy_Twin_Place_Business] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id;',	'[KYPEnrollment].[sp_delete_PlaceBusiness] @new_Account_Id',	'2.5.1',0),
('[KYPEnrollment].[sp_Copy_Business_Hours_CA] @new_Party_Id,@party_Id',	'[KYPEnrollment].[sp_delete_Business_Hours] @new_Account_Id',	'2.7.3',0),
('[KYPEnrollment].sp_Copy_Licenses_Certifications @new_Party_Id,@party_Id,@last_action_user_id',	'[KYPEnrollment].[sp_delete_License_Certificates]  @new_Account_Id',	'3.1.1',0),
('[KYPEnrollment].[sp_Copy_Speciality] @new_Party_Id,@party_Id,@last_action_user_id',	'[KYPEnrollment].[sp_delete_speciality] @new_Account_Id',	'3.3.1',0),
('[KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id;',	'[KYPEnrollment].[sp_Delete_Program_Participation] @new_Account_Id',	'4.1.1',0),
('[KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id;',	'[KYPEnrollment].[sp_delete_AdverseAction] @new_Account_Id;',	'4.2.1',0),
('[KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id;',	'[KYPEnrollment].[sp_delete_AdverseAction] @new_Account_Id;',	'4.2.2',0),
('[KYPEnrollment].[sp_Copy_Fines_Debts] @party_Id,@new_Party_Id,@last_action_user_id,null',	'[KYPEnrollment].[sp_delete_FineDebt] @new_Account_Id',	'4.3.1',0),
('[KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_Party_Id,@party_Id,@last_action_user_id,@new_Account_Id',	'[KYPEnrollment].[sp_delete_AdverseAction] @new_Account_Id',	'4.6.4',0),
('[KYPEnrollment].[sp_Copy_Counselor_Party] @party_Id,@new_Party_Id,@new_Account_Id,@last_action_user_id;',	'[KYPEnrollment].[sp_delete_Counselors] @new_Account_Id',	'5.2.1',0),
('[KYPEnrollment].[sp_Copy_Counselor_Party] @party_Id,@new_Party_Id,@new_Account_Id,@last_action_user_id;',	'[KYPEnrollment].[sp_delete_Counselors] @new_Account_Id;',	'5.2.2',0),
('[KYPEnrollment].[sp_Copy_PaymentDetail] @party_Id,@new_Party_Id,@last_action_user_id',	'[KYPEnrollment].[sp_delete_PaymentDetail] @new_Account_Id',	'10.1.1',0),
('[KYPEnrollment].[sp_Copy_ApplicationFee] @new_Party_Id,@party_Id,@last_action_user_id;','[KYPEnrollment].[sp_delete_ApplicationFee] @new_Account_Id', '13.1.1',0),
('[KYPEnrollment].[sp_Copy_ReasonEnrollment] @new_Party_Id,@party_Id,@last_action_user_id;', '[KYPEnrollment].[sp_delete_ReasonEnrollment] @new_Account_Id', '22.1.1',0)
      
END


GO

