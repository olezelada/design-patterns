
-- =============================================
-- Author:		<gLacunza>
-- Create date: <14/02/2018>
-- Description:	<Makes update to business hours>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Business_Hours_CA]
   @party_account_id INT, 
   @application_id INT,
   @last_action_user_id VARCHAR (100)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE @date_created   DATE,
		   @fullHoursService VARCHAR(200),
		   @logisticDay VARCHAR(50),
		   @logisticFrom VARCHAR(50),
		   @logisticTo VARCHAR(50),
		   @action_taken VARCHAR(20),
		   @acc_pk_value varchar(50),
       @fullHoursServiceApp VARCHAR(200);
       
       DECLARE @rows TABLE(ID INT IDENTITY (1, 1), acc int,Day varchar(50), TimeFrom varchar(50), TimeTo varchar(50), Deleted bit);
       DECLARE @rows2 TABLE(ID INT IDENTITY (1, 1), acc int, col varchar(50), value varchar(50));
       DECLARE @adds TABLE(ID INT IDENTITY (1, 1), day_aux varchar(30),t1 varchar(50),t2 varchar(50));
       
     declare @party_id_app int
     select @party_id_app = PartyID from  KYPPORTAL.PortalKYP.pADM_Application where ApplicationID= @application_id       

   SET @date_created = GETDATE ();

   SELECT @fullHoursService = FullHoursService
    FROM KYPEnrollment.PADM_BusinessService
    WHERE PartyID = @party_account_id;
    
    SELECT @fullHoursServiceApp = bus.FullHoursService
	  FROM KYPPORTAL.PortalKYP.pADM_Application por 
		  inner join KYPEnrollment.pADM_Account acc on por.ApplicationNo = acc.ApplicationNumber
		  inner join KYPPORTAL.PortalKYP.pPDM_BusinessService bus on por.PartyID = bus.PartyID
	  WHERE acc.PartyID = @party_account_id;
    
    IF @fullHoursService = 'Open 24/7'
    BEGIN
		UPDATE [KYPEnrollment].[PADM_BusinessHours]
		SET isDeleted = 1
		WHERE PartyID = @party_account_id;

		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Monday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Tuesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Wednesday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Thursday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Friday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Saturday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
		INSERT INTO [KYPEnrollment].[PADM_BusinessHours] ([Day], [TimeFrom], [TimeTo], [PartyID], [IsDeleted]) VALUES ('Sunday', '1/1/1970 12:00:00 AM', '1/1/1970 11:59:59 PM', @party_account_id, 0)
    END 
	ELSE
	BEGIN
		IF (@fullHoursService <> @fullHoursServiceApp) AND EXISTS (SELECT * FROM KYPPORTAL.PortalKYP.FieldValuesTracking WHERE ApplicationID = @application_id AND FieldCode = 'fullHoursService')
		BEGIN
			UPDATE [KYPEnrollment].[PADM_BusinessHours]
			SET isDeleted = 1
			WHERE PartyID = @party_account_id;
		END

    -- UPDATE/DELETE
    IF EXISTS(select FieldValueID from KYPPORTAL.PortalKYP.FieldValuesTracking where SectionCode='2.7.3' and ApplicationID=@application_id)
    BEGIN
      UPDATE [KYPEnrollment].[PADM_BusinessHours] SET CurrentRecordFlag=0, IsDeleted=0 WHERE PartyID = @party_account_id;
      EXEC [KYPEnrollment].[sp_Copy_Business_Hours_CA] @party_account_id, @party_id_app;
    END
	END
END

GO

