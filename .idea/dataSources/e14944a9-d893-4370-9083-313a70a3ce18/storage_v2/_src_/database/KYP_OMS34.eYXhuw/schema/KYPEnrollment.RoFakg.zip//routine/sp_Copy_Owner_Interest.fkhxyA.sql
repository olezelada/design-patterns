



/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Ownership Control Interest form.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @@account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Owner_Interest]
	@party_account_id INT,
	@party_app_id INT,
	@last_action_user_id VARCHAR(100),
	@party_owner_id INT,
	@account_id INT,
	@is_group BIT = 0
AS
BEGIN
	SET NOCOUNT ON 
	DECLARE @party_app_owner_id INT,@party_acc_owner_id INT, @party_type VARCHAR(50),@count_association INT,@is_update BIT, @is_prepopulated BIT,@target_path VARCHAR(200)
	DECLARE @SubmissionDate date ,@dateTaxid Date
	DECLARE @partID INT ,@targetp VARCHAR(50)
	
	
	-- get the Submission date 
	--KPP-10302
	SELECT  @SubmissionDate=trak.DateTracking 
	FROM KYPPORTAL.PortalKYP.pADM_Application ap
	INNER JOIN KYPPORTAL.PortalKYP.pApplicationHistoryTracking trak ON  ap.applicationNo = trak.applicationNumber 
	where 
	trak.applicationMilestone like 'Submitted' and ap.PartyID = @party_app_id
	
  --++
	
	IF @SubmissionDate is null set  @SubmissionDate = convert(date,'1900-01-01')
	
	--CREATE TABLE [KYPEnrollment].[Owner_Association] (
	CREATE TABLE #Owner_Association (pk int IDENTITY(1,1),
		AssPartyAppID INT, AssPartyAccID INT, SubcontractorAccID INT,TypeAsso VARCHAR(50)
	)
	IF @party_owner_id IS NULL
	BEGIN
		--DECLARE owner_cursor CURSOR FAST_FORWARD READ_ONLY FOR
		declare @owner table (pk int identity(1,1),PartyID int , Type varchar(50), IsPrepopulated BIT,TargetPath VARCHAR(200))
		--SELECT identity(int,1,1) as pk,PartyID, Type
		--into #owner
		insert into @owner
		select PartyID, Type, IsPrepopulated,TargetPath
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
		WHERE (Type = 'Entity Ownership' OR Type = 'Individual Ownership') AND (IsDeleted IS NULL OR IsDeleted = 'false') AND ParentPartyID = @party_app_id

		--OPEN owner_cursor

		--FETCH NEXT FROM owner_cursor INTO @party_app_owner_id, @party_type
        declare @cont int,@tot int
        select @tot=MAX(pk) from @owner
        set @cont=1
		while @cont<=@tot
		--WHILE @@FETCH_STATUS = 0
		BEGIN
			SET @is_update = 0;
            select @party_app_owner_id=partyid, @party_type=type, @is_prepopulated = IsPrepopulated, @target_path = TargetPath from @owner where pk=@cont
            
			EXEC @party_acc_owner_id = [KYPEnrollment].[sp_Copy_Party] @party_app_owner_id, @party_account_id, @account_id,@last_action_user_id;
				
            --UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET MOCARelationshipStartDate = GETDATE() WHERE PartyID = @party_acc_owner_id;
            IF (@is_prepopulated=1)
            BEGIN
				 SET  @partID= CONVERT(INT,SUBSTRING (@target_path,CHARINDEX ('pAccount_PDM_Party|PartyID|', @target_path, 1) + 27,LEN (@target_path)))
				 SELECT @dateTaxid=MOCARelationshipStartDate FROM kypenrollment.pAccount_PDM_Party where PartyID = convert(int,@partID)
				 UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET MOCARelationshipStartDate = @dateTaxid WHERE PartyID = @party_acc_owner_id;
            END
            ELSE
            BEGIN  
              UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET MOCARelationshipStartDate = @SubmissionDate WHERE PartyID = @party_acc_owner_id;
            END
  
            UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET LastMOCARelationshipUpdateBy = 'P' WHERE PartyID = @party_acc_owner_id;
            UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET LastMOCAUpdateBy = 'P' WHERE PartyID = @party_acc_owner_id;
            
			IF @party_type = 'Entity Ownership'
			BEGIN
				EXEC [KYPEnrollment].[sp_Copy_Entity_Owner] @party_acc_owner_id, @party_app_owner_id, @last_action_user_id, @account_id, @is_prepopulated,@party_account_id, @is_group,@target_path;
				EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id, 'Entity', @last_action_user_id,0;
			END
			ELSE
			BEGIN
				EXEC [KYPEnrollment].[sp_Copy_Individual_Owner] @party_acc_owner_id, @party_app_owner_id, @last_action_user_id, @is_update, @account_id, @is_prepopulated, @party_account_id, @is_group,@target_path ;
				EXEC [KYPEnrollment].[sp_Create_Unique_Party_Moca] @party_acc_owner_id, 'Individual', @last_action_user_id,0;
			END

			EXEC [KYPEnrollment].[sp_Copy_Subcontractor_Ownership] @party_account_id, @party_acc_owner_id, @party_app_id, @party_app_owner_id, @last_action_user_id, @account_id;

			--INSERT INTO [KYPEnrollment].[Owner_Association] (AssPartyAppID, AssPartyAccID)
			INSERT INTO #Owner_Association (AssPartyAppID, AssPartyAccID)
			VALUES (@party_app_owner_id, @party_acc_owner_id)
            set @cont=@cont+1
			--FETCH NEXT FROM owner_cursor INTO @party_app_owner_id, @party_type
		END

		--CLOSE owner_cursor;
		--DEALLOCATE owner_cursor;
         --drop table #owner
		DECLARE 
			@ass_party_app_id INT, 
			@ass_party_acc_id INT

		--DECLARE owner_association CURSOR FAST_FORWARD READ_ONLY FOR
		
		--SELECT AssPartyAppID, AssPartyAccID
		--FROM [KYPEnrollment].[Owner_Association]

		--OPEN owner_association

		--FETCH NEXT FROM owner_association INTO @ass_party_app_id, @ass_party_acc_id
        select @tot=MAX(pk)from #Owner_Association 
        set @cont=1
        WHILE @cont<=@tot
		--WHILE @@FETCH_STATUS = 0
		BEGIN
		     select @ass_party_app_id=AssPartyAppID, @ass_party_acc_id=AssPartyAccID from #Owner_Association where pk=@cont
			UPDATE [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]
			SET PartyIDOwned = @ass_party_acc_id, DeletedBy = NULL
			WHERE DeletedBy = @ass_party_app_id
            set @cont=@cont+1
			--FETCH NEXT FROM owner_association INTO @ass_party_app_id, @ass_party_acc_id
		END
         DROP TABLE #Owner_Association;
		--CLOSE owner_association;
		--DEALLOCATE owner_association;
		--DROP TABLE [KYPEnrollment].[Owner_Association];
	END
	ELSE
	BEGIN
		SET @is_update = 1;

        -- Review if exist Prepopulation
		
		SELECT @targetp=TargetPath from kypportal.portalkyp.pPDM_Party where PartyID = @party_owner_id  and isPrepopulated=1
		
		SET  @partID= CONVERT(INT,SUBSTRING (@targetp,CHARINDEX ('pAccount_PDM_Party|PartyID|', @targetp, 1) + 27,LEN (@targetp)))
	
		SELECT @dateTaxid=MOCARelationshipStartDate FROM kypenrollment.pAccount_PDM_Party where PartyID = convert(int,@partID)
		
		insert into dbo.Log (Mess,DateModified)  values ('MOCARel i'+convert(varchar,@party_owner_id) + ' '+ convert(varchar,@partID) +' '+convert(varchar,@dateTaxid),getdate());   
		
		IF @dateTaxid is not null  set @SubmissionDate = @dateTaxid 
		ELSE
			BEGIN 
				--set  @SubmissionDate = GETDATE();			
				SELECT  @SubmissionDate=trak.DateTracking 
				FROM KYPPORTAL.PortalKYP.pADM_Application ap
				INNER JOIN KYPPORTAL.PortalKYP.pApplicationHistoryTracking trak ON  ap.applicationNo = trak.applicationNumber 
				where 	trak.applicationMilestone like 'Submitted' and ap.PartyID = @party_app_id			
			END 
		
		insert into dbo.Log (Mess,DateModified)  values ('MOCARel s '+ convert(varchar,@SubmissionDate),getdate());  
				 
		SELECT @party_type = Type
		FROM #TaxIDChange
		WHERE PartyID = @party_owner_id

		EXEC @party_acc_owner_id = [KYPEnrollment].[sp_Copy_Party] @party_owner_id, @party_account_id, @account_id,@last_action_user_id;
	  --UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET MOCARelationshipStartDate = GETDATE() WHERE PartyID = @party_acc_owner_id;
        UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET MOCARelationshipStartDate = @SubmissionDate WHERE PartyID = @party_acc_owner_id;  
        UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET LastMOCARelationshipUpdateBy = 'P' WHERE PartyID = @party_acc_owner_id;
        UPDATE [KYPEnrollment].[pAccount_PDM_Party] SET LastMOCAUpdateBy = 'P' WHERE PartyID = @party_acc_owner_id;
        
        SELECT @is_prepopulated = IsPrepopulated,@target_path = TargetPath FROM #TaxIDChange WHERE PartyID = @party_owner_id AND Type = @party_type
        
		IF @party_type = 'Entity Ownership'
		BEGIN
			EXEC [KYPEnrollment].[sp_Copy_Entity_Owner] @party_acc_owner_id, @party_owner_id, @last_action_user_id, @account_id,@is_prepopulated,@party_account_id,@is_group,@target_path;
		END
		ELSE
		BEGIN
			EXEC [KYPEnrollment].[sp_Copy_Individual_Owner] @party_acc_owner_id, @party_owner_id, @last_action_user_id, @is_update, @account_id,@is_prepopulated,@party_account_id,@is_group,@target_path;
		END
        DROP TABLE #Owner_Association;
		--DROP TABLE [KYPEnrollment].[Owner_Association];
		RETURN @party_acc_owner_id
	END	
	
	--EXEC KYPEnrollment.usp_MocaInputDoc @account_id ----Added for MOCA Color changes. PI-754
END


GO

