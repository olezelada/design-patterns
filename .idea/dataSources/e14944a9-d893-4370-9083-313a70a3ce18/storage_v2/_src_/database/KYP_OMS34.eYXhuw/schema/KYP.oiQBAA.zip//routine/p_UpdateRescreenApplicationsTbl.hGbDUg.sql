



CREATE PROCEDURE [KYP].[p_UpdateRescreenApplicationsTbl]
AS	

BEGIN
DECLARE @Query VARCHAR(MAX)
-----------step-1-delete-table-------------
TRUNCATE TABLE [KYP].[SDM_Rescreen_Applications]
-----------step-1-delete-table-------------

-----------step-2-insert-table-------------
INSERT INTO [KYP].[SDM_Rescreen_Applications]
([PROVIDER_NUMBER],[PROVIDER_NAME],[NPI_STATUS],[RESCREENING_REQUIRED],CASE_ID
,PAN)---- KYP-10912 
SELECT KYP.ADM_Case.Number
	,substring(KYP.ADM_Case.ProviderName, 0, 150)
	,CASE 
		WHEN KYP.SDM_DBCheckResult.NPI = 'U'	-- KYP-10912 
			THEN 'Unknown'
		WHEN KYP.SDM_DBCheckResult.NPI = 'X'	-- KYP-10912 
			THEN 'Not Found'
		ELSE 'Unknown'
		END
	,'Yes'
	,KYP.ADM_Case.CaseID
	,KYP.ADM_Case.PAN
FROM KYP.ADM_Case
INNER JOIN KYP.ADM_Application ON KYP.ADM_Case.CaseID = KYP.ADM_Application.CaseID
INNER JOIN KYP.SDM_ApplicationParty ON KYP.ADM_Application.ApplicationID = KYP.SDM_ApplicationParty.ApplicationID
	AND KYP.SDM_ApplicationParty.IsActive = 1
INNER JOIN KYP.SDM_DBCheckResult ON KYP.SDM_DBCheckResult.ScreeningID = KYP.SDM_ApplicationParty.ScreeningID
	AND (
		NPI IN ('U','X')
		OR NPI IS NULL
		)
INNER JOIN KYP.SDM_DBCheckDetail ON KYP.SDM_DBCheckDetail.DBChkResultID = KYP.SDM_DBCheckResult.DBChkResultID
INNER JOIN KYP.SDM_HMSData ON KYP.SDM_HMSData.ID = KYP.SDM_DBCheckDetail.HMS_RefID
LEFT JOIN [HMS].dbo.HMS_Individual_Profiles IND ON IND.HMS_PIID = KYP.SDM_HMSData.HMSID
LEFT JOIN [HMS].dbo.HMS_Organization_NPI ORG ON ORG.HMS_POID = KYP.SDM_HMSData.HMSID
WHERE (
		IND.HMS_PIID IS NOT NULL
		OR ORG.HMS_POID IS NOT NULL
		)
	AND (
		IND.NPI IS NOT NULL
		OR ORG.NPI IS NOT NULL
		)
	AND KYP.ADM_Case.Number NOT IN (
		SELECT KYP.ADM_Case.Number
		FROM KYP.ADM_Case
		INNER JOIN KYP.ADM_Application ON KYP.ADM_Case.CaseID = KYP.ADM_Application.CaseID
		INNER JOIN KYP.SDM_ApplicationParty ON KYP.ADM_Application.ApplicationID = KYP.SDM_ApplicationParty.ApplicationID
			AND KYP.SDM_ApplicationParty.IsActive = 1
		INNER JOIN KYP.SDM_DBCheckResult ON KYP.SDM_DBCheckResult.ScreeningID = KYP.SDM_ApplicationParty.ScreeningID
			AND ltrim(rtrim(isnull(KYP.SDM_DBCheckResult.NPI, 'U'))) != 'U'
			AND ltrim(rtrim(isnull(KYP.SDM_DBCheckResult.NPI, 'X'))) != 'X'
		GROUP BY KYP.ADM_Case.Number
		)
GROUP BY KYP.ADM_Case.Number
	,KYP.ADM_Case.CaseID
	,KYP.ADM_Case.PAN -- KYP-10912 
	,substring(KYP.ADM_Case.ProviderName, 0, 150)
	,KYP.SDM_DBCheckResult.NPI
;

-----------step-2-insert-table-------------
END


GO

