
CREATE VIEW [KYP].[V_MDM_AlertStatisticsReport]
as
SELECT *, (ROW_NUMBER() OVER (ORDER BY DATENAME(YEAR, YEAR),DATEPART(mm,CAST([Months]+ ' 1900' AS DATETIME)),UniqueId Asc)) AS Row                                 
FROM kyp.MDM_AlertStatisticsReport


GO

