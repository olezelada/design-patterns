
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <29/09/2017>
-- Description:	<Creates a new Party with Counselor type for every party related to the accounts party>
-- @party_Id : main partyID of the application in pavePortal
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Counselor_Party] 
	@party_Id INT,
	@new_Party_Id INT,
	@account_id INT,
	@last_action_user_id VARCHAR(100)

AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	DECLARE @party_counselor_id int,@new_person int,@subparty int;
	declare @parties_id table (pk int identity(1,1),PartyID int);
	
	declare @tot int, @cont int,@add int,@new_add int,@loc int,@new_party_counselor int;

	
	IF EXISTS (SELECT PartyID FROM KYPPORTAL.PortalKYP.pPDM_Party where ParentPartyID=@party_Id  and Type = 'Counselor')
	BEGIN
		INSERT INTO @parties_id (PartyID)
		SELECT PartyID from KYPPORTAL.PortalKYP.pPDM_Party where ParentPartyID=@party_Id  and Type = 'Counselor' and IsDeleted=0;
		
		select @tot =MAX(pk) from @parties_id;
		
		set @cont=1;
		
		WHILE @cont<=@tot
		BEGIN
			select @subparty = PartyID from @parties_id where pk=@cont;
		
			select @add = PartyID from [KYPPORTAL].[PortalKYP].pPDM_Party where PartyID = @subparty;
			
			EXEC @new_party_counselor = [KYPEnrollment].[sp_Copy_Party_Counselor] 	@add,	@new_Party_Id,	@account_id,	@last_action_user_id;
			
			EXEC @new_person = [KYPEnrollment].sp_Copy_Person @new_party_counselor,@add,@last_action_user_id;
			
			EXEC [KYPEnrollment].sp_Copy_AllOtherNames 	@subparty,@last_action_user_id,@new_party_counselor;
			
			EXEC [KYPEnrollment].[sp_Copy_Provider] @new_party_counselor,@subparty,@last_action_user_id;
			
			EXEC [KYPEnrollment].[sp_Copy_Number]	@new_party_counselor,	@subparty,	@last_action_user_id,	null;

			EXEC KYPEnrollment.sp_Store_Attachments_References_Parties @account_id, @subparty, @new_party_counselor
			
			set @cont= @cont + 1;;
			PRINT 'New Counselor';
		END
		
		
	END
	
END
GO

