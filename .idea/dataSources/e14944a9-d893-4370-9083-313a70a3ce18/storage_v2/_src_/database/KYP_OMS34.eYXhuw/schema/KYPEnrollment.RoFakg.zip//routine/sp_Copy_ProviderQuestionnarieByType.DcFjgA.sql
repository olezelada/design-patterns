

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType]
	@party_app_id INT,
	@party_account_id INT,    
	@type varchar(50)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @QuestionId     INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[pAccount_PDM_ProviderQuestionnarie] (
                  [PartyID],
                  [Type],
                  [Name],
                  [Value],
                  [Description],
                  [DateCreated],
                  [CurrentRecordFlag],
                  [IsDeleted],
                  [AppQuestionnaireID])
	  SELECT @party_account_id,
			 Type,
			 Name,
			 Value,
			 Description,
			 @date_created,
			 1,
			 [IsDeleted],
			 QuestionID
	   FROM KYPPORTAL.PortalKYP.[pPDM_ProviderQuestionnarie] 
	   WHERE     
			 Type = @type             
			 AND PartyID = @party_app_id

   
   
      
      INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, DocumentInstanceId, AccountEntityId, EntityName, PrimaryKeyName)
      SELECT null,appQuestion.documentInstanceId, accQuestion.QuestionID,'pAccount_PDM_ProviderQuestionnarie', 'QuestionID' FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie accQuestion
        INNER JOIN KYPPORTAL.PortalKYP.pPDM_ProviderQuestionnarie appQuestion on appQuestion.QuestionID = accQuestion.AppQuestionnaireID
        left join kypenrollment.pAccount_Attachments att on appQuestion.documentInstanceId=att.DocumentInstanceId and accountentityid =accQuestion.QuestionID and att.EntityName ='pAccount_PDM_ProviderQuestionnarie'
      WHERE accQuestion.PartyID = @party_account_id and appQuestion.documentInstanceId is not null and accQuestion.QuestionID is not null and att.AttachmentId is null


    
END

GO

