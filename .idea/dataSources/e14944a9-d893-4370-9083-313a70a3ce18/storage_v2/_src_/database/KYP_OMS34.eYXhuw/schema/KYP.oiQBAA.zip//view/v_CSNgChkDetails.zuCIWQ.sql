


CREATE VIEW [KYP].[v_CSNgChkDetails] AS
SELECT DISTINCT CONVERT(VARCHAR,P.ScreeningID)As ScreeningID,CONVERT(VARCHAR,A.CaseID) As CaseID,B.Name,
		CONVERT(VARCHAR,P.PartyID) As PartyID,N.Field,N.Value,N.Comments,
		convert(varchar(10),P.DateCreated,101) [ScreenedOn]
  FROM 
	KYP.SDM_ApplicationParty P INNER JOIN KYP.ADM_Application A ON A.ApplicationID = P.ApplicationID AND P.IsActive = 1
	INNER JOIN KYP.ADM_Case C ON C.CaseID = A.CaseID 
	INNER JOIN KYP.PDM_Party B ON B.PartyID = P.PartyID  
	INNER JOIN [KYP].[v_CSPartyNegChkResult] N ON N.PartyID = P.PartyID AND N.ApplicationID = A.ApplicationID
	where P.Tag is null


GO

