




/* ==========================================================
-- Author:		<Rahul>
-- PROCEDURE: create ExternalFindingsForLetter.   
-- PARAMETERS: @Number,@UserID

-- ============================================================*/

CREATE PROCEDURE [KYP].[sp_MD_ExternalFindingsForLetter]
	@Number varchar(20),
	@UserID varchar(20)

AS


		INSERT INTO [KYP].[MD_ExternalFindingsForLetter]
			   (CaseID, 
			   Number, 
			   FindingTitle, 
			   FindingDescription,
			   UserID 
			  )


		select 
		c.CaseID,
		c.number,
		A.Name +' '+'-'  as FindingTitle ,
		A.UnformattedContent as FindingDescription,
		@UserID
		from 
			KYP.OIS_Note A
			join  KYP.MDM_JournalBasicInfo B on A.PInID=B.InfoID and B.IsIgnored=0
			join KYPPORTAL.PortalKYP.pADM_Case C on B.PCaseID=C.CaseID
			where (A.ExternalYesNO = '1' or A.ExternalYesNO='Yes') and 
			A.NoteID IN (select DISTINCT c.CFId from  KYP.Eventdates c) and A.Type='Application Review' and C.Number=@Number
	 
	 /*if(@@ROWCOUNT=0) 
	 begin
			INSERT INTO [KYP].[MD_ExternalFindingsForLetter]
			   ( 
			   Number, 
			   FindingTitle, 
			   FindingDescription,
			   UserID 
			  )
			  values('No Data Available','No Data Available','No Data Available',@UserID )
	 end*/











GO

