

CREATE TRIGGER [KYPEnrollment].[pADM_Account_AccStatus_tr]
   ON [KYPEnrollment].[pADM_Account]
   WITH EXECUTE AS CALLER
   FOR INSERT, UPDATE
AS
BEGIN
   /* Trigger body */
   DECLARE
      @oldStatus               VARCHAR (50),
      @newStatus               VARCHAR (50),
      @lastActorUserID         VARCHAR (100),
      @accountID               INT,
      @statusBeginDate         SMALLDATETIME,
      @isDeleted               BIT,
      @packageName             VARCHAR (100),
      @newStatusNotTruncated   VARCHAR (50),
      @ProvLocTypeCd           VARCHAR (1)                               /*1*/
                                          ,
      @ProvLocTypeCdold        VARCHAR (1)                               /*1*/
      , @PartyID int --Added for #1 CAPAVE-2103 
      
	DECLARE @Row_Updation_Source VARCHAR(100)
	SELECT  @Row_Updation_Source=INSERTED.Row_Updation_Source FROM INSERTED 

	--Added by Sundar for Elk implementation on 14 Feb 2019
	Update kypenrollment.padm_Account Set LastActionDate = Getdate()
	Where AccountID IN (Select AccountID from inserted)

	IF Update(Row_Updation_Source) and @Row_Updation_Source IN ('KYP.p_UpdateAlertonAccount','KYPEnrollment.SP_SuperUserHistory') 
	BEGIN
		PRINT 'Going to return to prevent deadlock schema M locks'
		RETURN
	END
	
	Declare @Date date = GETDATE()


   --SET @ProvLocTypeCd = (SELECT ProvLocTypeCd FROM inserted);            /*1*/
   --SET @ProvLocTypeCdold = (SELECT ProvLocTypeCd FROM deleted);          /*1*/
   --SET @oldStatus = (SELECT StatusAcc FROM deleted);
   
   SELECT @ProvLocTypeCd = ProvLocTypeCd FROM inserted;            /*1*/
   SELECT @ProvLocTypeCdold = ProvLocTypeCd FROM deleted;          /*1*/
   SELECT @oldStatus = StatusAcc FROM deleted;   
   
   SELECT @accountID = AccountID,
          @newStatus = StatusAcc,
          @lastActorUserID = LastActorUserID,
          @statusBeginDate = StatusBeginDate,
          @isDeleted = IsDeleted,
          @packageName = PackageName,
          @newStatusNotTruncated = StatusAcc
          , @PartyID = PartyID  --Added for #1 CAPAVE-2103            
   FROM inserted

   IF @oldStatus IS NULL AND @newStatus IS NOT NULL
      BEGIN
         --Insert Account Status
         INSERT INTO KYPEnrollment.pADM_AccountStatus (AccountID,
                                                       StatusType,
                                                       StatusValue,
                                                       LastAction,
                                                       LastActionDate,
                                                       EffectiveBeginDate,
                                                       CurrentRecordFlag)
         VALUES (@accountID,
                 'Enrollment',
                 @newStatus,
                 'C',
                 getDate (),
                 @statusBeginDate,
                 1);
      END
   ELSE
      IF @newStatus <> @oldStatus
         BEGIN
		 		 /* Start #1 MDKYP-1080 will be affecting also to CA */
				IF @newStatus in ('2 - Inactive')
				Begin
					UPDATE KYPEnrollment.AccountRevalidation 
						set ReenrollmentStatus = 'Account Deactivated' 
						where AccountID = @accountID AND ReenrollmentStatus <> 'Completed'
				End
				/* End #1 MDKYP-1080 will be affecting also to CA*/	
		 
            --Update Profile-Account mapping
            UPDATE KYPEnrollment.pAccount_BizProfile_Details
               SET AccountEnrollmentStatus = @newStatus,
                   LastAction = 'U',
                   LastActionDate = getdate (),
                   LastActorUserID = @lastActorUserID
             WHERE AccountID = @accountID;

            --Put the latest account status as historical
            UPDATE KYPEnrollment.pADM_AccountStatus
               SET EffectiveEndDate = @statusBeginDate,
                   LastAction = 'U',
                   LastActionDate = getdate (),
                   CurrentRecordFlag = 0
             WHERE     AccountId = @accountID
                   AND CurrentRecordFlag = 1
                   AND StatusType = 'Enrollment';

            --Insert new account Status
            INSERT INTO KYPEnrollment.pADM_AccountStatus (AccountID,
                                                          StatusType,
                                                          StatusValue,
                                                          LastAction,
                                                          LastActionDate,
                                                          EffectiveBeginDate,
                                                          CurrentRecordFlag)
            VALUES (@accountID,
                    'Enrollment',
                    @newStatus,
                    'C',
                    getDate (),
                    @statusBeginDate,
                    1);
         END

   --- Update Rendering Afiliation
   IF @packageName IN ('ISP_RP_P_DM',
                       'ISP_RP_U_RA',
                       'ISP_RP_S_RM',
                       'RP_RS_MDH')
      BEGIN
         DECLARE
            @isDeletedNewStatusAff               BIT = 1,
            @currentRecordFlagNewStatusAff       BIT = 0,
            @isDeletedCurrentStatusAff           BIT = 0,
            @currentRecordFlagCurrentStatusAff   BIT = 1

         IF @newStatusNotTruncated IN
               ('7 - Active Rendering (indirect)',
                '1 - Active',
                '9 - Temporary Suspended')
            BEGIN
               SET @isDeletedNewStatusAff = 0
               SET @currentRecordFlagNewStatusAff = 1
               SET @isDeletedCurrentStatusAff = 1
               SET @currentRecordFlagCurrentStatusAff = 0
            END

         UPDATE KYPEnrollment.pAccount_RenderingAffiliation
            SET --isDeleted = @isDeletedNewStatusAff,
                CurrentRecordFlag = @currentRecordFlagNewStatusAff,
                LastAction = 'U'
          --LastActionDate = getdate() --KEN-12246
          WHERE AffiliatedAccountID = @accountID --AND isDeleted = @isDeletedCurrentStatusAff
                AND CurrentRecordFlag = @currentRecordFlagCurrentStatusAff
      END
		IF (@ProvLocTypeCd <> isnull(@ProvLocTypeCdold, '') AND Update(ProvLocTypeCd) AND exists (Select ProvLocTypeCd from deleted)) --Changed the condition to add InputDoc_Biller table only for update not for Insert                    /*1*/
		BEGIN
		  INSERT INTO KYPEnrollment.INPUTDOC_BILLER (AccountID,
													 FieldName,
													 FromValue,
													 ToValue,
													 DateModified)
		  VALUES (@accountID,
				  'facility',
				  @ProvLocTypeCdold,
				  @ProvLocTypeCd,
				  GETDATE ())
		END      
      
	/* Start #1 CAPAVE-2103*/
	IF @newStatus in ('7 - Active Rendering (indirect)', '1 - Active', '9 - Temporary Suspended')
	Begin
		Update T1
		Set T1.SpecCertDate = @statusBeginDate
		From [KYPEnrollment].[pAccount_PDM_Speciality] T1
		Where T1.SpecCertDate is null
		and T1.PartyID = @PartyID
		and t1.Type = 'Specialty Code';  
	End
	/* End #1 CAPAVE-2103*/	
	      
	   EXEC [KYPEnrollment].[sp_Insert_AccountInputDoc] @accountID, 'System', @Date;	      
END

IF Update(StatusACC)

Begin

	Update A
	Set A.LastActionDate = Getdate(),A.EnrollmentStatus = B.StatusACC
	From kypenrollment.AccountSearch A
	Join Inserted B on A.AccountID=B.AccountID

End


GO

