CREATE PROCedure [KYP].[p_InsertADMAppAddress]
(@AddressLine1 varchar(50)=NULL
,@AddressLine2 varchar(50)=NULL
 ,@County varchar(25)= NULL
 ,@City varchar(25) =NULL
 ,@Zip varchar(5) = NULL
 ,@ZipPlus4 varchar(50)=NULL
 ,@State varchar(25)=NULL
 ,@Country varchar(25)=NULL
 ,@Latitude varchar(7)=NULL
 ,@Longitude varchar(8)=NULL
 ,@USPSFlag bit=0
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[ADM_App_Address]
           ([AddressLine1]
           ,[AddressLine2]
           ,[County]
           ,[City]
           ,[Zip]
           ,[ZipPlus4]
           ,[State]
           ,[Country]
           ,[Latitude]
           ,[Longitude]
           ,[USPSFlag]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@AddressLine1
           ,@AddressLine2
           ,@County
           ,@City
           ,@Zip
           ,@ZipPlus4
           ,@State
           ,@Country
           ,@Latitude
           ,@Longitude
           ,@USPSFlag
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[ADM_App_Address]')

end


GO

