
/* ==========================================================
-- Author:  <Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Contract/Program Actions and License Actions forms.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @account_id : AccointID that will be create.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Adverse_Action_Form]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @account_id             INT
AS
BEGIN
   /*Program Actions*/
   EXEC [KYPEnrollment].[sp_Copy_Program_Suspension] @party_account_id,
                                                     @party_app_id,
                                                     @last_action_user_id,
                                                     'LiabilitiesActionProgramSuspension',
                                                     NULL,
                                                     @account_id;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'LiabilitiesActionConviction',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'LiabilitiesActionLiability',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'LiabilitiesActionSettlement',
                                                 NULL;
   /*License Actions*/
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'AdverseActionDisciplineSuspendedRevoked',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'AdverseActionDisciplineDisciplinaryHearing',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'AdverseActionDisciplineOtherApproval',
                                                 NULL;

   /* Contract/Program Action for MD */
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'LiabilitiesActionPending',
                                                 NULL;
   EXEC [KYPEnrollment].[sp_Copy_Adverse_Action] @party_account_id,
                                                 @party_app_id,
                                                 @last_action_user_id,
                                                 'LiabilitiesActionSuspendedSurrendered',
                                                 NULL;

   PRINT 'New Adverse Action';
END


GO

