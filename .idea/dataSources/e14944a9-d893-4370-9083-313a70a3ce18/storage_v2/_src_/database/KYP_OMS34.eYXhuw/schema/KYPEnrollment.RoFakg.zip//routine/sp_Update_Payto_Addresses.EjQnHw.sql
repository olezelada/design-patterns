
-- =============================================
-- Author:		<Zelada, Olegario>
-- Create date: <09/06/2018>
-- Description:	<update the payto addresses for the accounts with the same NPI and Owner#>
-- =============================================


CREATE PROCEDURE [KYPEnrollment].[sp_Update_Payto_Addresses]
   @account_party_id           INT,
   @app_party_id               INT,
   @address_type           VARCHAR (100)

   AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @app_address_id       INT,
      @AppType          VARCHAR (100),
      @acc_address_id   INT;


	SELECT	@app_address_id = [AddressID]
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]
		WHERE [PartyID] = @app_party_id AND [Type] = @address_type

	SELECT @acc_address_id = addr.AddressID
			FROM KYPEnrollment.pAccount_PDM_Party party
			INNER JOIN KYPEnrollment.pAccount_PDM_Location location ON party.PartyID = location.PartyID
			INNER JOIN KYPEnrollment.pAccount_PDM_Address addr ON addr.AddressID=location.AddressID
			WHERE location.Type = @address_type and party.PartyID = @account_party_id  and location.CurrentRecordFlag = 1 and location.IsDeleted = 0

	IF Exists (Select [AddressID]
					FROM KYPEnrollment.[pAccount_PDM_Location]
					WHERE [PartyID] = @account_party_id AND [Type] = @address_type)
	Begin	
		UPDATE KYPEnrollment.pAccount_PDM_Address
		SET AddressLine1 = sourceAddress.line1, AddressLine2 = sourceAddress.line2, County = sourceAddress.county, City = sourceAddress.city, Zip = sourceAddress.zip, ZipPlus4 = sourceAddress.zip4,
			State = sourceAddress.state, Country = sourceAddress.country, Latitude = sourceAddress.lat, Longitude = sourceAddress.long, GeographicArea = sourceAddress.geoArea
		FROM
			(SELECT
				   [AddressLine1] as line1,
				   [AddressLine2] as line2,
				   [County] as county,
				   [City] as city,
				   [Zip] as zip,
				   [ZipPlus4] as zip4,
				   [State] as state,
				   [Country] as country,
				   [Latitude] as lat,
				   [Longitude] as long,
				   [GeographicArea] as geoArea
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Address]
			WHERE AddressID = @app_address_id) as sourceAddress
		WHERE AddressID = @acc_address_id
	End
	Else
	Begin
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Address] (
				 [AddressLine1],
				 [AddressLine2],
				 [County],
				 [City],
				 [Zip],
				 [ZipPlus4],
				 [State],
				 [Country],
				 [Latitude],
				 [Longitude],
				 [GeographicArea],
				 [LastAction],
				 [LastActionDate],
				 [LastActionUserID],
				 [LastActionApprovedByUsedID],
				 [CurrentRecordFlag])
		SELECT [AddressLine1],
			[AddressLine2],
			[County],
			[City],
			[Zip],
			[ZipPlus4],
			[State],
			[Country],
			[Latitude],
			[Longitude],
			[GeographicArea],
			'C',
			GETDATE(),
			'Pay-To',
			'Pay-To',
			1
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Address]
		WHERE AddressID = @app_address_id

		SELECT @acc_address_id = SCOPE_IDENTITY ();

		INSERT INTO [KYPEnrollment].[pAccount_PDM_Location] (
				 [AddressID],
				 [PartyID],
				 [Type],
				 [WorkingDays],
				 [WorkingHours],
				 [Phone1],
				 [Phone2],
				 [Fax],
				 [Remarks],
				 [InActive],
				 [Email],
				 [IsLicensed],
				 [IsRented],
				 [Status],
				 [Name],
				 [IsSchoolSide],
				 [IsDonatedSpace],
				 [IsDeleted],
				 [LastAction],
				 [LastActionDate],
				 [LastActorUserID],
				 [LastActionApprovedBy],
				 [CurrentRecordFlag])
		SELECT @acc_address_id,
			@account_party_id,
			[Type],
			[WorkingDays],
			[WorkingHours],
			[Phone1],
			[Phone2],
			[Fax],
			[Remarks],
			[InActive],
			[Email],
			[IsLicensed],
			[IsRented],
			[Status],
			[Name],
			[IsSchoolSide],
			[IsDonatedSpace],
			[IsDeleted],
			'C',
			GETDATE(),
			'Pay-To',
			'Pay-To',
			1
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Location]
		WHERE AddressID=@app_address_id
			and Type = @address_type
	End				 	
END
GO

