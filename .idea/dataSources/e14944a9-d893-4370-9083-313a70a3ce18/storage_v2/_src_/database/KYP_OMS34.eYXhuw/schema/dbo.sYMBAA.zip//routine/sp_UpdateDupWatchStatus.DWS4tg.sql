
-- =============================================
-- Author:		MANIKANTA DONTHU 
-- Create date: 10/7/2014
-- Description:	ELINMINATE THE DUPLCATE ENTRIES IN THE WATCHLIST TABLE AND ADDING THE STATUS IN DUMMY TABLE
-- =============================================
CREATE PROCEDURE [dbo].[sp_UpdateDupWatchStatus] @MEDICAIDID VARCHAR(MAX)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @PARTYID INT
	DECLARE @NPI VARCHAR(50)
	DECLARE @LICENSE VARCHAR(175)
	DECLARE @Name VARCHAR(175)
	DECLARE @DBANAME VARCHAR(175)
	DECLARE @ADDRESSLINE1 VARCHAR(175)
	DECLARE @CITY VARCHAR(175)
	DECLARE @WatchedPartyType VARCHAR(175)
	DECLARE @STATE VARCHAR(175)
	DECLARE @ZIP VARCHAR(175)
	DECLARE @ADDRESSID INT
	DECLARE @AlertID INT

	-- Insert statements for procedure here
	SELECT @PARTYID = WatchedPartyID, @WatchedPartyType = WatchedPartyType
	FROM KYP.MDM_Alert
	WHERE MedicaidID = @MEDICAIDID

	SELECT @NPI = NPI
	FROM KYP.PDM_Provider
	WHERE PartyID = @PARTYID

	--SELECT @ADDRESSID = ADDRESSID
	--FROM KYP.PDM_LOCATION
	--WHERE PARTYID = @PARTYID

	--SELECT @ADDRESSLINE1 = ADDRESSLINE1, @CITY = CITY, @STATE = [State], @ZIP = ZIP
	--FROM KYP.PDM_Address
	--WHERE ADDRESSID = @ADDRESSID
	SELECT @ADDRESSLINE1 = B.AddressLine1, @CITY = B.City, @STATE = B.[State], @ZIP = B.Zip FROM KYP.PDM_Location A INNER JOIN KYP.PDM_Address B
	ON A.AddressID = B.AddressID
	WHERE A.PartyID = @PARTYID

	IF @WatchedPartyType = 'Individual'
	BEGIN
		SELECT @Name = NAME
		FROM KYP.PDM_PARTY
		WHERE PARTYID = @PARTYID

		IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_NPIWatchlist AS S ON N.GateKeeperID = S.GateKeeperID
					AND N.ISAPPROVED = 1
				WHERE S.NPI = @NPI
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_LicenseWatchlist AS L ON N.GateKeeperID = L.GateKeeperID
					AND N.ISAPPROVED = 1
				WHERE L.LICENSE IN (
						SELECT LICENSECODE
						FROM KYP.PDM_LICENSE
						WHERE PARTYID = @PARTYID
						)
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_AddressWatchlist AS A ON N.GateKeeperID = A.GateKeeperID
					AND N.isApproved = 1
				WHERE (
						N.LastName + ', ' + N.FirstName + ' ' + N.MiddleName = @Name
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
					OR (
						N.AkaName = @Name
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'F'
			WHERE MEDICAIDID = @MEDICAIDID
		END
	END
	ELSE
	BEGIN
		SELECT @Name = LEGALNAME
		FROM KYP.PDM_ORGANIZATION
		WHERE PARTYID = @PARTYID

		SELECT @DBANAME = DBANAME1
		FROM KYP.PDM_ORGANIZATION
		WHERE PARTYID = @PARTYID

		IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_NPIWatchlist AS S ON N.GateKeeperID = S.GateKeeperID
					AND N.ISAPPROVED = 1
				WHERE S.NPI = @NPI
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_LicenseWatchlist AS L ON N.GateKeeperID = L.GateKeeperID
					AND N.ISAPPROVED = 1
				WHERE L.LICENSE IN (
						SELECT LICENSECODE
						FROM KYP.PDM_LICENSE
						WHERE PARTYID = @PARTYID
						)
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE IF EXISTS (
				SELECT 1
				FROM KYP.GK_Watchlist AS N
				INNER JOIN KYP.GK_AddressWatchlist AS A ON N.GateKeeperID = A.GateKeeperID
					AND N.isApproved = 1
				WHERE (
						N.NAME = @Name
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
					OR (
						N.NAME = @DBANAME
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
					OR (
						N.AkaName = @DBANAME
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
					OR (
						N.AkaName = @NAME
						AND A.AddressLine1 = @ADDRESSLINE1
						AND A.City = @CITY
						AND A.STATE = @STATE
						AND A.ZipCode = @ZIP
						)
				)
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'T'
			WHERE MEDICAIDID = @MEDICAIDID
		END
		ELSE
		BEGIN
			UPDATE KYP.MDM_BulkDupWatchlist
			SET DummyStatus = 'F'
			WHERE MEDICAIDID = @MEDICAIDID
		END
	END
END


GO

