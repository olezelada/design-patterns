-- =============================================
-- Author:		Vinoth
-- Create date: 12/3/2013
-- Description:	Employees and Owners count population
-- =============================================
CREATE PROCEDURE [dbo].[calOwnersEmployeesCount] 
	-- Add the parameters for the stored procedure here
	@alertID INT, 
	@watchedPartyID INT
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @ownersCount INT,
			@employesCount INT;

    SET @ownersCount = (SELECT COUNT(OwnerID) FROM KYP.PDM_Owner WHERE PartyID = @watchedPartyID);
	SET @employesCount = (SELECT COUNT(EmployeeID) FROM KYP.PDM_Employee WHERE PartyID = @watchedPartyID);
	
	IF @ownersCount IS NULL
		BEGIN
			SET @ownersCount = 0;
		END

	IF @employesCount IS NULL
		BEGIN
			SET @employesCount = 0;
		END	
		
	UPDATE KYP.MDM_Alert SET Owners = @ownersCount, Employees = @employesCount WHERE AlertID = @alertID;
END


GO

