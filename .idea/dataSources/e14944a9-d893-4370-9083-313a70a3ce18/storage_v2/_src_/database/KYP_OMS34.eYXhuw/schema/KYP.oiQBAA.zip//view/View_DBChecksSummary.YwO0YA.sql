/************************
9/24/18 
Updated By:Shayne Fletcher
Update done: Remove Row number ID creation and used unique Identity column that is already established.

***********************/

CREATE VIEW [KYP].[View_DBChecksSummary]
AS

SELECT   --row_number() OVER (ORDER BY KYP.SDM_ApplicationParty.ApplicationID ) AS ID, 
KYP.SDM_ApplicationParty.apppartyid as ID,
KYP.SDM_ApplicationParty.ApplicationID, 
KYP.SDM_ApplicationParty.ScreeningID, KYP.SDM_ApplicationParty.PartyID, KYP.PDM_Party.Name, KYP.PDM_Party.Type,KYP.SDM_ApplicationParty.PartyType,KYP.SDM_ApplicationParty.PartyRole
, KYP.SDM_DBCheckResult.OIGLEIE, KYP.SDM_DBCheckResult.GSAEPLS, KYP.SDM_DBCheckResult.DMF,  KYP.SDM_DBCheckResult.CourtCheck, KYP.SDM_DBCheckResult.PhoneNo,
KYP.SDM_DBCheckResult.NPI, KYP.SDM_DBCheckResult.SSN, KYP.SDM_DBCheckResult.TIN, KYP.SDM_DBCheckResult.DEA, 
KYP.SDM_DBCheckResult.License As License, 
KYP.SDM_DBCheckResult.TAXONOMY_STATUS,
KYP.SDM_DBCheckResult.City,KYP.SDM_DBCheckResult.Specialty, KYP.SDM_DBCheckResult.CLIA,KYP.SDM_DBCheckResult.IW_NPI_STATUS,KYP.SDM_DBCheckResult.IW_LICENSE_STATUS,KYP.SDM_DBCheckResult.IW_NAME_ADDRESS_STATUS
,SDM_RedFlag1.RedFlagCount,
[KYP].[numberToWords] (ISNULL(SDM_RedFlag1.RedFlagCount, 0)) AS FlagCountText,
CASE
 WHEN KYP.SDM_DBCheckResult.IW_NPI_STATUS = 'T' OR KYP.SDM_DBCheckResult.IW_NAME_STATUS = 'T' OR KYP.SDM_DBCheckResult.IW_LICENSE_STATUS = 'T' OR KYP.SDM_DBCheckResult.IW_NAME_ADDRESS_STATUS = 'T'
 THEN 'T'
 ELSE
      'F'
 END As KYP_Watchlist,
 CASE
 WHEN KYP.SDM_DBCheckResult.MCSIS_MD_NPI_STATUS = 'T' THEN 'F'
 when KYP.SDM_DBCheckResult.MCSIS_MD_NPI_STATUS = 'P'THEN 'F'
 when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_STATUS = 'T'THEN 'F'
 when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_STATUS = 'P'THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_ADDR_STATUS = 'T' THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MD_NAME_ADDR_STATUS = 'P' THEN 'F'
  when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_ADDR_STATUS = 'T'THEN 'F'
   when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_ADDR_STATUS = 'P' THEN 'F'
   when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_STATUS = 'T'THEN 'F'
 when KYP.SDM_DBCheckResult.MCSIS_MR_NAME_STATUS = 'P'THEN 'F'
   when MCSIS_MR_NPI_STATUS = 'T' THEN 'F'
    when MCSIS_MR_NPI_STATUS = 'P'THEN 'F'
  ELSE
      'T'
 END As MCSIS_Watchlist,
 CASE
 WHEN KYP.SDM_DBCheckResult.SANDI_NPI_STATUS = 'T' THEN 'T'
 WHEN KYP.SDM_DBCheckResult.SANDI_NAME_STATUS = 'T' THEN 'T'
 when KYP.SDM_DBCheckResult.SANDI_LICENSE_STATUS = 'T' THEN 'T'
 when KYP.SDM_DBCheckResult.SANDI_ADDRESS_STATUS = 'T' THEN 'T'
  WHEN KYP.SDM_DBCheckResult.SANDI_NPI_STATUS = 'P' THEN 'P'
  WHEN KYP.SDM_DBCheckResult.SANDI_NAME_STATUS = 'P' THEN 'P'
  when KYP.SDM_DBCheckResult.SANDI_LICENSE_STATUS = 'P' THEN 'P'
  when KYP.SDM_DBCheckResult.SANDI_ADDRESS_STATUS = 'P' THEN 'P'
 ELSE
      'U'
 END As SANDI_Watchlist,
 KYP.SDM_DBCheckResult.StrAttr2 AS 'TypeMismatch',
 KYP.SDM_DBCheckResult.SOR As SOR,
 (SUBSTRING(KYP.PDM_Person.SSN,0,4)+ '-'+SUBSTRING(KYP.PDM_Person.SSN,4,2)+'-'+SUBSTRING(KYP.PDM_Person.SSN,6,9)) AS PartyPerSSN,
 KYP.PDM_Person.TaxId  AS PartyPerTIN,
 KYP.PDM_Person.NPI AS PartyPerNPI,
 KYP.PDM_Organization.SSN AS PartyOrgSSN,
 (SUBSTRING(KYP.PDM_Organization.TIN,0,3)+ '-'+SUBSTRING(KYP.PDM_Organization.TIN,3,9)) AS PartyOrgTIN,
 KYP.PDM_Organization.NPI AS PartyOrgNPI,
 KYP.SDM_ApplicationParty.DateCreated As ScreenedOn,
 KYP.SDM_ApplicationParty.TAG As TAG,
 KYP.SDM_ApplicationParty.NormalizedRisk As NormalizedRisk
FROM         KYP.SDM_ApplicationParty INNER JOIN
                      KYP.PDM_Party ON KYP.SDM_ApplicationParty.PartyID = KYP.PDM_Party.PartyID INNER JOIN
                      KYP.SDM_PartyScreening ON KYP.SDM_ApplicationParty.ScreeningID = KYP.SDM_PartyScreening.ScreeningID AND 
                      KYP.PDM_Party.PartyID = KYP.SDM_PartyScreening.PartyID 
                      INNER JOIN
                      KYP.SDM_DBCheckResult ON KYP.SDM_PartyScreening.ScreeningID = KYP.SDM_DBCheckResult.ScreeningID AND KYP.SDM_ApplicationParty.IsActive = 1 
                      
                       LEFT OUTER JOIN
                      --
                      (select red1.ScreeningID,red1.isdeleted,RED1.RedFlagCount from KYP.SDM_RedFlag red1 inner join (select screeningid,MIN(redflagid) as redflagid from KYP.SDM_RedFlag where isnull(isdeleted,0)=0 group by screeningid) aux
                       on red1.RedFlagID =aux.redflagid ) SDM_RedFlag1   ON KYP.SDM_ApplicationParty.ScreeningID = SDM_RedFlag1.ScreeningID AND SDM_RedFlag1.IsDeleted = 0
     
                    
      
     LEFT OUTER JOIN 
     KYP.PDM_Person  ON  KYP.SDM_ApplicationParty.PartyID = KYP.PDM_Person.PartyID AND KYP.SDM_ApplicationParty.IsActive = 1
     LEFT OUTER JOIN  
     KYP.PDM_Organization  ON  KYP.SDM_ApplicationParty.PartyID = KYP.PDM_Organization.PartyID AND KYP.SDM_ApplicationParty.IsActive = 1

GO

