
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar address recive dos parametros id Address y el nombre del usuario que hace la modificacion
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Address]
	@addressId INT,
	@lastActionUserID varchar(100)
AS
BEGIN

    DECLARE @newAddressId int,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	SET @newAddressId =0
	--verifica si existe por lo menos un party antes de realisar la copia
	--[KYPPORTAL].[PortalKYP].[pPDM_Address] 
	--[DBLink].[Nombre de la base de datos].[Scheme de la base de datos].[nombre de la tabla]
	IF((SELECT COUNT([AddressID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] as address WHERE address.AddressID = @addressId)>0)
	BEGIN
		INSERT INTO [KYPEnrollment].[pAccount_PDM_Address]
		(AddressLine1 ,
		AddressLine2 ,
		County ,
		City ,
		Zip ,
		ZipPlus4 ,
		State ,
		Country ,
		Latitude ,
		Longitude ,
		GeographicArea,
		ServiceLocationNo,
		LastAction,
		LastActionDate,
		LastActionUserID,
		LastActionReason,
		LastActionComments,
		LastActionApprovedByUsedID,
		CurrentRecordFlag)
		SELECT [AddressLine1]
		,[AddressLine2]
		,[County]
		,[City]
		,[Zip]
		,[ZipPlus4]
		,[State]
		,[Country]
		,[Latitude]
		,[Longitude]
		,[GeographicArea]
		,null
		,'C'
		,@dateCreated
		,@lastActionUserID
		,null
		,null
		,@lastActionUserID		
		,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] as address WHERE address.AddressID = @addressId
		--function que recupera el id del nuevo registro
		SELECT @newAddressId = Scope_Identity()	
		SELECT @message = '[pAccount_PDM_Address] @newAddressId :' + CONVERT(char(10), @newAddressId)
		RAISERROR(@message, 0, 1) WITH NOWAIT
	END	
	RETURN  @newAddressId				
END


GO

