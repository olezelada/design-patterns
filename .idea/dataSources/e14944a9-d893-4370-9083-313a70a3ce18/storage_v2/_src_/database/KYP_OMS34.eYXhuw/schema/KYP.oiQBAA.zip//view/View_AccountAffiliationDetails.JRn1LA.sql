
CREATE VIEW [KYP].[View_AccountAffiliationDetails]
AS
SELECT ROW_NUMBER() OVER (
		ORDER BY Q.GroupProviderNo ASC
		) AS AffID
	,*
FROM (
	(
		SELECT KYP.MDM_GroupAlert.ID
			,KYP.MDM_GroupAlert.GroupAccountID AS GroupProviderNo
			,kyp.PDM_ProviderAccount.AccountNumber AS ProviderNo
			,kyp.PDM_ProviderAccount.AccountNumber AS ApplicationNo --KYP.ADM_Case.Number 
			,kyp.PDM_ProviderAccount.ProviderName AS Name
			,'' AS [Status] --KYP.ADM_Case.WFMinorStep
			,0 AS RiskScore
			,'' AS Type --KYP.ADM_Case.ApplnType
			,NULL AS DateReceived
			,KYP.MDM_GroupAlert.Type AS ProviderType
			,PDM_ProviderAccount.NPI AS NPI
			,NULL AS DateCreated --KYP.ADM_Case.DateCreated
			,'' AS AssignedToName -- KYP.ADM_Case.CurrentlyAssignedToName
			,'' AS WFStatus --KYP.ADM_Case.Status
		FROM kyp.PDM_ProviderAccount
		INNER JOIN KYP.MDM_GroupAlert ON KYP.PDM_ProviderAccount.AccountNumber = KYP.MDM_GroupAlert.GroupMemberAccountID
			AND KYP.PDM_ProviderAccount.AccGenNumber = KYP.MDM_GroupAlert.GroupGenMemberAccountID
		)
	
	UNION
	
	(
		SELECT *
		FROM KYP.view_ProviderGroupInfo
		)
	) Q


GO

