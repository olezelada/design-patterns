
CREATE FUNCTION [dbo].[CompareStringMetrics](@firstword [nvarchar](255), @secondword [nvarchar](255))
RETURNS TABLE
AS
RETURN
(
	SELECT dbo.JaroWinkler(@firstword, @secondword) as Score, 'JaroWinkler' as Metric
)


GO

