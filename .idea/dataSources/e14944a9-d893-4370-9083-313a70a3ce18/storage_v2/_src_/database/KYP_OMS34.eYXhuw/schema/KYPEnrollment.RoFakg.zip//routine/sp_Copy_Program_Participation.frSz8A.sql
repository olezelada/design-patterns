


/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Program Participation Table.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @last_action_user_id : this is the user Enrollment.
-- @type : Party type. 
-- @app_party_row_id : this is the PartyID Row to Application that will be Create in Update Account, it is Null when account is create.
-- @account_id : AccointID that will be create. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Program_Participation]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100),
@type VARCHAR(200),
@app_party_row_id INT,
@account_id INT
AS
BEGIN
DECLARE @party_app_par_id INT,@party_acc_par_id INT
IF @app_party_row_id IS NULL
 BEGIN

	--**
	 DECLARE @date_Create DATE
	SET @date_Create = GETDATE()
	declare  @parties table (partyEnroll int, partyPortal int) 
	 INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
			([Type] ,
			[Name] ,
			[IsProvider] ,
			[IsEnrolled] ,
			[IsTemp] ,
			[IsActive] ,
			[LoadType] ,
			[LoadID] ,
			[LastLoadDate] ,
			[IsDeleted],
			[DateModified] ,
			[CurrentRecordFlag] ,
			[Source] ,
			[LastAction] ,
			[LastActionDate] ,
			[profile_id],
			[ParentPartyID],
			[AccountID],
			[LastActorUserID],
			[LastActionApprovedBy],
			temppartyid
			)
			output inserted.partyid,inserted.temppartyid into @parties
			SELECT [Type]
			,[Name]
			,[IsProvider]
			,[IsEnrolled]
			,[IsTemp]
			,[IsActive]
			,[LoadType]
			,[LoadID]
			,[LastLoadDate]
			,[IsDeleted]
			,[DateModified]
			,1
			,[Source]
			,'C'
			,@date_Create
			,[profile_id]
			,@party_account_id
			,@account_id
			,@last_action_user_id
			,@last_action_user_id
			,partyid
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] 
		WHERE Type=@type AND ParentPartyID=@party_app_id AND IsDeleted = 0
	
	   INSERT INTO [KYPEnrollment].[pAccount_PDM_Organization] (
                  [PartyID],
                  [TIN],
                  [LegalName],
                  [DBAName1],
                  [BusinessName],
                  [Phone1],
                  [Remarks],
                  [CreatedBy],
                  [DateCreated],
                  [IsDeleted],
                  [Fax],
                  [NPI],
                  [License],
                  [EIN],
                  [Medicaid],
                  [DEA],
                  [Sellers],
                  [IsCorporation],
                  [Extension],
                  [CalOmsNumber],
                  [IsCalOms],
                  [LastAction],
                  [LastActionDate],
                  [LastActorUserID],
                  [LastActionApprovedBy],
                  [CurrentRecordFlag],
                  [OrgNumber])
          SELECT par.partyenroll,
             [TIN],
             [LegalName],
             [DBAName1],
             [BusinessName],
             [Phone1],
             [Remarks],
             [CreatedBy],
             @date_create,
             [IsDeleted],
             [Fax],
             [NPI],
             [License],
             [EIN],
             [Medicaid],
             [DEA],
             [Sellers],
             [IsCorporation],
             [Extension],
             [CalOmsNumber],
             [IsCalOms],
             'C',
             @date_create,
             @last_action_user_id,
             @last_action_user_id,
             1,
             [OrgNumber]
        FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] org inner join @parties par on org.partyid=par.partyportal
        
        INSERT INTO [KYPEnrollment].[pAccount_PDM_Provider]
           ([PartyID]
           ,[Category]
           ,[Type]
           ,[CreatedBy] 
           ,[DateCreated]
           ,[IsDeleted]
           ,[NPI]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
        SELECT par.partyenroll
            ,[Category]
            ,[Type]
            ,[CreatedBy]
            ,@date_create
            ,[IsDeleted]
            ,[NPI]
            ,'C'
            ,@date_create
            ,@last_action_user_id
            ,@last_action_user_id
            ,1
         FROM [KYPPORTAL].[PortalKYP].[pPDM_Provider] prov inner join @parties par on prov.partyid=par.partyportal
        
        declare @adre table (partadreEnroll int, partadreportal int)
        --
        INSERT INTO [KYPEnrollment].[pAccount_PDM_Address] (
                        [AddressLine1],
                        [AddressLine2],
                        [County],
                        [City],
                        [Zip],
                        [ZipPlus4],
                        [State],
                        [Country],
                        [Latitude],
                        [Longitude],
                        [GeographicArea],
                        [LastAction],
                        [LastActionDate],
                        [LastActionUserID],
                        [LastActionApprovedByUsedID],
                        [CurrentRecordFlag],
                        [AdaAccessible],  
                        [TtyCapacity],
                        [TtyNumber],
                        TempAddressID )
            output inserted.AddressID,inserted.TempAddressID into @adre             
            SELECT [AddressLine1],
                   [AddressLine2],
                   [County],
                   [City],
                   [Zip],
                   [ZipPlus4],
                   [State],
                   [Country],
                   [Latitude],
                   [Longitude],
                   [GeographicArea],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1,
                   [AdaAccessible] ,
                   [TtyCapacity],
                   [TtyNumber],
                   addr.addressid
              FROM [KYPPORTAL].[PortalKYP].[pPDM_Address] addr inner join kypportal.portalkyp.ppdm_location loc on addr.addressid=loc.addressid
              inner join @parties par on loc.partyid=par.partyportal
              
            INSERT INTO [KYPEnrollment].[pAccount_PDM_Location] (
                        [AddressID],
                        [PartyID],
                        [Type],
                        [WorkingDays],
                        [WorkingHours],
                        [Phone1],
                        [Phone2],
                        [Fax],
                        [Remarks],
                        [InActive],
                        [Email],
                        [IsLicensed],
                        [IsRented],
                        [Status],
                        [Name],
                        [IsSchoolSide],
                        [IsDonatedSpace],
                        [IsDeleted],
                        [LastAction],
                        [LastActionDate],
                        [LastActorUserID],
                        [LastActionApprovedBy],
                        [CurrentRecordFlag])
            SELECT ad.partadreEnroll,
                   par.partyEnroll,
                   [Type],
                   [WorkingDays],
                   [WorkingHours],
                   [Phone1],
                   [Phone2],
                   [Fax],
                   [Remarks],
                   [InActive],
                   [Email],
                   [IsLicensed],
                   [IsRented],
                   [Status],
                   [Name],
                   [IsSchoolSide],
                   [IsDonatedSpace],
                   [IsDeleted],
                   'C',
                   @date_create,
                   @last_action_user_id,
                   @last_action_user_id,
                   1
                   
              FROM  kypportal.portalkyp.ppdm_location loc  inner join @parties par on loc.partyid=par.partyportal
              inner join @adre ad on loc.AddressID=ad.partadreportal
                   
              update kypenrollment.paccount_pdm_party set TempPartyID =null where PartyID in (select partyenroll from @parties)  
              update kypenrollment.pAccount_PDM_Address set TempAddressID =null where AddressID in (select partadreenroll from @adre)     
	--**
	
	   
	
		
		
	
  END 
ELSE
BEGIN
    EXEC @party_acc_par_id = [KYPEnrollment].[sp_Copy_Party] @app_party_row_id, @party_account_id,@account_id,@last_action_user_id;
	EXEC [KYPEnrollment].[sp_Copy_Organization] @party_acc_par_id,@app_party_row_id,@last_action_user_id; 
	EXEC [KYPEnrollment].[sp_Copy_Provider] @party_acc_par_id,@app_party_row_id,@last_action_user_id; 
	EXEC [KYPEnrollment].[sp_Copy_Address] @party_acc_par_id,@app_party_row_id,NULL,@last_action_user_id;
END
END


GO

