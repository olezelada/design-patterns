
CREATE VIEW [KYP].[v_AlertDetailChild]
AS
SELECT     row_number() OVER (ORDER BY A.ParentAlertID ASC) AS ID, ParentAlertID, ChildAlertID, B.WatchedPartyType,
                          (SELECT     WatchlistName
                            FROM          KYP.MDM_Alert
                            WHERE      AlertID = ParentAlertID) AS 'Parent_WLName', B.WatchlistName AS 'Child_WLName', B.AlertNo AS 'ChildAlertno', B.MatchPercent AS 'ChildMatchpercentage', 
                      B.IsMerged AS 'ChildMerged', B.MatchStatusIndicator AS 'ChildMatchStatus', C.Name AS 'ProvParty_Name', 
                      CASE WHEN C.Type = 'Person' THEN D .Alias1 WHEN C.Type = 'Organization' THEN E.LegalName END AS 'ProvParty_Alias', 
                      CASE WHEN C.Type = 'Organization' THEN CASE WHEN E.TIN IS NOT NULL THEN E.TIN WHEN E.TIN IS NULL THEN
                          /* GET TaxID from HMD if NULL*/ (SELECT DISTINCT STUFF
                                                                                                                                ((SELECT     ',' + (Taxid)
                                                                                                                                    FROM         (SELECT DISTINCT TaxID, PartyID
                                                                                                                                                           FROM          KYP.MDM_PartyDetail) A
                                                                                                                                    WHERE     PartyID = C.PartyID FOR XML PATH('')), 1, 1, '') AS Numbers
                                                                                                     FROM         KYP.MDM_PartyDetail
                                                                                                     WHERE     db_Flag = 'HMS') /* GET TaxID from HMD if NULL*/ END END AS 'ProvParty_TaxID', 
                      CASE WHEN C.Type = 'Organization' THEN CASE WHEN E.TIN IS NULL THEN CASE WHEN
                          (SELECT     COUNT(DISTINCT (TaxID))
                            FROM          KYP.MDM_PartyDetail
                            WHERE      PartyID = C.PartyID AND db_Flag = 'HMS') > 0 THEN 'HMS' ELSE NULL END END END AS 'ProvParty_TIN_Source', 
                      CASE WHEN C.Type = 'Person' THEN D .SSN END AS 'ProvParty_SSN', D .DoB AS 'ProvParty_DOB',
                          /*START: Getting Multiple NPI */ (SELECT DISTINCT STUFF
                                                                                                                            ((SELECT     ',' + CONVERT(VARCHAR(50), NPI)
                                                                                                                                FROM         (SELECT DISTINCT NPI, PartyID
                                                                                                                                                       FROM          KYP.MDM_PartyDetail) A
                                                                                                                                WHERE     PartyID = C.PartyID FOR XML PATH('')), 1, 1, '') AS Numbers
                                                                                                  FROM         KYP.MDM_PartyDetail) AS 'ProvParty_NPI', /*END: Getting Multiple NPI */ F.UPIN,
                          /*START: Getting Multiple Speciality*/ (SELECT DISTINCT STUFF
                                                                                                                                         ((SELECT     ',' + Speciality
                                                                                                                                             FROM         (SELECT DISTINCT Speciality, PartyID
                                                                                                                                                                    FROM          KYP.MDM_PartyDetail WHERE Speciality NOT IN ('Unknown', 'unknown')) A
                                                                                                                                             WHERE     PartyID = C.PartyID FOR XML PATH('')), 1, 1, '') AS Numbers
                                                                                                              FROM         KYP.MDM_PartyDetail) AS 'ProvParty_Speciality',
                          /*START: Getting Multiple Licenses*/ (SELECT DISTINCT STUFF
                                                                                                                                       ((SELECT     ',' + License
                                                                                                                                           FROM         (SELECT DISTINCT License, PartyID
                                                                                                                                                                  FROM          KYP.MDM_PartyDetail) A
                                                                                                                                           WHERE     PartyID = C.PartyID FOR XML PATH('')), 1, 1, '') AS Numbers
                                                                                                            FROM          KYP.MDM_PartyDetail) AS 'ProvParty_Licenses', /*END: Getting Multiple Licenses*/ B.WatchlistName, 
                      /*---------------------------------------------*/ CASE WHEN B.WatchedPartyType = 'Individual' THEN LTRIM(RTRIM(ISNULL(G.LName, ''))) + ' ' + LTRIM(RTRIM(ISNULL(G.FName, ''))) + ' ' + LTRIM(RTRIM(ISNULL(G.MName, ''))) ELSE G.OrganizationName END AS 'MatchParty_Name',
                       G.AliasName AS 'MatchParty_Alias', G.TAXID AS 'MatchParty_TaxID', G.SSN AS 'MatchParty_SSN', G.DOB AS 'MatchParty_DOB', G.NPI AS 'MatchParty_NPI', 
                      G.UPIN AS 'MatchParty_UPIN', G.Speciality AS 'MatchParty_Specialty', G.LicenseNo AS 'MatchParty_License'
/***/ FROM KYP.MDM_RelatedAlerts A INNER JOIN
                      KYP.MDM_Alert B ON B.AlertID = A.ChildAlertID INNER JOIN
                      KYP.PDM_Party C ON C.PartyID = B.WatchedPartyID LEFT OUTER JOIN
                      KYP.PDM_Person D ON D .PartyID = C.PartyID LEFT OUTER JOIN
                      KYP.PDM_Organization E ON E.PartyID = C.PartyID LEFT OUTER JOIN
                      KYP.PDM_Provider F ON F.PartyID = C.PartyID /*ADDED FOR UPIN*/ LEFT OUTER JOIN
                      KYP.MDM_AlertDetail G ON G.AlertID = B.AlertID
/*ADDED FOR Matched Party from Watchlist*/ WHERE A.RelationshipType = 'Merged' AND ISNULL(A.IsDeleted, 0) = 0


GO

