
/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Other Associations Table. For added one other association is only need @last_action_user_id and @targetPath_PartyIdOwned.   
-- PARAMETERS: 
-- @party_account_id : partyID to new Account that will be create. 
-- @party_app_id : partyID Application that will be Account. 
-- @account_id : AccointID that will be create.
-- @last_action_user_id : this is the user Enrollment. 
-- @targetPath_PartyIdOwned : this come to Traking by Update, it is null when create account. 
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Others_Associations]
	@account_party_id_owner INT,
	@party_id_owner INT,
	@account_id INT,
	@last_action_user_id VARCHAR(100),
	@targetPath_PartyIdOwned VARCHAR(200) = NULL
AS
BEGIN
	DECLARE 
	@party_id_owned INT,
	@account_party_id_owned INT,@full_name_person VARCHAR(100),
	@party_owned_type VARCHAR(200)
	
	IF @party_id_owner IS NOT NULL
	BEGIN
		--DECLARE otherAssociationCursor CURSOR FAST_FORWARD READ_ONLY FOR 
		declare @otherassociation table (pk int identity(1,1),PartyID int, Type varchar(50))
		--SELECT IDENTITY(INT,1,1) as pk, PartyID, Type
		--into #otherassociation 
		insert into @otherassociation
		select PartyID, Type
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] 
		WHERE ParentPartyID=@party_id_owner AND (Type = 'OtherOwnershipIndividual' OR Type = 'OtherOwnershipEntity')		
		--OPEN otherAssociationCursor
		--FETCH NEXT FROM otherAssociationCursor INTO @party_id_owned, @party_owned_type
		
		--WHILE @@FETCH_STATUS = 0
		declare @cont int,@tot int
		select @tot =MAX(pk) from @otherassociation 
		set @cont=1
		WHILE @cont<=@tot
		BEGIN
		    select @party_id_owned=partyid, @party_owned_type=TYPE from @otherassociation where pk=@cont
			EXEC @account_party_id_owned = [KYPEnrollment].[sp_Copy_Party] @party_id_owned, @account_party_id_owner,@account_id,@last_action_user_id;
			IF @party_owned_type = 'OtherOwnershipEntity'
				BEGIN
					EXEC [KYPEnrollment].[sp_Copy_Organization] @account_party_id_owned, @party_id_owned, @last_action_user_id;
				END
			ELSE
				BEGIN
					EXEC [KYPEnrollment].[sp_Copy_Person] @account_party_id_owned, @party_id_owned, @last_action_user_id,'C';
				END
			EXEC [KYPEnrollment].[sp_Copy_Address] @account_party_id_owned, @party_id_owned, NULL, @last_action_user_id;
			EXEC [KYPEnrollment].[sp_Copy_Ownership_Relationship] NULL, @account_party_id_owner, @account_party_id_owned, @party_id_owner, @party_id_owned, @last_action_user_id, 'EntityOwnershipAssociation';
		 --FETCH NEXT FROM otherAssociationCursor INTO @party_id_owned, @party_owned_type
		set @cont=@cont+1
		END	
		--drop table #otherassociation 	
		--CLOSE otherAssociationCursor;
		--DEALLOCATE otherAssociationCursor;
	END
	ELSE 
	BEGIN
		SELECT @party_id_owned=PartyID, @party_id_owner=ParentPartyID, @party_owned_type = Type 
		FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] 
		WHERE TargetPath = @targetPath_PartyIdOwned; 
		
		EXEC @account_party_id_owned = [KYPEnrollment].[sp_Copy_Party] @party_id_owned, @account_party_id_owner,@account_id,@last_action_user_id;
		
		IF @party_owned_type = 'OtherOwnershipEntity'
			BEGIN
				EXEC [KYPEnrollment].[sp_Copy_Organization] @account_party_id_owned, @party_id_owned, @last_action_user_id;
			END
		ELSE
			BEGIN
				EXEC [KYPEnrollment].[sp_Copy_Person] @account_party_id_owned, @party_id_owned, @last_action_user_id,'C';
			END
		EXEC [KYPEnrollment].[sp_Copy_Address] @account_party_id_owned, @party_id_owned, NULL, @last_action_user_id;
		EXEC [KYPEnrollment].[sp_Copy_Ownership_Relationship] NULL, @account_party_id_owner, @account_party_id_owned, @party_id_owner, @party_id_owned, @last_action_user_id, 'EntityOwnershipAssociation';
	END
END


GO

