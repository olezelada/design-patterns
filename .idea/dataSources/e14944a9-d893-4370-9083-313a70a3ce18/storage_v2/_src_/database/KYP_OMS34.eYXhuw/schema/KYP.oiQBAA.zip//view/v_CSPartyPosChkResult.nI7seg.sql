




CREATE VIEW [KYP].[v_CSPartyPosChkResult] AS



SELECT * FROM (

/** OIG Watchlist **/


SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'OIG Exclusion' As Field,'HMS' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'OIG Exclusion Check' 
				where C.OIGLEIE = 'T' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** GSA EPLS/SAM Watchlist **/

SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'SAM' As Field,'HMS' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'SAM Check' 
				where C.GSAEPLS = 'T' 
	)X  
)Y WHERE  Y.SortOrder = 1


UNION ALL 

/** DMF **/

SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'SSA DMF' As Field,
					CASE WHEN S.RECORD_IDENTIFIER = 'TR' THEN 'TR'
					ELSE 'HMS' END As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1	
				INNER JOIN KYP.SDM_DBCheckDetail D ON D.DBChkResultID = C.DBChkResultID 
				INNER JOIN KYP.SDM_DMFDeatils S ON S.DBChkDetailID = D.DBChkDetailID OR S.ScreeningID = C.ScreeningID			
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'SSA DMF Check' 
				where C.DMF = 'T' 
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL

/** Medicare and Medicaid **/


SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'MCSIS' As Field,'PECOS' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'MCSIS Check' 
				where C.MCSIS_MR_NPI_STATUS = 'T' OR C.MCSIS_MR_NAME_ADDR_STATUS = 'T' OR C.MCSIS_MD_NPI_STATUS = 'T' OR C.MCSIS_MD_NAME_ADDR_STATUS = 'T' 
	)X  
)Y WHERE  Y.SortOrder = 1


UNION ALL

/** SANDI **/

SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'S&I Watchlist' As Field,'SANDI' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'S&I Watchlist' 
				where C.SANDI_NPI_STATUS = 'T' OR C.SANDI_LICENSE_STATUS = 'T' OR C.SANDI_ADDRESS_STATUS = 'T'
	)X  
)Y WHERE  Y.SortOrder = 1

UNION ALL
/** KYPWatchlist **/

SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'KYP Watchlist' As Field,'HMS' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'KYPWatchList Check' 
				where C.IW_NPI_STATUS = 'T' OR C.IW_LICENSE_STATUS = 'T' OR C.IW_NAME_ADDRESS_STATUS = 'T' 
	)X  
)Y WHERE  Y.SortOrder = 1
UNION ALL
/** Court Check **/

SELECT Y.Field,Y.DBSource,Y.Comments,Y.ApplicationID,Y.PartyID  FROM(
	SELECT X.*,ROW_NUMBER() OVER(PARTITION BY [ScreeningID] ORDER BY [DateCreated]) As SortOrder  FROM(
				SELECT  DISTINCT
					'Court Cases' As Field,'TR' As DBSource,
					COALESCE(F.Author,'') + ' create finding# '+ CONVERT(VARCHAR,F.NoteID) As Comments,
					CONVERT(VARCHAR,ApplicationID) As ApplicationID,CONVERT(VARCHAR,P.PartyID) As PartyID,
					CONVERT(VARCHAR,P.ScreeningID) As ScreeningID ,F.RelatedEntityID,F.DateCreated    
				FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1				
				LEFT JOIN KYP.view_FindingDates F ON F.RelatedEntityID = P.PartyID AND F.RelatedEntityType IN ('SDM_ApplicationParty','PDM_Provider','ADM_App_Provider') 
				AND (F.Deleted IS NULL OR F.Deleted = 'false') AND F.Tags = 'Court Check' 
				where C.CourtCheck = 'T'
	)X  
)Y WHERE  Y.SortOrder = 1


)X


GO

