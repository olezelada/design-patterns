

/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: create Number license Twin.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- @licenseType : this is the LicenseType.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Twin_NumberFromLicense]
   @party_account_id       INT,
   @party_app_id           INT,
   @last_action_user_id    VARCHAR (100),
   @licenseType            VARCHAR (100)
AS
BEGIN
   SET  NOCOUNT ON
   DECLARE
      @numberId         INT,
      @date_created   DATE;
   SET @date_created = GETDATE ();

   INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
           ([PartyID]
           ,[Type]
           ,[CreatedBy]
           ,[DateCreated]
           ,[IsDeleted]
           ,[Number]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag])
 SELECT    @party_account_id
           ,[LicenseType]
           ,[CreatedBy]
           ,@date_created
           ,[IsDeleted]
           ,[LicenseCode]
           ,'C'
           ,@date_created
           ,@last_action_user_id
           ,@last_action_user_id
           ,1

 FROM [KYPPORTAL].[PortalKYP].[pPDM_License] WHERE PartyID=@party_app_id AND LicenseType = @licenseType

   SELECT @numberId = SCOPE_IDENTITY ();
   RETURN @numberId
END


GO

