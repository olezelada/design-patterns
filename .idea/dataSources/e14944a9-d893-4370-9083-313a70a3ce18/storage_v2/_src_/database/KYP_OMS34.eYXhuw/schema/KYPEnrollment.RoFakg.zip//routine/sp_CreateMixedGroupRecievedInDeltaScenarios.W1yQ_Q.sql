CREATE PROCEDURE [KYPEnrollment].[sp_CreateMixedGroupRecievedInDeltaScenarios] @FileId SMALLDATETIME
AS

BEGIN

	BEGIN TRY
	-- BEGIN TRAN

		DECLARE @ScenariosRecordCount	INT;

		DECLARE @NewCHOWAccountNumberUpdated TABLE
		(
			AccountID		INT NULL,
			AccountNumber	VARCHAR(20) NULL
		)
/*
		DECLARE @AppendOwnerNoToPreviousMG TABLE
		(
			AccountID			INT NULL,
			OldAccountNumber	VARCHAR(20) NULL,
			NewAccountNumber	VARCHAR(20) NULL
		)
*/
		DECLARE @AccountNumberHistory TABLE
		(
			AccountID			INT,
			OldAccountNumber	VARCHAR(24),
			NewAccountNumber	VARCHAR(24)
		)

		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_PossibleMMISSubGroupsOfMixedGroup_Delta]') AND type in (N'U'))
		drop table temp_PossibleMMISSubGroupsOfMixedGroup_Delta

		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay]') AND type in (N'U'))
		drop table temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay

		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_MGDeltaScenario1]') AND type in (N'U'))
		drop table temp_MGDeltaScenario1


		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_MGDeltaScenario2]') AND type in (N'U'))
		drop table temp_MGDeltaScenario2


		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_StageSubGroups_ForComp_MGMapping]') AND type in (N'U'))
		drop table temp_StageSubGroups_ForComp_MGMapping


		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StageTableToLoopThroughMixedGroup]') AND type in (N'U'))
		drop table StageTableToLoopThroughMixedGroup

		IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[StageTableToLoopThroughMixedGroup]') AND type in (N'U'))
		CREATE TABLE StageTableToLoopThroughMixedGroup(
			[ID] [int] IDENTITY(1,1) NOT NULL,	
			[MixedGroupClubbingID] [varchar](18) NOT NULL,	
			[MixGroupLegalName] [varchar](150) NULL,
			[MixGroupPracticeAddress] [varchar](250) NULL	
		) ON [PRIMARY]

		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_MGDeltaScenario3]') AND type in (N'U'))
		drop table temp_MGDeltaScenario3

		IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_MGDeltaScenario4]') AND type in (N'U'))
		drop table temp_MGDeltaScenario4


		DELETE FROM KYPEnrollment.MixedGroupHistory
		--==================> First add any MG created from Portal on MG table<<======

		MERGE [KYPEnrollment].[pAccount_MixGroupOnly_Entities]  trgt
		USING 
		(
		select * from 
		KYPEnrollment.pADM_Account A
		where IsDeleted=0 and ProviderTypeCode='100'
		and StatusAcc <>'7 - Active Rendering (indirect)'
		and LegacyAccountNo IS NULL AND ServiceLocationNo IS NOT NULL AND OwnerNo IS NOT NULL

		)src ON (
		trgt.GroupNPI=src.NPI 
		and trgt.GroupOwnerNo=src.OwnerNo 
		and trgt.GroupServiceLocationNo=src.ServiceLocationNo
		and trgt.MGaccountid=src.AccountID
		)
		WHEN NOT MATCHED THEN 
		INSERT 
				   ([GroupNPI]
				   ,[GroupServiceLocationNo]
				   ,[GroupOwnerNo]
				   ,[GroupClubbingID]
				   ,[MGAccountID]
				   ,[MGPartyID]
				   ,[MGAccountNo]
				   ,[MGLegalName]
				   ,[MGProviderTypeCode]
				   ,[MGProviderDescription]
				   ,[MGAccountType]
				   ,[MGPackageName]
				   ,[MGPracticeAddress]
				   ,[DateCreated]
				   ,[IsDeleted])
		 VALUES (
		 src.NPI
		 ,src.ServiceLocationNo
		 ,src.OwnerNo
		 ,src.NPI + '_' + src.ServiceLocationNo + '_' + src.OwnerNo
		 ,src.AccountID
		 ,src.PartyID
		 ,src.AccountNumber
		 ,src.LegalName
		 ,src.ProviderTypeCode
		 ,src.ProviderType
		 ,src.AccountType
		 ,src.PackageName 
		 ,src.PracticeAddress
		 ,getdate()
		 ,0 
		 )
		;

		--==================>>Try to get all candidates for Mixed Group<<======

		select  NPI,ServiceLocationNo, ownerno, COUNT(*) as ttl
		into temp_PossibleMMISSubGroupsOfMixedGroup_Delta
		from KYPEnrollment.pADM_Account A
		where IsDeleted=0 and ProviderTypeCode<>'100'
		and StatusAcc <>'7 - Active Rendering (indirect)'
		--and LegacyAccountNo is not null
		and exists (
		select 1 from 
		KYPEnrollment.pAccount_RenderingAffiliation B
		where B.AccountID=A.AccountID
		)
		and ProviderTypeCode  in (
		'003',
		'005',
		'006',
		'010',
		'012',
		'013',
		'018',
		'019',
		'021',
		'022',
		'023',
		'025',
		'027',
		'029',
		'031',
		'032',
		'037',
		'062',
		'071',
		'078',
		'104')
		group by NPI,ServiceLocationNo, ownerno
		having COUNT(*)>1

		UNION

		select  NPI,ServiceLocationNo, ownerno, 0 as ttl
		from KYPEnrollment.pADM_Account A
		where IsDeleted = 0 and ProviderTypeCode = '100'
		and StatusAcc <>'7 - Active Rendering (indirect)'
		and LegacyAccountNo is null


		--==================>>Get Delta Run's Accounts against overall Mixed Group into a table<<======

		select distinct A.NPI, A.ServiceLocationNo, A.OwnerNo, B.[ProviderTypeCode],B.[LegalName],[PracticeAddress],NULL AS MGScenario,CAST('' AS VARCHAR(160)) AS MGScenarioDescription,IsCHOW
			into temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
			from temp_PossibleMMISSubGroupsOfMixedGroup_Delta A
			join [KYPEnrollment].[DatewiseDeltaLoadedAccounts] B
			on A.NPI=B.NPI
			and A.ServiceLocationNo=B.ServiceLocationNo
			and A.OwnerNo = B.OwnerNo
			where FileId=@FileId AND -----=====>>>>>>>>--calling FileID parameter of sp
				  ProviderTypeCode != '100' -- Mixed Group received from Delta
			order by A.NPI, A.ServiceLocationNo, A.OwnerNo, B.[ProviderTypeCode]


		--==================>>Scenario 1: Portal initiated MG's subgroups are recieved from MMIS<<======
		--There are 2 characterstics of such a situation
		--a. Mixed Group Account Exists in [pAccount_MixGroupOnly_Entities] table
		--b. No record in [pAccount_SubGroupOnly_Entities] table

		--In this case, there are basically 3 steps needed to be applied on MG account:
		--a. Change the account number of subgroups
		--b. Flag them out of Portal through IsPastOwner
		--c. Populate temp_StageSubGroups_ForComp_MGMapping of OneTime MG Creation for Scenario1 accounts
		--d. Populate StageTableToLoopThroughMixedGroup for looping through such Scenario 1 accounts
		--e. Calling the one time MG sp
		--f. Insert these SubAccounts in  pAccount_SubGroupOnly_Entities table

		SELECT * 
			INTO temp_MGDeltaScenario1
			FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay A
			WHERE EXISTS (SELECT 1 
							FROM [KYPEnrollment].[pAccount_MixGroupOnly_Entities] B
							WHERE	B.[GroupNPI]				= A.NPI AND
									B.[GroupServiceLocationNo]	= A.ServiceLocationNo AND
									B.[GroupOwnerNo]			= A.OwnerNo AND
									B.IsDeleted					= 0) AND
				  NOT EXISTS (SELECT 1 
								FROM [KYPEnrollment].[pAccount_SubGroupOnly_Entities] D
								where	D.[GroupNPI]				= A.NPI AND
										D.[GroupServiceLocationNo]	= A.ServiceLocationNo AND
										D.[GroupOwnerNo]			= A.OwnerNo AND
										-- AND D.[SGProviderTypeCode] = A.ProviderTypeCode
										D.IsDeleted					= 0) AND
				  MGScenario IS NULL;

		SELECT @ScenariosRecordCount = COUNT(1)
			FROM temp_MGDeltaScenario1;

		IF @ScenariosRecordCount > 0

		BEGIN
/* -- Comment Starts - Commented by Anshu on April 30, 2018 as Account Number gets update in called Stored Procedure for Scenario 1
			;
			DISABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
		/*
			DISABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	DISABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;


			UPDATE A 
				SET A.AccountNumber	= C.AccountNumber + '-' + A.ProviderTypeCode,
					A.IsPastOwner	= 1,
					A.LastActionDate = GETDATE()
				OUTPUT INSERTED.AccountID,DELETED.AccountNumber,INSERTED.AccountNumber
				INTO @AccountNumberHistory
				FROM KYPEnrollment.pADM_Account A
				JOIN temp_MGDeltaScenario1 B
				ON	A.NPI				= B.NPI AND
					A.ServiceLocationNo = B.ServiceLocationNo AND
					A.OwnerNo			= B.OwnerNo AND
					A.ProviderTypeCode	= B.ProviderTypeCode AND
					A.IsDeleted			= 0
				JOIN (SELECT * FROM 
						KYPEnrollment.pADM_Account
						WHERE IsDeleted			= 0 AND
							  ProviderTypeCode	= '100' AND
							  StatusAcc			<> '7 - Active Rendering (indirect)')C
				ON	C.NPI				= B.NPI AND
					C.ServiceLocationNo = B.ServiceLocationNo AND
					C.OwnerNo			= B.OwnerNo AND
					C.IsDeleted			= 0

			INSERT INTO KYPEnrollment.MixedGroupHistory(AccountID,GroupName,[Action],Attribute,OldValue,NewValue,IsFlag)
				SELECT AccountID,'Mixed Group Created','UPD','Account Number',OldAccountNumber,NewAccountNumber,0
					FROM @AccountNumberHistory

			UPDATE D 
				SET D.AccountNumber = C.AccountNumber + '-' + A.ProviderTypeCode
				FROM KYPEnrollment.pADM_Account A
				JOIN temp_MGDeltaScenario1 B
				ON	A.NPI				= B.NPI AND
					A.ServiceLocationNo = B.ServiceLocationNo AND
					A.OwnerNo			= B.OwnerNo AND
					A.ProviderTypeCode	= B.ProviderTypeCode AND
					A.IsDeleted			= 0
				JOIN (SELECT * FROM 
						KYPEnrollment.pADM_Account
						where IsDeleted			= 0 AND
							  ProviderTypeCode	= '100' AND
							  StatusAcc			<>'7 - Active Rendering (indirect)')C
				ON	C.NPI				= B.NPI AND
					C.ServiceLocationNo = B.ServiceLocationNo AND
					C.OwnerNo			= B.OwnerNo AND
					C.IsDeleted			= 0
				JOIN KYPEnrollment.AccountSearch D
				ON A.AccountID			= D.AccountID

			UPDATE D 
				SET D.AccountNumber	= C.AccountNumber + '-' + A.ProviderTypeCode
				FROM KYPEnrollment.pADM_Account A
				JOIN temp_MGDeltaScenario1 B
				ON	A.NPI				= B.NPI AND
					A.ServiceLocationNo = B.ServiceLocationNo AND
					A.OwnerNo			= B.OwnerNo AND
					A.ProviderTypeCode	= B.ProviderTypeCode AND
					A.IsDeleted			= 0
				JOIN (SELECT *
						FROM KYPEnrollment.pADM_Account
						WHERE IsDeleted			= 0 AND
							  ProviderTypeCode	= '100' AND
							  StatusAcc			<>'7 - Active Rendering (indirect)')C
				ON	C.NPI				= B.NPI AND
					C.ServiceLocationNo = B.ServiceLocationNo AND
					C.OwnerNo			= B.OwnerNo AND
					C.IsDeleted			= 0
				JOIN KYPEnrollment.pAccount_BizProfile_Details D
				on A.AccountID			= D.AccountID;
			
			ENABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
		/*
			ENABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	ENABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;
*/ -- Comment Ends here

			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_StageSubGroups_ForComp_MGMapping]') AND type in (N'U'))
				DROP TABLE temp_StageSubGroups_ForComp_MGMapping

			select	X.NPI as SubGroupNPI,
					X.ServiceLocationNo as SubGroupServiceLocationNo, 
					X.OwnerNo as SubGroupOwnerNo, 
					X.NPI + '_' + X.ServiceLocationNo + '_' + X.OwnerNo as MixedGroupClubbingID,
					X.IsCHOW AS IsCHOW,
					Y.AccountID as SubGroupAccountID,
					Y.PartyID as SubGroupPartyID,
					Y.AccountNumber as SubGroupAccountNumber,
					Y.LegalName as SubGroupLegalName,
					Y.ProviderTypeCode as SubGroupProviderTypeCode,
					Y.ProviderType as SubGroupProviderDescription,
					Y.AccountType as SubGroupAccountType,
					Y.PackageName as SubGroupPackageName,
					Y.PracticeAddress as SubGroupPracticeAddress,
					CAST('' AS VARCHAR(20)) AS PreviousOwnershipMGAccountNumber
				into temp_StageSubGroups_ForComp_MGMapping 
				from temp_MGDeltaScenario1 X
/*				join (select * from KYPEnrollment.pADM_Account A
						where IsDeleted=0 and ProviderTypeCode<>'100'
						and StatusAcc <>'7 - Active Rendering (indirect)'
						--and LegacyAccountNo is not null
						and exists (select 1 from 
										KYPEnrollment.pAccount_RenderingAffiliation B
										where B.AccountID=A.AccountID)
						and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
												  '023','025','027','029','031','032','037','062','071','078','104')
					  ) Y
				on X.NPI=Y.NPI
				and X.ServiceLocationNo=Y.ServiceLocationNo
				and X.OwnerNo=Y.OwnerNo
				and X.ProviderTypeCode = Y.ProviderTypeCode
				order by MixedGroupClubbingID,X.NPI, X.ServiceLocationNo
*/
				JOIN KYPEnrollment.pADM_Account Y
				ON X.NPI=Y.NPI
				AND X.ServiceLocationNo=Y.ServiceLocationNo
				AND X.OwnerNo=Y.OwnerNo
				-- AND X.ProviderTypeCode = Y.ProviderTypeCode
				WHERE IsDeleted=0 and Y.ProviderTypeCode<>'100'
						AND StatusAcc <>'7 - Active Rendering (indirect)'
						--and LegacyAccountNo is not null
						AND EXISTS (SELECT 1 FROM 
										KYPEnrollment.pAccount_RenderingAffiliation B
										WHERE B.AccountID=Y.AccountID)
						AND Y.ProviderTypeCode IN ('003','005','006','010','012','013','018','019','021','022',
												   '023','025','027','029','031','032','037','062','071','078','104')

			truncate table StageTableToLoopThroughMixedGroup

			insert into StageTableToLoopThroughMixedGroup (MixedGroupClubbingID /*, MixGroupLegalName, MixGroupPracticeAddress*/ )
				select distinct  MixedGroupClubbingID -- , SubGroupLegalName as MixGroupLegalName, SubGroupPracticeAddress as MixGroupPracticeAddress
					from temp_StageSubGroups_ForComp_MGMapping
					order by MixedGroupClubbingID
			-- Calling below SP as new MOCA/Rendering may come with new Subgroups
			exec KYPEnrollment.sp_CreateMixedGroupAffiliationMOCATranspositionForMMIS @Scenario = 1
			
			-- Now Populate pAccount_SubGroupOnly_Entities table for SubGroups received from MMIS

			MERGE [KYPEnrollment].[pAccount_SubGroupOnly_Entities]  trgt
			USING 
			(
			select distinct 
					[GroupNPI]
				  ,[GroupServiceLocationNo]
				  ,[GroupOwnerNo]
				  ,[GroupClubbingID]
				  ,[MGAccountID]
				  ,[MGPartyID]
				  ,[MGAccountNo]
				  ,[MGLegalName]
				  ,[MGPracticeAddress]
				  ,B.ProviderTypeCode
				  ,B.ProviderType
				  ,B.AccountType
				  ,B.PackageName
				  ,B.AccountID
				  ,B.PartyID
				  ,B.AccountNumber
				  ,B.[DateCreated]
				  ,B.[IsDeleted]
			from [KYPEnrollment].[pAccount_MixGroupOnly_Entities] A
			join KYPEnrollment.pADM_Account B
			on A.GroupNPI=B.NPI
			and A.GroupServiceLocationNo=B.ServiceLocationNo
			and A.GroupOwnerNo = B.OwnerNo
			and B.IsDeleted=0
			and exists (select 1 from 
										KYPEnrollment.pAccount_RenderingAffiliation R
										where R.AccountID=B.AccountID)
			and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
									  '023','025','027','029','031','032','037','062','071','078','104')
			join temp_MGDeltaScenario1 C
			on B.NPI=C.NPI
			and B.ServiceLocationNo = C.ServiceLocationNo
			and B.OwnerNo = C.OwnerNo
			and B.ProviderTypeCode = C.ProviderTypeCode

			where 
			B.ProviderTypeCode<>'100'
			and StatusAcc <>'7 - Active Rendering (indirect)'

			)src ON (
			trgt.GroupNPI=src.GroupNPI 
			and trgt.GroupOwnerNo=src.GroupOwnerNo 
			and trgt.GroupServiceLocationNo=src.GroupServiceLocationNo
			and trgt.[SGProviderTypeCode]=src.ProviderTypeCode

			)
			WHEN NOT MATCHED THEN 
			INSERT 
					   ([GroupNPI]
					   ,[GroupServiceLocationNo]
					   ,[GroupOwnerNo]
					   ,[GroupClubbingID]
					   ,[MGAccountID]
					   ,[MGPartyID]
					   ,[MGAccountNo]
					   ,[MGLegalName]
					   ,[MGPracticeAddress]
					   ,[SGProviderTypeCode]
					   ,[SGProviderDescription]
					   ,[SGAccountType]
					   ,[SGPackageName]
					   ,[SGAccountID]
					   ,[SGPartyID]
					   ,[SGAccountNo]
					   ,[DateCreated]
					   ,[IsDeleted]
					   )
			 VALUES (
			 
			 src.[GroupNPI]
				  ,src.[GroupServiceLocationNo]
				  ,src.[GroupOwnerNo]
				  ,src.[GroupClubbingID]
				  ,src.[MGAccountID]
				  ,src.[MGPartyID]
				  ,src.[MGAccountNo]
				  ,src.[MGLegalName]
				  ,src.[MGPracticeAddress]
				  ,src.ProviderTypeCode
				  ,src.ProviderType
				  ,src.AccountType
				  ,src.PackageName
				  ,src.AccountID
				  ,src.PartyID
				  ,src.AccountNumber
				  ,getdate()
				  ,0
			 
			 )
			;
			
			UPDATE temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
				SET MGScenario = 1,
					MGScenarioDescription = 'MG Sub group(s) created'
				FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay Temp
				JOIN temp_MGDeltaScenario1 B
				ON 	Temp.NPI=B.NPI AND
					Temp.ServiceLocationNo = B.ServiceLocationNo and 
					Temp.OwnerNo = B.OwnerNo and 
					Temp.ProviderTypeCode = B.ProviderTypeCode;
			
			DELETE FROM @AccountNumberHistory
			
			Print 'Mixed Group Scenario 1'

		END
		 
		--==================>>Scenario 2: Upgradation of single group to Mix Group from MMIS<<======
		--There are 2 characterstics of such a situation
		--a. No Mixed Group Account Exists in [pAccount_MixGroupOnly_Entities] table
		--b. No record in [pAccount_SubGroupOnly_Entities] table

		--In this case, there are basically 5 steps (but basically one point ie to create a mixed group from the scratch)
		--needed to be applied on MG account:
		--a. Populate temp_StageSubGroups_ForComp_MGMapping of OneTime MG Creation for Scenario2 accounts
		--b. Populate StageTableToLoopThroughMixedGroup for looping through such Scenario 1 accounts
		--c. Calling the one time MG sp
		--d. Populate pAccount_MixGroupOnly_Entities
		--e. Populate pAccount_SubGroupOnly_Entities

		SELECT * 
			INTO temp_MGDeltaScenario2
			FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay A
			WHERE NOT EXISTS (SELECT 1 
								FROM [KYPEnrollment].[pAccount_MixGroupOnly_Entities] B
								WHERE	B.[GroupNPI]				= A.NPI AND
										B.[GroupServiceLocationNo]	= A.ServiceLocationNo AND
										B.[GroupOwnerNo]			= A.OwnerNo AND
										B.IsDeleted					= 0) AND
				  NOT EXISTS (SELECT 1 
								FROM [KYPEnrollment].[pAccount_SubGroupOnly_Entities] D
								WHERE D.[GroupNPI]					= A.NPI AND
									  D.[GroupServiceLocationNo]	= A.ServiceLocationNo AND
									  D.[GroupOwnerNo]				= A.OwnerNo
									  -- AND D.[SGProviderTypeCode] = A.ProviderTypeCode
								AND D.isDeleted=0) AND
				  MGScenario IS NULL

		SELECT @ScenariosRecordCount = COUNT(1)
			FROM temp_MGDeltaScenario2;

		IF @ScenariosRecordCount > 0

		BEGIN

			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_StageSubGroups_ForComp_MGMapping]') AND type in (N'U'))
				DROP TABLE temp_StageSubGroups_ForComp_MGMapping

			--Step a 
			SELECT	X.NPI AS SubGroupNPI,
					X.ServiceLocationNo AS SubGroupServiceLocationNo, 
					X.OwnerNo AS SubGroupOwnerNo, 
					X.NPI + '_' + X.ServiceLocationNo + '_' + X.OwnerNo AS MixedGroupClubbingID,
					X.IsCHOW AS IsCHOW,
					Y.AccountID AS SubGroupAccountID,
					Y.PartyID AS SubGroupPartyID,
					Y.AccountNumber AS SubGroupAccountNumber,
					Y.LegalName AS SubGroupLegalName,
					Y.ProviderTypeCode AS SubGroupProviderTypeCode,
					Y.ProviderType AS SubGroupProviderDescription,
					Y.AccountType AS SubGroupAccountType,
					Y.PackageName AS SubGroupPackageName,
					Y.PracticeAddress AS SubGroupPracticeAddress,
					CAST('' AS VARCHAR(20)) AS PreviousOwnershipMGAccountNumber
				INTO temp_StageSubGroups_ForComp_MGMapping 
				FROM temp_MGDeltaScenario2 X
/*				JOIN (SELECT * FROM KYPEnrollment.pADM_Account A
						WHERE	IsDeleted		 = 0 AND
								ProviderTypeCode <> '100' AND
								StatusAcc		 <> '7 - Active Rendering (indirect)'
						-- AND LegacyAccountNo IS NOT NULL
						and exists (select 1 from 
										KYPEnrollment.pAccount_RenderingAffiliation B
										where B.AccountID=A.AccountID)
						and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
												  '023','025','027','029','031','032','037','062','071','078','104')
						) Y
				ON	X.NPI = Y.NPI AND
					X.ServiceLocationNo = Y.ServiceLocationNo and
					X.OwnerNo = Y.OwnerNo
				-- and X.ProviderTypeCode = Y.ProviderTypeCode
				ORDER BY MixedGroupClubbingID,X.NPI, X.ServiceLocationNo*/
				JOIN KYPEnrollment.pADM_Account Y
				ON X.NPI=Y.NPI
				AND X.ServiceLocationNo=Y.ServiceLocationNo
				AND X.OwnerNo=Y.OwnerNo
				-- AND X.ProviderTypeCode = Y.ProviderTypeCode
				WHERE IsDeleted=0 and Y.ProviderTypeCode<>'100'
						AND StatusAcc <>'7 - Active Rendering (indirect)'
						--and LegacyAccountNo is not null
						AND EXISTS (SELECT 1 FROM 
										KYPEnrollment.pAccount_RenderingAffiliation B
										WHERE B.AccountID=Y.AccountID)
						AND Y.ProviderTypeCode IN ('003','005','006','010','012','013','018','019','021','022',
												   '023','025','027','029','031','032','037','062','071','078','104')

			--Step b
			TRUNCATE TABLE StageTableToLoopThroughMixedGroup
			
			INSERT INTO StageTableToLoopThroughMixedGroup (MixedGroupClubbingID /*, MixGroupLegalName, MixGroupPracticeAddress*/ )
				SELECT DISTINCT MixedGroupClubbingID -- , SubGroupLegalName as MixGroupLegalName, SubGroupPracticeAddress as MixGroupPracticeAddress
					FROM temp_StageSubGroups_ForComp_MGMapping
					ORDER BY MixedGroupClubbingID
/* Comment starts here - Commented by Anshu on April 30, 2018 as CHOW Account Number changing logic has been removed from 3.0
			-- In below statement, we are updating PreviousOwnershipMGAccountNumber field which is useful to check whether the Previous Ownership is exist for Mixed Group. If it is exist then will take the same Account Number else MG creation logic Account Number('7' + RIGHT(SubGroupAccountNumber,8))
			UPDATE temp_StageSubGroups_ForComp_MGMapping
				SET PreviousOwnershipMGAccountNumber = Temp1.AccountNumber
				FROM temp_StageSubGroups_ForComp_MGMapping Temp
				JOIN (SELECT SUBSTRING(AccountNumber,1,9) AS AccountNumber,ACC.NPI,ACC.ServiceLocationNo,ACC.OwnerNo
						FROM(SELECT DISTINCT SubGroupNPI,SubGroupServiceLocationNo,SubGroupOwnerNo-1 AS ownerno -- temp_StageSubGroups_ForComp_MGMapping won't contain Old CHOW as temp_MGDeltaScenario2 table eliminating those records which are already part of MG
								FROM temp_StageSubGroups_ForComp_MGMapping
								WHERE IsCHOW = 1) Temp
						JOIN (SELECT NPI,Servicelocationno,OwnerNo,AccountNumber
								FROM KYPEnrollment.pADM_Account
								WHERE ProviderTypeCode = '100') ACC
						ON	Temp.SubGroupNPI				= ACC.NPI AND
							Temp.SubGroupServiceLocationNo	= ACC.ServiceLocationNo AND
							Temp.OwnerNo					= ACC.OwnerNo) Temp1
				ON Temp.SubGroupNPI					= Temp1.NPI AND
				   Temp.SubGroupServiceLocationNo	= Temp1.ServiceLocationNo

			-- We have created below temporary table, temp_StageSubGroups_ForComp_MGMapping won't contain Old CHOW as temp_MGDeltaScenario2 table eliminating those records which are already part of MG
			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_UpdateAccountForNewCHOW]') AND type in (N'U'))
				DROP TABLE temp_UpdateAccountForNewCHOW

			SELECT DISTINCT DL.AccountID,DL.AccountNumber,DL.NPI,DL.ServiceLocationNo,DL.OwnerNo,DL.ProviderTypeCode,DL.IsCHOW
				INTO temp_UpdateAccountForNewCHOW
				FROM (SELECT *
						FROM temp_StageSubGroups_ForComp_MGMapping
						WHERE IsCHOW = 1) Temp
				INNER JOIN KYPenrollment.DatewiseDeltaLoadedAccounts DL
				ON	Temp.SubGroupNPI				= DL.NPI AND
					Temp.SubGroupServiceLocationNo	= DL.ServiceLocationNo
				WHERE FileId						= @FileId AND
					  DL.IsCHOW 					= 1;
					  
			DISABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
		/*
			DISABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	DISABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;

		-- We are updating the Account number of previous ownership to the new ownership as Delta load won't change the Account number of additional Sub groups. Delta load will change the Account number of existing Sub groups only.
			UPDATE KYPEnrollment.pADM_Account
				SET AccountNumber	= PreviousCHOW.AccountNumber
				OUTPUT INSERTED.AccountID,DELETED.AccountNumber
					INTO @NewCHOWAccountNumberUpdated
				FROM KYPEnrollment.pADM_Account ACNT
				JOIN(SELECT NPI,ServiceLocationNo,MAX(OwnerNo) AS OwnerNo
						FROM temp_UpdateAccountForNewCHOW
						GROUP BY NPI,ServiceLocationNo) NewCHOW
				ON	ACNT.NPI				= NewCHOW.NPI AND
					ACNT.ServiceLocationNo	= NewCHOW.ServiceLocationNo AND
					ACNT.OwnerNo			= NewCHOW.OwnerNo
				LEFT OUTER JOIN(SELECT SUBSTRING(AccountNumber,1,9) AS AccountNumber,NPI,ServiceLocationNo 
									FROM(SELECT AccountID,AccountNumber,NPI,ServiceLocationNo,OwnerNo,ROW_NUMBER() OVER (PARTITION BY NPI,ServiceLocationNo ORDER BY OwnerNo) RankOwnerNo
											FROM (SELECT MAX(AccountID) AS AccountID,MAX(AccountNumber) AS AccountNumber,NPI,ServiceLocationNo,OwnerNo
													FROM (SELECT AccountID,AccountNumber,NPI,ServiceLocationNo,ProviderTypeCode,OwnerNo,RankOwnerNo
															FROM(SELECT AccountID,AccountNumber,NPI,ServiceLocationNo,ProviderTypeCode,OwnerNo,
																		ROW_NUMBER() OVER (PARTITION BY NPI,ServiceLocationNo,ProviderTypeCode ORDER BY OwnerNo) RankOwnerNo
																	FROM temp_UpdateAccountForNewCHOW) RankToOwnerNo
															WHERE RankToOwnerNo.RankOwnerNo = 1) GroupRankOwnerNo
													GROUP BY NPI,ServiceLocationNo,OwnerNo) RankOwnerNoAgain) ILV
									WHERE ILV.RankOwnerNo = 1) PreviousCHOW
				ON	ACNT.NPI				= PreviousCHOW.NPI AND
					ACNT.ServiceLocationNo	= PreviousCHOW.ServiceLocationNo;
			
			ENABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
		/*
			ENABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	ENABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;

		-- Will update the latest Account Number to temporary table also, so that, It will append the Provider type code to the latest Account Number in calling SP.
			UPDATE temp_StageSubGroups_ForComp_MGMapping
				SET SubGroupAccountNumber = ACNT.AccountNumber
				FROM temp_StageSubGroups_ForComp_MGMapping Temp
				JOIN @NewCHOWAccountNumberUpdated Temp1
				ON Temp.SubGroupAccountID	= Temp1.AccountID
				JOIN KYPEnrollment.pADM_Account ACNT
				ON Temp.SubGroupAccountID	= ACNT.AccountID
*/ -- Comment ends here

			--step c
			EXEC KYPEnrollment.sp_CreateMixedGroupAccountsForMMIS;
/* Comment starts here - Again for CHOW scenario

			DISABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
		/*
			DISABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			DISABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	DISABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;

			-- Below statement will append the OwnerNo to the previous Mixed Group
			UPDATE KYPEnrollment.pADM_Account
				SET AccountNumber	= AccountNumber + '-' + ACNT.OwnerNo,
					IsPastOwner		= 1,
					LastActionDate = GETDATE()
				OUTPUT INSERTED.AccountID,DELETED.AccountNumber,INSERTED.AccountNumber
					INTO @AppendOwnerNoToPreviousMG
				FROM KYPEnrollment.pADM_Account ACNT
				JOIN (SELECT NPI,ServiceLocationNo,MIN(OwnerNo) AS OwnerNo
						FROM temp_UpdateAccountForNewCHOW
						WHERE IsCHOW = 1
						GROUP BY NPI,ServiceLocationNo) PreviousCHOW
				ON	ACNT.NPI				= PreviousCHOW.NPI AND
					ACNT.ServiceLocationNo	= PreviousCHOW.ServiceLocationNo AND
					ACNT.OwnerNo			= PreviousCHOW.OwnerNo
				WHERE ACNT.ProviderTypeCode = '100' AND
					  ACNT.LegacyAccountNo	IS NOT NULL
			
			-- Mixed Group CHOW Account History
			INSERT INTO KYPEnrollment.MixedGroupHistory(AccountID,GroupName,[Action],Attribute,OldValue,NewValue,IsFlag)
				SELECT AccountID,'Mixed Group CHOW','UPD','Account Number',OldAccountNumber,NewAccountNumber,0
					FROM @AppendOwnerNoToPreviousMG

			-- Update the Mixed Group Account Number in Account Search table
			UPDATE KYPEnrollment.AccountSearch
				SET AccountNumber = Temp.OldAccountNumber + '-' + ACC.OwnerNo
				FROM KYPEnrollment.AccountSearch ASR
				JOIN @AppendOwnerNoToPreviousMG Temp
				ON ASR.AccountID	= Temp.AccountID
				JOIN KYPEnrollment.pADM_Account ACC
				ON ASR.AccountID	= ACC.AccountID
			
			-- Update the Mixed Group Account Number in Biz Profile table
			UPDATE KYPEnrollment.pAccount_BizProfile_Details
				SET AccountNumber = Temp.NewAccountNumber + '-' + ACC.OwnerNo
				FROM KYPEnrollment.pAccount_BizProfile_Details BPD
				JOIN @AppendOwnerNoToPreviousMG Temp
				ON BPD.AccountID	= Temp.AccountID
				JOIN KYPEnrollment.pADM_Account ACC
				ON BPD.AccountID	= ACC.AccountID;

			ENABLE TRIGGER ALL ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER ALL ON [KYPEnrollment].[AccountSearch];
*/ -- Comment ends here
/*
			ENABLE TRIGGER AccountHistory_MadeChange_Account  ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER AffectedPortalActive ON [KYPEnrollment].[pADM_Account];
			ENABLE TRIGGER pADM_Account_AccStatus_tr ON [KYPEnrollment].[pADM_Account];
		*/
		--	ENABLE TRIGGER AccountsSearch on KYPEnrollment.AccountSearch;

			UPDATE temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
				SET MGScenario = 2,
					MGScenarioDescription = 'MG & Sub group(s) created'
				FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay Temp
				JOIN temp_MGDeltaScenario2 B
				ON 	Temp.NPI=B.NPI AND
					Temp.ServiceLocationNo = B.ServiceLocationNo and 
					Temp.OwnerNo = B.OwnerNo /*and 
					Temp.ProviderTypeCode = B.ProviderTypeCode*/;

			--step d

			MERGE [KYPEnrollment].[pAccount_MixGroupOnly_Entities]  trgt
			USING 
			(
			select * from 
			KYPEnrollment.pADM_Account A
			where IsDeleted=0 and ProviderTypeCode='100'
			and StatusAcc <>'7 - Active Rendering (indirect)'
			--and LegacyAccountNo is not null  --Here, its known that sp has created LegacyAccountNo for MG account 
			AND ServiceLocationNo IS NOT NULL AND OwnerNo IS NOT NULL
			)src ON (
			trgt.GroupNPI=src.NPI 
			and trgt.GroupOwnerNo=src.OwnerNo 
			and trgt.GroupServiceLocationNo=src.ServiceLocationNo
			and trgt.MGaccountid=src.AccountID
			)
			WHEN NOT MATCHED THEN 
			INSERT 
					   ([GroupNPI]
					   ,[GroupServiceLocationNo]
					   ,[GroupOwnerNo]
					   ,[GroupClubbingID]
					   ,[MGAccountID]
					   ,[MGPartyID]
					   ,[MGAccountNo]
					   ,[MGLegalName]
					   ,[MGProviderTypeCode]
					   ,[MGProviderDescription]
					   ,[MGAccountType]
					   ,[MGPackageName]
					   ,[MGPracticeAddress]
					   ,[DateCreated]
					   ,[IsDeleted])
			 VALUES (
			 src.NPI
			 ,src.ServiceLocationNo
			 ,src.OwnerNo
			 ,src.NPI + '_' + src.ServiceLocationNo + '_' + src.OwnerNo
			 ,src.AccountID
			 ,src.PartyID
			 ,src.AccountNumber
			 ,src.LegalName
			 ,src.ProviderTypeCode
			 ,src.ProviderType
			 ,src.AccountType
			 ,src.PackageName 
			 ,src.PracticeAddress
			 ,getdate()
			 ,0 
			 )
			;
			 
			--step e 
			MERGE [KYPEnrollment].[pAccount_SubGroupOnly_Entities]  trgt
			USING 
			(
			select distinct 
					[GroupNPI]
				  ,[GroupServiceLocationNo]
				  ,[GroupOwnerNo]
				  ,[GroupClubbingID]
				  ,[MGAccountID]
				  ,[MGPartyID]
				  ,[MGAccountNo]
				  ,[MGLegalName]
				  ,[MGPracticeAddress]
				  ,B.ProviderTypeCode
				  ,B.ProviderType
				  ,B.AccountType
				  ,B.PackageName
				  ,B.AccountID
				  ,B.PartyID
				  ,B.AccountNumber
				  ,B.[DateCreated]
				  ,B.[IsDeleted]
			from [KYPEnrollment].[pAccount_MixGroupOnly_Entities] A
			join KYPEnrollment.pADM_Account B
			on A.GroupNPI=B.NPI
			and A.GroupServiceLocationNo=B.ServiceLocationNo
			and A.GroupOwnerNo = B.OwnerNo
			and B.IsDeleted=0
			and exists (select 1 from 
							KYPEnrollment.pAccount_RenderingAffiliation R
							where R.AccountID=B.AccountID)
			and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
									  '023','025','027','029','031','032','037','062','071','078','104')
			join temp_MGDeltaScenario2 C
			on B.NPI=C.NPI
			and B.ServiceLocationNo = C.ServiceLocationNo
			and B.OwnerNo = C.OwnerNo
			-- and B.ProviderTypeCode = C.ProviderTypeCode

			where 
			B.ProviderTypeCode<>'100'
			and StatusAcc <>'7 - Active Rendering (indirect)'

			)src ON (
			trgt.GroupNPI=src.GroupNPI 
			and trgt.GroupOwnerNo=src.GroupOwnerNo 
			and trgt.GroupServiceLocationNo=src.GroupServiceLocationNo
			-- and trgt.[SGProviderTypeCode]=src.ProviderTypeCode

			)
			WHEN NOT MATCHED THEN 
			INSERT 
					   ([GroupNPI]
					   ,[GroupServiceLocationNo]
					   ,[GroupOwnerNo]
					   ,[GroupClubbingID]
					   ,[MGAccountID]
					   ,[MGPartyID]
					   ,[MGAccountNo]
					   ,[MGLegalName]
					   ,[MGPracticeAddress]
					   ,[SGProviderTypeCode]
					   ,[SGProviderDescription]
					   ,[SGAccountType]
					   ,[SGPackageName]
					   ,[SGAccountID]
					   ,[SGPartyID]
					   ,[SGAccountNo]
					   ,[DateCreated]
					   ,[IsDeleted]
					   )
			 VALUES (
			 
			 src.[GroupNPI]
				  ,src.[GroupServiceLocationNo]
				  ,src.[GroupOwnerNo]
				  ,src.[GroupClubbingID]
				  ,src.[MGAccountID]
				  ,src.[MGPartyID]
				  ,src.[MGAccountNo]
				  ,src.[MGLegalName]
				  ,src.[MGPracticeAddress]
				  ,src.ProviderTypeCode
				  ,src.ProviderType
				  ,src.AccountType
				  ,src.PackageName
				  ,src.AccountID
				  ,src.PartyID
				  ,src.AccountNumber
				  ,getdate()
				  ,0
			 
			 )
			; 
/* Commented by Anshu on April 30,2018 as CHOW Account Number change logic is not required in 3.0
			DELETE FROM @AppendOwnerNoToPreviousMG
*/			
			Print 'Mixed Group Scenario 2'

		END


		--==================>>Scenario 3: Expansion of an Existing Mixed Group from MMIS to include one or more subgroups<<======
		--There are 2 characterstics of such a situation
		--a. Mixed Group Account Already Exists in [pAccount_MixGroupOnly_Entities] table
		--b. One or more subgroups for such Mix Group in daily file doesnot exist in [pAccount_SubGroupOnly_Entities] table

		--In this case, on a higher level, the Renderings and MOCAs of new subgroups need to be transposed
		--to Mixed Group and Account Number of new sub groups need to be taken care of

		--In terms of steps, they are as follows:
		--a. Identify missing subgroups and target mixed group
		--b. Transpose missing renderings and MOCAs on Target MixedGroup and do account numbering for the new subgroup
				--through a lighter version of sp
		--c. Apply any update on the MixedGroup on Portal related information
		--d. Check and change status if needed for Mixed Group
		--e. Put this new SubGroup in pAccount_SubGroupOnly_Entities table

		--Step a


		select * 
		into temp_MGDeltaScenario3
		from temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay A
		where exists (
		select 1 
		from [KYPEnrollment].[pAccount_MixGroupOnly_Entities] B
		where B.[GroupNPI]= A.NPI
		and B.[GroupServiceLocationNo] = A.ServiceLocationNo
		and B.[GroupOwnerNo] = A.OwnerNo
		and B.isDeleted=0
		)
		and not exists (
		select 1 
		from [KYPEnrollment].[pAccount_SubGroupOnly_Entities] D
		where D.[GroupNPI]= A.NPI
		and D.[GroupServiceLocationNo] = A.ServiceLocationNo
		and D.[GroupOwnerNo] = A.OwnerNo
		and D.[SGProviderTypeCode] = A.ProviderTypeCode
		and D.isDeleted=0
		) AND MGScenario IS NULL

		/*

		Condition to be modified to avoid seeping of Scenario 1 cases in this.

		*/

		;

		--Step b,c and d

		--Step b is attained by calling a lighter version of MG creation sp, that just Transposes 
		--Affiliations, MOCAs and takes care of AccountNumbering and things around it

		SELECT @ScenariosRecordCount = COUNT(1)
			FROM temp_MGDeltaScenario3;

		IF @ScenariosRecordCount > 0

		BEGIN

			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_StageSubGroups_ForComp_MGMapping]') AND type in (N'U'))
				drop table temp_StageSubGroups_ForComp_MGMapping

			select X.NPI as SubGroupNPI,
			X.ServiceLocationNo as SubGroupServiceLocationNo, 
			X.OwnerNo as SubGroupOwnerNo, 
			X.NPI + '_' + X.ServiceLocationNo + '_' + X.OwnerNo as MixedGroupClubbingID,
			X.IsCHOW AS IsCHOW,
			Y.AccountID as SubGroupAccountID,
			Y.PartyID as SubGroupPartyID,
			Y.AccountNumber as SubGroupAccountNumber,
			Y.LegalName as SubGroupLegalName,
			Y.ProviderTypeCode as SubGroupProviderTypeCode,
			Y.ProviderType as SubGroupProviderDescription,
			Y.AccountType as SubGroupAccountType,
			Y.PackageName as SubGroupPackageName,
			Y.PracticeAddress as SubGroupPracticeAddress,
			CAST('' AS VARCHAR(20)) AS PreviousOwnershipMGAccountNumber
			into temp_StageSubGroups_ForComp_MGMapping 
			from temp_MGDeltaScenario3 X
			join (
			select * from KYPEnrollment.pADM_Account A
			where IsDeleted=0 and ProviderTypeCode<>'100'
			and StatusAcc <>'7 - Active Rendering (indirect)'
			--and LegacyAccountNo is not null
			and exists (select 1 from 
							KYPEnrollment.pAccount_RenderingAffiliation B
							where B.AccountID=A.AccountID)
			and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
									  '023','025','027','029','031','032','037','062','071','078','104')
			) Y
			on X.NPI=Y.NPI
			and X.ServiceLocationNo=Y.ServiceLocationNo
			and X.OwnerNo=Y.OwnerNo
			and X.ProviderTypeCode = Y.ProviderTypeCode
			order by MixedGroupClubbingID,X.NPI, X.ServiceLocationNo


			truncate table StageTableToLoopThroughMixedGroup

			insert into StageTableToLoopThroughMixedGroup (MixedGroupClubbingID /*, MixGroupLegalName, MixGroupPracticeAddress */ )
			select distinct  MixedGroupClubbingID -- , SubGroupLegalName as MixGroupLegalName, SubGroupPracticeAddress as MixGroupPracticeAddress
			from 
			temp_StageSubGroups_ForComp_MGMapping
			order by MixedGroupClubbingID




			exec KYPEnrollment.sp_CreateMixedGroupAffiliationMOCATranspositionForMMIS @Scenario = 3





			--step e 
			MERGE [KYPEnrollment].[pAccount_SubGroupOnly_Entities]  trgt
			USING 
			(
			select distinct 
					[GroupNPI]
				  ,[GroupServiceLocationNo]
				  ,[GroupOwnerNo]
				  ,[GroupClubbingID]
				  ,[MGAccountID]
				  ,[MGPartyID]
				  ,[MGAccountNo]
				  ,[MGLegalName]
				  ,[MGPracticeAddress]
				  ,B.ProviderTypeCode
				  ,B.ProviderType
				  ,B.AccountType
				  ,B.PackageName
				  ,B.AccountID
				  ,B.PartyID
				  ,B.AccountNumber
				  ,B.[DateCreated]
				  ,B.[IsDeleted]
			from [KYPEnrollment].[pAccount_MixGroupOnly_Entities] A
			join KYPEnrollment.pADM_Account B
			on A.GroupNPI=B.NPI
			and A.GroupServiceLocationNo=B.ServiceLocationNo
			and A.GroupOwnerNo = B.OwnerNo
			and B.IsDeleted=0
			and exists (select 1 from 
							KYPEnrollment.pAccount_RenderingAffiliation R
							where R.AccountID=B.AccountID)
			and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
									  '023','025','027','029','031','032','037','062','071','078','104')
			join temp_MGDeltaScenario3 C
			on B.NPI=C.NPI
			and B.ServiceLocationNo = C.ServiceLocationNo
			and B.OwnerNo = C.OwnerNo
			and B.ProviderTypeCode = C.ProviderTypeCode

			where 
			B.ProviderTypeCode<>'100'
			and StatusAcc <>'7 - Active Rendering (indirect)'

			)src ON (
			trgt.GroupNPI=src.GroupNPI 
			and trgt.GroupOwnerNo=src.GroupOwnerNo 
			and trgt.GroupServiceLocationNo=src.GroupServiceLocationNo
			and trgt.[SGProviderTypeCode]=src.ProviderTypeCode

			)
			WHEN NOT MATCHED THEN 
			INSERT 
					   ([GroupNPI]
					   ,[GroupServiceLocationNo]
					   ,[GroupOwnerNo]
					   ,[GroupClubbingID]
					   ,[MGAccountID]
					   ,[MGPartyID]
					   ,[MGAccountNo]
					   ,[MGLegalName]
					   ,[MGPracticeAddress]
					   ,[SGProviderTypeCode]
					   ,[SGProviderDescription]
					   ,[SGAccountType]
					   ,[SGPackageName]
					   ,[SGAccountID]
					   ,[SGPartyID]
					   ,[SGAccountNo]
					   ,[DateCreated]
					   ,[IsDeleted]
					   )
			 VALUES (
			 
			 src.[GroupNPI]
				  ,src.[GroupServiceLocationNo]
				  ,src.[GroupOwnerNo]
				  ,src.[GroupClubbingID]
				  ,src.[MGAccountID]
				  ,src.[MGPartyID]
				  ,src.[MGAccountNo]
				  ,src.[MGLegalName]
				  ,src.[MGPracticeAddress]
				  ,src.ProviderTypeCode
				  ,src.ProviderType
				  ,src.AccountType
				  ,src.PackageName
				  ,src.AccountID
				  ,src.PartyID
				  ,src.AccountNumber
				  ,getdate()
				  ,0
			 
			 )
			; 
			  

			UPDATE temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
				SET MGScenario = 3,
					MGScenarioDescription = 'Additional MG Sub group(s) created with existing sub group(s)'
				FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay Temp
				JOIN temp_MGDeltaScenario3 B
				ON 	Temp.NPI=B.NPI AND
					Temp.ServiceLocationNo = B.ServiceLocationNo and 
					Temp.OwnerNo = B.OwnerNo and 
					Temp.ProviderTypeCode = B.ProviderTypeCode

			Print 'Mixed Group Scenario 3'

		END

		--==================>>Scenario 4: Mixed Group and all it Sub Group are already Exist<<======
		--There are 2 characterstics of such a situation
		--a. Mixed Group Account Already Exists in [pAccount_MixGroupOnly_Entities] table
		--b. Sub Group Account already exists in [pAccount_SubGroupOnly_Entities] table

		select * 
		into temp_MGDeltaScenario4
		from temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay A
		where exists (
		select 1 
		from [KYPEnrollment].[pAccount_MixGroupOnly_Entities] B
		where B.[GroupNPI]= A.NPI
		and B.[GroupServiceLocationNo] = A.ServiceLocationNo
		and B.[GroupOwnerNo] = A.OwnerNo
		and B.isDeleted=0
		)
		and exists (
		select 1 
		from [KYPEnrollment].[pAccount_SubGroupOnly_Entities] D
		where D.[GroupNPI]= A.NPI
		and D.[GroupServiceLocationNo] = A.ServiceLocationNo
		and D.[GroupOwnerNo] = A.OwnerNo
		-- and D.[SGProviderTypeCode] = A.ProviderTypeCode		-- This should be commented because here we have to take all the Provider type code otherwise MOCA update Procedure will not take the correct values from the Subgroup like Reenrollment Date, ProvisionalCodeDate etc.
		and D.isDeleted=0
		) AND MGScenario IS NULL

		SELECT @ScenariosRecordCount = COUNT(1)
			FROM temp_MGDeltaScenario4;

		IF @ScenariosRecordCount > 0

		BEGIN

			IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[temp_StageSubGroups_ForComp_MGMapping]') AND type in (N'U'))
				drop table temp_StageSubGroups_ForComp_MGMapping


			select X.NPI as SubGroupNPI,
			X.ServiceLocationNo as SubGroupServiceLocationNo, 
			X.OwnerNo as SubGroupOwnerNo, 
			X.NPI + '_' + X.ServiceLocationNo + '_' + X.OwnerNo as MixedGroupClubbingID,
			X.IsCHOW AS IsCHOW,
			Y.AccountID as SubGroupAccountID,
			Y.PartyID as SubGroupPartyID,
			Y.AccountNumber as SubGroupAccountNumber,
			Y.LegalName as SubGroupLegalName,
			Y.ProviderTypeCode as SubGroupProviderTypeCode,
			Y.ProviderType as SubGroupProviderDescription,
			Y.AccountType as SubGroupAccountType,
			Y.PackageName as SubGroupPackageName,
			Y.PracticeAddress as SubGroupPracticeAddress,
			CAST('' AS VARCHAR(20)) AS PreviousOwnershipMGAccountNumber
			into temp_StageSubGroups_ForComp_MGMapping 
			from temp_MGDeltaScenario4 X
			join (
			select * from KYPEnrollment.pADM_Account A
			where IsDeleted=0 and ProviderTypeCode<>'100'
			and StatusAcc <>'7 - Active Rendering (indirect)'
			--and LegacyAccountNo is not null
			and exists (select 1 from 
							KYPEnrollment.pAccount_RenderingAffiliation B
							where B.AccountID=A.AccountID)
			and ProviderTypeCode  in ('003','005','006','010','012','013','018','019','021','022',
									  '023','025','027','029','031','032','037','062','071','078','104')
			) Y
			on X.NPI=Y.NPI
			and X.ServiceLocationNo=Y.ServiceLocationNo
			and X.OwnerNo=Y.OwnerNo
			-- and X.ProviderTypeCode = Y.ProviderTypeCode
			order by MixedGroupClubbingID,X.NPI, X.ServiceLocationNo


			truncate table StageTableToLoopThroughMixedGroup


			insert into StageTableToLoopThroughMixedGroup (MixedGroupClubbingID /*, MixGroupLegalName, MixGroupPracticeAddress*/ )
			select distinct  MixedGroupClubbingID -- , SubGroupLegalName as MixGroupLegalName, SubGroupPracticeAddress as MixGroupPracticeAddress
			from temp_StageSubGroups_ForComp_MGMapping
			order by MixedGroupClubbingID


			exec KYPEnrollment.sp_CreateMixedGroupAffiliationMOCATranspositionForMMIS @Scenario = 4


			UPDATE temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
				SET MGScenario = 4,
					MGScenarioDescription = 'Existing MG and Sub group(s) updated'
				FROM temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay Temp
				JOIN temp_MGDeltaScenario4 B
				ON 	Temp.NPI=B.NPI AND
					Temp.ServiceLocationNo = B.ServiceLocationNo and 
					Temp.OwnerNo = B.OwnerNo and 
					Temp.ProviderTypeCode = B.ProviderTypeCode

			Print 'Mixed Group Scenario 4'

		END

		UPDATE temp_PossibleMMISSubGroupsOfMixedGroup_Delta_ForTheDay
			SET MGScenarioDescription = 'No effect'
			WHERE MGScenario IS NULL

	-- COMMIT TRAN
	SELECT 1

	END TRY

	BEGIN CATCH

		-- ROLLBACK TRAN
		INSERT INTO kypenrollment.DeltaProcedureErrorLog(ErrorName,ErrorNumber,ErrorProcedure,ErrorMessage,ErrorLine,ErrorDate)
		SELECT 'Delta MG Procedure Error',ERROR_NUMBER(),ERROR_PROCEDURE(),ERROR_MESSAGE(),ERROR_LINE(),GETDATE()

		SELECT 0

	END CATCH

END
GO

