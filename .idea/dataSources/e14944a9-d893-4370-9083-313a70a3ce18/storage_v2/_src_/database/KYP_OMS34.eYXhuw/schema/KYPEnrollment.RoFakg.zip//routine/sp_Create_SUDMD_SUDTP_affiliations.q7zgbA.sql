/* ==========================================================  
-- Author:  <RLoayza>  
-- PROCEDURE: Create affiliations between DMC and SUDMD/SUDTP  
-- ============================================================*/  
--Change History  
---------------------------------------------------------------------------------------  
-- Sl.No. JIRA No.   Author		Date			Description  
---------------------------------------------------------------------------------------  
--	1	KEN-20824	Sundar		19-May-2019		Added statement to avoid duplicate rendering in pAccount_renderingAffiliation table

CREATE PROCEDURE [KYPEnrollment].[sp_Create_SUDMD_SUDTP_affiliations]  
    @account_id          INT,  
    @last_action_user_id VARCHAR(100),  
    @application_no      VARCHAR(100)  
  
AS  
BEGIN  
	SET NOCOUNT ON  

	DECLARE @affiliationType VARCHAR(200),  
			@group_providerNumber VARCHAR(20),  
			@date_create DATE,  
			@group_npi VARCHAR(15),  
			@groupId INT,  
			@group_email VARCHAR(200);  

	--SET @date_create= GETDATE();  

	Select @date_create = DateCreated  
	From kyp.ADM_Case  
	Where Number=@application_no  

	SELECT @affiliationType = type_affiliation, @group_providerNumber = group_providerNumber,  
	@group_npi = group_npi, @group_email = groupEmail  
	FROM KYPPORTAL.PortalKYP.pRenderingAffiliation  
	WHERE rendering_providerNumber = @application_no  

	IF EXISTS(SELECT AccountID FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @group_providerNumber)  
	BEGIN  
		SELECT @groupId = AccountID FROM KYPEnrollment.pADM_Account WHERE AccountNumber = @group_providerNumber  

		IF Not Exists (Select RenderingAffiliationID from [KYPEnrollment].[pAccount_RenderingAffiliation] Where AccountID = @groupId and [AffiliatedAccountID] = @account_id) --Added for 1 KEN-20824
		Begin
			INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
			([AccountID]  
			, [AffiliatedAccountID]  
			, [TypeAffiliation]  
			, [LastActionDate]  
			, [LastActorUserID]  
			, [LastActionApprovedBy]  
			, [CurrentRecordFlag]  
			, [LastAction]  
			, [AffiliationStartDate]  
			, [LastUpdatedBy]  
			, [groupEmail]  
			, [rendering_email]  
			, isDeleted)  
			SELECT  
			@groupId,  
			@account_id,  
			[type_affiliation],  
			@date_create,  
			@last_action_user_id,  
			@last_action_user_id,  
			1,  
			'C',  
			@date_create,  
			'P',  
			[groupEmail],  
			[rendering_email],  
			0  
			FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  
			WHERE rendering_providerNumber = @application_no;  

			RETURN 
		End 
	END  

	CREATE TABLE #clinics(id INT IDENTITY (1, 1), accountId INT, providerTypeCode VARCHAR(6))  

	INSERT INTO #clinics(accountId, providerTypeCode)  
	SELECT acc.AccountID, acc.ProviderTypeCode FROM KYPEnrollment.pADM_Account acc  
	INNER JOIN KYPEnrollment.pAccount_PDM_Party party on party.PartyID = acc.PartyID  
	INNER JOIN KYPEnrollment.pAccount_PDM_Location loc on loc.PartyID = party.PartyID  
	INNER JOIN KYPEnrollment.pAccount_PDM_Address addr on addr.AddressID = loc.AddressID  
	INNER JOIN KYPPORTAL.PortalKYP.pPDM_Address appAddr on appAddr.AddressLine1 = addr.AddressLine1  
											 AND appAddr.City = addr.City  
											 AND appAddr.State = addr.State  
											 AND appAddr.County = addr.County  
											 AND appAddr.ZipPlus4 = addr.ZipPlus4  
	INNER JOIN KYPPORTAL.PortalKYP.pPDM_Location appLoc on appLoc.AddressID = appAddr.AddressID  
	INNER JOIN KYPPORTAL.PortalKYP.pADM_Application app on app.PartyID = appLoc.PartyID  
	WHERE acc.NPI = @group_npi  
	AND app.ApplicationCode = acc.PackageName  
	AND app.ApplicationNo = @group_providerNumber  
	AND acc.IsPastOwner = 0  
	AND loc.Type = 'Servicing' AND appLoc.Type = 'Servicing'  
	AND loc.IsDeleted = 0 AND appLoc.IsDeleted = 0  

	DECLARE @totalClinics INT  
	SELECT @totalClinics = COUNT(id) FROM #clinics  

	IF(1 < @totalClinics)  
	BEGIN  
		SELECT @groupId = accountId FROM #clinics WHERE providerTypeCode = '076'  
	END  
	ELSE  
	BEGIN  
		SELECT @groupId = accountId FROM #clinics  
	END  

	IF Not Exists (Select RenderingAffiliationID from [KYPEnrollment].[pAccount_RenderingAffiliation] Where AccountID = @groupId and [AffiliatedAccountID] = @account_id)--Added for 1 KEN-20824
	Begin
		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AccountID]  
		, [AffiliatedAccountID]  
		, [TypeAffiliation]  
		, [LastActionDate]  
		, [LastActorUserID]  
		, [LastActionApprovedBy]  
		, [CurrentRecordFlag]  
		, [LastAction]  
		, [AffiliationStartDate]  
		, [LastUpdatedBy]  
		, [groupEmail]  
		, [rendering_email]  
		, isDeleted) 
		SELECT  
		@groupId,  
		@account_id,  
		[type_affiliation],  
		@date_create,  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		@date_create,  
		'P',  
		[groupEmail],  
		[rendering_email],  
		0  
		FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  
		WHERE rendering_providerNumber = @application_no;  
	End
END
GO

