

/*
generate [KYPEnrollment].[pAccount_RenderingAffiliation]
Author: Richard Jimenez
*/


CREATE  PROCEDURE [KYPEnrollment].[sp_Copy_Affiliation_RenderingGroup_G]
@account_id INT

AS
BEGIN
 DECLARE @accountType varchar(2)
 DECLARE @acc_render VARCHAR(20), @isdel bit, @affcc varchar(40),@npi varchar(80),@modif int
 DECLARE @typerender VARCHAR(80)
		,@Date_Create datetime --Added for CAPAVE-2233 on 7 Nov 2017 
 
 BEGIN TRY

	SET NOCOUNT ON;
	
	declare @tot int
    declare @cont int

	SELECT @accountType=AccountType, @npi =npi from KYPEnrollment.pADM_Account where accountID = @account_id;
   
	IF @accountType='G'
    BEGIN
  
		  SET @affcc= @account_id 
		  SET @npi  = @npi
		  SET @typerender= 'NEW_RENDERING_FROM_GROUP'
		  --DECLARE Cur_m CURSOR FOR
 
				  --DECLARE Cur_addg CURSOR FOR
				  DECLARE  @AfillAddres table (pk int identity(1,1),accountid int, isdeleted bit,modifiedBy int)

				  INSERT INTO @AfillAddres(accountid,isdeleted,modifiedBy)
				  SELECT  accountid,isdeleted,modifiedBy 
				  FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] 
				  WHERE npi = @npi  and accountid <> @account_id
				  group by  accountid, isdeleted,modifiedBy 

				  --OPEN Cur_addg  
				  
				  --FETCH Cur_addg INTO @acc_render, @isdel,@modif
				  SELECT @tot =MAX(pk) from @AfillAddres
				  SET @cont=1;

				  WHILE  @cont<=@tot
				  BEGIN	
				    
					 SELECT  @acc_render=accountid,@isdel=isdeleted,@modif=modifiedBy FROM @AfillAddres WHERE pk = @cont

					 IF NOT EXISTS( SELECT  1 FROM [KYPEnrollment].pAccount_RenderingAffiliation WHERE AffiliatedAccountId = @acc_render and accountID = @affcc)
					 BEGIN
			  
						-- Added the below statement for CAPAVE-2233 on 7 Nov 2017
						select @Date_Create = T2.DateCreated
						from kypenrollment.padm_Account T1
						Join kyp.ADM_Case T2 with (nolock) on T1.ApplicationNumber=T2.Number
						Where T1.AccountID = @acc_render;							
			  
					   INSERT INTO  [KYPEnrollment].[pAccount_RenderingAffiliation]
								   ([AccountID]
								   ,[AffiliatedAccountID]
								   ,[TypeAffiliation]
								   ,[LastActionDate]
								   ,[LastActorUserID]
								   ,[LastActionComments]
								   ,[LastActionApprovedBy]
								   ,[CurrentRecordFlag]
								   ,[LastAction]
								   ,[AffiliationStartDate]
								   ,[LastUpdatedBy]
								   ,isDeleted)
								VALUES( 
								@affcc,
								@acc_render,
								@typerender, 
								getdate(),
								null,
								'.',
								null,
								1,
								'C',
								@Date_Create,--getdate(), --Changed for CAPAVE-2233 on 7 Nov 2017
								'P',
								0)
					END
					ELSE
					BEGIN
					 -- Update
					
						if (@modif is not null)
						BEGIN	     
							UPDATE [KYPEnrollment].[pAccount_RenderingAffiliation]
							SET isdeleted=1
							WHERE AffiliatedAccountId = @affcc and accountID = @acc_render 
						END 
					   
					END
				    set @cont=@cont+1
				 -- FETCH Cur_addg INTO @acc_render, @isdel,@modif
				 END 
				 -- CLOSE Cur_addg
				 -- DEALLOCATE Cur_addg
    END --if

 END TRY
	BEGIN CATCH
		DECLARE @error_message NVARCHAR (4000), @error_severity INT;
		SELECT @error_message = ERROR_MESSAGE(), @error_severity = ERROR_SEVERITY();
		RAISERROR (@error_message, @error_severity, 1);
 END CATCH
END

GO

