/* ==========================================================  
-- Author:  <RLoayza>  
-- PROCEDURE: create Affiliations of one rendering with multiple groups.  
-- PARAMETERS:   
-- @account_id : AccountID that will be create.   
-- @party_app_id : partyID Application that will be Account.   
-- @last_action_user_id : this is the user Enrollment.  
-- @type : type of affiliation will be create.  
-- @application_no : ApplicationNo that will be Account.   
-- @application_Id : ApplicationID that will be Account.   
-- ============================================================*/  
--Change History  
---------------------------------------------------------------------------------------  
-- Sl.No. JIRA No.   Author		Date			Description  
---------------------------------------------------------------------------------------  
--	1	KEN-20824	Sundar		19-May-2019		Added statement to avoid duplicate rendering in pAccount_renderingAffiliation table
  
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Multiple_Groups_Affiliation]  
    @account_id          INT,  
    @last_action_user_id VARCHAR(100),  
    @application_no      VARCHAR(100)  
  
AS  
BEGIN  
	SET NOCOUNT ON  

	DECLARE @affiliationType VARCHAR(200),  
			@group_providerNumber VARCHAR(100),  
			@date_create DATE,  
			@groupId INT  

	--SET @date_create= GETDATE();  

	SELECT @date_create = DateCreated  
	FROM KYP.ADM_CASE with (nolock)  
	WHERE Number = @application_no  

	SELECT @affiliationType = type_affiliation, @group_providerNumber = group_providerNumber   
	FROM KYPPORTAL.PortalKYP.pRenderingAffiliation WHERE rendering_providerNumber = @application_no  

	IF 'NEW_RENDERING_FROM_GROUP' = @affiliationType  
	BEGIN  

		DECLARE @groupsToAffiliate table (accid bigint,appno varchar(20))  

		INSERT INTO @groupsToAffiliate (accid,appno)  
		SELECT AccountID,@application_no  
		FROM KYPEnrollment.pADM_Account  
		WHERE ApplicationNumber = @group_providerNumber AND IsPastOwner = 0 AND IsDeleted = 0  

		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AccountID]  
		, [AffiliatedAccountID]  
		, [TypeAffiliation]  
		, [LastActionDate]  
		, [LastActorUserID]  
		, [LastActionApprovedBy]  
		, [CurrentRecordFlag]  
		, [LastAction]  
		, [AffiliationStartDate]  
		, [LastUpdatedBy]  
		, [groupEmail]  
		, [rendering_email]  
		, isDeleted)  
		SELECT  
		g.accid,  
		@account_id,  
		[type_affiliation],  
		@date_create,  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		@date_create,  
		'P',  
		A.[groupEmail],  
		A.[rendering_email],  
		0  
		FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] a  
		inner join @groupsToAffiliate g on a.rendering_providerNumber=g.appno  
		Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = g.accid and C.AffiliatedAccountID = @account_id and C.isDeleted=0  --Added for #1 KEN-20824 
		Where C.RenderingAffiliationID is null  --Added for #1 KEN-20824 
		
		RETURN  

	END  

	IF 'NEW_RENDERING_FROM_ACCOUNT' = @affiliationType  
	BEGIN  
		DECLARE @groupNPI VARCHAR(10),  
		@groupPackageName VARCHAR(20)  

		SELECT @groupNPI = NPI, @groupPackageName = PackageName FROM KYPEnrollment.pADM_Account  
		WHERE AccountNumber = @group_providerNumber  

		DECLARE @groupsToAffiliate2 table (accid bigint,appno varchar(20))  
		INSERT INTO @groupsToAffiliate2 (accid,appno)  
		SELECT AccountID,@application_no  
		FROM KYPEnrollment.pADM_Account  
		WHERE NPI = @groupNPI AND PackageName = @groupPackageName AND IsPastOwner = 0 AND IsDeleted = 0  

		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AccountID]  
		, [AffiliatedAccountID]  
		, [TypeAffiliation]  
		, [LastActionDate]  
		, [LastActorUserID]  
		, [LastActionApprovedBy]  
		, [CurrentRecordFlag]  
		, [LastAction]  
		, [AffiliationStartDate]  
		, [LastUpdatedBy]  
		, [groupEmail]  
		, [rendering_email]  
		, isDeleted)  
		SELECT  
		g.accid,  
		@account_id,  
		[type_affiliation],  
		@date_create,  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		@date_create,  
		'P',  
		A.[groupEmail],  
		A.[rendering_email],  
		0  
		FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] a   
		inner join @groupsToAffiliate2 g on a.rendering_providerNumber=g.appno  
		Left Join kypenrollment.pAccount_RenderingAffiliation C on C.AccountID = g.accid and C.AffiliatedAccountID = @account_id and C.isDeleted=0  --Added for #1 KEN-20824 
		Where C.RenderingAffiliationID is null  --Added for #1 KEN-20824 
		
	END  
END

GO

