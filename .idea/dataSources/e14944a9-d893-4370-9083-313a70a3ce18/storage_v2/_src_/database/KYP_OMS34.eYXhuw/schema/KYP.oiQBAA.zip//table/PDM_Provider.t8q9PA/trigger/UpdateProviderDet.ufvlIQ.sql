-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[UpdateProviderDet] 
   ON  [KYP].[PDM_Provider] 
   AFTER INSERT
AS 
BEGIN
	
Declare @PartyID INT,
        @CaseID INT,
        @NPI INT,
        @ApplicationID INT,
        @PrimarySpeciality varchar(255),
        @Rangename varchar(20)
      
        
        --@CaseType varchar(25)
        
 
SET @NPI=(Select NPI from inserted); 
SET @PrimarySpeciality=(Select PrimarySpecialty from inserted);
SET @PartyID = (select PartyID from inserted);
SET @ApplicationID=(Select ApplicationID from KYP.SDM_ApplicationParty where PartyID=@PartyID)
SET @CaseID=(Select CaseID from ADM_Application where ApplicationID=@ApplicationID);

--Set @NoofDays=Datediff(d,@DateInitiated,getdate())
--set @Rangename=KYP.AuditDays(@DateInitiated)

update KYP.DSH_DashBoardTable set NPI=@NPI,PrimarySpeciality=@PrimarySpeciality where PartyID=@PartyID and CaseID=@CaseID 

END


GO

