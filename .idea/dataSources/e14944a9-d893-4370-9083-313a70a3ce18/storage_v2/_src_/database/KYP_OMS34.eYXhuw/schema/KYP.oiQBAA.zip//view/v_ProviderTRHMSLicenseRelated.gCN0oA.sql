



CREATE VIEW [KYP].[v_ProviderTRHMSLicenseRelated]
AS

SELECT  Z.MoreValueID,Z.ScreeningID,Z.TRLicense,Z.TRStateName,Z.TRValidity,
Z.TRFirstIssue,Z.TROrgName,Z.TRLicenseType,Z.TRAuthority,Z.TRSTATUS,C.LicenseCount,
CASE WHEN Z.Source = 'TR' THEN Z.TRSTATUS
	 WHEN Z.Source = 'HMS' THEN Z.FStatus
END AS 'FinalStatus',
Z.Source FROM (
	SELECT MoreValueID,ScreeningID,TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS,FStatus,Source from(
		Select X.MoreValueID,X.ScreeningID,X.DetailAttributeName,X.DetailAttributeValue, X.Source from(
			Select D.MoreValueID,M.ScreeningID,D.DetailAttributeName,D.DetailAttributeValue,M.Source
				from KYP.SDM_MoreValue M inner join KYP.SDM_MoreValueDetail D 
				ON M.MoreValueID = D.MoreValueID 
		) X UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRLicense' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRStateName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRValidity' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRFirstIssue' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TROrgName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRLicenseType' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRAuthority' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRSTATUS' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'FStatus' As DetailAttributeName , '' As DetailAttributeValue
)Y PIVOT(max(DetailAttributeValue)
	for DetailAttributeName IN (TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS,FStatus)
) patx
) Z 
INNER JOIN
(
SELECT  Z.ScreeningID,COUNT(Z.ScreeningID)As LicenseCount FROM (
	SELECT MoreValueID,ScreeningID,TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS,
	CASE WHEN Source = 'TR' THEN TRSTATUS
	 WHEN Source = 'HMS' THEN FStatus
	END AS 'FinalStatus',	
	Source from(
		Select X.MoreValueID,X.ScreeningID,X.DetailAttributeName,X.DetailAttributeValue, X.Source from(
			Select D.MoreValueID,M.ScreeningID,D.DetailAttributeName,D.DetailAttributeValue, M.Source
				from KYP.SDM_MoreValue M inner join KYP.SDM_MoreValueDetail D 
				ON M.MoreValueID = D.MoreValueID 
		) X UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRLicense' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRStateName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRValidity' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRFirstIssue' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TROrgName' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRLicenseType' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRAuthority' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'TRSTATUS' As DetailAttributeName , '' As DetailAttributeValue
		UNION ALL
		SELECT '0' As MoreValueID ,'0' As ScreeningID , '0' As Source, 'FStatus' As DetailAttributeName , '' As DetailAttributeValue
)Y PIVOT(max(DetailAttributeValue)
	for DetailAttributeName IN (TRLicense,TRStateName,TRValidity,TRFirstIssue,TROrgName,TRLicenseType,TRAuthority,TRSTATUS,FStatus)
) patx
) Z WHERE Z.MoreValueID != 0 AND LTRIM(RTRIM(ISNULL(Z.TRLicense,''))) != '' 
	GROUP BY Z.ScreeningID
) C		
	ON Z.ScreeningID = C.ScreeningID 
WHERE Z.MoreValueID != 0 AND LTRIM(RTRIM(ISNULL(Z.TRLicense,''))) != ''


GO

