
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <02/10/2017>
-- Description:	<This procedure copy basic data from Portal to Enrollment>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Main_Info]
@new_accountID int,@party_Id INT, 
	--de aqui pasar todos los parametros del procedure superior:
	@last_Action_User_ID VARCHAR(100),
	@application_type VARCHAR(40)
	
	
AS
BEGIN

	SET NOCOUNT ON;
DECLARE @new_sub_party int,@new_Address_Id int/*servicing addres*/,@type varchar(30),@org_id int
select @new_sub_party = PartyID from [KYPEnrollment].pADM_Account where AccountID=@new_accountID and IsDeleted=0;
select @type = type from [KYPEnrollment].pAccount_PDM_Party where AccountID=@new_accountID and CurrentRecordFlag=1;
    
    --BUSINESS INFO
    
    EXEC @org_id = [KYPEnrollment].[sp_Copy_Business_Profile] @new_sub_party, @party_Id,@last_Action_User_ID;
    
    EXEC [KYPEnrollment].[sp_Contact_Person] @party_Id, @new_sub_party,@last_action_user_id,@new_accountID;	
    
    EXEC [KYPEnrollment].[sp_Copy_Place_Business] @new_sub_party, @party_Id,@last_Action_User_ID,@new_accountID;
    
    
    --ADDRESSES
    EXEC @new_Address_Id = [KYPEnrollment].[sp_Copy_Address] @new_sub_party, @party_Id, 'Servicing', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_sub_party, @party_Id, 'Pay-to', @last_Action_User_ID;
	EXEC [KYPEnrollment].[sp_Copy_Address] @new_sub_party, @party_Id, 'Mailing', @last_Action_User_ID;
    
    --INSURANCE
    EXEC [KYPEnrollment].[sp_Copy_Insurance] @new_sub_party, @party_Id,@last_action_user_id;       
    
	--participation program
	EXEC [KYPEnrollment].[sp_Copy_Program_Participation_Form] @new_sub_party, @party_Id,@last_action_user_id,@new_accountID; 
	--adverse actions
	EXEC [KYPEnrollment].[sp_Copy_Adverse_Action_Form] @new_sub_party, @party_Id,@last_action_user_id,@new_accountID; 
	/* Fines and debts */
	EXEC [KYPEnrollment].[sp_Copy_Fines_Debts] @party_Id, @new_sub_party, @last_action_user_id,NULL;
	
	
	--Social Form: Claim Payment
	--Claim Payment
	EXEC [KYPEnrollment].[sp_Copy_PaymentDetail] @party_Id, @new_sub_party, @last_Action_User_ID;
	
return @new_Address_Id; 
    
END


GO

