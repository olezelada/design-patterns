
-- =============================================
-- Author:		<Author,,Lperez>
-- copiar Party recive 5 para metros
-- @partyId old party ID,@newPartyIdProv nuevo party ID ,@accountId  new account ID,@lastActionUserID nombre del usuario que realiza la aprobacion y
-- @type tipo de operacion: valor vacio realiza una insert apartir party ID, distinto de vario hace la insert apartir del Parent PartyID
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[p_Copy_Party]
	@partyId INT,
	@newPartyIdProv INT,
	@accountId INT,
	@lastActionUserID varchar(100),
	@type varchar(50)
AS
BEGIN

    DECLARE @newPartyId int,
			@message varchar(100),
			@dateCreated date
	
	SET @dateCreated = GETDATE()	
	SET @newPartyId=0
	IF((SELECT COUNT([PartyID]) FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID = @partyId)>0)
	BEGIN
		IF(@type ='')
		BEGIN
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
			([Type] ,
			[Name] ,
			[IsProvider] ,
			[IsEnrolled] ,
			[IsTemp] ,
			[IsActive] ,
			[LoadType] ,
			[LoadID] ,
			[LastLoadDate] ,
			[DateModified] ,
			[CurrentRecordFlag] ,
			[Source] ,
			[LastAction] ,
			[LastActionDate] ,
			[LastActorUserID] ,
			[LastActionApprovedBy] ,
			[ParentPartyID] ,
			[profile_id],
			[AccountID] )
			SELECT [Type]
			,[Name]
			,[IsProvider]
			,[IsEnrolled]
			,[IsTemp]
			,[IsActive]
			,[LoadType]
			,[LoadID]
			,[LastLoadDate]
			,[DateModified]
			,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
			,[Source]
			,'C'
			,@dateCreated
			,@lastActionUserID
			,@lastActionUserID
			,@newPartyIdProv
			,[profile_id]
			,@accountId
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID = @partyId
			
			SELECT @newPartyId = Scope_Identity()
		END
		ELSE
		BEGIN
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]
			([Type] ,
			[Name] ,
			[IsProvider] ,
			[IsEnrolled] ,
			[IsTemp] ,
			[IsActive] ,
			[LoadType] ,
			[LoadID] ,
			[LastLoadDate] ,
			[Source] ,
			[LastAction],
			[LastActionDate],
			[LastActorUserID],
			[LastActionApprovedBy],
			[CurrentRecordFlag],
			[ParentPartyID] ,
			[profile_id],
			[AccountID] )
			SELECT [Type]
			,[Name]
			,[IsProvider]
			,[IsEnrolled]
			,[IsTemp]
			,[IsActive]
			,[LoadType]
			,[LoadID]
			,[LastLoadDate]	
			,[Source]
			,(case when [IsDeleted] is null or [IsDeleted] = 0 then 'C' else 'D' end)
			,@dateCreated
			,@lastActionUserID
			,@lastActionUserID
			,(case when [IsDeleted] = 0 or [IsDeleted] is null then 1 else 0 end)
			,@newPartyIdProv
			,[profile_id]
			,@accountId
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE ParentPartyID = @partyId AND Type= @type
			SELECT @newPartyId = Scope_Identity()
		END
		SELECT @message = '[pAccount_PDM_Party] @newParty : ' + CONVERT(char(10), @newPartyId)
		RAISERROR(@message, 0, 1) WITH NOWAIT	
	END
	RETURN  @newPartyId				
END


GO

