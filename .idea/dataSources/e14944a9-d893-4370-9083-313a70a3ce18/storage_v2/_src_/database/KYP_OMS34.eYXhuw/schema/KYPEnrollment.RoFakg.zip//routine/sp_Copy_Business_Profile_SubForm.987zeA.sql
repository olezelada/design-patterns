

/* ==========================================================
-- Author:		<DH-BOL>
-- PROCEDURE: Business Profile form.
-- PARAMETERS:
-- @party_account_id : partyID to new Account that will be create.
-- @party_app_id : partyID Application that will be Account.
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Business_Profile_SubForm]
@party_account_id INT,
@party_app_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN
SET NOCOUNT ON

EXEC [KYPEnrollment].[sp_Copy_Twin_Organization] @party_account_id,@party_app_id,@last_action_user_id,'BusinessProfile';
EXEC [KYPEnrollment].[sp_Copy_Twin_EntityType] @party_account_id,@party_app_id,@last_action_user_id;
EXEC [KYPEnrollment].[sp_Copy_Twin_NumberFromLicense] @party_account_id, @party_app_id, @last_action_user_id,'BusinessEinLicenses';

PRINT ' Business Profile';
END


GO

