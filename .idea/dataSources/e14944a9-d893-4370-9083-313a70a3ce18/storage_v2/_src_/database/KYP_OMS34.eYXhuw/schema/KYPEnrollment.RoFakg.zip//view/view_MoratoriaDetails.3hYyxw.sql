
CREATE VIEW [KYPEnrollment].[view_MoratoriaDetails]
AS
	SELECT distinct    
	MD.ID AS ID,  
	MD.County AS County,  
	CD.CountyDescription AS CountyName,  
	MD.City AS City,  
	CCD.CityDescription AS CityName,  
	MD.ZIPCOde AS ZIP,  
	MD.ProviderTypeCode AS ProviderTypeCode,  
	PTC.ProviderTypeDescription AS ProviderTypeName,  
	MD.MoratoriaStartDate AS StartDate,  
	MD.MoratoriaEndDate AS EndDate,  
	MD.ModifiedBy AS ModifiedBy,  
	MD.ModifiedDate AS ModifiedDate,  
	MD.IsDeleted AS IsDeleted,  
	MD.AddedBy AS AddedBy   
	FROM   
	Moratorium.dbo.MoratoriumData MD   
	LEFT JOIN Moratorium.dbo.CountyDetails CD ON MD.County = CD.CountyCode and CD.State = 'CA'  
	LEFT JOIN Moratorium.dbo.CityDetails CCD ON MD.City = CCD.CityCode and CCD.State = 'CA'   
	LEFT JOIN KYP.PDM_ProviderTypeCode PTC ON MD.ProviderTypeCode 
	collate database_default = PTC.ProviderTypeCode collate database_default


GO

