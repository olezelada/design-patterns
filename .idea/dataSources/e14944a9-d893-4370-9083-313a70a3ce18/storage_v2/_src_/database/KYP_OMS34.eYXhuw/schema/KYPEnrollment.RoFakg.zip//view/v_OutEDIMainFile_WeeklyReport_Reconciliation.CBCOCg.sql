


















;CREATE VIEW [KYPEnrollment].[v_OutEDIMainFile_WeeklyReport_Reconciliation] as
With Q1 as (
	select A.AccountID,
		A.PartyID,
		A.NPI,
		A.OwnerNo,
		A.ServiceLocationNo,
		A.ProviderTypeCode,
		A.LegalName,
		A.EIN,
		A.SSN,
		A.PIN,
		A.ApplicationDate,
		--A.ReenrollmentIndicator,
		--A.ReenrollmentDate,
		A.ProvTypeUpdateDate,
		A.DateCreated,
		A.AccountUpdateDate,
		A.BusinessName,
		A.ProvLocTypeCd
	from KYPENROLLMENT.pADM_Account A
	where AccountType not in ('nmp','orp')
	and IsDeleted=0
	and A.ProviderTypeCode<>'100'), --Added to eliminate Mixed Group records
Q2 as (Select AccounTID,PartyID,Number,EffectiveDate,LicenseBoardCode
	From (Select T2.AccountID,T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,T1.LicenseBoardCode,Row_Number() Over(Partition by t1.Partyid order by t1.LastActionDate desc) R
		from KYPEnrollment.pAccount_PDM_Number T1
		Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
		where t1.CurrentRecordFlag=1
		and Type in ('Professional License')
		and T1.IsPrimary=1
		and T2.ProviderTypeCode not in ('021','029')
		Union all
		Select T2.AccountID,T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,T1.LicenseBoardCode,Row_Number() Over(Partition by t1.Partyid order by t1.LastActionDate desc) R
		from KYPEnrollment.pAccount_PDM_Number T1
		Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
		where t1.CurrentRecordFlag=1
		and T1.Number is not null
		and Type in ('orthotistBOC','orthotistABCOP')
		and T2.ProviderTypeCode = '021'	
		Union all
		(Select AccountID,Tab.PartyID,Tab.Number,Tab.Type,Tab.LastActionDate,Tab.EffectiveDate,LicenseBoardCode,Row_Number() Over(Partition by tab.Partyid order by tab.LastActionDate desc) R
		From (Select T2.AccountID,T1.PartyId,Number,Type,t1.LastActionDate,EffectiveDate,T1.LicenseBoardCode,Isnull(T1.IsPrimary,0) IsPrimary
				from KYPEnrollment.pAccount_PDM_Number T1
				Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
				where t1.CurrentRecordFlag=1
				and T1.Number is not null
				and T2.ProviderTypeCode = '029'	
				and Type in ('prosthetistBOC','prosthetistABCOP','orthProsthABCOP')
				Union all
				Select T2.AccountID,T1.PartyId,SecondNumber,Type,t1.LastActionDate,T1.SecondEffectiveDate,T1.LicenseBoardCode,Isnull(T1.IsPrimary,0) IsPrimary
				from KYPEnrollment.pAccount_PDM_Number T1
				Join kypenrollment.pADM_Account T2 on t1.PartyId=T2.PartyId
				where t1.CurrentRecordFlag=1
				and T1.SecondNumber is NOT null
				and T2.ProviderTypeCode = '029'	
				and Type in ('orthBOCprosthBOC','orthABCOPprosthABCOP','orthBOCprosthABCOP','orthABCOPprosthBOC')
				) Tab
			)		
		) T
		Where T.R = 1),
Q3 as (
	select D.AddressLine1,D.AddressLine2,D.City,LS.Abreviation State,d.Zip
	,case when (d.Zip <> replace(D.ZipPlus4,'-','')) then right(D.ZipPlus4,4) end ZipPlus4,Q1.AccountID	
		from Q1
		join KYPEnrollment.pAccount_PDM_Location L ON L.PartyID = Q1.PartyID
		Join KYPEnrollment.pAccount_PDM_Address D ON D.AddressID = L.AddressID 
		LEFT Join kyp.LK_Screening LS on D.State=LS.Description
		WHERE L.Type='Pay-to'
			 and L.CurrentRecordFlag=1
			 and L.IsDeleted = 0
),
Q4 as (
	select D.AddressLine1,D.AddressLine2,D.City,LS.Abreviation State,d.Zip
	,case when (d.Zip <> replace(D.ZipPlus4,'-','')) then right(D.ZipPlus4,4) end ZipPlus4,Q1.AccountID,CA.Code County
		from Q1
		join KYPEnrollment.pAccount_PDM_Location L ON L.PartyID = Q1.PartyID
		Join KYPEnrollment.pAccount_PDM_Address D ON D.AddressID = L.AddressID 
		LEFT Join kyp.LK_Screening LS on D.State=LS.Description	
		left join kyp.CA_CountyCodes CA on CA.Name=D.County	
		WHERE L.Type='Servicing'
			 and L.CurrentRecordFlag=1
			 and L.IsDeleted = 0			 
),
Q5 as (
	select D.AddressLine1,D.AddressLine2,D.City,LS.Abreviation State,d.Zip
	,case when (d.Zip <> replace(D.ZipPlus4,'-','')) then right(D.ZipPlus4,4) end ZipPlus4,Q1.AccountID
		from Q1
		join KYPEnrollment.pAccount_PDM_Location L ON L.PartyID = Q1.PartyID
		Join KYPEnrollment.pAccount_PDM_Address D ON D.AddressID = L.AddressID 
		LEFT Join kyp.LK_Screening LS on D.State=LS.Description		
		WHERE L.Type='Mailing'
			 and L.CurrentRecordFlag=1
			 and L.IsDeleted = 0			 
), 
AccS as (
    SELECT Ac.AccountStatusID,Ac.AccountId,Left(Ac.StatusValue,1) StatusValue,ac.EffectiveBeginDate,ac.EffectiveEndDate,
			ROW_NUMBER() over(PARTITION by ac.accountid order by ac.AccountStatusId) R
 		from Q1
		Join KYPEnrollment.pADM_AccountStatus Ac ON Q1.AccountID=Ac.AccountID
		where Ac.StatusValue IS NOT null
),
EDMAIM as (
	SELECT E.AccInternalUseManyID,C.AccountId, E.CodeIdentification,E.CodeType,E.CodeDateEffDate,E.CodeDateExpDate
    from Q1
    join KYPEnrollment.EDM_AccountInternalUse C ON Q1.AccountID=C.AccountId
    Join [KYPEnrollment].[EDM_AccountInternalMany] E ON E.AccountInternalUseID=C.AccountInternalUseID
), Spe as
(	SELECT P.SpecialityID,Q1.Accountid,P.Speciality_Code,P.SpecCertDate
		FROM Q1
		join KYPEnrollment.pADM_Account A ON Q1.AccountID=A.AccountID
		Join KYPEnrollment.pAccount_PDM_Speciality P ON P.PartyID=A.PartyID 
		Where P.Type = 'Specialty Code'
		and A.IsDeleted = 0
		--and P.IsDeleted = 0
		),
Q6 as ( select AccountId, 
 SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
 SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8,
 AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
 ,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
 from 
(   
	SELECT AccountId, EDMAIM.CodeIdentification
    ,'SCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by accountid order by EDMAIM.AccInternalUseManyID  DESC ) ) seq
    from EDMAIM 
    Where EDMAIM.CodeType = 'Sanction'
    
    UNION ALL
    SELECT AccS.AccountId,AccS.StatusValue as StatusValue
    ,'AccStatusValue'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by AccS.AccountStatusId desc )) seq
    from AccS
    
    UNION ALL	
    SELECT AccS.AccountId,isnull(CONVERT(varchar(10), AccS.EffectiveBeginDate,101),'1800-01-01')
    ,'AccEffectiveBeginDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by  AccS.AccountStatusId desc )) seq
    from AccS 
	
    UNION ALL	
    SELECT AccS.AccountId,isnull(CONVERT(varchar(10), AccS.EffectiveEndDate,101),'1800-01-01')
    ,'AccEffectiveEndDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by AccS.AccountId order by AccS.AccountStatusId desc )) seq
    from AccS 

	UNION ALL 
	SELECT distinct Spe.Accountid,Spe.Speciality_Code
	,'Speciality_Code'+CONVERT(varchar(10), ROW_NUMBER() over(partition by Spe.Accountid order by  Spe.SpecialityID desc)) seq
	FROM Spe
	
	UNION ALL 
	SELECT Spe.Accountid,isnull(CONVERT(varchar(10), Spe.SpecCertDate,101),'1800-01-01')
	,'SpecCertDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by Spe.Accountid order by  Spe.SpecialityID Desc)) seq--Changed on 14Dec2016 
	FROM Spe
	
	UNION ALL
	SELECT AccountId,EDMAIM.CodeIdentification
	,'CCodeIdentification'+CONVERT(varchar(10), ROW_NUMBER() over(partition by accountid order by EDMAIM.AccInternalUseManyID)) seq
	from EDMAIM 
    where EDMAIM.CodeType = 'Category'

	UNION ALL	
	SELECT AccountId,isnull(CONVERT(varchar(10),EDMAIM.CodeDateEffDate,101),'1800-01-01')
	,'CCodeDateEffDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by accountid order by EDMAIM.AccInternalUseManyID)) seq
	from EDMAIM 
    where EDMAIM.CodeType = 'Category'

	UNION ALL	
	SELECT AccountId,isnull(CONVERT(varchar(10),EDMAIM.CodeDateExpDate,101),'1800-01-01')
	,'CCodeDateExpDate'+CONVERT(varchar(10), ROW_NUMBER() over(partition by accountid order by EDMAIM.AccInternalUseManyID)) seq
	from EDMAIM 
    where EDMAIM.CodeType = 'Category'
    
)ML(AccountId,CodeIdentification,seq)
PIVOT (max(ml.CodeIdentification) 
FOR ml.seq IN (
SCodeIdentification1,SCodeIdentification2,SCodeIdentification3,SCodeIdentification4,
SCodeIdentification5,SCodeIdentification6,SCodeIdentification7,SCodeIdentification8, 
AccStatusValue1,AccStatusValue2,AccStatusValue3,AccStatusValue4,AccStatusValue5
,AccEffectiveBeginDate1,AccEffectiveBeginDate2,AccEffectiveBeginDate3,AccEffectiveBeginDate4,AccEffectiveBeginDate5
,AccEffectiveEndDate1,AccEffectiveEndDate2,AccEffectiveEndDate3,AccEffectiveEndDate4,AccEffectiveEndDate5
,Speciality_Code1,Speciality_Code2,Speciality_Code3
,SpecCertDate1,SpecCertDate2,SpecCertDate3
,CCodeIdentification1,CCodeIdentification2,CCodeIdentification3,CCodeIdentification4,CCodeIdentification5,CCodeIdentification6,CCodeIdentification7
,CCodeIdentification8,CCodeIdentification9,CCodeIdentification10,CCodeIdentification11,CCodeIdentification12,CCodeIdentification13,CCodeIdentification14
,CCodeIdentification15,CCodeIdentification16,CCodeIdentification17,CCodeIdentification18,CCodeIdentification19,CCodeIdentification20
,CCodeDateEffDate1,CCodeDateEffDate2,CCodeDateEffDate3,CCodeDateEffDate4,CCodeDateEffDate5,CCodeDateEffDate6,CCodeDateEffDate7,CCodeDateEffDate8,CCodeDateEffDate9,CCodeDateEffDate10
,CCodeDateEffDate11,CCodeDateEffDate12,CCodeDateEffDate13,CCodeDateEffDate14,CCodeDateEffDate15,CCodeDateEffDate16,CCodeDateEffDate17,CCodeDateEffDate18,CCodeDateEffDate19,CCodeDateEffDate20
,CCodeDateExpDate1,CCodeDateExpDate2,CCodeDateExpDate3,CCodeDateExpDate4,CCodeDateExpDate5,CCodeDateExpDate6,CCodeDateExpDate7,CCodeDateExpDate8,CCodeDateExpDate9,CCodeDateExpDate10
,CCodeDateExpDate11,CCodeDateExpDate12,CCodeDateExpDate13,CCodeDateExpDate14,CCodeDateExpDate15,CCodeDateExpDate16,CCodeDateExpDate17,CCodeDateExpDate18,CCodeDateExpDate19,CCodeDateExpDate20
)) pvt ),
Q7 as (
	Select Q1.AccountID,replace(replace(replace(replace(P.Phone1,'(',''),')',''),'-',''),' ','') Phone1
	From KYPENROLLMENT.pADM_Account q1
	Join KYPEnrollment.pAccount_PDM_Provider PP on q1.PartyID=PP.PartyID
	Join KYPENROLLMENT.pAccount_PDM_Person P On Q1.PartyID=P.PartyID
	where p.Phone1 is not null
	and PP.Category='Physician'
	and Q1.IsDeleted = 0
	Union all 
	Select Q1.AccountID,replace(replace(replace(replace(O.Phone1,'(',''),')',''),'-',''),' ','')
	From KYPENROLLMENT.pADM_Account q1
	Join KYPEnrollment.pAccount_PDM_Provider PP on q1.PartyID=PP.PartyID
	Join KYPENROLLMENT.pAccount_PDM_Organization O on Q1.PartyID=O.PartyID
	where o.Phone1 is not null
	and PP.Category='Institutional'
	and Q1.IsDeleted = 0)
Select 
Q1.NPI,
Q1.OwnerNo,
Q1.ServiceLocationNo,
AO.EffectiveBeingDate,
AO.EffectiveEndDate,
Q1.LegalName,
Q1.EIN,
Q1.SSN,
Q1.PIN,
AIU.TINUpdateType,
AIU.TINUpdateDate,
NULL [DH-PAY-TO-ATTEN-LN],
Q3.AddressLine1 PAddressLine1,
Q3.AddressLine2 PAddressLine2,
Q3.City PCity,
Q3.State PState,
Q3.Zip PZip,
Q3.ZipPlus4 PZipPlus4,
Q1.DateCreated,
Q1.AccountUpdateDate,
null as [DH-LAST-ACTY-TIME],
Q6.SCodeIdentification1,
Q6.SCodeIdentification2,
Q6.SCodeIdentification3,
Q6.SCodeIdentification4,
Q6.SCodeIdentification5,
Q6.SCodeIdentification6,
Q6.SCodeIdentification7,
Q6.SCodeIdentification8,
Q1.ProvLocTypeCd,
Q1.BusinessName,
null [DH-ADDR-ATTEN-LN],
Q4.AddressLine1 SAddressLine1,
Q4.AddressLine2 SAddressLine2,
Q4.City SCity,
Q4.State SState,
Q4.Zip SZip,
Q4.ZipPlus4 SZipPlus4,
Q4.County SCountry,
Q7.Phone1 SPhone1,
AIU.NameOfFacAdmin,
NULL [DH-MAIL-TO-ATTEN-LN],
Q5.AddressLine1 MAddressLine1,
Q5.AddressLine2 MAddressLine2,
Q5.City MCity,
Q5.State MState,
Q5.Zip MZip,
Q5.ZipPlus4 MZipPlus4,
AIU.OutOfStateInd OutOfStateInd, 
Q1.ProviderTypeCode,
Q6.AccStatusValue1,
Q6.AccEffectiveBeginDate1,
Q6.AccEffectiveEndDate1,
Q6.AccStatusValue2,
Q6.AccEffectiveBeginDate2,
Q6.AccEffectiveEndDate2,
Q6.AccStatusValue3,
Q6.AccEffectiveBeginDate3,
Q6.AccEffectiveEndDate3,
Q6.AccStatusValue4,
Q6.AccEffectiveBeginDate4,
Q6.AccEffectiveEndDate4,
Q6.AccStatusValue5,
Q6.AccEffectiveBeginDate5,
Q6.AccEffectiveEndDate5
,Q6.CCodeIdentification1,Q6.CCodeDateEffDate1,Q6.CCodeDateExpDate1,Q6.CCodeIdentification2
,Q6.CCodeDateEffDate2,Q6.CCodeDateExpDate2,Q6.CCodeIdentification3,Q6.CCodeDateEffDate3,Q6.CCodeDateExpDate3
,Q6.CCodeIdentification4,Q6.CCodeDateEffDate4,Q6.CCodeDateExpDate4,Q6.CCodeIdentification5
,Q6.CCodeDateEffDate5,Q6.CCodeDateExpDate5,Q6.CCodeIdentification6,Q6.CCodeDateEffDate6,Q6.CCodeDateExpDate6,Q6.CCodeIdentification7
,Q6.CCodeDateEffDate7,Q6.CCodeDateExpDate7
,Q6.CCodeIdentification8,Q6.CCodeDateEffDate8,Q6.CCodeDateExpDate8,Q6.CCodeIdentification9
,Q6.CCodeDateEffDate9,Q6.CCodeDateExpDate9,Q6.CCodeIdentification10,Q6.CCodeDateEffDate10,Q6.CCodeDateExpDate10
,Q6.CCodeIdentification11,Q6.CCodeDateEffDate11,Q6.CCodeDateExpDate11,Q6.CCodeIdentification12
,Q6.CCodeDateEffDate12,Q6.CCodeDateExpDate12,Q6.CCodeDateExpDate13,Q6.CCodeIdentification13,Q6.CCodeDateEffDate13
,Q6.CCodeIdentification14,Q6.CCodeDateEffDate14,Q6.CCodeDateExpDate14
,Q6.CCodeIdentification15,Q6.CCodeDateEffDate15,Q6.CCodeDateExpDate15,Q6.CCodeIdentification16,Q6.CCodeDateEffDate16,Q6.CCodeDateExpDate16
,Q6.CCodeIdentification17,Q6.CCodeDateEffDate17,Q6.CCodeDateExpDate17,Q6.CCodeIdentification18,Q6.CCodeDateEffDate18,Q6.CCodeDateExpDate18
,Q6.CCodeIdentification19,Q6.CCodeDateEffDate19,Q6.CCodeDateExpDate19,Q6.CCodeIdentification20,Q6.CCodeDateEffDate20,Q6.CCodeDateExpDate20
,Q6.Speciality_Code1,Q6.SpecCertDate1,Q6.Speciality_Code2,Q6.SpecCertDate2,Q6.Speciality_Code3,Q6.SpecCertDate3,
AIU.SpecProcTypeCode,
AIU.IMDFacilType,
AIU.PracTypeCode1+AIU.PracTypeCode2 PracTypeCode,
Q1.ApplicationDate,
AIU.RejectReasonCode,
AIU.ExceptionIndicator,
AIU.ProvisionalCode,
AIU.ProvisionalCodeDate,
--Q1.ReenrollmentIndicator, --Changed the reference of these fields to EDM_AccountInternalUse by Sundar on 4Feb2019
--Q1.ReenrollmentDate,
AIU.ReEnrolInd ReenrollmentIndicator,
AIU.ReEnrolDate ReenrollmentDate,
Q2.Number,
Q2.LicenseBoardCode,
Q2.EffectiveDate,
K.CliaNumber,
K.CertificateType,
Q1.ProvTypeUpdateDate,
PD.EFT_Indicator,
AIU.CHDPCode
from Q1
Left Join KYPENROLLMENT.pAccount_Owner AO ON Q1.AccountID=AO.AccountID AND Q1.OwnerNo=AO.OwnerNo
Left Join KYPENROLLMENT.EDM_AccountInternalUse AIU on AIU.AccountID=Q1.AccountID
Left Join Q2 ON Q1.AccountID = Q2.AccountID
Left Join Q3 On Q1.AccountID=Q3.AccountID
Left Join Q4 On Q1.AccountID=Q4.AccountID
Left Join Q5 On Q1.AccountID=Q5.AccountID
Left Join KYPEnrollment.pAccount_PDM_Clia K on Q1.PartyID=K.PartyID AND K.CurrentRecordFlag=1
Left Join Q6 On Q1.AccountID=Q6.AccountID
Left Join Q7 on Q1.AccountID=Q7.AccountID
Left Join KYPENROLLMENT.pAccount_PDM_PaymentDetail PD on Q1.PartyID=PD.PartyID


GO

