









CREATE VIEW [KYPEnrollment].[v_MocaDetail]
AS
SELECT row_number() OVER (ORDER BY ParentPartyID ASC) AS ID, *
FROM         
(
select  distinct PRT.ParentPartyID,PRT.PartyID
,PRT.Type,CONVERT(varchar(10),PRT.MOCARelationshipStartDate,101) AS MOCASrtDT,
CONVERT(varchar(10),PRT.MOCARelationshipEndDate,101) AS MOCAEdDT,
CONVERT(varchar(10),PRT.DateDeleted,101)  AS MOCADelDT,
CONVERT(varchar(10),P.DOB,101) AS DOB,
Case when(PRT.Type='Individual Ownership')
then
P.LastName +''+P.FirstName
else
O.LegalName
END AS LegalName,

Case when(PRT.Type='Individual Ownership')
then
P.NPI
else
O.NPI
END AS NPI,

Case when(PRT.Type='Individual Ownership') then 
P.SSN else NULL End AS SSN,
Case when(PRT.Type='Entity Ownership') then 
 O.TIN ELSE NULL END AS TIN

from KYPEnrollment.pAccount_PDM_Party PRT
LEFT OUTER JOIN KYPEnrollment.pAccount_PDM_Person P on P.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Organization] O on O.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Provider] PVDR on PVDR.PartyID=PRT.PartyID
LEFT OUTER JOIN [KYPEnrollment].[pAccount_PDM_Owner_Role] ONR on ONR.PartyID=PRT.PartyID
where  AccountID=812272 and IsProvider=0 and   PRT.Type in ('Entity Ownership','Individual Ownership') 
AND CONVERT(VARCHAR, PRT.LastActionDate , 101) =  CONVERT(VARCHAR, GETDATE()-1, 101)
AND PRT.LastMOCAUpdateBy in('P','E','T')
) z






------------------------------------------- Close of MOCA Details file ------------------------------------------------------------------------------


GO

