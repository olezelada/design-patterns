

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_TaxIDAssocSignif_NewModel]
  @party_id               INT,
  @new_party_id           INT,
  @last_action_user_id    VARCHAR (100),
  @app_party_row_id       INT,
  @account_id             INT,
  @taxidprofileid         INT
AS
BEGIN
 BEGIN TRY
  DECLARE
     @party_adr           INT,
     @new_party_adr       INT,
     @count_association   INT,
     @main_party_id       INT,
     @is_prepopulated     BIT,
     @target_path         VARCHAR (200),
     @full_name_person    VARCHAR (100),
     @type                VARCHAR (50),
     @org_id              INT,
     @legal_name          VARCHAR (100),
     @person_id           INT;
  PRINT '[sp_Copy_TaxIDAssocSignif_NewModel]';
  print @party_id
        --Create  Associations      
        
        
       
           SELECT @new_party_id as PartyIDOwner,
                 case when par.IsPrepopulated =1 then
					 SUBSTRING (par.targetpath, CHARINDEX ('pAccount_PDM_Party|PartyID|', par.TargetPath, 1) + 27,LEN (par.targetpath)) 
				 else
                  (
                   select top 1 PartyID
                   from kypenrollment.pAccount_PDM_Party
                   where TempPartyID = o.PartyIDOwned
                   AND Type in (
                   'SignificantTransactionEntity',
                   'SignificantTransactionIndividual',
                    'SignificantOwnerIndividual',
                    'SignificantOwnerEntity'
                    )
                   AND IsDeleted = 0 AND CurrentRecordFlag = 1  
                   order by partyID asc
                  ) end as pOwned,
                  getdate () as datecreated,                                   --datecreated
                  0 as isdeleted,                                              --isdeleted
                  o.TypeAssociation,
                  'C' as lastaction,                                           --lastaction
                  getdate() as lastactiondate,                                --lastactiondate
                  @last_action_user_id as LastActorUserID,
                  @last_action_user_id as LastActionApprovedBy,
                  1 as currentRecordFlag,
                  o.OtherAssociation,
                  
                  TransDEscription,
                  isnull (
                      (SELECT TOP 1
                              partyID
                         FROM kypenrollment.pAccount_PDM_Party
                        WHERE TempPartyID = o.ParentPartyIDAssociation),
                      NULL)
                      AS pp,
                   @taxidprofileid as taxidprofileid
             into #temp_OwnerShip
             FROM KYPPORTAL.PortalKYP.pPDM_OwnershipRelationship o
             join kypportal.portalkyp.pPDM_Party par on o.PartyIDOwned=par.partyid
                     where o.PartyIDOwner = @party_id AND o.TypeAssociation  in ('ProviderSubcontractorAssociation', 'ProviderSubcontractorOwnerAssociation') AND o.IsDeleted = 0                                
 
        INSERT INTO [KYPEnrollment].[pAccount_PDM_OwnershipRelationship] (
                       [PartyIDOwner],
                       [PartyIDOwned],
                       [DateCreated],
                       [IsDeleted],
                       [TypeAssociation],
                       [LastAction],
                       [LastActionDate],
                       [LastActorUserID],
                       [LastActionApprovedBy],
                       [CurrentRecordFlag],
                       [OtherAssociation],
                       TransDescription,
                       ParentPartyIdAssociation,
                       taxIDProfileID)  
         SELECT t.* from  #temp_OwnerShip  t
         WHERE not exists (SELECT  * FROM [KYPEnrollment].[pAccount_PDM_OwnershipRelationship]  o
         WHERE t.pOwned = o.PartyIDOwned and t.taxidprofileid = o.taxIDProfileID)  
         --o.partyIDOwner = t.PartyIDOwner  and o.PartyIDOwned =t.pOwned ) 
  
         DROP TABLE  #temp_OwnerShip             
                            
   print 'salio'
   
   END TRY

	BEGIN CATCH
	   DECLARE @kval varchar(100)
	    SET @kval = CONVERT(varchar(100),  @taxidprofileid  );
		Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'TaxIDProfileID',@KeyValue=@kval
	END CATCH

END


GO

