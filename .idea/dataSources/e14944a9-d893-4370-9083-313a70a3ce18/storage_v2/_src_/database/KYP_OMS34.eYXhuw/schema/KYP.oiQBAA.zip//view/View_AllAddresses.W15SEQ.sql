

CREATE View [KYP].[View_AllAddresses] as
select distinct A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
	description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
		a1.County --,1 SortOrder
		from KYPPORTAL.PortalKYP.pPDM_Location l1 
		Inner join  KYPPORTAL.PortalKYP.pPDM_Address  A1 on l1.addressID=A1.addressID 
		Inner join  KYPPORTAL.PortalKYP.pADM_Application p1 on p1.PartyID=l1.PartyID 
		Inner join kyp.ADM_Case A2 on  A2.Number=p1.ApplicationNo  
Where A2.AccountNo is null
		and ((l1.type in ('Mailing','Servicing','Pay-To')
				and isnull(P1.FBPApp,0)=0) or (l1.type in ('Mailing','Pay-To')
				and P1.FBPApp=1)
				)
union all
select distinct A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
	description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
		a1.County--,2 SortOrder
		from KYPPORTAL.PortalKYP.pPDM_Location l1 
		Inner join  KYPPORTAL.PortalKYP.pPDM_Address  A1 on l1.addressID=A1.addressID 
		Inner join  KYPPORTAL.PortalKYP.pADM_Application p1 on p1.PartyID=l1.PartyID 
		Inner join kyp.ADM_Case A2 on  A2.Number=p1.ApplicationNo  
		join kypenrollment.padm_account Ac on A2.Accountno=Ac.Accountnumber
Where A2.AccountNo is not null
		and ((l1.type in ('Mailing','Servicing','Pay-To')
				and isnull(P1.FBPApp,0)=0) or (l1.type in ('Mailing','Pay-To')
				and P1.FBPApp=1)
				)
union all				
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,3 SortOrder	
from kyp.ADM_Case A2
	Join KYPPORTAL.PortalKYP.pADM_Application Ap on A2.Number=Ap.ApplicationNo
	Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A2.Number
	Join KYPEnrollment.pADM_Account A on R.group_providerNumber=A.Accountnumber
	Join KYPEnrollment.pAccount_PDM_Location l1 on A.PartyID=L1.PartyID
	join KYPEnrollment.pAccount_PDM_Address A1 on l1.addressID=A1.addressID 
	Where LEN(R.group_providerNumber)>8
	and A2.AccountNo is null
	and A2.Applntype in ('New Rendering','Rendering-S')
	and l1.type in ('Mailing','Servicing','Pay-To')
	and L1.isDeleted=0 and L1.CurrentRecordFlag=1
	and ((l1.type in ('Mailing','Servicing','Pay-To') and isnull(Ap.FBPApp,0)=0) 
			or (l1.type in ('Mailing','Pay-To') and Ap.FBPApp=1)
			)				
union all				
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,4 SortOrder	
from kyp.ADM_Case A2
	Join KYPPORTAL.PortalKYP.pADM_Application Ap on A2.Number=Ap.ApplicationNo
	Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A2.Number
	Join KYPEnrollment.pADM_Account A on R.group_providerNumber=A.Accountnumber
	Join KYPEnrollment.pAccount_PDM_Location l1 on A.PartyID=L1.PartyID
	join KYPEnrollment.pAccount_PDM_Address A1 on l1.addressID=A1.addressID
	Join kypenrollment.pADM_Account Ac on A2.AccountNo=Ac.AccountNumber 
	Where LEN(R.group_providerNumber)>8
	and A2.AccountNo is not null
	and Ac.AccountType in ('R','NMP')
	and l1.type in ('Mailing','Servicing','Pay-To')
	and L1.isDeleted=0 and L1.CurrentRecordFlag=1
	and ((l1.type in ('Mailing','Servicing','Pay-To') and isnull(Ap.FBPApp,0)=0) 
			or (l1.type in ('Mailing','Pay-To') and Ap.FBPApp=1)
			)	
union all
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,5 SortOrder	
from kyp.ADM_Case A2
	Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A2.Number
	Join KYPPORTAL.PortalKYP.pADM_Application A on R.group_providerNumber=A.ApplicationNo
	Join KYPPORTAL.PortalKYP.pPDM_Location l1 on A.PartyID=L1.PartyID
	join KYPPORTAL.PortalKYP.pPDM_Address  A1 on l1.addressID=A1.addressID 
	Where A2.AccountNo is null
	and LEN(R.group_providerNumber)=8
	and A2.Applntype in ('New Rendering','Rendering-S')	
	and ((l1.type in ('Mailing','Servicing','Pay-To') and isnull(A.FBPApp,0)=0) 
			or (l1.type in ('Mailing','Pay-To') and A.FBPApp=1)
			)	
union all					
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,6 SortOrder 
from kyp.ADM_Case A2
	Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on rendering_providerNumber = A2.Number
	Join KYPPORTAL.PortalKYP.pADM_Application A on R.group_providerNumber=A.ApplicationNo
	Join KYPPORTAL.PortalKYP.pPDM_Location l1 on A.PartyID=L1.PartyID
	join KYPPORTAL.PortalKYP.pPDM_Address  A1 on l1.addressID=A1.addressID 
	Join kypenrollment.pADM_Account Ac on A2.AccountNo=Ac.AccountNumber 	
	Where A2.AccountNo is not null
	and LEN(R.group_providerNumber)=8
	and Ac.AccountType in ('R','NMP')
	and l1.type in ('Mailing','Servicing','Pay-To')
	and ((l1.type in ('Mailing','Servicing','Pay-To') and isnull(A.FBPApp,0)=0) 
			or (l1.type in ('Mailing','Pay-To') and A.FBPApp=1)
			)
union all				
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,7 SortOrder	
from kyp.ADM_Case A2
	Join KYPPORTAL.PortalKYP.pADM_Application Ap on A2.Number=Ap.ApplicationNo
	Left Join KYPPORTAL.PortalKYP.pPDM_Location PL on Ap.PartyID=Pl.PartyID and Pl.Type in ('Mailing','Servicing','Pay-To')
	Left Join KYPPORTAL.PortalKYP.pRenderingAffiliation R on R.rendering_providerNumber = A2.Number
	Join KYPEnrollment.pADM_Account A on A2.AccountNo=A.Accountnumber
	Join KYPEnrollment.pAccount_PDM_Location l1 on A.PartyID=L1.PartyID
	join KYPEnrollment.pAccount_PDM_Address A1 on l1.addressID=A1.addressID
	Where A2.AccountNo is not null
	and Pl.LocationID is null
	and R.rendering_providerNumber is null
	and A.AccountType in ('R','NMP')
	and l1.type in ('Mailing','Servicing','Pay-To')
	and L1.isDeleted=0 and L1.CurrentRecordFlag=1
	and ((l1.type in ('Mailing','Servicing','Pay-To') and isnull(Ap.FBPApp,0)=0) 
			or (l1.type in ('Mailing','Pay-To') and Ap.FBPApp=1)
			)					
union all				
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,t1.ApplicationNo As ApplicationNo,'Servicing' Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,8 SortOrder
	from KYPPORTAL.PortalKYP.pADM_Application t1
	Join kyp.ADM_CASE A2 on T1.ApplicationNo=A2.Number
	Join (Select *
				From (Select a.ApplicationID,A.LocationID,B.AddressID,Row_number() over(Partition by a.ApplicationId order by a.IsDeleted, b.Approved desc,a.LocationID desc) R
						From KYPPORTAL.PortalKYP.pPDM_FBPAffiliations a
						Join KYPPORTAL.PortalKYP.pPDM_Location b on A.LocationID=b.LocationID
						Where b.Type='FacilityBusiness Address') c
				Where R=1
				) t2 on T1.ApplicationID=T2.ApplicationID
	Join KYPPORTAL.PortalKYP.pPDM_Address A1 on t2.AddressID=A1.AddressID
	Join KYPPORTAL.PortalKYP.pRenderingAffiliation t5 on T1.ApplicationNo=t5.rendering_providerNumber
	Join KYPPORTAL.portalkyp.pADM_Application t6 on T5.group_providerNumber=t6.ApplicationNo			
	Where t6.FBPApp=1
	and (A2.ApplnType in ('New Rendering','Supplemental')
	or (A2.Applntype = 'Rendering-S' and NOT exists (select Ac.AccountID From kypenrollment.padm_account Ac where Ac.AccountNumber=A2.AccountNo and Ac.AccountType='I'))
	)
Union all	
select
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,t1.ApplicationNo As ApplicationNo,'Servicing' Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,9 SortOrder
	From kypportal.PortalKYP.pADM_Application t1
	Join kyp.ADM_CASE A2 on T1.ApplicationNo=A2.Number
	Join (Select * 
			From (Select P.ParentPartyID,L.AddressID,ROW_NUMBER() Over(Partition by P.ParentPartyid Order by L.Approved desc,L.LocationID desc) R
				From KYPPORTAL.PortalKYP.pPDM_Party P
				Join KYPPORTAL.PortalKYP.pPDM_Location L on P.PartyID=L.PartyID
				where P.IsDeleted=0
				and L.Type='FacilityBusiness Address') T
				Where R=1) P on t1.PartyID=P.ParentPartyID
	--Join KYPPORTAL.PortalKYP.pPDM_Location L1 on P.LocationID=L1.LocationID
	Join KYPPORTAL.PortalKYP.pPDM_Address A1 on A1.AddressID=P.AddressID
	where t1.FBPApp=1
union all
select  A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where
        description = a1.state and TypeID='4') as statecode,a1.AddressLine2,t1.Number As ApplicationNo,'Servicing' Type,T1.ApplnType,T1.AccountNo,T1.Group_AccountNumber,
        a1.County--,10 SortOrder
                From kyp.ADM_CASE T1
                Join kypportal.portalkyp.pADM_Application t2 on t1.Number=t2.ApplicationNo
                Join (Select ParentPartyID,Max(PartyID) PartyID
                        From KYPPORTAL.PortalKYP.ppdm_party
                        Where Type='BusinessProfileOrp'
                        Group by ParentPartyID) P on T2.PartyID=P.ParentPartyID
                Join KYPPORTAL.PortalKYP.pPDM_Location L1 on P.PartyID=L1.PartyID
                Join KYPPORTAL.PortalKYP.pPDM_Address A1 on L1.AddressID=A1.AddressID
                Where 
                --T1.WFMajorStep<>'Completed'
                --and T1.MILESTONE<>'Closed' and 
                T1.P_PRACT_TY_CD='ORP'
Union all                
select distinct 
A1.AddressId,A1.AddressLine1,A1.City,a1.ZipPlus4,(select Abreviation from kyp.LK_Screening where 
description = a1.state and TypeID='4') as statecode,a1.AddressLine2,a2.Number As ApplicationNo,l1.Type,A2.ApplnType,A2.AccountNo,A2.Group_AccountNumber,  
a1.County--,11 SortOrder	
from kyp.ADM_Case A2
	Join kypEnrollment.pADM_Account RAc on Rac.AccountNumber = A2.AccountNo
	Join KYPEnrollment.pAccount_PDM_Location l1 on RAc.PartyID=L1.PartyID
	join KYPEnrollment.pAccount_PDM_Address A1 on l1.addressID=A1.addressID 
	Where A2.Applntype = 'Rendering-S'
	and Rac.AccountType='I'
	and l1.type in ('Mailing','Servicing','Pay-To')
	and L1.isDeleted=0 and L1.CurrentRecordFlag=1
GO

