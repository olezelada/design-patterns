

CREATE VIEW [KYP].[v_ApplicationDetails]
AS
SELECT     row_number() OVER (ORDER BY Number ASC) AS ID, *
FROM     (
SELECT     KYP.ADM_Case.Risk, KYP.ADM_Case.Number as Number,KYP.ADM_Case.PAN as PAN, KYP.ADM_Case.ProviderName, KYP.ADM_Case.TypeDescription, KYP.OIS_User.FullName, 
                      KYP.ADM_Case.DateReceived, KYP.ADM_Case.DateAssigned, KYP.ADM_Case.DateResolved, KYP.ADM_Case.WFMinorStep AS StatusName, 
                      KYP.ADM_Case.StatusCodeNumber
FROM         KYP.ADM_Case LEFT OUTER JOIN
                     KYP.OIS_User ON KYP.ADM_Case.CurrentlyAssignedToID = KYP.OIS_User.PersonID 
WHERE IsPPURequired = 0

) Q


GO

