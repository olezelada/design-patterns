


CREATE VIEW [KYPEnrollment].[v_Portable_ServAddrImaging]
As

With Q1 as (Select T1.PartyID,T3.AddressLine1,T3.AddressLine2,T3.City,T3.State,T3.Zip,T3.ZipPlus4,T3.County,T4.Number,
					T2.Type Ad_Type, T4.Type Li_Type,T1.ParentPartyID
					,T3.AddressID,T4.NumberID
			From kypenrollment.pAccount_PDM_Party T1
			Join kypenrollment.pAccount_PDM_Location T2 on T1.PartyID=T2.PartyID
			Join kypenrollment.paccount_pdm_address T3 on T2.AddressID=T3.AddressID
			Join kypenrollment.pAccount_PDM_Number T4 on T1.PartyID=T4.PartyID
			Where T2.IsDeleted = 0
				and T2.CurrentRecordFlag = 1
				and T3.CurrentRecordFlag = 1
				--and T4.Type = 'ServAddrImagingLic'
				)
,Q2 as (Select *
			from Q1
			Where Ad_Type = 'Servicing'
				and Li_Type = 'ServAddrImagingLic'
				and ParentPartyID is null)
Select Q2.PartyID,Q2.AddressLine1,Q2.AddressLine2,Q2.City,Q2.State,Q2.Zip,Q2.ZipPlus4,Q2.County,Q2.Number,Q2.AddressID,Q2.NumberID,
Q2.AddressLine1+', '+Q2.AddressLine2+', '+Q2.City+', '+Q2.State+', '+Q2.ZipPlus4+', '+Q2.County As FullAddress
from Q2				
Union all
Select Q1.ParentPartyID,Q1.AddressLine1,Q1.AddressLine2,Q1.City,Q1.State,Q1.Zip,Q1.ZipPlus4,Q1.County,Q1.Number,Q1.AddressID,Q1.NumberID,
Q1.AddressLine1+', '+Q1.AddressLine2+', '+Q1.City+', '+Q1.State+', '+Q1.ZipPlus4+', '+Q1.County As FullAddress
From Q1	
Join Q2 on Q1.ParentPartyID = Q2.PartyID	
Where Q1.Ad_Type = 'ServAddrImagingLicPermit'
	and Q1.Li_Type = 'ServAddrImagingLicPermit'


GO

