
-- =============================================
-- Author:		Nitish Gondkar
-- Create date: 08-Oct-2014
-- Description:	Map Provider Staging Full
-- =============================================
CREATE PROCEDURE [KYP].[p_Map_ProvidersForTheDay]	
AS
BEGIN
		INSERT INTO [dbo].[ProvidersForTheDay]
		(
			FileType,
			P_ID			
		)
		SELECT 
			CASE [Column 0] WHEN '' THEN NULL ELSE LTRIM(RTRIM([Column 0])) END,
			CASE [Column 2] WHEN '' THEN NULL ELSE LTRIM(RTRIM([Column 2])) END				
		FROM [dbo].[ProviderStagingFull]		
END


GO

