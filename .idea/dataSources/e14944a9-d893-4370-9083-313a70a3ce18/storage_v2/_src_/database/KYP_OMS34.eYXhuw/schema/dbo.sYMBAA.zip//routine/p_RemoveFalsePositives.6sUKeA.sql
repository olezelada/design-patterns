-- =============================================
-- Description:	Handles the regeneration of alerts based on the values provided for the status either False Positive or Ignored
-- =============================================
CREATE PROCEDURE [dbo].[p_RemoveFalsePositives]
AS
BEGIN
	DECLARE @currentDate datetime
	
	/** Getting recent provider load month and year **/
	SELECT TOP 1 @currentDate = fileloaddate
		FROM KYP.MDM_MonthlyActiveProvider
	ORDER BY fileloaddate DESC

	/** Getting parties of the closed alerts in the system **/
	SELECT alertid
	INTO #watchedPartyIds
	FROM kyp.MDM_Alert
	WHERE MatchStatusIndicator NOT IN (
			'U'
			,'C'
			)
		AND WFStatus = 'Completed'

	/** Getting all the closed alerts in the system **/
	SELECT *
		,0 AS ispartymodified
	INTO #tmpAlerts
	FROM kyp.MDM_Alert
	WHERE AlertID IN (
			SELECT alertid
			FROM #watchedPartyIds
			)
		OR AlertID IN (
			SELECT ChildAlertID
			FROM kyp.MDM_RelatedAlerts
			WHERE ParentAlertID IN (
					SELECT alertid
					FROM #watchedPartyIds
					)
				AND IsDeleted = 0
			)

	/** Updating the PartyDataModifiedDate for the parties that has data change in the recent provider load **/
	UPDATE x
	SET x.ispartymodified = 1
	FROM #tmpAlerts x
	INNER JOIN kyp.PDM_Party y ON x.WatchedPartyID = y.PartyID
	WHERE y.PartyDataModifiedDate> @currentDate

	SELECT x.PartyID
		,x.WatchedPartyType
		,x.WatchlistName
		,x.FName
		,x.MName
		,x.LName
		,x.OrganizationName
		,x.SnoozeDate
		,x.WatchlistPartyID
		,x.DataChanged
		,x.AlertStatus
		,x.alertid
		,z.UniqueKey
		,z.LicenseNo
		,z.License_State
		,z.Offense_Code
		,z.Board_Code
		,z.Action_Code
		,z.NPIID
		,y.GK_WL_ID
		,y.MatchStatusIndicator
		,y.ispartymodified
		,cast('' AS INT) AS snoozedatediff
		,y.MatchPercent
		,y.CreatedDate
	INTO #tmpFalseAlerts
	FROM KYP.MDM_FalsePositiveAlert x
	INNER JOIN #tmpAlerts y ON x.AlertID = y.AlertID
	LEFT JOIN kyp.MDM_AlertDetail z ON y.AlertId = z.AlertID

	/** Updating szooze date for the IGNORED alerts **/
	/** Differences are in minute, (-ve difference denotes it is not passed snooze date, +ve difference denotes it is passed szooze date) **/
	UPDATE x
	SET x.snoozedatediff = DATEDIFF(MINUTE, x.SnoozeDate, GETDATE())
	FROM #tmpFalseAlerts x
	WHERE x.SnoozeDate IS NOT NULL
		AND x.MatchStatusIndicator = 'I'

	/** False Positive Alerts : FP = 3 : Either Watchlist/Enrollment Record updated **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND x.WatchlistName = y.WatchlistName
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 3
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** False Positive Alerts : FP = 3 : Either Watchlist/Enrollment Record updated **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND x.WatchlistName = y.WatchlistName
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 3
		AND y.WatchlistName IN ('License Status')

	/** False Positive Alerts : FP = 3 : Either Watchlist/Enrollment Record updated **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND x.WatchlistName = y.WatchlistName
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 3
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)

	/** False Positive Alerts : FP = 4 : Forever do not generate the alerts **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 4
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** False Positive Alerts : FP = 4 : Forever do not generate the alerts **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 4
		AND y.WatchlistName IN ('License Status')

	/** False Positive Alerts : FP = 4 : Forever do not generate the alerts **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 4
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)

	/** False Positive Alerts : FP = 1 : Only enrollment record updated **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 1
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** False Positive Alerts : FP = 1 : Only enrollment record updated **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 1
		AND y.WatchlistName IN ('License Status')

	/** False Positive Alerts : FP = 1 : Only enrollment record updated **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
		AND y.ispartymodified = 0
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 1
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)

	/** False Positive Alerts : FP = 2 : Only watchlist record updated **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 2
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** False Positive Alerts : FP = 2 : Only watchlist record updated **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 2
		AND y.WatchlistName IN ('License Status')

	/** False Positive Alerts : FP = 2 : Only watchlist record updated **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'F'
		AND y.DataChanged = 2
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)

	/** Ignored Alerts : Either watchlist/enrollment updated **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND y.ispartymodified = 0
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'I'
		AND y.SnoozeDate IS NULL
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** Ignored Alerts : Either watchlist/enrollment updated **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
		AND y.ispartymodified = 0
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'I'
		AND y.SnoozeDate IS NULL
		AND y.WatchlistName IN ('License Status')

	/** Ignored Alerts : Either watchlist/enrollment updated **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
		AND y.ispartymodified = 0
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		--AND coalesce(cast(x.lastloaddate AS DATETIME), '') <= coalesce(cast(y.CreatedDate AS DATETIME), '')
	WHERE y.MatchStatusIndicator = 'I'
		AND y.SnoozeDate IS NULL
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)

	DELETE
	FROM #tmpFalseAlerts
	WHERE MatchStatusIndicator = 'I'
		AND snoozedate IS NULL

	/** Ignored Alerts : Snooze date not passed (60 days, 90 days, 1 year) **/
	/** 'SAM', 'OIG LEIE', 'NPI Issues', 'SSA DMF', 'Internal Watchlist' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
	WHERE y.MatchStatusIndicator = 'I'
		AND y.snoozedatediff <= 0
		AND y.WatchlistName IN (
			'SAM'
			,'OIG LEIE'
			,'NPI Issues'
			,'SSA DMF'
			,'Internal Watchlist'
			)

	/** Ignored Alerts : Snooze date not passed (60 days, 90 days, 1 year) **/
	/** 'License Status' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND right(coalesce(x.License_Number, ''), 4) = right(coalesce(y.LicenseNo, ''), 4)
		AND coalesce(x.License_State, '') = coalesce(y.License_State, '')
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
	WHERE y.MatchStatusIndicator = 'I'
		AND y.snoozedatediff <= 0
		AND y.WatchlistName IN ('License Status')

	/** Ignored Alerts : Snooze date not passed (60 days, 90 days, 1 year) **/
	/** 'Sanction Status', 'Medicaid & Medicare Exclusion' **/
	DELETE x
	FROM kyp.MDM_StageAlerts x
	INNER JOIN #tmpFalseAlerts y ON x.PartyID = y.PartyID
		AND coalesce(x.watchlistpartyid, '') = coalesce(y.NPIID, '')
		AND x.WatchlistName = y.WatchlistName
		AND coalesce(x.Board_Code, '') = coalesce(y.Board_Code, '')
		AND coalesce(x.Offense_Code, '') = coalesce(y.Offense_Code, '')
		AND coalesce(x.Action_Code, '') = coalesce(y.Action_Code, '')
	WHERE y.MatchStatusIndicator = 'I'
		AND y.snoozedatediff <= 0
		AND cast(x.matchpercentage AS INT) <= cast(y.MatchPercent AS INT)
		AND y.WatchlistName IN (
			'Sanction Status'
			,'Medicaid & Medicare Exclusion'
			)
END
GO

