-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <20/09/2017>
-- Description:	<This procedure copy operators data from Portal to Enrollment>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Operator]
	@new_Party_Id INT,
	@operatorid int,
	@last_Action_User_ID VARCHAR(100)


AS
BEGIN
	
	DECLARE @date_created DATE;
	SET @date_created = GETDATE();
	
	SET NOCOUNT ON;

IF EXISTS (SELECT  TABLE_NAME from	INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'pAccount_PDM_Operator')
	
	begin

    INSERT INTO KYPEnrollment.pAccount_PDM_Operator (

    PartyId,
    DriverLicenseNumber,
    ExpirationDate,
    OperatorLicNumber,
    OperatorType,
    IsDeleted,
    Approved,
    LastAction,
    LastActionDate,
    LastActionUserID,
    CurrentRecordFlag,
    DateCreated,
      EffectiveDate,
      OperatorLegalName
    ) 
    
	SELECT 
	
    @new_Party_Id,
    DriverLicenseNumber,
    ExpirationDate,
    OperatorLicNumber,
    OperatorType,
    0,
    1,
    'C',
    @date_created,
    @last_Action_User_ID,
    1, 
	@date_created,
    EffectiveDate,
    OperatorLegalName
	    
    from KYPPORTAL.PortalKYP.pPDM_Operators where OperatorId = @operatorid and Approved=1 and IsDeleted=0
    
    
    
    end
    
  
    
    
    
END


GO

