

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Pharmacy_Information]
   @party_id               INT,
   @new_party_id           INT,
   @last_action_user_id    VARCHAR (100),  
   @app_party_row_id       INT,
   @account_id             INT,
   @is_group               BIT = 0
AS
BEGIN
      
   PRINT '[sp_Copy_Pharmacy_Information]';

   --new account
   IF @app_party_row_id IS NULL
      BEGIN
         DECLARE @party TABLE
                        (
                           pk               INT IDENTITY (1, 1),
                           PartyID          INT,
                           IsPrepopulated   BIT,
                           TargetPath       VARCHAR (200),
                           Type             VARCHAR (50)
                        )
                        
         
		DECLARE @date_created DATE;
		SET @date_created =  GETDATE();
	                        
         INSERT INTO @party
            SELECT p.PartyID,
                   p.IsPrepopulated,
                   p.TargetPath,
                   p.type
              FROM Kypportal.PortalKYP.pPDM_Party p
             WHERE     ParentPartyID = @party_id
                   AND p.type in ('PharmacistInformation')

         	DECLARE @date_Create DATE;
		   	SET @date_Create = GETDATE()
		   	declare @newparty table (partEnroll int,partPortal int)
			
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Party]	
			([Type] ,
			[Name] ,
			[IsProvider] ,
			[IsEnrolled] ,
			[IsTemp] ,
			[IsActive] ,
			[LoadType] ,
			[LoadID] ,
			[LastLoadDate] ,
			[IsDeleted],
			[DateModified] ,
			[CurrentRecordFlag] ,
			[Source] ,
			[LastAction] ,
			[LastActionDate] ,
			[profile_id],
			[ParentPartyID],
			[AccountID],
			[LastActorUserID],
			[LastActionApprovedBy],
			temppartyid)
			output inserted.PartyID,inserted.TempPartyID into @newparty
			SELECT [Type]
			,[Name]
			,[IsProvider]
			,[IsEnrolled]
			,[IsTemp]
			,[IsActive]
			,[LoadType]
			,[LoadID]
			,[LastLoadDate]
			,[IsDeleted]
			,[DateModified]
			,1
			,[Source]
			,'C'
			,@date_Create
			,[profile_id]
			,@new_party_id
			,@account_id
			,@last_action_user_id
			,@last_action_user_id
			,partyid
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Party] WHERE PartyID in (select PartyID from @party) AND IsDeleted = 0
			
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Person]
           ([PartyID]
           ,[SSN]
           ,[FirstName]
           ,[LastName]
           ,[MiddleName]
           ,[Gender]
           ,[DoB]
           ,[Email1]
           ,[Remark]
           ,[CreatedBy]
           ,[Prefix]
           ,[Sufix]
           ,[ProfessionalTitle]
           ,[DateCreated]
           ,[Position]
           ,[Extension]
           ,[Phone1]
           ,[Phone2]
           ,[FaxNumber]
           ,[Deleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[Salutation]
           ,[NPI] )

			SELECT nuevo.partenroll,
			[SSN],
			[FirstName],
			[LastName],
			[MiddleName],
			[Gender],
			[DoB],
			[Email1],
			[Remark],
			[CreatedBy],
			[Prefix],
			[Sufix],
			[ProfessionalTitle],
			@date_created,
			[Position],
			[Extension],
			[Phone1],
			[Phone2],
			[FaxNumber],
			[Deleted],
			'C',
			 @date_created,
			 @last_action_user_id,
			 @last_action_user_id,
			 1,
			 ProfessionalTitle,
			[NPI]
   
			 FROM [KYPPORTAL].[PortalKYP].[pPDM_Person] per inner join @newparty nuevo on per.PartyID=nuevo.partportal
        
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Document]
			([PartyID]
			 ,[TypeDoc]
			 ,[NumberDoc]
			 ,[StateIssued]
			 ,[CreatedBy]
			 ,[DateCreated]
			 ,[IsDeleted]
			 ,[LastAction]
			 ,[LastActionDate]
			 ,[LastActorUserID]
			 ,[LastActionApprovedBy]
			 ,[CurrentRecordFlag])
      
			SELECT nuevo.partenroll,
			[TypeDoc],
			[NumberDoc],
			[StateIssued],
			[CreatedBy],
			@date_created,
			[IsDeleted],
			'C',
			@date_created,
			@last_action_user_id,
			@last_action_user_id,
			1
			FROM [KYPPORTAL].[PortalKYP].[pPDM_Document] doc inner join @newparty nuevo on doc.PartyID=nuevo.partportal
     
			INSERT INTO [KYPEnrollment].[pAccount_PDM_Number]
			 ([PartyID]
			   ,[Type]
			   ,[CreatedBy]
			   ,[DateCreated]
			   ,[IsDeleted]
			   ,[Number]
			   ,[LastAction]
			   ,[LastActionDate]
			   ,[LastActorUserID]
			   ,[LastActionApprovedBy]
			   ,[CurrentRecordFlag])
			SELECT    nuevo.partEnroll 
			   ,[LicenseType]
			   ,[CreatedBy]
			   ,@date_created
			   ,[IsDeleted]
			   ,[LicenseCode]
			   ,'C'
			   ,@date_created
			   ,@last_action_user_id
			   ,@last_action_user_id
			   ,1

			FROM [KYPPORTAL].[PortalKYP].[pPDM_License] lic inner join @newparty nuevo on lic.PartyID=nuevo.partportal 
			
			-------*****
            update kypenrollment.paccount_pdm_party set TempPartyID=null where PartyID in (select partenroll from @newparty)
            
       
      END

 
END

GO

