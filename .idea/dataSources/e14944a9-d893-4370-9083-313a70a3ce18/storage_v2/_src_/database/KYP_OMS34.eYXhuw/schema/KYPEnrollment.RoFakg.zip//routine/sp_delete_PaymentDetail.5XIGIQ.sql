-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <13/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the residential address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_PaymentDetail] 
@new_Account_Id int

AS
BEGIN
Declare @payment int
	SET NOCOUNT ON;

select @payment = p.PaymentDetailID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_PaymentDetail p ON a.PartyID=p.PartyID
where p.IsDeleted=0 and p.CurrentRecordFlag=1 and a.IsDeleted=0 and a.AccountID=@new_Account_Id

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_PaymentDetail','PaymentDetailID',@payment

END


GO

