
CREATE PROCEDURE [KYPEnrollment].[MDTPackageBufferProvider]

		@applicatioNo VARCHAR(50),
	  @caseId INT

AS
	BEGIN

		SET NOCOUNT ON;

DECLARE @exist_air_vehicle bit,@exist_air_operator bit,@exist_ground_vehicle bit,@exist_ground_operator bit,@tot int, @cont int,@add int,@buf varchar(100);
declare @types table (pk int identity(1,1),type varchar(100))
declare @NonMedicalVehicle bit,@NonMedicalOperator bit

		INSERT INTO @types (type)
	    select o.OperatorType from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p on a.PartyID=p.ParentPartyID inner join 
	    KYPPORTAL.PortalKYP.pPDM_Operators o on p.PartyID=o.PartyId and a.ApplicationNo=@applicatioNo and a.IsDeleted=0 and p.IsDeleted=0 and o.Approved=1 and o.IsDeleted=0
	    
   		INSERT INTO @types (type)
	    select o.VehicleType from KYPPORTAL.PortalKYP.pADM_Application a inner join KYPPORTAL.PortalKYP.pPDM_Party p on a.PartyID=p.ParentPartyID inner join 
	    KYPPORTAL.PortalKYP.pPDM_Vehicle o on p.PartyID=o.PartyId and a.ApplicationNo=@applicatioNo and a.IsDeleted=0 and p.IsDeleted=0 and o.Approved=1 and o.IsDeleted=0

			IF exists(select * from @types where type in ('Pilot'))
			begin
				set @exist_air_operator = 1
			end

			IF exists(select * from @types where type in ('Aircraft'))
			begin
				set @exist_air_vehicle = 1
			end	

			IF exists(select * from @types where type in ('AmbulanceDriver','LitterWheelchairVanDriver'))
			begin
				set @exist_ground_operator = 1
			end

			IF exists(select * from @types where type in ('Ambulance','Van'))
			begin
				set @exist_ground_vehicle = 1	
			end

			IF exists(select * from @types where type in ('Non-Medical Operator'))
			begin
				set @NonMedicalOperator = 1
			end

			IF exists(select * from @types where type in ('Non-Medical Vehicle'))
			begin
				set @NonMedicalVehicle = 1	
			end


		IF exists(SELECT ApplicationID
							FROM KYPPORTAL.PortalKYP.pADM_Application a
							WHERE a.ApplicationNo = @applicatioNo
							and @exist_air_operator=1 and @exist_air_vehicle=1)
			BEGIN
				INSERT INTO #tempProviderType(tempProviderType, appName, AccountNumber)
        VALUES('038', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 110000000+@caseId)))
			END

		IF exists(SELECT ApplicationID
							FROM KYPPORTAL.PortalKYP.pADM_Application a
							WHERE a.ApplicationNo = @applicatioNo
							and ((@exist_ground_operator=1 and @exist_ground_vehicle=1) OR (@NonMedicalOperator = 1 and @NonMedicalVehicle = 1)))
			BEGIN
				INSERT INTO #tempProviderType(tempProviderType, appName, AccountNumber)
        VALUES('030', @applicatioNo, CONVERT(VARCHAR(20), CONVERT(INT, 120000000+@caseId)))
			END

	END
GO

