

/* ==========================================================
-- Author:		<Ralba,TJaldin,JHuanca>
-- PROCEDURE: create Payment Detail form.   
-- PARAMETERS: 
-- @party_id: partyID Application that will be Account. 
-- @new_party_Id : partyID to new Account that will be create. 
-- @last_action_user_id : this is the user Enrollment.
-- ============================================================*/

CREATE PROCEDURE [KYPEnrollment].[sp_Copy_PaymentDetail]
@party_id INT,
@new_party_id INT,
@last_action_user_id VARCHAR(100)
AS
BEGIN 
SET NOCOUNT ON
DECLARE @date_Created SMALLDATETIME
SET @date_Created =  CURRENT_TIMESTAMP;
INSERT INTO [KYPEnrollment].[pAccount_PDM_PaymentDetail]
           ([PartyID]
           ,[TypeOfPayment]
           ,[BankpAccountNumber]
           ,[RoutingNumber]
           ,[BankName]
           ,[StreetName]
           ,[City]
           ,[ZipPlus4]
           ,[County]
           ,[StateTrans]
           ,[CreatedBy]
           ,[DateCreated]
           ,[IsDeleted]
           ,[LastAction]
           ,[LastActionDate]
           ,[LastActorUserID]
           ,[LastActionApprovedBy]
           ,[CurrentRecordFlag]
           ,[ProviderName]
           ,[ProviderContact]
           ,[ReasonForSubmission]
           ,[UpdateAll]
	     -- ,[EFT_Indicator]
	      ,[Temp_EFT_Indicator]
           )
SELECT @new_party_id
       ,[TypeOfPayment]
       ,[BankAccountNumber]
       ,[RoutingNumber]
       ,[BankName]
       ,[StreetName]
       ,[City]
       ,[ZipPlus4]
       ,[County]
       ,[StateTrans]
       ,[CreatedBy]
       ,@date_Created
       ,[IsDeleted]
       ,'C'
       ,@date_Created
       ,@last_action_user_id
       ,@last_action_user_id
       ,1
       ,[ProviderName]
       ,[ProviderContact]
       ,[ReasonForSubmission]
       ,[UpdateAll]   
       ,CASE
                  WHEN [HasEftInfoChange] is not NULL
                  THEN [HasEftInfoChange]
                  WHEN [TypeOfPayment] is not NULL
                  THEN 'Y' 
                  ELSE 'N'
         END

FROM [KYPPORTAL].[PortalKYP].[pPDM_PaymentDetail] WHERE PartyID=@party_id
PRINT 'New PaymentDetail'           
END

GO

