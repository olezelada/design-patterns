

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE  PROCEDURE [KYP].[p_UpdateAlertonAccount]
 @alertID INT
,@CurrentlyAssignedToID VARCHAR(50)
,@CurrentlyAssignedByID VARCHAR(50)
,@MatchStatusIndicatordecription VARCHAR(15)
,@WatchlistName VARCHAR(50)
,@AlertRelevance varchar(20)
,@AlertCreatedDate datetime
,@AlertCreatedBy int
,@Medicaid_id varchar(20)
,@CurrentWFStatus VARCHAR(100)
,@AlertNumber VARCHAR(15)
,@DateResolved SMALLDATETIME
,@PartyID int
,@Priority VARCHAR(15)
,@PartyName Varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	DECLARE @status VARCHAR(50)=''
	--,@StatusReason VARCHAR(50)=NULL
	,@Names VARCHAR(MAX)
	,@id int
	,@Comments Varchar(200)
	,@AccountID int
	,@ProviderID VarChar(50)
	,@childAlertCheck bit =0,
	@HIS_AlertDateResolved SMALLDATETIME=NULL
	
	
	select  @childAlertCheck=1  from kyp.MDM_RelatedAlerts RA where  RA.MergedByUserID=1 and RA.ChildAlertID=@alertID

	
	 INSERT into   KYPEnrollment.pAccount_History 
	     (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
	    select distinct PH.RelatedID,PH.AccountID,'54' ,PH.DateCreated,@CurrentlyAssignedToID,GETDATE() ,'1' 
	     from  KYPEnrollment.pAccount_History PH 
	     where PH.RelatedID=@alertID and PH.ActionID='53'
	     
	     
     INSERT into KYPEnrollment.HIS_Alert
      (AccountID,HistoryID,AlertNumber,MonStatus,MonRelevance,ModifiedBy,
      DateCreate,WatchlistCategory,DateModify,AlertPartyName) 		
	select distinct PH.AccountID,PH.HistoryID,@AlertNumber,@MatchStatusIndicatordecription,
	 @Priority,@CurrentlyAssignedToID,@AlertCreatedDate,@WatchlistName,@DateResolved,
	@PartyName
	from  KYPEnrollment.pAccount_History PH 
	 where PH.RelatedID=@alertID and PH.ActionID='54'
	   
	  
	   
	   IF (	@CurrentWFStatus = 'Completed' and @childAlertCheck=1 )
	     BEGIN
	 				UPDATE HA set 
							HA.MonResolution=i.List_Output
					  FROM  KYPEnrollment.HIS_Alert HA
					  
					  inner join (  select @AlertNumber AlertNO,Acc.AccountID, 
	  						  STUFF((SELECT ', ' + CAST(Res.ResolutionType AS VARCHAR(MAX)) [text()]
									FROM kyp.MDM_AlertResolution Res
									WHERE Res.ProviderID=PR.ProviderID and Res.AlertID=RA.ParentAlertID and Res.IsDeleted=0 and
										 Res.ResolutionType in ('Suspend Account Temporarily',
										 'Suspend Account', 'Deactivate Account','Deactivate Provider As Deceased',
										 'Add to Internal Watch list','Enrollment Record Updated',
										 'Letter Sent to Provider','Notify Provider','Initiate Re-enrollment',
										 'Refer for Investigation','Refer to Legal','Refer to Program Integrity',
										 'Update Account')
								FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') List_Output
								from    KYPEnrollment.pAccount_History PH
								--inner join KYPEnrollment.pAccount_History PH on PH.AccountID=HR.AccountID
								inner join kyp.MDM_RelatedAlerts RA on   RA.ChildAlertID=@alertID and RA.MergedByUserID=1
								inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=PH.AccountID 
								inner join KYP.MDM_SearchProviders PR on PR.MedicaidID=Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode and PR.AlertID=RA.ParentAlertID
								where PH.RelatedID=@alertID and   PH.ActionID='54'
								--from   KYP.MDM_SearchProviders PR 
								--inner join  KYPEnrollment.HIS_Alert HR on HR.AlertNumber=@AlertNumber
								--where PR.AlertID=@alertID
								
								  ) i on i.AlertNO=HA.AlertNumber and i.AccountID=HA.AccountID
						 
		  END
	    
	   ELSE IF (
			@CurrentWFStatus = 'Completed' and @childAlertCheck=0 )
	     BEGIN
						
							
						UPDATE HA set 
							HA.MonResolution=i.List_Output
					  FROM  KYPEnrollment.HIS_Alert HA
					  
					  inner join (   select  @AlertNumber   AlertNO,Acc.AccountID, 
	  						  STUFF((SELECT ', ' + CAST(Res.ResolutionType AS VARCHAR(MAX)) [text()]
									FROM kyp.MDM_AlertResolution Res
									WHERE Res.ProviderID=PR.ProviderID and Res.AlertID=@alertID and Res.IsDeleted=0 and
										 Res.ResolutionType in ('Suspend Account Temporarily',
										 'Suspend Account', 'Deactivate Account','Deactivate Provider As Deceased',
										 'Add to Internal Watch list','Enrollment Record Updated',
										 'Letter Sent to Provider','Notify Provider','Initiate Re-enrollment',
										 'Refer for Investigation','Refer to Legal','Refer to Program Integrity',
										 'Update Account')
								FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') List_Output
								from    KYPEnrollment.pAccount_History PH 							
								inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=PH.AccountID 
								inner join KYP.MDM_SearchProviders PR on PR.MedicaidID=Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode and PR.AlertID=@alertID
								where  PH.RelatedID=@alertID and   PH.ActionID='54' 
								
								  ) i on i.AlertNO=HA.AlertNumber and i.AccountID=HA.AccountID
					
				
				select @Comments=NotesDescription from  kyp.MDM_AlertAssignTracker  where AlertNo like '%@alertID%'
						
				IF OBJECT_ID('tempdb..#tmp', 'U') IS NOT NULL
						DROP TABLE dbo.#tmp
							
						CREATE TABLE #tmp (ProviderID INT , AccID INT,HisID INT ,oldSts VARCHAR(50) COLLATE SQL_Latin1_General_CP1_CI_AS,  newSts VARCHAR(100)  COLLATE SQL_Latin1_General_CP1_CI_AS null )
				  
						insert into #tmp( ProviderID,AccID,HisID,oldSts,newSts)
						select distinct PR.ProviderID, PH.AccountID,PH.HistoryID,Acc.StatusAcc,IUD.EnrollStatusAcc
						from KYPEnrollment.pAccount_History  PH
						inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=PH.AccountID 
						inner join KYP.MDM_SearchProviders PR on PR.MedicaidID=Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode and PR.AlertID =@alertID						
						inner join kyp.MDM_AlertResolution Res on  Res.ProviderID=PR.ProviderID and Res.AlertID=@alertID
						inner join KYPEnrollment.EDM_AlertlInternalUse IUD on Acc.AccountID=IUD.AccountID and IUD.AlertID=@alertID
						where Res.IsDeleted=0 and PH.RelatedID=@alertID and PH.ActionID='54'
						

/* commiting code for IUD cnages By Rahul Raghavendra 
						  UPDATE #tmp  set newSts ='2 - INACTIVE'
										from (select PR.ProviderID from  KYP.MDM_SearchProviders PR 
													inner join kyp.MDM_AlertResolution Res on  Res.ProviderID=PR.ProviderID and PR.AlertID =@alertID
													where  Res.IsDeleted=0  and Res.ResolutionType = 'Deactivate Account'  ) i
						where #tmp.newSts is null and #tmp.ProviderID=i.ProviderID
						

						  UPDATE #tmp  set newSts ='4 - DECEASED'
											from (select PR.ProviderID from  KYP.MDM_SearchProviders PR 
														inner join kyp.MDM_AlertResolution Res on  Res.ProviderID=PR.ProviderID and PR.AlertID =@alertID
														where  Res.IsDeleted=0  and Res.ResolutionType = 'Deactivate Provider As Deceased'  ) i
						where #tmp.newSts is null and #tmp.ProviderID=i.ProviderID
						
						
						UPDATE #tmp  set newSts ='6 - SUSPENDED' 
											from (select PR.ProviderID from  KYP.MDM_SearchProviders PR 
														inner join kyp.MDM_AlertResolution Res on  Res.ProviderID=PR.ProviderID and PR.AlertID =@alertID
														where  Res.IsDeleted=0  and Res.ResolutionType = 'Suspend Account'  ) i
												where #tmp.newSts is null and #tmp.ProviderID=i.ProviderID
						
					

					  UPDATE #tmp  set newSts ='9 - TEMPORARY SUSPENDED'
					from (select PR.ProviderID from  KYP.MDM_SearchProviders PR 
								inner join kyp.MDM_AlertResolution Res on  Res.ProviderID=PR.ProviderID and PR.AlertID =@alertID
								where  Res.IsDeleted=0  and Res.ResolutionType = 'Suspend Account Temporarily' ) i
						where #tmp.newSts is null and #tmp.ProviderID=i.ProviderID 

					
						
						if(@WatchlistName='OIG LEIE')
							 begin
								SET @StatusReason= '15 � Federally Excluded'
							 end
							 else if(@WatchlistName='SAM')
							 begin 
								SET @StatusReason= '15 � Federally Excluded'
							 end
							 else if(@WatchlistName='SSA DMF')
							 begin 
								SET @StatusReason= '14 � Other'
							 end 
							 else if(@WatchlistName='Medicaid & Medicare Exclusion')
							 begin 
								SET @StatusReason= '16 � Terminated By Medicaid'
							 end 
							 else if(@WatchlistName='License Status')
							 begin 
								SET @StatusReason= '19 � Sanctions by License Board'
							 end  else if(@WatchlistName='Sanction Status')
							 begin 
								SET @StatusReason= '19 � Sanctions by License Board'
							 end
							 else if(@WatchlistName='NPI Issues')
							 begin 
								SET @StatusReason= '14 � Other'
							 end 
							 else if(@WatchlistName='S&I Watchlist')
							 begin 
								SET @StatusReason= '7 � Suspected provider fraud/under investigation'
							 end
							  else if(@WatchlistName='Internal Watchlist')
							 begin 
								SET @StatusReason= '14 � Other'
							 end	
*/			
if(@MatchStatusIndicatordecription='Confirmed')				
	BEGIN 					
		   INSERT INTO KYPEnrollment.pAccount_History(AccountID,ActionID,DateCreated,IsDeleted,LastActorUserID,LastActionDate) 
           select t.AccID,'43',getdate(), 0,@CurrentlyAssignedToID,getdate() from  #tmp t where t.newSts is not null and  (t.oldSts is null) or (  t.oldSts is  not null and  t.newSts<> t.oldSts ) order by t.AccID
		
 		  insert into KYPEnrollment.HIS_MadeChange( HistoryID,Field,Oldvalue,NewValue,DateCreate)       
		  select tm.HistoryID, 'Status|Deactivation Date|Status Reason Code',
 		  ISNULL(oldSts, 'NA') + '|' + isnull(left(convert(varchar,Acc.DeActivationDate,103),10),'NA')+ '|'+ISNULL(Acc.StatusReasonCode, 'NA'),
		  ISNULL(t.newSts, 'NA') + '|' + isnull(left(convert(varchar,IUDA.EnrollStatusBeginDate,103),10),'NA')+'|'+ISNULL(IUDA.EnrollStatusReasonCode, 'NA'),
		  GETDATE()   from #tmp t 
		  inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=t.AccID
		  inner join KYPEnrollment.EDM_AlertlInternalUse IUDA on Acc.AccountID=IUDA.AccountID and IUDA.AlertID=@alertID
		  inner join (select  AccountID,HistoryID,ActionID, row_number() over(partition by ActionID order by LastActionDate desc) as rn
 
    from KYPEnrollment.pAccount_History 
   )tm    ON tm.AccountID =t.AccID  and tm.ActionID='43' and tm.rn=1
   where newSts is not null and  (t.oldSts is null) or (  t.oldSts is  not null and  t.newSts<> t.oldSts )
  
  
  	--commiting code for IUD changes By Rahul Raghavendra   
	update Acc_sts  set Acc_sts.CurrentRecordFlag=0 ,Acc_sts.EffectiveEndDate=(getDate()-1),Acc_sts.LastAction='U' ,Acc_sts.LastActionDate=getDate(),Acc_sts.LastActionReason='Update'
							FROM kypEnrollment.pADM_AccountStatus  Acc_sts
							inner join #tmp t on t.AccID=Acc_sts.AccountID 
							where  Acc_sts.StatusType='Billing'   and  isnull(t.OldSts,'')<>isnull(t.newSts,'') --is not null
											


	
		
	insert into kypEnrollment.pADM_AccountStatus ( AccountID,StatusType,StatusValue,AbstractedStatusValue,BillingAccountNo,BillingNPI,BillingServiceLocationNo,BillingServiceAdrLn1,BillingServiceAdrLn2,
																		   BillingServiceCity,BillingServiceState,BillingServiceZIP9,EffectiveBeginDate,EffectiveEndDate,
																		   LastAction,LastActionDate,LastActionReason,LastActionComments,LastActionApprovedBy,CurrentRecordFlag)
							                                     
	select  AC.AccountID,AC.StatusType,t.newSts,AC.AbstractedStatusValue,AC.BillingAccountNo,AC.BillingNPI,AC.BillingServiceLocationNo,AC.BillingServiceAdrLn1,
	AC.BillingServiceAdrLn2,AC.BillingServiceCity,AC.BillingServiceState,AC.BillingServiceZIP9,getDate(),AC.EffectiveEndDate,
																		   'U',getDate(),'Update',@Comments,@CurrentlyAssignedByID,1 from  
																		   kypEnrollment.pADM_AccountStatus AC
																		   inner join  #tmp t on t.AccID=AC.AccountID 
																			   where  AC.StatusType='Billing'   and CurrentRecordFlag=0 
																			   and  --t.newSts is not null and  (t.oldSts is null) or (  t.oldSts is  not null and  t.newSts<> t.oldSts )
																			   isnull(t.OldSts,'')<>isnull(t.newSts,'')
	/*							                                  				
	                                                              

	   BEGIN
			update Acc set Acc.StatusAcc = t.newSts,Acc.StatusReasonCode=@StatusReason,
								 Acc.DeActivationDate=@DateResolved, Acc.LastActionDate=getDate(), Acc.LastAction='U' ,Acc.LastActorUserID=@CurrentlyAssignedToID, 
								 Acc.AccountUpdatedBy='T',Acc.StatusBeginDate=@DateResolved --Made changes since colsed date of alert closed should be Status Begin Date for Account 
								 ,Acc.Row_Updation_Source = 'KYP.p_UpdateAlertonAccount'
							FROM kypEnrollment.pADM_Account  Acc
							inner join #tmp t on t.AccID=Acc.AccountID
								where  t.newSts is not null and  (t.oldSts is null) or (  t.oldSts is  not null and  t.newSts<> t.oldSts )
	    END	*/
	   			
						
	END					
END
				
					

					
END


GO

