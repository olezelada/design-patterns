CREATE PROCEDURE [KYPEnrollment].[sp_Copy_Service_List]
  @new_Account_Id INT,
	@new_Party_Id INT,
	@party_Id INT

AS
BEGIN

	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_Id, @new_Party_Id, 'ServiceList';
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_Id, @new_Party_Id, 'RayList';
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_Id, @new_Party_Id, 'ServiceOtherList';
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_Id, @new_Party_Id, 'ultrasoundUsed';
	EXEC [KYPEnrollment].[sp_Copy_ProviderQuestionnarieByType] @party_Id, @new_Party_Id, 'mammographyUsed';

END


GO

