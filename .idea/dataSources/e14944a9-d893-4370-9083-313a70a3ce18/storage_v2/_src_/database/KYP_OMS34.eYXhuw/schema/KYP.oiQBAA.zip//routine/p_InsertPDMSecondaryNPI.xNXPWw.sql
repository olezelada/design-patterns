/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMSecondaryNPI]
(
 @PartyID int
 ,@NPI int= NULL
 ,@DateModified Datetime=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
 
)
as begin 

INSERT INTO [KYP].[PDM_SecondaryNPI]
           ([PartyID]
           ,[NPI]
           ,[DateModified]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted])
     VALUES
           (@PartyID
           ,@NPI
           ,@DateModified
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DeletedBy
           ,@DateDeleted)

	return IDENT_CURRENT('[KYP].[PDM_SecondaryNPI]')

end


GO

