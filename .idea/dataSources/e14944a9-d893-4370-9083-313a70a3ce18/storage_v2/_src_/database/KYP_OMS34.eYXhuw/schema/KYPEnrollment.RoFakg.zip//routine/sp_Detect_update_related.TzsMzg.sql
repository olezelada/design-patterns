-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <21/11/2017>
-- Description:	<This is a factory procedure that choose between different packages updates that creates new accounts>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].sp_Detect_update_related
@account_id int,
@application_no varchar(20),
@last_Action_User_ID VARCHAR(100),
@priority VARCHAR(3),
@composite_risk INT,
@case_id INT,
@risk VARCHAR(15),
@application_type VARCHAR(30),
@main_app_number varchar(100)	
AS
BEGIN

declare @package varchar(50),@app_party int,@npi varchar(50),@appType varchar(50),@provTypeCode varchar(30), @appProviderType VARCHAR(10), @npiType VARCHAR(100);

select @package = PackagesName, @app_party = PartyID , @npi = NPI,@appType = ApplicationType, @appProviderType = ProviderTypeCode, @npiType = NpiType  from KYPPORTAL.PortalKYP.pADM_Application where ApplicationNo = @application_no and IsDeleted=0



IF @package IN ('FSP_MDT_SP','FSP_MDT_IN','FSP_DMC_SP','FSP_DMC_IN','F_THS_OE', 'F_THS_SP') OR  (@appType not IN ('Facility')
AND EXISTS ( select ad.AddressID,l.LocationID from
				KYPPORTAL.PortalKYP.pPDM_Party p
				inner join KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pb on p.ParentPartyID =pb.PartyId
				inner join KYPPORTAL.PortalKYP.pPDM_Location l on l.PartyID=p.PartyID
				inner join KYPPORTAL.PortalKYP.pPDM_Address ad on l.AddressID=ad.AddressID
				where p.ParentPartyID=@app_party and p.IsDeleted=0 and pb.IsDeleted=0 and l.IsDeleted=0 and ad.IsDeleted=0 and Approved=1
				and p.TYPE in ('FacilityBusiness Address'))
)
BEGIN
			--IF NOT EXISTS (select * from tempdb.INFORMATION_SCHEMA.TABLES t WHERE t.TABLE_NAME like '#tempProviderType%')
			IF OBJECT_ID('tempdb..#tempProviderType') IS  NULL
			BEGIN
				CREATE TABLE #tempProviderType (id INT IDENTITY (1, 1),[tempProviderType] [nvarchar](50) NULL,[appName] [nvarchar](50) NULL,
				[AccountNumber] [varchar](20) NULL,[partyAddressId] [int] NULL,	[IsFBP] [bit] NULL,	[locationID] [int] NULL )
			END
END

IF @package IN ('FSP_MDT_SP','FSP_MDT_IN')
BEGIN
	print 'MDT DETECTED'
    EXEC [KYPEnrollment].sp_Detect_MDT_Update_Case @account_id,
												   @application_no,
												   @last_Action_User_ID,
												   @priority,
												   @composite_risk,
												   @case_id,
												   @risk,
												   @application_type,
												   @main_app_number

END

-- F_THS_OE   F_THS_SP
IF @package IN ('F_THS_OE', 'F_THS_SP') AND @appProviderType  = '075'
BEGIN
   PRINT('creating new account DDP from tribal')
   print 'NEW DPP through Tribal DETECTED';
   EXEC [KYPEnrollment].sp_Detect_NewDPP_From_Tribal @account_id,
												   @application_no,
												   @last_Action_User_ID,
												   @priority,
												   @composite_risk,
												   @case_id,
												   @risk,
												   @npiType,
												   @main_app_number
END

IF @package IN ('FSP_DMC_SP','FSP_DMC_IN')
BEGIN
	print 'DMC DETECTED'
    EXEC [KYPEnrollment].sp_Detect_DMC_Update_Case @account_id,
												   @application_no,
												   @last_Action_User_ID,
												   @priority,
												   @composite_risk,
												   @case_id,
												   @risk,
												   @application_type,
												   @main_app_number,
												   @package

END


IF @appType not IN ('Facility') 
AND EXISTS (
select ad.AddressID,l.LocationID from
				KYPPORTAL.PortalKYP.pPDM_Party p 
				inner join KYPPORTAL.PortalKYP.pPDM_PlaceBusiness pb on p.ParentPartyID =pb.PartyId
				inner join KYPPORTAL.PortalKYP.pPDM_Location l on l.PartyID=p.PartyID
				inner join KYPPORTAL.PortalKYP.pPDM_Address ad on l.AddressID=ad.AddressID
				where p.ParentPartyID=@app_party and p.IsDeleted=0 and pb.IsDeleted=0 and l.IsDeleted=0 and ad.IsDeleted=0 and Approved=1
				and p.TYPE in ('FacilityBusiness Address')

)

BEGIN
	print 'Place of Business DETECTED'
    EXEC [KYPEnrollment].sp_Detect_PB_Update_Case @account_id,
												   @application_no,
												   @last_Action_User_ID,
												   @priority,
												   @composite_risk,
												   @case_id,
												   @risk,
												   @application_type,
												   @main_app_number

END


--ADD OTHERS:


END
GO

