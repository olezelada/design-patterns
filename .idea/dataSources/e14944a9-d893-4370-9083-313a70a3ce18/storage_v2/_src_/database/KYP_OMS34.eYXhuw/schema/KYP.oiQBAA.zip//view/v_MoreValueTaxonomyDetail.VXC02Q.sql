


CREATE VIEW [KYP].[v_MoreValueTaxonomyDetail]
AS
SELECT  Z.MoreValueID,Z.ScreeningID,Z.HMSID,Z.AttributeName,Z.DisclosedData,Z.FoundData,Z.MatchResult, Z.Category, Z.SortOrder,Z.FlagCount,Z.DTaxonomyCode, Z.DTaxonomyDesc, Z.FTaxonomyCode, Z.FTaxonomyDesc,Z.FTaxonomyNPI FROM (
	SELECT MoreValueID,ScreeningID,HMSID,AttributeName,DisclosedData,FoundData,FlagCount,MatchResult, Category, SortOrder,DTaxonomyCode, DTaxonomyDesc, FTaxonomyCode, FTaxonomyDesc,FTaxonomyNPI from(
		Select X.MoreValueID,X.ScreeningID,X.HMSID,X.AttributeName,X.DisclosedData,X.FoundData,X.FlagCount,X.MatchResult, X.Category, X.SortOrder,X.DetailAttributeName,X.DetailAttributeValue from(
			Select D.MoreValueID,M.ScreeningID,M.HMSID,M.AttributeName,M.DisclosedData,M.FoundData,M.FlagCount,M.MatchResult, M.Category, M.SortOrder,
			D.DetailAttributeName,D.DetailAttributeValue
				from KYP.SDM_MoreValue M inner join KYP.SDM_MoreValueDetail D 
				ON M.MoreValueID = D.MoreValueID 
		) X 
)Y PIVOT(max(DetailAttributeValue)
	for DetailAttributeName IN (DTaxonomyCode, DTaxonomyDesc, FTaxonomyCode, FTaxonomyDesc,FTaxonomyNPI)
) patx
) Z where (LTRIM(RTRIM(ISNULL(Z.DisclosedData,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.FoundData,''))) != '' OR
		   LTRIM(RTRIM(ISNULL(Z.DTaxonomyCode,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.DTaxonomyDesc,''))) != '' OR
		   LTRIM(RTRIM(ISNULL(Z.FTaxonomyCode,''))) != '' OR LTRIM(RTRIM(ISNULL(Z.FTaxonomyDesc,''))) != '' OR
		   LTRIM(RTRIM(ISNULL(Z.FTaxonomyNPI,''))) != '' )


GO

