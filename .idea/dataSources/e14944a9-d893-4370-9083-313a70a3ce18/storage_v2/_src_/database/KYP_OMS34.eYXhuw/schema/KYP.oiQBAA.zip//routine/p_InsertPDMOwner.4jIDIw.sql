/******Script for insert procedurse************/
CREATE PROCedure [KYP].[p_InsertPDMOwner]
(@PartyID int
 ,@ProviderID int= NULL
 ,@OwnerNO varchar(15) =NULL
 ,@FromDate smalldatetime = NULL
 ,@ThroughDate smalldatetime=NULL
 ,@Ownership int=NULL
 ,@Type varchar(15)=NULL
 ,@DateReported datetime=NULL
 ,@InformationSource varchar(50)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
 ,@UPIN varchar(6)=NULL
 ,@Designation varchar(25)=NULL
)
as begin 

INSERT INTO [KYP].[PDM_Owner]
           ([PartyID]
           ,[ProviderID]
           ,[OwnerNO]
           ,[FromDate]
           ,[ThroughDate]
           ,[Ownership]
           ,[Type]
           ,[DateReported]
           ,[InformationSource]
           ,[Remarks]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted]
           ,[UPIN]
           ,[Designation]
           )
     VALUES
           (@PartyID
           ,@ProviderID
           ,@OwnerNO
           ,@FromDate
           ,@ThroughDate
           ,@Ownership
           ,@Type
           ,@DateReported
           ,@InformationSource
           ,@Remarks
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted
           ,@UPIN
           ,@Designation
           )

	return IDENT_CURRENT('[KYP].[PDM_Owner]')

end


GO

