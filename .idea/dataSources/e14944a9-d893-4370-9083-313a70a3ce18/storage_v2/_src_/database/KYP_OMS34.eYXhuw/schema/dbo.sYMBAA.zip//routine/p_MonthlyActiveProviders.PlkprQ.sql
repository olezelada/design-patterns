-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[p_MonthlyActiveProviders]
AS
BEGIN
	SET NOCOUNT ON;

	--DECLARE @YearNo INT
	--	,@MonthNo INT
	--	,@ProvidersReceived INT

	--SELECT @YearNo = datepart(year, GETDATE())
	--	,@MonthNo = datepart(month, getdate())

	--SELECT @ProvidersReceived = count(DISTINCT Pvd.Mon_MedicaidID)
	--FROM KYP.PDM_Party Prty
	--INNER JOIN KYP.PDM_Provider Pvd ON Prty.PartyID = Pvd.PartyID
	--	AND ISNULL(Prty.IsDeleted, 0) = 0
	--	AND ISNULL(Pvd.IsDeleted, 0) = 0
	--	AND Prty.IsProvider = 1
	--	AND Prty.CurrentModule = 2

	--IF NOT EXISTS (
	--		SELECT 1
	--		FROM KYP.MDM_MonthlyActiveProvider
	--		WHERE Year = @YearNo
	--			AND Month = @MonthNo
	--		)
	--BEGIN
	--	INSERT INTO KYP.MDM_MonthlyActiveProvider
	--	VALUES (
	--		@MonthNo
	--		,@YearNo
	--		,@ProvidersReceived
	--		,GETDATE()
	--		)
	--END
	--ELSE
	--BEGIN
	--	DELETE
	--	FROM KYP.MDM_MonthlyActiveProvider
	--	WHERE Year = @YearNo
	--		AND Month = @MonthNo

	--	INSERT INTO KYP.MDM_MonthlyActiveProvider
	--	VALUES (
	--		@MonthNo
	--		,@YearNo
	--		,@ProvidersReceived
	--		,GETDATE()
	--		)
	--END
END
GO

