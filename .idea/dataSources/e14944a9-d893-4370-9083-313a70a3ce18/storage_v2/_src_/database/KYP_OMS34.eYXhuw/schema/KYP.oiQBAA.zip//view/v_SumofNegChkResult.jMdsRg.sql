

CREATE VIEW [KYP].[v_SumofNegChkResult] AS

SELECT SUM(X.cNegative) As cNegative,ApplicationID FROM (

/*SELECT 
    COUNT(GSAEPLS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1   where GSAEPLS = 'F' 
GROUP BY ApplicationID, GSAEPLS 

UNION ALL

SELECT 
    COUNT(OIGLEIE) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where OIGLEIE = 'F' 
GROUP BY ApplicationID, OIGLEIE 

UNION ALL

SELECT 
    COUNT(SOR) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SOR = 'F' 
GROUP BY ApplicationID, SOR 

UNION ALL

SELECT 
    COUNT(SSADMF) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SSADMF = 'F' 
GROUP BY ApplicationID, SSADMF 

UNION ALL*/

SELECT 
    COUNT(NPI) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where NPI = 'F' 
GROUP BY ApplicationID, NPI 

UNION ALL

SELECT 
    COUNT(SSN) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SSN = 'F' 
GROUP BY ApplicationID, SSN 

UNION ALL

SELECT 
    COUNT(TIN) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where TIN = 'F' 
GROUP BY ApplicationID, TIN 

UNION ALL

SELECT 
    COUNT(StrAttr1) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where StrAttr1 = 'F' 
GROUP BY ApplicationID, StrAttr1 

UNION ALL


SELECT 
    COUNT(StrAttr2) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where StrAttr2 = 'F' 
GROUP BY ApplicationID, StrAttr2 

UNION ALL

SELECT 
    COUNT(StrAttr3) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where StrAttr3 = 'F' 
GROUP BY ApplicationID, StrAttr3 

UNION ALL

SELECT 
    COUNT(DEA) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where DEA = 'F' 
GROUP BY ApplicationID, DEA 

UNION ALL

SELECT 
    COUNT(License) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where License = 'F' 
GROUP BY ApplicationID, License 

UNION ALL

SELECT 
    COUNT(City) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where City = 'F' 
GROUP BY ApplicationID, City 

UNION ALL

SELECT 
    COUNT(CLIA) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where CLIA = 'F' 
GROUP BY ApplicationID, CLIA 

UNION ALL

/*SELECT 
    COUNT(DMF) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where DMF = 'F' 
GROUP BY ApplicationID, DMF 

UNION ALL

SELECT 
    COUNT(CourtCheck) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where CourtCheck = 'F' 
GROUP BY ApplicationID, CourtCheck 

UNION ALL


SELECT 
    COUNT(HMSSanction) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where HMSSanction = 'F' 
GROUP BY ApplicationID, HMSSanction 

UNION ALL*/

SELECT 
    COUNT(Specialty) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where Specialty = 'F' 
GROUP BY ApplicationID, Specialty 

UNION ALL

SELECT 
    COUNT(PhoneNo) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where PhoneNo = 'F' 
GROUP BY ApplicationID, PhoneNo 

UNION ALL

/*SELECT 
    COUNT(IW_NPI_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where IW_NPI_STATUS = 'F' 
GROUP BY ApplicationID, IW_NPI_STATUS 

UNION ALL

SELECT 
    COUNT(IW_LICENSE_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where IW_LICENSE_STATUS = 'F' 
GROUP BY ApplicationID, IW_LICENSE_STATUS 

UNION ALL

SELECT 
    COUNT(IW_NAME_ADDRESS_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where IW_NAME_ADDRESS_STATUS = 'F' 
GROUP BY ApplicationID, IW_NAME_ADDRESS_STATUS 

UNION ALL

SELECT 
    COUNT(PECOS_NPI_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where PECOS_NPI_STATUS = 'F' 
GROUP BY ApplicationID, PECOS_NPI_STATUS 

UNION ALL

SELECT 
    COUNT(PECOS_TIN_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where PECOS_TIN_STATUS = 'F' 
GROUP BY ApplicationID, PECOS_TIN_STATUS 

UNION ALL 


SELECT 
    COUNT(PECOS_NAME_ADDRESS_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where PECOS_NAME_ADDRESS_STATUS = 'F' 
GROUP BY ApplicationID, PECOS_NAME_ADDRESS_STATUS 

UNION ALL

SELECT 
    COUNT(MCSIS_MR_NPI_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NPI_STATUS = 'F' 
GROUP BY ApplicationID, MCSIS_MR_NPI_STATUS 

UNION ALL

SELECT 
    COUNT(MCSIS_MR_NAME_ADDR_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MR_NAME_ADDR_STATUS = 'F' 
GROUP BY ApplicationID, MCSIS_MR_NAME_ADDR_STATUS 

UNION ALL

SELECT 
    COUNT(MCSIS_MD_NPI_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NPI_STATUS = 'F' 
GROUP BY ApplicationID, MCSIS_MD_NPI_STATUS 

UNION ALL

SELECT 
    COUNT(MCSIS_MD_NAME_ADDR_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where MCSIS_MD_NAME_ADDR_STATUS = 'F' 
GROUP BY ApplicationID, MCSIS_MD_NAME_ADDR_STATUS 

UNION ALL*/

SELECT 
    COUNT(TAXONOMY_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where TAXONOMY_STATUS = 'F' 
GROUP BY ApplicationID, TAXONOMY_STATUS 
/*
UNION ALL

SELECT 
    COUNT(SANDI_NPI_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_NPI_STATUS = 'F' 
GROUP BY ApplicationID, SANDI_NPI_STATUS 

UNION ALL

SELECT 
    COUNT(SANDI_LICENSE_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_LICENSE_STATUS = 'F' 
GROUP BY ApplicationID, SANDI_LICENSE_STATUS 

UNION ALL

SELECT 
    COUNT(SANDI_ADDRESS_STATUS) AS cNegative, ApplicationID    
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_ADDRESS_STATUS = 'F' 
GROUP BY ApplicationID, SANDI_ADDRESS_STATUS 

UNION ALL

SELECT 
    COUNT(SANDI_STATUS) AS cNegative, ApplicationID   
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where SANDI_STATUS = 'F' 
GROUP BY ApplicationID, SANDI_STATUS 

UNION ALL

SELECT 
    COUNT(JACHO_STATUS) AS cNegative, ApplicationID   
FROM KYP.SDM_DBCheckResult C INNER JOIN KYP.SDM_ApplicationParty P ON P.ScreeningID = C.ScreeningID AND P.IsActive = 1 where JACHO_STATUS = 'F' 
GROUP BY ApplicationID, JACHO_STATUS*/
)X 
GROUP BY X.ApplicationID


GO

