
-- =============================================
-- Author:		Sundar
-- Create date: 31-May-2017
-- Description:	This SP is used to fetch Billing Provider information to be populated in Input Document. This is used in Biller and ORP Input Documents.PI-799
-- =============================================
--Change History
---------------------------------------------------------------------------------------
-- Sl.No.	JIRA No.			Author		Date			Description
---------------------------------------------------------------------------------------
-- 1		MD-4				Sundar		20-Jul-2016		Added Input Doc functionality for MD
-- 2		KEN-12838			Sundar		26-Aug-2017		Implemented PAVE 3.0 changes for Input Document
-- 3		PI-843				Sundar		4-Sep-2017		Changed the logic for License Effective Date
-- 4		PI-841				Sundar		9-Sep-2017		Fixed the issue for City Name not being highlighted
-- 5		KEN-13613			Sundar		09-Sep-2017		Added Padm_Account.DateCreated<>Paccount_Pdm_Number.LastActionDate condition in the LicenseEffDate field calculation
-- 6		KEN-13796			Sundar		18-Sep-2017		Removed the special character ('-') for SSN and EIN fields
-- 7		KEN-14962			Sundar		4-Jan-2017		Considered PartyID to reduce the logical reads
-- 8		CAPAVE-2464			Sundar		6-Feb-2017		Ignored the values with ToValue as Null and FromValue as 0 from InputDoc_Biller table.
-- 9		CAPAVE-2602, 2617	Sundar		22-Feb-2017		Getting data from FullLoad table instead of History table
-- 10		KEN-15462			Sundar		9-Mar-2018		Added IsApproved = 1 to consider only the approved IUD changes
-- 11		CAPAVE-3142, 3139 Sundar	8-May-2018	Added EDM_AccountInternalMany.IsApproved = 1 to consider only the approved IUD changes
-- 12		CAPAVE-5367			Sundar		26-Mar-2019		Added IsPrimary Desc condition to consider Primary license
 
CREATE PROCEDURE [KYPEnrollment].[Usp_IDoc_Biller_Info]
      @acc_party_id int, 
      @Username varchar(50),
      @UserDate date
AS
BEGIN
	--SET NOCOUNT ON;

  Declare @v_Str varchar(8000) = '',
          @v_Select_Str varchar(4000) = '',
          @v_Pivot_Str varchar(2000) = '',                
          @v_Insert_Str varchar(4000) = '',
          @v_Pivot_Qry varchar(4000) = '',
          @Date bigint,
          @SCodeIdty varchar(2000) = '',
          @c int=0,
          @StatusBeginDate varchar(10) --Added for #14 CAPAVE-1575                  
          ,@PartyID int --Added for #7 KEN-14962
--	--BEGIN Try
	If exists (select object_id
						  from sys.objects
						  where name = 'Stage_InputDoc')
	Begin
		--Drop table Stage_InputDoc;
		Delete from Stage_InputDoc; --Replaced Drop with Delete state due to DDL permission is removed by DBA team
	End                              

	Set @Date = convert(bigint,CONVERT(varchar(8),@UserDate,112));
	
	--Sanction Changes start
	
	Select @SCodeIdty = @SCodeIdty+''''+ coalesce(CodeIdentification,'')+''',',
			@c = @c+1
	from (
	SELECT C.AccountId, 
		isnull(CONVERT(varchar(20),(case when CodeIdentification = 'other' then left(UPPER(CodeDescription),5) else CodeIdentification end)),'') as CodeIdentification,
		ROW_NUMBER() over(partition by c.accountid order by EDMAIM.AccInternalUseManyID DESC)  R
	from [KYPEnrollment].[EDM_AccountInternalMany] EDMAIM  
	inner join KYPEnrollment.EDM_AccountInternalUse C on EDMAIM.AccountInternalUseID=C.AccountInternalUseID AND EDMAIM.CodeType = 'Sanction'
	where AccountID=@acc_party_id/*2011886*/
		and (C.IsApproved = 1 OR C.IsApproved is null)--Added for #10 KEN-15462
		and (EDMAIM.IsApproved=1 OR EDMAIM.IsApproved is null) -- #11 CAPAVE-3142, 3139	
	) T	
	Where R<9;

	select @SCodeIdty = @SCodeIdty+REPLICATE('NULL,',(8-@c))
	--Sanction Changes End
	
	--Added the below Select statement for #14 CAPAVE-1575
	Select @StatusBeginDate = Convert(varchar(10),StatusBeginDate,101)
	From KYPEnrollment.pADM_Account
	Where AccountID = @acc_party_id	
	
	--select T1.AccountID,t1.FieldName, t1.ToValue into Stage_InputDoc
	Insert into Stage_InputDoc(AccountID,FieldName,ToValue) -- Replaced Create to Insert since DDL permission is removed
	select T1.AccountID,t1.FieldName, t1.ToValue
		from KYPENROLLMENT.INPUTDOC_BILLER T1
		Join (select FieldName,MAX(ID) ID
			  from KYPENROLLMENT.INPUTDOC_BILLER
			  where AccountID=@acc_party_id
			  and convert(bigint,DateSearch) >= @Date
			  and FieldName not in ('Spec_C','SpecCertDT') -- Added for #6 CAPAVE-1221
			  and Not(FromValue = '0' and ToValue is null) --Added the condition for CAPAVE-2464 #8
			  Group by FieldName
			  ) t2 on t1.ID=t2.id

	/*Start of #22 Ken-12838*/		  
	Delete from Stage_InputDoc Where FieldName like 'CI%'
									and FieldName <> 'City';--Added the condition for #24 PI-841	
	Delete from Stage_InputDoc Where FieldName like 'CEfD%';
	Delete from Stage_InputDoc Where FieldName like 'CExD%';	
	
	Delete from Stage_InputDoc Where FieldName like 'LI%';
	Delete from Stage_InputDoc Where FieldName like 'LExD%';
	Delete from Stage_InputDoc Where FieldName like 'LEfD%';
	
	Delete from Stage_InputDoc Where FieldName like 'SI%';
	Delete from Stage_InputDoc Where FieldName like 'SEfD%';
	Delete from Stage_InputDoc Where FieldName like 'SExD%';	
	/*End of #22 Ken-12838*/
			  
	--print @acc_party_id
	--print @Date

	--Insert clause Static fields 
	set @v_Insert_Str = '[AccountID],[PartyID],[ProvNameScan],[Analyst],[AnalystDT],[Reviewer],[ReviewerDT],[Supervisor],[SupervisorDT],[NPI],[OwnerNo],[SerLocNo],[ProviderType],[DocNo],[ProfileID],'
						--+'[Spec_C1_old],[Spec_C2_old],[Spec_C3_old],[SpecCertDT1_old],[SpecCertDT2_old],[SpecCertDT3_old],'--#6

	--Add ScodeIdentity fields
	Set @v_Insert_Str = @v_Insert_Str+'[ScodeIdty1_old],[ScodeIdty2_old],[ScodeIdty3_Old],[ScodeIdty4_Old],[ScodeIdty5_Old],[ScodeIdty6_Old],[ScodeIdty7_Old],[ScodeIdty8_Old],'
						
	--Insert clause Fields that are changed
	set @v_Insert_Str = @v_Insert_Str + isnull((select STUFF((select '['+FieldName+'_New],'
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,'')),'');

	--Insert clause Fields that are not changed									  
	set @v_Insert_Str = @v_Insert_Str+(select STUFF((select '['+FieldName+'_Old],'
									  from (Select Column_name FieldName
												  from INFORMATION_SCHEMA.COLUMNS
												  where TABLE_NAME='AccountInputDocFullLoad'
												  and COLUMN_NAME not in ('AccountID','UserNAme','ID',
																		'PartyID',
																		'ProvNameScan',
																		'Analyst',
																		'AnalystDT',
																		'Reviewer',
																		'ReviewerDT',
																		'Supervisor',
																		'SupervisorDT',
																		'NPI',
																		'OwnerNo',
																		'SerLocNo',
																		'ProviderType',
																		'DocNo',
																		'ProfileID',
																		'LastLoadedDate',
																		'ScodeIdty1',--Sanction Changes start
																		'ScodeIdty2',
																		'ScodeIdty3',
																		'ScodeIdty4',
																		'ScodeIdty5',
																		'ScodeIdty6',
																		'ScodeIdty7',
																		'ScodeIdty8',--Sanction Changes end
																		/*#6 CAPAVE-1221 Start*/
																		--'Spec_C1', --added for Spec code
																		--'Spec_C2',
																		--'Spec_C3',
																		--'SpecCertDT1',
																		--'SpecCertDT2',
																		--'SpecCertDT3' --added for Spec code
																		'Spec_C',
																		'SpecCertDT'																		
																		/*#6 CAPAVE-1221 End*/
																		/*#21 MD-4 Start*/																		
																		,'UserName',
																		'SCounty',
																		'DOB',
																		'EPSDT',
																		'AuditDate',
																		'Audit',
																		'PrevProv',
																		'NCPDP',
																		'RevalidationDate',
																		'PracticeType',
																		'DEA',
																		'LabPermitNo',
																		'LicenseExpiryDate',
																		'Sort',
																		'MA_ID'
																		/*#21 MD-4 End*/																			
																		,'CNO' --Added for #22 KEN-12838																		
																		)
												  except
												  select FieldName
												  from Stage_InputDoc) S order by FieldName for xml path('')),1,0,''));     

	--Removing the trailing comma
	set @v_Insert_Str = LEFT(@v_Insert_Str,len(@v_Insert_Str)-1);	
	
	--To Add County for #22 Ken-12838
	Set @v_Insert_Str = @v_Insert_Str+',CNO'										  
	
	--Pivot clause fields								  
	set @v_Pivot_Str = (select STUFF((select '['+FieldName+'],'
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,''));

	--Removing the trailing comma
	If isnull(len(@v_Pivot_Str),0)>0
	Begin                                    
	set @v_Pivot_Str = LEFT(@v_Pivot_Str,len(@v_Pivot_Str)-1);
	End

	--Select clause fields that are changed
	set @v_Select_Str = isnull((select STUFF((select 't1.['+FieldName+'],' --Changed the table from t2 to t1 for CAPAVE-2602
									  from Stage_InputDoc 
									  order by FieldName for xml path('')),1,0,'')),'');

	--Select clause fields that are not changed
	set @v_Select_Str = @v_Select_Str+(select STUFF((select 't1.['+FieldName+'],'
									  from (Select Column_name FieldName
												  from INFORMATION_SCHEMA.COLUMNS
												  where TABLE_NAME='AccountInputDocFullLoad'
												  and COLUMN_NAME not in ('AccountID','UserNAme','ID',
																		'PartyID',
																		'ProvNameScan',
																		'Analyst',
																		'AnalystDT',
																		'Reviewer',
																		'ReviewerDT',
																		'Supervisor',
																		'SupervisorDT',
																		'NPI',
																		'OwnerNo',
																		'SerLocNo',
																		'ProviderType',
																		'DocNo',
																		'ProfileID',
																		'LastLoadedDate',
																		'ScodeIdty1',----Sanction Changes start
																		'ScodeIdty2',
																		'ScodeIdty3',
																		'ScodeIdty4',
																		'ScodeIdty5',
																		'ScodeIdty6',
																		'ScodeIdty7',
																		'ScodeIdty8',--Sanction Changes end
																		/*#6 CAPAVE-1221 Start*/
																		--'Spec_C1', --added for Spec code
																		--'Spec_C2',
																		--'Spec_C3',
																		--'SpecCertDT1',
																		--'SpecCertDT2',
																		--'SpecCertDT3' --added for Spec code
																		'Spec_C',
																		'SpecCertDT'
																		/*#6 CAPAVE-1221 End*/	
																		/*#21 MD-4 Start*/																		
																		,'UserName',
																		'SCounty',
																		'DOB',
																		'EPSDT',
																		'AuditDate',
																		'Audit',
																		'PrevProv',
																		'NCPDP',
																		'RevalidationDate',
																		'PracticeType',
																		'DEA',
																		'LabPermitNo',
																		'LicenseExpiryDate',
																		'Sort',
																		'MA_ID'
																		/*#21 MD-4 End*/
																		,'CNO' --Added for #22 KEN-12838																		
																		)
												  except
												  select FieldName
												  from Stage_InputDoc) S order by FieldName for xml path('')),1,0,''))

	--Removing the trailing comma
	set @v_Select_Str = LEFT(@v_Select_Str,len(@v_Select_Str)-1);
	
	--To Add County for #22 Ken-12838
	Set @v_Select_Str = @v_Select_Str+',t1.[CNO]'

	--Query to get the changed values
	Set @v_Pivot_Qry = 'Left Join (select * '+
			  'From Stage_InputDoc S '+
			  'Pivot (MAX([ToValue]) for FieldName in ('+@v_Pivot_Str+') '+  
			  ' ) P) t2 on t1.AccountId = t2.AccountId'

	--Building the insert statement by joining full load table and the changed data table
	Set @v_Str = 'insert into kypenrollment.Idoc_Biller(UserName,'+@v_Insert_Str+') '+
		'Select '''+@Username+''',t1.AccountID,t1.PartyID,t1.ProvNameScan,t1.Analyst,t1.AnalystDT,t1.Reviewer,t1.ReviewerDT,'+
		't1.Supervisor,t1.SupervisorDT,t1.NPI,t1.OwnerNo,t1.SerLocNo,t1.ProviderType,t1.DocNo,BZ.ProfileId,'/*t1.Spec_C1,t1.Spec_C2,t1.Spec_C3,t1.SpecCertDT1,t1.SpecCertDT2,t1.SpecCertDT3,*/--#6 CAPAVE-1221
		+@SCodeIdty+@v_Select_Str+' '+ 		
		'from KYPENROLLMENT.AccountInputDocFullLoad t1 '
		+'Left Join KYPEnrollment.pAccount_BizProfile_Details BZ ON BZ.AccountID=t1.AccountID ' --PI-693
		+ISNULL(@v_Pivot_Qry,'')+
		' Where T1.AccountID='+convert(varchar(20),@acc_party_id)

	print @v_Str;

	--Execute the insert statement
	Exec (@v_Str)

	--Commented for #22 KEN-12838
	/*
	/*#6 CAPAVE-1221 Start*/
	--Specialty Code New is updated when there is any change in value for highlighting
	Update IB
	Set IB.Spec_C1_New = FL.Spec_C1,
		IB.SpecCertDT1_New = isnull(FL.SpecCertDT1,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C1 = ID.ToValue
					)
					
	Update IB
	Set IB.Spec_C2_New = FL.Spec_C2,
		IB.SpecCertDT2_New = isnull(FL.SpecCertDT2,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C2 = ID.ToValue
					)
					
	Update IB
	Set IB.Spec_C3_New = FL.Spec_C3,
		IB.SpecCertDT3_New = isnull(FL.SpecCertDT3,@StatusBeginDate) --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id and 
	exists (select ID
					from kypenrollment.inputdoc_biller ID
					where ID.FieldName='Spec_C'
					and convert(bigint,ID.DateSearch) >= @Date
					and ID.AccountID = IB.AccountID
					and FL.Spec_C3 = ID.ToValue
					)								
	
	--Specialty Code Old fields are updated when there is no change in value				
	Update IB
	Set IB.Spec_C1_Old = Case When (IB.Spec_C1_New IS null) Then FL.Spec_C1 End,
	IB.SpecCertDT1_Old = Case When (IB.SpecCertDT1_New is null and FL.Spec_C1 IS Not Null) Then isnull(FL.SpecCertDT1,@StatusBeginDate) End, --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	IB.Spec_C2_Old = Case When (IB.Spec_C2_New IS null) Then FL.Spec_C2 End,
	IB.SpecCertDT2_Old = Case When (IB.SpecCertDT2_New is null and FL.Spec_C2 IS Not Null) Then isnull(FL.SpecCertDT2,@StatusBeginDate) End, --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575	
	IB.Spec_C3_Old = Case When (IB.Spec_C3_New IS null) Then FL.Spec_C3 End,
	IB.SpecCertDT3_Old = Case When (IB.SpecCertDT3_New is null and FL.Spec_C3 IS Not Null) Then isnull(FL.SpecCertDT3,@StatusBeginDate) End --Added isnull condition to consider StatusBeginDate for #14 CAPAVE-1575
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.AccountInputDocFullLoad FL on IB.AccountID=FL.AccountID
	Where IB.AccountID = @acc_party_id	
	/*#6 CAPAVE-1221 End*/
	*/

	--#8 CAPAVE-1393
	Update IB
	Set IB.LegalName_New = A.LegalName
	From KYPEnrollment.Idoc_Biller IB
	Join KYPEnrollment.pADM_Account A on IB.AccountID=A.AccountID
	Where IB.AccountID = @acc_party_id
	AND IB.LegalName_New is not null
	and IB.LegalName_Old is null;

	--Added for #7 KEN-14962
	Select @PartyID=PartyID
	From kypenrollment.padm_Account
	where AccountID = @acc_party_id
	
	--Commented for CAPAVE-5367 by Sundar on 27Mar2019
	/*Start #3 PI-843*/
	--Update IB
	--SET IB.EffDT_Old = NULL,
	--	IB.EffDT_New = Convert(Varchar(10),L.EffectiveDate,101)
	--From KYPEnrollment.Idoc_Biller IB
	--Join kypenrollment.Padm_Account A on IB.AccountID = A.AccountID
	--Join (Select PartyID,Number,EffectiveDate,LastActionDate,LastActorUserID
	--		From (Select PartyId,Number,Type,LastActionDate,EffectiveDate,LastActorUserID,Row_Number() Over(Partition by Partyid order by Type desc,IsPrimary desc,LastActionDate Desc) R --Added IsPrimary Desc condition for CAPAVE-5367 by Sundar on 26Mar2019
	--			from KYPEnrollment.pAccount_PDM_Number
	--			where Type in ('Professional License','Certificate') AND CurrentRecordFlag=1
	--			and PartyID = @PartyID --Added for #7 KEN-14962
	--			) T
	--			Where T.R = 1) L on A.PartyID = L.PartyID
	--Where IB.AccountID = @acc_party_id
	--and L.LastActionDate >= @UserDate 
	--and isnull(L.LastActorUserID,'') <> 'System'
	--and Convert(date,A.DateCreated) < ConverT(date,isnull(L.LastActionDate,'')); --Added for #25 KEN-13613
	 
	--Update IB
	--SET IB.EffDT_Old = Convert(Varchar(10),L.EffectiveDate,101),
	--	IB.EffDT_New = NULL
	--From KYPEnrollment.Idoc_Biller IB
	--Join kypenrollment.Padm_Account A on IB.AccountID = A.AccountID
	--Join (Select PartyID,Number,EffectiveDate,LastActionDate,LastActorUserID
	--		From (Select PartyId,Number,Type,LastActionDate,EffectiveDate,LastActorUserID,Row_Number() Over(Partition by Partyid order by Type desc,IsPrimary desc,LastActionDate desc) R --Added IsPrimary Desc condition for CAPAVE-5367 by Sundar on 26Mar2019
	--			from KYPEnrollment.pAccount_PDM_Number
	--			where Type in ('Professional License','Certificate') AND CurrentRecordFlag=1
	--			and PartyID = @PartyID --Added for #7 KEN-14962
	--			) T
	--			Where T.R = 1) L on A.PartyID = L.PartyID
	--Where IB.AccountID = @acc_party_id
	--and ((L.LastActionDate < @UserDate 
	--		OR L.LastActionDate is null)
	--	OR L.LastActorUserID = 'System'
	--	OR CONVERT(date,A.DateCreated) >= Convert(date,L.LastActionDate)); --Added for #25 KEN-13613
	/*End #3 PI-843*/	

	--Added the below Update statement for KEN-13796	
	Update Kypenrollment.Idoc_Biller
	Set SSN_Old = REPLACE(SSN_Old,'-',''),
		SSN_New = REPLACE(SSN_New,'-',''),		
		EIN_Old = REPLACE(EIN_Old,'-',''),
		EIN_New = REPLACE(EIN_New,'-','')
	Where AccountID = @acc_party_id	
END

GO

