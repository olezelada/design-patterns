


CREATE VIEW [KYP].[v_CSCategoryServices] AS
SELECT	CONVERT(VARCHAR,U.AccountID) As AccountID,
		CONVERT(VARCHAR,C.CaseID) As CaseID,
		COALESCE(CONVERT(VARCHAR,I.CodeIdentification),'') + COALESCE((' - ' + CONVERT(VARCHAR,I.CodeDescription)),'') As Category,
		CONVERT(VARCHAR,CodeDateEffDate,101) As BeginDate,
		CONVERT(VARCHAR,CodeDateExpDate,101) As ExpirationDate
FROM KYPEnrollment.EDM_AccountInternalMany I 
	INNER JOIN KYPEnrollment.EDM_AccountInternalUse U ON I.AccountInternalUseID = U.AccountInternalUseID AND I.CodeType = 'Category'
	INNER JOIN KYPEnrollment.pADM_Account A ON U.AccountID = A.AccountID  
	INNER JOIN KYP.ADM_Case C ON C.AccountNo  = A.AccountNumber


GO

