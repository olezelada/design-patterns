
-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <14/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the PROGRAM PARTICIPATION-MEDICARE of the respective account>
-- =============================================
create PROCEDURE [KYPEnrollment].[sp_Delete_Program_Participation]
@new_Account_Id int

AS
BEGIN

declare @participation_party table (pk int identity(1,1),party int);

SET NOCOUNT ON;

INSERT INTO @participation_party (party)
select p.PartyID from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p 
ON a.PartyID=p.ParentPartyID where a.AccountID=@new_Account_Id and a.IsDeleted=0 and p.IsDeleted=0
and p.Type in ('ProgramParticipation','Provider Q1')


update ad set CurrentRecordFlag=0
from 
@participation_party par  INNER JOIN kypenrollment.pAccount_PDM_Location loc on par.Party=loc.PartyID
inner join kypenrollment.pAccount_PDM_Address ad on loc.AddressID=ad.AddressID  where loc.IsDeleted=0 and ad.CurrentRecordFlag=1 and loc.CurrentRecordFlag=1

update loc set isdeleted=1,currentrecordflag=0 from
@participation_party par  INNER JOIN kypenrollment.pAccount_PDM_Location loc on par.Party=loc.PartyID where loc.IsDeleted=0  and loc.CurrentRecordFlag=1

update org set isdeleted=1,currentrecordflag=0 from
@participation_party par  INNER JOIN kypenrollment.pAccount_PDM_organization org on par.Party=org.PartyID where org.IsDeleted=0 and org.CurrentRecordFlag=1

update Prov set isdeleted=1,currentrecordflag=0 from
@participation_party par  INNER JOIN kypenrollment.pAccount_PDM_provider prov on par.Party=prov.PartyID where prov.IsDeleted=0 and prov.CurrentRecordFlag=1


update part set isdeleted=1,currentrecordflag=0 from
@participation_party par  INNER JOIN kypenrollment.pAccount_PDM_party part on par.Party=part.PartyID



END

GO

