-- =============================================
-- Author:		<jvera>
-- Create date: <01/24/2018>
-- Description:	<This procedure update Incontinence Tables>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Update_Location_Stock_Table]
@acc_party_id INT,
@action_taken VARCHAR(50),
@last_action_user_id VARCHAR(100),
@target_path VARCHAR(200),
@en_db_column VARCHAR(100), 
@data VARCHAR(MAX), 
@acc_PK VARCHAR(100), 
@acc_PK_value INT,
@is_text_date CHAR(1),
@account_id INT,
 @acc_table_name VARCHAR(200)
AS
BEGIN
SET NOCOUNT ON;


IF @action_taken='Added'
  BEGIN
  
  PRINT @action_taken 
  
  DECLARE @party_location_id INT;			
			  SELECT @party_location_id = PartyID FROM [KYPPORTAL].[PortalKYP].[pPDM_Organization] WHERE TargetPath=@target_path;			  
			  IF not exists(SELECT FiledID FROM #Control_Add_row WHERE FiledID=@party_location_id AND NameTable='pAccount_PDM_Party')
			  BEGIN
    			EXEC [KYPEnrollment].[sp_Copy_Location_Stock]  NULL, @acc_party_id, @last_action_user_id, @party_location_id, @account_id, NULL;
    			INSERT INTO #Control_Add_row(FiledID,NameTable)	VALUES(@party_location_id, 'pAccount_PDM_Party'); 
    		  END
   
END
  
  
IF @action_taken='Deleted' AND @target_path LIKE '%'+@acc_table_name+'%'
  BEGIN
      PRINT 'DELETE  LOCATION STOCK';
  
			DECLARE @update NVARCHAR(MAX)
			DECLARE @ParamDefinition AS NVARCHAR(2000),@accPKvalue VARCHAR(100)
			SET @ParamDefinition = '@accPKvalue INT'

			SET @accPKvalue = CONVERT(VARCHAR(100), @acc_PK_value);
			SET @update = 'UPDATE KYPEnrollment.' + @acc_table_name + ' SET CurrentRecordFlag = 0 WHERE ' + @acc_PK + ' = ' + '@accPKvalue'
			 
			  EXEC sp_executesql @update
							  ,@ParamDefinition
							  ,@accPKvalue
  
END
END


GO

