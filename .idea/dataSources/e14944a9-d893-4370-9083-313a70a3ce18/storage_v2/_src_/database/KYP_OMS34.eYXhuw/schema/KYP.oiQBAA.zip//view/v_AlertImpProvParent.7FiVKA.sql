CREATE VIEW [KYP].[v_AlertImpProvParent]
AS
SELECT    row_number() OVER (ORDER BY A.AlertID ASC) AS ID, B.AlertID, A.MedicaidID, ProviderName,
                          (SELECT     WatchedPartyName
                            FROM          KYP.MDM_Alert
                            WHERE      AlertID = A.AlertID) AS 'PartyName', Auto, C.NPI, C.EnrolledSince, C.PrimarySpecialty,
                          /* START: For Multiple Cities found for Provider*/ (SELECT DISTINCT STUFF
                                                                                                                                                                 ((SELECT     ',' + City
                                                                                                                                                                     FROM         (SELECT DISTINCT City, AddressID
                                                                                                                                                                                            FROM          KYP.PDM_Address) A
                                                                                                                                                                     WHERE     AddressID IN
                                                                                                                                                                                               (SELECT     AddressID
                                                                                                                                                                                                 FROM          KYP.PDM_Location
                                                                                                                                                                                                 WHERE      PartyID = C.PartyID) FOR XML PATH('')), 1, 1, '') AS Numbers) AS 'City', 
                      /* START: Party as Provider Relation*/ CASE WHEN Auto = 'Y' AND
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Provider
                            WHERE      PartyID = A.SearchPartyID) > 0 THEN 'PROVIDER' END AS 'ProvRel', /* START: Party as Employee Relation*/ CASE WHEN Auto = 'Y' AND
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN 'EMPLOYEE' END AS 'EmpRel', 
                      /* START: Party as Owner Relation*/ CASE WHEN Auto = 'Y' AND
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN 'OWNER' END AS 'OwnRel', /* END: Party as Owner Relation*/ MatchType, 
                      /* START: Multiple Designations*/ CASE WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT DISTINCT STUFF
                                                       ((SELECT     ', ' + Designation
                                                           FROM         (SELECT DISTINCT Designation, PartyID
                                                                                  FROM          KYP.PDM_Employee) DSG
                                                           WHERE     PartyID IN
                                                                                     (SELECT     PartyID
                                                                                       FROM          KYP.PDM_Employee
                                                                                       WHERE      PartyID = A.SearchPartyID AND ProviderID = A.ProviderID) FOR XML PATH('')), 1, 1, '')) WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT DISTINCT STUFF
                                                       ((SELECT     ', ' + Designation
                                                           FROM         (SELECT DISTINCT Designation, PartyID
                                                                                  FROM          KYP.PDM_Owner) DSG
                                                           WHERE     PartyID IN
                                                                                     (SELECT     PartyID
                                                                                       FROM          KYP.PDM_Owner
                                                                                       WHERE      PartyID = A.SearchPartyID AND ProviderID = A.ProviderID) FOR XML PATH('')), 1, 1, '')) END AS 'Designation',
                          /* START: Ownership*/ (SELECT     TOP 1 Ownership
                                                                              FROM         KYP.PDM_Owner
                                                                              WHERE     PartyID = A.SearchPartyID AND ProvID = A.ProviderID) AS 'Ownership', /*START: From Date*/ CASE WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 FromDate
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 FromDate
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) END AS 'FromDate', /*START: Through Date*/ CASE WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 ThroughDate
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 ThroughDate
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) END AS 'ThroughDate', /*START: Information Source*/ CASE WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 InformationSource
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 InformationSource
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) END AS 'InformationSource', /*START: DateReported*/ CASE WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 DateReported
                            FROM          KYP.PDM_Employee
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) WHEN
                          (SELECT     COUNT(*)
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) > 0 THEN
                          (SELECT     TOP 1 DateReported
                            FROM          KYP.PDM_Owner
                            WHERE      PartyID = A.SearchPartyID AND ProvID = A.ProviderID) END AS 'DateReported', /*END: DateReported*/ A.Remarks
/***/ FROM KYP.MDM_ImpProviders A INNER JOIN
                      KYP.MDM_Alert B ON A.AlertID = B.AlertID LEFT OUTER JOIN
                      KYP.PDM_Provider C ON C.ProvID = A.ProviderID
WHERE     A.Impacted = 1 AND A.IsDeleted <> 1 AND B.IsMerged = 'N'


GO

