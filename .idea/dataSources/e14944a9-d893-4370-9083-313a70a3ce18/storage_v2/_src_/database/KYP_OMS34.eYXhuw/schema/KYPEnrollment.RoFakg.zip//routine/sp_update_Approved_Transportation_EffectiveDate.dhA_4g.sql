
-- =============================================
-- Author:		<hbustamante>
-- Create date: <04/11/2019>
-- Description:	<This procedure Update EffectiveDate column for all Pre-populated and Approved Vehicles and Operators records on supplemental apps, including (CHOA, Reenrollment, Revalidation)>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_update_Approved_Transportation_EffectiveDate]
   @party_id               INT
AS
BEGIN

	IF (@party_id IS NOT NULL)
	BEGIN

		PRINT('UPDATING EffectiveDate for OPERATORS');
		UPDATE operator
			SET operator.EffectiveDate = portalOperator.EffectiveDate
				, operator.LastActionDate = GETDATE()
		FROM KYPEnrollment.pAccount_PDM_Operator operator
			INNER JOIN (SELECT opId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(o.TargetPath), 0, PATINDEX('%|%', (REVERSE(o.TargetPath))))), ''))
							    , o.EffectiveDate
                  FROM KYPPORTAL.PortalKYP.pPDM_Operators o
                      INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON p.PartyID = o.PartyID
                  WHERE o.TargetPath LIKE '%pAccount%'
                      AND o.IsDeleted = 0
                      AND (o.Approved IS NOT NULL AND o.Approved = 1)
                      AND p.ParentPartyID = @party_id) portalOperator on portalOperator.opId = operator.OperatorId
		WHERE CurrentRecordFlag = 1

		PRINT('UPDATING EffectiveDate for VEHICLES');
		UPDATE vehicle
			SET vehicle.EffectiveDate = portalVehicle.EffectiveDate
				, vehicle.LastActionDate = GETDATE()
		FROM KYPEnrollment.pAccount_PDM_Vehicle vehicle
			INNER JOIN (SELECT vId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(v.TargetPath), 0, PATINDEX('%|%', (REVERSE(v.TargetPath))))), ''))
						      , v.EffectiveDate
                    FROM KYPPORTAL.PortalKYP.pPDM_Vehicle v
						            INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON p.PartyID = v.PartyID
                    WHERE v.TargetPath LIKE '%pAccount%'
						            AND v.IsDeleted = 0
                        AND (v.Approved IS NOT NULL AND v.Approved = 1)
                        AND p.ParentPartyID = @party_id) portalVehicle on portalVehicle.vId = vehicle.VehicleId
			AND CurrentRecordFlag = 1
	END

END

GO

