
CREATE VIEW [KYPEnrollment].[AlertHistoryView] as
select  row_number() over ( order by x.HistoryID )as HistoryID,x.AlertNumber, x.AccountID,x.MonStatus,x.DateModify,x.DateCreate,x.WatchlistCategory,x.AlertPartyName,x.MonRelevance
      from (select distinct HR.AlertNumber,HR.HistoryID, HR.AccountID,
      CONVERT(VARCHAR(10), HR.DateModify, 101) 
                        + ' ' + CONVERT(VARCHAR(8), HR.DateModify, 108) as DateModify ,
     CONVERT(VARCHAR(10), HR.DateCreate, 101) 
                        + ' ' + CONVERT(VARCHAR(8), HR.DateCreate, 108)  as DateCreate,
      HR.WatchlistCategory,HR.AlertPartyName ,HR.MonStatus,HR.MonRelevance  from KYPEnrollment.HIS_Alert HR
	inner join KYP.MDM_Alert MA on MA.AlertNo=HR.AlertNumber
	  inner join (select   RelatedID,HistoryID, row_number() over(partition by RelatedID, accountid order by LastActionDate desc) as rn
 
    from KYPEnrollment.pAccount_History 
   )tm    ON tm.RelatedID =MA.AlertID and tm.HistoryID=HR.HistoryID and tm.rn=1)

	  x


GO

