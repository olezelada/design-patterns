/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMLocation]
(@AddressID int
 ,@PartyID int
 ,@ProviderID int =NULL
 ,@PersonID int = NULL
 ,@Type varchar(25)=NULL
 ,@WorkingDays varchar(25)=NULL
 ,@WorkingHours varchar(25)=NULL
 ,@Phone1 varchar(15)=NULL
 ,@Phone2 varchar(15)=NULL
 ,@Fax varchar(15)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CurrentModule smallint=NULL
 ,@CreatedBy int = NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@InActive bit=1
 ,@IsDeleted bit=0

)
as begin 

INSERT INTO [KYP].[PDM_Location]
           ([AddressID]
           ,[PartyID]
           ,[ProviderID]
           ,[PersonID]
           ,[Type]
           ,[WorkingDays]
           ,[WorkingHours]
           ,[Phone1]
           ,[Phone2]
           ,[Fax]
           ,[Remarks]
           ,[CurrentModule]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[InActive]
           ,[IsDeleted])
     VALUES
           (@AddressID
           ,@PartyID
           ,@ProviderID
           ,@PersonID
           ,@Type
           ,@WorkingDays
           ,@WorkingHours
           ,@Phone1
           ,@Phone2
           ,@Fax
           ,@Remarks
           ,@CurrentModule
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@InActive
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[PDM_Location]')

end


GO

