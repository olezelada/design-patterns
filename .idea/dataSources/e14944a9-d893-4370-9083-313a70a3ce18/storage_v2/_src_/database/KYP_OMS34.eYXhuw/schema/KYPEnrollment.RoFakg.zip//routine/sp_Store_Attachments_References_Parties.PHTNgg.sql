-- =============================================
-- Author:		<Rloayza>
-- Create date: <07/15/2018>
-- Description:	<Store application account attachment references>
-- =============================================
CREATE PROCedure [KYPEnrollment].[sp_Store_Attachments_References_Parties]
  (
    @accountId INT,
    @applicationPartyId INT,
    @accountPartyId INT
  )

AS

  BEGIN

    BEGIN TRY

    IF @applicationPartyId IS NOT NULL AND @accountPartyId IS NOT NULL
      BEGIN

        IF NOT EXISTS(SELECT * FROM KYPEnrollment.pAccount_Attachments WHERE AccountPartyId = @accountPartyId AND ApplicationPartyId = @applicationPartyId AND IsDeleted <> 1)
          BEGIN
            INSERT INTO KYPEnrollment.pAccount_Attachments(AccountID, ApplicationPartyId, AccountPartyId)
            VALUES(@accountId, @applicationPartyId, @accountPartyId)
          END
        RETURN
      END

    END TRY

    BEGIN CATCH

    Exec [KYPEnrollment].[Usp_LogError] @KeyField = 'PartyID',@KeyValue = @accountPartyId

    END CATCH;

  END


GO

