-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [KYP].[p_BulkUpdateAlertonAccount]
-- @alertID INT
--,@CurrentlyAssignedToID VARCHAR(50)
--,@CurrentlyAssignedByID VARCHAR(50)
--,@MatchStatusIndicatordecription VARCHAR(15)
--,@WatchlistName VARCHAR(50)
--,@AlertCreatedDate datetime
--,@AlertCreatedBy int
--,@AlertRelevance varchar(20)
--,@Medicaid_id varchar(20)
--,@CurrentWFStatus VARCHAR(100)
--,@AlertNumber VARCHAR(15)
--,@DateResolved SMALLDATETIME
--,@PartyID int
--,@Priority VARCHAR(15)
--,@PartyName Varchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	





BEGIN
		BEGIN	 
          --drop table dbo.pADM_AccProvMapping /*PI-507,As this tbl does not exists*/

DELETE FROM KYPEnrollment.HIS_Alert;

	 INSERT into   KYPEnrollment.pAccount_History (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
	select distinct A.AlertID,Acc.AccountID,'53' ,A.CreatedDate,'System',GETDATE() ,'1' 
	 from kyp.MDM_Alert A 
	  inner join  KYP.MDM_SearchProviders PR on PR.AlertID =A.AlertID
	   inner join KYPEnrollment.pADM_Account Acc on Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode=PR.MedicaidID
	  left join KYPEnrollment.pAccount_History PH on PH.AccountID=Acc.AccountID and PH.ActionID=53
	    where A.IsMerged='N' and PH.AccountID is null
	
	INSERT into   KYPEnrollment.pAccount_History (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
	select distinct A.AlertID,Acc.AccountID,'53' ,A.CreatedDate,'System',GETDATE() ,'1' 
	 from kyp.MDM_Alert A 
	 inner join KYP.MDM_RelatedAlerts RA on RA.ChildAlertID=A.AlertID and  RA.MergedByUserID=1
	  inner join  KYP.MDM_SearchProviders PR on PR.AlertID =RA.ParentAlertID
	   inner join KYPEnrollment.pADM_Account Acc on Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode=pr.MedicaidID
	    left join KYPEnrollment.pAccount_History PH on PH.AccountID=Acc.AccountID and PH.ActionID=53
	 

	
	INSERT into KYPEnrollment.HIS_Alert (AccountID,HistoryID,AlertNumber,MonStatus,MonRelevance,CreatedBy,DateCreate,WatchlistCategory,AlertPartyName) 
		
	select distinct AH.AccountID,AH.HistoryID,A.AlertNo,A.MatchStatusIndicatorDesc, A.Priority,'System',A.CreatedDate,A.WatchlistName,A.WatchedPartyName
	 from kyp.MDM_Alert A 
	  
	 inner join KYPEnrollment.pAccount_History AH on AH.RelatedID=A.AlertID   and ActionID='53'
	
	 INSERT into   KYPEnrollment.pAccount_History 
	     (RelatedID,AccountID,ActionID,DateCreated,LastActorUserID,LastActionDate,CurrentRecordFlag)
	    select distinct PH.RelatedID,PH.AccountID,'54' ,PH.DateCreated,OA.UserID,GETDATE() ,'1' 
	     from  KYPEnrollment.pAccount_History PH 
	     inner join  KYP.MDM_Alert A on A.AlertID=PH.RelatedID
	     inner join kyp.OIS_User OA on OA.PersonID=A.AssignedToUserID
	     where PH.ActionID='53' and A.ActivityStatus='Completed'
	     
      INSERT into KYPEnrollment.HIS_Alert
      (AccountID,HistoryID,AlertNumber,MonStatus,MonRelevance,ModifiedBy,
      DateCreate,WatchlistCategory,DateModify,AlertPartyName,MonResolution) 
		
	select distinct PH.AccountID,PH.HistoryID,A.AlertNo,A.MatchStatusIndicatorDesc,
	 A.Priority,OA.UserID,A.CreatedDate,A.WatchlistName,A.DateClosed,
	A.WatchedPartyName  , STUFF((SELECT ', ' + CAST(Res.ResolutionType AS VARCHAR(MAX)) [text()]
									FROM kyp.MDM_AlertResolution Res
									WHERE Res.ProviderID=PR.ProviderID and Res.AlertID=A.AlertID and Res.IsDeleted=0 and
										 Res.ResolutionType in ('Suspend Account Temporarily',
										 'Suspend Account', 'Deactivate Account','Deactivate Provider As Deceased',
										 'Add to Internal Watch list','Enrollment Record Updated',
										 'Letter Sent to Provider','Notify Provider','Initiate Re-enrollment',
										 'Refer for Investigation','Refer to Legal','Refer to Program Integrity',
										 'Update Account','Update Account')
								FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') List_Output
	from  KYPEnrollment.pAccount_History PH 
	inner join KYP.MDM_Alert A on A.AlertID=PH.RelatedID
	 inner join kyp.OIS_User OA on OA.PersonID=A.AssignedToUserID
	 inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=PH.AccountID 
	 inner join KYP.MDM_SearchProviders PR on PR.MedicaidID=Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode and PR.AlertID=A.AlertID
	 where PH.RelatedID=A.AlertID and PH.ActionID='54'and A.ActivityStatus='Completed'
		

	
	INSERT into KYPEnrollment.HIS_Alert
      (AccountID,HistoryID,AlertNumber,MonStatus,MonRelevance,ModifiedBy,
      DateCreate,WatchlistCategory,DateModify,AlertPartyName,MonResolution) 
		
	select distinct PH.AccountID,PH.HistoryID,A.AlertNo,A.MatchStatusIndicatorDesc,
	 A.Priority,OA.UserID,A.CreatedDate,A.WatchlistName,A.DateClosed,
	A.WatchedPartyName  , STUFF((SELECT ', ' + CAST(Res.ResolutionType AS VARCHAR(MAX)) [text()]
									FROM kyp.MDM_AlertResolution Res
									WHERE Res.ProviderID=PR.ProviderID and Res.AlertID=RA.ParentAlertID and Res.IsDeleted=0 and
										 Res.ResolutionType in ('Suspend Account Temporarily',
										 'Suspend Account', 'Deactivate Account','Deactivate Provider As Deceased',
										 'Add to Internal Watch list','Enrollment Record Updated',
										 'Letter Sent to Provider','Notify Provider','Initiate Re-enrollment',
										 'Refer for Investigation','Refer to Legal','Refer to Program Integrity',
										 'Update Account','Update Account')
								FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') List_Output
	from  KYPEnrollment.pAccount_History PH 
	 inner join KYP.MDM_RelatedAlerts RA on RA.ChildAlertID=PH.RelatedID and  RA.MergedByUserID=1
	 inner join kyp.MDM_Alert A on A.AlertID=RA.ChildAlertID
	 inner join kyp.OIS_User OA on OA.PersonID=A.AssignedToUserID
	 inner join KYPEnrollment.pADM_Account Acc on  Acc.AccountID=PH.AccountID 
	 inner join KYP.MDM_SearchProviders PR on PR.MedicaidID=Acc.NPI+Acc.OwnerNo+Acc.ServiceLocationNo+Acc.ProviderTypeCode and PR.AlertID=RA.ParentAlertID
	 where PH.ActionID='54'and A.ActivityStatus='Completed' 
	
	END
							
		END
		END
GO

