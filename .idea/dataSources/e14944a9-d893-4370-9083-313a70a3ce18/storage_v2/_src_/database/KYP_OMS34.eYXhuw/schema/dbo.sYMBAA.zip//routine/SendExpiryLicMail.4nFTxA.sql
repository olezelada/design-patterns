CREATE PROCEDURE [dbo].[SendExpiryLicMail]
As
begin

DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
Declare @EmailAdd varchar(500)
Declare @Sender varchar(500)
Declare @Sub varchar(max)
Declare @Amail varchar(max)
declare @ALIASNAME VARCHAR(100)

SELECT TOP 1 @ALIASNAME = KYPALIAS FROM KYP.OIS_App_Version WHERE InstalledDate = (SELECT MAX(InstalledDate) FROM KYP.OIS_App_Version)
        
IF (@ALIASNAME IS NULL OR @ALIASNAME = '')
BEGIN
	SET @ALIASNAME = 'KYP';
END

select @Sender=ReminderToMailID from KYP.MDM_ReminderMailID where ReminderName ='SenderEmailID'
select @Amail=ReminderToMailID from KYP.MDM_ReminderMailID where ReminderName ='AdminEmailID'


select @EmailAdd=ReminderToMailID from KYP.MDM_ReminderMailID where ReminderName ='ExpiringLicenseReminder'


SET @xml = CAST(( SELECT [ProviderName] AS 'td','',[ProviderMedicaid] AS 'td','',
       [ProviderLicenseNo] AS 'td','',cast([ProviderLicenseExpiryDate] as date) AS 'td'
FROM  KYP.v_LicenseExpiry_Reminder 
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))


SET @body ='Licenses of Providers with following details are due to expire next month 
'+' '+ Datename(MONTH ,DATEADD(m,1,getdate())) + ' ' + convert(varchar(50),DATEPART(yyyy, DATEADD(m,1,getdate())))+ '<BR><html><body><H3></H3>
<table border = 1> 
<tr>
<th> Name </th> <th> MedicaidID </th> <th> LicenseNo </th><th> Expiry Date </th></tr>'    

 
SET @body =@body + @xml +'</table>'+'<BR><BR>-----<BR>This is a system generated message. <BR>
Please do not reply.If you think it was sent incorrectly, contact the system administrator at' + ' '+@Amail+'</body></html>'
Set @Sub='[' + @ALIASNAME + '] Notification: Provider licenses expiring in '+' '+ Datename(MONTH ,DATEADD(m,1,getdate())) + ' ' + convert(varchar(50),DATEPART(yyyy, DATEADD(m,1,getdate())))


EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'administrator', -- replace with your SQL Database Mail Profile 
@body = @body,
@body_format ='HTML',
--@recipients = 'sheetal.savagaonkar@dharbor.com', -- replace with your email address
@recipients = @EmailAdd,
@subject = @Sub ;
end


GO

