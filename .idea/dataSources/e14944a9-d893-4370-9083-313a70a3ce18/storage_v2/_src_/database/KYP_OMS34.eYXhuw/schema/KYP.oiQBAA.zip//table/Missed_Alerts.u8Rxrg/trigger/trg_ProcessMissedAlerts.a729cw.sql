

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [KYP].[trg_ProcessMissedAlerts]
   ON  [KYP].[Missed_Alerts] 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
DECLARE @alertno VARCHAR(10)
DECLARE @PARENTID NVARCHAR(MAX)
declare @Count int
declare @parentNos int

SELECT @alertno = AlertNo FROM Inserted	

set @parentNos =1

Select @Count = count(distinct parent) from [dbo].[PROCESS_TABLE]
where PROCESSID 
in(SELECT PROCESSID from PJ_MDM_ALERT where ALERTID in (select ALERTID from kyp.MDM_Alert where AlertNo=@alertno))

while(@parentNos<=@Count)
begin
	select @PARENTID = x.parent from(
	Select distinct parent, ROW_NUMBER()over (order by parent)as row from [dbo].[PROCESS_TABLE]
	where PROCESSID 
	in(SELECT PROCESSID from PJ_MDM_ALERT where ALERTID in (select ALERTID from kyp.MDM_Alert where AlertNo=@alertno)))x
	where x.row=@parentNos
	

	DELETE from [dbo].[PROCESS_TABLE] where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )
	DELETE from dbo.PROCESS_ACTORS_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )
	DELETE from dbo.PROCESS_ATTRIBUTES_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )
	DELETE from dbo.PROCESS_INPUTS_ARRAY_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )
	DELETE from dbo.PROCESS_INPUTS_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )
	DELETE from dbo.PROCESS_OUTPUTS_ARRAY_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )

	DELETE from dbo.PROCESS_RESOURCES_TABLE where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )

	DELETE from dbo.PJ_MDM_ALERT where PROCESSID in 
	( SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID )

	DELETE from dbo.PROCESS_EDGE_TABLE where PROCESS_ID IN 
	(SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID)

	DELETE from dbo.PJ_OIS_USER where PROCESSID IN 
	(SELECT PROCESSID FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID)


	DELETE FROM dbo.PROCESS_TABLE WHERE PARENT = @PARENTID

	set @parentNos = @parentNos+1

end

begin	
	declare @AlertID Int 		
	select @AlertID = alertid from kyp.MDM_Alert with(nolock) where AlertNo=@alertno
	
	SELECT ResolutionID, ResolutionType, ProviderMedicaidID into #tmpres FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID 
	 
	delete from kyp.MDM_ResolutionHistory where AlertID=@AlertID
					
	delete  x
	from KYP.MDM_AlertPIUReferral x
	inner join #tmpres y
	on x.ResolutionID= y.ResolutionID

	delete  x
	from KYP.MDM_AlertOIGReferral x
	inner join #tmpres y
	on x.ResolutionID= y.ResolutionID

	delete  x
	from KYP.MDM_AlertPvdSuspension x
	inner join #tmpres y
	on x.ResolutionID= y.ResolutionID

	delete  x
	from KYP.MDM_AlertNewResolutions x
	inner join #tmpres y
	on x.ResolutionID= y.ResolutionID


	delete from KYP.MDM_AlertResolution where AlertID= @AlertID
		
	
	delete from KYP.OIS_JT_NoteTag  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertPvdSuspension WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID)) 
	delete from KYP.OIS_JT_NoteTag  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertPIUReferral WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_JT_NoteTag  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertOIGReferral WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_JT_NoteTag  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertNewResolutions WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_JT_NoteTag where noteid IN ( 
	select NoteID from KYP.OIS_Note  WHERE TYPE in('Disposition','Special Instructions') AND RelatedEntityType = 'MDM_Alert' AND RelatedEntityID = @AlertID)
	delete from KYP.OIS_JT_NoteTag where noteid in (select noteid from kyp.OIS_Note where RelatedEntityID =@AlertID)
	delete from KYP.OIS_JT_NoteTag where noteid in (select noteid from kyp.OIS_Note where AlertID =@AlertID)
	delete from KYP.OIS_JT_NoteTag where noteid in (select confirmationnoteid from kyp.MDM_Alert where AlertID =@AlertID)

	delete from KYP.OIS_Note where noteid in (select confirmationnoteid from kyp.MDM_Alert where AlertID =@AlertID)
	delete from kyp.OIS_Note where AlertID = @AlertID
	delete from KYP.OIS_Note  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertPvdSuspension WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID)) 
	delete from KYP.OIS_Note  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertPIUReferral WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_Note  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertOIGReferral WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_Note  WHERE NoteID IN (SELECT ResolutionNoteID FROM KYP.MDM_AlertNewResolutions WHERE ResolutionID IN (SELECT ResolutionID FROM KYP.MDM_AlertResolution WHERE AlertID = @AlertID))
	delete from KYP.OIS_Note  WHERE TYPE = 'Disposition' AND RelatedEntityType = 'MDM_Alert' AND RelatedEntityID = @AlertID
	delete from KYP.OIS_Note  WHERE TYPE = 'Special Instructions' AND RelatedEntityType = 'MDM_Alert' AND RelatedEntityID = @AlertID
	
	 
	delete from KYP.OIS_JT_TagAttachment where AttachmentID in(
	select attachmentid from kyp.OIS_Attachment where AbsolutePath like '%'+@alertno+'%' and coalesce(FileName,'')<>'')

	delete from KYP.AttachmentEntity where AttachmentID in(
	select attachmentid from kyp.OIS_Attachment where AbsolutePath like '%'+@alertno+'%' and coalesce(FileName,'')<>'')

	delete from KYP.OIS_DocumentVersion where AttachmentID in(
	select attachmentid from kyp.OIS_Attachment where AbsolutePath like '%'+@alertno+'%' and coalesce(FileName,'')<>'')

	DELETE from kyp.OIS_Attachment where AbsolutePath like '%'+@alertno+'%' and coalesce(FileName,'')<>''
	
	delete from kyp.MDM_DashBoardTable where AlertID=@AlertID
	
	ALTER TABLE KYP.MDM_SearchProviders DISABLE TRIGGER trg_MDM_SearchProvidersOnUpdate
	
	UPDATE KYP.MDM_SearchProviders SET Remarks =NULL,Impacted=0
	WHERE  AlertID = @AlertID AND SearchID IN (SELECT SearchID FROM KYP.MDM_ImpProviders WHERE AlertID = @AlertID)

	ALTER TABLE KYP.MDM_SearchProviders ENABLE TRIGGER trg_MDM_SearchProvidersOnUpdate
			
	 
	UPDATE KYP.MDM_ImpProviders SET Remarks =NULL,CreatedBy =NULL,CreatedDate =NULL,ModifiedBy =NULL,ModifiedDate =NULL,IsDeleted = 1
	 WHERE AlertID = @AlertID

end

END


GO

