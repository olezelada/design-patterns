

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[DeleteUsers] ON [dbo].[USERTABLE]
AFTER DELETE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- Insert statements for trigger here
	DECLARE @UserID VARCHAR(200),
		@PersonID INT;

	SELECT @UserID = [USER_NAME]
	FROM deleted

	SELECT @PersonID = PersonID FROM KYP.OIS_User WITH(NOLOCK) WHERE UserID = @UserID	
	
	--ALTER TABLE KYP.OIS_User DISABLE TRIGGER UpdateUserDetails
	
	UPDATE KYP.OIS_User
	SET ACTIVE = 0
	,Row_Updation_Source = 'dbo.UserTable.DeleteUsers'
	WHERE UserID = @UserID
	
	UPDATE KYP.OIS_Person
	SET Deleted = 1
	WHERE PersonID = @PersonID
	
	--ALTER TABLE KYP.OIS_User ENABLE TRIGGER UpdateUserDetails
END
GO

