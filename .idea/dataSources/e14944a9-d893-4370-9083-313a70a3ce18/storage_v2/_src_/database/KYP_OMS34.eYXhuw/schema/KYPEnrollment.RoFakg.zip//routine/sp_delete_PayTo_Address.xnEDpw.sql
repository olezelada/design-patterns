-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <09/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the PAYMENT address of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_PayTo_Address] 
@new_Account_Id int

AS
BEGIN
Declare @address int,@location int
	SET NOCOUNT ON;

select @location= l.LocationID , @address = ad.AddressID 
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Location l ON p.PartyID=l.PartyID INNER JOIN KYPEnrollment.pAccount_PDM_Address ad
ON ad.AddressID=l.AddressID where l.Type='Pay-to' and a.AccountID=@new_Account_Id and a.IsDeleted=0 and l.CurrentRecordFlag=1 and l.IsDeleted=0
and a.IsDeleted=0

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Address','AddressID',@address

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Location','LocationID',@location

END


GO

