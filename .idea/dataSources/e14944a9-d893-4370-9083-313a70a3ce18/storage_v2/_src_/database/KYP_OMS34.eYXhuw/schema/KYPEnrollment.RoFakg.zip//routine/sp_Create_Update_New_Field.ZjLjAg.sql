

CREATE PROCEDURE [KYPEnrollment].[sp_Create_Update_New_Field]
	@en_db_column VARCHAR(100),
	@last_action_user_id VARCHAR(100),
	@action_taken VARCHAR(50),
	@account_id INT,
	@section_nanme VARCHAR(100),
	@account_party_id INT,
	@new_value_text VARCHAR (250),
	@target_path varchar(200),
	@new_fields_values VARCHAR (MAX),
	@new_value_date DATE,
	@application_Code VARCHAR(50),
  @field_code VARCHAR(50),
  @party_id_provider INT,
  @section_code VARCHAR (30)
AS
BEGIN

	DECLARE @today_date DATE = GETDATE()
	DECLARE @is_deleted BIT = 0
	DECLARE @current_record_flag BIT = 1
	DECLARE @last_action VARCHAR(1) = 'C'

	DECLARE @acc_address_id INT
	DECLARE @acc_document_id INT
	DECLARE @liability_id INT
	DECLARE @malpractice_id INT
	DECLARE @business_permit_id INT
	DECLARE @business_license_id INT
	DECLARE @deaId INT
	DECLARE @cliaId INT
	DECLARE @place_id INT
	DECLARE @questionnaireId INT
	DECLARE @numberId INT

  PRINT 'sp_Create_Update_New_Field'


    IF @section_nanme = 'Residential Address'
    BEGIN

						SELECT @acc_address_id = addr.AddressID
                        FROM KYPEnrollment.pAccount_PDM_Address addr,
                              KYPEnrollment.pAccount_PDM_Location loc,
                              KYPEnrollment.pAccount_PDM_Party par
                        WHERE addr.AddressID = loc.AddressID AND par.PartyID = loc.PartyID AND par.PartyID = @account_party_id AND addr.AddressType = 'Individual Profile'

            IF (@acc_address_id is null OR @acc_address_id = 0 )
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_Address ([CurrentRecordFlag],[AddressType],[LastAction],[LastActionDate],[LastActionUserID])
                                                        VALUES (@current_record_flag,'Individual Profile',@last_action,@today_date,@last_action_user_id);

                SET @acc_address_id = SCOPE_IDENTITY()

                INSERT INTO KYPEnrollment.pAccount_PDM_Location ([PartyID],[AddressID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                         VALUES (@account_party_id,@acc_address_id,'Individual Profile',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
              END

            IF @en_db_column = 'AddressLine1'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Address set AddressLine1 = @new_value_text WHERE AddressID = @acc_address_id
              END

             IF @en_db_column = 'AddressLine2'
              BEGIN
                 UPDATE KYPEnrollment.pAccount_PDM_Address set AddressLine2 = @new_value_text WHERE AddressID = @acc_address_id
              END

            IF @en_db_column = 'City'
              BEGIN
                 UPDATE KYPEnrollment.pAccount_PDM_Address set City = @new_value_text WHERE AddressID = @acc_address_id
              END

             IF @en_db_column = 'State'
              BEGIN
                 UPDATE KYPEnrollment.pAccount_PDM_Address set State = @new_value_text WHERE AddressID = @acc_address_id
              END

             IF @en_db_column = 'County'
              BEGIN
                 UPDATE KYPEnrollment.pAccount_PDM_Address set County = @new_value_text WHERE AddressID = @acc_address_id
              END

             IF @en_db_column = 'ZipPlus4'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Address set ZipPlus4 = @new_value_text WHERE AddressID = @acc_address_id
              END

    END

    IF @section_nanme = 'Identification'
    BEGIN

        SELECT @acc_document_id = DocumentID
                            FROM KYPEnrollment.pAccount_PDM_Document doc,
                                  KYPEnrollment.pAccount_PDM_Party par
                            WHERE par.PartyID = doc.PartyID AND par.PartyID = @account_party_id AND doc.TypeDoc IN ('Driver''s License','State Issued ID','No Data')

        IF (@acc_document_id is null OR @acc_document_id = 0) AND @en_db_column is not null AND @target_path is null
          BEGIN
            INSERT INTO KYPEnrollment.pAccount_PDM_Document ([PartyID],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                     VALUES (@account_party_id,@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

            SET @acc_document_id = SCOPE_IDENTITY()

          END

          IF @en_db_column = 'TypeDoc'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set TypeDoc = @new_value_text WHERE DocumentID = @acc_document_id
            END

          IF @en_db_column = 'NumberDoc'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set NumberDoc = @new_value_text WHERE DocumentID = @acc_document_id
            END

          IF @en_db_column = 'StateIssued'
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Document set StateIssued = @new_value_text WHERE DocumentID = @acc_document_id
            END
    END

    IF @section_nanme IN ('TIN/EIN & Business License','EIN/Business License')
    BEGIN

          SELECT @business_license_id = NumberID
                            FROM KYPEnrollment.pAccount_PDM_Number
                            WHERE PartyID = @account_party_id AND Type IN ('BusinessEinLicenses')

          IF (@business_license_id is null OR @business_license_id = 0) AND @en_db_column is not null AND @target_path is null
            BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_Number ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                     VALUES (@account_party_id,'BusinessEinLicenses',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

              SET @business_license_id = SCOPE_IDENTITY()

            END

          IF @en_db_column = 'Number' AND @target_path is null
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Number set Number = @new_value_text WHERE NumberID = @business_license_id
            END

    END

    IF @section_nanme = 'Business Permits'
    BEGIN

        SELECT @business_permit_id = NumberID
                            FROM KYPEnrollment.pAccount_PDM_Number
                            WHERE PartyID = @account_party_id AND Type IN ('BusinessPermits')

          IF (@business_permit_id is null OR @business_permit_id = 0) AND @en_db_column is not null AND @target_path is null
            BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_Number ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                     VALUES (@account_party_id,'BusinessPermits',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

              SET @business_permit_id = SCOPE_IDENTITY()

            END

          IF @en_db_column = 'Number' AND @target_path is null
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Number set Number = @new_value_text WHERE NumberID = @business_permit_id
            END
    END

    IF @section_nanme in ('Liability Insurance', 'General Liability Insurance')
    BEGIN

          SELECT @liability_id = InsuranceID
                            FROM KYPEnrollment.pAccount_PDM_Insurance
                            WHERE PartyID = @account_party_id AND Type IN ('Insurance')

          IF @liability_id is null OR @liability_id = 0
            BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_Insurance ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                        VALUES (@account_party_id,'Insurance',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

                SET @liability_id = SCOPE_IDENTITY()

            END

          IF @en_db_column = 'PolicyNumber'
            BEGIN
              UPDATE KYPEnrollment.pAccount_PDM_Insurance set PolicyNumber = @new_value_text WHERE InsuranceID = @liability_id
            END
    END

    IF @section_nanme = 'Malpractice Insurance'
    BEGIN

            SELECT @malpractice_id = InsuranceID
                              FROM KYPEnrollment.pAccount_PDM_Insurance
                              WHERE PartyID = @account_party_id AND Type IN ('InsurancePage3')
            IF @malpractice_id is null OR @malpractice_id = 0
              BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_Insurance ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                          VALUES (@account_party_id,'InsurancePage3',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);

                  SET @malpractice_id = SCOPE_IDENTITY()
              END

            IF @en_db_column = 'PolicyNumber'
              BEGIN
                UPDATE KYPEnrollment.pAccount_PDM_Insurance set PolicyNumber = @new_value_text WHERE InsuranceID = @malpractice_id
              END
    END

    IF (@section_nanme = 'Prof. Licenses, Certificates & Lab Services' OR @section_nanme = 'CLIA/State Lab registration' OR @section_nanme = 'Lab Services')
    BEGIN

        IF @en_db_column = 'DEA' OR @en_db_column = 'ExpiryDate'
          BEGIN
                SELECT @deaId = DeaID
                              FROM KYPEnrollment.pAccount_PDM_DEA
                              WHERE PartyID = @account_party_id
                IF @deaId is null OR @deaId = 0
                  BEGIN
                    INSERT INTO KYPEnrollment.pAccount_PDM_DEA ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedBy])
                VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
                      SET @deaId = SCOPE_IDENTITY()
                  END

                IF @en_db_column = 'DEA'
                  BEGIN
                    UPDATE KYPEnrollment.pAccount_PDM_DEA set DEA = @new_value_text WHERE DeaID = @deaId
                  END

                IF @en_db_column = 'ExpiryDate'
                  BEGIN
                    UPDATE KYPEnrollment.pAccount_PDM_DEA set ExpiryDate = @new_value_date WHERE DeaID = @deaId
                  END
          END

          IF @en_db_column = 'RegistrationNumber' OR @en_db_column = 'CertificationNumber' OR  @en_db_column = 'CliaNumber'
            BEGIN
                  SELECT @cliaId = CliaID
                                FROM KYPEnrollment.pAccount_PDM_Clia
                                WHERE PartyID = @account_party_id

                  IF @cliaId is null OR @cliaId = 0
                    BEGIN
                      INSERT INTO KYPEnrollment.pAccount_PDM_Clia ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedByUsedID])
                                                            VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
                        SET @cliaId = SCOPE_IDENTITY()
                    END

                  IF @en_db_column = 'RegistrationNumber'
                    BEGIN
                      UPDATE KYPEnrollment.pAccount_PDM_Clia set RegistrationNumber = @new_value_text WHERE CliaID = @cliaId
                    END

                  IF @en_db_column = 'CertificationNumber'
                    BEGIN
                      UPDATE KYPEnrollment.pAccount_PDM_Clia set CertificationNumber = @new_value_text WHERE CliaID = @cliaId
                    END

                  IF @en_db_column = 'CliaNumber'
                    BEGIN
                      UPDATE KYPEnrollment.pAccount_PDM_Clia set CliaNumber = @new_value_text WHERE CliaID = @cliaId
                    END
            END

    END

    IF @section_nanme = 'Licenses, Certificates Permits'
    BEGIN

      IF @en_db_column = 'Number' OR @en_db_column = 'SecondNumber' OR @en_db_column = 'EffectiveDate'
      BEGIN
        SELECT @numberId = NumberID
                            FROM KYPEnrollment.pAccount_PDM_Number
                            WHERE PartyID = @account_party_id AND Type IN ('Professional License')

          IF (@numberId is null OR @numberId = 0) AND @en_db_column is not null AND @target_path is null
            BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_Number ([PartyID],[Type],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                     VALUES (@account_party_id,'Professional License',@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
              SET @numberId = SCOPE_IDENTITY()
            END

          IF @en_db_column = 'Number' AND @target_path is null
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Number set Number = @new_value_text WHERE NumberID = @numberId
            END

          IF @en_db_column = 'SecondNumber' AND @target_path is null
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Number set SecondNumber = @new_value_text WHERE NumberID = @numberId
            END

          IF @en_db_column = 'EffectiveDate' AND @target_path is null
            BEGIN
               UPDATE KYPEnrollment.pAccount_PDM_Number set EffectiveDate = @new_value_date WHERE NumberID = @numberId
            END
      END

      IF @en_db_column = 'DEA'
      BEGIN
         SELECT @deaId = DeaID
                        FROM KYPEnrollment.pAccount_PDM_DEA
                        WHERE PartyID = @account_party_id

          IF (@deaId is null OR @deaId = 0) AND @en_db_column is not null AND @target_path is null
            BEGIN
                INSERT INTO KYPEnrollment.pAccount_PDM_DEA ([PartyID], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedBy])
                                                    VALUES (@account_party_id, @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
                SET @deaId = SCOPE_IDENTITY()
            END

          IF @en_db_column = 'DEA' AND @target_path is null
            BEGIN
              UPDATE KYPEnrollment.pAccount_PDM_DEA set DEA = @new_value_text WHERE DeaID = @deaId
            END
      END

      IF @en_db_column = 'Value'
      BEGIN
        SELECT @questionnaireId = QuestionID
                        FROM KYPEnrollment.pAccount_PDM_ProviderQuestionnarie
                        WHERE PartyID = @account_party_id AND TYPE = 'Professional License' AND Name = 'sellerPermit'

        IF (@questionnaireId is null OR @questionnaireId = 0) AND @en_db_column is not null AND @target_path is null
          BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_ProviderQuestionnarie ([PartyID],[Type],[Name], [CurrentRecordFlag], [LastAction], [LastActionDate], [LastActorUserID], [LastActionApprovedBy])
                                                                    VALUES (@account_party_id, 'Professional License' , 'sellerPermit' , @current_record_flag, @last_action, @today_date, @last_action_user_id, @last_action_user_id);
              SET @questionnaireId = SCOPE_IDENTITY()
          END

          IF @en_db_column = 'Value' AND @target_path is null
          BEGIN
            UPDATE KYPEnrollment.pAccount_PDM_ProviderQuestionnarie set Value = @new_value_text WHERE QuestionID = @questionnaireId
          END
      END
    END
    
    IF @section_nanme = 'Place of Business'
      BEGIN

          SELECT @place_id = PlaceBusinessID  FROM KYPEnrollment.pAccount_PDM_PlaceBusiness  WHERE PartyId = @account_party_id

          IF @place_id is null OR @place_id = 0 OR @place_id = ''
            BEGIN
              INSERT INTO KYPEnrollment.pAccount_PDM_PlaceBusiness ([PartyId],[CurrentRecordFlag],[IsDeleted],[DateCreated],[LastAction],[LastActionDate],[LastActorUserID])
                                                            VALUES (@account_party_id,@current_record_flag,@is_deleted,@today_date,@last_action,@today_date,@last_action_user_id);
                SET @place_id = SCOPE_IDENTITY()
            END

          IF @en_db_column = 'PrimaryAnswer'
            BEGIN
              UPDATE KYPEnrollment.pAccount_PDM_PlaceBusiness set PrimaryAnswer = @new_fields_values WHERE PlaceBusinessID = @place_id
            END

           IF @en_db_column = 'SecondAnswer'
            BEGIN
              UPDATE KYPEnrollment.pAccount_PDM_PlaceBusiness set SecondAnswer = @new_fields_values WHERE PlaceBusinessID = @place_id
            END

           IF @en_db_column = 'ThirdAnswer'
            BEGIN
              UPDATE KYPEnrollment.pAccount_PDM_PlaceBusiness set ThirdAnswer = @new_fields_values WHERE PlaceBusinessID = @place_id
            END

          -- FOR THE SECTION WITH TWO RADIOS
          IF  (@field_code IN ('leaseOption','ownOption')
                AND (@target_path NOT LIKE '%|%' OR @target_path IS NULL)
                AND @application_Code IN ('F_PI_OE', 'F_PI_SP', 'F_CAEL_SP', 'F_CAEL_OE', 'F_CNAEL_SP', 'F_CNAEL_OE', 'F_OOS_OE', 'F_BB_SP', 'F_BB_OE'))
          BEGIN
              DECLARE @type_Radio VARCHAR(50),@type_answer_two VARCHAR(50),@type_answer_Three VARCHAR(100),@newPartyPlace INT

              SELECT @type_Radio = PrimaryAnswer, @type_answer_two = SecondAnswer, @type_answer_Three = ThirdAnswer
	            FROM  [KYPPORTAL].[PortalKYP].[pPDM_PlaceBusiness] WHERE PartyID =@party_id_provider;

              UPDATE KYPEnrollment.pAccount_PDM_PlaceBusiness
              SET PrimaryAnswer = @type_Radio,  SecondAnswer = @type_answer_two, ThirdAnswer = @type_answer_Three
              WHERE PlaceBusinessID = @place_id

              SELECT @newPartyPlace = COUNT (PartyID) FROM [KYPPORTAL].[PortalKYP].[pPDM_Party]
              WHERE Type = 'Lease Information' AND ParentPartyID = @party_id_provider AND IsDeleted = 0 AND  TargetPath NOT LIKE '%|%';
              IF (@newPartyPlace = 1)
              BEGIN
                EXEC [KYPEnrollment].[sp_Copy_Place_Business_Two_Radios] @account_party_id, @party_id_provider, @last_Action_User_ID,  @account_id, 1;
              END
          END

      END
END

GO

