











-- =============================================
-- Author:		<Rahul Raghavendra>
-- recive 2 parametros
-- @Number id Number of applictaion ,@UserID  User who as genertaed the letter
-- =============================================
CREATE PROCEDURE [KYP].[sp_MD_Letter_AllData]
	 @Number varchar(20),
	@UserID varchar(200),
	@P_PRACT_TY_CD varchar(200),
	@LetterName varchar(200)
AS
BEGIN

if(@P_PRACT_TY_CD='Accounts')
	begin
	PRINT 'TEST123'
		INSERT INTO KYP.MD_LetterAllData
			(Name, 
			AddressLine1, 
			AddressLine2, 
			City, 
			state, 
			ZipPlus4, 
			LegacyAccountNo, 
			NPI, 
			ApplicationNo, 
			--ProviderTypeCode, 
			--TypeDescription, 
			--ApplnType, 
			PartyID, 
			--ReviewerFullName, 
			UserID,
			EnrollmentStatus
			)	
			select 
			Name,
			AddressLine1,
			--Case when (ISNULL(AddressLine2 ,'') Or AddressLine2='')  = '' then ','+' '+AddressLine2 end  as AddressLine,
			Case when (AddressLine2 IS null Or AddressLine2='')  then '' else ','+' '+AddressLine2 end  as AddressLine,
			City,
			state,
			ZipPlus4,
			LegacyAccountNo,
			NPI,
			ApplicationNo,
			--ProviderTypeCode,
			--TypeDescription,
			--ApplnType,
			PartyID,
			--FullName
			@UserID,
			EnrollmentStatus
			from (
				select 
					case when (A.NPIType='Individual') then (isnull(E.FirstName,'')+' '+isnull(LEFT(E.MiddleName, 1),'')+' '+isnull(E.LastName,'')) 
					else D.LegalName end as Name,
					C.AddressLine1 as AddressLine1,
					C.AddressLine2 as AddressLine2,
					C.City as City,
					F.Abreviation as state ,
					C.ZipPlus4  as ZipPlus4,
					A.LegacyAccountNo,A.NPI,A.ApplicationNumber as ApplicationNo,--f.ProviderTypeCode,f.TypeDescription,f.ApplnType,
					A.PartyID,
					isnull(CONVERT(VARCHAR(300),A.StatusBeginDate,101),T.Abreviation) as EnrollmentStatus
					--,H.FullName 

					 from 
					KYPEnrollment.pADM_Account A 
					left join KYPEnrollment.pAccount_PDM_Location B on B.PartyID= A.partyid and B.Type='Mailing'
					left join KYPEnrollment.pAccount_PDM_Address C on C.AddressID=B.AddressID
					left join KYPEnrollment.pAccount_PDM_Organization D on A.partyid= D.PartyID
					left join KYPEnrollment.pAccount_PDM_Person E on A.partyid= E.PartyID
					left join KYP.LK_Screening F on F.Description=C.State and TypeID=4
					left join KYP.LK_Screening T on T.TypeID=407 and T.Description=@LetterName
					where A.AccountID=@Number
) T
			
	end
else
	begin
		INSERT INTO KYP.MD_LetterAllData
				(Name, 
				AddressLine1, 
				AddressLine2, 
				City, 
				state, 
				ZipPlus4, 
				LegacyAccountNo, 
				NPI, 
				ApplicationNo, 
				ProviderTypeCode, 
				TypeDescription, 
				ApplnType, 
				PartyID, 
				ReviewerFullName, 
				UserID,
				EnrollmentStatus
				)	
				select 
				Name,
				AddressLine1,
				--Case when (ISNULL(AddressLine2 ,'') Or AddressLine2='')  = '' then ','+' '+AddressLine2 end  as AddressLine,
				Case when (AddressLine2 IS null Or AddressLine2='')  then '' else ','+' '+AddressLine2 end  as AddressLine,
				City,
				state,
				ZipPlus4,
				LegacyAccountNo,
				NPI,
				ApplicationNo,
				ProviderTypeCode,
				TypeDescription,
				ApplnType,
				PartyID,
				FullName,
				@UserID,
				EnrollmentStatus
				from (
					select 
						case when (A.NpiType='Individual') then (isnull(E.FirstName,'')+' '+isnull(LEFT(E.MiddleName, 1),'')+' '+isnull(E.LastName,'')) else D.LegalName end as Name,
						--case when (F.P_PRACT_TY_CD in('RS','Rendering','NMP')) then r.AddressLine1 else C.AddressLine1 end as AddressLine1,
						--case when (F.P_PRACT_TY_CD in('RS','Rendering','NMP')) then r.AddressLine2 else C.AddressLine2 end as AddressLine2,
						--case when (F.P_PRACT_TY_CD in('RS','Rendering','NMP'))then r.City else C.City end as City,
						--case when (F.P_PRACT_TY_CD in('RS','Rendering','NMP')) then r.state else C.StateCode end as state ,
						--case when (F.P_PRACT_TY_CD in('RS','Rendering','NMP'))then r.ZipPlus4 else C.ZipPlus4 end as ZipPlus4,
						 C.AddressLine1 as AddressLine1,
						C.AddressLine2 as AddressLine2,
						C.City as City,
						Z.Abreviation as state ,
						C.ZipPlus4 as ZipPlus4,
						G.LegacyAccountNo,A.NPI,A.ApplicationNo,f.ProviderTypeCode,f.TypeDescription,f.ApplnType,A.PartyID,H.FullName,
						isnull(CONVERT(VARCHAR(300),G.StatusBeginDate,101),T.Abreviation) as EnrollmentStatus 
						 from 
						 KYPPORTAL.PortalKYP.pADM_Application A 
						 left join KYPEnrollment.PortalAddress c on c.PortalCaseID=A.CaseID 
						--left join KYPPORTAL.PortalKYP.pPDM_Location B on B.PartyID= A.PartyID and B.Type='Mailing'
						--left join KYPPORTAL.PortalKYP.pPDM_Address C on C.AddressID=B.AddressID
						left join KYP.ADM_Case F on A.ApplicationNo=F.Number
						--left join KYP.ADM_Application I on I.ApplicationNo=A.ApplicationNo
						--left join KYP.SDM_ApplicationParty j on j.ApplicationID=I.ApplicationID and (j.PartyType='Provider Person' or j.PartyType='Provider Organization')
						left join KYPPORTAL.PortalKYP.pPDM_Organization D on A.PartyID= D.PartyID
						left join KYPPORTAL.PortalKYP.pPDM_Person E on A.PartyID= E.PartyID
						left join KYPEnrollment.pADM_Account G on f.AccountNo=G.AccountNumber
						left join KYP.OIS_User H on f.CurrentlyAssignedToID=H.PersonID
						--left join KYP.MD_AllAddresses R on R.Number = A.ApplicationNo and R.UserID=@UserID
						left join KYP.LK_Screening T on T.TypeID=407 and T.Description=@LetterName
						left join KYP.LK_Screening Z on Z.Description=C.State and Z.TypeID=4

						where A.ApplicationNo=@Number
			) T
end
END


GO

