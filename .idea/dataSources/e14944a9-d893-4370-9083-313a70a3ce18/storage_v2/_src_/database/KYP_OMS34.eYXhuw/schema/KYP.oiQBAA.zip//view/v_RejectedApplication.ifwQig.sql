






CREATE VIEW [KYP].[v_RejectedApplication]
as
SELECT
	row_number() OVER (ORDER BY AC.CaseID ASC) AS ID,
	AC.CaseID as CaseID,
	AC.Number as TrackingNo,
	AC.ProviderName as Provider,
	AC.TypeDescription as ProviderType,
	SR.ReviewStatus as ReasonCode,
	SR.DateCreated as RejectedDate,
	AC.UserFullName AS UserFullName,
	AC.Risk As ScreeningLevel,
	AC.PAN AS Application,		
	AC.CurrentlyAssignedToID,
	OS.UserID

FROM  KYP.ADM_Case AC

	INNER JOIN KYP.ADM_Application AA
	ON AA.CaseID=AC.CaseID
	INNER JOIN KYP.SDM_Resolution SR
	ON AA.ApplicationID=SR.ApplicationID and SR.DateCreated = (select MAX(DateCreated) from KYP.SDM_Resolution a where a.ApplicationID = AA.ApplicationID  )
	AND SR.ResolutionID = (Select MAX(ResolutionID) from KYP.SDM_Resolution b where b.ApplicationID = AA.ApplicationID AND b.ResolutionSubType = 'Rejected')
	LEFT OUTER JOIN KYP.OIS_User OS
	ON AC.CurrentlyAssignedToID=OS.PersonID
	WHERE SR.ResolutionSubType='Rejected' and SR.IsDeleted = 0 
	AND AC.WFStatus = 'Completed'


GO

