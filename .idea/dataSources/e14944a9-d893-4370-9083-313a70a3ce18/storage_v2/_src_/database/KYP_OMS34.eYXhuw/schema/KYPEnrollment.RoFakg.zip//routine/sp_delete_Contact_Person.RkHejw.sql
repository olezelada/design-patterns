-- =============================================
-- Author:		<Lacunza, Giresse>
-- Create date: <13/11/2017>
-- Description:	<This procedure puts in delete mode rows related to the CONTACT PERSON of the respective account>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_delete_Contact_Person] 
@new_Account_Id int


AS
BEGIN
Declare @party int,@person int
	SET NOCOUNT ON;

select @party = p2.PartyID,@person = pe.PersonID
from KYPEnrollment.pADM_Account a INNER JOIN KYPEnrollment.pAccount_PDM_Party p ON a.PartyID=p.PartyID
INNER JOIN  KYPEnrollment.pAccount_PDM_Party p2 ON p.PartyID=p2.ParentPartyID
INNER JOIN KYPEnrollment.pAccount_PDM_Person pe ON p2.PartyID=pe.PartyID
where a.AccountID=@new_Account_Id and p2.Type='Contact Person' 
and pe.CurrentRecordFlag=1 and p2.CurrentRecordFlag=1 and p2.IsDeleted=0

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Person','PersonID',@person

EXEC KYPEnrollment.turn_delete_tables 'pAccount_PDM_Party','PartyID',@party

END


GO

