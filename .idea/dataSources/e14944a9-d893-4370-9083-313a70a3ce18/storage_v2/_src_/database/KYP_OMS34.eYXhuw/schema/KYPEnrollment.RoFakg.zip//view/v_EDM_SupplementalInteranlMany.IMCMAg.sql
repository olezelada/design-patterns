
CREATE VIEW [KYPEnrollment].[v_EDM_SupplementalInteranlMany]
AS
SELECT *
	,CASE ISNULL(CodeIdentification, '')
		WHEN ''
			THEN CodeDescription
		ELSE isnull(CodeIdentification,'') + ' - ' + CodeDescription
		END AS 'CodeDescriptionFull'
FROM KYPEnrollment.EDM_SupplementalInteranlMany


GO

