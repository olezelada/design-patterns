-- =============================================
-- Author:		<Zelada Olegario>
-- Create date: <08/30/2018>
-- Description:	<copy documents instances ID to the account tables>
-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_Store_Copy_Table_Number_Docs]
@party_account_id int,
@account_table_name varchar (150),
@account_pk_name varchar(150)
AS
BEGIN

  DECLARE @tot INT
	DECLARE @cont INT
	DECLARE @documentInstanceId INT, @accountNumberId INT
	DECLARE @temporal TABLE(id INT IDENTITY (1, 1), documentInstanceId INT, accountNumberId INT)

   INSERT INTO @temporal (documentInstanceId, accountNumberId)
		SELECT appAC.documentInstanceId, accAC.NumberID FROM KYPEnrollment.pAccount_PDM_Number accAc
			INNER JOIN KYPPORTAL.PortalKYP.pPDM_Number appAC on appAC.NumberID = accAc.AppNumberID
		WHERE accAc.PartyID = @party_account_id


	SELECT @tot = MAX(id) FROM @temporal
	SET @cont = 1;

	WHILE @cont <= @tot
		BEGIN

			SELECT
				@documentInstanceId = t.documentInstanceId,
				@accountNumberId = t.accountNumberId
			FROM @temporal t
			WHERE t.id = @cont
			EXEC KYPEnrollment.sp_Store_Attachments_References NULL, @documentInstanceId, @accountNumberId,@account_table_name, @account_pk_name

			SET @cont = @cont + 1

		END
  END
GO

