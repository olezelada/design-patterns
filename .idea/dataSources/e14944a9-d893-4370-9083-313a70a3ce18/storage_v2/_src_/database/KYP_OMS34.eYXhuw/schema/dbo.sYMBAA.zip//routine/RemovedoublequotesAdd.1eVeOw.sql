-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[RemovedoublequotesAdd] 
(
	
	@NameValue varchar(500)
)
RETURNS varchar(500)
AS
BEGIN 
	
select @NameValue =
case 

when (charindex(char(34),@NameValue) = 1 and charindex(char(34),@NameValue,LEN(@NameValue)-1) = LEN(@NameValue))
      then substring(substring(@NameValue, 2, LEN(@NameValue)-1 ), 1, LEN(@NameValue)-2)
when charindex(char(34),@NameValue) = 1
      then substring(@NameValue, 2, LEN(@NameValue)-1)
when charindex(char(34),@NameValue,LEN(@NameValue)-1) = LEN(@NameValue)
      then substring(@NameValue, 1, LEN(@NameValue)-1)
else 
      @NameValue      
end   




return @NameValue
END


GO

