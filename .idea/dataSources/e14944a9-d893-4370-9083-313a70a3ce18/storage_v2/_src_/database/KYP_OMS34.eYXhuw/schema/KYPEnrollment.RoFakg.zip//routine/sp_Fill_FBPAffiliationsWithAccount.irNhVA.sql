-- =============================================  
-- Author:  <RLoayza>  
-- Create date: <02/09/2018>  
-- Description: <Fills table pPDM_FBPAffiliations in FBP cases that are affiliated with accounts>  
-- =============================================  
--Change History  
---------------------------------------------------------------------------------------  
-- Sl.No. JIRA No.   Author		Date			Description  
---------------------------------------------------------------------------------------  
--	1	KEN-20824	Sundar		19-May-2019		Added statement to avoid duplicate rendering in pAccount_renderingAffiliation table


CREATE PROCEDURE [KYPEnrollment].[sp_Fill_FBPAffiliationsWithAccount]  
    @application_no      VARCHAR(100),  
    @Account_Id          INT,  
    @application_Id      INT,  
    @last_action_user_id VARCHAR(100)  
  
AS  
BEGIN  
	PRINT 'CREATING AFFILIATION WITH FBP ACCOUNT'  

	DECLARE @date_create DATE,  
			@rendering_app_affiliation_id INT,  
			@group_email VARCHAR(100),  
			@type_affiliation VARCHAR(100),  
			@rendering_email VARCHAR(100),  
			@fillFBPID INT;  

	--SET @date_create = GETDATE();  
	SET NOCOUNT ON;  

	SELECT @date_create = DateCreated  
	FROM KYP.ADM_CASE with (nolock)  
	WHERE Number = @application_no  

	SELECT  
		@rendering_app_affiliation_id = rendering_affiliation_id,  
		@group_email = groupEmail,  
		@rendering_email = rendering_email,  
		@type_affiliation = type_affiliation  
	FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation]  
	WHERE rendering_providerNumber = @application_no AND isDeleted = 0;  

	IF NOT EXISTS(SELECT * FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations WHERE ApplicationID = @application_Id AND IsDeleted = 0)  
	BEGIN  
		PRINT 'NO ADDITIONAL FBP HAS BEEN SELECTED'  

		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AccountID]  
		, [AffiliatedAccountID]  
		, [TypeAffiliation]  
		, [LastActionDate]  
		, [LastActorUserID]  
		, [LastActionApprovedBy]  
		, [CurrentRecordFlag]  
		, [LastAction]  
		, [AffiliationStartDate]  
		, [LastUpdatedBy]  
		, [groupEmail]  
		, [rendering_email]  
		, [isDeleted])  
		SELECT  
		A.[accountId],  
		@Account_Id,  
		@type_affiliation,  
		--@date_create,  
		GETdate(), --Changed by Sundar on 12Sep2018 for CAPAVE-3992  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		B.DateCreated,  
		'P',  
		A.[groupEmail],  
		A.[renderingEmail],  
		0  
		FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] A  
		INNER JOIN kyp.adm_case B ON A.applicationNumber = B.Number  
		Left Join [KYPEnrollment].[pAccount_RenderingAffiliation] C on A.accountId = C.AccountID and C.AffiliatedAccountID = @Account_Id and C.isDeleted=0 --Added for KEN-20824
		WHERE rendering_affiliation_id = @rendering_app_affiliation_id  
			and C.RenderingAffiliationID is null --Added for KEN-20824
			AND A.accountId NOT IN (  
							SELECT FBPAccountID  
							FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations fbpAff  
							WHERE fbpAff.ApplicationID = @application_Id  
							  AND fbpAff.IsDeleted = 0  
							  AND fbpAff.FBPAccountID IS NOT NULL  
							);  

		INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
		([AffiliatedAccountID]  
		,[TypeAffiliation]  
		,[LastActionDate]  
		,[LastActorUserID]  
		,[LastActionApprovedBy]  
		,[CurrentRecordFlag]  
		,[LastAction]  
		,[AccountID]  
		,[AffiliationStartDate]  
		,[LastUpdatedBy]  
		,[groupEmail]  
		,[rendering_email]  
		,isDeleted)  
		SELECT @account_id,  
		A.[type_affiliation],  
		--@date_create,  
		GETdate(), --Changed by Sundar on 12Sep2018 for CAPAVE-3992  
		@last_action_user_id,  
		@last_action_user_id,  
		1,  
		'C',  
		A.[group_instance_id],  
		@date_create,  
		'P'  
		,A.[groupEmail]  
		,A.[rendering_email]  
		,0  
		FROM [KYPPORTAL].[PortalKYP].[pRenderingAffiliation] A
		Left Join [KYPEnrollment].[pAccount_RenderingAffiliation] B on A.group_instance_id = B.AccountID and B.AffiliatedAccountID = @account_id and B.isDeleted=0		--Added for KEN-20824
		WHERE rendering_providerNumber = @application_no
			and B.RenderingAffiliationID is null; --Added for KEN-20824 

		SET @fillFBPID = @@IDENTITY  
		RETURN @fillFBPID  
	END  

	PRINT 'CREATING AFFILIATIONS WITH ALL THE SELECTED ACCOUNTS'  

	INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
	([AccountID]  
	, [AffiliatedAccountID]  
	, [TypeAffiliation]  
	, [LastActionDate]  
	, [LastActorUserID]  
	, [LastActionApprovedBy]  
	, [CurrentRecordFlag]  
	, [LastAction]  
	, [AffiliationStartDate]  
	, [LastUpdatedBy]  
	, [groupEmail]  
	, [rendering_email]  
	, isDeleted)  
	SELECT  
	A.FBPAccountID,  
	@Account_Id,  
	@type_affiliation,  
	--@date_create,  
	GETdate(), --Changed by Sundar on 12Sep2018 for CAPAVE-3992  
	@last_action_user_id,  
	@last_action_user_id,  
	1,  
	'C',  
	@date_create,  
	'P',  
	@group_email,  
	@rendering_email,  
	0  
	FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations A
	Left Join [KYPEnrollment].[pAccount_RenderingAffiliation] B on A.FBPAccountID = B.AccountID and B.AffiliatedAccountID = @Account_Id and B.isDeleted=0		--Added for KEN-20824
	WHERE A.ApplicationID = @application_Id 
		AND A.IsDeleted = 0  
		and B.RenderingAffiliationID is null; --Added for KEN-20824 

	INSERT INTO [KYPEnrollment].[pAccount_RenderingAffiliation]  
	([AccountID]  
	, [AffiliatedAccountID]  
	, [TypeAffiliation]  
	, [LastActionDate]  
	, [LastActorUserID]  
	, [LastActionApprovedBy]  
	, [CurrentRecordFlag]  
	, [LastAction]  
	, [AffiliationStartDate]  
	, [LastUpdatedBy]  
	, [groupEmail]  
	, [rendering_email]  
	, [isDeleted])  
	SELECT  
	A.[accountId],  
	@Account_Id,  
	@type_affiliation,  
	--@date_create,  
	GETdate(), --Changed by Sundar on 12Sep2018 for CAPAVE-3992  
	@last_action_user_id,  
	@last_action_user_id,  
	1,  
	'C',  
	B.DateCreated,  
	'P',  
	A.[groupEmail],  
	A.[renderingEmail],  
	0  
	FROM [KYPPORTAL].[PortalKYP].[pAffiliationServiceAddress] A  
	INNER JOIN kyp.adm_case B ON A.applicationNumber = B.Number  
	Left Join [KYPEnrollment].[pAccount_RenderingAffiliation] C on A.accountId = C.AccountID and C.AffiliatedAccountID = @Account_Id and C.isDeleted=0 --Added for KEN-20824	
	WHERE A.rendering_affiliation_id = @rendering_app_affiliation_id  
		AND A.accountId NOT IN (  
				SELECT FBPAccountID  
				FROM KYPPORTAL.PortalKYP.pPDM_FBPAffiliations fbpAff  
				WHERE fbpAff.ApplicationID = @application_Id  
				AND fbpAff.IsDeleted = 0  
				AND fbpAff.FBPAccountID IS NOT NULL  
				)
		and C.RenderingAffiliationID is null; --Added for KEN-20824  

	RETURN @@IDENTITY  

END


GO

