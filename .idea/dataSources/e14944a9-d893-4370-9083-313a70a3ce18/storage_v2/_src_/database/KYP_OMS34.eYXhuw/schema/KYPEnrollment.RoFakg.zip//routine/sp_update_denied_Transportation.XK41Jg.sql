
-- =============================================
-- Author:		<hbustamante>
-- Create date: <04/11/2019>
-- Description:	<This procedure Update as Denied Vehicles and Operators records on supplemental apps, including (CHOA, Reenrollment, Revalidation)>

-- =============================================
CREATE PROCEDURE [KYPEnrollment].[sp_update_denied_Transportation]
   @party_id               INT
AS
BEGIN

	IF (@party_id IS NOT NULL)
	BEGIN

		SELECT accountEntityId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(o.TargetPath), 0, PATINDEX('%|%', (REVERSE(o.TargetPath))))), ''))
			, accountPartyId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(p.TargetPath), 0, PATINDEX('%|%', (REVERSE(p.TargetPath))))), ''))
			, typeEntity = 'pPDM_Operators'
			INTO #transportationInfo
		FROM KYPPORTAL.PortalKYP.pPDM_Operators o
			INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON p.PartyID = o.PartyID
		WHERE o.TargetPath LIKE '%pAccount%'
			AND o.IsDeleted = 0
			AND (o.Approved IS NOT NULL AND o.Approved = 0)
			AND p.ParentPartyID = @party_id

		UNION

		SELECT accountEntityId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(v.TargetPath), 0, PATINDEX('%|%', (REVERSE(v.TargetPath))))), ''))
			, accountPartyId = CONVERT(INT, ISNULL(REVERSE(SUBSTRING(REVERSE(p.TargetPath), 0, PATINDEX('%|%', (REVERSE(p.TargetPath))))), ''))
			, typeEntity = 'pPDM_Vehicle'
		FROM KYPPORTAL.PortalKYP.pPDM_Vehicle v
			INNER JOIN KYPPORTAL.PortalKYP.pPDM_Party p ON p.PartyID = v.PartyID
		WHERE v.TargetPath LIKE '%pAccount%'
			AND v.IsDeleted = 0
			AND (v.Approved IS NOT NULL AND v.Approved = 0)
			AND p.ParentPartyID = @party_id

		PRINT('DELETING OPERATORS DENIED ');
		UPDATE KYPEnrollment.pAccount_PDM_Operator
			SET CurrentRecordFlag = 0
				, Approved = 0
				, LastAction = 'U'
				, LastActionDate = GETDATE()
		WHERE OperatorId IN (SELECT accountEntityId FROM #transportationInfo WHERE typeEntity = 'pPDM_Operators')
			AND CurrentRecordFlag = 1

		PRINT('DELETING VEHICLES DENIED ');
		UPDATE KYPEnrollment.pAccount_PDM_Vehicle
			SET CurrentRecordFlag = 0
				, Approved = 0
				, LastAction = 'U'
				, LastActionDate = GETDATE()
		WHERE VehicleId IN (SELECT accountEntityId FROM #transportationInfo WHERE typeEntity = 'pPDM_Vehicle')
			AND CurrentRecordFlag = 1

		PRINT('DELETING Party for DENIED Vehicles and Operators ');
		UPDATE KYPEnrollment.pAccount_PDM_Party
			SET CurrentRecordFlag = 0
				, LastAction = 'U'
				, LastActionDate = GETDATE()
		WHERE PartyID IN (SELECT accountPartyId FROM #transportationInfo)
			AND CurrentRecordFlag = 1

		DROP TABLE #transportationInfo;
	END

END

GO

