

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[LinkedServerHMS]
@HMSServerName VARCHAR(250)
AS

BEGIN

DECLARE 

@HMSLoginServer VARCHAR(100),
@ExistCount1 INT


SET @HMSLoginServer = ''+@HMSServerName+''

	SELECT @ExistCount1 = COUNT(1) FROM sys.servers WHERE name = @HMSLoginServer

	IF @ExistCount1 = 0
		BEGIN
			EXECUTE sp_addlinkedserver @HMSLoginServer

		END



END


GO

