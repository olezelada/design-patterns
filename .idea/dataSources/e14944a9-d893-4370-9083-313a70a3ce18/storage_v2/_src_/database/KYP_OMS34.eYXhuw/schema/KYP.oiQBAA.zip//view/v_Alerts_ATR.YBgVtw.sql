




CREATE VIEW [KYP].[v_Alerts_ATR]
AS
SELECT TOP (100) PERCENT   row_number() OVER (ORDER BY B.AlertID ASC) AS ID,
	B.AlertID,
	B.AlertNo, 
	B.WatchlistName,
	B.IsMerged,--added for http://jira/browse/KYP-7824
	D.userID as AssignedToUserID,
	D.FullName as AssignmentUserIDName,
	B.ReasonCode as ReasonCode,
	B.MatchPercent,
	B.MatchStatusIndicatorDesc,
	b.AlertOpen,
	b.DateInitiated,
	A.ResolutionID,
	A.ResolutionType,
	A.ResolutionTypeID,
	A.ProviderMedicaidID AS 'MedicaidID', 
	A.ProviderName,
	E.ProvID AS 'ProviderID',
	H.ProviderTypeDescription as ProviderType, 
	A.ResolutionDate as ResolutionDate, 
	A.ResolutionByUserID,
	B.GK_WL_ID,
	C.Userid as ResolutionUserIDName,
	case 
		when B.WFStatus = 'Completed'
			then 'Closed'
		else 'Open'	
	end as AlertStatus,
	B.Priority
from 
KYP.MDM_Alert B
INNER JOIN KYP.MDM_AlertResolution  A
	ON A.AlertId = B.AlertID AND ISNULL(A.IsDeleted, 0) = 0 AND A.ResolutionTypeID NOT IN (5,6) 
	INNER JOIN KYP.OIS_User C
	ON A.ResolutionByUserID = C.PersonID	
	INNER JOIN KYP.OIS_User D
	ON B.AssignedToUserID = D.PersonID
	INNER JOIN KYP.PDM_Provider E
	ON A.ProviderID = E.ProvID
	inner join KYP.PDM_ProviderTypeCode H
	on E.Type = H.ProviderTypeCode
WHERE ISNULL(A.IsDeleted,0) =0 AND  ISNULL(B.IsDeleted,0) =0 AND B.WFStatus ='Completed'
--and Impacted =1
ORDER BY B.AlertID ASC


GO

