






CREATE PROCEDURE [KYPEnrollment].[sp_Create_Account_DPP]
   @application_id           INT
   , @party_account_id       INT
   , @application_type       VARCHAR (30)
   , @new_account_number     VARCHAR (20)
   , @newPackage             VARCHAR (20)
   , @provider_type_code     VARCHAR (50)
   , @risk                   VARCHAR (15)
   , @priority               VARCHAR (3)
   , @composite_risk         INT
   , @last_action_user_id    VARCHAR (100)
   , @EIN                    VARCHAR (20)


------------------------------------------

AS
BEGIN
   SET  NOCOUNT ON;
   DECLARE @date_created DATE, @account_id          INT;
   SET @date_created = GETDATE();

   INSERT INTO [KYPEnrollment].[pADM_Account]
	  ([portaluserid]
      ,[ProviderType]
      ,[NPI]
      ,[NPIType]
      ,[ApplicationNumber]
      --,[StatusAcc]
      ,[PartyID]
      ,[AccountNumber]
      ,[IsDeleted]
      ,[profile_id]
      ,[PackageName]
      ,[ProviderTypeCode]

      ,[RiskDescriptor]
      ,[OwnerNo]
      ,[Risk]
      ,[RiskScore]
      --,[StatusBeginDate]
      ,[IncorporatedDate]
      ,[ActivationDate]
      ,[DateCreated]
      --,[LastActionDate]
      ,[LastAction]
      --,[LastActorUserID]
      ,[LastActionApprovedBy]
      ,[AccountUpdatedBy]
      ,[ProvTypeUpdateDate]
      ,[CreatedBy]
      ,[AccProcessing]-- KEN-7045
      ,[IsProvOwnedData]
      ,[ApplicationDate]
      ,[DateModified]--KPP-6612
      ,[ProvLocTypeCd]
      ,ReenrollmentDate --KEN-17331
      ,EIN
      )

SELECT  [portaluserid]
		, @application_type
		,[NPI]
		,[NpiType]
		,[ApplicationNo]
		--,'3 - Pending'--change '1 - Active'
		,@party_account_id
		, @new_account_number
		,0
		,[profile_id]
		, @newPackage
		-------------------------------------------------------------
		,@provider_type_code
		-------------------------------------------------------------
		,@risk
		,'01'
		,@priority
		,@composite_risk
		--,@date_created
		,@date_created
		,@date_created
		,@date_created
		--,@date_created
		,'C'
		--,@last_action_user_id
		,@last_action_user_id
		,'P'
		,@date_created
		,@last_action_user_id
		,1
		,1
		,[DateCreated]
		,getdate()
		,CASE WHEN (EXISTS(select partyAddressId from #tempProviderType where appName=ApplicationNo and IsDeleted=0 and partyAddressId IS NOT NULL)
		 OR EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p
		 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioFacility' and p.IsDeleted=0))
		 THEN 'F' ELSE CASE WHEN EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p
		 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioHospital' and p.IsDeleted=0)
		 THEN 'H' ELSE CASE WHEN EXISTS(select p.PartyID from KYPPORTAL.PortalKYP.pPDM_PlaceBusiness p
		 where PartyID=p.PartyID and PrimaryAnswer='RadioThree' and SecondAnswer='RadioClinic' and p.IsDeleted=0)
		 THEN 'C' END END END
		 ,kypenrollment.ScheduleAccDate()--KEN-17331
		 ,@EIN


FROM [KYPPORTAL].[PortalKYP].[pADM_Application]
WHERE ApplicationID = @application_id;

SELECT @account_id = SCOPE_IDENTITY();
    PRINT 'Create New AccountID: '+ CONVERT(VARCHAR(10),@account_id);
    RETURN  @account_id;

END
GO

