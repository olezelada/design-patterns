CREATE VIEW [KYP].[V_CaseLevel_Counts] as
 select row_number() OVER (ORDER BY T1.CaseID ASC) AS ID ,T1.CaseID,COUNT(t1.CommentID) CaseCount
from kyp.ADM_Comments T1
where T1.IsActive = 1
Group by T1.CaseID


GO

