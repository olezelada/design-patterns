

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[GenerateAtypicalNPIValue] 
	-- Add the parameters for the stored procedure here
	(
	@ConfigField varchar(10),
	@ApplicationNumber VARCHAR(15),
	@NewNPI varchar(20) OUTPUT
	
	)
	
AS
BEGIN

Declare @NextNumber int;
Declare @CurrentNumber int;
Declare @Prefix varchar(10);

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.

	SET NOCOUNT ON;

	select  @CurrentNumber = NextNumber , @Prefix = Prefix
	from dbo.Atypical_Prov_No_Config 
	where ConfigField = @ConfigField;
	
	SET @NextNumber = @CurrentNumber + 1;
	
	SET @NewNPI = CASE WHEN @Prefix IS NULL THEN CAST(@CurrentNumber as varchar(10)) ELSE @prefix + CAST(@CurrentNumber as varchar(10)) END
 
    update dbo.Atypical_Prov_No_Config set NextNumber = @NextNumber where ConfigField = @ConfigField;
    
    print '@nextNumber : ' + CAST(@NextNumber as varchar(10)) 
	Print '@NewNPI : ' + @NewNPI
	
END


GO

