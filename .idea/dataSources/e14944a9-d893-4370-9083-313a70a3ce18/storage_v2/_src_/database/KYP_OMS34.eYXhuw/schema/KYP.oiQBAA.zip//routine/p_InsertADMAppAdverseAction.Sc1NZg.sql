/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertADMAppAdverseAction]
(@PartyID int
 ,@ApplicationID int= NULL
 ,@ActionAuthority varchar(100) =NULL
 ,@ActionDate datetime = NULL
 ,@ActionState varchar(25)=NULL
 ,@FromDate smalldatetime=NULL
 ,@ThroughDate smalldatetime=NULL
 ,@SanctionType int=NULL
 ,@SantionSubType int=NULL
 ,@SanctionCode varchar(15)=NULL
 ,@SanctionSummary varchar(100)=NULL
 ,@Remarks varchar(250)=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated smalldatetime=NULL
 ,@ModifiedBy int=NULL
 ,@DateModified smalldatetime=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted smalldatetime=NULL
 ,@IsDeleted bit=0
)
as begin 

INSERT INTO [KYP].[ADM_App_AdverseAction]
           ([PartyID]
           ,[ApplicationID]
           ,[ActionAuthority]
           ,[ActionDate]
           ,[ActionState]
           ,[FromDate]
           ,[ThroughDate]
           ,[SanctionType]
           ,[SantionSubType]
           ,[SanctionCode]
           ,[SanctionSummary]
           ,[Remarks]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DateModified]
           ,[DeletedBy]
           ,[DateDeleted]
           ,[IsDeleted])
     VALUES
           (@PartyID
           ,@ApplicationID
           ,@ActionAuthority
           ,@ActionDate
           ,@ActionState
           ,@FromDate
           ,@ThroughDate
           ,@SanctionType
           ,@SantionSubType
           ,@SanctionCode
           ,@SanctionSummary
           ,@Remarks
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DateModified
           ,@DeletedBy
           ,@DateDeleted
           ,@IsDeleted)

	return IDENT_CURRENT('[KYP].[ADM_App_AdverseAction]')

end


GO

