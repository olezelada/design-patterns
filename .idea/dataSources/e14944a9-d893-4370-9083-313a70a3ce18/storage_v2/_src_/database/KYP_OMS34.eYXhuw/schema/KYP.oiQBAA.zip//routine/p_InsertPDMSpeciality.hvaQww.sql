/******Script for insert procedure************/
CREATE PROCedure [KYP].[p_InsertPDMSpeciality]
(
  @PartyID int
 ,@Speciality_Code varchar(20) =NULL
 ,@DateModified Datetime=NULL
 ,@CreatedBy int=NULL
 ,@DateCreated datetime=NULL
 ,@ModifiedBy int=NULL
 ,@DeletedBy int=NULL
 ,@DateDeleted datetime=NULL
)
as begin 

INSERT INTO [KYP].[PDM_Speciality]
           ([PartyID]
           ,[Speciality_Code]
           ,[DateModified]
           ,[CreatedBy]
           ,[DateCreated]
           ,[ModifiedBy]
           ,[DeletedBy]
           ,[DateDeleted])
     VALUES
           (@PartyID
           ,@Speciality_Code
           ,@DateModified
           ,@CreatedBy
           ,@DateCreated
           ,@ModifiedBy
           ,@DeletedBy
           ,@DateDeleted)

	return IDENT_CURRENT('[KYP].[PDM_Speciality]')

end


GO

