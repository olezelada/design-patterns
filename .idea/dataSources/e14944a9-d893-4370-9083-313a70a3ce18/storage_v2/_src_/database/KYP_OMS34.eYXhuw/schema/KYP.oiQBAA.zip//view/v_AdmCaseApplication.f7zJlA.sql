
CREATE VIEW [KYP].[v_AdmCaseApplication]
AS
SELECT     c.PAN,c.AccountID,c.CaseID,c.Provider_NPI, c.ApplnType,c.DateReceived, c.WFMinorStep, a.NormalizedRisk,a.ApplicationNo,
c.TypeDescription,c.WFStatus,c.ProviderName,c.WFMajorStep,c.MILESTONE
FROM         KYP.ADM_Case AS c INNER JOIN
                      KYP.ADM_Application AS a ON c.CaseID = a.CaseID AND c.Number = a.ApplicationNo


GO

